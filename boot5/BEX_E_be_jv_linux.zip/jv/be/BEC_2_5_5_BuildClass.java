package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_5_BuildClass extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
public static BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;

public static BET_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public BEC_2_5_5_BuildClass bem_new_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevp_methods = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_isLocal = be.BECS_Runtime.boolFalse;
bevp_isNotNull = be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (new BEC_2_4_3_MathInt(0));
bevp_isList = be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = be.BECS_Runtime.boolFalse;
bevp_belsCount = (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_ta_ph);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_ta_ph);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) throws Throwable {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_emits == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 137*/ {
bevp_emits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 138*/
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevl_ret = bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_2));
bevt_1_ta_ph = bevl_ret.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
if (bevp_extends == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_3));
bevt_5_ta_ph = bevl_ret.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
} /* Line: 148*/
} /* Line: 147*/
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() throws Throwable {
return bevp_extends;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_extendsGetDirect_0() throws Throwable {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_extendsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() throws Throwable {
return bevp_emits;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitsGetDirect_0() throws Throwable {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_emitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() throws Throwable {
return bevp_methods;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_methodsGetDirect_0() throws Throwable {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_methodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() throws Throwable {
return bevp_orderedMethods;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGetDirect_0() throws Throwable {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_orderedMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() throws Throwable {
return bevp_used;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_usedGetDirect_0() throws Throwable {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_usedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() throws Throwable {
return bevp_freeFirstSlot;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_freeFirstSlotGetDirect_0() throws Throwable {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_freeFirstSlotSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() throws Throwable {
return bevp_firstSlotNative;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_firstSlotNativeGetDirect_0() throws Throwable {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_firstSlotNativeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() throws Throwable {
return bevp_nativeSlots;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nativeSlotsGetDirect_0() throws Throwable {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_nativeSlotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() throws Throwable {
return bevp_isList;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isListGetDirect_0() throws Throwable {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_isListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() throws Throwable {
return bevp_onceEvalCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_onceEvalCountGetDirect_0() throws Throwable {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_onceEvalCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() throws Throwable {
return bevp_referencedProperties;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_referencedPropertiesGetDirect_0() throws Throwable {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_referencedPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() throws Throwable {
return bevp_shouldWrite;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_shouldWriteGetDirect_0() throws Throwable {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_shouldWriteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() throws Throwable {
return bevp_belsCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_belsCountGetDirect_0() throws Throwable {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_belsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 123, 124, 124, 125, 127, 128, 128, 129, 133, 137, 137, 138, 140, 144, 145, 145, 146, 146, 146, 146, 147, 147, 148, 148, 148, 148, 151, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 69, 74, 79, 80, 82, 95, 96, 101, 102, 103, 104, 105, 106, 111, 112, 113, 114, 115, 118, 121, 124, 127, 131, 135, 138, 141, 145, 149, 152, 155, 159, 163, 166, 169, 173, 177, 180, 183, 187, 191, 194, 197, 201, 205, 208, 211, 215, 219, 222, 225, 229, 233, 236, 239, 243, 247, 250, 253, 257, 261, 264, 267, 271, 275, 278, 281, 285, 289, 292, 295, 299, 303, 306, 309, 313, 317, 320, 323, 327, 331, 334, 337, 341, 345, 348, 351, 355, 359, 362, 365, 369, 373, 376, 379, 383, 387, 390, 393, 397, 401, 404, 407, 411, 415, 418, 421, 425, 429, 432, 435, 439};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 103 42
new 0 103 42
assign 1 104 43
new 0 104 43
assign 1 105 44
new 0 105 44
assign 1 106 45
new 0 106 45
assign 1 107 46
new 0 107 46
assign 1 108 47
new 0 108 47
assign 1 109 48
new 0 109 48
assign 1 110 49
new 0 110 49
assign 1 111 50
new 0 111 50
assign 1 112 51
new 0 112 51
assign 1 113 52
new 0 113 52
assign 1 114 53
new 0 114 53
assign 1 115 54
new 0 115 54
assign 1 116 55
new 0 116 55
assign 1 117 56
new 0 117 56
assign 1 118 57
new 0 118 57
assign 1 123 58
new 0 123 58
assign 1 124 59
new 0 124 59
fromString 1 124 60
addUsed 1 125 61
assign 1 127 62
new 0 127 62
assign 1 128 63
new 0 128 63
fromString 1 128 64
addUsed 1 129 65
addValue 1 133 69
assign 1 137 74
undef 1 137 79
assign 1 138 80
new 0 138 80
addValue 1 140 82
assign 1 144 95
classNameGet 0 144 95
assign 1 145 96
def 1 145 101
assign 1 146 102
new 0 146 102
assign 1 146 103
add 1 146 103
assign 1 146 104
toString 0 146 104
assign 1 146 105
add 1 146 105
assign 1 147 106
def 1 147 111
assign 1 148 112
new 0 148 112
assign 1 148 113
add 1 148 113
assign 1 148 114
toString 0 148 114
assign 1 148 115
add 1 148 115
return 1 151 118
return 1 0 121
return 1 0 124
assign 1 0 127
assign 1 0 131
return 1 0 135
return 1 0 138
assign 1 0 141
assign 1 0 145
return 1 0 149
return 1 0 152
assign 1 0 155
assign 1 0 159
return 1 0 163
return 1 0 166
assign 1 0 169
assign 1 0 173
return 1 0 177
return 1 0 180
assign 1 0 183
assign 1 0 187
return 1 0 191
return 1 0 194
assign 1 0 197
assign 1 0 201
return 1 0 205
return 1 0 208
assign 1 0 211
assign 1 0 215
return 1 0 219
return 1 0 222
assign 1 0 225
assign 1 0 229
return 1 0 233
return 1 0 236
assign 1 0 239
assign 1 0 243
return 1 0 247
return 1 0 250
assign 1 0 253
assign 1 0 257
return 1 0 261
return 1 0 264
assign 1 0 267
assign 1 0 271
return 1 0 275
return 1 0 278
assign 1 0 281
assign 1 0 285
return 1 0 289
return 1 0 292
assign 1 0 295
assign 1 0 299
return 1 0 303
return 1 0 306
assign 1 0 309
assign 1 0 313
return 1 0 317
return 1 0 320
assign 1 0 323
assign 1 0 327
return 1 0 331
return 1 0 334
assign 1 0 337
assign 1 0 341
return 1 0 345
return 1 0 348
assign 1 0 351
assign 1 0 355
return 1 0 359
return 1 0 362
assign 1 0 365
assign 1 0 369
return 1 0 373
return 1 0 376
assign 1 0 379
assign 1 0 383
return 1 0 387
return 1 0 390
assign 1 0 393
assign 1 0 397
return 1 0 401
return 1 0 404
assign 1 0 407
assign 1 0 411
return 1 0 415
return 1 0 418
assign 1 0 421
assign 1 0 425
return 1 0 429
return 1 0 432
assign 1 0 435
assign 1 0 439
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1041001124: return bem_referencedPropertiesGetDirect_0();
case 1632241168: return bem_onceEvalCountGetDirect_0();
case 42922333: return bem_methodsGetDirect_0();
case 962458675: return bem_isFinalGet_0();
case -1582171867: return bem_extendsGetDirect_0();
case -1783211465: return bem_synGetDirect_0();
case 605889763: return bem_shouldWriteGetDirect_0();
case 2036853244: return bem_firstSlotNativeGetDirect_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case -392615944: return bem_firstSlotNativeGet_0();
case -1724453868: return bem_serializeToString_0();
case -665649433: return bem_serializeContents_0();
case -963084376: return bem_isListGet_0();
case -544280537: return bem_freeFirstSlotGet_0();
case -194416815: return bem_tagGet_0();
case 1955915393: return bem_fieldNamesGet_0();
case 684370014: return bem_belsCountGetDirect_0();
case 400000395: return bem_extendsGet_0();
case 378307569: return bem_copy_0();
case -1100045890: return bem_isLocalGet_0();
case 1490309456: return bem_onceEvalCountGet_0();
case -2054985135: return bem_referencedPropertiesGet_0();
case -149991782: return bem_orderedVarsGetDirect_0();
case 193084255: return bem_methodsGet_0();
case 1095297479: return bem_echo_0();
case -533443118: return bem_many_0();
case 474531258: return bem_nameGet_0();
case 461036156: return bem_isFinalGetDirect_0();
case 597730693: return bem_anyMapGetDirect_0();
case 280712282: return bem_toString_0();
case 617445256: return bem_sourceFileNameGet_0();
case 509361355: return bem_once_0();
case 1906961793: return bem_orderedVarsGet_0();
case -2145522431: return bem_anyMapGet_0();
case -157463425: return bem_libNameGetDirect_0();
case 1314592013: return bem_synGet_0();
case 1202074442: return bem_shouldWriteGet_0();
case -1054770809: return bem_namepathGetDirect_0();
case -1455899172: return bem_create_0();
case -281656014: return bem_fromFileGet_0();
case -1375638031: return bem_emitsGetDirect_0();
case 670510151: return bem_nameGetDirect_0();
case 1797865600: return bem_new_0();
case 1886318100: return bem_isListGetDirect_0();
case -119499799: return bem_serializationIteratorGet_0();
case 394550785: return bem_isLocalGetDirect_0();
case -180175097: return bem_classNameGet_0();
case 967234853: return bem_fieldIteratorGet_0();
case 1777587047: return bem_hashGet_0();
case 546297686: return bem_belsCountGet_0();
case 766881626: return bem_print_0();
case -1715766851: return bem_toAny_0();
case 1117137679: return bem_freeFirstSlotGetDirect_0();
case 1807707003: return bem_nativeSlotsGetDirect_0();
case -1080872716: return bem_orderedMethodsGet_0();
case -686600576: return bem_usedGetDirect_0();
case -232007930: return bem_libNameGet_0();
case 3394873: return bem_nativeSlotsGet_0();
case -84449434: return bem_isNotNullGet_0();
case 2011135674: return bem_iteratorGet_0();
case -332010808: return bem_orderedMethodsGetDirect_0();
case -1854296781: return bem_isNotNullGetDirect_0();
case -887382145: return bem_usedGet_0();
case -931713867: return bem_namepathGet_0();
case 1292676499: return bem_fromFileGetDirect_0();
case 1936065662: return bem_emitsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 744489232: return bem_libNameSet_1(bevd_0);
case -351003: return bem_synSet_1(bevd_0);
case -1230930851: return bem_fromFileSet_1(bevd_0);
case 779600292: return bem_orderedVarsSetDirect_1(bevd_0);
case -113905579: return bem_firstSlotNativeSet_1(bevd_0);
case -1016230318: return bem_synSetDirect_1(bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 720005040: return bem_methodsSet_1(bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case -813808957: return bem_orderedMethodsSet_1(bevd_0);
case -523606719: return bem_firstSlotNativeSetDirect_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1206441290: return bem_shouldWriteSet_1(bevd_0);
case -2080261350: return bem_anyMapSet_1(bevd_0);
case 748702186: return bem_isLocalSetDirect_1(bevd_0);
case -1339607150: return bem_isListSetDirect_1(bevd_0);
case -480111856: return bem_isNotNullSetDirect_1(bevd_0);
case 1107570162: return bem_nativeSlotsSetDirect_1(bevd_0);
case 972120318: return bem_extendsSet_1(bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case -244906494: return bem_anyMapSetDirect_1(bevd_0);
case 920182018: return bem_belsCountSetDirect_1(bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -46303633: return bem_isLocalSet_1(bevd_0);
case -1375952411: return bem_namepathSetDirect_1(bevd_0);
case -524112540: return bem_orderedMethodsSetDirect_1(bevd_0);
case -1565125791: return bem_shouldWriteSetDirect_1(bevd_0);
case -453410870: return bem_freeFirstSlotSet_1(bevd_0);
case 1597493187: return bem_libNameSetDirect_1(bevd_0);
case -1288177732: return bem_addEmit_1(bevd_0);
case -1088029253: return bem_addUsed_1(bevd_0);
case -445857610: return bem_notEquals_1(bevd_0);
case 1366069834: return bem_isNotNullSet_1(bevd_0);
case -783373260: return bem_nameSet_1(bevd_0);
case 702422225: return bem_onceEvalCountSet_1(bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case 916887003: return bem_referencedPropertiesSetDirect_1(bevd_0);
case 691683295: return bem_referencedPropertiesSet_1(bevd_0);
case 238379744: return bem_namepathSet_1(bevd_0);
case 1493560935: return bem_usedSet_1(bevd_0);
case 906320876: return bem_defined_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case 1702709244: return bem_extendsSetDirect_1(bevd_0);
case -292387069: return bem_belsCountSet_1(bevd_0);
case 2031409799: return bem_emitsSet_1(bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case -1482678801: return bem_onceEvalCountSetDirect_1(bevd_0);
case -1219149984: return bem_orderedVarsSet_1(bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case 1015239461: return bem_methodsSetDirect_1(bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2056106419: return bem_freeFirstSlotSetDirect_1(bevd_0);
case -961640007: return bem_isFinalSet_1(bevd_0);
case -316331850: return bem_emitsSetDirect_1(bevd_0);
case 107851339: return bem_nativeSlotsSet_1(bevd_0);
case 754647885: return bem_usedSetDirect_1(bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case -581068770: return bem_isFinalSetDirect_1(bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case -1494604406: return bem_isListSet_1(bevd_0);
case 1398765688: return bem_nameSetDirect_1(bevd_0);
case -322106874: return bem_fromFileSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildClass();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_type;
}
}
