package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_6_SystemThread extends BEC_2_6_10_SystemThinThread {
public BEC_2_6_6_SystemThread() { }
private static byte[] becc_BEC_2_6_6_SystemThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_6_SystemThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_inst;

public static BET_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_type;

public BEC_3_6_6_12_SystemThreadObjectLocker bevp_started;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_finished;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_threwException;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_returned;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_exception;
public BEC_2_6_6_SystemThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
bevp_started = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevp_finished = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_1_ta_ph);
bevp_threwException = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_returned = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_exception = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
super.bem_new_1(beva__toRun);
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
try /* Line: 490*/ {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
bevp_started.bem_oSet_1(bevt_0_ta_ph);
bevt_1_ta_ph = bevp_toRun.bemd_0(-1785533337);
bevp_returned.bem_oSet_1(bevt_1_ta_ph);
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
bevp_threwException.bem_oSet_1(bevt_2_ta_ph);
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_3_ta_ph);
} /* Line: 494*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
bevp_threwException.bem_oSet_1(bevt_4_ta_ph);
bevp_exception.bem_oSet_1(bevl_e);
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_5_ta_ph);
} /* Line: 498*/
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGet_0() throws Throwable {
return bevp_started;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGet_0() throws Throwable {
return bevp_finished;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGet_0() throws Throwable {
return bevp_threwException;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGet_0() throws Throwable {
return bevp_returned;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGet_0() throws Throwable {
return bevp_exception;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {479, 479, 480, 480, 481, 482, 483, 485, 491, 491, 492, 492, 493, 493, 494, 494, 496, 496, 497, 498, 498, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 24, 25, 26, 27, 28, 40, 41, 42, 43, 44, 45, 46, 47, 51, 52, 53, 54, 55, 60, 63, 67, 70, 74, 77, 81, 84, 88, 91};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 479 21
new 0 479 21
assign 1 479 22
new 1 479 22
assign 1 480 23
new 0 480 23
assign 1 480 24
new 1 480 24
assign 1 481 25
new 0 481 25
assign 1 482 26
new 0 482 26
assign 1 483 27
new 0 483 27
new 1 485 28
assign 1 491 40
new 0 491 40
oSet 1 491 41
assign 1 492 42
main 0 492 42
oSet 1 492 43
assign 1 493 44
new 0 493 44
oSet 1 493 45
assign 1 494 46
new 0 494 46
oSet 1 494 47
assign 1 496 51
new 0 496 51
oSet 1 496 52
oSet 1 497 53
assign 1 498 54
new 0 498 54
oSet 1 498 55
return 1 0 60
assign 1 0 63
return 1 0 67
assign 1 0 70
return 1 0 74
assign 1 0 77
return 1 0 81
assign 1 0 84
return 1 0 88
assign 1 0 91
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1785533337: return bem_main_0();
case -2101684619: return bem_new_0();
case 1838376897: return bem_returnedGet_0();
case 1488878514: return bem_wait_0();
case 1319233284: return bem_iteratorGet_0();
case 156015624: return bem_startedGet_0();
case -1134995215: return bem_finishedGet_0();
case -428175563: return bem_toString_0();
case -1677484548: return bem_print_0();
case -1715211966: return bem_hashGet_0();
case -2035524442: return bem_start_0();
case -414672201: return bem_create_0();
case -2049427190: return bem_exceptionGet_0();
case 1749455096: return bem_copy_0();
case 613906102: return bem_toRunGet_0();
case -1474708987: return bem_threwExceptionGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -329682344: return bem_undef_1(bevd_0);
case 393805114: return bem_exceptionSet_1(bevd_0);
case 36557867: return bem_toRunSet_1(bevd_0);
case -760176780: return bem_copyTo_1(bevd_0);
case -1513472994: return bem_new_1(bevd_0);
case 1448278255: return bem_startedSet_1(bevd_0);
case -2145623505: return bem_finishedSet_1(bevd_0);
case 799679410: return bem_threwExceptionSet_1(bevd_0);
case 1550265543: return bem_returnedSet_1(bevd_0);
case 1789302952: return bem_notEquals_1(bevd_0);
case 183362921: return bem_equals_1(bevd_0);
case 1228234604: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -355340329: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 365672883: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -519546757: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -242597694: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemThread_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_6_SystemThread_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemThread();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst = (BEC_2_6_6_SystemThread) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_type;
}
}
