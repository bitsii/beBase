package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemThread extends BEC_2_6_10_SystemThinThread {
public BEC_2_6_6_SystemThread() { }
private static byte[] becc_BEC_2_6_6_SystemThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_6_SystemThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_inst;

public static BET_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_type;

public BEC_3_6_6_12_SystemThreadObjectLocker bevp_started;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_finished;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_threwException;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_returned;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_exception;
public BEC_2_6_6_SystemThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_started = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_finished = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_1_tmpany_phold);
bevp_threwException = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_returned = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_exception = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
super.bem_new_1(beva__toRun);
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
try  /* Line: 758 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_started.bem_oSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_toRun.bemd_0(-245308576);
bevp_returned.bem_oSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_threwException.bem_oSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_3_tmpany_phold);
} /* Line: 762 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_threwException.bem_oSet_1(bevt_4_tmpany_phold);
bevp_exception.bem_oSet_1(bevl_e);
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_5_tmpany_phold);
} /* Line: 766 */
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGet_0() throws Throwable {
return bevp_started;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGet_0() throws Throwable {
return bevp_finished;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGet_0() throws Throwable {
return bevp_threwException;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGet_0() throws Throwable {
return bevp_returned;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGet_0() throws Throwable {
return bevp_exception;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {747, 747, 748, 748, 749, 750, 751, 753, 759, 759, 760, 760, 761, 761, 762, 762, 764, 764, 765, 766, 766, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 24, 25, 26, 27, 28, 40, 41, 42, 43, 44, 45, 46, 47, 51, 52, 53, 54, 55, 60, 63, 67, 70, 74, 77, 81, 84, 88, 91};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 747 21
new 0 747 21
assign 1 747 22
new 1 747 22
assign 1 748 23
new 0 748 23
assign 1 748 24
new 1 748 24
assign 1 749 25
new 0 749 25
assign 1 750 26
new 0 750 26
assign 1 751 27
new 0 751 27
new 1 753 28
assign 1 759 40
new 0 759 40
oSet 1 759 41
assign 1 760 42
main 0 760 42
oSet 1 760 43
assign 1 761 44
new 0 761 44
oSet 1 761 45
assign 1 762 46
new 0 762 46
oSet 1 762 47
assign 1 764 51
new 0 764 51
oSet 1 764 52
oSet 1 765 53
assign 1 766 54
new 0 766 54
oSet 1 766 55
return 1 0 60
assign 1 0 63
return 1 0 67
assign 1 0 70
return 1 0 74
assign 1 0 77
return 1 0 81
assign 1 0 84
return 1 0 88
assign 1 0 91
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 628140821: return bem_wait_0();
case -41023079: return bem_iteratorGet_0();
case 1043984390: return bem_once_0();
case 761778979: return bem_create_0();
case 169398438: return bem_hashGet_0();
case 561897572: return bem_start_0();
case 512670579: return bem_deserializeClassNameGet_0();
case 1186229381: return bem_exceptionGet_0();
case 2090767709: return bem_many_0();
case -35948872: return bem_toRunGet_0();
case -1662177650: return bem_classNameGet_0();
case -1120421430: return bem_print_0();
case 605404858: return bem_tagGet_0();
case 697531305: return bem_startedGet_0();
case 764622375: return bem_finishedGet_0();
case 751706402: return bem_copy_0();
case 2079084965: return bem_toString_0();
case 1387818040: return bem_new_0();
case 1315558702: return bem_sourceFileNameGet_0();
case -245308576: return bem_main_0();
case -1165063866: return bem_serializeContents_0();
case -1032373300: return bem_echo_0();
case 2033350872: return bem_serializeToString_0();
case -1211925955: return bem_threwExceptionGet_0();
case 1783116813: return bem_returnedGet_0();
case -364109840: return bem_serializationIteratorGet_0();
case 763461621: return bem_toAny_0();
case -268528295: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -462169728: return bem_startedSet_1(bevd_0);
case -7557996: return bem_toRunSet_1(bevd_0);
case -550476304: return bem_sameType_1(bevd_0);
case -1883179408: return bem_returnedSet_1(bevd_0);
case 1646725461: return bem_copyTo_1(bevd_0);
case -132994488: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 327020484: return bem_sameObject_1(bevd_0);
case -1573551110: return bem_threwExceptionSet_1(bevd_0);
case -1628072592: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -95156212: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 969791765: return bem_finishedSet_1(bevd_0);
case -173923543: return bem_def_1(bevd_0);
case 932249623: return bem_sameClass_1(bevd_0);
case -1095756156: return bem_new_1(bevd_0);
case -176889091: return bem_exceptionSet_1(bevd_0);
case 611966660: return bem_equals_1(bevd_0);
case -1179778534: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1953673516: return bem_undef_1(bevd_0);
case -46023056: return bem_notEquals_1(bevd_0);
case -400783475: return bem_undefined_1(bevd_0);
case 1296533558: return bem_otherClass_1(bevd_0);
case -1578179895: return bem_defined_1(bevd_0);
case 1479785081: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -501684028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815708233: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1424200790: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1920722583: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806507047: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1733811664: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1465498474: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemThread_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemThread_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemThread();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst = (BEC_2_6_6_SystemThread) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_type;
}
}
