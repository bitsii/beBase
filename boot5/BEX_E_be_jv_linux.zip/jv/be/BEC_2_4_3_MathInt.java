package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_0 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_1 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_2 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_3 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_5 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_6 = (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_7 = (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_9 = (new BEC_2_4_3_MathInt(24));
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_0, 39));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_11 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_12 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_13 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_14 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_15 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_17 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_18 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_19 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_20 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_21 = (new BEC_2_4_3_MathInt(43));
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_1, 21));
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_25 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_26 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_27 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_28 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_29 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_30 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_31 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_32 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_33 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_34 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_35 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_36 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_38 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt());
return (BEC_2_4_3_MathInt) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_2;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_3;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_4;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_5;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_7;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_8;
if (beva_radix.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_9;
if (beva_radix.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_10;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_radix);
bevt_5_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 95 */
bevt_9_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_11;
if (beva_radix.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 98 */
 else  /* Line: 99 */ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 100 */
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_11_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_12;
bevt_13_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_13;
bevt_12_tmpany_phold = beva_radix.bem_subtract_1(bevt_13_tmpany_phold);
bevl_maxA = bevt_11_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_14;
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_15;
bevt_15_tmpany_phold = beva_radix.bem_subtract_1(bevt_16_tmpany_phold);
bevl_maxa = bevt_14_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_j = bevt_4_tmpany_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 114 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_16;
if (bevl_j.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 114 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_17;
if (bevl_ic.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 118 */ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 118 */
 else  /* Line: 118 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 118 */ {
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 121 */
 else  /* Line: 118 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_18;
if (bevl_ic.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 122 */ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 122 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 122 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 122 */
 else  /* Line: 122 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 122 */ {
bevt_14_tmpany_phold = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 125 */
 else  /* Line: 118 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_19;
if (bevl_ic.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 126 */ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 126 */ {
bevt_18_tmpany_phold = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 129 */
 else  /* Line: 118 */ {
bevt_20_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_20;
if (bevl_ic.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_21_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_tmpany_phold);
} /* Line: 132 */
 else  /* Line: 118 */ {
bevt_23_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_21;
if (bevl_ic.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 133 */ {
} /* Line: 133 */
 else  /* Line: 135 */ {
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_22;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(beva_str);
bevt_29_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_23;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevl_ic);
bevt_24_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 136 */
} /* Line: 118 */
} /* Line: 118 */
} /* Line: 118 */
} /* Line: 118 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 139 */
 else  /* Line: 114 */ {
break;
} /* Line: 114 */
} /* Line: 114 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_24;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_25;
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) bevt_6_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, bevt_3_tmpany_phold, bevt_5_tmpany_phold, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_toHexString_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_26;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_27;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_3(beva_res, bevt_1_tmpany_phold, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_28;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, beva_zeroPad, beva_radix, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_29;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 212 */ {
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_30;
if (bevl_ts.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_31;
if (bevl_val.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_tmpany_phold.bevi_int;
} /* Line: 216 */
 else  /* Line: 217 */ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 218 */
bevt_6_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int <= bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_9_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_32;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpany_phold);
} /* Line: 222 */
bevt_11_tmpany_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpany_phold, bevl_val);
bevt_13_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_33;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 229 */
 else  /* Line: 212 */ {
break;
} /* Line: 212 */
} /* Line: 212 */
while (true)
 /* Line: 232 */ {
bevt_19_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_19_tmpany_phold.bevi_int < beva_zeroPad.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 232 */ {
bevt_21_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_21_tmpany_phold.bevi_int <= bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_24_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_34;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpany_phold);
} /* Line: 234 */
bevt_26_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_35;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_36;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpany_phold);
} /* Line: 238 */
 else  /* Line: 232 */ {
break;
} /* Line: 232 */
} /* Line: 232 */
bevt_36_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_37;
if (bevi_int < bevt_36_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 243 */
bevt_38_tmpany_phold = beva_res.bem_reverseBytes_0();
return bevt_38_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_absValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_38;
if (bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_tmpany_phold);
} /* Line: 260 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 280 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /* Line: 287 */
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 295 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /* Line: 302 */
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 338 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /* Line: 345 */
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 367 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /* Line: 374 */
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 396 */ {
bevl_res = (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /* Line: 403 */
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 425 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /* Line: 437 */
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 464 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /* Line: 471 */
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 612 */ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 612 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 612 */
 else  /* Line: 612 */ {
break;
} /* Line: 612 */
} /* Line: 612 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {75, 75, 78, 82, 86, 86, 86, 86, 86, 86, 86, 86, 86, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94, 94, 94, 0, 94, 94, 94, 0, 0, 95, 95, 95, 95, 97, 97, 97, 98, 100, 102, 102, 103, 103, 103, 103, 104, 104, 104, 104, 105, 109, 109, 110, 110, 111, 112, 113, 114, 114, 114, 116, 118, 118, 118, 118, 118, 0, 0, 0, 119, 119, 120, 121, 122, 122, 122, 122, 122, 0, 0, 0, 123, 123, 124, 125, 126, 126, 126, 126, 126, 0, 0, 0, 127, 127, 128, 129, 130, 130, 130, 132, 132, 133, 133, 133, 136, 136, 136, 136, 136, 136, 136, 138, 139, 144, 144, 148, 152, 152, 156, 167, 185, 189, 189, 189, 189, 189, 189, 189, 189, 193, 193, 193, 193, 197, 197, 197, 197, 197, 197, 201, 201, 201, 201, 201, 205, 205, 205, 205, 209, 210, 211, 212, 212, 212, 213, 214, 215, 215, 215, 216, 216, 218, 221, 221, 221, 221, 222, 222, 222, 222, 224, 224, 225, 225, 225, 225, 229, 232, 232, 232, 233, 233, 233, 233, 234, 234, 234, 234, 236, 236, 236, 236, 237, 237, 237, 237, 242, 242, 242, 243, 243, 245, 245, 249, 250, 251, 255, 255, 255, 259, 259, 259, 260, 260, 276, 281, 287, 296, 302, 320, 334, 339, 345, 363, 368, 374, 392, 397, 403, 421, 426, 437, 460, 465, 471, 489, 493, 504, 518, 522, 533, 547, 551, 562, 576, 580, 591, 605, 610, 612, 612, 612, 613, 612, 615, 647, 647, 676, 676, 697, 697, 718, 718, 739, 739, 760, 760};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {70, 71, 74, 78, 90, 91, 92, 93, 94, 95, 96, 97, 98, 110, 111, 112, 113, 114, 115, 116, 117, 118, 142, 143, 148, 149, 152, 153, 158, 159, 162, 166, 167, 168, 169, 171, 172, 177, 178, 181, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 230, 231, 232, 233, 234, 235, 236, 239, 240, 245, 246, 247, 248, 253, 254, 259, 260, 263, 267, 270, 271, 272, 273, 276, 277, 282, 283, 288, 289, 292, 296, 299, 300, 301, 302, 305, 306, 311, 312, 317, 318, 321, 325, 328, 329, 330, 331, 334, 335, 340, 341, 342, 345, 346, 351, 354, 355, 356, 357, 358, 359, 360, 366, 367, 377, 378, 381, 386, 387, 390, 394, 397, 407, 408, 409, 410, 411, 412, 413, 414, 420, 421, 422, 423, 431, 432, 433, 434, 435, 436, 443, 444, 445, 446, 447, 453, 454, 455, 456, 500, 501, 502, 505, 506, 511, 512, 513, 514, 515, 520, 521, 522, 525, 527, 528, 529, 534, 535, 536, 537, 538, 540, 541, 542, 543, 544, 545, 546, 554, 555, 560, 561, 562, 563, 568, 569, 570, 571, 572, 574, 575, 576, 577, 578, 579, 580, 581, 587, 588, 593, 594, 595, 597, 598, 602, 603, 604, 609, 610, 611, 617, 618, 623, 624, 625, 632, 638, 641, 648, 651, 657, 662, 668, 671, 677, 683, 686, 692, 698, 701, 707, 713, 716, 722, 728, 731, 737, 741, 744, 749, 753, 756, 761, 765, 768, 773, 777, 780, 785, 791, 792, 795, 800, 801, 802, 808, 817, 818, 827, 828, 837, 838, 847, 848, 857, 858, 867, 868};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 75 70
new 0 75 70
return 1 75 71
setStringValueDec 1 78 74
setStringValueHex 1 82 78
assign 1 86 90
new 0 86 90
assign 1 86 91
once 0 86 91
assign 1 86 92
new 0 86 92
assign 1 86 93
once 0 86 93
assign 1 86 94
new 0 86 94
assign 1 86 95
once 0 86 95
assign 1 86 96
new 0 86 96
assign 1 86 97
once 0 86 97
setStringValue 5 86 98
assign 1 90 110
new 0 90 110
assign 1 90 111
once 0 90 111
assign 1 90 112
new 0 90 112
assign 1 90 113
once 0 90 113
assign 1 90 114
new 0 90 114
assign 1 90 115
once 0 90 115
assign 1 90 116
new 0 90 116
assign 1 90 117
once 0 90 117
setStringValue 5 90 118
assign 1 94 142
new 0 94 142
assign 1 94 143
lesser 1 94 148
assign 1 0 149
assign 1 94 152
new 0 94 152
assign 1 94 153
greater 1 94 158
assign 1 0 159
assign 1 0 162
assign 1 95 166
new 0 95 166
assign 1 95 167
add 1 95 167
assign 1 95 168
new 1 95 168
throw 1 95 169
assign 1 97 171
new 0 97 171
assign 1 97 172
lesser 1 97 177
assign 1 98 178
copy 0 98 178
assign 1 100 181
new 0 100 181
assign 1 102 183
new 0 102 183
addValue 1 102 184
assign 1 103 185
new 0 103 185
assign 1 103 186
new 0 103 186
assign 1 103 187
subtract 1 103 187
assign 1 103 188
add 1 103 188
assign 1 104 189
new 0 104 189
assign 1 104 190
new 0 104 190
assign 1 104 191
subtract 1 104 191
assign 1 104 192
add 1 104 192
setStringValue 5 105 193
assign 1 109 230
new 0 109 230
setValue 1 109 231
assign 1 110 232
sizeGet 0 110 232
assign 1 110 233
copy 0 110 233
decrementValue 0 111 234
assign 1 112 235
new 0 112 235
assign 1 113 236
new 0 113 236
assign 1 114 239
new 0 114 239
assign 1 114 240
greaterEquals 1 114 245
getInt 2 116 246
assign 1 118 247
new 0 118 247
assign 1 118 248
greater 1 118 253
assign 1 118 254
lesser 1 118 259
assign 1 0 260
assign 1 0 263
assign 1 0 267
assign 1 119 270
new 0 119 270
subtractValue 1 119 271
multiplyValue 1 120 272
addValue 1 121 273
assign 1 122 276
new 0 122 276
assign 1 122 277
greater 1 122 282
assign 1 122 283
lesser 1 122 288
assign 1 0 289
assign 1 0 292
assign 1 0 296
assign 1 123 299
new 0 123 299
subtractValue 1 123 300
multiplyValue 1 124 301
addValue 1 125 302
assign 1 126 305
new 0 126 305
assign 1 126 306
greater 1 126 311
assign 1 126 312
lesser 1 126 317
assign 1 0 318
assign 1 0 321
assign 1 0 325
assign 1 127 328
new 0 127 328
subtractValue 1 127 329
multiplyValue 1 128 330
addValue 1 129 331
assign 1 130 334
new 0 130 334
assign 1 130 335
equals 1 130 340
assign 1 132 341
new 0 132 341
multiplyValue 1 132 342
assign 1 133 345
new 0 133 345
assign 1 133 346
equals 1 133 351
assign 1 136 354
new 0 136 354
assign 1 136 355
add 1 136 355
assign 1 136 356
new 0 136 356
assign 1 136 357
add 1 136 357
assign 1 136 358
add 1 136 358
assign 1 136 359
new 1 136 359
throw 1 136 360
decrementValue 0 138 366
multiplyValue 1 139 367
assign 1 144 377
toString 0 144 377
return 1 144 378
new 1 148 381
assign 1 152 386
new 0 152 386
return 1 152 387
return 1 156 390
assign 1 167 394
new 0 167 394
return 1 185 397
assign 1 189 407
new 0 189 407
assign 1 189 408
new 1 189 408
assign 1 189 409
new 0 189 409
assign 1 189 410
once 0 189 410
assign 1 189 411
new 0 189 411
assign 1 189 412
once 0 189 412
assign 1 189 413
toString 4 189 413
return 1 189 414
assign 1 193 420
new 0 193 420
assign 1 193 421
new 1 193 421
assign 1 193 422
toHexString 1 193 422
return 1 193 423
assign 1 197 431
new 0 197 431
assign 1 197 432
once 0 197 432
assign 1 197 433
new 0 197 433
assign 1 197 434
once 0 197 434
assign 1 197 435
toString 3 197 435
return 1 197 436
assign 1 201 443
new 1 201 443
assign 1 201 444
new 0 201 444
assign 1 201 445
once 0 201 445
assign 1 201 446
toString 4 201 446
return 1 201 447
assign 1 205 453
new 0 205 453
assign 1 205 454
once 0 205 454
assign 1 205 455
toString 4 205 455
return 1 205 456
clear 0 209 500
assign 1 210 501
abs 0 210 501
assign 1 211 502
new 0 211 502
assign 1 212 505
new 0 212 505
assign 1 212 506
greater 1 212 511
setValue 1 213 512
modulusValue 1 214 513
assign 1 215 514
new 0 215 514
assign 1 215 515
lesser 1 215 520
assign 1 216 521
new 0 216 521
addValue 1 216 522
addValue 1 218 525
assign 1 221 527
capacityGet 0 221 527
assign 1 221 528
sizeGet 0 221 528
assign 1 221 529
lesserEquals 1 221 534
assign 1 222 535
capacityGet 0 222 535
assign 1 222 536
new 0 222 536
assign 1 222 537
add 1 222 537
capacitySet 1 222 538
assign 1 224 540
sizeGet 0 224 540
setIntUnchecked 2 224 541
assign 1 225 542
sizeGet 0 225 542
assign 1 225 543
new 0 225 543
assign 1 225 544
add 1 225 544
sizeSet 1 225 545
divideValue 1 229 546
assign 1 232 554
sizeGet 0 232 554
assign 1 232 555
lesser 1 232 560
assign 1 233 561
capacityGet 0 233 561
assign 1 233 562
sizeGet 0 233 562
assign 1 233 563
lesserEquals 1 233 568
assign 1 234 569
capacityGet 0 234 569
assign 1 234 570
new 0 234 570
assign 1 234 571
add 1 234 571
capacitySet 1 234 572
assign 1 236 574
sizeGet 0 236 574
assign 1 236 575
new 0 236 575
assign 1 236 576
once 0 236 576
setIntUnchecked 2 236 577
assign 1 237 578
sizeGet 0 237 578
assign 1 237 579
new 0 237 579
assign 1 237 580
add 1 237 580
sizeSet 1 237 581
assign 1 242 587
new 0 242 587
assign 1 242 588
lesser 1 242 593
assign 1 243 594
new 0 243 594
addValue 1 243 595
assign 1 245 597
reverseBytes 0 245 597
return 1 245 598
assign 1 249 602
new 0 249 602
setValue 1 250 603
return 1 251 604
assign 1 255 609
copy 0 255 609
assign 1 255 610
absValue 0 255 610
return 1 255 611
assign 1 259 617
new 0 259 617
assign 1 259 618
lesser 1 259 623
assign 1 260 624
new 0 260 624
multiplyValue 1 260 625
return 1 276 632
assign 1 281 638
new 0 281 638
return 1 287 641
assign 1 296 648
new 0 296 648
return 1 302 651
return 1 320 657
return 1 334 662
assign 1 339 668
new 0 339 668
return 1 345 671
return 1 363 677
assign 1 368 683
new 0 368 683
return 1 374 686
return 1 392 692
assign 1 397 698
new 0 397 698
return 1 403 701
return 1 421 707
assign 1 426 713
new 0 426 713
return 1 437 716
return 1 460 722
assign 1 465 728
new 0 465 728
return 1 471 731
return 1 489 737
assign 1 493 741
new 0 493 741
return 1 504 744
return 1 518 749
assign 1 522 753
new 0 522 753
return 1 533 756
return 1 547 761
assign 1 551 765
new 0 551 765
return 1 562 768
return 1 576 773
assign 1 580 777
new 0 580 777
return 1 591 780
return 1 605 785
assign 1 610 791
new 0 610 791
assign 1 612 792
new 0 612 792
assign 1 612 795
lesser 1 612 800
multiplyValue 1 613 801
incrementValue 0 612 802
return 1 615 808
assign 1 647 817
new 0 647 817
return 1 647 818
assign 1 676 827
new 0 676 827
return 1 676 828
assign 1 697 837
new 0 697 837
return 1 697 838
assign 1 718 847
new 0 718 847
return 1 718 848
assign 1 739 857
new 0 739 857
return 1 739 858
assign 1 760 867
new 0 760 867
return 1 760 868
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1009286812: return bem_iteratorGet_0();
case 1071019003: return bem_toHexString_0();
case -138934452: return bem_serializationIteratorGet_0();
case -162465408: return bem_classNameGet_0();
case -1653065356: return bem_serializeToString_0();
case -826924838: return bem_fieldIteratorGet_0();
case 357618761: return bem_new_0();
case -1528945516: return bem_fieldNamesGet_0();
case 71860751: return bem_create_0();
case 1899370103: return bem_echo_0();
case 1181744069: return bem_decrementValue_0();
case 1491676822: return bem_decrement_0();
case 783668861: return bem_increment_0();
case -486535795: return bem_vintSet_0();
case 1555639231: return bem_print_0();
case 1881523822: return bem_deserializeClassNameGet_0();
case -971929648: return bem_abs_0();
case 206708983: return bem_incrementValue_0();
case 1901482140: return bem_tagGet_0();
case -1774143633: return bem_once_0();
case -275244597: return bem_hashGet_0();
case 216387563: return bem_many_0();
case -716934857: return bem_serializeContents_0();
case -532934283: return bem_absValue_0();
case -2101622436: return bem_sourceFileNameGet_0();
case 1570211646: return bem_toFloat_0();
case -2036889336: return bem_toAny_0();
case -702348589: return bem_toString_0();
case -1287228905: return bem_vintGet_0();
case -1118611827: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -255836966: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -1402682949: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case 107285016: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case -2130714868: return bem_equals_1(bevd_0);
case 499708117: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1353620660: return bem_sameClass_1(bevd_0);
case -1082439894: return bem_sameObject_1(bevd_0);
case 1095159782: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case -187298939: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1005236051: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case -45803309: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case -1339829082: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1772686279: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case 1193778385: return bem_undefined_1(bevd_0);
case 140255657: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -1148136203: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 66254795: return bem_sameType_1(bevd_0);
case 229887499: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 487961: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1357210760: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case -536891364: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1165078064: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1372480825: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1493100314: return bem_otherClass_1(bevd_0);
case 1459678776: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1990527902: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case -1750512772: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case -2109980302: return bem_undef_1(bevd_0);
case -1308008296: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case -1507231722: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 2082558825: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -959745115: return bem_otherType_1(bevd_0);
case -68723535: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 814727407: return bem_notEquals_1(bevd_0);
case 2027670755: return bem_defined_1(bevd_0);
case -2035726901: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -23180754: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case -1759126894: return bem_new_1(bevd_0);
case 1137403549: return bem_copyTo_1(bevd_0);
case -1897473612: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case 608090978: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case -287302116: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 1325575386: return bem_def_1(bevd_0);
case -573324881: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1493417805: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 70790709: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020619337: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 163657925: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -478914702: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1186365239: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2063942247: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686267336: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271558857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1157880701: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 330764968: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1602404479: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1269077525: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
