package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
public static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt());
return (BEC_2_4_3_MathInt) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(97));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(71));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(103));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_9_SystemException bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
if (beva_radix.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(24));
if (beva_radix.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 100*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 100*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_4_3_MathInt_bels_0));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_radix);
bevt_5_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_ta_ph);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 101*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(10));
if (beva_radix.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 103*/ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 104*/
 else /* Line: 105*/ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 106*/
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_ta_ph.bevi_int;
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_12_ta_ph = beva_radix.bem_subtract_1(bevt_13_ta_ph);
bevl_maxA = bevt_11_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(97));
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_15_ta_ph = beva_radix.bem_subtract_1(bevt_16_ta_ph);
bevl_maxa = bevt_14_ta_ph.bem_add_1(bevt_15_ta_ph);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_9_SystemException bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_ta_ph.bevi_int;
bevt_4_ta_ph = beva_str.bem_lengthGet_0();
bevl_j = bevt_4_ta_ph.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 120*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 120*/ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 124*/ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 124*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 124*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 124*/
 else /* Line: 124*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 124*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 127*/
 else /* Line: 124*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 128*/ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 128*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 128*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 128*/
 else /* Line: 128*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 128*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 131*/
 else /* Line: 124*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 132*/ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 132*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 132*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 132*/
 else /* Line: 132*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 132*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 135*/
 else /* Line: 124*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 136*/ {
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_ta_ph);
} /* Line: 138*/
 else /* Line: 124*/ {
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 139*/ {
} /* Line: 139*/
 else /* Line: 141*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_3_MathInt_bels_1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(beva_str);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_2));
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevl_ic);
bevt_24_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 142*/
} /* Line: 124*/
} /* Line: 124*/
} /* Line: 124*/
} /* Line: 124*/
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 145*/
 else /* Line: 120*/ {
break;
} /* Line: 120*/
} /* Line: 120*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_toHexString_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bem_toString_3(beva_res, bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, beva_zeroPad, beva_radix, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 189*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_ts.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 189*/ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(10));
if (bevl_val.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 192*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_ta_ph.bevi_int;
} /* Line: 193*/
 else /* Line: 194*/ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 195*/
bevt_6_ta_ph = beva_res.bem_capacityGet_0();
bevt_7_ta_ph = beva_res.bem_lengthGet_0();
if (bevt_6_ta_ph.bevi_int <= bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 198*/ {
bevt_9_ta_ph = beva_res.bem_capacityGet_0();
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_10_ta_ph);
beva_res.bem_capacitySet_1(bevt_8_ta_ph);
} /* Line: 199*/
bevt_11_ta_ph = beva_res.bem_lengthGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_ta_ph, bevl_val);
bevt_13_ta_ph = beva_res.bem_lengthGet_0();
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
beva_res.bem_lengthSet_1(bevt_12_ta_ph);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 206*/
 else /* Line: 189*/ {
break;
} /* Line: 189*/
} /* Line: 189*/
while (true)
/* Line: 209*/ {
bevt_16_ta_ph = beva_res.bem_lengthGet_0();
if (bevt_16_ta_ph.bevi_int < beva_zeroPad.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 209*/ {
bevt_18_ta_ph = beva_res.bem_capacityGet_0();
bevt_19_ta_ph = beva_res.bem_lengthGet_0();
if (bevt_18_ta_ph.bevi_int <= bevt_19_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 210*/ {
bevt_21_ta_ph = beva_res.bem_capacityGet_0();
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_22_ta_ph);
beva_res.bem_capacitySet_1(bevt_20_ta_ph);
} /* Line: 211*/
bevt_23_ta_ph = beva_res.bem_lengthGet_0();
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(48));
beva_res.bem_setIntUnchecked_2(bevt_23_ta_ph, bevt_24_ta_ph);
bevt_26_ta_ph = beva_res.bem_lengthGet_0();
bevt_27_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevt_27_ta_ph);
beva_res.bem_lengthSet_1(bevt_25_ta_ph);
} /* Line: 215*/
 else /* Line: 209*/ {
break;
} /* Line: 209*/
} /* Line: 209*/
bevt_29_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_29_ta_ph.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_30_ta_ph);
} /* Line: 220*/
bevt_31_ta_ph = beva_res.bem_reverseBytes_0();
return bevt_31_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_absValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_ta_ph);
} /* Line: 237*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 561*/ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 561*/ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 561*/
 else /* Line: 561*/ {
break;
} /* Line: 561*/
} /* Line: 561*/
return bevl_result;
} /*method end*/
public BEC_2_4_3_MathInt bem_squaredGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_multiply_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_squareRootGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

      double rd = Math.sqrt((double) bevi_int);
      bevl_res.bevi_int = (int) rd;
      return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_xi == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 586*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 586*/

      if (this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_xi == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 632*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 632*/

      if (this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {81, 81, 84, 88, 92, 92, 92, 92, 92, 96, 96, 96, 96, 96, 100, 100, 100, 0, 100, 100, 100, 0, 0, 101, 101, 101, 101, 103, 103, 103, 104, 106, 108, 108, 109, 109, 109, 109, 110, 110, 110, 110, 111, 115, 115, 116, 116, 117, 118, 119, 120, 120, 120, 122, 124, 124, 124, 124, 124, 0, 0, 0, 125, 125, 126, 127, 128, 128, 128, 128, 128, 0, 0, 0, 129, 129, 130, 131, 132, 132, 132, 132, 132, 0, 0, 0, 133, 133, 134, 135, 136, 136, 136, 138, 138, 139, 139, 139, 142, 142, 142, 142, 142, 142, 142, 144, 145, 150, 150, 154, 158, 158, 162, 166, 166, 166, 166, 166, 166, 170, 170, 170, 170, 174, 174, 174, 174, 178, 178, 178, 178, 182, 182, 182, 186, 187, 188, 189, 189, 189, 190, 191, 192, 192, 192, 193, 193, 195, 198, 198, 198, 198, 199, 199, 199, 199, 201, 201, 202, 202, 202, 202, 206, 209, 209, 209, 210, 210, 210, 210, 211, 211, 211, 211, 213, 213, 213, 214, 214, 214, 214, 219, 219, 219, 220, 220, 222, 222, 226, 227, 228, 232, 232, 232, 236, 236, 236, 237, 237, 253, 267, 281, 285, 296, 310, 314, 325, 339, 343, 354, 368, 372, 389, 409, 413, 424, 438, 442, 453, 467, 471, 482, 496, 500, 511, 525, 529, 540, 554, 559, 561, 561, 561, 562, 561, 564, 568, 568, 572, 579, 586, 586, 586, 586, 625, 625, 632, 632, 632, 632, 668, 668, 696, 696, 724, 724, 752, 752, 780, 780};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 29, 33, 41, 42, 43, 44, 45, 53, 54, 55, 56, 57, 81, 82, 87, 88, 91, 92, 97, 98, 101, 105, 106, 107, 108, 110, 111, 116, 117, 120, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 169, 170, 171, 172, 173, 174, 175, 178, 179, 184, 185, 186, 187, 192, 193, 198, 199, 202, 206, 209, 210, 211, 212, 215, 216, 221, 222, 227, 228, 231, 235, 238, 239, 240, 241, 244, 245, 250, 251, 256, 257, 260, 264, 267, 268, 269, 270, 273, 274, 279, 280, 281, 284, 285, 290, 293, 294, 295, 296, 297, 298, 299, 305, 306, 316, 317, 320, 325, 326, 329, 337, 338, 339, 340, 341, 342, 348, 349, 350, 351, 357, 358, 359, 360, 366, 367, 368, 369, 374, 375, 376, 413, 414, 415, 418, 419, 424, 425, 426, 427, 428, 433, 434, 435, 438, 440, 441, 442, 447, 448, 449, 450, 451, 453, 454, 455, 456, 457, 458, 459, 467, 468, 473, 474, 475, 476, 481, 482, 483, 484, 485, 487, 488, 489, 490, 491, 492, 493, 499, 500, 505, 506, 507, 509, 510, 514, 515, 516, 521, 522, 523, 529, 530, 535, 536, 537, 544, 549, 554, 558, 561, 566, 570, 573, 578, 582, 585, 590, 594, 597, 602, 606, 609, 614, 618, 621, 626, 630, 633, 638, 642, 645, 650, 654, 657, 662, 668, 669, 672, 677, 678, 679, 685, 689, 690, 694, 698, 704, 709, 710, 711, 717, 718, 724, 729, 730, 731, 737, 738, 746, 747, 755, 756, 764, 765, 773, 774};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 81 25
new 0 81 25
return 1 81 26
setStringValueDec 1 84 29
setStringValueHex 1 88 33
assign 1 92 41
new 0 92 41
assign 1 92 42
new 0 92 42
assign 1 92 43
new 0 92 43
assign 1 92 44
new 0 92 44
setStringValue 5 92 45
assign 1 96 53
new 0 96 53
assign 1 96 54
new 0 96 54
assign 1 96 55
new 0 96 55
assign 1 96 56
new 0 96 56
setStringValue 5 96 57
assign 1 100 81
new 0 100 81
assign 1 100 82
lesser 1 100 87
assign 1 0 88
assign 1 100 91
new 0 100 91
assign 1 100 92
greater 1 100 97
assign 1 0 98
assign 1 0 101
assign 1 101 105
new 0 101 105
assign 1 101 106
add 1 101 106
assign 1 101 107
new 1 101 107
throw 1 101 108
assign 1 103 110
new 0 103 110
assign 1 103 111
lesser 1 103 116
assign 1 104 117
copy 0 104 117
assign 1 106 120
new 0 106 120
assign 1 108 122
new 0 108 122
addValue 1 108 123
assign 1 109 124
new 0 109 124
assign 1 109 125
new 0 109 125
assign 1 109 126
subtract 1 109 126
assign 1 109 127
add 1 109 127
assign 1 110 128
new 0 110 128
assign 1 110 129
new 0 110 129
assign 1 110 130
subtract 1 110 130
assign 1 110 131
add 1 110 131
setStringValue 5 111 132
assign 1 115 169
new 0 115 169
setValue 1 115 170
assign 1 116 171
lengthGet 0 116 171
assign 1 116 172
copy 0 116 172
decrementValue 0 117 173
assign 1 118 174
new 0 118 174
assign 1 119 175
new 0 119 175
assign 1 120 178
new 0 120 178
assign 1 120 179
greaterEquals 1 120 184
getInt 2 122 185
assign 1 124 186
new 0 124 186
assign 1 124 187
greater 1 124 192
assign 1 124 193
lesser 1 124 198
assign 1 0 199
assign 1 0 202
assign 1 0 206
assign 1 125 209
new 0 125 209
subtractValue 1 125 210
multiplyValue 1 126 211
addValue 1 127 212
assign 1 128 215
new 0 128 215
assign 1 128 216
greater 1 128 221
assign 1 128 222
lesser 1 128 227
assign 1 0 228
assign 1 0 231
assign 1 0 235
assign 1 129 238
new 0 129 238
subtractValue 1 129 239
multiplyValue 1 130 240
addValue 1 131 241
assign 1 132 244
new 0 132 244
assign 1 132 245
greater 1 132 250
assign 1 132 251
lesser 1 132 256
assign 1 0 257
assign 1 0 260
assign 1 0 264
assign 1 133 267
new 0 133 267
subtractValue 1 133 268
multiplyValue 1 134 269
addValue 1 135 270
assign 1 136 273
new 0 136 273
assign 1 136 274
equals 1 136 279
assign 1 138 280
new 0 138 280
multiplyValue 1 138 281
assign 1 139 284
new 0 139 284
assign 1 139 285
equals 1 139 290
assign 1 142 293
new 0 142 293
assign 1 142 294
add 1 142 294
assign 1 142 295
new 0 142 295
assign 1 142 296
add 1 142 296
assign 1 142 297
add 1 142 297
assign 1 142 298
new 1 142 298
throw 1 142 299
decrementValue 0 144 305
multiplyValue 1 145 306
assign 1 150 316
toString 0 150 316
return 1 150 317
new 1 154 320
assign 1 158 325
new 0 158 325
return 1 158 326
return 1 162 329
assign 1 166 337
new 0 166 337
assign 1 166 338
new 1 166 338
assign 1 166 339
new 0 166 339
assign 1 166 340
new 0 166 340
assign 1 166 341
toString 4 166 341
return 1 166 342
assign 1 170 348
new 0 170 348
assign 1 170 349
new 1 170 349
assign 1 170 350
toHexString 1 170 350
return 1 170 351
assign 1 174 357
new 0 174 357
assign 1 174 358
new 0 174 358
assign 1 174 359
toString 3 174 359
return 1 174 360
assign 1 178 366
new 1 178 366
assign 1 178 367
new 0 178 367
assign 1 178 368
toString 4 178 368
return 1 178 369
assign 1 182 374
new 0 182 374
assign 1 182 375
toString 4 182 375
return 1 182 376
clear 0 186 413
assign 1 187 414
abs 0 187 414
assign 1 188 415
new 0 188 415
assign 1 189 418
new 0 189 418
assign 1 189 419
greater 1 189 424
setValue 1 190 425
modulusValue 1 191 426
assign 1 192 427
new 0 192 427
assign 1 192 428
lesser 1 192 433
assign 1 193 434
new 0 193 434
addValue 1 193 435
addValue 1 195 438
assign 1 198 440
capacityGet 0 198 440
assign 1 198 441
lengthGet 0 198 441
assign 1 198 442
lesserEquals 1 198 447
assign 1 199 448
capacityGet 0 199 448
assign 1 199 449
new 0 199 449
assign 1 199 450
add 1 199 450
capacitySet 1 199 451
assign 1 201 453
lengthGet 0 201 453
setIntUnchecked 2 201 454
assign 1 202 455
lengthGet 0 202 455
assign 1 202 456
new 0 202 456
assign 1 202 457
add 1 202 457
lengthSet 1 202 458
divideValue 1 206 459
assign 1 209 467
lengthGet 0 209 467
assign 1 209 468
lesser 1 209 473
assign 1 210 474
capacityGet 0 210 474
assign 1 210 475
lengthGet 0 210 475
assign 1 210 476
lesserEquals 1 210 481
assign 1 211 482
capacityGet 0 211 482
assign 1 211 483
new 0 211 483
assign 1 211 484
add 1 211 484
capacitySet 1 211 485
assign 1 213 487
lengthGet 0 213 487
assign 1 213 488
new 0 213 488
setIntUnchecked 2 213 489
assign 1 214 490
lengthGet 0 214 490
assign 1 214 491
new 0 214 491
assign 1 214 492
add 1 214 492
lengthSet 1 214 493
assign 1 219 499
new 0 219 499
assign 1 219 500
lesser 1 219 505
assign 1 220 506
new 0 220 506
addValue 1 220 507
assign 1 222 509
reverseBytes 0 222 509
return 1 222 510
assign 1 226 514
new 0 226 514
setValue 1 227 515
return 1 228 516
assign 1 232 521
copy 0 232 521
assign 1 232 522
absValue 0 232 522
return 1 232 523
assign 1 236 529
new 0 236 529
assign 1 236 530
lesser 1 236 535
assign 1 237 536
new 0 237 536
multiplyValue 1 237 537
return 1 253 544
return 1 267 549
return 1 281 554
assign 1 285 558
new 0 285 558
return 1 296 561
return 1 310 566
assign 1 314 570
new 0 314 570
return 1 325 573
return 1 339 578
assign 1 343 582
new 0 343 582
return 1 354 585
return 1 368 590
assign 1 372 594
new 0 372 594
return 1 389 597
return 1 409 602
assign 1 413 606
new 0 413 606
return 1 424 609
return 1 438 614
assign 1 442 618
new 0 442 618
return 1 453 621
return 1 467 626
assign 1 471 630
new 0 471 630
return 1 482 633
return 1 496 638
assign 1 500 642
new 0 500 642
return 1 511 645
return 1 525 650
assign 1 529 654
new 0 529 654
return 1 540 657
return 1 554 662
assign 1 559 668
new 0 559 668
assign 1 561 669
new 0 561 669
assign 1 561 672
lesser 1 561 677
multiplyValue 1 562 678
incrementValue 0 561 679
return 1 564 685
assign 1 568 689
multiply 1 568 689
return 1 568 690
assign 1 572 694
new 0 572 694
return 1 579 698
assign 1 586 704
undef 1 586 709
assign 1 586 710
new 0 586 710
return 1 586 711
assign 1 625 717
new 0 625 717
return 1 625 718
assign 1 632 724
undef 1 632 729
assign 1 632 730
new 0 632 730
return 1 632 731
assign 1 668 737
new 0 668 737
return 1 668 738
assign 1 696 746
new 0 696 746
return 1 696 747
assign 1 724 755
new 0 724 755
return 1 724 756
assign 1 752 764
new 0 752 764
return 1 752 765
assign 1 780 773
new 0 780 773
return 1 780 774
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 189070720: return bem_new_0();
case 1669226776: return bem_squaredGet_0();
case 441331165: return bem_print_0();
case 446711025: return bem_serializeToString_0();
case 1870128138: return bem_toString_0();
case -1184569870: return bem_serializeContentsGet_0();
case -559059286: return bem_create_0();
case -791369436: return bem_abs_0();
case 1460770980: return bem_incrementValue_0();
case -710549913: return bem_squareRootGet_0();
case 1684508629: return bem_copy_0();
case 1603420250: return bem_absValue_0();
case 1991657606: return bem_hashGet_0();
case 1220616710: return bem_toHexString_0();
case -1399615900: return bem_iteratorGet_0();
case -382130277: return bem_decrementValue_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 955127779: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1204606264: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case 2007782276: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case -514952459: return bem_notEquals_1(bevd_0);
case -1690031446: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case -704280640: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -1146215684: return bem_def_1(bevd_0);
case 546625047: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -51803260: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case 2095428199: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 637301921: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 1849784828: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case -342422765: return bem_undef_1(bevd_0);
case 1437114439: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -741638175: return bem_new_1(bevd_0);
case -461789566: return bem_copyTo_1(bevd_0);
case -1689568319: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case -907308916: return bem_print_1(bevd_0);
case -1375104016: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1423423209: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1513796971: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 305443687: return bem_equals_1(bevd_0);
case -13719074: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -959838722: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 338928857: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 139317253: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case 479710196: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -304101359: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -1841534094: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -1871450426: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case -1783890492: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1756536811: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1192644662: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -354635220: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case 105558806: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case -381133611: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1532908424: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -734031807: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 99764285: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1918971160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 272048443: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 566078336: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 407199842: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -274864897: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1287199626: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
