package be;
/* IO:File: source/base/EcProcess.be */
public final class BEC_2_6_7_SystemProcess extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemProcess() { }
private static byte[] becc_BEC_2_6_7_SystemProcess_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] becc_BEC_2_6_7_SystemProcess_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x63,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x62,0x65};
public static BEC_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_inst;

public static BET_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_4_3_MathInt bevp_numArgs;
public BEC_2_6_6_SystemObject bevp_execName;
public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_6_6_SystemObject bevp_result;
public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_15_SystemCurrentPlatform bevp_platform;
public BEC_2_6_6_SystemObject bevp_fullExecName;
public BEC_2_6_7_SystemProcess bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_default_0() throws Throwable {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bem_prepArgs_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_execNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_1_tmpany_phold = bem_fullExecNameGet_0();
return bevt_1_tmpany_phold;
} /* Line: 39 */
if (bevp_execName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 40 */ {
} /* Line: 41 */
return bevp_execName;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_execPathGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_execNameGet_0();
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fullExecNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_fullExecName == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {
} /* Line: 60 */
return bevp_fullExecName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_prepArgs_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 72 */ {
if (bevp_args == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevp_args = (new BEC_2_9_4_ContainerList()).bem_new_0();

            for (int i = 0;i < be.BECS_Runtime.args.length;i++) {
                bevp_args.bem_addValue_1(new BEC_2_4_6_TextString(be.BECS_Runtime.args[i].getBytes("UTF-8")));
            }
          bevp_numArgs = bevp_args.bem_sizeGet_0();
} /* Line: 98 */
} /* Line: 73 */
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bem_exit_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_1(BEC_2_4_3_MathInt beva_code) throws Throwable {

     System.exit(beva_code.bevi_int);
     return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_start_1(BEC_2_6_6_SystemObject beva__target) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevp_target = beva__target;
try  /* Line: 123 */ {
bevp_result = bevp_target.bemd_0(-1356631885);
} /* Line: 124 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_except = bevl_e;
bevl_e.bemd_0(1616854488);
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 128 */
return bevp_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startByName_1(BEC_2_6_6_SystemObject beva__name) throws Throwable {
BEC_2_6_6_SystemObject bevl_t = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) beva__name );
bevl_t = bevt_0_tmpany_phold.bemd_0(774012273);
bevt_1_tmpany_phold = bem_start_1(bevl_t);
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numArgsGet_0() throws Throwable {
return bevp_numArgs;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_numArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numArgs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_execNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_execName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_resultGet_0() throws Throwable {
return bevp_result;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_resultSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_result = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() throws Throwable {
return bevp_except;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_fullExecNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fullExecName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {32, 35, 39, 39, 39, 40, 40, 48, 52, 52, 52, 59, 59, 67, 73, 73, 74, 98, 105, 105, 122, 124, 126, 127, 128, 128, 130, 134, 134, 135, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 31, 33, 34, 36, 41, 43, 48, 49, 50, 54, 59, 61, 66, 71, 72, 77, 84, 85, 96, 98, 102, 103, 104, 105, 107, 113, 114, 115, 116, 119, 122, 126, 129, 133, 137, 140, 144, 147, 151, 154, 158, 161, 165};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 32 23
new 0 32 23
prepArgs 0 35 24
assign 1 39 31
new 0 39 31
assign 1 39 33
fullExecNameGet 0 39 33
return 1 39 34
assign 1 40 36
undef 1 40 41
return 1 48 43
assign 1 52 48
execNameGet 0 52 48
assign 1 52 49
apNew 1 52 49
return 1 52 50
assign 1 59 54
undef 1 59 59
return 1 67 61
assign 1 73 66
undef 1 73 71
assign 1 74 72
new 0 74 72
assign 1 98 77
sizeGet 0 98 77
assign 1 105 84
new 0 105 84
exit 1 105 85
assign 1 122 96
assign 1 124 98
main 0 124 98
assign 1 126 102
print 0 127 103
assign 1 128 104
new 0 128 104
return 1 128 105
return 1 130 107
assign 1 134 113
createInstance 1 134 113
assign 1 134 114
new 0 134 114
assign 1 135 115
start 1 135 115
return 1 135 116
return 1 0 119
assign 1 0 122
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
assign 1 0 140
return 1 0 144
assign 1 0 147
return 1 0 151
assign 1 0 154
return 1 0 158
assign 1 0 161
assign 1 0 165
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 847900593: return bem_serializeContents_0();
case -1099311989: return bem_once_0();
case 1495405880: return bem_execNameGet_0();
case 504888857: return bem_fullExecNameGet_0();
case -1220916727: return bem_many_0();
case 1309260532: return bem_execPathGet_0();
case 2080907218: return bem_echo_0();
case 1853846231: return bem_resultGet_0();
case -1172871068: return bem_targetGet_0();
case 1059907561: return bem_classNameGet_0();
case 774012273: return bem_new_0();
case -1228227275: return bem_deserializeClassNameGet_0();
case 1975956372: return bem_hashGet_0();
case -1718552946: return bem_exceptGet_0();
case -724497650: return bem_exit_0();
case 728240113: return bem_argsGet_0();
case -1131153280: return bem_copy_0();
case 827292547: return bem_create_0();
case 684765292: return bem_platformGet_0();
case 677808118: return bem_toString_0();
case -1971423632: return bem_numArgsGet_0();
case -362294474: return bem_sourceFileNameGet_0();
case 1616854488: return bem_print_0();
case -497405976: return bem_tagGet_0();
case 887158094: return bem_fieldIteratorGet_0();
case -1571656834: return bem_toAny_0();
case -1438776041: return bem_prepArgs_0();
case 585989692: return bem_serializeToString_0();
case 988563641: return bem_iteratorGet_0();
case -1707345921: return bem_serializationIteratorGet_0();
case -236699214: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1704127291: return bem_argsSet_1(bevd_0);
case 1730126997: return bem_def_1(bevd_0);
case -248970787: return bem_sameObject_1(bevd_0);
case -1013351049: return bem_otherClass_1(bevd_0);
case -1542443673: return bem_copyTo_1(bevd_0);
case 1998346117: return bem_undefined_1(bevd_0);
case 1434568333: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1133393159: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1248878306: return bem_notEquals_1(bevd_0);
case -1599156894: return bem_sameClass_1(bevd_0);
case -1990764469: return bem_execNameSet_1(bevd_0);
case 1414816999: return bem_platformSet_1(bevd_0);
case 1910844205: return bem_defined_1(bevd_0);
case 1870797623: return bem_numArgsSet_1(bevd_0);
case 1453342260: return bem_start_1(bevd_0);
case -1883746791: return bem_otherType_1(bevd_0);
case -1649058984: return bem_sameType_1(bevd_0);
case 197557310: return bem_undef_1(bevd_0);
case -1727272588: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1653906941: return bem_exit_1((BEC_2_4_3_MathInt) bevd_0);
case 719748952: return bem_startByName_1(bevd_0);
case -1058368187: return bem_exceptSet_1(bevd_0);
case -129188295: return bem_fullExecNameSet_1(bevd_0);
case 410232788: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -923722135: return bem_resultSet_1(bevd_0);
case -970121374: return bem_equals_1(bevd_0);
case 1133299169: return bem_targetSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 755484682: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -831651783: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1440576715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1239513525: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383341402: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1754203643: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126803346: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemProcess_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_7_SystemProcess_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemProcess();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst = (BEC_2_6_7_SystemProcess) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_type;
}
}
