package be;
/* IO:File: source/base/EcProcess.be */
public final class BEC_2_6_7_SystemProcess extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemProcess() { }
private static byte[] becc_BEC_2_6_7_SystemProcess_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] becc_BEC_2_6_7_SystemProcess_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x63,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x62,0x65};
public static BEC_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_inst;

public static BET_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_4_3_MathInt bevp_numArgs;
public BEC_2_6_6_SystemObject bevp_execName;
public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_6_6_SystemObject bevp_result;
public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_15_SystemCurrentPlatform bevp_platform;
public BEC_2_6_6_SystemObject bevp_fullExecName;
public BEC_2_6_7_SystemProcess bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_default_0() throws Throwable {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bem_prepArgs_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_execNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_1_tmpany_phold = bem_fullExecNameGet_0();
return bevt_1_tmpany_phold;
} /* Line: 38 */
if (bevp_execName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 39 */ {
} /* Line: 40 */
return bevp_execName;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_execPathGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_execNameGet_0();
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fullExecNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_fullExecName == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
} /* Line: 59 */
return bevp_fullExecName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_prepArgs_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 71 */ {
if (bevp_args == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevp_args = (new BEC_2_9_4_ContainerList()).bem_new_0();

            for (int i = 0;i < be.BECS_Runtime.args.length;i++) {
                bevp_args.bem_addValue_1(new BEC_2_4_6_TextString(be.BECS_Runtime.args[i].getBytes("UTF-8")));
            }
          bevp_numArgs = bevp_args.bem_sizeGet_0();
} /* Line: 106 */
} /* Line: 72 */
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bem_exit_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_1(BEC_2_4_3_MathInt beva_code) throws Throwable {

     System.exit(beva_code.bevi_int);
     return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_start_1(BEC_2_6_6_SystemObject beva__target) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevp_target = beva__target;
try  /* Line: 136 */ {
bevp_result = bevp_target.bemd_0(459076290);
} /* Line: 137 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_except = bevl_e;
bevl_e.bemd_0(1562045422);
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 141 */
return bevp_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startByName_1(BEC_2_6_6_SystemObject beva__name) throws Throwable {
BEC_2_6_6_SystemObject bevl_t = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) beva__name );
bevl_t = bevt_0_tmpany_phold.bemd_0(841207683);
bevt_1_tmpany_phold = bem_start_1(bevl_t);
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemProcess bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numArgsGet_0() throws Throwable {
return bevp_numArgs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_numArgsGetDirect_0() throws Throwable {
return bevp_numArgs;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_numArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numArgs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemProcess bem_numArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numArgs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_execNameGetDirect_0() throws Throwable {
return bevp_execName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_execNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_execName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemProcess bem_execNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_execName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_targetGetDirect_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemProcess bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_resultGet_0() throws Throwable {
return bevp_result;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_resultGetDirect_0() throws Throwable {
return bevp_result;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_resultSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_result = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemProcess bem_resultSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_result = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() throws Throwable {
return bevp_except;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_exceptGetDirect_0() throws Throwable {
return bevp_except;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemProcess bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public final BEC_2_6_15_SystemCurrentPlatform bem_platformGetDirect_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemProcess bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fullExecNameGetDirect_0() throws Throwable {
return bevp_fullExecName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_fullExecNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fullExecName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemProcess bem_fullExecNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fullExecName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {31, 34, 38, 38, 38, 39, 39, 47, 51, 51, 51, 58, 58, 66, 72, 72, 73, 106, 113, 113, 135, 137, 139, 140, 141, 141, 143, 147, 147, 148, 148, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 31, 33, 34, 36, 41, 43, 48, 49, 50, 54, 59, 61, 66, 71, 72, 77, 84, 85, 96, 98, 102, 103, 104, 105, 107, 113, 114, 115, 116, 119, 122, 125, 129, 133, 136, 139, 143, 147, 150, 154, 158, 161, 164, 168, 172, 175, 178, 182, 186, 189, 192, 196, 200, 203, 206, 210, 214, 217, 221};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 31 23
new 0 31 23
prepArgs 0 34 24
assign 1 38 31
new 0 38 31
assign 1 38 33
fullExecNameGet 0 38 33
return 1 38 34
assign 1 39 36
undef 1 39 41
return 1 47 43
assign 1 51 48
execNameGet 0 51 48
assign 1 51 49
apNew 1 51 49
return 1 51 50
assign 1 58 54
undef 1 58 59
return 1 66 61
assign 1 72 66
undef 1 72 71
assign 1 73 72
new 0 73 72
assign 1 106 77
sizeGet 0 106 77
assign 1 113 84
new 0 113 84
exit 1 113 85
assign 1 135 96
assign 1 137 98
main 0 137 98
assign 1 139 102
print 0 140 103
assign 1 141 104
new 0 141 104
return 1 141 105
return 1 143 107
assign 1 147 113
createInstance 1 147 113
assign 1 147 114
new 0 147 114
assign 1 148 115
start 1 148 115
return 1 148 116
return 1 0 119
return 1 0 122
assign 1 0 125
assign 1 0 129
return 1 0 133
return 1 0 136
assign 1 0 139
assign 1 0 143
return 1 0 147
assign 1 0 150
assign 1 0 154
return 1 0 158
return 1 0 161
assign 1 0 164
assign 1 0 168
return 1 0 172
return 1 0 175
assign 1 0 178
assign 1 0 182
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
return 1 0 214
assign 1 0 217
assign 1 0 221
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1866691844: return bem_numArgsGet_0();
case 232809271: return bem_copy_0();
case -1247813666: return bem_tagGet_0();
case -225078823: return bem_serializationIteratorGet_0();
case 757807697: return bem_platformGetDirect_0();
case -858518329: return bem_many_0();
case 285074277: return bem_deserializeClassNameGet_0();
case 863596927: return bem_sourceFileNameGet_0();
case 944745844: return bem_iteratorGet_0();
case -1366631071: return bem_fullExecNameGet_0();
case -1059015850: return bem_resultGet_0();
case 33648639: return bem_argsGetDirect_0();
case -592325377: return bem_resultGetDirect_0();
case -967525204: return bem_fieldNamesGet_0();
case 1505225416: return bem_prepArgs_0();
case 2121511121: return bem_fullExecNameGetDirect_0();
case -606597902: return bem_exceptGet_0();
case -1155411626: return bem_classNameGet_0();
case 353598831: return bem_execNameGet_0();
case -1581691779: return bem_default_0();
case 1562045422: return bem_print_0();
case -513985458: return bem_once_0();
case 1482468754: return bem_platformGet_0();
case -1154985755: return bem_echo_0();
case 1728178194: return bem_execPathGet_0();
case 841207683: return bem_new_0();
case 1659991605: return bem_targetGet_0();
case -1122461447: return bem_exceptGetDirect_0();
case 745980876: return bem_serializeToString_0();
case -1648741755: return bem_exit_0();
case 1592801927: return bem_serializeContents_0();
case 1835904283: return bem_fieldIteratorGet_0();
case -1326512766: return bem_argsGet_0();
case -703952395: return bem_toAny_0();
case 470410877: return bem_execNameGetDirect_0();
case -623430890: return bem_numArgsGetDirect_0();
case -373071073: return bem_targetGetDirect_0();
case -1845402369: return bem_create_0();
case -1890761825: return bem_hashGet_0();
case -1995804558: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759208190: return bem_targetSetDirect_1(bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -35012436: return bem_exceptSet_1(bevd_0);
case 733295640: return bem_execNameSetDirect_1(bevd_0);
case -581021659: return bem_start_1(bevd_0);
case 219943616: return bem_startByName_1(bevd_0);
case -1130012021: return bem_fullExecNameSet_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case 311404742: return bem_resultSet_1(bevd_0);
case -2042757860: return bem_targetSet_1(bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1532874964: return bem_exceptSetDirect_1(bevd_0);
case 1200297939: return bem_undef_1(bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1512758476: return bem_fullExecNameSetDirect_1(bevd_0);
case 1691418359: return bem_argsSet_1(bevd_0);
case -2076291764: return bem_execNameSet_1(bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
case -1922943807: return bem_argsSetDirect_1(bevd_0);
case -1652958053: return bem_numArgsSet_1(bevd_0);
case 1873211042: return bem_resultSetDirect_1(bevd_0);
case -1464484798: return bem_exit_1((BEC_2_4_3_MathInt) bevd_0);
case 12031225: return bem_def_1(bevd_0);
case -1815546435: return bem_copyTo_1(bevd_0);
case -1365438906: return bem_platformSet_1(bevd_0);
case 418027722: return bem_platformSetDirect_1(bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
case -1619355296: return bem_numArgsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemProcess_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_7_SystemProcess_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemProcess();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst = (BEC_2_6_7_SystemProcess) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_type;
}
}
