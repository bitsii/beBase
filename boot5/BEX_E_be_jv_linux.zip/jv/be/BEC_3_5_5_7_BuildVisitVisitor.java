package be;
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor extends BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;

public static BET_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;

public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_transGet_0() throws Throwable {
return bevp_trans;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constGet_0() throws Throwable {
return bevp_const;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 15, 16, 17, 22, 22, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 24, 25, 31, 34, 38, 41, 45, 48, 52, 55};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 16
assign 1 15 17
buildGet 0 15 17
assign 1 16 18
constantsGet 0 16 18
assign 1 17 19
ntypesGet 0 17 19
assign 1 22 24
nextDescendGet 0 22 24
return 1 22 25
return 1 0 31
assign 1 0 34
return 1 0 38
assign 1 0 41
return 1 0 45
assign 1 0 48
return 1 0 52
assign 1 0 55
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1450568577: return bem_hashGet_0();
case 1448984271: return bem_create_0();
case -87056108: return bem_new_0();
case 912871340: return bem_toString_0();
case -1166859559: return bem_iteratorGet_0();
case 633682209: return bem_print_0();
case 476934751: return bem_copy_0();
case 1327041155: return bem_ntypesGet_0();
case 288379006: return bem_constGet_0();
case -147802984: return bem_transGet_0();
case 1097393106: return bem_buildGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -949117601: return bem_constSet_1(bevd_0);
case -431570572: return bem_begin_1(bevd_0);
case 2106618550: return bem_def_1(bevd_0);
case -1076047891: return bem_notEquals_1(bevd_0);
case -1298417481: return bem_end_1(bevd_0);
case -1101353329: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1089041118: return bem_undef_1(bevd_0);
case 381130981: return bem_copyTo_1(bevd_0);
case -1002099233: return bem_buildSet_1(bevd_0);
case -1486086431: return bem_equals_1(bevd_0);
case 1268662776: return bem_transSet_1(bevd_0);
case -1659745314: return bem_ntypesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1900258780: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 551846529: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -658194391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -64978042: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;
}
}
