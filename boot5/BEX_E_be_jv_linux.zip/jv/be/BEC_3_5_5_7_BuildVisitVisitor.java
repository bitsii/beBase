package be;
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor extends BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_transGet_0() throws Throwable {
return bevp_trans;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constGet_0() throws Throwable {
return bevp_const;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15, 16, 17, 18, 23, 23, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 15, 16, 21, 22, 28, 31, 35, 38, 42, 45, 49, 52};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 15 13
assign 1 16 14
buildGet 0 16 14
assign 1 17 15
constantsGet 0 17 15
assign 1 18 16
ntypesGet 0 18 16
assign 1 23 21
nextDescendGet 0 23 21
return 1 23 22
return 1 0 28
assign 1 0 31
return 1 0 35
assign 1 0 38
return 1 0 42
assign 1 0 45
return 1 0 49
assign 1 0 52
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1693411633: return bem_fieldIteratorGet_0();
case 1740583826: return bem_serializeToString_0();
case 1330053746: return bem_classNameGet_0();
case -1666892068: return bem_once_0();
case 19655765: return bem_tagGet_0();
case -266150550: return bem_many_0();
case -1256903143: return bem_print_0();
case 721298840: return bem_serializationIteratorGet_0();
case 937159837: return bem_ntypesGet_0();
case 895906767: return bem_toString_0();
case -1755437106: return bem_serializeContents_0();
case 2021065028: return bem_constGet_0();
case -907223016: return bem_iteratorGet_0();
case -67323485: return bem_create_0();
case -748130189: return bem_echo_0();
case 978873391: return bem_deserializeClassNameGet_0();
case 648643859: return bem_sourceFileNameGet_0();
case 559194567: return bem_transGet_0();
case -2089883321: return bem_new_0();
case 394710523: return bem_toAny_0();
case 1781926555: return bem_copy_0();
case 1782125853: return bem_hashGet_0();
case 1642913038: return bem_buildGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2097315666: return bem_sameClass_1(bevd_0);
case -217318371: return bem_buildSet_1(bevd_0);
case 2119054446: return bem_otherType_1(bevd_0);
case -694710091: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1471395824: return bem_transSet_1(bevd_0);
case 803845413: return bem_def_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case 708433060: return bem_ntypesSet_1(bevd_0);
case 1010245414: return bem_begin_1(bevd_0);
case 2077937958: return bem_end_1(bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
case -614737267: return bem_constSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
}
