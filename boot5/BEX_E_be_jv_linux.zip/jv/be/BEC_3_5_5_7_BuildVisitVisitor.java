package be;
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor extends BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;

public static BET_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;

public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_transGet_0() throws Throwable {
return bevp_trans;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_transGetDirect_0() throws Throwable {
return bevp_trans;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_7_BuildVisitVisitor bem_transSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildGetDirect_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_7_BuildVisitVisitor bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constGet_0() throws Throwable {
return bevp_const;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constGetDirect_0() throws Throwable {
return bevp_const;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_7_BuildVisitVisitor bem_constSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 15, 16, 17, 22, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 24, 25, 31, 34, 37, 41, 45, 48, 51, 55, 59, 62, 65, 69, 73, 76, 79, 83};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 16
assign 1 15 17
buildGet 0 15 17
assign 1 16 18
constantsGet 0 16 18
assign 1 17 19
ntypesGet 0 17 19
assign 1 22 24
nextDescendGet 0 22 24
return 1 22 25
return 1 0 31
return 1 0 34
assign 1 0 37
assign 1 0 41
return 1 0 45
return 1 0 48
assign 1 0 51
assign 1 0 55
return 1 0 59
return 1 0 62
assign 1 0 65
assign 1 0 69
return 1 0 73
return 1 0 76
assign 1 0 79
assign 1 0 83
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1724453868: return bem_serializeToString_0();
case 1777587047: return bem_hashGet_0();
case 1797865600: return bem_new_0();
case 791802958: return bem_ntypesGetDirect_0();
case -180175097: return bem_classNameGet_0();
case 967234853: return bem_fieldIteratorGet_0();
case 766881626: return bem_print_0();
case 1095297479: return bem_echo_0();
case 992286008: return bem_transGetDirect_0();
case -404516557: return bem_constGetDirect_0();
case 2011135674: return bem_iteratorGet_0();
case 617445256: return bem_sourceFileNameGet_0();
case -1455899172: return bem_create_0();
case -862722877: return bem_transGet_0();
case -1004023772: return bem_ntypesGet_0();
case 888353027: return bem_buildGetDirect_0();
case 1955915393: return bem_fieldNamesGet_0();
case -194416815: return bem_tagGet_0();
case 1818057755: return bem_constGet_0();
case -119499799: return bem_serializationIteratorGet_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case -665649433: return bem_serializeContents_0();
case -1715766851: return bem_toAny_0();
case 378307569: return bem_copy_0();
case 509361355: return bem_once_0();
case -533443118: return bem_many_0();
case 1374272360: return bem_buildGet_0();
case 280712282: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -445857610: return bem_notEquals_1(bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case 1525819013: return bem_transSet_1(bevd_0);
case 457461480: return bem_transSetDirect_1(bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case 1863238097: return bem_constSetDirect_1(bevd_0);
case -427578580: return bem_ntypesSetDirect_1(bevd_0);
case -1391031501: return bem_begin_1(bevd_0);
case 1927957525: return bem_buildSetDirect_1(bevd_0);
case 906320876: return bem_defined_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
case 594913348: return bem_constSet_1(bevd_0);
case 1838349708: return bem_end_1(bevd_0);
case 756151160: return bem_ntypesSet_1(bevd_0);
case 20780357: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -12217689: return bem_buildSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;
}
}
