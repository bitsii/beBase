package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x0A};
public static BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_4_ContainerList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_vv = be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_19_SystemExceptionTranslator bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_19_SystemExceptionTranslator) BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;
bevt_0_ta_ph.bem_translateEmittedException_1(this);
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_0));
if (bevp_description == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 56*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_1));
bevt_2_ta_ph = bevl_toRet.bemd_1(2064121669, bevt_3_ta_ph);
bevl_toRet = bevt_2_ta_ph.bemd_1(2064121669, bevp_description);
} /* Line: 57*/
if (bevp_fileName == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_2));
bevt_5_ta_ph = bevl_toRet.bemd_1(2064121669, bevt_6_ta_ph);
bevl_toRet = bevt_5_ta_ph.bemd_1(2064121669, bevp_fileName);
} /* Line: 60*/
if (bevp_lineNumber == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 62*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_3));
bevt_8_ta_ph = bevl_toRet.bemd_1(2064121669, bevt_9_ta_ph);
bevt_10_ta_ph = bevp_lineNumber.bemd_0(-1164957310);
bevl_toRet = bevt_8_ta_ph.bemd_1(2064121669, bevt_10_ta_ph);
} /* Line: 63*/
if (bevp_lang == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 65*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_12_ta_ph = bevl_toRet.bemd_1(2064121669, bevt_13_ta_ph);
bevl_toRet = bevt_12_ta_ph.bemd_1(2064121669, bevp_lang);
} /* Line: 66*/
if (bevp_emitLang == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 68*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_5));
bevt_15_ta_ph = bevl_toRet.bemd_1(2064121669, bevt_16_ta_ph);
bevl_toRet = bevt_15_ta_ph.bemd_1(2064121669, bevp_emitLang);
} /* Line: 69*/
if (bevp_methodName == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_6));
bevt_18_ta_ph = bevl_toRet.bemd_1(2064121669, bevt_19_ta_ph);
bevl_toRet = bevt_18_ta_ph.bemd_1(2064121669, bevp_methodName);
} /* Line: 72*/
if (bevp_klassName == null) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 74*/ {
bevt_22_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_7));
bevt_21_ta_ph = bevl_toRet.bemd_1(2064121669, bevt_22_ta_ph);
bevl_toRet = bevt_21_ta_ph.bemd_1(2064121669, bevp_klassName);
} /* Line: 75*/
if (bevp_framesText == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 77*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_8));
bevt_24_ta_ph = bevl_toRet.bemd_1(2064121669, bevt_25_ta_ph);
bevl_toRet = bevt_24_ta_ph.bemd_1(2064121669, bevp_framesText);
} /* Line: 78*/
if (bevp_frames == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_27_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(2064121669, bevt_27_ta_ph);
} /* Line: 81*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_9_4_ContainerList bem_framesGet_0() throws Throwable {
BEC_2_6_19_SystemExceptionTranslator bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_19_SystemExceptionTranslator) BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;
bevt_0_ta_ph.bem_translateEmittedException_1(this);
if (bevp_vv.bevi_bool)/* Line: 90*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_9_SystemException_bels_9));
bevt_1_ta_ph.bem_print_0();
} /* Line: 91*/
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_4_ContainerList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_19_SystemExceptionTranslator bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_19_SystemExceptionTranslator) BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;
bevt_1_ta_ph.bem_translateEmittedException_1(this);
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_10));
bevl_toRet = bevl_toRet.bem_add_1(bevt_3_ta_ph);
bevt_0_ta_loop = bevl_myFrames.bem_iteratorGet_0();
while (true)
/* Line: 103*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(-1774805934);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 103*/ {
bevl_ft = bevt_0_ta_loop.bemd_0(1956741611);
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 104*/
 else /* Line: 103*/ {
break;
} /* Line: 103*/
} /* Line: 103*/
} /* Line: 103*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_frames == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 115*/ {
bevp_frames = (new BEC_2_9_4_ContainerList()).bem_new_0();
} /* Line: 116*/
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_klassName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_description = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lineNumber = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_frames = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGet_0() throws Throwable {
return bevp_vv;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {47, 50, 54, 54, 55, 56, 56, 57, 57, 57, 59, 59, 60, 60, 60, 62, 62, 63, 63, 63, 63, 65, 65, 66, 66, 66, 68, 68, 69, 69, 69, 71, 71, 72, 72, 72, 74, 74, 75, 75, 75, 77, 77, 78, 78, 78, 80, 80, 81, 81, 83, 89, 89, 91, 91, 94, 98, 98, 99, 100, 101, 101, 102, 102, 103, 0, 103, 103, 104, 107, 111, 115, 115, 116, 118, 122, 122, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {34, 35, 68, 69, 70, 71, 76, 77, 78, 79, 81, 86, 87, 88, 89, 91, 96, 97, 98, 99, 100, 102, 107, 108, 109, 110, 112, 117, 118, 119, 120, 122, 127, 128, 129, 130, 132, 137, 138, 139, 140, 142, 147, 148, 149, 150, 152, 157, 158, 159, 161, 166, 167, 169, 170, 172, 183, 184, 185, 186, 187, 192, 193, 194, 195, 195, 198, 200, 201, 208, 211, 215, 220, 221, 223, 228, 229, 233, 236, 240, 244, 247, 251, 254, 258, 261, 265, 268, 272, 275, 279, 283, 286, 290, 293, 297, 300};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 47 34
new 0 47 34
assign 1 50 35
assign 1 54 68
new 0 54 68
translateEmittedException 1 54 69
assign 1 55 70
new 0 55 70
assign 1 56 71
def 1 56 76
assign 1 57 77
new 0 57 77
assign 1 57 78
add 1 57 78
assign 1 57 79
add 1 57 79
assign 1 59 81
def 1 59 86
assign 1 60 87
new 0 60 87
assign 1 60 88
add 1 60 88
assign 1 60 89
add 1 60 89
assign 1 62 91
def 1 62 96
assign 1 63 97
new 0 63 97
assign 1 63 98
add 1 63 98
assign 1 63 99
toString 0 63 99
assign 1 63 100
add 1 63 100
assign 1 65 102
def 1 65 107
assign 1 66 108
new 0 66 108
assign 1 66 109
add 1 66 109
assign 1 66 110
add 1 66 110
assign 1 68 112
def 1 68 117
assign 1 69 118
new 0 69 118
assign 1 69 119
add 1 69 119
assign 1 69 120
add 1 69 120
assign 1 71 122
def 1 71 127
assign 1 72 128
new 0 72 128
assign 1 72 129
add 1 72 129
assign 1 72 130
add 1 72 130
assign 1 74 132
def 1 74 137
assign 1 75 138
new 0 75 138
assign 1 75 139
add 1 75 139
assign 1 75 140
add 1 75 140
assign 1 77 142
def 1 77 147
assign 1 78 148
new 0 78 148
assign 1 78 149
add 1 78 149
assign 1 78 150
add 1 78 150
assign 1 80 152
def 1 80 157
assign 1 81 158
getFrameText 0 81 158
assign 1 81 159
add 1 81 159
return 1 83 161
assign 1 89 166
new 0 89 166
translateEmittedException 1 89 167
assign 1 91 169
new 0 91 169
print 0 91 170
return 1 94 172
assign 1 98 183
new 0 98 183
translateEmittedException 1 98 184
assign 1 99 185
new 0 99 185
assign 1 100 186
framesGet 0 100 186
assign 1 101 187
def 1 101 192
assign 1 102 193
new 0 102 193
assign 1 102 194
add 1 102 194
assign 1 103 195
iteratorGet 0 0 195
assign 1 103 198
hasNextGet 0 103 198
assign 1 103 200
nextGet 0 103 200
assign 1 104 201
add 1 104 201
return 1 107 208
return 1 111 211
assign 1 115 215
undef 1 115 220
assign 1 116 221
new 0 116 221
addValue 1 118 223
assign 1 122 228
new 4 122 228
addFrame 1 122 229
return 1 0 233
assign 1 0 236
assign 1 0 240
return 1 0 244
assign 1 0 247
return 1 0 251
assign 1 0 254
return 1 0 258
assign 1 0 261
return 1 0 265
assign 1 0 268
return 1 0 272
assign 1 0 275
assign 1 0 279
return 1 0 283
assign 1 0 286
return 1 0 290
assign 1 0 293
return 1 0 297
assign 1 0 300
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1459352689: return bem_create_0();
case 732450878: return bem_framesTextGet_0();
case -576794307: return bem_lineNumberGet_0();
case 1778185843: return bem_new_0();
case 1263379711: return bem_print_0();
case 90937029: return bem_vvGet_0();
case -579576714: return bem_framesGet_0();
case 1078828387: return bem_klassNameGet_0();
case 1281153852: return bem_translatedGet_0();
case 347991132: return bem_getFrameText_0();
case 468830578: return bem_fileNameGet_0();
case -1164957310: return bem_toString_0();
case -1237839130: return bem_iteratorGet_0();
case -117112429: return bem_methodNameGet_0();
case 1201640484: return bem_emitLangGet_0();
case 251183973: return bem_descriptionGet_0();
case 1358781509: return bem_langGet_0();
case -1676319714: return bem_hashGet_0();
case 220006479: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 66888839: return bem_def_1(bevd_0);
case -580429773: return bem_lineNumberSet_1(bevd_0);
case -1283944608: return bem_framesSet_1(bevd_0);
case -1944046315: return bem_undef_1(bevd_0);
case -41534900: return bem_copyTo_1(bevd_0);
case -1129499895: return bem_methodNameSet_1(bevd_0);
case 1386150187: return bem_langSet_1(bevd_0);
case 1202748890: return bem_notEquals_1(bevd_0);
case -1199811401: return bem_fileNameSet_1(bevd_0);
case -1383081887: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -769036849: return bem_descriptionSet_1(bevd_0);
case 154021484: return bem_translatedSet_1(bevd_0);
case -1017560371: return bem_equals_1(bevd_0);
case 1263103742: return bem_new_1(bevd_0);
case -246800392: return bem_vvSet_1(bevd_0);
case -2097416832: return bem_emitLangSet_1(bevd_0);
case -1287007364: return bem_klassNameSet_1(bevd_0);
case -1921691724: return bem_framesTextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1494765242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -481857229: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -828074266: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 903252754: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2084695400: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
