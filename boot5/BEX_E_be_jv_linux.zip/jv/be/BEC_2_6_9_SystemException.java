package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x54,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x6F,0x72};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_11 = {0x0A};
public static BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_4_ContainerList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_vv = be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
/* Line: 54*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_1_ta_ph = bem_createInstance_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1054253204);
bevt_0_ta_ph.bemd_1(1171440533, this);
} /* Line: 55*/
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_1));
if (bevp_description == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 58*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_2));
bevt_4_ta_ph = bevl_toRet.bemd_1(-840442158, bevt_5_ta_ph);
bevl_toRet = bevt_4_ta_ph.bemd_1(-840442158, bevp_description);
} /* Line: 59*/
if (bevp_fileName == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 61*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_3));
bevt_7_ta_ph = bevl_toRet.bemd_1(-840442158, bevt_8_ta_ph);
bevl_toRet = bevt_7_ta_ph.bemd_1(-840442158, bevp_fileName);
} /* Line: 62*/
if (bevp_lineNumber == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 64*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_10_ta_ph = bevl_toRet.bemd_1(-840442158, bevt_11_ta_ph);
bevt_12_ta_ph = bevp_lineNumber.bemd_0(1497956054);
bevl_toRet = bevt_10_ta_ph.bemd_1(-840442158, bevt_12_ta_ph);
} /* Line: 65*/
if (bevp_lang == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 67*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_5));
bevt_14_ta_ph = bevl_toRet.bemd_1(-840442158, bevt_15_ta_ph);
bevl_toRet = bevt_14_ta_ph.bemd_1(-840442158, bevp_lang);
} /* Line: 68*/
if (bevp_emitLang == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 70*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_6));
bevt_17_ta_ph = bevl_toRet.bemd_1(-840442158, bevt_18_ta_ph);
bevl_toRet = bevt_17_ta_ph.bemd_1(-840442158, bevp_emitLang);
} /* Line: 71*/
if (bevp_methodName == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_7));
bevt_20_ta_ph = bevl_toRet.bemd_1(-840442158, bevt_21_ta_ph);
bevl_toRet = bevt_20_ta_ph.bemd_1(-840442158, bevp_methodName);
} /* Line: 74*/
if (bevp_klassName == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 76*/ {
bevt_24_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_8));
bevt_23_ta_ph = bevl_toRet.bemd_1(-840442158, bevt_24_ta_ph);
bevl_toRet = bevt_23_ta_ph.bemd_1(-840442158, bevp_klassName);
} /* Line: 77*/
if (bevp_framesText == null) {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 79*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_9));
bevt_26_ta_ph = bevl_toRet.bemd_1(-840442158, bevt_27_ta_ph);
bevl_toRet = bevt_26_ta_ph.bemd_1(-840442158, bevp_framesText);
} /* Line: 80*/
if (bevp_frames == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 82*/ {
bevt_29_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(-840442158, bevt_29_ta_ph);
} /* Line: 83*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_9_4_ContainerList bem_framesGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
/* Line: 91*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_1_ta_ph = bem_createInstance_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1054253204);
bevt_0_ta_ph.bemd_1(1171440533, this);
} /* Line: 92*/
if (bevp_vv.bevi_bool)/* Line: 94*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_9_SystemException_bels_10));
bevt_3_ta_ph.bem_print_0();
} /* Line: 95*/
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_4_ContainerList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
/* Line: 102*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_2_ta_ph = bem_createInstance_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1054253204);
bevt_1_ta_ph.bemd_1(1171440533, this);
} /* Line: 103*/
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_11));
bevl_toRet = bevl_toRet.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_loop = bevl_myFrames.bem_iteratorGet_0();
while (true)
/* Line: 109*/ {
bevt_6_ta_ph = bevt_0_ta_loop.bemd_0(433084870);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 109*/ {
bevl_ft = bevt_0_ta_loop.bemd_0(811191969);
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 110*/
 else /* Line: 109*/ {
break;
} /* Line: 109*/
} /* Line: 109*/
} /* Line: 109*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_frames == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 121*/ {
bevp_frames = (new BEC_2_9_4_ContainerList()).bem_new_0();
} /* Line: 122*/
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_klassName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_description = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lineNumber = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_frames = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGet_0() throws Throwable {
return bevp_vv;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {47, 50, 55, 55, 55, 55, 57, 58, 58, 59, 59, 59, 61, 61, 62, 62, 62, 64, 64, 65, 65, 65, 65, 67, 67, 68, 68, 68, 70, 70, 71, 71, 71, 73, 73, 74, 74, 74, 76, 76, 77, 77, 77, 79, 79, 80, 80, 80, 82, 82, 83, 83, 85, 92, 92, 92, 92, 95, 95, 98, 103, 103, 103, 103, 105, 106, 107, 107, 108, 108, 109, 0, 109, 109, 110, 113, 117, 121, 121, 122, 124, 128, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 72, 73, 74, 75, 77, 78, 83, 84, 85, 86, 88, 93, 94, 95, 96, 98, 103, 104, 105, 106, 107, 109, 114, 115, 116, 117, 119, 124, 125, 126, 127, 129, 134, 135, 136, 137, 139, 144, 145, 146, 147, 149, 154, 155, 156, 157, 159, 164, 165, 166, 168, 176, 177, 178, 179, 182, 183, 185, 199, 200, 201, 202, 204, 205, 206, 211, 212, 213, 214, 214, 217, 219, 220, 227, 230, 234, 239, 240, 242, 247, 248, 252, 255, 259, 263, 266, 270, 273, 277, 280, 284, 287, 291, 294, 298, 302, 305, 309, 312, 316, 319};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 47 35
new 0 47 35
assign 1 50 36
assign 1 55 72
new 0 55 72
assign 1 55 73
createInstance 1 55 73
assign 1 55 74
new 0 55 74
translateEmittedException 1 55 75
assign 1 57 77
new 0 57 77
assign 1 58 78
def 1 58 83
assign 1 59 84
new 0 59 84
assign 1 59 85
add 1 59 85
assign 1 59 86
add 1 59 86
assign 1 61 88
def 1 61 93
assign 1 62 94
new 0 62 94
assign 1 62 95
add 1 62 95
assign 1 62 96
add 1 62 96
assign 1 64 98
def 1 64 103
assign 1 65 104
new 0 65 104
assign 1 65 105
add 1 65 105
assign 1 65 106
toString 0 65 106
assign 1 65 107
add 1 65 107
assign 1 67 109
def 1 67 114
assign 1 68 115
new 0 68 115
assign 1 68 116
add 1 68 116
assign 1 68 117
add 1 68 117
assign 1 70 119
def 1 70 124
assign 1 71 125
new 0 71 125
assign 1 71 126
add 1 71 126
assign 1 71 127
add 1 71 127
assign 1 73 129
def 1 73 134
assign 1 74 135
new 0 74 135
assign 1 74 136
add 1 74 136
assign 1 74 137
add 1 74 137
assign 1 76 139
def 1 76 144
assign 1 77 145
new 0 77 145
assign 1 77 146
add 1 77 146
assign 1 77 147
add 1 77 147
assign 1 79 149
def 1 79 154
assign 1 80 155
new 0 80 155
assign 1 80 156
add 1 80 156
assign 1 80 157
add 1 80 157
assign 1 82 159
def 1 82 164
assign 1 83 165
getFrameText 0 83 165
assign 1 83 166
add 1 83 166
return 1 85 168
assign 1 92 176
new 0 92 176
assign 1 92 177
createInstance 1 92 177
assign 1 92 178
new 0 92 178
translateEmittedException 1 92 179
assign 1 95 182
new 0 95 182
print 0 95 183
return 1 98 185
assign 1 103 199
new 0 103 199
assign 1 103 200
createInstance 1 103 200
assign 1 103 201
new 0 103 201
translateEmittedException 1 103 202
assign 1 105 204
new 0 105 204
assign 1 106 205
framesGet 0 106 205
assign 1 107 206
def 1 107 211
assign 1 108 212
new 0 108 212
assign 1 108 213
add 1 108 213
assign 1 109 214
iteratorGet 0 0 214
assign 1 109 217
hasNextGet 0 109 217
assign 1 109 219
nextGet 0 109 219
assign 1 110 220
add 1 110 220
return 1 113 227
return 1 117 230
assign 1 121 234
undef 1 121 239
assign 1 122 240
new 0 122 240
addValue 1 124 242
assign 1 128 247
new 4 128 247
addFrame 1 128 248
return 1 0 252
assign 1 0 255
assign 1 0 259
return 1 0 263
assign 1 0 266
return 1 0 270
assign 1 0 273
return 1 0 277
assign 1 0 280
return 1 0 284
assign 1 0 287
return 1 0 291
assign 1 0 294
assign 1 0 298
return 1 0 302
assign 1 0 305
return 1 0 309
assign 1 0 312
return 1 0 316
assign 1 0 319
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 457178368: return bem_classNameGet_0();
case 562138791: return bem_print_0();
case -1886612635: return bem_framesGet_0();
case 1745333375: return bem_hashGet_0();
case 493396768: return bem_translatedGet_0();
case -1054253204: return bem_new_0();
case 1242398529: return bem_getFrameText_0();
case 1336616742: return bem_fieldNamesGet_0();
case -1401305769: return bem_copy_0();
case 1653499699: return bem_create_0();
case 1580305828: return bem_lineNumberGet_0();
case 458243294: return bem_descriptionGet_0();
case 636970399: return bem_klassNameGet_0();
case 1705940506: return bem_fileNameGet_0();
case 1300547597: return bem_methodNameGet_0();
case 1787710498: return bem_iteratorGet_0();
case -1826754149: return bem_tagGet_0();
case 1497956054: return bem_toString_0();
case 147569631: return bem_emitLangGet_0();
case -1576971234: return bem_vvGet_0();
case -1931080083: return bem_framesTextGet_0();
case 1145963129: return bem_langGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 586710983: return bem_notEquals_1(bevd_0);
case 266455440: return bem_framesSet_1(bevd_0);
case -1471136482: return bem_new_1(bevd_0);
case -93958152: return bem_equals_1(bevd_0);
case 1660653507: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -943743519: return bem_klassNameSet_1(bevd_0);
case 112425026: return bem_undef_1(bevd_0);
case 1023520532: return bem_lineNumberSet_1(bevd_0);
case -1060201270: return bem_methodNameSet_1(bevd_0);
case 1349971415: return bem_vvSet_1(bevd_0);
case -1538599237: return bem_emitLangSet_1(bevd_0);
case -1094966912: return bem_framesTextSet_1(bevd_0);
case -1282419489: return bem_copyTo_1(bevd_0);
case 519586024: return bem_def_1(bevd_0);
case 1950847863: return bem_descriptionSet_1(bevd_0);
case -1190667933: return bem_translatedSet_1(bevd_0);
case -2045148476: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1894503367: return bem_sameType_1(bevd_0);
case -1094345634: return bem_otherType_1(bevd_0);
case 897088300: return bem_sameObject_1(bevd_0);
case -990904887: return bem_langSet_1(bevd_0);
case 291082926: return bem_fileNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1052889707: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651612463: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 209233844: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1399119392: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 402325359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 754474221: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
