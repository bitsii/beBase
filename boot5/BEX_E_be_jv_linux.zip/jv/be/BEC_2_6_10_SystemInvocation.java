package be;
/* IO:File: source/base/Functions.be */
public class BEC_2_6_10_SystemInvocation extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemInvocation() { }
private static byte[] becc_BEC_2_6_10_SystemInvocation_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_10_SystemInvocation_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_inst;

public static BET_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemInvocation bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_9_4_ContainerList beva__args) throws Throwable {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_args = beva__args;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(1977574168, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(1977574168, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_targetGetDirect_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGet_0() throws Throwable {
return bevp_callName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_callNameGetDirect_0() throws Throwable {
return bevp_callName;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {58, 59, 60, 65, 66, 70, 71, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 22, 23, 27, 28, 31, 34, 37, 41, 45, 48, 51, 55, 59, 62, 65, 69};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 58 15
assign 1 59 16
assign 1 60 17
assign 1 65 22
invoke 2 65 22
return 1 66 23
assign 1 70 27
invoke 2 70 27
return 1 71 28
return 1 0 31
return 1 0 34
assign 1 0 37
assign 1 0 41
return 1 0 45
return 1 0 48
assign 1 0 51
assign 1 0 55
return 1 0 59
return 1 0 62
assign 1 0 65
assign 1 0 69
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1486081832: return bem_invoke_0();
case -1002240013: return bem_callNameGetDirect_0();
case -1400770094: return bem_many_0();
case -518710385: return bem_fieldNamesGet_0();
case -1840409586: return bem_targetGet_0();
case -512236724: return bem_deserializeClassNameGet_0();
case 992975540: return bem_argsGet_0();
case -2091241279: return bem_create_0();
case 1349866592: return bem_toString_0();
case -582086241: return bem_callNameGet_0();
case 1957608515: return bem_fieldIteratorGet_0();
case -1423578661: return bem_print_0();
case -923057320: return bem_serializationIteratorGet_0();
case 993759307: return bem_iteratorGet_0();
case -35248652: return bem_toAny_0();
case 1299948053: return bem_serializeContents_0();
case 518862870: return bem_tagGet_0();
case -914347833: return bem_new_0();
case 646589914: return bem_sourceFileNameGet_0();
case -2035208893: return bem_echo_0();
case 1052263558: return bem_serializeToString_0();
case 1528862471: return bem_main_0();
case 675566088: return bem_classNameGet_0();
case 13807179: return bem_hashGet_0();
case 758802515: return bem_once_0();
case -747311613: return bem_targetGetDirect_0();
case -245363326: return bem_copy_0();
case -1050935903: return bem_argsGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -537932837: return bem_equals_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case -1845541676: return bem_callNameSetDirect_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case -478999650: return bem_targetSetDirect_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case -285679185: return bem_argsSet_1(bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case 2012468585: return bem_argsSetDirect_1(bevd_0);
case 112982911: return bem_callNameSet_1(bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case 1878088795: return bem_targetSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 777577179: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_4_ContainerList) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemInvocation_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_10_SystemInvocation_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemInvocation();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst = (BEC_2_6_10_SystemInvocation) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_type;
}
}
