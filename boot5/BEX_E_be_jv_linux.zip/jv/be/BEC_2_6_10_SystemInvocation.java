package be;
/* IO:File: source/base/Functions.be */
public class BEC_2_6_10_SystemInvocation extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemInvocation() { }
private static byte[] becc_BEC_2_6_10_SystemInvocation_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_10_SystemInvocation_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_inst;

public static BET_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemInvocation bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_9_4_ContainerList beva__args) throws Throwable {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_args = beva__args;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-2117068130, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-2117068130, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGet_0() throws Throwable {
return bevp_callName;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {64, 65, 66, 71, 72, 76, 77, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 22, 23, 27, 28, 31, 34, 38, 41, 45, 48};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 64 15
assign 1 65 16
assign 1 66 17
assign 1 71 22
invoke 2 71 22
return 1 72 23
assign 1 76 27
invoke 2 76 27
return 1 77 28
return 1 0 31
assign 1 0 34
return 1 0 38
assign 1 0 41
return 1 0 45
assign 1 0 48
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -538472806: return bem_toString_0();
case -913633167: return bem_create_0();
case 705768714: return bem_hashGet_0();
case 2145150459: return bem_argsGet_0();
case 1214951712: return bem_copy_0();
case 1592655621: return bem_iteratorGet_0();
case -1825266857: return bem_targetGet_0();
case 1237286351: return bem_new_0();
case 1963830339: return bem_main_0();
case 1847604164: return bem_callNameGet_0();
case 1743441213: return bem_print_0();
case -1019530841: return bem_invoke_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1447238914: return bem_undef_1(bevd_0);
case -92722830: return bem_notEquals_1(bevd_0);
case -943829857: return bem_targetSet_1(bevd_0);
case 2063097426: return bem_copyTo_1(bevd_0);
case -985676477: return bem_callNameSet_1(bevd_0);
case -1933589038: return bem_argsSet_1(bevd_0);
case 1117275607: return bem_equals_1(bevd_0);
case -1873180946: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2117068130: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 105174404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -77288097: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -828010984: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1533746710: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_4_ContainerList) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemInvocation_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_10_SystemInvocation_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemInvocation();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst = (BEC_2_6_10_SystemInvocation) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_type;
}
}
