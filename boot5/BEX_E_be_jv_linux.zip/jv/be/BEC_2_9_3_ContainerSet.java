package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_4_ContainerList bevp_buckets;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 187*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 188*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 194*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /* Line: 195*/
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_modu.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
/* Line: 213*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 213*/ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 215*/ {
bevt_4_ta_ph = bevl_ni.bem_keyGet_0();
bevt_3_ta_ph = bem_innerPut_4(bevt_4_ta_ph, null, bevl_ni, beva_ninner);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1595083651);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 216*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 217*/
} /* Line: 216*/
} /* Line: 215*/
 else /* Line: 213*/ {
break;
} /* Line: 213*/
} /* Line: 213*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nbuckets = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = beva_slt.bem_sizeGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(bevp_multi);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_nbuckets = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
while (true)
/* Line: 228*/ {
bevt_4_ta_ph = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-1595083651);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 228*/ {
bevl_nbuckets = bevl_nbuckets.bem_increment_0();
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
} /* Line: 230*/
 else /* Line: 228*/ {
break;
} /* Line: 228*/
} /* Line: 228*/
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_4_ta_ph = beva_other.bem_sizeGet_0();
bevt_5_ta_ph = bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 237*/
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 239*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_7_ta_ph.bevi_bool)/* Line: 239*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_9_ta_ph = beva_other.bem_has_1(bevl_i);
if (bevt_9_ta_ph.bevi_bool) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 240*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 240*/
} /* Line: 240*/
 else /* Line: 239*/ {
break;
} /* Line: 239*/
} /* Line: 239*/
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 247*/ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 249*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 250*/
} /* Line: 249*/
 else /* Line: 252*/ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(1117980607);
} /* Line: 253*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 257*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 259*/ {
if (beva_inode == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_ta_ph);
} /* Line: 261*/
 else /* Line: 262*/ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 263*/
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 266*/
 else /* Line: 259*/ {
bevt_10_ta_ph = bevl_n.bem_hvalGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_9_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /* Line: 268*/
 else /* Line: 259*/ {
bevt_13_ta_ph = bevl_n.bem_keyGet_0();
bevt_12_ta_ph = bevp_rel.bem_isEqual_2(bevt_13_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 269*/ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /* Line: 273*/
 else /* Line: 274*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 276*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 277*/
} /* Line: 276*/
} /* Line: 259*/
} /* Line: 259*/
} /* Line: 259*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevp_buckets);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1595083651);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 284*/ {
bevl_slt = bevp_buckets;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 287*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1595083651);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 287*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 288*/
 else /* Line: 287*/ {
break;
} /* Line: 287*/
} /* Line: 287*/
bevp_buckets = bevl_slt;
} /* Line: 290*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 292*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 293*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 301*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 302*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 306*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 308*/ {
return null;
} /* Line: 309*/
 else /* Line: 308*/ {
bevt_5_ta_ph = bevl_n.bem_hvalGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_4_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 310*/ {
return null;
} /* Line: 311*/
 else /* Line: 308*/ {
bevt_7_ta_ph = bevl_n.bem_keyGet_0();
bevt_6_ta_ph = bevp_rel.bem_isEqual_2(bevt_7_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 312*/ {
bevt_8_ta_ph = bevl_n.bem_getFrom_0();
return bevt_8_ta_ph;
} /* Line: 313*/
 else /* Line: 314*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 316*/ {
return null;
} /* Line: 317*/
} /* Line: 316*/
} /* Line: 308*/
} /* Line: 308*/
} /* Line: 308*/
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 327*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 328*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 332*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 334*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 335*/
 else /* Line: 334*/ {
bevt_6_ta_ph = bevl_n.bem_hvalGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_5_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 337*/
 else /* Line: 334*/ {
bevt_9_ta_ph = bevl_n.bem_keyGet_0();
bevt_8_ta_ph = bevp_rel.bem_isEqual_2(bevt_9_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 338*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 339*/
 else /* Line: 340*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /* Line: 343*/
} /* Line: 342*/
} /* Line: 334*/
} /* Line: 334*/
} /* Line: 334*/
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 354*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 355*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 359*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 361*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 362*/
 else /* Line: 361*/ {
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_6_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 363*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 364*/
 else /* Line: 361*/ {
bevt_10_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevp_rel.bem_isEqual_2(bevt_10_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 365*/ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
/* Line: 369*/ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 369*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 371*/ {
bevt_15_ta_ph = bevl_n.bem_hvalGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_14_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 371*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 371*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 371*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_16_ta_ph;
} /* Line: 372*/
 else /* Line: 373*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_17_ta_ph = bevl_sl.bem_subtract_1(bevt_18_ta_ph);
bevl_slt.bem_put_2(bevt_17_ta_ph, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 375*/
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 377*/
 else /* Line: 369*/ {
break;
} /* Line: 369*/
} /* Line: 369*/
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_19_ta_ph;
} /* Line: 379*/
 else /* Line: 380*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_21_ta_ph;
} /* Line: 383*/
} /* Line: 382*/
} /* Line: 361*/
} /* Line: 361*/
} /* Line: 361*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_buckets.bem_copy_0();
bevl_other.bemd_1(-114248980, bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 394*/ {
bevt_2_ta_ph = bevp_buckets.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 394*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 396*/ {
bevt_4_ta_ph = bevl_other.bemd_0(-1752406544);
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_8_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevl_n.bem_getFrom_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
bevt_4_ta_ph.bemd_2(-153469850, bevl_i, bevt_5_ta_ph);
} /* Line: 397*/
 else /* Line: 398*/ {
bevt_10_ta_ph = bevl_other.bemd_0(-1752406544);
bevt_10_ta_ph.bemd_2(-153469850, bevl_i, null);
} /* Line: 399*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 394*/
 else /* Line: 394*/ {
break;
} /* Line: 394*/
} /* Line: 394*/
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_buckets.bem_clear_0();
bevp_buckets.bem_sizeSet_1(bevp_modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_keyIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_nodeIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 439*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 439*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = beva_other.bem_has_1(bevl_x);
if (bevt_3_ta_ph.bevi_bool)/* Line: 440*/ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 441*/
} /* Line: 440*/
 else /* Line: 439*/ {
break;
} /* Line: 439*/
} /* Line: 439*/
} /* Line: 439*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 450*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 450*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 451*/
 else /* Line: 450*/ {
break;
} /* Line: 450*/
} /* Line: 450*/
if (beva_other == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 453*/ {
bevt_1_ta_loop = beva_other.bem_setIteratorGet_0();
while (true)
/* Line: 454*/ {
bevt_4_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 454*/ {
bevl_x = bevt_1_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 455*/
 else /* Line: 454*/ {
break;
} /* Line: 454*/
} /* Line: 454*/
} /* Line: 454*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 468*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_other, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 469*/ {
bevt_0_ta_loop = beva_other.bemd_0(966722567);
while (true)
/* Line: 470*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(2002551285);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 470*/ {
bevl_x = bevt_0_ta_loop.bemd_0(-150432513);
bem_put_1(bevl_x);
} /* Line: 471*/
 else /* Line: 470*/ {
break;
} /* Line: 470*/
} /* Line: 470*/
} /* Line: 470*/
 else /* Line: 469*/ {
bevt_6_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_5_ta_ph = bevt_6_ta_ph.bem_sameType_2(beva_other, bevp_baseNode);
if (bevt_5_ta_ph.bevi_bool)/* Line: 473*/ {
bevt_7_ta_ph = beva_other.bemd_0(-1616583659);
bem_put_1(bevt_7_ta_ph);
} /* Line: 474*/
 else /* Line: 475*/ {
bem_put_1(beva_other);
} /* Line: 476*/
} /* Line: 469*/
} /* Line: 469*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_bucketsGet_0() throws Throwable {
return bevp_buckets;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_bucketsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buckets = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {167, 167, 173, 174, 175, 176, 177, 180, 181, 187, 187, 187, 188, 188, 190, 190, 194, 194, 194, 195, 195, 197, 197, 201, 201, 205, 205, 209, 209, 213, 213, 214, 215, 215, 216, 216, 216, 217, 217, 221, 221, 226, 226, 226, 226, 227, 228, 228, 229, 230, 232, 236, 236, 0, 236, 236, 236, 236, 0, 0, 237, 237, 239, 0, 239, 239, 240, 240, 240, 240, 240, 242, 242, 246, 247, 247, 248, 249, 249, 249, 250, 253, 255, 256, 258, 259, 259, 260, 260, 261, 261, 261, 263, 265, 266, 266, 267, 267, 267, 267, 268, 268, 269, 269, 270, 272, 273, 273, 275, 276, 276, 277, 277, 284, 284, 285, 286, 287, 287, 288, 290, 293, 298, 299, 300, 301, 301, 301, 302, 304, 305, 307, 308, 308, 309, 310, 310, 310, 310, 311, 312, 312, 313, 313, 315, 316, 316, 317, 324, 325, 326, 327, 327, 327, 328, 330, 331, 333, 334, 334, 335, 335, 336, 336, 336, 336, 337, 337, 338, 338, 339, 339, 341, 342, 342, 343, 343, 350, 351, 353, 354, 354, 354, 355, 357, 358, 360, 361, 361, 362, 362, 363, 363, 363, 363, 364, 364, 365, 365, 366, 367, 368, 369, 369, 370, 371, 371, 0, 371, 371, 371, 371, 0, 0, 372, 372, 374, 374, 374, 375, 377, 379, 379, 381, 382, 382, 383, 383, 391, 392, 393, 393, 394, 394, 394, 394, 395, 396, 396, 397, 397, 397, 397, 397, 397, 397, 399, 399, 394, 402, 407, 408, 409, 413, 413, 417, 417, 421, 421, 425, 425, 429, 429, 433, 433, 437, 438, 438, 439, 0, 439, 439, 440, 441, 445, 449, 450, 0, 450, 450, 451, 453, 453, 454, 0, 454, 454, 455, 458, 462, 463, 464, 468, 468, 469, 469, 470, 0, 470, 470, 471, 473, 473, 474, 474, 476, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 27, 28, 29, 30, 31, 39, 40, 45, 46, 47, 49, 50, 57, 58, 63, 64, 65, 67, 68, 72, 73, 77, 78, 83, 84, 96, 99, 101, 102, 107, 108, 109, 110, 112, 113, 121, 122, 132, 133, 134, 135, 136, 139, 140, 142, 143, 149, 165, 170, 171, 174, 175, 176, 181, 182, 185, 189, 190, 192, 192, 195, 197, 198, 199, 204, 205, 206, 213, 214, 239, 240, 245, 246, 247, 248, 253, 254, 258, 260, 261, 264, 265, 270, 271, 276, 277, 278, 279, 282, 284, 285, 286, 289, 290, 291, 296, 297, 298, 301, 302, 304, 305, 306, 307, 310, 311, 316, 317, 318, 331, 332, 334, 335, 338, 339, 341, 347, 350, 371, 372, 373, 374, 375, 380, 381, 383, 384, 387, 388, 393, 394, 397, 398, 399, 404, 405, 408, 409, 411, 412, 415, 416, 421, 422, 449, 450, 451, 452, 453, 458, 459, 461, 462, 465, 466, 471, 472, 473, 476, 477, 478, 483, 484, 485, 488, 489, 491, 492, 495, 496, 501, 502, 503, 539, 540, 541, 542, 543, 548, 549, 551, 552, 555, 556, 561, 562, 563, 566, 567, 568, 573, 574, 575, 578, 579, 581, 582, 583, 586, 591, 592, 593, 598, 599, 602, 603, 604, 609, 610, 613, 617, 618, 621, 622, 623, 624, 626, 632, 633, 636, 637, 642, 643, 644, 666, 667, 668, 669, 670, 673, 674, 679, 680, 681, 686, 687, 688, 689, 690, 691, 692, 693, 696, 697, 699, 705, 708, 709, 710, 715, 716, 720, 721, 725, 726, 730, 731, 735, 736, 740, 741, 750, 751, 756, 757, 757, 760, 762, 763, 765, 773, 783, 784, 784, 787, 789, 790, 796, 801, 802, 802, 805, 807, 808, 815, 819, 820, 821, 833, 838, 839, 840, 842, 842, 845, 847, 848, 856, 857, 859, 860, 863, 870, 873, 877, 880};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 167 20
new 0 167 20
new 1 167 21
assign 1 173 25
assign 1 174 26
new 0 174 26
assign 1 175 27
new 0 175 27
assign 1 176 28
new 0 176 28
assign 1 177 29
new 0 177 29
assign 1 180 30
new 1 180 30
assign 1 181 31
new 0 181 31
assign 1 187 39
new 0 187 39
assign 1 187 40
equals 1 187 45
assign 1 188 46
new 0 188 46
return 1 188 47
assign 1 190 49
new 0 190 49
return 1 190 50
assign 1 194 57
new 0 194 57
assign 1 194 58
equals 1 194 63
assign 1 195 64
new 0 195 64
return 1 195 65
assign 1 197 67
new 0 197 67
return 1 197 68
assign 1 201 72
toString 0 201 72
return 1 201 73
assign 1 205 77
new 1 205 77
new 1 205 78
assign 1 209 83
new 1 209 83
return 1 209 84
assign 1 213 96
arrayIteratorGet 0 213 96
assign 1 213 99
hasNextGet 0 213 99
assign 1 214 101
nextGet 0 214 101
assign 1 215 102
def 1 215 107
assign 1 216 108
keyGet 0 216 108
assign 1 216 109
innerPut 4 216 109
assign 1 216 110
not 0 216 110
assign 1 217 112
new 0 217 112
return 1 217 113
assign 1 221 121
new 0 221 121
return 1 221 122
assign 1 226 132
sizeGet 0 226 132
assign 1 226 133
multiply 1 226 133
assign 1 226 134
new 0 226 134
assign 1 226 135
add 1 226 135
assign 1 227 136
new 1 227 136
assign 1 228 139
insertAll 2 228 139
assign 1 228 140
not 0 228 140
assign 1 229 142
increment 0 229 142
assign 1 230 143
new 1 230 143
return 1 232 149
assign 1 236 165
undef 1 236 170
assign 1 0 171
assign 1 236 174
sizeGet 0 236 174
assign 1 236 175
sizeGet 0 236 175
assign 1 236 176
notEquals 1 236 181
assign 1 0 182
assign 1 0 185
assign 1 237 189
new 0 237 189
return 1 237 190
assign 1 239 192
setIteratorGet 0 0 192
assign 1 239 195
hasNextGet 0 239 195
assign 1 239 197
nextGet 0 239 197
assign 1 240 198
has 1 240 198
assign 1 240 199
not 0 240 204
assign 1 240 205
new 0 240 205
return 1 240 206
assign 1 242 213
new 0 242 213
return 1 242 214
assign 1 246 239
sizeGet 0 246 239
assign 1 247 240
undef 1 247 245
assign 1 248 246
getHash 1 248 246
assign 1 249 247
new 0 249 247
assign 1 249 248
lesser 1 249 253
assign 1 250 254
abs 0 250 254
assign 1 253 258
hvalGet 0 253 258
assign 1 255 260
modulus 1 255 260
assign 1 256 261
assign 1 258 264
get 1 258 264
assign 1 259 265
undef 1 259 270
assign 1 260 271
undef 1 260 276
assign 1 261 277
create 0 261 277
assign 1 261 278
new 3 261 278
put 2 261 279
put 2 263 282
assign 1 265 284
new 0 265 284
assign 1 266 285
new 0 266 285
return 1 266 286
assign 1 267 289
hvalGet 0 267 289
assign 1 267 290
modulus 1 267 290
assign 1 267 291
notEquals 1 267 296
assign 1 268 297
new 0 268 297
return 1 268 298
assign 1 269 301
keyGet 0 269 301
assign 1 269 302
isEqual 2 269 302
putTo 2 270 304
assign 1 272 305
new 0 272 305
assign 1 273 306
new 0 273 306
return 1 273 307
assign 1 275 310
increment 0 275 310
assign 1 276 311
greaterEquals 1 276 316
assign 1 277 317
new 0 277 317
return 1 277 318
assign 1 284 331
innerPut 4 284 331
assign 1 284 332
not 0 284 332
assign 1 285 334
assign 1 286 335
rehash 1 286 335
assign 1 287 338
innerPut 4 287 338
assign 1 287 339
not 0 287 339
assign 1 288 341
rehash 1 288 341
assign 1 290 347
assign 1 293 350
increment 0 293 350
assign 1 298 371
assign 1 299 372
sizeGet 0 299 372
assign 1 300 373
getHash 1 300 373
assign 1 301 374
new 0 301 374
assign 1 301 375
lesser 1 301 380
assign 1 302 381
abs 0 302 381
assign 1 304 383
modulus 1 304 383
assign 1 305 384
assign 1 307 387
get 1 307 387
assign 1 308 388
undef 1 308 393
return 1 309 394
assign 1 310 397
hvalGet 0 310 397
assign 1 310 398
modulus 1 310 398
assign 1 310 399
notEquals 1 310 404
return 1 311 405
assign 1 312 408
keyGet 0 312 408
assign 1 312 409
isEqual 2 312 409
assign 1 313 411
getFrom 0 313 411
return 1 313 412
assign 1 315 415
increment 0 315 415
assign 1 316 416
greaterEquals 1 316 421
return 1 317 422
assign 1 324 449
assign 1 325 450
sizeGet 0 325 450
assign 1 326 451
getHash 1 326 451
assign 1 327 452
new 0 327 452
assign 1 327 453
lesser 1 327 458
assign 1 328 459
abs 0 328 459
assign 1 330 461
modulus 1 330 461
assign 1 331 462
assign 1 333 465
get 1 333 465
assign 1 334 466
undef 1 334 471
assign 1 335 472
new 0 335 472
return 1 335 473
assign 1 336 476
hvalGet 0 336 476
assign 1 336 477
modulus 1 336 477
assign 1 336 478
notEquals 1 336 483
assign 1 337 484
new 0 337 484
return 1 337 485
assign 1 338 488
keyGet 0 338 488
assign 1 338 489
isEqual 2 338 489
assign 1 339 491
new 0 339 491
return 1 339 492
assign 1 341 495
increment 0 341 495
assign 1 342 496
greaterEquals 1 342 501
assign 1 343 502
new 0 343 502
return 1 343 503
assign 1 350 539
assign 1 351 540
sizeGet 0 351 540
assign 1 353 541
getHash 1 353 541
assign 1 354 542
new 0 354 542
assign 1 354 543
lesser 1 354 548
assign 1 355 549
abs 0 355 549
assign 1 357 551
modulus 1 357 551
assign 1 358 552
assign 1 360 555
get 1 360 555
assign 1 361 556
undef 1 361 561
assign 1 362 562
new 0 362 562
return 1 362 563
assign 1 363 566
hvalGet 0 363 566
assign 1 363 567
modulus 1 363 567
assign 1 363 568
notEquals 1 363 573
assign 1 364 574
new 0 364 574
return 1 364 575
assign 1 365 578
keyGet 0 365 578
assign 1 365 579
isEqual 2 365 579
put 2 366 581
assign 1 367 582
decrement 0 367 582
assign 1 368 583
increment 0 368 583
assign 1 369 586
lesser 1 369 591
assign 1 370 592
get 1 370 592
assign 1 371 593
undef 1 371 598
assign 1 0 599
assign 1 371 602
hvalGet 0 371 602
assign 1 371 603
modulus 1 371 603
assign 1 371 604
notEquals 1 371 609
assign 1 0 610
assign 1 0 613
assign 1 372 617
new 0 372 617
return 1 372 618
assign 1 374 621
new 0 374 621
assign 1 374 622
subtract 1 374 622
put 2 374 623
put 2 375 624
assign 1 377 626
increment 0 377 626
assign 1 379 632
new 0 379 632
return 1 379 633
assign 1 381 636
increment 0 381 636
assign 1 382 637
greaterEquals 1 382 642
assign 1 383 643
new 0 383 643
return 1 383 644
assign 1 391 666
create 0 391 666
copyTo 1 392 667
assign 1 393 668
copy 0 393 668
bucketsSet 1 393 669
assign 1 394 670
new 0 394 670
assign 1 394 673
lengthGet 0 394 673
assign 1 394 674
lesser 1 394 679
assign 1 395 680
get 1 395 680
assign 1 396 681
def 1 396 686
assign 1 397 687
bucketsGet 0 397 687
assign 1 397 688
create 0 397 688
assign 1 397 689
hvalGet 0 397 689
assign 1 397 690
keyGet 0 397 690
assign 1 397 691
getFrom 0 397 691
assign 1 397 692
new 3 397 692
put 2 397 693
assign 1 399 696
bucketsGet 0 399 696
put 2 399 697
assign 1 394 699
increment 0 394 699
return 1 402 705
clear 0 407 708
sizeSet 1 408 709
assign 1 409 710
new 0 409 710
assign 1 413 715
new 1 413 715
return 1 413 716
assign 1 417 720
new 1 417 720
return 1 417 721
assign 1 421 725
new 1 421 725
return 1 421 726
assign 1 425 730
keyIteratorGet 0 425 730
return 1 425 731
assign 1 429 735
new 1 429 735
return 1 429 736
assign 1 433 740
nodeIteratorGet 0 433 740
return 1 433 741
assign 1 437 750
new 0 437 750
assign 1 438 751
def 1 438 756
assign 1 439 757
setIteratorGet 0 0 757
assign 1 439 760
hasNextGet 0 439 760
assign 1 439 762
nextGet 0 439 762
assign 1 440 763
has 1 440 763
put 1 441 765
return 1 445 773
assign 1 449 783
new 0 449 783
assign 1 450 784
setIteratorGet 0 0 784
assign 1 450 787
hasNextGet 0 450 787
assign 1 450 789
nextGet 0 450 789
put 1 451 790
assign 1 453 796
def 1 453 801
assign 1 454 802
setIteratorGet 0 0 802
assign 1 454 805
hasNextGet 0 454 805
assign 1 454 807
nextGet 0 454 807
put 1 455 808
return 1 458 815
assign 1 462 819
copy 0 462 819
addValue 1 463 820
return 1 464 821
assign 1 468 833
def 1 468 838
assign 1 469 839
new 0 469 839
assign 1 469 840
sameType 2 469 840
assign 1 470 842
iteratorGet 0 0 842
assign 1 470 845
hasNextGet 0 470 845
assign 1 470 847
nextGet 0 470 847
put 1 471 848
assign 1 473 856
new 0 473 856
assign 1 473 857
sameType 2 473 857
assign 1 474 859
keyGet 0 474 859
put 1 474 860
put 1 476 863
return 1 0 870
assign 1 0 873
return 1 0 877
assign 1 0 880
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -298460557: return bem_notEmptyGet_0();
case 1006966064: return bem_nodeIteratorGet_0();
case 1318937193: return bem_create_0();
case -1490589724: return bem_serializationIteratorGet_0();
case 1327010431: return bem_hashGet_0();
case -1852386173: return bem_keysGet_0();
case 1769965429: return bem_toString_0();
case -41247917: return bem_sizeGet_0();
case 1783973435: return bem_keyIteratorGet_0();
case -1640186908: return bem_serializeToString_0();
case -1863366512: return bem_setIteratorGet_0();
case 126520025: return bem_nodesGet_0();
case 966722567: return bem_iteratorGet_0();
case -469226465: return bem_print_0();
case -1683349196: return bem_clear_0();
case -1752406544: return bem_bucketsGet_0();
case 532380883: return bem_new_0();
case -639540574: return bem_isEmptyGet_0();
case 2120153411: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2096206933: return bem_sizeSet_1(bevd_0);
case -2053869140: return bem_delete_1(bevd_0);
case 212487942: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 2147027771: return bem_copyTo_1(bevd_0);
case 1985969826: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1694293325: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -479777037: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 870914554: return bem_get_1(bevd_0);
case -1161919231: return bem_addValue_1(bevd_0);
case 341261542: return bem_put_1(bevd_0);
case 1194286113: return bem_def_1(bevd_0);
case -533094380: return bem_undef_1(bevd_0);
case -16136112: return bem_notEquals_1(bevd_0);
case -114248980: return bem_bucketsSet_1(bevd_0);
case 292329142: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1292997110: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -268811991: return bem_equals_1(bevd_0);
case -287443777: return bem_has_1(bevd_0);
case 860733724: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1665151698: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 792362948: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1118394126: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -672637344: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1688602503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1588182299: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
