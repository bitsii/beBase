package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_4_ContainerList bevp_buckets;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 203*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 204*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 210*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /* Line: 211*/
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_modu.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = (BEC_3_9_4_8_ContainerListIterator) beva_ir.bem_iteratorGet_0();
while (true)
/* Line: 229*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 229*/ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 231*/ {
bevt_4_ta_ph = bevl_ni.bem_keyGet_0();
bevt_3_ta_ph = bem_innerPut_4(bevt_4_ta_ph, null, bevl_ni, beva_ninner);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-863303476);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 232*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 233*/
} /* Line: 232*/
} /* Line: 231*/
 else /* Line: 229*/ {
break;
} /* Line: 229*/
} /* Line: 229*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nbuckets = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_1_ta_ph = beva_slt.bem_lengthGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(bevp_multi);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_nbuckets = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
while (true)
/* Line: 244*/ {
bevt_4_ta_ph = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-863303476);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 244*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_nbuckets = bevl_nbuckets.bem_add_1(bevt_5_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
} /* Line: 246*/
 else /* Line: 244*/ {
break;
} /* Line: 244*/
} /* Line: 244*/
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 252*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 252*/ {
bevt_4_ta_ph = beva_other.bem_lengthGet_0();
bevt_5_ta_ph = bem_lengthGet_0();
if (bevt_4_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 252*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 252*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 252*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 252*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 253*/
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 255*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_7_ta_ph.bevi_bool)/* Line: 255*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_9_ta_ph = beva_other.bem_has_1(bevl_i);
if (bevt_9_ta_ph.bevi_bool) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 256*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 256*/
} /* Line: 256*/
 else /* Line: 255*/ {
break;
} /* Line: 255*/
} /* Line: 255*/
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
bevl_modu = beva_slt.bem_lengthGet_0();
if (beva_inode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 263*/ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 265*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 266*/
} /* Line: 265*/
 else /* Line: 268*/ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(1212087351);
} /* Line: 269*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 273*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 275*/ {
if (beva_inode == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 276*/ {
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_ta_ph);
} /* Line: 277*/
 else /* Line: 278*/ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 279*/
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 282*/
 else /* Line: 275*/ {
bevt_10_ta_ph = bevl_n.bem_hvalGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_9_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /* Line: 284*/
 else /* Line: 275*/ {
bevt_13_ta_ph = bevl_n.bem_keyGet_0();
bevt_12_ta_ph = bevp_rel.bem_isEqual_2(bevt_13_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 285*/ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /* Line: 289*/
 else /* Line: 290*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_15_ta_ph);
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 292*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_17_ta_ph;
} /* Line: 293*/
} /* Line: 292*/
} /* Line: 275*/
} /* Line: 275*/
} /* Line: 275*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevp_buckets);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-863303476);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 300*/ {
bevl_slt = bevp_buckets;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 303*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-863303476);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 303*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 304*/
 else /* Line: 303*/ {
break;
} /* Line: 303*/
} /* Line: 303*/
bevp_buckets = bevl_slt;
} /* Line: 306*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 308*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_length = bevp_length.bem_add_1(bevt_4_ta_ph);
} /* Line: 309*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_lengthGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 317*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 318*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 322*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 324*/ {
return null;
} /* Line: 325*/
 else /* Line: 324*/ {
bevt_5_ta_ph = bevl_n.bem_hvalGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_4_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 326*/ {
return null;
} /* Line: 327*/
 else /* Line: 324*/ {
bevt_7_ta_ph = bevl_n.bem_keyGet_0();
bevt_6_ta_ph = bevp_rel.bem_isEqual_2(bevt_7_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 328*/ {
bevt_8_ta_ph = bevl_n.bem_getFrom_0();
return bevt_8_ta_ph;
} /* Line: 329*/
 else /* Line: 330*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_9_ta_ph);
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 332*/ {
return null;
} /* Line: 333*/
} /* Line: 332*/
} /* Line: 324*/
} /* Line: 324*/
} /* Line: 324*/
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_lengthGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 343*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 344*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 348*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 351*/
 else /* Line: 350*/ {
bevt_6_ta_ph = bevl_n.bem_hvalGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_5_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 352*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 353*/
 else /* Line: 350*/ {
bevt_9_ta_ph = bevl_n.bem_keyGet_0();
bevt_8_ta_ph = bevp_rel.bem_isEqual_2(bevt_9_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 354*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 355*/
 else /* Line: 356*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_11_ta_ph);
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 358*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 359*/
} /* Line: 358*/
} /* Line: 350*/
} /* Line: 350*/
} /* Line: 350*/
} /*method end*/
public BEC_2_6_6_SystemObject bem_remove_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_lengthGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 370*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 371*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 375*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 377*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 378*/
 else /* Line: 377*/ {
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_6_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 379*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 380*/
 else /* Line: 377*/ {
bevt_10_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevp_rel.bem_isEqual_2(bevt_10_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 381*/ {
bevl_slt.bem_put_2(bevl_sl, null);
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_length = bevp_length.bem_subtract_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_12_ta_ph);
while (true)
/* Line: 385*/ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 385*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 387*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 387*/ {
bevt_17_ta_ph = bevl_n.bem_hvalGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_16_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 387*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 387*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 387*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 387*/ {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_18_ta_ph;
} /* Line: 388*/
 else /* Line: 389*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_19_ta_ph = bevl_sl.bem_subtract_1(bevt_20_ta_ph);
bevl_slt.bem_put_2(bevt_19_ta_ph, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 391*/
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_21_ta_ph);
} /* Line: 393*/
 else /* Line: 385*/ {
break;
} /* Line: 385*/
} /* Line: 385*/
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_22_ta_ph;
} /* Line: 395*/
 else /* Line: 396*/ {
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_23_ta_ph);
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 398*/ {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_25_ta_ph;
} /* Line: 399*/
} /* Line: 398*/
} /* Line: 377*/
} /* Line: 377*/
} /* Line: 377*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_9_3_ContainerSet) bem_create_0();
bevl_other = bevt_1_ta_ph.bem_new_1(bevp_modu);
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 407*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 407*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_other.bemd_1(-970031311, bevl_x);
} /* Line: 408*/
 else /* Line: 407*/ {
break;
} /* Line: 407*/
} /* Line: 407*/
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_buckets.bem_clear_0();
bevp_buckets.bem_lengthSet_1(bevp_modu);
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_keyIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_nodeIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 448*/ {
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 449*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 449*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = beva_other.bem_has_1(bevl_x);
if (bevt_3_ta_ph.bevi_bool)/* Line: 450*/ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 451*/
} /* Line: 450*/
 else /* Line: 449*/ {
break;
} /* Line: 449*/
} /* Line: 449*/
} /* Line: 449*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 460*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 460*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 461*/
 else /* Line: 460*/ {
break;
} /* Line: 460*/
} /* Line: 460*/
if (beva_other == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 463*/ {
bevt_1_ta_loop = beva_other.bem_setIteratorGet_0();
while (true)
/* Line: 464*/ {
bevt_4_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 464*/ {
bevl_x = bevt_1_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 465*/
 else /* Line: 464*/ {
break;
} /* Line: 464*/
} /* Line: 464*/
} /* Line: 464*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 478*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_other, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 479*/ {
bevt_0_ta_loop = beva_other.bemd_0(607475508);
while (true)
/* Line: 480*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(-1878575877);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 480*/ {
bevl_x = bevt_0_ta_loop.bemd_0(2053394926);
bem_put_1(bevl_x);
} /* Line: 481*/
 else /* Line: 480*/ {
break;
} /* Line: 480*/
} /* Line: 480*/
} /* Line: 480*/
 else /* Line: 479*/ {
bevt_6_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_5_ta_ph = bevt_6_ta_ph.bem_sameType_2(beva_other, bevp_baseNode);
if (bevt_5_ta_ph.bevi_bool)/* Line: 483*/ {
bevt_7_ta_ph = beva_other.bemd_0(-1342275928);
bem_put_1(bevt_7_ta_ph);
} /* Line: 484*/
 else /* Line: 485*/ {
bem_put_1(beva_other);
} /* Line: 486*/
} /* Line: 479*/
} /* Line: 479*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_bucketsGet_0() throws Throwable {
return bevp_buckets;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_bucketsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buckets = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_lengthSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {183, 183, 189, 190, 191, 192, 193, 196, 197, 203, 203, 203, 204, 204, 206, 206, 210, 210, 210, 211, 211, 213, 213, 217, 217, 221, 221, 225, 225, 229, 229, 230, 231, 231, 232, 232, 232, 233, 233, 237, 237, 242, 242, 242, 242, 243, 244, 244, 245, 245, 246, 248, 252, 252, 0, 252, 252, 252, 252, 0, 0, 253, 253, 255, 0, 255, 255, 256, 256, 256, 256, 256, 258, 258, 262, 263, 263, 264, 265, 265, 265, 266, 269, 271, 272, 274, 275, 275, 276, 276, 277, 277, 277, 279, 281, 282, 282, 283, 283, 283, 283, 284, 284, 285, 285, 286, 288, 289, 289, 291, 291, 292, 292, 293, 293, 300, 300, 301, 302, 303, 303, 304, 306, 309, 309, 314, 315, 316, 317, 317, 317, 318, 320, 321, 323, 324, 324, 325, 326, 326, 326, 326, 327, 328, 328, 329, 329, 331, 331, 332, 332, 333, 340, 341, 342, 343, 343, 343, 344, 346, 347, 349, 350, 350, 351, 351, 352, 352, 352, 352, 353, 353, 354, 354, 355, 355, 357, 357, 358, 358, 359, 359, 366, 367, 369, 370, 370, 370, 371, 373, 374, 376, 377, 377, 378, 378, 379, 379, 379, 379, 380, 380, 381, 381, 382, 383, 383, 384, 384, 385, 385, 386, 387, 387, 0, 387, 387, 387, 387, 0, 0, 388, 388, 390, 390, 390, 391, 393, 393, 395, 395, 397, 397, 398, 398, 399, 399, 406, 406, 407, 0, 407, 407, 408, 410, 417, 418, 419, 423, 423, 427, 427, 431, 431, 435, 435, 439, 439, 443, 443, 447, 448, 448, 449, 0, 449, 449, 450, 451, 455, 459, 460, 0, 460, 460, 461, 463, 463, 464, 0, 464, 464, 465, 468, 472, 473, 474, 478, 478, 479, 479, 480, 0, 480, 480, 481, 483, 483, 484, 484, 486, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 27, 28, 29, 30, 31, 39, 40, 45, 46, 47, 49, 50, 57, 58, 63, 64, 65, 67, 68, 72, 73, 77, 78, 83, 84, 96, 99, 101, 102, 107, 108, 109, 110, 112, 113, 121, 122, 133, 134, 135, 136, 137, 140, 141, 143, 144, 145, 151, 167, 172, 173, 176, 177, 178, 183, 184, 187, 191, 192, 194, 194, 197, 199, 200, 201, 206, 207, 208, 215, 216, 242, 243, 248, 249, 250, 251, 256, 257, 261, 263, 264, 267, 268, 273, 274, 279, 280, 281, 282, 285, 287, 288, 289, 292, 293, 294, 299, 300, 301, 304, 305, 307, 308, 309, 310, 313, 314, 315, 320, 321, 322, 336, 337, 339, 340, 343, 344, 346, 352, 355, 356, 378, 379, 380, 381, 382, 387, 388, 390, 391, 394, 395, 400, 401, 404, 405, 406, 411, 412, 415, 416, 418, 419, 422, 423, 424, 429, 430, 458, 459, 460, 461, 462, 467, 468, 470, 471, 474, 475, 480, 481, 482, 485, 486, 487, 492, 493, 494, 497, 498, 500, 501, 504, 505, 506, 511, 512, 513, 553, 554, 555, 556, 557, 562, 563, 565, 566, 569, 570, 575, 576, 577, 580, 581, 582, 587, 588, 589, 592, 593, 595, 596, 597, 598, 599, 602, 607, 608, 609, 614, 615, 618, 619, 620, 625, 626, 629, 633, 634, 637, 638, 639, 640, 642, 643, 649, 650, 653, 654, 655, 660, 661, 662, 675, 676, 677, 677, 680, 682, 683, 689, 692, 693, 694, 699, 700, 704, 705, 709, 710, 714, 715, 719, 720, 724, 725, 734, 735, 740, 741, 741, 744, 746, 747, 749, 757, 767, 768, 768, 771, 773, 774, 780, 785, 786, 786, 789, 791, 792, 799, 803, 804, 805, 817, 822, 823, 824, 826, 826, 829, 831, 832, 840, 841, 843, 844, 847, 854, 857, 861, 864};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 183 20
new 0 183 20
new 1 183 21
assign 1 189 25
assign 1 190 26
new 0 190 26
assign 1 191 27
new 0 191 27
assign 1 192 28
new 0 192 28
assign 1 193 29
new 0 193 29
assign 1 196 30
new 1 196 30
assign 1 197 31
new 0 197 31
assign 1 203 39
new 0 203 39
assign 1 203 40
equals 1 203 45
assign 1 204 46
new 0 204 46
return 1 204 47
assign 1 206 49
new 0 206 49
return 1 206 50
assign 1 210 57
new 0 210 57
assign 1 210 58
equals 1 210 63
assign 1 211 64
new 0 211 64
return 1 211 65
assign 1 213 67
new 0 213 67
return 1 213 68
assign 1 217 72
toString 0 217 72
return 1 217 73
assign 1 221 77
new 1 221 77
new 1 221 78
assign 1 225 83
new 1 225 83
return 1 225 84
assign 1 229 96
iteratorGet 0 229 96
assign 1 229 99
hasNextGet 0 229 99
assign 1 230 101
nextGet 0 230 101
assign 1 231 102
def 1 231 107
assign 1 232 108
keyGet 0 232 108
assign 1 232 109
innerPut 4 232 109
assign 1 232 110
not 0 232 110
assign 1 233 112
new 0 233 112
return 1 233 113
assign 1 237 121
new 0 237 121
return 1 237 122
assign 1 242 133
lengthGet 0 242 133
assign 1 242 134
multiply 1 242 134
assign 1 242 135
new 0 242 135
assign 1 242 136
add 1 242 136
assign 1 243 137
new 1 243 137
assign 1 244 140
insertAll 2 244 140
assign 1 244 141
not 0 244 141
assign 1 245 143
new 0 245 143
assign 1 245 144
add 1 245 144
assign 1 246 145
new 1 246 145
return 1 248 151
assign 1 252 167
undef 1 252 172
assign 1 0 173
assign 1 252 176
lengthGet 0 252 176
assign 1 252 177
lengthGet 0 252 177
assign 1 252 178
notEquals 1 252 183
assign 1 0 184
assign 1 0 187
assign 1 253 191
new 0 253 191
return 1 253 192
assign 1 255 194
setIteratorGet 0 0 194
assign 1 255 197
hasNextGet 0 255 197
assign 1 255 199
nextGet 0 255 199
assign 1 256 200
has 1 256 200
assign 1 256 201
not 0 256 206
assign 1 256 207
new 0 256 207
return 1 256 208
assign 1 258 215
new 0 258 215
return 1 258 216
assign 1 262 242
lengthGet 0 262 242
assign 1 263 243
undef 1 263 248
assign 1 264 249
getHash 1 264 249
assign 1 265 250
new 0 265 250
assign 1 265 251
lesser 1 265 256
assign 1 266 257
abs 0 266 257
assign 1 269 261
hvalGet 0 269 261
assign 1 271 263
modulus 1 271 263
assign 1 272 264
assign 1 274 267
get 1 274 267
assign 1 275 268
undef 1 275 273
assign 1 276 274
undef 1 276 279
assign 1 277 280
create 0 277 280
assign 1 277 281
new 3 277 281
put 2 277 282
put 2 279 285
assign 1 281 287
new 0 281 287
assign 1 282 288
new 0 282 288
return 1 282 289
assign 1 283 292
hvalGet 0 283 292
assign 1 283 293
modulus 1 283 293
assign 1 283 294
notEquals 1 283 299
assign 1 284 300
new 0 284 300
return 1 284 301
assign 1 285 304
keyGet 0 285 304
assign 1 285 305
isEqual 2 285 305
putTo 2 286 307
assign 1 288 308
new 0 288 308
assign 1 289 309
new 0 289 309
return 1 289 310
assign 1 291 313
new 0 291 313
assign 1 291 314
add 1 291 314
assign 1 292 315
greaterEquals 1 292 320
assign 1 293 321
new 0 293 321
return 1 293 322
assign 1 300 336
innerPut 4 300 336
assign 1 300 337
not 0 300 337
assign 1 301 339
assign 1 302 340
rehash 1 302 340
assign 1 303 343
innerPut 4 303 343
assign 1 303 344
not 0 303 344
assign 1 304 346
rehash 1 304 346
assign 1 306 352
assign 1 309 355
new 0 309 355
assign 1 309 356
add 1 309 356
assign 1 314 378
assign 1 315 379
lengthGet 0 315 379
assign 1 316 380
getHash 1 316 380
assign 1 317 381
new 0 317 381
assign 1 317 382
lesser 1 317 387
assign 1 318 388
abs 0 318 388
assign 1 320 390
modulus 1 320 390
assign 1 321 391
assign 1 323 394
get 1 323 394
assign 1 324 395
undef 1 324 400
return 1 325 401
assign 1 326 404
hvalGet 0 326 404
assign 1 326 405
modulus 1 326 405
assign 1 326 406
notEquals 1 326 411
return 1 327 412
assign 1 328 415
keyGet 0 328 415
assign 1 328 416
isEqual 2 328 416
assign 1 329 418
getFrom 0 329 418
return 1 329 419
assign 1 331 422
new 0 331 422
assign 1 331 423
add 1 331 423
assign 1 332 424
greaterEquals 1 332 429
return 1 333 430
assign 1 340 458
assign 1 341 459
lengthGet 0 341 459
assign 1 342 460
getHash 1 342 460
assign 1 343 461
new 0 343 461
assign 1 343 462
lesser 1 343 467
assign 1 344 468
abs 0 344 468
assign 1 346 470
modulus 1 346 470
assign 1 347 471
assign 1 349 474
get 1 349 474
assign 1 350 475
undef 1 350 480
assign 1 351 481
new 0 351 481
return 1 351 482
assign 1 352 485
hvalGet 0 352 485
assign 1 352 486
modulus 1 352 486
assign 1 352 487
notEquals 1 352 492
assign 1 353 493
new 0 353 493
return 1 353 494
assign 1 354 497
keyGet 0 354 497
assign 1 354 498
isEqual 2 354 498
assign 1 355 500
new 0 355 500
return 1 355 501
assign 1 357 504
new 0 357 504
assign 1 357 505
add 1 357 505
assign 1 358 506
greaterEquals 1 358 511
assign 1 359 512
new 0 359 512
return 1 359 513
assign 1 366 553
assign 1 367 554
lengthGet 0 367 554
assign 1 369 555
getHash 1 369 555
assign 1 370 556
new 0 370 556
assign 1 370 557
lesser 1 370 562
assign 1 371 563
abs 0 371 563
assign 1 373 565
modulus 1 373 565
assign 1 374 566
assign 1 376 569
get 1 376 569
assign 1 377 570
undef 1 377 575
assign 1 378 576
new 0 378 576
return 1 378 577
assign 1 379 580
hvalGet 0 379 580
assign 1 379 581
modulus 1 379 581
assign 1 379 582
notEquals 1 379 587
assign 1 380 588
new 0 380 588
return 1 380 589
assign 1 381 592
keyGet 0 381 592
assign 1 381 593
isEqual 2 381 593
put 2 382 595
assign 1 383 596
new 0 383 596
assign 1 383 597
subtract 1 383 597
assign 1 384 598
new 0 384 598
assign 1 384 599
add 1 384 599
assign 1 385 602
lesser 1 385 607
assign 1 386 608
get 1 386 608
assign 1 387 609
undef 1 387 614
assign 1 0 615
assign 1 387 618
hvalGet 0 387 618
assign 1 387 619
modulus 1 387 619
assign 1 387 620
notEquals 1 387 625
assign 1 0 626
assign 1 0 629
assign 1 388 633
new 0 388 633
return 1 388 634
assign 1 390 637
new 0 390 637
assign 1 390 638
subtract 1 390 638
put 2 390 639
put 2 391 640
assign 1 393 642
new 0 393 642
assign 1 393 643
add 1 393 643
assign 1 395 649
new 0 395 649
return 1 395 650
assign 1 397 653
new 0 397 653
assign 1 397 654
add 1 397 654
assign 1 398 655
greaterEquals 1 398 660
assign 1 399 661
new 0 399 661
return 1 399 662
assign 1 406 675
create 0 406 675
assign 1 406 676
new 1 406 676
assign 1 407 677
setIteratorGet 0 0 677
assign 1 407 680
hasNextGet 0 407 680
assign 1 407 682
nextGet 0 407 682
put 1 408 683
return 1 410 689
clear 0 417 692
lengthSet 1 418 693
assign 1 419 694
new 0 419 694
assign 1 423 699
new 1 423 699
return 1 423 700
assign 1 427 704
new 1 427 704
return 1 427 705
assign 1 431 709
new 1 431 709
return 1 431 710
assign 1 435 714
keyIteratorGet 0 435 714
return 1 435 715
assign 1 439 719
new 1 439 719
return 1 439 720
assign 1 443 724
nodeIteratorGet 0 443 724
return 1 443 725
assign 1 447 734
new 0 447 734
assign 1 448 735
def 1 448 740
assign 1 449 741
setIteratorGet 0 0 741
assign 1 449 744
hasNextGet 0 449 744
assign 1 449 746
nextGet 0 449 746
assign 1 450 747
has 1 450 747
put 1 451 749
return 1 455 757
assign 1 459 767
new 0 459 767
assign 1 460 768
setIteratorGet 0 0 768
assign 1 460 771
hasNextGet 0 460 771
assign 1 460 773
nextGet 0 460 773
put 1 461 774
assign 1 463 780
def 1 463 785
assign 1 464 786
setIteratorGet 0 0 786
assign 1 464 789
hasNextGet 0 464 789
assign 1 464 791
nextGet 0 464 791
put 1 465 792
return 1 468 799
assign 1 472 803
copy 0 472 803
addValue 1 473 804
return 1 474 805
assign 1 478 817
def 1 478 822
assign 1 479 823
new 0 479 823
assign 1 479 824
sameType 2 479 824
assign 1 480 826
iteratorGet 0 0 826
assign 1 480 829
hasNextGet 0 480 829
assign 1 480 831
nextGet 0 480 831
put 1 481 832
assign 1 483 840
new 0 483 840
assign 1 483 841
sameType 2 483 841
assign 1 484 843
keyGet 0 484 843
put 1 484 844
put 1 486 847
return 1 0 854
assign 1 0 857
return 1 0 861
assign 1 0 864
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 822551800: return bem_clear_0();
case -724736001: return bem_keysGet_0();
case 607475508: return bem_iteratorGet_0();
case -305461678: return bem_lengthGet_0();
case 1088288279: return bem_keyIteratorGet_0();
case 1813043009: return bem_nodeIteratorGet_0();
case 1968169851: return bem_serializeToString_0();
case -668747312: return bem_hashGet_0();
case 748992962: return bem_serializationIteratorGet_0();
case -63808123: return bem_notEmptyGet_0();
case -485814560: return bem_print_0();
case -1588096235: return bem_isEmptyGet_0();
case -394881605: return bem_bucketsGet_0();
case -1772356243: return bem_toString_0();
case -1743078764: return bem_copy_0();
case -1189610979: return bem_new_0();
case 790138640: return bem_nodesGet_0();
case -1501266936: return bem_create_0();
case 1456852737: return bem_setIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -621138407: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 995078652: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -805326223: return bem_notEquals_1(bevd_0);
case 1872569713: return bem_get_1(bevd_0);
case 642304804: return bem_print_1(bevd_0);
case -1635936879: return bem_bucketsSet_1(bevd_0);
case 2081298496: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1399470006: return bem_remove_1(bevd_0);
case -2011296803: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1820346233: return bem_addValue_1(bevd_0);
case 551470188: return bem_copyTo_1(bevd_0);
case 241865106: return bem_equals_1(bevd_0);
case -1506803036: return bem_has_1(bevd_0);
case -877440292: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 421158622: return bem_undef_1(bevd_0);
case -1609247053: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -347939855: return bem_def_1(bevd_0);
case 397082027: return bem_lengthSet_1(bevd_0);
case 873134: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -970031311: return bem_put_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1690321658: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1310310445: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1441215540: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1691003596: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1788284604: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -121966181: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
