package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_4_ContainerList bevp_buckets;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 195*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 196*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 202*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /* Line: 203*/
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_modu.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = (BEC_3_9_4_8_ContainerListIterator) beva_ir.bem_iteratorGet_0();
while (true)
/* Line: 221*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 221*/ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 223*/ {
bevt_4_ta_ph = bevl_ni.bem_keyGet_0();
bevt_3_ta_ph = bem_innerPut_4(bevt_4_ta_ph, null, bevl_ni, beva_ninner);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1116633374);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 224*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 225*/
} /* Line: 224*/
} /* Line: 223*/
 else /* Line: 221*/ {
break;
} /* Line: 221*/
} /* Line: 221*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nbuckets = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_1_ta_ph = beva_slt.bem_lengthGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(bevp_multi);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_nbuckets = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
while (true)
/* Line: 236*/ {
bevt_4_ta_ph = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-1116633374);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 236*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_nbuckets = bevl_nbuckets.bem_add_1(bevt_5_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
} /* Line: 238*/
 else /* Line: 236*/ {
break;
} /* Line: 236*/
} /* Line: 236*/
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_4_ta_ph = beva_other.bem_lengthGet_0();
bevt_5_ta_ph = bem_lengthGet_0();
if (bevt_4_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 244*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 244*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 245*/
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 247*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_7_ta_ph.bevi_bool)/* Line: 247*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_9_ta_ph = beva_other.bem_contains_1(bevl_i);
if (bevt_9_ta_ph.bevi_bool) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 248*/
} /* Line: 248*/
 else /* Line: 247*/ {
break;
} /* Line: 247*/
} /* Line: 247*/
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
bevl_modu = beva_slt.bem_lengthGet_0();
if (beva_inode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 255*/ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 257*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 258*/
} /* Line: 257*/
 else /* Line: 260*/ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(-1166875260);
} /* Line: 261*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 265*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 267*/ {
if (beva_inode == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 268*/ {
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_ta_ph);
} /* Line: 269*/
 else /* Line: 270*/ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 271*/
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 274*/
 else /* Line: 267*/ {
bevt_10_ta_ph = bevl_n.bem_hvalGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_9_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /* Line: 276*/
 else /* Line: 267*/ {
bevt_13_ta_ph = bevl_n.bem_keyGet_0();
bevt_12_ta_ph = bevp_rel.bem_isEqual_2(bevt_13_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 277*/ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /* Line: 281*/
 else /* Line: 282*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_15_ta_ph);
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 284*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_17_ta_ph;
} /* Line: 285*/
} /* Line: 284*/
} /* Line: 267*/
} /* Line: 267*/
} /* Line: 267*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevp_buckets);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1116633374);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 292*/ {
bevl_slt = bevp_buckets;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 295*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1116633374);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 295*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 296*/
 else /* Line: 295*/ {
break;
} /* Line: 295*/
} /* Line: 295*/
bevp_buckets = bevl_slt;
} /* Line: 298*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 300*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_length = bevp_length.bem_add_1(bevt_4_ta_ph);
} /* Line: 301*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_lengthGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 309*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 310*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 314*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 316*/ {
return null;
} /* Line: 317*/
 else /* Line: 316*/ {
bevt_5_ta_ph = bevl_n.bem_hvalGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_4_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 318*/ {
return null;
} /* Line: 319*/
 else /* Line: 316*/ {
bevt_7_ta_ph = bevl_n.bem_keyGet_0();
bevt_6_ta_ph = bevp_rel.bem_isEqual_2(bevt_7_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 320*/ {
bevt_8_ta_ph = bevl_n.bem_getFrom_0();
return bevt_8_ta_ph;
} /* Line: 321*/
 else /* Line: 322*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_9_ta_ph);
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 324*/ {
return null;
} /* Line: 325*/
} /* Line: 324*/
} /* Line: 316*/
} /* Line: 316*/
} /* Line: 316*/
} /*method end*/
public BEC_2_5_4_LogicBool bem_contains_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_lengthGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 335*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 336*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 340*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 343*/
 else /* Line: 342*/ {
bevt_6_ta_ph = bevl_n.bem_hvalGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_5_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 345*/
 else /* Line: 342*/ {
bevt_9_ta_ph = bevl_n.bem_keyGet_0();
bevt_8_ta_ph = bevp_rel.bem_isEqual_2(bevt_9_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 346*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 347*/
 else /* Line: 348*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_11_ta_ph);
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 351*/
} /* Line: 350*/
} /* Line: 342*/
} /* Line: 342*/
} /* Line: 342*/
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_lengthGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 362*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 363*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 367*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 369*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 370*/
 else /* Line: 369*/ {
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_6_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 372*/
 else /* Line: 369*/ {
bevt_10_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevp_rel.bem_isEqual_2(bevt_10_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 373*/ {
bevl_slt.bem_put_2(bevl_sl, null);
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_length = bevp_length.bem_subtract_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_12_ta_ph);
while (true)
/* Line: 377*/ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 377*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 379*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 379*/ {
bevt_17_ta_ph = bevl_n.bem_hvalGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_16_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 379*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 379*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 379*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 379*/ {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_18_ta_ph;
} /* Line: 380*/
 else /* Line: 381*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_19_ta_ph = bevl_sl.bem_subtract_1(bevt_20_ta_ph);
bevl_slt.bem_put_2(bevt_19_ta_ph, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 383*/
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_21_ta_ph);
} /* Line: 385*/
 else /* Line: 377*/ {
break;
} /* Line: 377*/
} /* Line: 377*/
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_22_ta_ph;
} /* Line: 387*/
 else /* Line: 388*/ {
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_sl = bevl_sl.bem_add_1(bevt_23_ta_ph);
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 390*/ {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_25_ta_ph;
} /* Line: 391*/
} /* Line: 390*/
} /* Line: 369*/
} /* Line: 369*/
} /* Line: 369*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_buckets.bem_copy_0();
bevl_other.bemd_1(435176597, bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 402*/ {
bevt_2_ta_ph = bevp_buckets.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 402*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 404*/ {
bevt_4_ta_ph = bevl_other.bemd_0(694005703);
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_8_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevl_n.bem_getFrom_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
bevt_4_ta_ph.bemd_2(207488529, bevl_i, bevt_5_ta_ph);
} /* Line: 405*/
 else /* Line: 406*/ {
bevt_10_ta_ph = bevl_other.bemd_0(694005703);
bevt_10_ta_ph.bemd_2(207488529, bevl_i, null);
} /* Line: 407*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_i = bevl_i.bem_add_1(bevt_11_ta_ph);
} /* Line: 402*/
 else /* Line: 402*/ {
break;
} /* Line: 402*/
} /* Line: 402*/
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_buckets.bem_clear_0();
bevp_buckets.bem_lengthSet_1(bevp_modu);
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_keyIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_nodeIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 448*/ {
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 449*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 449*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = beva_other.bem_contains_1(bevl_x);
if (bevt_3_ta_ph.bevi_bool)/* Line: 450*/ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 451*/
} /* Line: 450*/
 else /* Line: 449*/ {
break;
} /* Line: 449*/
} /* Line: 449*/
} /* Line: 449*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 460*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 460*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 461*/
 else /* Line: 460*/ {
break;
} /* Line: 460*/
} /* Line: 460*/
if (beva_other == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 463*/ {
bevt_1_ta_loop = beva_other.bem_setIteratorGet_0();
while (true)
/* Line: 464*/ {
bevt_4_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 464*/ {
bevl_x = bevt_1_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 465*/
 else /* Line: 464*/ {
break;
} /* Line: 464*/
} /* Line: 464*/
} /* Line: 464*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 478*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_other, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 479*/ {
bevt_0_ta_loop = beva_other.bemd_0(-1399615900);
while (true)
/* Line: 480*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(-123670595);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 480*/ {
bevl_x = bevt_0_ta_loop.bemd_0(734567808);
bem_put_1(bevl_x);
} /* Line: 481*/
 else /* Line: 480*/ {
break;
} /* Line: 480*/
} /* Line: 480*/
} /* Line: 480*/
 else /* Line: 479*/ {
bevt_6_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_5_ta_ph = bevt_6_ta_ph.bem_sameType_2(beva_other, bevp_baseNode);
if (bevt_5_ta_ph.bevi_bool)/* Line: 483*/ {
bevt_7_ta_ph = beva_other.bemd_0(-1152009370);
bem_put_1(bevt_7_ta_ph);
} /* Line: 484*/
 else /* Line: 485*/ {
bem_put_1(beva_other);
} /* Line: 486*/
} /* Line: 479*/
} /* Line: 479*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_bucketsGet_0() throws Throwable {
return bevp_buckets;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_bucketsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buckets = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_lengthSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {175, 175, 181, 182, 183, 184, 185, 188, 189, 195, 195, 195, 196, 196, 198, 198, 202, 202, 202, 203, 203, 205, 205, 209, 209, 213, 213, 217, 217, 221, 221, 222, 223, 223, 224, 224, 224, 225, 225, 229, 229, 234, 234, 234, 234, 235, 236, 236, 237, 237, 238, 240, 244, 244, 0, 244, 244, 244, 244, 0, 0, 245, 245, 247, 0, 247, 247, 248, 248, 248, 248, 248, 250, 250, 254, 255, 255, 256, 257, 257, 257, 258, 261, 263, 264, 266, 267, 267, 268, 268, 269, 269, 269, 271, 273, 274, 274, 275, 275, 275, 275, 276, 276, 277, 277, 278, 280, 281, 281, 283, 283, 284, 284, 285, 285, 292, 292, 293, 294, 295, 295, 296, 298, 301, 301, 306, 307, 308, 309, 309, 309, 310, 312, 313, 315, 316, 316, 317, 318, 318, 318, 318, 319, 320, 320, 321, 321, 323, 323, 324, 324, 325, 332, 333, 334, 335, 335, 335, 336, 338, 339, 341, 342, 342, 343, 343, 344, 344, 344, 344, 345, 345, 346, 346, 347, 347, 349, 349, 350, 350, 351, 351, 358, 359, 361, 362, 362, 362, 363, 365, 366, 368, 369, 369, 370, 370, 371, 371, 371, 371, 372, 372, 373, 373, 374, 375, 375, 376, 376, 377, 377, 378, 379, 379, 0, 379, 379, 379, 379, 0, 0, 380, 380, 382, 382, 382, 383, 385, 385, 387, 387, 389, 389, 390, 390, 391, 391, 399, 400, 401, 401, 402, 402, 402, 402, 403, 404, 404, 405, 405, 405, 405, 405, 405, 405, 407, 407, 402, 402, 410, 417, 418, 419, 423, 423, 427, 427, 431, 431, 435, 435, 439, 439, 443, 443, 447, 448, 448, 449, 0, 449, 449, 450, 451, 455, 459, 460, 0, 460, 460, 461, 463, 463, 464, 0, 464, 464, 465, 468, 472, 473, 474, 478, 478, 479, 479, 480, 0, 480, 480, 481, 483, 483, 484, 484, 486, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 27, 28, 29, 30, 31, 39, 40, 45, 46, 47, 49, 50, 57, 58, 63, 64, 65, 67, 68, 72, 73, 77, 78, 83, 84, 96, 99, 101, 102, 107, 108, 109, 110, 112, 113, 121, 122, 133, 134, 135, 136, 137, 140, 141, 143, 144, 145, 151, 167, 172, 173, 176, 177, 178, 183, 184, 187, 191, 192, 194, 194, 197, 199, 200, 201, 206, 207, 208, 215, 216, 242, 243, 248, 249, 250, 251, 256, 257, 261, 263, 264, 267, 268, 273, 274, 279, 280, 281, 282, 285, 287, 288, 289, 292, 293, 294, 299, 300, 301, 304, 305, 307, 308, 309, 310, 313, 314, 315, 320, 321, 322, 336, 337, 339, 340, 343, 344, 346, 352, 355, 356, 378, 379, 380, 381, 382, 387, 388, 390, 391, 394, 395, 400, 401, 404, 405, 406, 411, 412, 415, 416, 418, 419, 422, 423, 424, 429, 430, 458, 459, 460, 461, 462, 467, 468, 470, 471, 474, 475, 480, 481, 482, 485, 486, 487, 492, 493, 494, 497, 498, 500, 501, 504, 505, 506, 511, 512, 513, 553, 554, 555, 556, 557, 562, 563, 565, 566, 569, 570, 575, 576, 577, 580, 581, 582, 587, 588, 589, 592, 593, 595, 596, 597, 598, 599, 602, 607, 608, 609, 614, 615, 618, 619, 620, 625, 626, 629, 633, 634, 637, 638, 639, 640, 642, 643, 649, 650, 653, 654, 655, 660, 661, 662, 685, 686, 687, 688, 689, 692, 693, 698, 699, 700, 705, 706, 707, 708, 709, 710, 711, 712, 715, 716, 718, 719, 725, 728, 729, 730, 735, 736, 740, 741, 745, 746, 750, 751, 755, 756, 760, 761, 770, 771, 776, 777, 777, 780, 782, 783, 785, 793, 803, 804, 804, 807, 809, 810, 816, 821, 822, 822, 825, 827, 828, 835, 839, 840, 841, 853, 858, 859, 860, 862, 862, 865, 867, 868, 876, 877, 879, 880, 883, 890, 893, 897, 900};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 175 20
new 0 175 20
new 1 175 21
assign 1 181 25
assign 1 182 26
new 0 182 26
assign 1 183 27
new 0 183 27
assign 1 184 28
new 0 184 28
assign 1 185 29
new 0 185 29
assign 1 188 30
new 1 188 30
assign 1 189 31
new 0 189 31
assign 1 195 39
new 0 195 39
assign 1 195 40
equals 1 195 45
assign 1 196 46
new 0 196 46
return 1 196 47
assign 1 198 49
new 0 198 49
return 1 198 50
assign 1 202 57
new 0 202 57
assign 1 202 58
equals 1 202 63
assign 1 203 64
new 0 203 64
return 1 203 65
assign 1 205 67
new 0 205 67
return 1 205 68
assign 1 209 72
toString 0 209 72
return 1 209 73
assign 1 213 77
new 1 213 77
new 1 213 78
assign 1 217 83
new 1 217 83
return 1 217 84
assign 1 221 96
iteratorGet 0 221 96
assign 1 221 99
hasNextGet 0 221 99
assign 1 222 101
nextGet 0 222 101
assign 1 223 102
def 1 223 107
assign 1 224 108
keyGet 0 224 108
assign 1 224 109
innerPut 4 224 109
assign 1 224 110
not 0 224 110
assign 1 225 112
new 0 225 112
return 1 225 113
assign 1 229 121
new 0 229 121
return 1 229 122
assign 1 234 133
lengthGet 0 234 133
assign 1 234 134
multiply 1 234 134
assign 1 234 135
new 0 234 135
assign 1 234 136
add 1 234 136
assign 1 235 137
new 1 235 137
assign 1 236 140
insertAll 2 236 140
assign 1 236 141
not 0 236 141
assign 1 237 143
new 0 237 143
assign 1 237 144
add 1 237 144
assign 1 238 145
new 1 238 145
return 1 240 151
assign 1 244 167
undef 1 244 172
assign 1 0 173
assign 1 244 176
lengthGet 0 244 176
assign 1 244 177
lengthGet 0 244 177
assign 1 244 178
notEquals 1 244 183
assign 1 0 184
assign 1 0 187
assign 1 245 191
new 0 245 191
return 1 245 192
assign 1 247 194
setIteratorGet 0 0 194
assign 1 247 197
hasNextGet 0 247 197
assign 1 247 199
nextGet 0 247 199
assign 1 248 200
contains 1 248 200
assign 1 248 201
not 0 248 206
assign 1 248 207
new 0 248 207
return 1 248 208
assign 1 250 215
new 0 250 215
return 1 250 216
assign 1 254 242
lengthGet 0 254 242
assign 1 255 243
undef 1 255 248
assign 1 256 249
getHash 1 256 249
assign 1 257 250
new 0 257 250
assign 1 257 251
lesser 1 257 256
assign 1 258 257
abs 0 258 257
assign 1 261 261
hvalGet 0 261 261
assign 1 263 263
modulus 1 263 263
assign 1 264 264
assign 1 266 267
get 1 266 267
assign 1 267 268
undef 1 267 273
assign 1 268 274
undef 1 268 279
assign 1 269 280
create 0 269 280
assign 1 269 281
new 3 269 281
put 2 269 282
put 2 271 285
assign 1 273 287
new 0 273 287
assign 1 274 288
new 0 274 288
return 1 274 289
assign 1 275 292
hvalGet 0 275 292
assign 1 275 293
modulus 1 275 293
assign 1 275 294
notEquals 1 275 299
assign 1 276 300
new 0 276 300
return 1 276 301
assign 1 277 304
keyGet 0 277 304
assign 1 277 305
isEqual 2 277 305
putTo 2 278 307
assign 1 280 308
new 0 280 308
assign 1 281 309
new 0 281 309
return 1 281 310
assign 1 283 313
new 0 283 313
assign 1 283 314
add 1 283 314
assign 1 284 315
greaterEquals 1 284 320
assign 1 285 321
new 0 285 321
return 1 285 322
assign 1 292 336
innerPut 4 292 336
assign 1 292 337
not 0 292 337
assign 1 293 339
assign 1 294 340
rehash 1 294 340
assign 1 295 343
innerPut 4 295 343
assign 1 295 344
not 0 295 344
assign 1 296 346
rehash 1 296 346
assign 1 298 352
assign 1 301 355
new 0 301 355
assign 1 301 356
add 1 301 356
assign 1 306 378
assign 1 307 379
lengthGet 0 307 379
assign 1 308 380
getHash 1 308 380
assign 1 309 381
new 0 309 381
assign 1 309 382
lesser 1 309 387
assign 1 310 388
abs 0 310 388
assign 1 312 390
modulus 1 312 390
assign 1 313 391
assign 1 315 394
get 1 315 394
assign 1 316 395
undef 1 316 400
return 1 317 401
assign 1 318 404
hvalGet 0 318 404
assign 1 318 405
modulus 1 318 405
assign 1 318 406
notEquals 1 318 411
return 1 319 412
assign 1 320 415
keyGet 0 320 415
assign 1 320 416
isEqual 2 320 416
assign 1 321 418
getFrom 0 321 418
return 1 321 419
assign 1 323 422
new 0 323 422
assign 1 323 423
add 1 323 423
assign 1 324 424
greaterEquals 1 324 429
return 1 325 430
assign 1 332 458
assign 1 333 459
lengthGet 0 333 459
assign 1 334 460
getHash 1 334 460
assign 1 335 461
new 0 335 461
assign 1 335 462
lesser 1 335 467
assign 1 336 468
abs 0 336 468
assign 1 338 470
modulus 1 338 470
assign 1 339 471
assign 1 341 474
get 1 341 474
assign 1 342 475
undef 1 342 480
assign 1 343 481
new 0 343 481
return 1 343 482
assign 1 344 485
hvalGet 0 344 485
assign 1 344 486
modulus 1 344 486
assign 1 344 487
notEquals 1 344 492
assign 1 345 493
new 0 345 493
return 1 345 494
assign 1 346 497
keyGet 0 346 497
assign 1 346 498
isEqual 2 346 498
assign 1 347 500
new 0 347 500
return 1 347 501
assign 1 349 504
new 0 349 504
assign 1 349 505
add 1 349 505
assign 1 350 506
greaterEquals 1 350 511
assign 1 351 512
new 0 351 512
return 1 351 513
assign 1 358 553
assign 1 359 554
lengthGet 0 359 554
assign 1 361 555
getHash 1 361 555
assign 1 362 556
new 0 362 556
assign 1 362 557
lesser 1 362 562
assign 1 363 563
abs 0 363 563
assign 1 365 565
modulus 1 365 565
assign 1 366 566
assign 1 368 569
get 1 368 569
assign 1 369 570
undef 1 369 575
assign 1 370 576
new 0 370 576
return 1 370 577
assign 1 371 580
hvalGet 0 371 580
assign 1 371 581
modulus 1 371 581
assign 1 371 582
notEquals 1 371 587
assign 1 372 588
new 0 372 588
return 1 372 589
assign 1 373 592
keyGet 0 373 592
assign 1 373 593
isEqual 2 373 593
put 2 374 595
assign 1 375 596
new 0 375 596
assign 1 375 597
subtract 1 375 597
assign 1 376 598
new 0 376 598
assign 1 376 599
add 1 376 599
assign 1 377 602
lesser 1 377 607
assign 1 378 608
get 1 378 608
assign 1 379 609
undef 1 379 614
assign 1 0 615
assign 1 379 618
hvalGet 0 379 618
assign 1 379 619
modulus 1 379 619
assign 1 379 620
notEquals 1 379 625
assign 1 0 626
assign 1 0 629
assign 1 380 633
new 0 380 633
return 1 380 634
assign 1 382 637
new 0 382 637
assign 1 382 638
subtract 1 382 638
put 2 382 639
put 2 383 640
assign 1 385 642
new 0 385 642
assign 1 385 643
add 1 385 643
assign 1 387 649
new 0 387 649
return 1 387 650
assign 1 389 653
new 0 389 653
assign 1 389 654
add 1 389 654
assign 1 390 655
greaterEquals 1 390 660
assign 1 391 661
new 0 391 661
return 1 391 662
assign 1 399 685
create 0 399 685
copyTo 1 400 686
assign 1 401 687
copy 0 401 687
bucketsSet 1 401 688
assign 1 402 689
new 0 402 689
assign 1 402 692
lengthGet 0 402 692
assign 1 402 693
lesser 1 402 698
assign 1 403 699
get 1 403 699
assign 1 404 700
def 1 404 705
assign 1 405 706
bucketsGet 0 405 706
assign 1 405 707
create 0 405 707
assign 1 405 708
hvalGet 0 405 708
assign 1 405 709
keyGet 0 405 709
assign 1 405 710
getFrom 0 405 710
assign 1 405 711
new 3 405 711
put 2 405 712
assign 1 407 715
bucketsGet 0 407 715
put 2 407 716
assign 1 402 718
new 0 402 718
assign 1 402 719
add 1 402 719
return 1 410 725
clear 0 417 728
lengthSet 1 418 729
assign 1 419 730
new 0 419 730
assign 1 423 735
new 1 423 735
return 1 423 736
assign 1 427 740
new 1 427 740
return 1 427 741
assign 1 431 745
new 1 431 745
return 1 431 746
assign 1 435 750
keyIteratorGet 0 435 750
return 1 435 751
assign 1 439 755
new 1 439 755
return 1 439 756
assign 1 443 760
nodeIteratorGet 0 443 760
return 1 443 761
assign 1 447 770
new 0 447 770
assign 1 448 771
def 1 448 776
assign 1 449 777
setIteratorGet 0 0 777
assign 1 449 780
hasNextGet 0 449 780
assign 1 449 782
nextGet 0 449 782
assign 1 450 783
contains 1 450 783
put 1 451 785
return 1 455 793
assign 1 459 803
new 0 459 803
assign 1 460 804
setIteratorGet 0 0 804
assign 1 460 807
hasNextGet 0 460 807
assign 1 460 809
nextGet 0 460 809
put 1 461 810
assign 1 463 816
def 1 463 821
assign 1 464 822
setIteratorGet 0 0 822
assign 1 464 825
hasNextGet 0 464 825
assign 1 464 827
nextGet 0 464 827
put 1 465 828
return 1 468 835
assign 1 472 839
copy 0 472 839
addValue 1 473 840
return 1 474 841
assign 1 478 853
def 1 478 858
assign 1 479 859
new 0 479 859
assign 1 479 860
sameType 2 479 860
assign 1 480 862
iteratorGet 0 0 862
assign 1 480 865
hasNextGet 0 480 865
assign 1 480 867
nextGet 0 480 867
put 1 481 868
assign 1 483 876
new 0 483 876
assign 1 483 877
sameType 2 483 877
assign 1 484 879
keyGet 0 484 879
put 1 484 880
put 1 486 883
return 1 0 890
assign 1 0 893
return 1 0 897
assign 1 0 900
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 499674580: return bem_isEmptyGet_0();
case 1684508629: return bem_copy_0();
case -250278628: return bem_lengthGet_0();
case 189070720: return bem_new_0();
case 1870128138: return bem_toString_0();
case -859591620: return bem_serializationIteratorGet_0();
case -559059286: return bem_create_0();
case -641156019: return bem_notEmptyGet_0();
case -989573696: return bem_keysGet_0();
case 1791364133: return bem_nodesGet_0();
case -1835833846: return bem_setIteratorGet_0();
case -436887872: return bem_keyIteratorGet_0();
case -1399615900: return bem_iteratorGet_0();
case -1583834374: return bem_clear_0();
case 1991657606: return bem_hashGet_0();
case 441331165: return bem_print_0();
case 694005703: return bem_bucketsGet_0();
case 446711025: return bem_serializeToString_0();
case -483574019: return bem_nodeIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1561002764: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1375104016: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -342422765: return bem_undef_1(bevd_0);
case -907308916: return bem_print_1(bevd_0);
case -442084607: return bem_contains_1(bevd_0);
case -514952459: return bem_notEquals_1(bevd_0);
case 1849784828: return bem_addValue_1(bevd_0);
case -1146215684: return bem_def_1(bevd_0);
case 435176597: return bem_bucketsSet_1(bevd_0);
case -1172427709: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 139317253: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 963573829: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -457165313: return bem_put_1(bevd_0);
case -1258099487: return bem_delete_1(bevd_0);
case -741638175: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1216015171: return bem_get_1(bevd_0);
case 305443687: return bem_equals_1(bevd_0);
case 1394624585: return bem_lengthSet_1(bevd_0);
case -461789566: return bem_copyTo_1(bevd_0);
case 886760859: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1532908424: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -734031807: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 99764285: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1918971160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 930615652: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 927726929: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
