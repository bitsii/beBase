package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_5 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_7 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_9_3_ContainerSet_bevo_0;
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 232*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 233*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_9_3_ContainerSet_bevo_1;
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /* Line: 240*/
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_modu.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
/* Line: 258*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_4_ta_ph = bevl_ni.bem_keyGet_0();
bevt_3_ta_ph = bem_innerPut_4(bevt_4_ta_ph, null, bevl_ni, beva_ninner);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-244976954);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 261*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 262*/
} /* Line: 261*/
} /* Line: 260*/
 else /* Line: 258*/ {
break;
} /* Line: 258*/
} /* Line: 258*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = beva_slt.bem_sizeGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(bevp_multi);
bevt_2_ta_ph = bece_BEC_2_9_3_ContainerSet_bevo_2;
bevl_nslots = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
/* Line: 273*/ {
bevt_4_ta_ph = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-244976954);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 273*/ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 275*/
 else /* Line: 273*/ {
break;
} /* Line: 273*/
} /* Line: 273*/
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 281*/ {
bevt_4_ta_ph = beva_other.bem_sizeGet_0();
bevt_5_ta_ph = bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 281*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 281*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 282*/
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 284*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_7_ta_ph.bevi_bool)/* Line: 284*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_9_ta_ph = beva_other.bem_has_1(bevl_i);
if (bevt_9_ta_ph.bevi_bool) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 285*/
} /* Line: 285*/
 else /* Line: 284*/ {
break;
} /* Line: 284*/
} /* Line: 284*/
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 292*/ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = bece_BEC_2_9_3_ContainerSet_bevo_3;
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 294*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 295*/
} /* Line: 294*/
 else /* Line: 297*/ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(1202248406);
} /* Line: 298*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 302*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 304*/ {
if (beva_inode == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_ta_ph);
} /* Line: 306*/
 else /* Line: 307*/ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 308*/
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 311*/
 else /* Line: 304*/ {
bevt_10_ta_ph = bevl_n.bem_hvalGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_9_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 312*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /* Line: 313*/
 else /* Line: 304*/ {
bevt_13_ta_ph = bevl_n.bem_keyGet_0();
bevt_12_ta_ph = bevp_rel.bem_isEqual_2(bevt_13_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 314*/ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /* Line: 318*/
 else /* Line: 319*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 321*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 322*/
} /* Line: 321*/
} /* Line: 304*/
} /* Line: 304*/
} /* Line: 304*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-244976954);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 329*/ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 332*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-244976954);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 332*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 333*/
 else /* Line: 332*/ {
break;
} /* Line: 332*/
} /* Line: 332*/
bevp_slots = bevl_slt;
} /* Line: 335*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 337*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 338*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = bece_BEC_2_9_3_ContainerSet_bevo_4;
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 346*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 347*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 351*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 353*/ {
return null;
} /* Line: 354*/
 else /* Line: 353*/ {
bevt_5_ta_ph = bevl_n.bem_hvalGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_4_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 355*/ {
return null;
} /* Line: 356*/
 else /* Line: 353*/ {
bevt_7_ta_ph = bevl_n.bem_keyGet_0();
bevt_6_ta_ph = bevp_rel.bem_isEqual_2(bevt_7_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 357*/ {
bevt_8_ta_ph = bevl_n.bem_getFrom_0();
return bevt_8_ta_ph;
} /* Line: 358*/
 else /* Line: 359*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 361*/ {
return null;
} /* Line: 362*/
} /* Line: 361*/
} /* Line: 353*/
} /* Line: 353*/
} /* Line: 353*/
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = bece_BEC_2_9_3_ContainerSet_bevo_5;
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 372*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 373*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 377*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 379*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 380*/
 else /* Line: 379*/ {
bevt_6_ta_ph = bevl_n.bem_hvalGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_5_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 381*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 382*/
 else /* Line: 379*/ {
bevt_9_ta_ph = bevl_n.bem_keyGet_0();
bevt_8_ta_ph = bevp_rel.bem_isEqual_2(bevt_9_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 383*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 384*/
 else /* Line: 385*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 387*/ {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /* Line: 388*/
} /* Line: 387*/
} /* Line: 379*/
} /* Line: 379*/
} /* Line: 379*/
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = bece_BEC_2_9_3_ContainerSet_bevo_6;
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 399*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 400*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 404*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 406*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 407*/
 else /* Line: 406*/ {
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_6_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 408*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 409*/
 else /* Line: 406*/ {
bevt_10_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevp_rel.bem_isEqual_2(bevt_10_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 410*/ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
/* Line: 414*/ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 414*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 416*/ {
bevt_15_ta_ph = bevl_n.bem_hvalGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_14_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 416*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 416*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_16_ta_ph;
} /* Line: 417*/
 else /* Line: 418*/ {
bevt_18_ta_ph = bece_BEC_2_9_3_ContainerSet_bevo_7;
bevt_17_ta_ph = bevl_sl.bem_subtract_1(bevt_18_ta_ph);
bevl_slt.bem_put_2(bevt_17_ta_ph, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 420*/
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 422*/
 else /* Line: 414*/ {
break;
} /* Line: 414*/
} /* Line: 414*/
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_19_ta_ph;
} /* Line: 424*/
 else /* Line: 425*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 427*/ {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_21_ta_ph;
} /* Line: 428*/
} /* Line: 427*/
} /* Line: 406*/
} /* Line: 406*/
} /* Line: 406*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_slots.bem_copy_0();
bevl_other.bemd_1(-721534798, bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 438*/ {
bevt_2_ta_ph = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 438*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_4_ta_ph = bevl_other.bemd_0(-1858410285);
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_8_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevl_n.bem_getFrom_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
bevt_4_ta_ph.bemd_2(-436671793, bevl_i, bevt_5_ta_ph);
} /* Line: 441*/
 else /* Line: 442*/ {
bevt_10_ta_ph = bevl_other.bemd_0(-1858410285);
bevt_10_ta_ph.bemd_2(-436671793, bevl_i, null);
} /* Line: 443*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 438*/
 else /* Line: 438*/ {
break;
} /* Line: 438*/
} /* Line: 438*/
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_slots.bem_sizeSet_1(bevp_modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_keyIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_nodeIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 482*/ {
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 483*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 483*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = beva_other.bem_has_1(bevl_x);
if (bevt_3_ta_ph.bevi_bool)/* Line: 484*/ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 485*/
} /* Line: 484*/
 else /* Line: 483*/ {
break;
} /* Line: 483*/
} /* Line: 483*/
} /* Line: 483*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 494*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 494*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 495*/
 else /* Line: 494*/ {
break;
} /* Line: 494*/
} /* Line: 494*/
if (beva_other == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 497*/ {
bevt_1_ta_loop = beva_other.bem_setIteratorGet_0();
while (true)
/* Line: 498*/ {
bevt_4_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 498*/ {
bevl_x = bevt_1_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 499*/
 else /* Line: 498*/ {
break;
} /* Line: 498*/
} /* Line: 498*/
} /* Line: 498*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 512*/ {
bevt_2_ta_ph = beva_other.bemd_1(1321313051, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 513*/ {
bevt_0_ta_loop = beva_other.bemd_0(-1331626162);
while (true)
/* Line: 514*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(1590161492);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 514*/ {
bevl_x = bevt_0_ta_loop.bemd_0(-920607504);
bem_put_1(bevl_x);
} /* Line: 515*/
 else /* Line: 514*/ {
break;
} /* Line: 514*/
} /* Line: 514*/
} /* Line: 514*/
 else /* Line: 513*/ {
bevt_4_ta_ph = beva_other.bemd_1(1321313051, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 517*/ {
bevt_5_ta_ph = beva_other.bemd_0(-1950179209);
bem_put_1(bevt_5_ta_ph);
} /* Line: 518*/
 else /* Line: 519*/ {
bem_put_1(beva_other);
} /* Line: 520*/
} /* Line: 513*/
} /* Line: 513*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_slotsGetDirect_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public final BEC_2_4_3_MathInt bem_moduGetDirect_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public final BEC_2_4_3_MathInt bem_multiGetDirect_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_multiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public final BEC_3_9_3_9_ContainerSetRelations bem_relGetDirect_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_relSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public final BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGetDirect_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_baseNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_innerPutAddedGetDirect_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_innerPutAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {214, 214, 220, 221, 222, 223, 224, 225, 226, 232, 232, 232, 233, 233, 235, 235, 239, 239, 239, 240, 240, 242, 242, 246, 246, 250, 250, 254, 254, 258, 258, 259, 260, 260, 261, 261, 261, 262, 262, 266, 266, 271, 271, 271, 271, 272, 273, 273, 274, 275, 277, 281, 281, 0, 281, 281, 281, 281, 0, 0, 282, 282, 284, 0, 284, 284, 285, 285, 285, 285, 285, 287, 287, 291, 292, 292, 293, 294, 294, 294, 295, 298, 300, 301, 303, 304, 304, 305, 305, 306, 306, 306, 308, 310, 311, 311, 312, 312, 312, 312, 313, 313, 314, 314, 315, 317, 318, 318, 320, 321, 321, 322, 322, 329, 329, 330, 331, 332, 332, 333, 335, 338, 343, 344, 345, 346, 346, 346, 347, 349, 350, 352, 353, 353, 354, 355, 355, 355, 355, 356, 357, 357, 358, 358, 360, 361, 361, 362, 369, 370, 371, 372, 372, 372, 373, 375, 376, 378, 379, 379, 380, 380, 381, 381, 381, 381, 382, 382, 383, 383, 384, 384, 386, 387, 387, 388, 388, 395, 396, 398, 399, 399, 399, 400, 402, 403, 405, 406, 406, 407, 407, 408, 408, 408, 408, 409, 409, 410, 410, 411, 412, 413, 414, 414, 415, 416, 416, 0, 416, 416, 416, 416, 0, 0, 417, 417, 419, 419, 419, 420, 422, 424, 424, 426, 427, 427, 428, 428, 435, 436, 437, 437, 438, 438, 438, 438, 439, 440, 440, 441, 441, 441, 441, 441, 441, 441, 443, 443, 438, 446, 451, 452, 453, 457, 457, 461, 461, 465, 465, 469, 469, 473, 473, 477, 477, 481, 482, 482, 483, 0, 483, 483, 484, 485, 489, 493, 494, 0, 494, 494, 495, 497, 497, 498, 0, 498, 498, 499, 502, 506, 507, 508, 512, 512, 513, 514, 0, 514, 514, 515, 517, 518, 518, 520, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {28, 29, 33, 34, 35, 36, 37, 38, 39, 47, 48, 53, 54, 55, 57, 58, 65, 66, 71, 72, 73, 75, 76, 80, 81, 85, 86, 91, 92, 104, 107, 109, 110, 115, 116, 117, 118, 120, 121, 129, 130, 140, 141, 142, 143, 144, 147, 148, 150, 151, 157, 173, 178, 179, 182, 183, 184, 189, 190, 193, 197, 198, 200, 200, 203, 205, 206, 207, 212, 213, 214, 221, 222, 247, 248, 253, 254, 255, 256, 261, 262, 266, 268, 269, 272, 273, 278, 279, 284, 285, 286, 287, 290, 292, 293, 294, 297, 298, 299, 304, 305, 306, 309, 310, 312, 313, 314, 315, 318, 319, 324, 325, 326, 339, 340, 342, 343, 346, 347, 349, 355, 358, 379, 380, 381, 382, 383, 388, 389, 391, 392, 395, 396, 401, 402, 405, 406, 407, 412, 413, 416, 417, 419, 420, 423, 424, 429, 430, 457, 458, 459, 460, 461, 466, 467, 469, 470, 473, 474, 479, 480, 481, 484, 485, 486, 491, 492, 493, 496, 497, 499, 500, 503, 504, 509, 510, 511, 547, 548, 549, 550, 551, 556, 557, 559, 560, 563, 564, 569, 570, 571, 574, 575, 576, 581, 582, 583, 586, 587, 589, 590, 591, 594, 599, 600, 601, 606, 607, 610, 611, 612, 617, 618, 621, 625, 626, 629, 630, 631, 632, 634, 640, 641, 644, 645, 650, 651, 652, 674, 675, 676, 677, 678, 681, 682, 687, 688, 689, 694, 695, 696, 697, 698, 699, 700, 701, 704, 705, 707, 713, 716, 717, 718, 723, 724, 728, 729, 733, 734, 738, 739, 743, 744, 748, 749, 758, 759, 764, 765, 765, 768, 770, 771, 773, 781, 791, 792, 792, 795, 797, 798, 804, 809, 810, 810, 813, 815, 816, 823, 827, 828, 829, 839, 844, 845, 847, 847, 850, 852, 853, 861, 863, 864, 867, 874, 877, 880, 884, 888, 891, 894, 898, 902, 905, 908, 912, 916, 919, 922, 926, 930, 933, 936, 940, 944, 947, 950, 954, 958, 961, 964, 968};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 214 28
new 0 214 28
new 1 214 29
assign 1 220 33
new 1 220 33
assign 1 221 34
assign 1 222 35
new 0 222 35
assign 1 223 36
new 0 223 36
assign 1 224 37
new 0 224 37
assign 1 225 38
new 0 225 38
assign 1 226 39
new 0 226 39
assign 1 232 47
new 0 232 47
assign 1 232 48
equals 1 232 53
assign 1 233 54
new 0 233 54
return 1 233 55
assign 1 235 57
new 0 235 57
return 1 235 58
assign 1 239 65
new 0 239 65
assign 1 239 66
equals 1 239 71
assign 1 240 72
new 0 240 72
return 1 240 73
assign 1 242 75
new 0 242 75
return 1 242 76
assign 1 246 80
toString 0 246 80
return 1 246 81
assign 1 250 85
new 1 250 85
new 1 250 86
assign 1 254 91
new 1 254 91
return 1 254 92
assign 1 258 104
arrayIteratorGet 0 258 104
assign 1 258 107
hasNextGet 0 258 107
assign 1 259 109
nextGet 0 259 109
assign 1 260 110
def 1 260 115
assign 1 261 116
keyGet 0 261 116
assign 1 261 117
innerPut 4 261 117
assign 1 261 118
not 0 261 118
assign 1 262 120
new 0 262 120
return 1 262 121
assign 1 266 129
new 0 266 129
return 1 266 130
assign 1 271 140
sizeGet 0 271 140
assign 1 271 141
multiply 1 271 141
assign 1 271 142
new 0 271 142
assign 1 271 143
add 1 271 143
assign 1 272 144
new 1 272 144
assign 1 273 147
insertAll 2 273 147
assign 1 273 148
not 0 273 148
assign 1 274 150
increment 0 274 150
assign 1 275 151
new 1 275 151
return 1 277 157
assign 1 281 173
undef 1 281 178
assign 1 0 179
assign 1 281 182
sizeGet 0 281 182
assign 1 281 183
sizeGet 0 281 183
assign 1 281 184
notEquals 1 281 189
assign 1 0 190
assign 1 0 193
assign 1 282 197
new 0 282 197
return 1 282 198
assign 1 284 200
setIteratorGet 0 0 200
assign 1 284 203
hasNextGet 0 284 203
assign 1 284 205
nextGet 0 284 205
assign 1 285 206
has 1 285 206
assign 1 285 207
not 0 285 212
assign 1 285 213
new 0 285 213
return 1 285 214
assign 1 287 221
new 0 287 221
return 1 287 222
assign 1 291 247
sizeGet 0 291 247
assign 1 292 248
undef 1 292 253
assign 1 293 254
getHash 1 293 254
assign 1 294 255
new 0 294 255
assign 1 294 256
lesser 1 294 261
assign 1 295 262
abs 0 295 262
assign 1 298 266
hvalGet 0 298 266
assign 1 300 268
modulus 1 300 268
assign 1 301 269
assign 1 303 272
get 1 303 272
assign 1 304 273
undef 1 304 278
assign 1 305 279
undef 1 305 284
assign 1 306 285
create 0 306 285
assign 1 306 286
new 3 306 286
put 2 306 287
put 2 308 290
assign 1 310 292
new 0 310 292
assign 1 311 293
new 0 311 293
return 1 311 294
assign 1 312 297
hvalGet 0 312 297
assign 1 312 298
modulus 1 312 298
assign 1 312 299
notEquals 1 312 304
assign 1 313 305
new 0 313 305
return 1 313 306
assign 1 314 309
keyGet 0 314 309
assign 1 314 310
isEqual 2 314 310
putTo 2 315 312
assign 1 317 313
new 0 317 313
assign 1 318 314
new 0 318 314
return 1 318 315
assign 1 320 318
increment 0 320 318
assign 1 321 319
greaterEquals 1 321 324
assign 1 322 325
new 0 322 325
return 1 322 326
assign 1 329 339
innerPut 4 329 339
assign 1 329 340
not 0 329 340
assign 1 330 342
assign 1 331 343
rehash 1 331 343
assign 1 332 346
innerPut 4 332 346
assign 1 332 347
not 0 332 347
assign 1 333 349
rehash 1 333 349
assign 1 335 355
assign 1 338 358
increment 0 338 358
assign 1 343 379
assign 1 344 380
sizeGet 0 344 380
assign 1 345 381
getHash 1 345 381
assign 1 346 382
new 0 346 382
assign 1 346 383
lesser 1 346 388
assign 1 347 389
abs 0 347 389
assign 1 349 391
modulus 1 349 391
assign 1 350 392
assign 1 352 395
get 1 352 395
assign 1 353 396
undef 1 353 401
return 1 354 402
assign 1 355 405
hvalGet 0 355 405
assign 1 355 406
modulus 1 355 406
assign 1 355 407
notEquals 1 355 412
return 1 356 413
assign 1 357 416
keyGet 0 357 416
assign 1 357 417
isEqual 2 357 417
assign 1 358 419
getFrom 0 358 419
return 1 358 420
assign 1 360 423
increment 0 360 423
assign 1 361 424
greaterEquals 1 361 429
return 1 362 430
assign 1 369 457
assign 1 370 458
sizeGet 0 370 458
assign 1 371 459
getHash 1 371 459
assign 1 372 460
new 0 372 460
assign 1 372 461
lesser 1 372 466
assign 1 373 467
abs 0 373 467
assign 1 375 469
modulus 1 375 469
assign 1 376 470
assign 1 378 473
get 1 378 473
assign 1 379 474
undef 1 379 479
assign 1 380 480
new 0 380 480
return 1 380 481
assign 1 381 484
hvalGet 0 381 484
assign 1 381 485
modulus 1 381 485
assign 1 381 486
notEquals 1 381 491
assign 1 382 492
new 0 382 492
return 1 382 493
assign 1 383 496
keyGet 0 383 496
assign 1 383 497
isEqual 2 383 497
assign 1 384 499
new 0 384 499
return 1 384 500
assign 1 386 503
increment 0 386 503
assign 1 387 504
greaterEquals 1 387 509
assign 1 388 510
new 0 388 510
return 1 388 511
assign 1 395 547
assign 1 396 548
sizeGet 0 396 548
assign 1 398 549
getHash 1 398 549
assign 1 399 550
new 0 399 550
assign 1 399 551
lesser 1 399 556
assign 1 400 557
abs 0 400 557
assign 1 402 559
modulus 1 402 559
assign 1 403 560
assign 1 405 563
get 1 405 563
assign 1 406 564
undef 1 406 569
assign 1 407 570
new 0 407 570
return 1 407 571
assign 1 408 574
hvalGet 0 408 574
assign 1 408 575
modulus 1 408 575
assign 1 408 576
notEquals 1 408 581
assign 1 409 582
new 0 409 582
return 1 409 583
assign 1 410 586
keyGet 0 410 586
assign 1 410 587
isEqual 2 410 587
put 2 411 589
assign 1 412 590
decrement 0 412 590
assign 1 413 591
increment 0 413 591
assign 1 414 594
lesser 1 414 599
assign 1 415 600
get 1 415 600
assign 1 416 601
undef 1 416 606
assign 1 0 607
assign 1 416 610
hvalGet 0 416 610
assign 1 416 611
modulus 1 416 611
assign 1 416 612
notEquals 1 416 617
assign 1 0 618
assign 1 0 621
assign 1 417 625
new 0 417 625
return 1 417 626
assign 1 419 629
new 0 419 629
assign 1 419 630
subtract 1 419 630
put 2 419 631
put 2 420 632
assign 1 422 634
increment 0 422 634
assign 1 424 640
new 0 424 640
return 1 424 641
assign 1 426 644
increment 0 426 644
assign 1 427 645
greaterEquals 1 427 650
assign 1 428 651
new 0 428 651
return 1 428 652
assign 1 435 674
create 0 435 674
copyTo 1 436 675
assign 1 437 676
copy 0 437 676
slotsSet 1 437 677
assign 1 438 678
new 0 438 678
assign 1 438 681
lengthGet 0 438 681
assign 1 438 682
lesser 1 438 687
assign 1 439 688
get 1 439 688
assign 1 440 689
def 1 440 694
assign 1 441 695
slotsGet 0 441 695
assign 1 441 696
create 0 441 696
assign 1 441 697
hvalGet 0 441 697
assign 1 441 698
keyGet 0 441 698
assign 1 441 699
getFrom 0 441 699
assign 1 441 700
new 3 441 700
put 2 441 701
assign 1 443 704
slotsGet 0 443 704
put 2 443 705
assign 1 438 707
increment 0 438 707
return 1 446 713
clear 0 451 716
sizeSet 1 452 717
assign 1 453 718
new 0 453 718
assign 1 457 723
new 1 457 723
return 1 457 724
assign 1 461 728
new 1 461 728
return 1 461 729
assign 1 465 733
new 1 465 733
return 1 465 734
assign 1 469 738
keyIteratorGet 0 469 738
return 1 469 739
assign 1 473 743
new 1 473 743
return 1 473 744
assign 1 477 748
nodeIteratorGet 0 477 748
return 1 477 749
assign 1 481 758
new 0 481 758
assign 1 482 759
def 1 482 764
assign 1 483 765
setIteratorGet 0 0 765
assign 1 483 768
hasNextGet 0 483 768
assign 1 483 770
nextGet 0 483 770
assign 1 484 771
has 1 484 771
put 1 485 773
return 1 489 781
assign 1 493 791
new 0 493 791
assign 1 494 792
setIteratorGet 0 0 792
assign 1 494 795
hasNextGet 0 494 795
assign 1 494 797
nextGet 0 494 797
put 1 495 798
assign 1 497 804
def 1 497 809
assign 1 498 810
setIteratorGet 0 0 810
assign 1 498 813
hasNextGet 0 498 813
assign 1 498 815
nextGet 0 498 815
put 1 499 816
return 1 502 823
assign 1 506 827
copy 0 506 827
addValue 1 507 828
return 1 508 829
assign 1 512 839
def 1 512 844
assign 1 513 845
sameType 1 513 845
assign 1 514 847
iteratorGet 0 0 847
assign 1 514 850
hasNextGet 0 514 850
assign 1 514 852
nextGet 0 514 852
put 1 515 853
assign 1 517 861
sameType 1 517 861
assign 1 518 863
keyGet 0 518 863
put 1 518 864
put 1 520 867
return 1 0 874
return 1 0 877
assign 1 0 880
assign 1 0 884
return 1 0 888
return 1 0 891
assign 1 0 894
assign 1 0 898
return 1 0 902
return 1 0 905
assign 1 0 908
assign 1 0 912
return 1 0 916
return 1 0 919
assign 1 0 922
assign 1 0 926
return 1 0 930
return 1 0 933
assign 1 0 936
assign 1 0 940
return 1 0 944
return 1 0 947
assign 1 0 950
assign 1 0 954
return 1 0 958
return 1 0 961
assign 1 0 964
assign 1 0 968
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 137910263: return bem_create_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 1509673790: return bem_baseNodeGet_0();
case -438289515: return bem_fieldIteratorGet_0();
case -363608728: return bem_innerPutAddedGetDirect_0();
case -1714583788: return bem_classNameGet_0();
case 795486446: return bem_setIteratorGet_0();
case -1597419130: return bem_keyIteratorGet_0();
case -1858410285: return bem_slotsGet_0();
case -1068830530: return bem_clear_0();
case -1352231766: return bem_multiGet_0();
case -1238524057: return bem_print_0();
case -128143113: return bem_sizeGet_0();
case 1681476981: return bem_moduGet_0();
case -1079456517: return bem_many_0();
case 1173173568: return bem_sizeGetDirect_0();
case -1840332766: return bem_moduGetDirect_0();
case 2128429591: return bem_isEmptyGet_0();
case -1320550083: return bem_notEmptyGet_0();
case -1868892722: return bem_multiGetDirect_0();
case 78412540: return bem_toAny_0();
case 217381802: return bem_serializationIteratorGet_0();
case 594247679: return bem_relGet_0();
case -1233462827: return bem_slotsGetDirect_0();
case 2031134632: return bem_baseNodeGetDirect_0();
case -1426056679: return bem_hashGet_0();
case 205150354: return bem_new_0();
case -1861979274: return bem_keysGet_0();
case -1331626162: return bem_iteratorGet_0();
case -1558757422: return bem_innerPutAddedGet_0();
case 310047227: return bem_fieldNamesGet_0();
case -1681881609: return bem_relGetDirect_0();
case -777537417: return bem_serializeContents_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -826120598: return bem_nodesGet_0();
case 221458969: return bem_serializeToString_0();
case -1392846471: return bem_toString_0();
case -1851472893: return bem_once_0();
case 664735157: return bem_nodeIteratorGet_0();
case 814015164: return bem_copy_0();
case 993286746: return bem_echo_0();
case -992634121: return bem_tagGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1532589482: return bem_sizeSet_1(bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 1833872660: return bem_relSetDirect_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case -1363735306: return bem_innerPutAddedSet_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case 457551069: return bem_multiSetDirect_1(bevd_0);
case -202882393: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -281877258: return bem_addValue_1(bevd_0);
case -2138130543: return bem_multiSet_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -268710771: return bem_baseNodeSetDirect_1(bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case -78330890: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -271728426: return bem_get_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case -1742042817: return bem_has_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case -462650082: return bem_moduSetDirect_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 1036258198: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 78930112: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case -1376135535: return bem_baseNodeSet_1(bevd_0);
case -1158092207: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -690010496: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1775185276: return bem_sizeSetDirect_1(bevd_0);
case 351809565: return bem_moduSet_1(bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case -401695690: return bem_relSet_1(bevd_0);
case -1596902712: return bem_slotsSetDirect_1(bevd_0);
case -128747274: return bem_delete_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1408836221: return bem_innerPutAddedSetDirect_1(bevd_0);
case -751734469: return bem_put_1(bevd_0);
case -721534798: return bem_slotsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1021198555: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -361142314: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
