package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_4_ContainerList bevp_buckets;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 189*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 190*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 196*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /* Line: 197*/
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_modu.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
/* Line: 215*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 215*/ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_4_ta_ph = bevl_ni.bem_keyGet_0();
bevt_3_ta_ph = bem_innerPut_4(bevt_4_ta_ph, null, bevl_ni, beva_ninner);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1200750884);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 218*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 219*/
} /* Line: 218*/
} /* Line: 217*/
 else /* Line: 215*/ {
break;
} /* Line: 215*/
} /* Line: 215*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nbuckets = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = beva_slt.bem_sizeGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(bevp_multi);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_nbuckets = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
while (true)
/* Line: 230*/ {
bevt_4_ta_ph = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-1200750884);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 230*/ {
bevl_nbuckets = bevl_nbuckets.bem_increment_0();
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
} /* Line: 232*/
 else /* Line: 230*/ {
break;
} /* Line: 230*/
} /* Line: 230*/
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 238*/ {
bevt_4_ta_ph = beva_other.bem_sizeGet_0();
bevt_5_ta_ph = bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 238*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 238*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 238*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 239*/
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 241*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_7_ta_ph.bevi_bool)/* Line: 241*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_9_ta_ph = beva_other.bem_has_1(bevl_i);
if (bevt_9_ta_ph.bevi_bool) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 242*/
} /* Line: 242*/
 else /* Line: 241*/ {
break;
} /* Line: 241*/
} /* Line: 241*/
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 249*/ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 251*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 252*/
} /* Line: 251*/
 else /* Line: 254*/ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(1392718019);
} /* Line: 255*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 259*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 261*/ {
if (beva_inode == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 262*/ {
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_ta_ph);
} /* Line: 263*/
 else /* Line: 264*/ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 265*/
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 268*/
 else /* Line: 261*/ {
bevt_10_ta_ph = bevl_n.bem_hvalGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_9_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /* Line: 270*/
 else /* Line: 261*/ {
bevt_13_ta_ph = bevl_n.bem_keyGet_0();
bevt_12_ta_ph = bevp_rel.bem_isEqual_2(bevt_13_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 271*/ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /* Line: 275*/
 else /* Line: 276*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 278*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 279*/
} /* Line: 278*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevp_buckets);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1200750884);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 286*/ {
bevl_slt = bevp_buckets;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 289*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1200750884);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 289*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 290*/
 else /* Line: 289*/ {
break;
} /* Line: 289*/
} /* Line: 289*/
bevp_buckets = bevl_slt;
} /* Line: 292*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 294*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 295*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 303*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 304*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 308*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 310*/ {
return null;
} /* Line: 311*/
 else /* Line: 310*/ {
bevt_5_ta_ph = bevl_n.bem_hvalGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_4_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 312*/ {
return null;
} /* Line: 313*/
 else /* Line: 310*/ {
bevt_7_ta_ph = bevl_n.bem_keyGet_0();
bevt_6_ta_ph = bevp_rel.bem_isEqual_2(bevt_7_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 314*/ {
bevt_8_ta_ph = bevl_n.bem_getFrom_0();
return bevt_8_ta_ph;
} /* Line: 315*/
 else /* Line: 316*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 318*/ {
return null;
} /* Line: 319*/
} /* Line: 318*/
} /* Line: 310*/
} /* Line: 310*/
} /* Line: 310*/
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 329*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 330*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 334*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 337*/
 else /* Line: 336*/ {
bevt_6_ta_ph = bevl_n.bem_hvalGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_5_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 338*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 339*/
 else /* Line: 336*/ {
bevt_9_ta_ph = bevl_n.bem_keyGet_0();
bevt_8_ta_ph = bevp_rel.bem_isEqual_2(bevt_9_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 340*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 341*/
 else /* Line: 342*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /* Line: 345*/
} /* Line: 344*/
} /* Line: 336*/
} /* Line: 336*/
} /* Line: 336*/
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 356*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 357*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 361*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 363*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 364*/
 else /* Line: 363*/ {
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_6_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 365*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 366*/
 else /* Line: 363*/ {
bevt_10_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevp_rel.bem_isEqual_2(bevt_10_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 367*/ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
/* Line: 371*/ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 371*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 373*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 373*/ {
bevt_15_ta_ph = bevl_n.bem_hvalGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_14_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 373*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 373*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 373*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 373*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_16_ta_ph;
} /* Line: 374*/
 else /* Line: 375*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_17_ta_ph = bevl_sl.bem_subtract_1(bevt_18_ta_ph);
bevl_slt.bem_put_2(bevt_17_ta_ph, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 377*/
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 379*/
 else /* Line: 371*/ {
break;
} /* Line: 371*/
} /* Line: 371*/
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_19_ta_ph;
} /* Line: 381*/
 else /* Line: 382*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 384*/ {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_21_ta_ph;
} /* Line: 385*/
} /* Line: 384*/
} /* Line: 363*/
} /* Line: 363*/
} /* Line: 363*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_buckets.bem_copy_0();
bevl_other.bemd_1(-935646021, bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 396*/ {
bevt_2_ta_ph = bevp_buckets.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 396*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 398*/ {
bevt_4_ta_ph = bevl_other.bemd_0(1590877755);
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_8_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevl_n.bem_getFrom_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
bevt_4_ta_ph.bemd_2(68260516, bevl_i, bevt_5_ta_ph);
} /* Line: 399*/
 else /* Line: 400*/ {
bevt_10_ta_ph = bevl_other.bemd_0(1590877755);
bevt_10_ta_ph.bemd_2(68260516, bevl_i, null);
} /* Line: 401*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 396*/
 else /* Line: 396*/ {
break;
} /* Line: 396*/
} /* Line: 396*/
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_buckets.bem_clear_0();
bevp_buckets.bem_sizeSet_1(bevp_modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_keyIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_nodeIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 441*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 441*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = beva_other.bem_has_1(bevl_x);
if (bevt_3_ta_ph.bevi_bool)/* Line: 442*/ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 443*/
} /* Line: 442*/
 else /* Line: 441*/ {
break;
} /* Line: 441*/
} /* Line: 441*/
} /* Line: 441*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 452*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 452*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 453*/
 else /* Line: 452*/ {
break;
} /* Line: 452*/
} /* Line: 452*/
if (beva_other == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 455*/ {
bevt_1_ta_loop = beva_other.bem_setIteratorGet_0();
while (true)
/* Line: 456*/ {
bevt_4_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 456*/ {
bevl_x = bevt_1_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 457*/
 else /* Line: 456*/ {
break;
} /* Line: 456*/
} /* Line: 456*/
} /* Line: 456*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 470*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_other, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 471*/ {
bevt_0_ta_loop = beva_other.bemd_0(1319233284);
while (true)
/* Line: 472*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(-156903720);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 472*/ {
bevl_x = bevt_0_ta_loop.bemd_0(-714905669);
bem_put_1(bevl_x);
} /* Line: 473*/
 else /* Line: 472*/ {
break;
} /* Line: 472*/
} /* Line: 472*/
} /* Line: 472*/
 else /* Line: 471*/ {
bevt_6_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_5_ta_ph = bevt_6_ta_ph.bem_sameType_2(beva_other, bevp_baseNode);
if (bevt_5_ta_ph.bevi_bool)/* Line: 475*/ {
bevt_7_ta_ph = beva_other.bemd_0(1795385275);
bem_put_1(bevt_7_ta_ph);
} /* Line: 476*/
 else /* Line: 477*/ {
bem_put_1(beva_other);
} /* Line: 478*/
} /* Line: 471*/
} /* Line: 471*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_bucketsGet_0() throws Throwable {
return bevp_buckets;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_bucketsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buckets = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {169, 169, 175, 176, 177, 178, 179, 182, 183, 189, 189, 189, 190, 190, 192, 192, 196, 196, 196, 197, 197, 199, 199, 203, 203, 207, 207, 211, 211, 215, 215, 216, 217, 217, 218, 218, 218, 219, 219, 223, 223, 228, 228, 228, 228, 229, 230, 230, 231, 232, 234, 238, 238, 0, 238, 238, 238, 238, 0, 0, 239, 239, 241, 0, 241, 241, 242, 242, 242, 242, 242, 244, 244, 248, 249, 249, 250, 251, 251, 251, 252, 255, 257, 258, 260, 261, 261, 262, 262, 263, 263, 263, 265, 267, 268, 268, 269, 269, 269, 269, 270, 270, 271, 271, 272, 274, 275, 275, 277, 278, 278, 279, 279, 286, 286, 287, 288, 289, 289, 290, 292, 295, 300, 301, 302, 303, 303, 303, 304, 306, 307, 309, 310, 310, 311, 312, 312, 312, 312, 313, 314, 314, 315, 315, 317, 318, 318, 319, 326, 327, 328, 329, 329, 329, 330, 332, 333, 335, 336, 336, 337, 337, 338, 338, 338, 338, 339, 339, 340, 340, 341, 341, 343, 344, 344, 345, 345, 352, 353, 355, 356, 356, 356, 357, 359, 360, 362, 363, 363, 364, 364, 365, 365, 365, 365, 366, 366, 367, 367, 368, 369, 370, 371, 371, 372, 373, 373, 0, 373, 373, 373, 373, 0, 0, 374, 374, 376, 376, 376, 377, 379, 381, 381, 383, 384, 384, 385, 385, 393, 394, 395, 395, 396, 396, 396, 396, 397, 398, 398, 399, 399, 399, 399, 399, 399, 399, 401, 401, 396, 404, 409, 410, 411, 415, 415, 419, 419, 423, 423, 427, 427, 431, 431, 435, 435, 439, 440, 440, 441, 0, 441, 441, 442, 443, 447, 451, 452, 0, 452, 452, 453, 455, 455, 456, 0, 456, 456, 457, 460, 464, 465, 466, 470, 470, 471, 471, 472, 0, 472, 472, 473, 475, 475, 476, 476, 478, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 27, 28, 29, 30, 31, 39, 40, 45, 46, 47, 49, 50, 57, 58, 63, 64, 65, 67, 68, 72, 73, 77, 78, 83, 84, 96, 99, 101, 102, 107, 108, 109, 110, 112, 113, 121, 122, 132, 133, 134, 135, 136, 139, 140, 142, 143, 149, 165, 170, 171, 174, 175, 176, 181, 182, 185, 189, 190, 192, 192, 195, 197, 198, 199, 204, 205, 206, 213, 214, 239, 240, 245, 246, 247, 248, 253, 254, 258, 260, 261, 264, 265, 270, 271, 276, 277, 278, 279, 282, 284, 285, 286, 289, 290, 291, 296, 297, 298, 301, 302, 304, 305, 306, 307, 310, 311, 316, 317, 318, 331, 332, 334, 335, 338, 339, 341, 347, 350, 371, 372, 373, 374, 375, 380, 381, 383, 384, 387, 388, 393, 394, 397, 398, 399, 404, 405, 408, 409, 411, 412, 415, 416, 421, 422, 449, 450, 451, 452, 453, 458, 459, 461, 462, 465, 466, 471, 472, 473, 476, 477, 478, 483, 484, 485, 488, 489, 491, 492, 495, 496, 501, 502, 503, 539, 540, 541, 542, 543, 548, 549, 551, 552, 555, 556, 561, 562, 563, 566, 567, 568, 573, 574, 575, 578, 579, 581, 582, 583, 586, 591, 592, 593, 598, 599, 602, 603, 604, 609, 610, 613, 617, 618, 621, 622, 623, 624, 626, 632, 633, 636, 637, 642, 643, 644, 666, 667, 668, 669, 670, 673, 674, 679, 680, 681, 686, 687, 688, 689, 690, 691, 692, 693, 696, 697, 699, 705, 708, 709, 710, 715, 716, 720, 721, 725, 726, 730, 731, 735, 736, 740, 741, 750, 751, 756, 757, 757, 760, 762, 763, 765, 773, 783, 784, 784, 787, 789, 790, 796, 801, 802, 802, 805, 807, 808, 815, 819, 820, 821, 833, 838, 839, 840, 842, 842, 845, 847, 848, 856, 857, 859, 860, 863, 870, 873, 877, 880};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 169 20
new 0 169 20
new 1 169 21
assign 1 175 25
assign 1 176 26
new 0 176 26
assign 1 177 27
new 0 177 27
assign 1 178 28
new 0 178 28
assign 1 179 29
new 0 179 29
assign 1 182 30
new 1 182 30
assign 1 183 31
new 0 183 31
assign 1 189 39
new 0 189 39
assign 1 189 40
equals 1 189 45
assign 1 190 46
new 0 190 46
return 1 190 47
assign 1 192 49
new 0 192 49
return 1 192 50
assign 1 196 57
new 0 196 57
assign 1 196 58
equals 1 196 63
assign 1 197 64
new 0 197 64
return 1 197 65
assign 1 199 67
new 0 199 67
return 1 199 68
assign 1 203 72
toString 0 203 72
return 1 203 73
assign 1 207 77
new 1 207 77
new 1 207 78
assign 1 211 83
new 1 211 83
return 1 211 84
assign 1 215 96
arrayIteratorGet 0 215 96
assign 1 215 99
hasNextGet 0 215 99
assign 1 216 101
nextGet 0 216 101
assign 1 217 102
def 1 217 107
assign 1 218 108
keyGet 0 218 108
assign 1 218 109
innerPut 4 218 109
assign 1 218 110
not 0 218 110
assign 1 219 112
new 0 219 112
return 1 219 113
assign 1 223 121
new 0 223 121
return 1 223 122
assign 1 228 132
sizeGet 0 228 132
assign 1 228 133
multiply 1 228 133
assign 1 228 134
new 0 228 134
assign 1 228 135
add 1 228 135
assign 1 229 136
new 1 229 136
assign 1 230 139
insertAll 2 230 139
assign 1 230 140
not 0 230 140
assign 1 231 142
increment 0 231 142
assign 1 232 143
new 1 232 143
return 1 234 149
assign 1 238 165
undef 1 238 170
assign 1 0 171
assign 1 238 174
sizeGet 0 238 174
assign 1 238 175
sizeGet 0 238 175
assign 1 238 176
notEquals 1 238 181
assign 1 0 182
assign 1 0 185
assign 1 239 189
new 0 239 189
return 1 239 190
assign 1 241 192
setIteratorGet 0 0 192
assign 1 241 195
hasNextGet 0 241 195
assign 1 241 197
nextGet 0 241 197
assign 1 242 198
has 1 242 198
assign 1 242 199
not 0 242 204
assign 1 242 205
new 0 242 205
return 1 242 206
assign 1 244 213
new 0 244 213
return 1 244 214
assign 1 248 239
sizeGet 0 248 239
assign 1 249 240
undef 1 249 245
assign 1 250 246
getHash 1 250 246
assign 1 251 247
new 0 251 247
assign 1 251 248
lesser 1 251 253
assign 1 252 254
abs 0 252 254
assign 1 255 258
hvalGet 0 255 258
assign 1 257 260
modulus 1 257 260
assign 1 258 261
assign 1 260 264
get 1 260 264
assign 1 261 265
undef 1 261 270
assign 1 262 271
undef 1 262 276
assign 1 263 277
create 0 263 277
assign 1 263 278
new 3 263 278
put 2 263 279
put 2 265 282
assign 1 267 284
new 0 267 284
assign 1 268 285
new 0 268 285
return 1 268 286
assign 1 269 289
hvalGet 0 269 289
assign 1 269 290
modulus 1 269 290
assign 1 269 291
notEquals 1 269 296
assign 1 270 297
new 0 270 297
return 1 270 298
assign 1 271 301
keyGet 0 271 301
assign 1 271 302
isEqual 2 271 302
putTo 2 272 304
assign 1 274 305
new 0 274 305
assign 1 275 306
new 0 275 306
return 1 275 307
assign 1 277 310
increment 0 277 310
assign 1 278 311
greaterEquals 1 278 316
assign 1 279 317
new 0 279 317
return 1 279 318
assign 1 286 331
innerPut 4 286 331
assign 1 286 332
not 0 286 332
assign 1 287 334
assign 1 288 335
rehash 1 288 335
assign 1 289 338
innerPut 4 289 338
assign 1 289 339
not 0 289 339
assign 1 290 341
rehash 1 290 341
assign 1 292 347
assign 1 295 350
increment 0 295 350
assign 1 300 371
assign 1 301 372
sizeGet 0 301 372
assign 1 302 373
getHash 1 302 373
assign 1 303 374
new 0 303 374
assign 1 303 375
lesser 1 303 380
assign 1 304 381
abs 0 304 381
assign 1 306 383
modulus 1 306 383
assign 1 307 384
assign 1 309 387
get 1 309 387
assign 1 310 388
undef 1 310 393
return 1 311 394
assign 1 312 397
hvalGet 0 312 397
assign 1 312 398
modulus 1 312 398
assign 1 312 399
notEquals 1 312 404
return 1 313 405
assign 1 314 408
keyGet 0 314 408
assign 1 314 409
isEqual 2 314 409
assign 1 315 411
getFrom 0 315 411
return 1 315 412
assign 1 317 415
increment 0 317 415
assign 1 318 416
greaterEquals 1 318 421
return 1 319 422
assign 1 326 449
assign 1 327 450
sizeGet 0 327 450
assign 1 328 451
getHash 1 328 451
assign 1 329 452
new 0 329 452
assign 1 329 453
lesser 1 329 458
assign 1 330 459
abs 0 330 459
assign 1 332 461
modulus 1 332 461
assign 1 333 462
assign 1 335 465
get 1 335 465
assign 1 336 466
undef 1 336 471
assign 1 337 472
new 0 337 472
return 1 337 473
assign 1 338 476
hvalGet 0 338 476
assign 1 338 477
modulus 1 338 477
assign 1 338 478
notEquals 1 338 483
assign 1 339 484
new 0 339 484
return 1 339 485
assign 1 340 488
keyGet 0 340 488
assign 1 340 489
isEqual 2 340 489
assign 1 341 491
new 0 341 491
return 1 341 492
assign 1 343 495
increment 0 343 495
assign 1 344 496
greaterEquals 1 344 501
assign 1 345 502
new 0 345 502
return 1 345 503
assign 1 352 539
assign 1 353 540
sizeGet 0 353 540
assign 1 355 541
getHash 1 355 541
assign 1 356 542
new 0 356 542
assign 1 356 543
lesser 1 356 548
assign 1 357 549
abs 0 357 549
assign 1 359 551
modulus 1 359 551
assign 1 360 552
assign 1 362 555
get 1 362 555
assign 1 363 556
undef 1 363 561
assign 1 364 562
new 0 364 562
return 1 364 563
assign 1 365 566
hvalGet 0 365 566
assign 1 365 567
modulus 1 365 567
assign 1 365 568
notEquals 1 365 573
assign 1 366 574
new 0 366 574
return 1 366 575
assign 1 367 578
keyGet 0 367 578
assign 1 367 579
isEqual 2 367 579
put 2 368 581
assign 1 369 582
decrement 0 369 582
assign 1 370 583
increment 0 370 583
assign 1 371 586
lesser 1 371 591
assign 1 372 592
get 1 372 592
assign 1 373 593
undef 1 373 598
assign 1 0 599
assign 1 373 602
hvalGet 0 373 602
assign 1 373 603
modulus 1 373 603
assign 1 373 604
notEquals 1 373 609
assign 1 0 610
assign 1 0 613
assign 1 374 617
new 0 374 617
return 1 374 618
assign 1 376 621
new 0 376 621
assign 1 376 622
subtract 1 376 622
put 2 376 623
put 2 377 624
assign 1 379 626
increment 0 379 626
assign 1 381 632
new 0 381 632
return 1 381 633
assign 1 383 636
increment 0 383 636
assign 1 384 637
greaterEquals 1 384 642
assign 1 385 643
new 0 385 643
return 1 385 644
assign 1 393 666
create 0 393 666
copyTo 1 394 667
assign 1 395 668
copy 0 395 668
bucketsSet 1 395 669
assign 1 396 670
new 0 396 670
assign 1 396 673
lengthGet 0 396 673
assign 1 396 674
lesser 1 396 679
assign 1 397 680
get 1 397 680
assign 1 398 681
def 1 398 686
assign 1 399 687
bucketsGet 0 399 687
assign 1 399 688
create 0 399 688
assign 1 399 689
hvalGet 0 399 689
assign 1 399 690
keyGet 0 399 690
assign 1 399 691
getFrom 0 399 691
assign 1 399 692
new 3 399 692
put 2 399 693
assign 1 401 696
bucketsGet 0 401 696
put 2 401 697
assign 1 396 699
increment 0 396 699
return 1 404 705
clear 0 409 708
sizeSet 1 410 709
assign 1 411 710
new 0 411 710
assign 1 415 715
new 1 415 715
return 1 415 716
assign 1 419 720
new 1 419 720
return 1 419 721
assign 1 423 725
new 1 423 725
return 1 423 726
assign 1 427 730
keyIteratorGet 0 427 730
return 1 427 731
assign 1 431 735
new 1 431 735
return 1 431 736
assign 1 435 740
nodeIteratorGet 0 435 740
return 1 435 741
assign 1 439 750
new 0 439 750
assign 1 440 751
def 1 440 756
assign 1 441 757
setIteratorGet 0 0 757
assign 1 441 760
hasNextGet 0 441 760
assign 1 441 762
nextGet 0 441 762
assign 1 442 763
has 1 442 763
put 1 443 765
return 1 447 773
assign 1 451 783
new 0 451 783
assign 1 452 784
setIteratorGet 0 0 784
assign 1 452 787
hasNextGet 0 452 787
assign 1 452 789
nextGet 0 452 789
put 1 453 790
assign 1 455 796
def 1 455 801
assign 1 456 802
setIteratorGet 0 0 802
assign 1 456 805
hasNextGet 0 456 805
assign 1 456 807
nextGet 0 456 807
put 1 457 808
return 1 460 815
assign 1 464 819
copy 0 464 819
addValue 1 465 820
return 1 466 821
assign 1 470 833
def 1 470 838
assign 1 471 839
new 0 471 839
assign 1 471 840
sameType 2 471 840
assign 1 472 842
iteratorGet 0 0 842
assign 1 472 845
hasNextGet 0 472 845
assign 1 472 847
nextGet 0 472 847
put 1 473 848
assign 1 475 856
new 0 475 856
assign 1 475 857
sameType 2 475 857
assign 1 476 859
keyGet 0 476 859
put 1 476 860
put 1 478 863
return 1 0 870
assign 1 0 873
return 1 0 877
assign 1 0 880
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2101684619: return bem_new_0();
case -655071244: return bem_sizeGet_0();
case -907468016: return bem_nodeIteratorGet_0();
case -698276284: return bem_nodesGet_0();
case -130444845: return bem_isEmptyGet_0();
case 1319233284: return bem_iteratorGet_0();
case -1046533786: return bem_notEmptyGet_0();
case -118181938: return bem_clear_0();
case 1700887903: return bem_setIteratorGet_0();
case -1267695015: return bem_serializeToString_0();
case -428175563: return bem_toString_0();
case 1671411432: return bem_keyIteratorGet_0();
case -1677484548: return bem_print_0();
case -1715211966: return bem_hashGet_0();
case -26482090: return bem_serializationIteratorGet_0();
case 1236932780: return bem_keysGet_0();
case -414672201: return bem_create_0();
case 1749455096: return bem_copy_0();
case 1590877755: return bem_bucketsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 183362921: return bem_equals_1(bevd_0);
case -797981574: return bem_delete_1(bevd_0);
case -726820115: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1472171117: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1241694000: return bem_get_1(bevd_0);
case 1228234604: return bem_def_1(bevd_0);
case -859227245: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 762354236: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -329682344: return bem_undef_1(bevd_0);
case -935646021: return bem_bucketsSet_1(bevd_0);
case 1371977795: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1507043668: return bem_sizeSet_1(bevd_0);
case -1513472994: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1777660964: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1545988169: return bem_addValue_1(bevd_0);
case 1406732523: return bem_has_1(bevd_0);
case -760176780: return bem_copyTo_1(bevd_0);
case 1494281396: return bem_put_1(bevd_0);
case 1789302952: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -355340329: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 365672883: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -519546757: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -811910767: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -242597694: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -677194446: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
