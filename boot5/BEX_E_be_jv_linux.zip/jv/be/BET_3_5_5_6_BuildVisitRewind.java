package be;
public class BET_3_5_5_6_BuildVisitRewind extends BETS_Object {
public BET_3_5_5_6_BuildVisitRewind() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "begin_1", "accept_1", "end_1", "transGet_0", "transSet_1", "buildGet_0", "buildSet_1", "constGet_0", "constSet_1", "ntypesGet_0", "ntypesSet_1", "processTmps_0", "tvmapGet_0", "tvmapSet_1", "rmapGet_0", "rmapSet_1", "inClassGet_0", "inClassSet_1", "inClassNpGet_0", "inClassNpSet_1", "inClassSynGet_0", "inClassSynSet_1", "nlGet_0", "nlSet_1", "emitterGet_0", "emitterSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "trans", "build", "const", "ntypes", "tvmap", "rmap", "inClass", "inClassNp", "inClassSyn", "nl", "emitter" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_5_5_6_BuildVisitRewind();
}
}
