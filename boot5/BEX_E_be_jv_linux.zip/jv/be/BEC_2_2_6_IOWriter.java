package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOWriter extends BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOWriter() { }

   
    public java.io.OutputStream bevi_os;
    
   private static byte[] becc_BEC_2_2_6_IOWriter_clname = {0x49,0x4F,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_2_6_IOWriter bece_BEC_2_2_6_IOWriter_bevs_inst;

public static BET_2_2_6_IOWriter bece_BEC_2_2_6_IOWriter_bevs_type;

public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_2_6_IOWriter bem_new_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_vfileGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_extOpen_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_close_0() throws Throwable {

      if (this.bevi_os != null) {
        this.bevi_os.close();
        this.bevi_os = null;
      }
      bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_write_1(BEC_2_4_6_TextString beva_stri) throws Throwable {

      this.bevi_os.write(beva_stri.bevi_bytes, 0, beva_stri.bevp_size.bevi_int);
      return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_vfileGetDirect_0() throws Throwable {
return bevp_vfile;
} /*method end*/
public final BEC_2_2_6_IOWriter bem_vfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vfile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isClosedGetDirect_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_6_IOWriter bem_isClosedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {505, 516, 562, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 28, 37, 46, 49, 53, 56, 59, 63};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 505 18
new 0 505 18
assign 1 516 28
new 0 516 28
assign 1 562 37
new 0 562 37
return 1 0 46
assign 1 0 49
return 1 0 53
return 1 0 56
assign 1 0 59
assign 1 0 63
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1202859281: return bem_fieldIteratorGet_0();
case 1800213309: return bem_serializeContents_0();
case -169510412: return bem_toString_0();
case -458279913: return bem_serializationIteratorGet_0();
case -1927892139: return bem_isClosedGetDirect_0();
case 1166902012: return bem_print_0();
case 221369236: return bem_echo_0();
case -1223869755: return bem_close_0();
case -1052224695: return bem_vfileGet_0();
case -982743450: return bem_extOpen_0();
case 737627600: return bem_classNameGet_0();
case -1627101286: return bem_many_0();
case -1721224705: return bem_copy_0();
case -1588608331: return bem_iteratorGet_0();
case 1926605259: return bem_vfileGetDirect_0();
case -1760283647: return bem_sourceFileNameGet_0();
case -165877765: return bem_create_0();
case 586787044: return bem_toAny_0();
case 419402773: return bem_fieldNamesGet_0();
case -1145946037: return bem_serializeToString_0();
case -1200024888: return bem_tagGet_0();
case 1662643176: return bem_new_0();
case -166191037: return bem_isClosedGet_0();
case -1855742442: return bem_deserializeClassNameGet_0();
case -4634496: return bem_once_0();
case -12708128: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -409899450: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1058481552: return bem_undef_1(bevd_0);
case -327804541: return bem_sameClass_1(bevd_0);
case 763779493: return bem_isClosedSet_1(bevd_0);
case 286179063: return bem_copyTo_1(bevd_0);
case 1174135522: return bem_sameType_1(bevd_0);
case -978336250: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -306633068: return bem_undefined_1(bevd_0);
case 1396328003: return bem_otherClass_1(bevd_0);
case -2050626933: return bem_def_1(bevd_0);
case -1967308895: return bem_vfileSetDirect_1(bevd_0);
case -39094467: return bem_equals_1(bevd_0);
case 766990358: return bem_vfileSet_1(bevd_0);
case -2002377294: return bem_isClosedSetDirect_1(bevd_0);
case -1880368515: return bem_notEquals_1(bevd_0);
case 1039180755: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1694968514: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2038137777: return bem_otherType_1(bevd_0);
case -1143294403: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -883889211: return bem_sameObject_1(bevd_0);
case -1617140536: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -549233499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853281410: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666962597: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1983260459: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -136430353: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2126382926: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1776809505: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOWriter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOWriter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_6_IOWriter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_inst = (BEC_2_2_6_IOWriter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_type;
}
}
