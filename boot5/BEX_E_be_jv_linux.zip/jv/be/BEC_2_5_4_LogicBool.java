package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_4_LogicBool extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }

   
    public boolean bevi_bool;
    public BEC_2_5_4_LogicBool(boolean bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_5 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_6 = {0x66,0x61,0x6C,0x73,0x65};
public static BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;
public BEC_2_5_4_LogicBool bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(2016817692, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 43 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 44 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(2016817692, bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 51 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 61 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_0_tmpany_phold;
} /* Line: 62 */
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 72 */ {
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 73 */
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 88 */
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_5));
return bevt_0_tmpany_phold;
} /* Line: 95 */
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_6));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copy_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {43, 43, 44, 44, 46, 46, 50, 50, 50, 50, 0, 0, 0, 51, 51, 53, 53, 57, 57, 62, 62, 64, 64, 68, 68, 73, 73, 75, 75, 79, 79, 83, 83, 88, 88, 90, 90, 95, 95, 97, 97, 101};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {28, 29, 31, 32, 34, 35, 44, 49, 50, 51, 53, 56, 60, 63, 64, 66, 67, 71, 72, 78, 79, 81, 82, 86, 87, 93, 94, 96, 97, 101, 102, 106, 107, 113, 114, 116, 117, 123, 124, 126, 127, 130};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 43 28
new 0 43 28
assign 1 43 29
equals 1 43 29
assign 1 44 31
new 0 44 31
return 1 44 32
assign 1 46 34
new 0 46 34
return 1 46 35
assign 1 50 44
def 1 50 49
assign 1 50 50
new 0 50 50
assign 1 50 51
equals 1 50 51
assign 1 0 53
assign 1 0 56
assign 1 0 60
assign 1 51 63
new 0 51 63
return 1 51 64
assign 1 53 66
new 0 53 66
return 1 53 67
assign 1 57 71
new 0 57 71
return 1 57 72
assign 1 62 78
new 0 62 78
return 1 62 79
assign 1 64 81
new 0 64 81
return 1 64 82
assign 1 68 86
new 0 68 86
return 1 68 87
assign 1 73 93
new 0 73 93
return 1 73 94
assign 1 75 96
new 0 75 96
return 1 75 97
assign 1 79 101
new 0 79 101
return 1 79 102
assign 1 83 106
new 0 83 106
return 1 83 107
assign 1 88 113
new 0 88 113
return 1 88 114
assign 1 90 116
new 0 90 116
return 1 90 117
assign 1 95 123
new 0 95 123
return 1 95 124
assign 1 97 126
new 0 97 126
return 1 97 127
return 1 101 130
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -145312000: return bem_serializationIteratorGet_0();
case -176876439: return bem_fieldIteratorGet_0();
case -1077716790: return bem_decrement_0();
case 904467476: return bem_create_0();
case -629628110: return bem_toAny_0();
case 714053375: return bem_many_0();
case -820547047: return bem_new_0();
case -131080468: return bem_print_0();
case -1239151636: return bem_sourceFileNameGet_0();
case -863935940: return bem_copy_0();
case -717024807: return bem_increment_0();
case 1030499827: return bem_iteratorGet_0();
case 865364657: return bem_serializeContents_0();
case -1895992021: return bem_deserializeClassNameGet_0();
case 1021615634: return bem_classNameGet_0();
case -543336520: return bem_not_0();
case -316245103: return bem_echo_0();
case 521055509: return bem_serializeToString_0();
case -1196329855: return bem_tagGet_0();
case 1797341089: return bem_once_0();
case 269723613: return bem_hashGet_0();
case 657801083: return bem_toString_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 1808338509: return bem_def_1(bevd_0);
case 681555470: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 544484580: return bem_defined_1(bevd_0);
case -455244874: return bem_undefined_1(bevd_0);
case 1354444477: return bem_undef_1(bevd_0);
case 779198300: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2063004658: return bem_sameType_1(bevd_0);
case 218874128: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1584774500: return bem_sameClass_1(bevd_0);
case 1409882627: return bem_checkDefNew_1(bevd_0);
case 566034428: return bem_new_1(bevd_0);
case -1074673344: return bem_copyTo_1(bevd_0);
case 153472398: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1693196376: return bem_otherType_1(bevd_0);
case 788271940: return bem_sameObject_1(bevd_0);
case -560471223: return bem_otherClass_1(bevd_0);
case 80790810: return bem_notEquals_1(bevd_0);
case 2016817692: return bem_equals_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 423661912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 338963035: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -236631668: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -539434931: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 901264448: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 883042907: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -884026318: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_LogicBool();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
}
