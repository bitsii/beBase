package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_4_LogicBool extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }

   
    public boolean bevi_bool;
    public BEC_2_5_4_LogicBool(boolean bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_5 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_6 = {0x66,0x61,0x6C,0x73,0x65};
public static BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;

public static BET_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_type;

public BEC_2_5_4_LogicBool bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(850683733, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 52 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(850683733, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 58 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
 else  /* Line: 58 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 58 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 59 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 69 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_0_tmpany_phold;
} /* Line: 70 */
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 80 */ {
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 81 */
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 95 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 96 */
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 102 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_5));
return bevt_0_tmpany_phold;
} /* Line: 103 */
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_6));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copy_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {51, 51, 52, 52, 54, 54, 58, 58, 58, 58, 0, 0, 0, 59, 59, 61, 61, 65, 65, 70, 70, 72, 72, 76, 76, 81, 81, 83, 83, 87, 87, 91, 91, 96, 96, 98, 98, 103, 103, 105, 105, 109};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 34, 35, 37, 38, 47, 52, 53, 54, 56, 59, 63, 66, 67, 69, 70, 74, 75, 81, 82, 84, 85, 89, 90, 96, 97, 99, 100, 104, 105, 109, 110, 116, 117, 119, 120, 126, 127, 129, 130, 133};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 51 31
new 0 51 31
assign 1 51 32
equals 1 51 32
assign 1 52 34
new 0 52 34
return 1 52 35
assign 1 54 37
new 0 54 37
return 1 54 38
assign 1 58 47
def 1 58 52
assign 1 58 53
new 0 58 53
assign 1 58 54
equals 1 58 54
assign 1 0 56
assign 1 0 59
assign 1 0 63
assign 1 59 66
new 0 59 66
return 1 59 67
assign 1 61 69
new 0 61 69
return 1 61 70
assign 1 65 74
new 0 65 74
return 1 65 75
assign 1 70 81
new 0 70 81
return 1 70 82
assign 1 72 84
new 0 72 84
return 1 72 85
assign 1 76 89
new 0 76 89
return 1 76 90
assign 1 81 96
new 0 81 96
return 1 81 97
assign 1 83 99
new 0 83 99
return 1 83 100
assign 1 87 104
new 0 87 104
return 1 87 105
assign 1 91 109
new 0 91 109
return 1 91 110
assign 1 96 116
new 0 96 116
return 1 96 117
assign 1 98 119
new 0 98 119
return 1 98 120
assign 1 103 126
new 0 103 126
return 1 103 127
assign 1 105 129
new 0 105 129
return 1 105 130
return 1 109 133
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 854837664: return bem_create_0();
case 239325412: return bem_copy_0();
case 1486098436: return bem_fieldNamesGet_0();
case 1616240746: return bem_toString_0();
case -1503677102: return bem_not_0();
case -760211542: return bem_sourceFileNameGet_0();
case -795764953: return bem_fieldIteratorGet_0();
case 417125603: return bem_increment_0();
case 1697432405: return bem_once_0();
case 1737862711: return bem_print_0();
case 1236768538: return bem_iteratorGet_0();
case -911579003: return bem_decrement_0();
case -1187132797: return bem_hashGet_0();
case -2036442591: return bem_toAny_0();
case 1319933824: return bem_classNameGet_0();
case 396059776: return bem_tagGet_0();
case -178992645: return bem_deserializeClassNameGet_0();
case 2077314506: return bem_many_0();
case -604973932: return bem_serializeContents_0();
case -1159943693: return bem_echo_0();
case -324733615: return bem_serializeToString_0();
case -1698643956: return bem_serializationIteratorGet_0();
case -980484092: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1021147088: return bem_otherClass_1(bevd_0);
case -492919920: return bem_new_1(bevd_0);
case 1109276399: return bem_sameObject_1(bevd_0);
case 1784508277: return bem_undefined_1(bevd_0);
case -354650091: return bem_undef_1(bevd_0);
case -58601680: return bem_sameType_1(bevd_0);
case 1075750255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1479379696: return bem_sameClass_1(bevd_0);
case 486594455: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1097624238: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 962423408: return bem_def_1(bevd_0);
case -1754732193: return bem_notEquals_1(bevd_0);
case 215737112: return bem_otherType_1(bevd_0);
case -1120436550: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1229731165: return bem_copyTo_1(bevd_0);
case -1649216440: return bem_checkDefNew_1(bevd_0);
case 850683733: return bem_equals_1(bevd_0);
case 395717057: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 602921151: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1012334348: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 661390803: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -434648658: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 192635884: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 103255187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 834345030: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_LogicBool();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_type;
}
}
