package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_4_LogicBool extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }

   
    public boolean bevi_bool;
    public BEC_2_5_4_LogicBool(boolean bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x66,0x61,0x6C,0x73,0x65};
public static BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;

public static BET_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_type;

public BEC_2_5_4_LogicBool bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_ta_ph = beva_str.bemd_1(-526829482, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 56*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 57*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 67*/ {
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_1));
return bevt_0_ta_ph;
} /* Line: 68*/
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 78*/ {
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
return bevt_0_ta_ph;
} /* Line: 79*/
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 85*/ {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /* Line: 86*/
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 92*/ {
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
return bevt_0_ta_ph;
} /* Line: 93*/
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copy_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {56, 56, 57, 57, 59, 59, 63, 63, 68, 68, 70, 70, 74, 74, 79, 79, 81, 81, 86, 86, 88, 88, 93, 93, 95, 95, 99};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 30, 32, 33, 35, 36, 40, 41, 47, 48, 50, 51, 55, 56, 62, 63, 65, 66, 72, 73, 75, 76, 82, 83, 85, 86, 89};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 56 29
new 0 56 29
assign 1 56 30
equals 1 56 30
assign 1 57 32
new 0 57 32
return 1 57 33
assign 1 59 35
new 0 59 35
return 1 59 36
assign 1 63 40
new 0 63 40
return 1 63 41
assign 1 68 47
new 0 68 47
return 1 68 48
assign 1 70 50
new 0 70 50
return 1 70 51
assign 1 74 55
new 0 74 55
return 1 74 56
assign 1 79 62
new 0 79 62
return 1 79 63
assign 1 81 65
new 0 81 65
return 1 81 66
assign 1 86 72
new 0 86 72
return 1 86 73
assign 1 88 75
new 0 88 75
return 1 88 76
assign 1 93 82
new 0 93 82
return 1 93 83
assign 1 95 85
new 0 95 85
return 1 95 86
return 1 99 89
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1712538602: return bem_toString_0();
case 403958228: return bem_serializeContentsGet_0();
case -1301883703: return bem_hashGet_0();
case 336279764: return bem_serializeToString_0();
case -1008787576: return bem_create_0();
case 1408609733: return bem_iteratorGet_0();
case 252385543: return bem_deserializeClassNameGet_0();
case -978033728: return bem_print_0();
case 1806064504: return bem_new_0();
case 1877465750: return bem_not_0();
case -1275315701: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1162939778: return bem_def_1(bevd_0);
case -526829482: return bem_equals_1(bevd_0);
case -148010615: return bem_undef_1(bevd_0);
case 2105889386: return bem_notEquals_1(bevd_0);
case -1234820220: return bem_copyTo_1(bevd_0);
case -1217552554: return bem_print_1(bevd_0);
case -1784930552: return bem_new_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -960117370: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 596327003: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -554972801: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 415995996: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_LogicBool();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_type;
}
}
