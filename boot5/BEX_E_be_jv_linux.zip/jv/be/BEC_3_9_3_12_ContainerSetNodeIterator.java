package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;

public static BET_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;

public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_buckets;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_set = beva__set;
bevp_buckets = bevp_set.bem_bucketsGet_0();
bevp_modu = bevp_buckets.bem_lengthGet_0();
bevp_current = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_containerGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_i = bevp_current;
while (true)
/* Line: 623*/ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 623*/ {
bevt_2_ta_ph = bevp_buckets.bem_get_1(bevl_i);
if (bevt_2_ta_ph == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 624*/ {
bevp_current = bevl_i;
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 626*/
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_i = bevl_i.bem_add_1(bevt_4_ta_ph);
} /* Line: 623*/
 else /* Line: 623*/ {
break;
} /* Line: 623*/
} /* Line: 623*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevl_i = bevp_current;
while (true)
/* Line: 633*/ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 633*/ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 635*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_current = bevl_i.bem_add_1(bevt_2_ta_ph);
return bevl_toRet;
} /* Line: 637*/
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_i = bevl_i.bem_add_1(bevt_3_ta_ph);
} /* Line: 633*/
 else /* Line: 633*/ {
break;
} /* Line: 633*/
} /* Line: 633*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_remove_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_i = bevp_current.bem_subtract_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_i.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 645*/ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 647*/ {
bevt_5_ta_ph = bevl_sn.bem_keyGet_0();
bevt_4_ta_ph = bevp_set.bem_remove_1(bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 648*/ {
bevp_current = bevl_i;
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 650*/
} /* Line: 648*/
} /* Line: 647*/
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {610, 611, 612, 613, 619, 623, 623, 623, 624, 624, 624, 625, 626, 626, 623, 623, 629, 629, 633, 633, 633, 634, 635, 635, 636, 636, 637, 633, 633, 640, 644, 644, 645, 645, 645, 646, 647, 647, 648, 648, 649, 650, 650, 654, 654, 659, 663};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 23, 33, 36, 41, 42, 43, 48, 49, 50, 51, 53, 54, 60, 61, 70, 73, 78, 79, 80, 85, 86, 87, 88, 90, 91, 97, 110, 111, 112, 113, 118, 119, 120, 125, 126, 127, 129, 130, 131, 135, 136, 139, 142};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 610 16
assign 1 611 17
bucketsGet 0 611 17
assign 1 612 18
lengthGet 0 612 18
assign 1 613 19
new 0 613 19
return 1 619 23
assign 1 623 33
assign 1 623 36
lesser 1 623 41
assign 1 624 42
get 1 624 42
assign 1 624 43
def 1 624 48
assign 1 625 49
assign 1 626 50
new 0 626 50
return 1 626 51
assign 1 623 53
new 0 623 53
assign 1 623 54
add 1 623 54
assign 1 629 60
new 0 629 60
return 1 629 61
assign 1 633 70
assign 1 633 73
lesser 1 633 78
assign 1 634 79
get 1 634 79
assign 1 635 80
def 1 635 85
assign 1 636 86
new 0 636 86
assign 1 636 87
add 1 636 87
return 1 637 88
assign 1 633 90
new 0 633 90
assign 1 633 91
add 1 633 91
return 1 640 97
assign 1 644 110
new 0 644 110
assign 1 644 111
subtract 1 644 111
assign 1 645 112
new 0 645 112
assign 1 645 113
greaterEquals 1 645 118
assign 1 646 119
get 1 646 119
assign 1 647 120
def 1 647 125
assign 1 648 126
keyGet 0 648 126
assign 1 648 127
remove 1 648 127
assign 1 649 129
assign 1 650 130
new 0 650 130
return 1 650 131
assign 1 654 135
new 0 654 135
return 1 654 136
return 1 659 139
return 1 663 142
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1702262082: return bem_containerGet_0();
case 534407118: return bem_nodeIteratorIteratorGet_0();
case -1301883703: return bem_hashGet_0();
case -978033728: return bem_print_0();
case 1806064504: return bem_new_0();
case -2091955637: return bem_remove_0();
case -1008787576: return bem_create_0();
case -1514376542: return bem_nextGet_0();
case 1712538602: return bem_toString_0();
case -1275315701: return bem_copy_0();
case -1739111147: return bem_hasNextGet_0();
case 1408609733: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1162939778: return bem_def_1(bevd_0);
case -526829482: return bem_equals_1(bevd_0);
case -148010615: return bem_undef_1(bevd_0);
case 2105889386: return bem_notEquals_1(bevd_0);
case -1234820220: return bem_copyTo_1(bevd_0);
case -1217552554: return bem_print_1(bevd_0);
case -1784930552: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -960117370: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 596327003: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -554972801: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 415995996: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;
}
}
