package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;

public static BET_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;

public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_set = beva__set;
bevp_slots = bevp_set.bem_slotsGet_0();
bevp_modu = bevp_slots.bem_sizeGet_0();
bevp_current = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_containerGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = bevp_current;
while (true)
/* Line: 657*/ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 657*/ {
bevt_2_ta_ph = bevp_slots.bem_get_1(bevl_i);
if (bevt_2_ta_ph == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 658*/ {
bevp_current = bevl_i;
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 660*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 657*/
 else /* Line: 657*/ {
break;
} /* Line: 657*/
} /* Line: 657*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_i = bevp_current;
while (true)
/* Line: 667*/ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 667*/ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 669*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_current = bevl_i.bem_add_1(bevt_2_ta_ph);
return bevl_toRet;
} /* Line: 671*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 667*/
 else /* Line: 667*/ {
break;
} /* Line: 667*/
} /* Line: 667*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delete_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_i = bevp_current.bem_subtract_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_i.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 679*/ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 681*/ {
bevt_5_ta_ph = bevl_sn.bem_keyGet_0();
bevt_4_ta_ph = bevp_set.bem_delete_1(bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 682*/ {
bevp_current = bevl_i;
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 684*/
} /* Line: 682*/
} /* Line: 681*/
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_setGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_setGetDirect_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_setSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_3_12_ContainerSetNodeIterator bem_setSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_slotsGetDirect_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public final BEC_2_4_3_MathInt bem_moduGetDirect_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public final BEC_2_4_3_MathInt bem_currentGetDirect_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {644, 645, 646, 647, 653, 657, 657, 657, 658, 658, 658, 659, 660, 660, 657, 663, 663, 667, 667, 667, 668, 669, 669, 670, 670, 671, 667, 674, 678, 678, 679, 679, 679, 680, 681, 681, 682, 682, 683, 684, 684, 688, 688, 693, 697, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 23, 32, 35, 40, 41, 42, 47, 48, 49, 50, 52, 58, 59, 67, 70, 75, 76, 77, 82, 83, 84, 85, 87, 93, 106, 107, 108, 109, 114, 115, 116, 121, 122, 123, 125, 126, 127, 131, 132, 135, 138, 141, 144, 147, 151, 155, 158, 161, 165, 169, 172, 175, 179, 183, 186, 189, 193};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 644 16
assign 1 645 17
slotsGet 0 645 17
assign 1 646 18
sizeGet 0 646 18
assign 1 647 19
new 0 647 19
return 1 653 23
assign 1 657 32
assign 1 657 35
lesser 1 657 40
assign 1 658 41
get 1 658 41
assign 1 658 42
def 1 658 47
assign 1 659 48
assign 1 660 49
new 0 660 49
return 1 660 50
assign 1 657 52
increment 0 657 52
assign 1 663 58
new 0 663 58
return 1 663 59
assign 1 667 67
assign 1 667 70
lesser 1 667 75
assign 1 668 76
get 1 668 76
assign 1 669 77
def 1 669 82
assign 1 670 83
new 0 670 83
assign 1 670 84
add 1 670 84
return 1 671 85
assign 1 667 87
increment 0 667 87
return 1 674 93
assign 1 678 106
new 0 678 106
assign 1 678 107
subtract 1 678 107
assign 1 679 108
new 0 679 108
assign 1 679 109
greaterEquals 1 679 114
assign 1 680 115
get 1 680 115
assign 1 681 116
def 1 681 121
assign 1 682 122
keyGet 0 682 122
assign 1 682 123
delete 1 682 123
assign 1 683 125
assign 1 684 126
new 0 684 126
return 1 684 127
assign 1 688 131
new 0 688 131
return 1 688 132
return 1 693 135
return 1 697 138
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
return 1 0 155
return 1 0 158
assign 1 0 161
assign 1 0 165
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 967234853: return bem_fieldIteratorGet_0();
case 2079194339: return bem_hasNextGet_0();
case 360872129: return bem_slotsGet_0();
case 766881626: return bem_print_0();
case 1955915393: return bem_fieldNamesGet_0();
case 509361355: return bem_once_0();
case -194416815: return bem_tagGet_0();
case -1455899172: return bem_create_0();
case 1368356838: return bem_slotsGetDirect_0();
case 1994778350: return bem_delete_0();
case -1715766851: return bem_toAny_0();
case -533443118: return bem_many_0();
case 925852098: return bem_currentGetDirect_0();
case -180175097: return bem_classNameGet_0();
case -592427136: return bem_setGetDirect_0();
case 1790843424: return bem_nextGet_0();
case 378307569: return bem_copy_0();
case 1797865600: return bem_new_0();
case 280712282: return bem_toString_0();
case -1866351922: return bem_moduGet_0();
case -665649433: return bem_serializeContents_0();
case -1616244364: return bem_nodeIteratorIteratorGet_0();
case 1610655321: return bem_setGet_0();
case -119499799: return bem_serializationIteratorGet_0();
case 661198498: return bem_currentGet_0();
case 1777587047: return bem_hashGet_0();
case 2011135674: return bem_iteratorGet_0();
case 617445256: return bem_sourceFileNameGet_0();
case -639730360: return bem_containerGet_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case 1095297479: return bem_echo_0();
case -1724453868: return bem_serializeToString_0();
case 30433882: return bem_moduGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -445857610: return bem_notEquals_1(bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case -1728112714: return bem_moduSet_1(bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case -702801474: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 615341917: return bem_slotsSet_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case 1775292984: return bem_currentSet_1(bevd_0);
case 1274393801: return bem_moduSetDirect_1(bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case 906320876: return bem_defined_1(bevd_0);
case -1004644935: return bem_setSet_1(bevd_0);
case 1589767987: return bem_currentSetDirect_1(bevd_0);
case 482561896: return bem_setSetDirect_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
case -550662270: return bem_slotsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;
}
}
