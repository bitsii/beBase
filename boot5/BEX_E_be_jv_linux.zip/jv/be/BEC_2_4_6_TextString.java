package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_6_TextString extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) {
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) {
      //do copy, isOnce
      this.bevi_bytes = new byte[bevi_length];
      System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
      bevp_size = new BEC_2_4_3_MathInt(bevi_length);
      bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) {
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(String bevi_string) throws Exception {
        byte[] bevi_bytes = bevi_string.getBytes("UTF-8");
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public String bems_toJvString() throws Exception {
        String jvString = new String(bevi_bytes, 0, bevp_size.bevi_int, "UTF-8");
        return jvString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
public static BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_6_TextString bem_vstringGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_capacity == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 270*/ {
bevp_capacity = (new BEC_2_4_3_MathInt(0));
} /* Line: 271*/
 else /* Line: 270*/ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 272*/ {
return this;
} /* Line: 273*/
} /* Line: 270*/

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        this.bevi_bytes = java.util.Arrays.copyOf(this.bevi_bytes, beva_ncap.bevi_int);
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 309*/ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 310*/
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setHex_2(bevt_2_ta_ph, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt());
bevt_1_ta_ph = bem_getCode_2(beva_pos, bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_toString_3(bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) throws Throwable {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_sizi = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_7_TextStrings bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(290193605);
bevl_sizi = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bevl_str.bem_sizeGet_0();
bevl_sizi.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevl_sizi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 337*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_3_ta_ph = bevl_sizi.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_2_ta_ph = bevt_3_ta_ph.bem_multiply_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_nsize = bevt_2_ta_ph.bem_divide_1(bevt_6_ta_ph);
bem_capacitySet_1(bevl_nsize);
} /* Line: 341*/
bevt_8_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_7_ta_ph = bevt_8_ta_ph.bem_zeroGet_0();
bevt_9_ta_ph = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_7_ta_ph, bevt_9_ta_ph, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) throws Throwable {
beva_w.bemd_1(-73400120, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 375*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setIntUnchecked_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_size.bevi_int = bevt_4_ta_ph.bevi_int;
} /* Line: 377*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setCodeUnchecked_2(bevt_2_ta_ph, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() throws Throwable {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_nl = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_0_ta_ph = bem_ends_1(bevl_nl);
if (bevt_0_ta_ph.bevi_bool)/* Line: 389*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_3_ta_ph = bevp_size.bem_subtract_1(bevt_4_ta_ph);
bevt_1_ta_ph = bem_substring_2(bevt_2_ta_ph, bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 390*/
bevl_nl = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_5_ta_ph = bem_ends_1(bevl_nl);
if (bevt_5_ta_ph.bevi_bool)/* Line: 393*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_8_ta_ph = bevp_size.bem_subtract_1(bevt_9_ta_ph);
bevt_6_ta_ph = bem_substring_2(bevt_7_ta_ph, bevt_8_ta_ph);
return bevt_6_ta_ph;
} /* Line: 394*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_copy_0() throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_c = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_c.bem_addValue_1(this);
return (BEC_2_4_6_TextString) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 407*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 407*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_found.bevi_int != bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 407*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 407*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 407*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 407*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 408*/
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 414*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 414*/
bevt_3_ta_ph = beva_str.bem_sizeGet_0();
bevt_2_ta_ph = bevp_size.bem_subtract_1(bevt_3_ta_ph);
bevl_found = bem_find_2(beva_str, bevt_2_ta_ph);
if (bevl_found == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 417*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 423*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 423*/ {
bevt_3_ta_ph = bem_find_1(beva_str);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 423*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 423*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 423*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 423*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 424*/
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isIntegerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isInteger_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 435*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 435*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 437*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 437*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 437*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 437*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 437*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 437*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 437*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 437*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 437*/
 else /* Line: 437*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 437*/ {
} /* Line: 437*/
 else /* Line: 437*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(57));
if (bevl_ic.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(48));
if (bevl_ic.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 439*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 439*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 440*/
} /* Line: 437*/
bevl_j.bevi_int++;
} /* Line: 435*/
 else /* Line: 435*/ {
break;
} /* Line: 435*/
} /* Line: 435*/
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 448*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 448*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ic.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 450*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 450*/
 else /* Line: 450*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 450*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 450*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_ic.bevi_int < bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 450*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 450*/
 else /* Line: 450*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 450*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 450*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 450*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 450*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 450*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ic.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 450*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 450*/
 else /* Line: 450*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 450*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 450*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 450*/
if (!(bevt_0_ta_anchor.bevi_bool))/* Line: 450*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 451*/
bevl_j.bevi_int++;
} /* Line: 448*/
 else /* Line: 448*/ {
break;
} /* Line: 448*/
} /* Line: 448*/
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumericGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAlphaNumGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 463*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 463*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 465*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 465*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 465*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 465*/
 else /* Line: 465*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 465*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_ta_ph.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 467*/
bevl_j.bevi_int++;
} /* Line: 463*/
 else /* Line: 463*/ {
break;
} /* Line: 463*/
} /* Line: 463*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_lowerValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 478*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 478*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 480*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 480*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 480*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 480*/
 else /* Line: 480*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 480*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_ta_ph);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 482*/
bevl_j.bevi_int++;
} /* Line: 478*/
 else /* Line: 478*/ {
break;
} /* Line: 478*/
} /* Line: 478*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_upperValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 497*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_2_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = bem_sizeGet_0();
bevt_3_ta_ph = bem_substring_2(bevl_last, bevt_4_ta_ph);
bevl_res.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 501*/
 else /* Line: 502*/ {
bevt_5_ta_ph = beva_from.bem_copy_0();
return bevt_5_ta_ph;
} /* Line: 503*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 513*/ {
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 513*/ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 515*/ {
bevt_2_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_3_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_ta_ph);
} /* Line: 518*/
 else /* Line: 520*/ {
bevt_5_ta_ph = bem_sizeGet_0();
bevt_4_ta_ph = bem_substring_2(bevl_last, bevt_5_ta_ph);
bevl_res.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 521*/
} /* Line: 515*/
 else /* Line: 513*/ {
break;
} /* Line: 513*/
} /* Line: 513*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_j = bem_mbiterGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 532*/ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 532*/ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 532*/
 else /* Line: 532*/ {
break;
} /* Line: 532*/
} /* Line: 532*/
bevt_2_ta_ph = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_ta_ph.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 542*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 542*/ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_ta_ph);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 542*/
 else /* Line: 542*/ {
break;
} /* Line: 542*/
} /* Line: 542*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_hashValue_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getCode_2(beva_pos, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 566*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 566*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 566*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 566*/
 else /* Line: 566*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 566*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 594*/
 else /* Line: 602*/ {
return null;
} /* Line: 603*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 616*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 616*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 616*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 616*/
 else /* Line: 616*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 616*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int < 0) {
            beva_into.bevi_int += 256;
         }
         } /* Line: 645*/
 else /* Line: 650*/ {
return null;
} /* Line: 651*/
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 657*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 657*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 657*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 657*/
 else /* Line: 657*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 657*/ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 658*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 663*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 663*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 663*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 663*/
 else /* Line: 663*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 663*/ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 664*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() throws Throwable {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevl_input = this;
bevt_3_ta_ph = bevl_input.bem_sizeGet_0();
bevl_insz = bevt_3_ta_ph.bem_copy_0();
bevl_output = (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (new BEC_2_4_3_MathInt());
bevl_p = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 674*/ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 674*/ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_c.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 676*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_c.bevi_int < bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 676*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 676*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 676*/
 else /* Line: 676*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 676*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 676*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_c.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 676*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_c.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 676*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 676*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 676*/
 else /* Line: 676*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 676*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 676*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 676*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 676*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 676*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_c.bevi_int > bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 676*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_c.bevi_int < bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 676*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 676*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 676*/
 else /* Line: 676*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 676*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 676*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 676*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 676*/ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 678*/
bevl_i.bevi_int++;
} /* Line: 674*/
 else /* Line: 674*/ {
break;
} /* Line: 674*/
} /* Line: 674*/
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 686*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 687*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b > 127) {
        twvls_b -= 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_rfind_1(beva_str);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_reverseBytes_0();
bevt_3_ta_ph = beva_str.bem_copy_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_reverseBytes_0();
bevl_rpos = bevt_0_ta_ph.bem_find_1(bevt_2_ta_ph);
if (bevl_rpos == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 794*/ {
bevt_5_ta_ph = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_ta_ph.bevi_int;
bevt_6_ta_ph = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_ta_ph;
} /* Line: 796*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_find_2(beva_str, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
if (beva_str == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 808*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
if (beva_start == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 808*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 808*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 808*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_start.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 808*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 808*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 808*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 808*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 808*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 808*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_12_ta_ph = beva_str.bem_sizeGet_0();
if (bevt_12_ta_ph.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 808*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 808*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 808*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 808*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 808*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 808*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_16_ta_ph = beva_str.bem_sizeGet_0();
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 808*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 808*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 808*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 808*/ {
return null;
} /* Line: 809*/
bevl_end = bevp_size;
bevl_current = beva_start.bem_copy_0();
bevl_myval = (new BEC_2_4_3_MathInt());
bevl_strfirst = (new BEC_2_4_3_MathInt());
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_ta_ph, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_strsize.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 820*/ {
bevl_strval = (new BEC_2_4_3_MathInt());
bevl_current2 = (new BEC_2_4_3_MathInt());
bevl_end2 = (new BEC_2_4_3_MathInt());
} /* Line: 823*/
bevl_currentstr2 = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 826*/ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 826*/ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 828*/ {
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_strsize.bevi_int == bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 829*/ {
return bevl_current;
} /* Line: 830*/
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_ta_ph = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_ta_ph.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 836*/ {
return null;
} /* Line: 837*/
bevt_27_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_currentstr2.bevi_int = bevt_27_ta_ph.bevi_int;
while (true)
/* Line: 840*/ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 840*/ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 843*/ {
break;
} /* Line: 844*/
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 847*/
 else /* Line: 840*/ {
break;
} /* Line: 840*/
} /* Line: 840*/
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 849*/ {
return bevl_current;
} /* Line: 850*/
} /* Line: 849*/
bevl_current.bevi_int++;
} /* Line: 853*/
 else /* Line: 826*/ {
break;
} /* Line: 826*/
} /* Line: 826*/
return null;
} /*method end*/
public BEC_2_9_4_ContainerList bem_split_1(BEC_2_4_6_TextString beva_delim) throws Throwable {
BEC_2_9_4_ContainerList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevl_splits = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
/* Line: 863*/ {
if (bevl_i == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 863*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_ta_ph);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 866*/
 else /* Line: 863*/ {
break;
} /* Line: 863*/
} /* Line: 863*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 868*/ {
bevt_3_ta_ph = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 869*/
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_join_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_stri == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 887*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 887*/ {
bevt_2_ta_ph = beva_stri.bemd_1(1880525273, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 887*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 887*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 887*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 887*/ {
return null;
} /* Line: 888*/
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(-2026840142);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 892*/ {
bevl_maxsize = bevl_osize;
} /* Line: 893*/
 else /* Line: 894*/ {
bevl_maxsize = bevl_mysize;
} /* Line: 895*/
bevl_myret = (new BEC_2_4_3_MathInt());
bevl_mv = (new BEC_2_4_3_MathInt());
bevl_ov = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 900*/ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 900*/ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(-310307261, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 903*/ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 904*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(1));
return bevt_7_ta_ph;
} /* Line: 905*/
 else /* Line: 906*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(-1));
return bevt_8_ta_ph;
} /* Line: 907*/
} /* Line: 904*/
bevl_i.bevi_int++;
} /* Line: 900*/
 else /* Line: 900*/ {
break;
} /* Line: 900*/
} /* Line: 900*/
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_myret.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 911*/ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 912*/ {
bevl_myret = (new BEC_2_4_3_MathInt(1));
} /* Line: 913*/
 else /* Line: 912*/ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 914*/ {
bevl_myret = (new BEC_2_4_3_MathInt(-1));
} /* Line: 915*/
} /* Line: 912*/
} /* Line: 912*/
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 922*/ {
return null;
} /* Line: 922*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(-1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 923*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 924*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 930*/ {
return null;
} /* Line: 930*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 931*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 932*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

    BEC_2_4_6_TextString bevls_stri = (BEC_2_4_6_TextString) beva_stri;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_str);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(290193605);
bevt_1_ta_ph = bevl_str.bem_sizeGet_0();
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_ta_ph, bevp_size, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_ta_ph, bevt_5_ta_ph, bevp_size);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_create_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) throws Throwable {
BEC_2_4_3_MathInt bevl_leni = null;
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_4_3_MathInt bevl_sizi = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_7_TextStrings bevt_13_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_zeroGet_0();
if (beva_starti.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1016*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1016*/ {
bevt_5_ta_ph = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 1016*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1016*/ {
bevt_7_ta_ph = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1016*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1016*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1016*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1016*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1016*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1016*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1016*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_8_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 1017*/
 else /* Line: 1018*/ {
bevl_leni = (new BEC_2_4_3_MathInt());
bevl_leni.bevi_int = beva_endi.bevi_int;
bevl_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevl_leni;
bevl_sizi = (new BEC_2_4_3_MathInt());
bevl_sizi.bevi_int = beva_dstarti.bevi_int;
bevl_sizi.bevi_int += bevl_leni.bevi_int;
if (bevl_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1029*/ {
bem_capacitySet_1(bevl_sizi);
} /* Line: 1030*/

         //source, sourceStart, dest, destStart, length
         System.arraycopy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevl_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 1063*/ {
bevp_size.bevi_int = bevl_sizi.bevi_int;
} /* Line: 1067*/
return this;
} /* Line: 1069*/
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sizeGet_0();
bevt_0_ta_ph = bem_substring_2(beva_starti, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_2_ta_ph = beva_endi.bem_subtract_1(beva_starti);
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bevt_1_ta_ph.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevi_bytes.length - 1);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_print_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevp_size.bevi_int);
System.out.write('\n');
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_echo_0() throws Throwable {
bem_output_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_snw == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1204*/ {
bem_new_0();
} /* Line: 1205*/
 else /* Line: 1206*/ {
bevt_2_ta_ph = beva_snw.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_new_1(bevt_1_ta_ph);
bem_addValue_1(beva_snw);
} /* Line: 1208*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_strip_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevl_vb = (new BEC_2_4_3_MathInt());
bevl_ve = (new BEC_2_4_3_MathInt());
bevl_b = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_e = bevp_size.bem_subtract_1(bevt_0_ta_ph);
while (true)
/* Line: 1225*/ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1225*/ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1231*/
 else /* Line: 1225*/ {
break;
} /* Line: 1225*/
} /* Line: 1225*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_6_TextString bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_4_3_MathInt bem_capacityGetDirect_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_4_6_TextString bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {256, 257, 266, 266, 270, 270, 271, 272, 272, 273, 309, 309, 310, 312, 316, 316, 317, 317, 318, 318, 322, 322, 322, 322, 322, 322, 322, 326, 327, 331, 333, 334, 334, 335, 337, 337, 338, 338, 338, 338, 338, 338, 341, 343, 343, 343, 343, 347, 351, 355, 359, 369, 370, 371, 375, 375, 375, 376, 376, 376, 377, 377, 382, 382, 383, 383, 384, 384, 388, 389, 390, 390, 390, 390, 390, 392, 393, 394, 394, 394, 394, 394, 396, 400, 400, 400, 401, 402, 406, 407, 407, 0, 407, 407, 407, 0, 0, 408, 408, 410, 410, 414, 414, 414, 414, 415, 415, 415, 416, 416, 417, 417, 419, 419, 423, 423, 0, 423, 423, 423, 0, 0, 424, 424, 426, 426, 430, 430, 434, 435, 435, 435, 436, 437, 437, 437, 437, 437, 437, 0, 437, 437, 437, 0, 0, 0, 0, 0, 439, 439, 439, 0, 439, 439, 439, 0, 0, 440, 440, 435, 443, 443, 447, 448, 448, 448, 449, 450, 450, 450, 450, 450, 450, 0, 0, 0, 0, 450, 450, 450, 450, 450, 450, 0, 0, 0, 0, 0, 0, 450, 450, 450, 450, 450, 450, 0, 0, 0, 0, 0, 451, 451, 448, 454, 454, 458, 458, 462, 463, 463, 463, 464, 465, 465, 465, 465, 465, 465, 0, 0, 0, 466, 466, 467, 463, 473, 473, 473, 477, 478, 478, 478, 479, 480, 480, 480, 480, 480, 480, 0, 0, 0, 481, 481, 482, 478, 488, 488, 488, 493, 494, 495, 496, 497, 497, 498, 498, 499, 500, 500, 501, 501, 501, 503, 503, 505, 510, 511, 512, 513, 513, 514, 515, 515, 516, 516, 517, 518, 518, 521, 521, 521, 525, 530, 530, 531, 532, 532, 532, 533, 532, 535, 535, 536, 540, 541, 541, 542, 542, 542, 543, 544, 544, 545, 542, 548, 552, 552, 552, 556, 556, 556, 566, 566, 566, 566, 566, 0, 0, 0, 603, 605, 616, 616, 616, 616, 616, 0, 0, 0, 651, 653, 657, 657, 657, 657, 657, 0, 0, 0, 658, 663, 663, 663, 663, 663, 0, 0, 0, 664, 669, 670, 670, 671, 672, 673, 674, 674, 674, 675, 676, 676, 676, 676, 676, 676, 0, 0, 0, 0, 676, 676, 676, 676, 676, 676, 0, 0, 0, 0, 0, 0, 676, 676, 676, 676, 676, 676, 0, 0, 0, 0, 0, 677, 678, 674, 681, 682, 686, 686, 686, 687, 687, 689, 689, 786, 786, 792, 792, 792, 792, 792, 794, 794, 795, 795, 796, 796, 798, 802, 802, 802, 808, 808, 0, 808, 808, 0, 0, 0, 808, 808, 808, 0, 0, 0, 808, 808, 0, 0, 0, 808, 808, 808, 0, 0, 0, 808, 808, 808, 0, 0, 0, 808, 808, 808, 808, 0, 0, 809, 812, 813, 814, 815, 816, 816, 818, 820, 820, 820, 821, 822, 823, 825, 826, 826, 827, 828, 828, 829, 829, 829, 830, 832, 833, 834, 835, 835, 836, 836, 837, 839, 839, 840, 840, 841, 842, 843, 843, 846, 847, 849, 849, 850, 853, 855, 859, 860, 861, 862, 863, 863, 864, 864, 865, 866, 868, 868, 869, 869, 871, 875, 875, 875, 879, 887, 887, 0, 887, 0, 0, 888, 890, 891, 892, 892, 893, 895, 897, 898, 899, 900, 900, 900, 901, 902, 903, 903, 904, 904, 905, 905, 907, 907, 900, 911, 911, 911, 912, 912, 913, 914, 914, 915, 918, 922, 922, 922, 923, 923, 923, 923, 924, 924, 926, 926, 930, 930, 930, 931, 931, 931, 931, 932, 932, 934, 934, 997, 997, 1001, 1001, 1001, 1005, 1006, 1006, 1006, 1007, 1007, 1007, 1008, 1008, 1008, 1009, 1012, 1012, 1016, 1016, 1016, 1016, 0, 1016, 1016, 1016, 0, 1016, 1016, 1016, 0, 0, 0, 0, 1017, 1017, 1017, 1020, 1021, 1022, 1023, 1025, 1026, 1027, 1029, 1029, 1030, 1063, 1063, 1067, 1069, 1074, 1074, 1074, 1078, 1078, 1078, 1078, 1078, 1172, 1176, 1176, 1180, 1180, 1184, 1184, 1188, 1188, 1192, 1192, 1196, 1196, 1200, 1204, 1204, 1205, 1207, 1207, 1207, 1207, 1208, 1213, 1213, 1217, 1217, 1217, 1221, 1222, 1223, 1224, 1224, 1225, 1225, 1226, 1227, 1228, 1229, 1230, 1231, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {55, 56, 61, 62, 69, 74, 75, 78, 83, 84, 93, 98, 99, 101, 108, 109, 110, 111, 112, 113, 123, 124, 125, 126, 127, 128, 129, 133, 134, 151, 152, 153, 154, 155, 156, 161, 162, 163, 164, 165, 166, 167, 168, 170, 171, 172, 173, 177, 180, 183, 187, 198, 199, 200, 208, 209, 214, 215, 216, 217, 218, 219, 227, 228, 229, 230, 231, 232, 247, 248, 250, 251, 252, 253, 254, 256, 257, 259, 260, 261, 262, 263, 265, 271, 272, 273, 274, 275, 285, 286, 291, 292, 295, 296, 301, 302, 305, 309, 310, 312, 313, 324, 329, 330, 331, 333, 334, 335, 336, 341, 342, 343, 345, 346, 355, 360, 361, 364, 365, 370, 371, 374, 378, 379, 381, 382, 386, 387, 407, 408, 411, 416, 417, 418, 419, 424, 425, 426, 431, 432, 435, 436, 441, 442, 445, 449, 452, 456, 461, 462, 467, 468, 471, 472, 477, 478, 481, 485, 486, 489, 495, 496, 519, 520, 523, 528, 529, 530, 531, 536, 537, 538, 543, 544, 547, 551, 554, 557, 558, 563, 564, 565, 570, 571, 574, 578, 581, 584, 588, 591, 592, 597, 598, 599, 604, 605, 608, 612, 615, 618, 622, 623, 625, 631, 632, 636, 637, 649, 650, 653, 658, 659, 660, 661, 666, 667, 668, 673, 674, 677, 681, 684, 685, 686, 688, 699, 700, 701, 713, 714, 717, 722, 723, 724, 725, 730, 731, 732, 737, 738, 741, 745, 748, 749, 750, 752, 763, 764, 765, 777, 778, 779, 780, 781, 786, 787, 788, 789, 790, 791, 792, 793, 794, 797, 798, 800, 812, 813, 814, 817, 822, 823, 824, 829, 830, 831, 832, 833, 834, 837, 838, 839, 846, 856, 857, 858, 859, 862, 867, 868, 869, 875, 876, 877, 885, 886, 887, 888, 891, 896, 897, 898, 899, 900, 901, 907, 912, 913, 914, 919, 920, 921, 928, 929, 934, 935, 940, 941, 944, 948, 955, 957, 964, 965, 970, 971, 976, 977, 980, 984, 994, 996, 1003, 1004, 1009, 1010, 1015, 1016, 1019, 1023, 1026, 1035, 1036, 1041, 1042, 1047, 1048, 1051, 1055, 1058, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1095, 1100, 1101, 1102, 1103, 1108, 1109, 1110, 1115, 1116, 1119, 1123, 1126, 1129, 1130, 1135, 1136, 1137, 1142, 1143, 1146, 1150, 1153, 1156, 1160, 1163, 1164, 1169, 1170, 1171, 1176, 1177, 1180, 1184, 1187, 1190, 1194, 1195, 1197, 1203, 1204, 1211, 1212, 1217, 1218, 1219, 1221, 1222, 1240, 1241, 1252, 1253, 1254, 1255, 1256, 1257, 1262, 1263, 1264, 1265, 1266, 1268, 1273, 1274, 1275, 1318, 1323, 1324, 1327, 1332, 1333, 1336, 1340, 1343, 1344, 1349, 1350, 1353, 1357, 1360, 1365, 1366, 1369, 1373, 1376, 1377, 1382, 1383, 1386, 1390, 1393, 1394, 1399, 1400, 1403, 1407, 1410, 1411, 1412, 1417, 1418, 1421, 1425, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1440, 1441, 1442, 1443, 1445, 1448, 1453, 1454, 1455, 1460, 1461, 1462, 1467, 1468, 1470, 1471, 1472, 1473, 1474, 1475, 1480, 1481, 1483, 1484, 1487, 1492, 1493, 1494, 1495, 1500, 1503, 1504, 1510, 1515, 1516, 1519, 1525, 1536, 1537, 1538, 1539, 1542, 1547, 1548, 1549, 1550, 1551, 1557, 1562, 1563, 1564, 1566, 1571, 1572, 1573, 1576, 1599, 1604, 1605, 1608, 1610, 1613, 1617, 1619, 1620, 1621, 1626, 1627, 1630, 1632, 1633, 1634, 1635, 1638, 1643, 1644, 1645, 1646, 1651, 1652, 1657, 1658, 1659, 1662, 1663, 1666, 1672, 1673, 1678, 1679, 1684, 1685, 1688, 1693, 1694, 1698, 1707, 1712, 1713, 1715, 1716, 1717, 1722, 1723, 1724, 1726, 1727, 1736, 1741, 1742, 1744, 1745, 1746, 1751, 1752, 1753, 1755, 1756, 1770, 1771, 1776, 1777, 1782, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1800, 1801, 1802, 1803, 1807, 1808, 1828, 1829, 1830, 1835, 1836, 1839, 1840, 1845, 1846, 1849, 1850, 1855, 1856, 1859, 1863, 1866, 1870, 1871, 1872, 1875, 1876, 1877, 1878, 1879, 1880, 1881, 1882, 1887, 1888, 1893, 1898, 1899, 1901, 1907, 1908, 1909, 1916, 1917, 1918, 1919, 1920, 1934, 1939, 1940, 1944, 1945, 1949, 1950, 1954, 1955, 1959, 1960, 1964, 1965, 1968, 1975, 1980, 1981, 1984, 1985, 1986, 1987, 1988, 1994, 1995, 2000, 2001, 2002, 2011, 2012, 2013, 2014, 2015, 2018, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2038, 2041, 2044, 2048, 2052, 2055, 2058};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 256 55
new 0 256 55
capacitySet 1 257 56
assign 1 266 61
new 0 266 61
new 1 266 62
assign 1 270 69
undef 1 270 74
assign 1 271 75
new 0 271 75
assign 1 272 78
equals 1 272 83
return 1 273 84
assign 1 309 93
greater 1 309 98
setValue 1 310 99
setValue 1 312 101
assign 1 316 108
new 0 316 108
new 1 316 109
assign 1 317 110
new 0 317 110
setValue 1 317 111
assign 1 318 112
new 0 318 112
setHex 2 318 113
assign 1 322 123
new 0 322 123
assign 1 322 124
getCode 2 322 124
assign 1 322 125
new 0 322 125
assign 1 322 126
new 0 322 126
assign 1 322 127
new 0 322 127
assign 1 322 128
toString 3 322 128
return 1 322 129
assign 1 326 133
hexNew 1 326 133
setCode 2 327 134
assign 1 331 151
toString 0 331 151
assign 1 333 152
new 0 333 152
assign 1 334 153
sizeGet 0 334 153
setValue 1 334 154
addValue 1 335 155
assign 1 337 156
lesser 1 337 161
assign 1 338 162
new 0 338 162
assign 1 338 163
add 1 338 163
assign 1 338 164
new 0 338 164
assign 1 338 165
multiply 1 338 165
assign 1 338 166
new 0 338 166
assign 1 338 167
divide 1 338 167
capacitySet 1 341 168
assign 1 343 170
new 0 343 170
assign 1 343 171
zeroGet 0 343 171
assign 1 343 172
sizeGet 0 343 172
copyValue 4 343 173
return 1 347 177
return 1 351 180
addValue 1 355 183
write 1 359 187
assign 1 369 198
copy 0 369 198
clear 0 370 199
return 1 371 200
assign 1 375 208
new 0 375 208
assign 1 375 209
greater 1 375 214
assign 1 376 215
new 0 376 215
assign 1 376 216
new 0 376 216
setIntUnchecked 2 376 217
assign 1 377 218
new 0 377 218
setValue 1 377 219
assign 1 382 227
new 0 382 227
new 1 382 228
assign 1 383 229
new 0 383 229
setValue 1 383 230
assign 1 384 231
new 0 384 231
setCodeUnchecked 2 384 232
assign 1 388 247
new 0 388 247
assign 1 389 248
ends 1 389 248
assign 1 390 250
new 0 390 250
assign 1 390 251
sizeGet 0 390 251
assign 1 390 252
subtract 1 390 252
assign 1 390 253
substring 2 390 253
return 1 390 254
assign 1 392 256
new 0 392 256
assign 1 393 257
ends 1 393 257
assign 1 394 259
new 0 394 259
assign 1 394 260
sizeGet 0 394 260
assign 1 394 261
subtract 1 394 261
assign 1 394 262
substring 2 394 262
return 1 394 263
return 1 396 265
assign 1 400 271
new 0 400 271
assign 1 400 272
add 1 400 272
assign 1 400 273
new 1 400 273
addValue 1 401 274
return 1 402 275
assign 1 406 285
find 1 406 285
assign 1 407 286
undef 1 407 291
assign 1 0 292
assign 1 407 295
new 0 407 295
assign 1 407 296
notEquals 1 407 301
assign 1 0 302
assign 1 0 305
assign 1 408 309
new 0 408 309
return 1 408 310
assign 1 410 312
new 0 410 312
return 1 410 313
assign 1 414 324
undef 1 414 329
assign 1 414 330
new 0 414 330
return 1 414 331
assign 1 415 333
sizeGet 0 415 333
assign 1 415 334
subtract 1 415 334
assign 1 415 335
find 2 415 335
assign 1 416 336
undef 1 416 341
assign 1 417 342
new 0 417 342
return 1 417 343
assign 1 419 345
new 0 419 345
return 1 419 346
assign 1 423 355
undef 1 423 360
assign 1 0 361
assign 1 423 364
find 1 423 364
assign 1 423 365
undef 1 423 370
assign 1 0 371
assign 1 0 374
assign 1 424 378
new 0 424 378
return 1 424 379
assign 1 426 381
new 0 426 381
return 1 426 382
assign 1 430 386
isInteger 0 430 386
return 1 430 387
assign 1 434 407
new 0 434 407
assign 1 435 408
new 0 435 408
assign 1 435 411
lesser 1 435 416
getInt 2 436 417
assign 1 437 418
new 0 437 418
assign 1 437 419
equals 1 437 424
assign 1 437 425
new 0 437 425
assign 1 437 426
equals 1 437 431
assign 1 0 432
assign 1 437 435
new 0 437 435
assign 1 437 436
equals 1 437 441
assign 1 0 442
assign 1 0 445
assign 1 0 449
assign 1 0 452
assign 1 0 456
assign 1 439 461
new 0 439 461
assign 1 439 462
greater 1 439 467
assign 1 0 468
assign 1 439 471
new 0 439 471
assign 1 439 472
lesser 1 439 477
assign 1 0 478
assign 1 0 481
assign 1 440 485
new 0 440 485
return 1 440 486
incrementValue 0 435 489
assign 1 443 495
new 0 443 495
return 1 443 496
assign 1 447 519
new 0 447 519
assign 1 448 520
new 0 448 520
assign 1 448 523
lesser 1 448 528
getInt 2 449 529
assign 1 450 530
new 0 450 530
assign 1 450 531
greater 1 450 536
assign 1 450 537
new 0 450 537
assign 1 450 538
lesser 1 450 543
assign 1 0 544
assign 1 0 547
assign 1 0 551
assign 1 0 554
assign 1 450 557
new 0 450 557
assign 1 450 558
greater 1 450 563
assign 1 450 564
new 0 450 564
assign 1 450 565
lesser 1 450 570
assign 1 0 571
assign 1 0 574
assign 1 0 578
assign 1 0 581
assign 1 0 584
assign 1 0 588
assign 1 450 591
new 0 450 591
assign 1 450 592
greater 1 450 597
assign 1 450 598
new 0 450 598
assign 1 450 599
lesser 1 450 604
assign 1 0 605
assign 1 0 608
assign 1 0 612
assign 1 0 615
assign 1 0 618
assign 1 451 622
new 0 451 622
return 1 451 623
incrementValue 0 448 625
assign 1 454 631
new 0 454 631
return 1 454 632
assign 1 458 636
isAlphaNumGet 0 458 636
return 1 458 637
assign 1 462 649
new 0 462 649
assign 1 463 650
new 0 463 650
assign 1 463 653
lesser 1 463 658
getInt 2 464 659
assign 1 465 660
new 0 465 660
assign 1 465 661
greater 1 465 666
assign 1 465 667
new 0 465 667
assign 1 465 668
lesser 1 465 673
assign 1 0 674
assign 1 0 677
assign 1 0 681
assign 1 466 684
new 0 466 684
addValue 1 466 685
setIntUnchecked 2 467 686
incrementValue 0 463 688
assign 1 473 699
copy 0 473 699
assign 1 473 700
lowerValue 0 473 700
return 1 473 701
assign 1 477 713
new 0 477 713
assign 1 478 714
new 0 478 714
assign 1 478 717
lesser 1 478 722
getInt 2 479 723
assign 1 480 724
new 0 480 724
assign 1 480 725
greater 1 480 730
assign 1 480 731
new 0 480 731
assign 1 480 732
lesser 1 480 737
assign 1 0 738
assign 1 0 741
assign 1 0 745
assign 1 481 748
new 0 481 748
subtractValue 1 481 749
setIntUnchecked 2 482 750
incrementValue 0 478 752
assign 1 488 763
copy 0 488 763
assign 1 488 764
upperValue 0 488 764
return 1 488 765
assign 1 493 777
new 0 493 777
assign 1 494 778
new 0 494 778
assign 1 495 779
new 0 495 779
assign 1 496 780
find 2 496 780
assign 1 497 781
def 1 497 786
assign 1 498 787
substring 2 498 787
addValue 1 498 788
addValue 1 499 789
assign 1 500 790
sizeGet 0 500 790
assign 1 500 791
add 1 500 791
assign 1 501 792
sizeGet 0 501 792
assign 1 501 793
substring 2 501 793
addValue 1 501 794
assign 1 503 797
copy 0 503 797
return 1 503 798
return 1 505 800
assign 1 510 812
new 0 510 812
assign 1 511 813
new 0 511 813
assign 1 512 814
new 0 512 814
assign 1 513 817
def 1 513 822
assign 1 514 823
find 2 514 823
assign 1 515 824
def 1 515 829
assign 1 516 830
substring 2 516 830
addValue 1 516 831
addValue 1 517 832
assign 1 518 833
sizeGet 0 518 833
assign 1 518 834
add 1 518 834
assign 1 521 837
sizeGet 0 521 837
assign 1 521 838
substring 2 521 838
addValue 1 521 839
return 1 525 846
assign 1 530 856
new 0 530 856
assign 1 530 857
new 1 530 857
assign 1 531 858
mbiterGet 0 531 858
assign 1 532 859
new 0 532 859
assign 1 532 862
lesser 1 532 867
next 1 533 868
incrementValue 0 532 869
assign 1 535 875
next 1 535 875
assign 1 535 876
toString 0 535 876
return 1 536 877
assign 1 540 885
new 0 540 885
assign 1 541 886
new 0 541 886
setValue 1 541 887
assign 1 542 888
new 0 542 888
assign 1 542 891
lesser 1 542 896
getInt 2 543 897
assign 1 544 898
new 0 544 898
multiplyValue 1 544 899
addValue 1 545 900
incrementValue 0 542 901
return 1 548 907
assign 1 552 912
new 0 552 912
assign 1 552 913
hashValue 1 552 913
return 1 552 914
assign 1 556 919
new 0 556 919
assign 1 556 920
getCode 2 556 920
return 1 556 921
assign 1 566 928
new 0 566 928
assign 1 566 929
greaterEquals 1 566 934
assign 1 566 935
greater 1 566 940
assign 1 0 941
assign 1 0 944
assign 1 0 948
return 1 603 955
return 1 605 957
assign 1 616 964
new 0 616 964
assign 1 616 965
greaterEquals 1 616 970
assign 1 616 971
greater 1 616 976
assign 1 0 977
assign 1 0 980
assign 1 0 984
return 1 651 994
return 1 653 996
assign 1 657 1003
new 0 657 1003
assign 1 657 1004
greaterEquals 1 657 1009
assign 1 657 1010
greater 1 657 1015
assign 1 0 1016
assign 1 0 1019
assign 1 0 1023
setIntUnchecked 2 658 1026
assign 1 663 1035
new 0 663 1035
assign 1 663 1036
greaterEquals 1 663 1041
assign 1 663 1042
greater 1 663 1047
assign 1 0 1048
assign 1 0 1051
assign 1 0 1055
setCodeUnchecked 2 664 1058
assign 1 669 1086
assign 1 670 1087
sizeGet 0 670 1087
assign 1 670 1088
copy 0 670 1088
assign 1 671 1089
new 1 671 1089
assign 1 672 1090
new 0 672 1090
assign 1 673 1091
new 0 673 1091
assign 1 674 1092
new 0 674 1092
assign 1 674 1095
lesser 1 674 1100
getInt 2 675 1101
assign 1 676 1102
new 0 676 1102
assign 1 676 1103
greater 1 676 1108
assign 1 676 1109
new 0 676 1109
assign 1 676 1110
lesser 1 676 1115
assign 1 0 1116
assign 1 0 1119
assign 1 0 1123
assign 1 0 1126
assign 1 676 1129
new 0 676 1129
assign 1 676 1130
greater 1 676 1135
assign 1 676 1136
new 0 676 1136
assign 1 676 1137
lesser 1 676 1142
assign 1 0 1143
assign 1 0 1146
assign 1 0 1150
assign 1 0 1153
assign 1 0 1156
assign 1 0 1160
assign 1 676 1163
new 0 676 1163
assign 1 676 1164
greater 1 676 1169
assign 1 676 1170
new 0 676 1170
assign 1 676 1171
lesser 1 676 1176
assign 1 0 1177
assign 1 0 1180
assign 1 0 1184
assign 1 0 1187
assign 1 0 1190
setIntUnchecked 2 677 1194
incrementValue 0 678 1195
incrementValue 0 674 1197
sizeSet 1 681 1203
return 1 682 1204
assign 1 686 1211
new 0 686 1211
assign 1 686 1212
lesserEquals 1 686 1217
assign 1 687 1218
new 0 687 1218
return 1 687 1219
assign 1 689 1221
new 0 689 1221
return 1 689 1222
assign 1 786 1240
rfind 1 786 1240
return 1 786 1241
assign 1 792 1252
copy 0 792 1252
assign 1 792 1253
reverseBytes 0 792 1253
assign 1 792 1254
copy 0 792 1254
assign 1 792 1255
reverseBytes 0 792 1255
assign 1 792 1256
find 1 792 1256
assign 1 794 1257
def 1 794 1262
assign 1 795 1263
sizeGet 0 795 1263
addValue 1 795 1264
assign 1 796 1265
subtract 1 796 1265
return 1 796 1266
return 1 798 1268
assign 1 802 1273
new 0 802 1273
assign 1 802 1274
find 2 802 1274
return 1 802 1275
assign 1 808 1318
undef 1 808 1323
assign 1 0 1324
assign 1 808 1327
undef 1 808 1332
assign 1 0 1333
assign 1 0 1336
assign 1 0 1340
assign 1 808 1343
new 0 808 1343
assign 1 808 1344
lesser 1 808 1349
assign 1 0 1350
assign 1 0 1353
assign 1 0 1357
assign 1 808 1360
greaterEquals 1 808 1365
assign 1 0 1366
assign 1 0 1369
assign 1 0 1373
assign 1 808 1376
sizeGet 0 808 1376
assign 1 808 1377
greater 1 808 1382
assign 1 0 1383
assign 1 0 1386
assign 1 0 1390
assign 1 808 1393
new 0 808 1393
assign 1 808 1394
equals 1 808 1399
assign 1 0 1400
assign 1 0 1403
assign 1 0 1407
assign 1 808 1410
sizeGet 0 808 1410
assign 1 808 1411
new 0 808 1411
assign 1 808 1412
equals 1 808 1417
assign 1 0 1418
assign 1 0 1421
return 1 809 1425
assign 1 812 1427
assign 1 813 1428
copy 0 813 1428
assign 1 814 1429
new 0 814 1429
assign 1 815 1430
new 0 815 1430
assign 1 816 1431
new 0 816 1431
getInt 2 816 1432
assign 1 818 1433
sizeGet 0 818 1433
assign 1 820 1434
new 0 820 1434
assign 1 820 1435
greater 1 820 1440
assign 1 821 1441
new 0 821 1441
assign 1 822 1442
new 0 822 1442
assign 1 823 1443
new 0 823 1443
assign 1 825 1445
new 0 825 1445
assign 1 826 1448
lesser 1 826 1453
getInt 2 827 1454
assign 1 828 1455
equals 1 828 1460
assign 1 829 1461
new 0 829 1461
assign 1 829 1462
equals 1 829 1467
return 1 830 1468
setValue 1 832 1470
incrementValue 0 833 1471
setValue 1 834 1472
assign 1 835 1473
sizeGet 0 835 1473
addValue 1 835 1474
assign 1 836 1475
greater 1 836 1480
return 1 837 1481
assign 1 839 1483
new 0 839 1483
setValue 1 839 1484
assign 1 840 1487
lesser 1 840 1492
getInt 2 841 1493
getInt 2 842 1494
assign 1 843 1495
notEquals 1 843 1500
incrementValue 0 846 1503
incrementValue 0 847 1504
assign 1 849 1510
equals 1 849 1515
return 1 850 1516
incrementValue 0 853 1519
return 1 855 1525
assign 1 859 1536
new 0 859 1536
assign 1 860 1537
new 0 860 1537
assign 1 861 1538
find 2 861 1538
assign 1 862 1539
sizeGet 0 862 1539
assign 1 863 1542
def 1 863 1547
assign 1 864 1548
substring 2 864 1548
addValue 1 864 1549
assign 1 865 1550
add 1 865 1550
assign 1 866 1551
find 2 866 1551
assign 1 868 1557
lesser 1 868 1562
assign 1 869 1563
substring 2 869 1563
addValue 1 869 1564
return 1 871 1566
assign 1 875 1571
new 0 875 1571
assign 1 875 1572
join 2 875 1572
return 1 875 1573
return 1 879 1576
assign 1 887 1599
undef 1 887 1604
assign 1 0 1605
assign 1 887 1608
otherType 1 887 1608
assign 1 0 1610
assign 1 0 1613
return 1 888 1617
assign 1 890 1619
assign 1 891 1620
sizeGet 0 891 1620
assign 1 892 1621
greater 1 892 1626
assign 1 893 1627
assign 1 895 1630
assign 1 897 1632
new 0 897 1632
assign 1 898 1633
new 0 898 1633
assign 1 899 1634
new 0 899 1634
assign 1 900 1635
new 0 900 1635
assign 1 900 1638
lesser 1 900 1643
getCode 2 901 1644
getCode 2 902 1645
assign 1 903 1646
notEquals 1 903 1651
assign 1 904 1652
greater 1 904 1657
assign 1 905 1658
new 0 905 1658
return 1 905 1659
assign 1 907 1662
new 0 907 1662
return 1 907 1663
incrementValue 0 900 1666
assign 1 911 1672
new 0 911 1672
assign 1 911 1673
equals 1 911 1678
assign 1 912 1679
greater 1 912 1684
assign 1 913 1685
new 0 913 1685
assign 1 914 1688
greater 1 914 1693
assign 1 915 1694
new 0 915 1694
return 1 918 1698
assign 1 922 1707
undef 1 922 1712
return 1 922 1713
assign 1 923 1715
compare 1 923 1715
assign 1 923 1716
new 0 923 1716
assign 1 923 1717
equals 1 923 1722
assign 1 924 1723
new 0 924 1723
return 1 924 1724
assign 1 926 1726
new 0 926 1726
return 1 926 1727
assign 1 930 1736
undef 1 930 1741
return 1 930 1742
assign 1 931 1744
compare 1 931 1744
assign 1 931 1745
new 0 931 1745
assign 1 931 1746
equals 1 931 1751
assign 1 932 1752
new 0 932 1752
return 1 932 1753
assign 1 934 1755
new 0 934 1755
return 1 934 1756
assign 1 997 1770
new 0 997 1770
return 1 997 1771
assign 1 1001 1776
equals 1 1001 1776
assign 1 1001 1777
not 0 1001 1782
return 1 1001 1782
assign 1 1005 1793
toString 0 1005 1793
assign 1 1006 1794
sizeGet 0 1006 1794
assign 1 1006 1795
add 1 1006 1795
assign 1 1006 1796
new 1 1006 1796
assign 1 1007 1797
new 0 1007 1797
assign 1 1007 1798
new 0 1007 1798
copyValue 4 1007 1799
assign 1 1008 1800
new 0 1008 1800
assign 1 1008 1801
sizeGet 0 1008 1801
copyValue 4 1008 1802
return 1 1009 1803
assign 1 1012 1807
new 0 1012 1807
return 1 1012 1808
assign 1 1016 1828
new 0 1016 1828
assign 1 1016 1829
zeroGet 0 1016 1829
assign 1 1016 1830
lesser 1 1016 1835
assign 1 0 1836
assign 1 1016 1839
sizeGet 0 1016 1839
assign 1 1016 1840
greater 1 1016 1845
assign 1 0 1846
assign 1 1016 1849
sizeGet 0 1016 1849
assign 1 1016 1850
greater 1 1016 1855
assign 1 0 1856
assign 1 0 1859
assign 1 0 1863
assign 1 0 1866
assign 1 1017 1870
new 0 1017 1870
assign 1 1017 1871
new 1 1017 1871
throw 1 1017 1872
assign 1 1020 1875
new 0 1020 1875
setValue 1 1021 1876
subtractValue 1 1022 1877
assign 1 1023 1878
assign 1 1025 1879
new 0 1025 1879
setValue 1 1026 1880
addValue 1 1027 1881
assign 1 1029 1882
greater 1 1029 1887
capacitySet 1 1030 1888
assign 1 1063 1893
greater 1 1063 1898
setValue 1 1067 1899
return 1 1069 1901
assign 1 1074 1907
sizeGet 0 1074 1907
assign 1 1074 1908
substring 2 1074 1908
return 1 1074 1909
assign 1 1078 1916
subtract 1 1078 1916
assign 1 1078 1917
new 1 1078 1917
assign 1 1078 1918
new 0 1078 1918
assign 1 1078 1919
copyValue 4 1078 1919
return 1 1078 1920
output 0 1172 1934
assign 1 1176 1939
new 1 1176 1939
return 1 1176 1940
assign 1 1180 1944
new 1 1180 1944
return 1 1180 1945
assign 1 1184 1949
new 1 1184 1949
return 1 1184 1950
assign 1 1188 1954
new 1 1188 1954
return 1 1188 1955
assign 1 1192 1959
new 1 1192 1959
return 1 1192 1960
assign 1 1196 1964
new 1 1196 1964
return 1 1196 1965
return 1 1200 1968
assign 1 1204 1975
undef 1 1204 1980
new 0 1205 1981
assign 1 1207 1984
sizeGet 0 1207 1984
assign 1 1207 1985
new 0 1207 1985
assign 1 1207 1986
add 1 1207 1986
new 1 1207 1987
addValue 1 1208 1988
assign 1 1213 1994
new 0 1213 1994
return 1 1213 1995
assign 1 1217 2000
new 0 1217 2000
assign 1 1217 2001
strip 1 1217 2001
return 1 1217 2002
assign 1 1221 2011
new 0 1221 2011
assign 1 1222 2012
new 0 1222 2012
assign 1 1223 2013
new 0 1223 2013
assign 1 1224 2014
new 0 1224 2014
assign 1 1224 2015
subtract 1 1224 2015
assign 1 1225 2018
greater 1 1225 2023
getInt 2 1226 2024
getInt 2 1227 2025
setInt 2 1228 2026
setInt 2 1229 2027
incrementValue 0 1230 2028
decrementValue 0 1231 2029
return 1 0 2038
return 1 0 2041
assign 1 0 2044
assign 1 0 2048
return 1 0 2052
return 1 0 2055
assign 1 0 2058
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -510935436: return bem_output_0();
case -1018964112: return bem_readBuffer_0();
case 2123497935: return bem_stringIteratorGet_0();
case 436036034: return bem_sizeGetDirect_0();
case -129556018: return bem_fieldNamesGet_0();
case 715553388: return bem_serializationIteratorGet_0();
case -1915513690: return bem_classNameGet_0();
case 1534778339: return bem_serializeContents_0();
case -1436937159: return bem_readString_0();
case 1057028028: return bem_fieldIteratorGet_0();
case 168452264: return bem_upperValue_0();
case -1171157816: return bem_lower_0();
case 1793746706: return bem_capacityGetDirect_0();
case 198473032: return bem_tagGet_0();
case 1594353291: return bem_isEmptyGet_0();
case 271125264: return bem_upper_0();
case -49011070: return bem_chomp_0();
case -1931403512: return bem_toAlphaNum_0();
case -566589302: return bem_multiByteIteratorGet_0();
case 708488762: return bem_create_0();
case 306888733: return bem_reverseBytes_0();
case 290193605: return bem_toString_0();
case 580248377: return bem_clear_0();
case 1528097206: return bem_serializeToString_0();
case 807844599: return bem_copy_0();
case -1781364078: return bem_print_0();
case 210349252: return bem_deserializeClassNameGet_0();
case -649614617: return bem_biterGet_0();
case -360167388: return bem_byteIteratorGet_0();
case 705182450: return bem_extractString_0();
case -481010431: return bem_mbiterGet_0();
case 1981112113: return bem_isAlphaNumGet_0();
case 428447159: return bem_close_0();
case 886843570: return bem_open_0();
case 1963419455: return bem_isIntegerGet_0();
case -1902821230: return bem_sourceFileNameGet_0();
case 142822222: return bem_lowerValue_0();
case 1665087202: return bem_isInteger_0();
case -2026840142: return bem_sizeGet_0();
case -450907329: return bem_iteratorGet_0();
case -66588780: return bem_isAlphaNumericGet_0();
case -436514878: return bem_echo_0();
case -935206158: return bem_capacityGet_0();
case -310473603: return bem_strip_0();
case 1812136083: return bem_vstringGet_0();
case -1895047759: return bem_vstringSet_0();
case 1476572399: return bem_new_0();
case 1604055525: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1794607352: return bem_writeTo_1(bevd_0);
case 1880525273: return bem_otherType_1(bevd_0);
case 1282465310: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case -500840024: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -999927226: return bem_notEquals_1(bevd_0);
case -1865008630: return bem_equals_1(bevd_0);
case 355611843: return bem_addValue_1(bevd_0);
case 1141872328: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1908723776: return bem_capacitySetDirect_1(bevd_0);
case 1675176426: return bem_compare_1(bevd_0);
case -969395710: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 554906044: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case -2131850952: return bem_sizeSet_1(bevd_0);
case -1095722748: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case 909428606: return bem_otherClass_1(bevd_0);
case -1689452364: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 1528010380: return bem_sameClass_1(bevd_0);
case -1428889801: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -1606202955: return bem_copyTo_1(bevd_0);
case 938863663: return bem_def_1(bevd_0);
case 1228290552: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -2017423289: return bem_codeNew_1(bevd_0);
case 1975331476: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 1576967936: return bem_add_1(bevd_0);
case -1408314939: return bem_sizeSetDirect_1(bevd_0);
case -1887482375: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -575460023: return bem_sameType_1(bevd_0);
case -224368598: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case 591001313: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1859153072: return bem_undef_1(bevd_0);
case 1342151407: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -746609219: return bem_sameObject_1(bevd_0);
case -1768944168: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -73400120: return bem_write_1(bevd_0);
case 1361956409: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case -1077353241: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case -835119407: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -802294345: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 1516460726: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -310307261: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953140974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1582482490: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 506082618: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1357885285: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1658140700: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 913894431: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -297145767: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1983033893: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -857389255: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2010603536: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2093057752: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 668559710: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1676629012: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -430490240: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1393048879: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1978405023: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1450832316: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_TextString();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
