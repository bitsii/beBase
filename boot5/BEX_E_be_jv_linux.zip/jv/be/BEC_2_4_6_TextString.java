package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_6_TextString extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) {
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) {
      //do copy, isOnce
      this.bevi_bytes = new byte[bevi_length];
      System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
      bevp_size = new BEC_2_4_3_MathInt(bevi_length);
      bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) {
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(String bevi_string) throws Exception {
        byte[] bevi_bytes = bevi_string.getBytes("UTF-8");
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public String bems_toJvString() throws Exception {
        String jvString = new String(bevi_bytes, 0, bevp_size.bevi_int, "UTF-8");
        return jvString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
public static BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_6_TextString bem_vstringGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_capacity == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 258*/ {
bevp_capacity = (new BEC_2_4_3_MathInt(0));
} /* Line: 259*/
 else /* Line: 258*/ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 260*/ {
return this;
} /* Line: 261*/
} /* Line: 258*/

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        this.bevi_bytes = java.util.Arrays.copyOf(this.bevi_bytes, beva_ncap.bevi_int);
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 297*/ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 298*/
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setHex_2(bevt_2_ta_ph, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt());
bevt_1_ta_ph = bem_getCode_2(beva_pos, bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_toString_3(bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) throws Throwable {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_sizi = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_7_TextStrings bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1769965429);
bevl_sizi = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bevl_str.bem_sizeGet_0();
bevl_sizi.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevl_sizi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 325*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_3_ta_ph = bevl_sizi.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_2_ta_ph = bevt_3_ta_ph.bem_multiply_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_nsize = bevt_2_ta_ph.bem_divide_1(bevt_6_ta_ph);
bem_capacitySet_1(bevl_nsize);
} /* Line: 329*/
bevt_8_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_7_ta_ph = bevt_8_ta_ph.bem_zeroGet_0();
bevt_9_ta_ph = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_7_ta_ph, bevt_9_ta_ph, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) throws Throwable {
beva_w.bemd_1(-1748701226, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 363*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setIntUnchecked_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_size.bevi_int = bevt_4_ta_ph.bevi_int;
} /* Line: 365*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setCodeUnchecked_2(bevt_2_ta_ph, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() throws Throwable {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_nl = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_0_ta_ph = bem_ends_1(bevl_nl);
if (bevt_0_ta_ph.bevi_bool)/* Line: 377*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_3_ta_ph = bevp_size.bem_subtract_1(bevt_4_ta_ph);
bevt_1_ta_ph = bem_substring_2(bevt_2_ta_ph, bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 378*/
bevl_nl = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_5_ta_ph = bem_ends_1(bevl_nl);
if (bevt_5_ta_ph.bevi_bool)/* Line: 381*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_8_ta_ph = bevp_size.bem_subtract_1(bevt_9_ta_ph);
bevt_6_ta_ph = bem_substring_2(bevt_7_ta_ph, bevt_8_ta_ph);
return bevt_6_ta_ph;
} /* Line: 382*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_copy_0() throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_c = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_c.bem_addValue_1(this);
return (BEC_2_4_6_TextString) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 395*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 395*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_found.bevi_int != bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 395*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 395*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 395*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 395*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 396*/
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 402*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 402*/
bevt_3_ta_ph = beva_str.bem_sizeGet_0();
bevt_2_ta_ph = bevp_size.bem_subtract_1(bevt_3_ta_ph);
bevl_found = bem_find_2(beva_str, bevt_2_ta_ph);
if (bevl_found == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 404*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 405*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 411*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 411*/ {
bevt_3_ta_ph = bem_find_1(beva_str);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 411*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 411*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 411*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 411*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 412*/
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isIntegerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isInteger_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 423*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 423*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 425*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 425*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 425*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 425*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 425*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 425*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 425*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 425*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 425*/
 else /* Line: 425*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 425*/ {
} /* Line: 425*/
 else /* Line: 425*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(57));
if (bevl_ic.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 427*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 427*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(48));
if (bevl_ic.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 427*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 427*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 427*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 427*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 428*/
} /* Line: 425*/
bevl_j.bevi_int++;
} /* Line: 423*/
 else /* Line: 423*/ {
break;
} /* Line: 423*/
} /* Line: 423*/
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 436*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 436*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ic.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 438*/
 else /* Line: 438*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_ic.bevi_int < bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 438*/
 else /* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 438*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 438*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ic.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 438*/
 else /* Line: 438*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 438*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 438*/
if (!(bevt_0_ta_anchor.bevi_bool))/* Line: 438*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 439*/
bevl_j.bevi_int++;
} /* Line: 436*/
 else /* Line: 436*/ {
break;
} /* Line: 436*/
} /* Line: 436*/
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumericGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAlphaNumGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 451*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 451*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 453*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 453*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 453*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 453*/
 else /* Line: 453*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 453*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_ta_ph.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 455*/
bevl_j.bevi_int++;
} /* Line: 451*/
 else /* Line: 451*/ {
break;
} /* Line: 451*/
} /* Line: 451*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_lowerValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 466*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 466*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 468*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 468*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 468*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 468*/
 else /* Line: 468*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 468*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_ta_ph);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 470*/
bevl_j.bevi_int++;
} /* Line: 466*/
 else /* Line: 466*/ {
break;
} /* Line: 466*/
} /* Line: 466*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_upperValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 485*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_2_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = bem_sizeGet_0();
bevt_3_ta_ph = bem_substring_2(bevl_last, bevt_4_ta_ph);
bevl_res.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 489*/
 else /* Line: 490*/ {
bevt_5_ta_ph = beva_from.bem_copy_0();
return bevt_5_ta_ph;
} /* Line: 491*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 501*/ {
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 501*/ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 503*/ {
bevt_2_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_3_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_ta_ph);
} /* Line: 506*/
 else /* Line: 508*/ {
bevt_5_ta_ph = bem_sizeGet_0();
bevt_4_ta_ph = bem_substring_2(bevl_last, bevt_5_ta_ph);
bevl_res.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 509*/
} /* Line: 503*/
 else /* Line: 501*/ {
break;
} /* Line: 501*/
} /* Line: 501*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_j = bem_mbiterGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 520*/ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 520*/ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 520*/
 else /* Line: 520*/ {
break;
} /* Line: 520*/
} /* Line: 520*/
bevt_2_ta_ph = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_ta_ph.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 530*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 530*/ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_ta_ph);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 530*/
 else /* Line: 530*/ {
break;
} /* Line: 530*/
} /* Line: 530*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_hashValue_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getCode_2(beva_pos, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 554*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 554*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 554*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 554*/
 else /* Line: 554*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 554*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 582*/
 else /* Line: 590*/ {
return null;
} /* Line: 591*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 604*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 604*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 604*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 604*/
 else /* Line: 604*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 604*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int < 0) {
            beva_into.bevi_int += 256;
         }
         } /* Line: 633*/
 else /* Line: 638*/ {
return null;
} /* Line: 639*/
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 645*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 645*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 645*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 645*/
 else /* Line: 645*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 645*/ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 646*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 651*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 651*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 651*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 651*/
 else /* Line: 651*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 651*/ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 652*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() throws Throwable {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevl_input = this;
bevt_3_ta_ph = bevl_input.bem_sizeGet_0();
bevl_insz = bevt_3_ta_ph.bem_copy_0();
bevl_output = (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (new BEC_2_4_3_MathInt());
bevl_p = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 662*/ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 662*/ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_c.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 664*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_c.bevi_int < bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 664*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 664*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 664*/
 else /* Line: 664*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 664*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 664*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_c.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 664*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_c.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 664*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 664*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 664*/
 else /* Line: 664*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 664*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 664*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 664*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 664*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 664*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_c.bevi_int > bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 664*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_c.bevi_int < bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 664*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 664*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 664*/
 else /* Line: 664*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 664*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 664*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 664*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 664*/ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 666*/
bevl_i.bevi_int++;
} /* Line: 662*/
 else /* Line: 662*/ {
break;
} /* Line: 662*/
} /* Line: 662*/
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 674*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 675*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b > 127) {
        twvls_b -= 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_rfind_1(beva_str);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_reverseBytes_0();
bevt_3_ta_ph = beva_str.bem_copy_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_reverseBytes_0();
bevl_rpos = bevt_0_ta_ph.bem_find_1(bevt_2_ta_ph);
if (bevl_rpos == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 782*/ {
bevt_5_ta_ph = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_ta_ph.bevi_int;
bevt_6_ta_ph = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_ta_ph;
} /* Line: 784*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_find_2(beva_str, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
if (beva_str == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 796*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
if (beva_start == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 796*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 796*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 796*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_start.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 796*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 796*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 796*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 796*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 796*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 796*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_12_ta_ph = beva_str.bem_sizeGet_0();
if (bevt_12_ta_ph.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 796*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 796*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 796*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 796*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 796*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 796*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_16_ta_ph = beva_str.bem_sizeGet_0();
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 796*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 796*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 796*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 796*/ {
return null;
} /* Line: 797*/
bevl_end = bevp_size;
bevl_current = beva_start.bem_copy_0();
bevl_myval = (new BEC_2_4_3_MathInt());
bevl_strfirst = (new BEC_2_4_3_MathInt());
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_ta_ph, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_strsize.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 808*/ {
bevl_strval = (new BEC_2_4_3_MathInt());
bevl_current2 = (new BEC_2_4_3_MathInt());
bevl_end2 = (new BEC_2_4_3_MathInt());
} /* Line: 811*/
bevl_currentstr2 = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 814*/ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 814*/ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 816*/ {
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_strsize.bevi_int == bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 817*/ {
return bevl_current;
} /* Line: 818*/
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_ta_ph = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_ta_ph.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 824*/ {
return null;
} /* Line: 825*/
bevt_27_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_currentstr2.bevi_int = bevt_27_ta_ph.bevi_int;
while (true)
/* Line: 828*/ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 828*/ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 831*/ {
break;
} /* Line: 832*/
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 835*/
 else /* Line: 828*/ {
break;
} /* Line: 828*/
} /* Line: 828*/
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 837*/ {
return bevl_current;
} /* Line: 838*/
} /* Line: 837*/
bevl_current.bevi_int++;
} /* Line: 841*/
 else /* Line: 814*/ {
break;
} /* Line: 814*/
} /* Line: 814*/
return null;
} /*method end*/
public BEC_2_9_4_ContainerList bem_split_1(BEC_2_4_6_TextString beva_delim) throws Throwable {
BEC_2_9_4_ContainerList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevl_splits = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
/* Line: 851*/ {
if (bevl_i == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 851*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_ta_ph);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 854*/
 else /* Line: 851*/ {
break;
} /* Line: 851*/
} /* Line: 851*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 856*/ {
bevt_3_ta_ph = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 857*/
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_join_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
if (beva_stri == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 875*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 875*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_otherType_2(beva_stri, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 875*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 875*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 875*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 875*/ {
return null;
} /* Line: 876*/
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(-41247917);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 880*/ {
bevl_maxsize = bevl_osize;
} /* Line: 881*/
 else /* Line: 882*/ {
bevl_maxsize = bevl_mysize;
} /* Line: 883*/
bevl_myret = (new BEC_2_4_3_MathInt());
bevl_mv = (new BEC_2_4_3_MathInt());
bevl_ov = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 888*/ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 888*/ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(-1780116392, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 891*/ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 892*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(1));
return bevt_8_ta_ph;
} /* Line: 893*/
 else /* Line: 894*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(-1));
return bevt_9_ta_ph;
} /* Line: 895*/
} /* Line: 892*/
bevl_i.bevi_int++;
} /* Line: 888*/
 else /* Line: 888*/ {
break;
} /* Line: 888*/
} /* Line: 888*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_myret.bevi_int == bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 899*/ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 900*/ {
bevl_myret = (new BEC_2_4_3_MathInt(1));
} /* Line: 901*/
 else /* Line: 900*/ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 902*/ {
bevl_myret = (new BEC_2_4_3_MathInt(-1));
} /* Line: 903*/
} /* Line: 900*/
} /* Line: 900*/
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 910*/ {
return null;
} /* Line: 910*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(-1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 911*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 912*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 918*/ {
return null;
} /* Line: 918*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 919*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 920*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

    BEC_2_4_6_TextString bevls_stri = (BEC_2_4_6_TextString) beva_stri;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_str);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1769965429);
bevt_1_ta_ph = bevl_str.bem_sizeGet_0();
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_ta_ph, bevp_size, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_ta_ph, bevt_5_ta_ph, bevp_size);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_create_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) throws Throwable {
BEC_2_4_3_MathInt bevl_leni = null;
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_4_3_MathInt bevl_sizi = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_7_TextStrings bevt_13_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_zeroGet_0();
if (beva_starti.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1004*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1004*/ {
bevt_5_ta_ph = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 1004*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1004*/ {
bevt_7_ta_ph = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1004*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1004*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1004*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1004*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1004*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1004*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1004*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_8_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 1005*/
 else /* Line: 1006*/ {
bevl_leni = (new BEC_2_4_3_MathInt());
bevl_leni.bevi_int = beva_endi.bevi_int;
bevl_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevl_leni;
bevl_sizi = (new BEC_2_4_3_MathInt());
bevl_sizi.bevi_int = beva_dstarti.bevi_int;
bevl_sizi.bevi_int += bevl_leni.bevi_int;
if (bevl_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1017*/ {
bem_capacitySet_1(bevl_sizi);
} /* Line: 1018*/

         //source, sourceStart, dest, destStart, length
         System.arraycopy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevl_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 1051*/ {
bevp_size.bevi_int = bevl_sizi.bevi_int;
} /* Line: 1055*/
return this;
} /* Line: 1057*/
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sizeGet_0();
bevt_0_ta_ph = bem_substring_2(beva_starti, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_2_ta_ph = beva_endi.bem_subtract_1(beva_starti);
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bevt_1_ta_ph.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevi_bytes.length - 1);
/* Line: 1089*/ {
} /* Line: 1090*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_print_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevp_size.bevi_int);
System.out.write('\n');
/* Line: 1147*/ {
} /* Line: 1148*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_echo_0() throws Throwable {
bem_output_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_snw == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1214*/ {
bem_new_0();
} /* Line: 1215*/
 else /* Line: 1216*/ {
bevt_2_ta_ph = beva_snw.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_new_1(bevt_1_ta_ph);
bem_addValue_1(beva_snw);
} /* Line: 1218*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_strip_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevl_vb = (new BEC_2_4_3_MathInt());
bevl_ve = (new BEC_2_4_3_MathInt());
bevl_b = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_e = bevp_size.bem_subtract_1(bevt_0_ta_ph);
while (true)
/* Line: 1235*/ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1235*/ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1241*/
 else /* Line: 1235*/ {
break;
} /* Line: 1235*/
} /* Line: 1235*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {244, 245, 254, 254, 258, 258, 259, 260, 260, 261, 297, 297, 298, 300, 304, 304, 305, 305, 306, 306, 310, 310, 310, 310, 310, 310, 310, 314, 315, 319, 321, 322, 322, 323, 325, 325, 326, 326, 326, 326, 326, 326, 329, 331, 331, 331, 331, 335, 339, 343, 347, 357, 358, 359, 363, 363, 363, 364, 364, 364, 365, 365, 370, 370, 371, 371, 372, 372, 376, 377, 378, 378, 378, 378, 378, 380, 381, 382, 382, 382, 382, 382, 384, 388, 388, 388, 389, 390, 394, 395, 395, 0, 395, 395, 395, 0, 0, 396, 396, 398, 398, 402, 402, 402, 402, 403, 403, 403, 404, 404, 405, 405, 407, 407, 411, 411, 0, 411, 411, 411, 0, 0, 412, 412, 414, 414, 418, 418, 422, 423, 423, 423, 424, 425, 425, 425, 425, 425, 425, 0, 425, 425, 425, 0, 0, 0, 0, 0, 427, 427, 427, 0, 427, 427, 427, 0, 0, 428, 428, 423, 431, 431, 435, 436, 436, 436, 437, 438, 438, 438, 438, 438, 438, 0, 0, 0, 0, 438, 438, 438, 438, 438, 438, 0, 0, 0, 0, 0, 0, 438, 438, 438, 438, 438, 438, 0, 0, 0, 0, 0, 439, 439, 436, 442, 442, 446, 446, 450, 451, 451, 451, 452, 453, 453, 453, 453, 453, 453, 0, 0, 0, 454, 454, 455, 451, 461, 461, 461, 465, 466, 466, 466, 467, 468, 468, 468, 468, 468, 468, 0, 0, 0, 469, 469, 470, 466, 476, 476, 476, 481, 482, 483, 484, 485, 485, 486, 486, 487, 488, 488, 489, 489, 489, 491, 491, 493, 498, 499, 500, 501, 501, 502, 503, 503, 504, 504, 505, 506, 506, 509, 509, 509, 513, 518, 518, 519, 520, 520, 520, 521, 520, 523, 523, 524, 528, 529, 529, 530, 530, 530, 531, 532, 532, 533, 530, 536, 540, 540, 540, 544, 544, 544, 554, 554, 554, 554, 554, 0, 0, 0, 591, 593, 604, 604, 604, 604, 604, 0, 0, 0, 639, 641, 645, 645, 645, 645, 645, 0, 0, 0, 646, 651, 651, 651, 651, 651, 0, 0, 0, 652, 657, 658, 658, 659, 660, 661, 662, 662, 662, 663, 664, 664, 664, 664, 664, 664, 0, 0, 0, 0, 664, 664, 664, 664, 664, 664, 0, 0, 0, 0, 0, 0, 664, 664, 664, 664, 664, 664, 0, 0, 0, 0, 0, 665, 666, 662, 669, 670, 674, 674, 674, 675, 675, 677, 677, 774, 774, 780, 780, 780, 780, 780, 782, 782, 783, 783, 784, 784, 786, 790, 790, 790, 796, 796, 0, 796, 796, 0, 0, 0, 796, 796, 796, 0, 0, 0, 796, 796, 0, 0, 0, 796, 796, 796, 0, 0, 0, 796, 796, 796, 0, 0, 0, 796, 796, 796, 796, 0, 0, 797, 800, 801, 802, 803, 804, 804, 806, 808, 808, 808, 809, 810, 811, 813, 814, 814, 815, 816, 816, 817, 817, 817, 818, 820, 821, 822, 823, 823, 824, 824, 825, 827, 827, 828, 828, 829, 830, 831, 831, 834, 835, 837, 837, 838, 841, 843, 847, 848, 849, 850, 851, 851, 852, 852, 853, 854, 856, 856, 857, 857, 859, 863, 863, 863, 867, 875, 875, 0, 875, 875, 0, 0, 876, 878, 879, 880, 880, 881, 883, 885, 886, 887, 888, 888, 888, 889, 890, 891, 891, 892, 892, 893, 893, 895, 895, 888, 899, 899, 899, 900, 900, 901, 902, 902, 903, 906, 910, 910, 910, 911, 911, 911, 911, 912, 912, 914, 914, 918, 918, 918, 919, 919, 919, 919, 920, 920, 922, 922, 985, 985, 989, 989, 989, 993, 994, 994, 994, 995, 995, 995, 996, 996, 996, 997, 1000, 1000, 1004, 1004, 1004, 1004, 0, 1004, 1004, 1004, 0, 1004, 1004, 1004, 0, 0, 0, 0, 1005, 1005, 1005, 1008, 1009, 1010, 1011, 1013, 1014, 1015, 1017, 1017, 1018, 1051, 1051, 1055, 1057, 1062, 1062, 1062, 1066, 1066, 1066, 1066, 1066, 1182, 1186, 1186, 1190, 1190, 1194, 1194, 1198, 1198, 1202, 1202, 1206, 1206, 1210, 1214, 1214, 1215, 1217, 1217, 1217, 1217, 1218, 1223, 1223, 1227, 1227, 1227, 1231, 1232, 1233, 1234, 1234, 1235, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {55, 56, 61, 62, 69, 74, 75, 78, 83, 84, 93, 98, 99, 101, 108, 109, 110, 111, 112, 113, 123, 124, 125, 126, 127, 128, 129, 133, 134, 151, 152, 153, 154, 155, 156, 161, 162, 163, 164, 165, 166, 167, 168, 170, 171, 172, 173, 177, 180, 183, 187, 198, 199, 200, 208, 209, 214, 215, 216, 217, 218, 219, 227, 228, 229, 230, 231, 232, 247, 248, 250, 251, 252, 253, 254, 256, 257, 259, 260, 261, 262, 263, 265, 271, 272, 273, 274, 275, 285, 286, 291, 292, 295, 296, 301, 302, 305, 309, 310, 312, 313, 324, 329, 330, 331, 333, 334, 335, 336, 341, 342, 343, 345, 346, 355, 360, 361, 364, 365, 370, 371, 374, 378, 379, 381, 382, 386, 387, 407, 408, 411, 416, 417, 418, 419, 424, 425, 426, 431, 432, 435, 436, 441, 442, 445, 449, 452, 456, 461, 462, 467, 468, 471, 472, 477, 478, 481, 485, 486, 489, 495, 496, 519, 520, 523, 528, 529, 530, 531, 536, 537, 538, 543, 544, 547, 551, 554, 557, 558, 563, 564, 565, 570, 571, 574, 578, 581, 584, 588, 591, 592, 597, 598, 599, 604, 605, 608, 612, 615, 618, 622, 623, 625, 631, 632, 636, 637, 649, 650, 653, 658, 659, 660, 661, 666, 667, 668, 673, 674, 677, 681, 684, 685, 686, 688, 699, 700, 701, 713, 714, 717, 722, 723, 724, 725, 730, 731, 732, 737, 738, 741, 745, 748, 749, 750, 752, 763, 764, 765, 777, 778, 779, 780, 781, 786, 787, 788, 789, 790, 791, 792, 793, 794, 797, 798, 800, 812, 813, 814, 817, 822, 823, 824, 829, 830, 831, 832, 833, 834, 837, 838, 839, 846, 856, 857, 858, 859, 862, 867, 868, 869, 875, 876, 877, 885, 886, 887, 888, 891, 896, 897, 898, 899, 900, 901, 907, 912, 913, 914, 919, 920, 921, 928, 929, 934, 935, 940, 941, 944, 948, 955, 957, 964, 965, 970, 971, 976, 977, 980, 984, 994, 996, 1003, 1004, 1009, 1010, 1015, 1016, 1019, 1023, 1026, 1035, 1036, 1041, 1042, 1047, 1048, 1051, 1055, 1058, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1095, 1100, 1101, 1102, 1103, 1108, 1109, 1110, 1115, 1116, 1119, 1123, 1126, 1129, 1130, 1135, 1136, 1137, 1142, 1143, 1146, 1150, 1153, 1156, 1160, 1163, 1164, 1169, 1170, 1171, 1176, 1177, 1180, 1184, 1187, 1190, 1194, 1195, 1197, 1203, 1204, 1211, 1212, 1217, 1218, 1219, 1221, 1222, 1240, 1241, 1252, 1253, 1254, 1255, 1256, 1257, 1262, 1263, 1264, 1265, 1266, 1268, 1273, 1274, 1275, 1318, 1323, 1324, 1327, 1332, 1333, 1336, 1340, 1343, 1344, 1349, 1350, 1353, 1357, 1360, 1365, 1366, 1369, 1373, 1376, 1377, 1382, 1383, 1386, 1390, 1393, 1394, 1399, 1400, 1403, 1407, 1410, 1411, 1412, 1417, 1418, 1421, 1425, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1440, 1441, 1442, 1443, 1445, 1448, 1453, 1454, 1455, 1460, 1461, 1462, 1467, 1468, 1470, 1471, 1472, 1473, 1474, 1475, 1480, 1481, 1483, 1484, 1487, 1492, 1493, 1494, 1495, 1500, 1503, 1504, 1510, 1515, 1516, 1519, 1525, 1536, 1537, 1538, 1539, 1542, 1547, 1548, 1549, 1550, 1551, 1557, 1562, 1563, 1564, 1566, 1571, 1572, 1573, 1576, 1600, 1605, 1606, 1609, 1610, 1612, 1615, 1619, 1621, 1622, 1623, 1628, 1629, 1632, 1634, 1635, 1636, 1637, 1640, 1645, 1646, 1647, 1648, 1653, 1654, 1659, 1660, 1661, 1664, 1665, 1668, 1674, 1675, 1680, 1681, 1686, 1687, 1690, 1695, 1696, 1700, 1709, 1714, 1715, 1717, 1718, 1719, 1724, 1725, 1726, 1728, 1729, 1738, 1743, 1744, 1746, 1747, 1748, 1753, 1754, 1755, 1757, 1758, 1772, 1773, 1778, 1779, 1784, 1795, 1796, 1797, 1798, 1799, 1800, 1801, 1802, 1803, 1804, 1805, 1809, 1810, 1830, 1831, 1832, 1837, 1838, 1841, 1842, 1847, 1848, 1851, 1852, 1857, 1858, 1861, 1865, 1868, 1872, 1873, 1874, 1877, 1878, 1879, 1880, 1881, 1882, 1883, 1884, 1889, 1890, 1895, 1900, 1901, 1903, 1909, 1910, 1911, 1918, 1919, 1920, 1921, 1922, 1940, 1945, 1946, 1950, 1951, 1955, 1956, 1960, 1961, 1965, 1966, 1970, 1971, 1974, 1981, 1986, 1987, 1990, 1991, 1992, 1993, 1994, 2000, 2001, 2006, 2007, 2008, 2017, 2018, 2019, 2020, 2021, 2024, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2044, 2047, 2051};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 244 55
new 0 244 55
capacitySet 1 245 56
assign 1 254 61
new 0 254 61
new 1 254 62
assign 1 258 69
undef 1 258 74
assign 1 259 75
new 0 259 75
assign 1 260 78
equals 1 260 83
return 1 261 84
assign 1 297 93
greater 1 297 98
setValue 1 298 99
setValue 1 300 101
assign 1 304 108
new 0 304 108
new 1 304 109
assign 1 305 110
new 0 305 110
setValue 1 305 111
assign 1 306 112
new 0 306 112
setHex 2 306 113
assign 1 310 123
new 0 310 123
assign 1 310 124
getCode 2 310 124
assign 1 310 125
new 0 310 125
assign 1 310 126
new 0 310 126
assign 1 310 127
new 0 310 127
assign 1 310 128
toString 3 310 128
return 1 310 129
assign 1 314 133
hexNew 1 314 133
setCode 2 315 134
assign 1 319 151
toString 0 319 151
assign 1 321 152
new 0 321 152
assign 1 322 153
sizeGet 0 322 153
setValue 1 322 154
addValue 1 323 155
assign 1 325 156
lesser 1 325 161
assign 1 326 162
new 0 326 162
assign 1 326 163
add 1 326 163
assign 1 326 164
new 0 326 164
assign 1 326 165
multiply 1 326 165
assign 1 326 166
new 0 326 166
assign 1 326 167
divide 1 326 167
capacitySet 1 329 168
assign 1 331 170
new 0 331 170
assign 1 331 171
zeroGet 0 331 171
assign 1 331 172
sizeGet 0 331 172
copyValue 4 331 173
return 1 335 177
return 1 339 180
addValue 1 343 183
write 1 347 187
assign 1 357 198
copy 0 357 198
clear 0 358 199
return 1 359 200
assign 1 363 208
new 0 363 208
assign 1 363 209
greater 1 363 214
assign 1 364 215
new 0 364 215
assign 1 364 216
new 0 364 216
setIntUnchecked 2 364 217
assign 1 365 218
new 0 365 218
setValue 1 365 219
assign 1 370 227
new 0 370 227
new 1 370 228
assign 1 371 229
new 0 371 229
setValue 1 371 230
assign 1 372 231
new 0 372 231
setCodeUnchecked 2 372 232
assign 1 376 247
new 0 376 247
assign 1 377 248
ends 1 377 248
assign 1 378 250
new 0 378 250
assign 1 378 251
sizeGet 0 378 251
assign 1 378 252
subtract 1 378 252
assign 1 378 253
substring 2 378 253
return 1 378 254
assign 1 380 256
new 0 380 256
assign 1 381 257
ends 1 381 257
assign 1 382 259
new 0 382 259
assign 1 382 260
sizeGet 0 382 260
assign 1 382 261
subtract 1 382 261
assign 1 382 262
substring 2 382 262
return 1 382 263
return 1 384 265
assign 1 388 271
new 0 388 271
assign 1 388 272
add 1 388 272
assign 1 388 273
new 1 388 273
addValue 1 389 274
return 1 390 275
assign 1 394 285
find 1 394 285
assign 1 395 286
undef 1 395 291
assign 1 0 292
assign 1 395 295
new 0 395 295
assign 1 395 296
notEquals 1 395 301
assign 1 0 302
assign 1 0 305
assign 1 396 309
new 0 396 309
return 1 396 310
assign 1 398 312
new 0 398 312
return 1 398 313
assign 1 402 324
undef 1 402 329
assign 1 402 330
new 0 402 330
return 1 402 331
assign 1 403 333
sizeGet 0 403 333
assign 1 403 334
subtract 1 403 334
assign 1 403 335
find 2 403 335
assign 1 404 336
undef 1 404 341
assign 1 405 342
new 0 405 342
return 1 405 343
assign 1 407 345
new 0 407 345
return 1 407 346
assign 1 411 355
undef 1 411 360
assign 1 0 361
assign 1 411 364
find 1 411 364
assign 1 411 365
undef 1 411 370
assign 1 0 371
assign 1 0 374
assign 1 412 378
new 0 412 378
return 1 412 379
assign 1 414 381
new 0 414 381
return 1 414 382
assign 1 418 386
isInteger 0 418 386
return 1 418 387
assign 1 422 407
new 0 422 407
assign 1 423 408
new 0 423 408
assign 1 423 411
lesser 1 423 416
getInt 2 424 417
assign 1 425 418
new 0 425 418
assign 1 425 419
equals 1 425 424
assign 1 425 425
new 0 425 425
assign 1 425 426
equals 1 425 431
assign 1 0 432
assign 1 425 435
new 0 425 435
assign 1 425 436
equals 1 425 441
assign 1 0 442
assign 1 0 445
assign 1 0 449
assign 1 0 452
assign 1 0 456
assign 1 427 461
new 0 427 461
assign 1 427 462
greater 1 427 467
assign 1 0 468
assign 1 427 471
new 0 427 471
assign 1 427 472
lesser 1 427 477
assign 1 0 478
assign 1 0 481
assign 1 428 485
new 0 428 485
return 1 428 486
incrementValue 0 423 489
assign 1 431 495
new 0 431 495
return 1 431 496
assign 1 435 519
new 0 435 519
assign 1 436 520
new 0 436 520
assign 1 436 523
lesser 1 436 528
getInt 2 437 529
assign 1 438 530
new 0 438 530
assign 1 438 531
greater 1 438 536
assign 1 438 537
new 0 438 537
assign 1 438 538
lesser 1 438 543
assign 1 0 544
assign 1 0 547
assign 1 0 551
assign 1 0 554
assign 1 438 557
new 0 438 557
assign 1 438 558
greater 1 438 563
assign 1 438 564
new 0 438 564
assign 1 438 565
lesser 1 438 570
assign 1 0 571
assign 1 0 574
assign 1 0 578
assign 1 0 581
assign 1 0 584
assign 1 0 588
assign 1 438 591
new 0 438 591
assign 1 438 592
greater 1 438 597
assign 1 438 598
new 0 438 598
assign 1 438 599
lesser 1 438 604
assign 1 0 605
assign 1 0 608
assign 1 0 612
assign 1 0 615
assign 1 0 618
assign 1 439 622
new 0 439 622
return 1 439 623
incrementValue 0 436 625
assign 1 442 631
new 0 442 631
return 1 442 632
assign 1 446 636
isAlphaNumGet 0 446 636
return 1 446 637
assign 1 450 649
new 0 450 649
assign 1 451 650
new 0 451 650
assign 1 451 653
lesser 1 451 658
getInt 2 452 659
assign 1 453 660
new 0 453 660
assign 1 453 661
greater 1 453 666
assign 1 453 667
new 0 453 667
assign 1 453 668
lesser 1 453 673
assign 1 0 674
assign 1 0 677
assign 1 0 681
assign 1 454 684
new 0 454 684
addValue 1 454 685
setIntUnchecked 2 455 686
incrementValue 0 451 688
assign 1 461 699
copy 0 461 699
assign 1 461 700
lowerValue 0 461 700
return 1 461 701
assign 1 465 713
new 0 465 713
assign 1 466 714
new 0 466 714
assign 1 466 717
lesser 1 466 722
getInt 2 467 723
assign 1 468 724
new 0 468 724
assign 1 468 725
greater 1 468 730
assign 1 468 731
new 0 468 731
assign 1 468 732
lesser 1 468 737
assign 1 0 738
assign 1 0 741
assign 1 0 745
assign 1 469 748
new 0 469 748
subtractValue 1 469 749
setIntUnchecked 2 470 750
incrementValue 0 466 752
assign 1 476 763
copy 0 476 763
assign 1 476 764
upperValue 0 476 764
return 1 476 765
assign 1 481 777
new 0 481 777
assign 1 482 778
new 0 482 778
assign 1 483 779
new 0 483 779
assign 1 484 780
find 2 484 780
assign 1 485 781
def 1 485 786
assign 1 486 787
substring 2 486 787
addValue 1 486 788
addValue 1 487 789
assign 1 488 790
sizeGet 0 488 790
assign 1 488 791
add 1 488 791
assign 1 489 792
sizeGet 0 489 792
assign 1 489 793
substring 2 489 793
addValue 1 489 794
assign 1 491 797
copy 0 491 797
return 1 491 798
return 1 493 800
assign 1 498 812
new 0 498 812
assign 1 499 813
new 0 499 813
assign 1 500 814
new 0 500 814
assign 1 501 817
def 1 501 822
assign 1 502 823
find 2 502 823
assign 1 503 824
def 1 503 829
assign 1 504 830
substring 2 504 830
addValue 1 504 831
addValue 1 505 832
assign 1 506 833
sizeGet 0 506 833
assign 1 506 834
add 1 506 834
assign 1 509 837
sizeGet 0 509 837
assign 1 509 838
substring 2 509 838
addValue 1 509 839
return 1 513 846
assign 1 518 856
new 0 518 856
assign 1 518 857
new 1 518 857
assign 1 519 858
mbiterGet 0 519 858
assign 1 520 859
new 0 520 859
assign 1 520 862
lesser 1 520 867
next 1 521 868
incrementValue 0 520 869
assign 1 523 875
next 1 523 875
assign 1 523 876
toString 0 523 876
return 1 524 877
assign 1 528 885
new 0 528 885
assign 1 529 886
new 0 529 886
setValue 1 529 887
assign 1 530 888
new 0 530 888
assign 1 530 891
lesser 1 530 896
getInt 2 531 897
assign 1 532 898
new 0 532 898
multiplyValue 1 532 899
addValue 1 533 900
incrementValue 0 530 901
return 1 536 907
assign 1 540 912
new 0 540 912
assign 1 540 913
hashValue 1 540 913
return 1 540 914
assign 1 544 919
new 0 544 919
assign 1 544 920
getCode 2 544 920
return 1 544 921
assign 1 554 928
new 0 554 928
assign 1 554 929
greaterEquals 1 554 934
assign 1 554 935
greater 1 554 940
assign 1 0 941
assign 1 0 944
assign 1 0 948
return 1 591 955
return 1 593 957
assign 1 604 964
new 0 604 964
assign 1 604 965
greaterEquals 1 604 970
assign 1 604 971
greater 1 604 976
assign 1 0 977
assign 1 0 980
assign 1 0 984
return 1 639 994
return 1 641 996
assign 1 645 1003
new 0 645 1003
assign 1 645 1004
greaterEquals 1 645 1009
assign 1 645 1010
greater 1 645 1015
assign 1 0 1016
assign 1 0 1019
assign 1 0 1023
setIntUnchecked 2 646 1026
assign 1 651 1035
new 0 651 1035
assign 1 651 1036
greaterEquals 1 651 1041
assign 1 651 1042
greater 1 651 1047
assign 1 0 1048
assign 1 0 1051
assign 1 0 1055
setCodeUnchecked 2 652 1058
assign 1 657 1086
assign 1 658 1087
sizeGet 0 658 1087
assign 1 658 1088
copy 0 658 1088
assign 1 659 1089
new 1 659 1089
assign 1 660 1090
new 0 660 1090
assign 1 661 1091
new 0 661 1091
assign 1 662 1092
new 0 662 1092
assign 1 662 1095
lesser 1 662 1100
getInt 2 663 1101
assign 1 664 1102
new 0 664 1102
assign 1 664 1103
greater 1 664 1108
assign 1 664 1109
new 0 664 1109
assign 1 664 1110
lesser 1 664 1115
assign 1 0 1116
assign 1 0 1119
assign 1 0 1123
assign 1 0 1126
assign 1 664 1129
new 0 664 1129
assign 1 664 1130
greater 1 664 1135
assign 1 664 1136
new 0 664 1136
assign 1 664 1137
lesser 1 664 1142
assign 1 0 1143
assign 1 0 1146
assign 1 0 1150
assign 1 0 1153
assign 1 0 1156
assign 1 0 1160
assign 1 664 1163
new 0 664 1163
assign 1 664 1164
greater 1 664 1169
assign 1 664 1170
new 0 664 1170
assign 1 664 1171
lesser 1 664 1176
assign 1 0 1177
assign 1 0 1180
assign 1 0 1184
assign 1 0 1187
assign 1 0 1190
setIntUnchecked 2 665 1194
incrementValue 0 666 1195
incrementValue 0 662 1197
sizeSet 1 669 1203
return 1 670 1204
assign 1 674 1211
new 0 674 1211
assign 1 674 1212
lesserEquals 1 674 1217
assign 1 675 1218
new 0 675 1218
return 1 675 1219
assign 1 677 1221
new 0 677 1221
return 1 677 1222
assign 1 774 1240
rfind 1 774 1240
return 1 774 1241
assign 1 780 1252
copy 0 780 1252
assign 1 780 1253
reverseBytes 0 780 1253
assign 1 780 1254
copy 0 780 1254
assign 1 780 1255
reverseBytes 0 780 1255
assign 1 780 1256
find 1 780 1256
assign 1 782 1257
def 1 782 1262
assign 1 783 1263
sizeGet 0 783 1263
addValue 1 783 1264
assign 1 784 1265
subtract 1 784 1265
return 1 784 1266
return 1 786 1268
assign 1 790 1273
new 0 790 1273
assign 1 790 1274
find 2 790 1274
return 1 790 1275
assign 1 796 1318
undef 1 796 1323
assign 1 0 1324
assign 1 796 1327
undef 1 796 1332
assign 1 0 1333
assign 1 0 1336
assign 1 0 1340
assign 1 796 1343
new 0 796 1343
assign 1 796 1344
lesser 1 796 1349
assign 1 0 1350
assign 1 0 1353
assign 1 0 1357
assign 1 796 1360
greaterEquals 1 796 1365
assign 1 0 1366
assign 1 0 1369
assign 1 0 1373
assign 1 796 1376
sizeGet 0 796 1376
assign 1 796 1377
greater 1 796 1382
assign 1 0 1383
assign 1 0 1386
assign 1 0 1390
assign 1 796 1393
new 0 796 1393
assign 1 796 1394
equals 1 796 1399
assign 1 0 1400
assign 1 0 1403
assign 1 0 1407
assign 1 796 1410
sizeGet 0 796 1410
assign 1 796 1411
new 0 796 1411
assign 1 796 1412
equals 1 796 1417
assign 1 0 1418
assign 1 0 1421
return 1 797 1425
assign 1 800 1427
assign 1 801 1428
copy 0 801 1428
assign 1 802 1429
new 0 802 1429
assign 1 803 1430
new 0 803 1430
assign 1 804 1431
new 0 804 1431
getInt 2 804 1432
assign 1 806 1433
sizeGet 0 806 1433
assign 1 808 1434
new 0 808 1434
assign 1 808 1435
greater 1 808 1440
assign 1 809 1441
new 0 809 1441
assign 1 810 1442
new 0 810 1442
assign 1 811 1443
new 0 811 1443
assign 1 813 1445
new 0 813 1445
assign 1 814 1448
lesser 1 814 1453
getInt 2 815 1454
assign 1 816 1455
equals 1 816 1460
assign 1 817 1461
new 0 817 1461
assign 1 817 1462
equals 1 817 1467
return 1 818 1468
setValue 1 820 1470
incrementValue 0 821 1471
setValue 1 822 1472
assign 1 823 1473
sizeGet 0 823 1473
addValue 1 823 1474
assign 1 824 1475
greater 1 824 1480
return 1 825 1481
assign 1 827 1483
new 0 827 1483
setValue 1 827 1484
assign 1 828 1487
lesser 1 828 1492
getInt 2 829 1493
getInt 2 830 1494
assign 1 831 1495
notEquals 1 831 1500
incrementValue 0 834 1503
incrementValue 0 835 1504
assign 1 837 1510
equals 1 837 1515
return 1 838 1516
incrementValue 0 841 1519
return 1 843 1525
assign 1 847 1536
new 0 847 1536
assign 1 848 1537
new 0 848 1537
assign 1 849 1538
find 2 849 1538
assign 1 850 1539
sizeGet 0 850 1539
assign 1 851 1542
def 1 851 1547
assign 1 852 1548
substring 2 852 1548
addValue 1 852 1549
assign 1 853 1550
add 1 853 1550
assign 1 854 1551
find 2 854 1551
assign 1 856 1557
lesser 1 856 1562
assign 1 857 1563
substring 2 857 1563
addValue 1 857 1564
return 1 859 1566
assign 1 863 1571
new 0 863 1571
assign 1 863 1572
join 2 863 1572
return 1 863 1573
return 1 867 1576
assign 1 875 1600
undef 1 875 1605
assign 1 0 1606
assign 1 875 1609
new 0 875 1609
assign 1 875 1610
otherType 2 875 1610
assign 1 0 1612
assign 1 0 1615
return 1 876 1619
assign 1 878 1621
assign 1 879 1622
sizeGet 0 879 1622
assign 1 880 1623
greater 1 880 1628
assign 1 881 1629
assign 1 883 1632
assign 1 885 1634
new 0 885 1634
assign 1 886 1635
new 0 886 1635
assign 1 887 1636
new 0 887 1636
assign 1 888 1637
new 0 888 1637
assign 1 888 1640
lesser 1 888 1645
getCode 2 889 1646
getCode 2 890 1647
assign 1 891 1648
notEquals 1 891 1653
assign 1 892 1654
greater 1 892 1659
assign 1 893 1660
new 0 893 1660
return 1 893 1661
assign 1 895 1664
new 0 895 1664
return 1 895 1665
incrementValue 0 888 1668
assign 1 899 1674
new 0 899 1674
assign 1 899 1675
equals 1 899 1680
assign 1 900 1681
greater 1 900 1686
assign 1 901 1687
new 0 901 1687
assign 1 902 1690
greater 1 902 1695
assign 1 903 1696
new 0 903 1696
return 1 906 1700
assign 1 910 1709
undef 1 910 1714
return 1 910 1715
assign 1 911 1717
compare 1 911 1717
assign 1 911 1718
new 0 911 1718
assign 1 911 1719
equals 1 911 1724
assign 1 912 1725
new 0 912 1725
return 1 912 1726
assign 1 914 1728
new 0 914 1728
return 1 914 1729
assign 1 918 1738
undef 1 918 1743
return 1 918 1744
assign 1 919 1746
compare 1 919 1746
assign 1 919 1747
new 0 919 1747
assign 1 919 1748
equals 1 919 1753
assign 1 920 1754
new 0 920 1754
return 1 920 1755
assign 1 922 1757
new 0 922 1757
return 1 922 1758
assign 1 985 1772
new 0 985 1772
return 1 985 1773
assign 1 989 1778
equals 1 989 1778
assign 1 989 1779
not 0 989 1784
return 1 989 1784
assign 1 993 1795
toString 0 993 1795
assign 1 994 1796
sizeGet 0 994 1796
assign 1 994 1797
add 1 994 1797
assign 1 994 1798
new 1 994 1798
assign 1 995 1799
new 0 995 1799
assign 1 995 1800
new 0 995 1800
copyValue 4 995 1801
assign 1 996 1802
new 0 996 1802
assign 1 996 1803
sizeGet 0 996 1803
copyValue 4 996 1804
return 1 997 1805
assign 1 1000 1809
new 0 1000 1809
return 1 1000 1810
assign 1 1004 1830
new 0 1004 1830
assign 1 1004 1831
zeroGet 0 1004 1831
assign 1 1004 1832
lesser 1 1004 1837
assign 1 0 1838
assign 1 1004 1841
sizeGet 0 1004 1841
assign 1 1004 1842
greater 1 1004 1847
assign 1 0 1848
assign 1 1004 1851
sizeGet 0 1004 1851
assign 1 1004 1852
greater 1 1004 1857
assign 1 0 1858
assign 1 0 1861
assign 1 0 1865
assign 1 0 1868
assign 1 1005 1872
new 0 1005 1872
assign 1 1005 1873
new 1 1005 1873
throw 1 1005 1874
assign 1 1008 1877
new 0 1008 1877
setValue 1 1009 1878
subtractValue 1 1010 1879
assign 1 1011 1880
assign 1 1013 1881
new 0 1013 1881
setValue 1 1014 1882
addValue 1 1015 1883
assign 1 1017 1884
greater 1 1017 1889
capacitySet 1 1018 1890
assign 1 1051 1895
greater 1 1051 1900
setValue 1 1055 1901
return 1 1057 1903
assign 1 1062 1909
sizeGet 0 1062 1909
assign 1 1062 1910
substring 2 1062 1910
return 1 1062 1911
assign 1 1066 1918
subtract 1 1066 1918
assign 1 1066 1919
new 1 1066 1919
assign 1 1066 1920
new 0 1066 1920
assign 1 1066 1921
copyValue 4 1066 1921
return 1 1066 1922
output 0 1182 1940
assign 1 1186 1945
new 1 1186 1945
return 1 1186 1946
assign 1 1190 1950
new 1 1190 1950
return 1 1190 1951
assign 1 1194 1955
new 1 1194 1955
return 1 1194 1956
assign 1 1198 1960
new 1 1198 1960
return 1 1198 1961
assign 1 1202 1965
new 1 1202 1965
return 1 1202 1966
assign 1 1206 1970
new 1 1206 1970
return 1 1206 1971
return 1 1210 1974
assign 1 1214 1981
undef 1 1214 1986
new 0 1215 1987
assign 1 1217 1990
sizeGet 0 1217 1990
assign 1 1217 1991
new 0 1217 1991
assign 1 1217 1992
add 1 1217 1992
new 1 1217 1993
addValue 1 1218 1994
assign 1 1223 2000
new 0 1223 2000
return 1 1223 2001
assign 1 1227 2006
new 0 1227 2006
assign 1 1227 2007
strip 1 1227 2007
return 1 1227 2008
assign 1 1231 2017
new 0 1231 2017
assign 1 1232 2018
new 0 1232 2018
assign 1 1233 2019
new 0 1233 2019
assign 1 1234 2020
new 0 1234 2020
assign 1 1234 2021
subtract 1 1234 2021
assign 1 1235 2024
greater 1 1235 2029
getInt 2 1236 2030
getInt 2 1237 2031
setInt 2 1238 2032
setInt 2 1239 2033
incrementValue 0 1240 2034
decrementValue 0 1241 2035
return 1 0 2044
assign 1 0 2047
return 1 0 2051
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 863698620: return bem_lowerValue_0();
case 2045425568: return bem_byteIteratorGet_0();
case 935617271: return bem_readBuffer_0();
case 966722567: return bem_iteratorGet_0();
case -639540574: return bem_isEmptyGet_0();
case -1755447410: return bem_chomp_0();
case 1327010431: return bem_hashGet_0();
case 1933267094: return bem_open_0();
case -886668933: return bem_readString_0();
case -542460519: return bem_capacityGet_0();
case -107172498: return bem_strip_0();
case -1561744843: return bem_extractString_0();
case 301009490: return bem_isIntegerGet_0();
case -469226465: return bem_print_0();
case 731351030: return bem_echo_0();
case -1640186908: return bem_serializeToString_0();
case 2120153411: return bem_copy_0();
case 1769965429: return bem_toString_0();
case -1093979288: return bem_output_0();
case -256664174: return bem_upper_0();
case 1318937193: return bem_create_0();
case -1683349196: return bem_clear_0();
case -122256676: return bem_isInteger_0();
case 1190330015: return bem_isAlphaNumGet_0();
case -1475865762: return bem_close_0();
case -41247917: return bem_sizeGet_0();
case -1830147254: return bem_stringIteratorGet_0();
case -986263263: return bem_toAlphaNum_0();
case 693119491: return bem_isAlphaNumericGet_0();
case 989296698: return bem_multiByteIteratorGet_0();
case 640515907: return bem_upperValue_0();
case -509759754: return bem_biterGet_0();
case 1579356616: return bem_reverseBytes_0();
case 1709050481: return bem_mbiterGet_0();
case 147269376: return bem_serializeContentsGet_0();
case 212938660: return bem_vstringGet_0();
case 532380883: return bem_new_0();
case 1452941025: return bem_vstringSet_0();
case 1990302936: return bem_lower_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -287443777: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 1043437161: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case -431742737: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 501948498: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case 292329142: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1055271386: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case 17439675: return bem_writeTo_1(bevd_0);
case 860733724: return bem_add_1(bevd_0);
case -1161919231: return bem_addValue_1(bevd_0);
case 1194286113: return bem_def_1(bevd_0);
case 883662375: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 1444987432: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case -533094380: return bem_undef_1(bevd_0);
case -16136112: return bem_notEquals_1(bevd_0);
case 1512092307: return bem_compare_1(bevd_0);
case -811769910: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -1802543578: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -1077290651: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 2147027771: return bem_copyTo_1(bevd_0);
case -956900036: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case -920777352: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -1748701226: return bem_write_1(bevd_0);
case -751816106: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case -1694293325: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 2131421647: return bem_codeNew_1(bevd_0);
case -2096206933: return bem_sizeSet_1(bevd_0);
case -268811991: return bem_equals_1(bevd_0);
case 741655866: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 988274878: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -901093534: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1701814665: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1665151698: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 792362948: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 612039004: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1973148427: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1094064068: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 305030213: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 724241161: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1288182396: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 256278369: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -672637344: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1170276586: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1780116392: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1764802394: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 642814715: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1688602503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 986116170: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_TextString();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
