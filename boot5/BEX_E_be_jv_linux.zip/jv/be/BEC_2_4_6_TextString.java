package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_6_TextString extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) {
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) {
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) {
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(String bevi_string) throws Exception {
        byte[] bevi_bytes = bevi_string.getBytes("UTF-8");
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public String bems_toJvString() throws Exception {
        String jvString = new String(bevi_bytes, 0, bevp_size.bevi_int, "UTF-8");
        return jvString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_18 = (new BEC_2_4_3_MathInt(43));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_19 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_20 = (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_21 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_22 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_23 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_24 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_25 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_27 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_28 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_29 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_30 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_31 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_32 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_33 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_34 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_35 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_36 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_38 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_40 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_41 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_42 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_43 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_44 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_45 = (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_46 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_47 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_48 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_49 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevp_capacity = (new BEC_2_4_3_MathInt(0));
} /* Line: 253 */
 else  /* Line: 252 */ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 254 */ {
return this;
} /* Line: 255 */
} /* Line: 252 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        this.bevi_bytes = java.util.Arrays.copyOf(this.bevi_bytes, beva_ncap.bevi_int);
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 292 */
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_1;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bem_new_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_2;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_3;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bem_setHex_2(bevt_4_tmpany_phold, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_1_tmpany_phold = bem_getCode_2(beva_pos, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt(16));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_toString_3(bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) throws Throwable {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1349866592);
if (bevp_leni == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevp_leni = (new BEC_2_4_3_MathInt());
bevp_sizi = (new BEC_2_4_3_MathInt());
} /* Line: 316 */
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_4;
bevt_4_tmpany_phold = bevp_sizi.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_5;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_6;
bevl_nsize = bevt_3_tmpany_phold.bem_divide_1(bevt_7_tmpany_phold);
bem_capacitySet_1(bevl_nsize);
} /* Line: 323 */
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_9_tmpany_phold = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_8_tmpany_phold, bevt_9_tmpany_phold, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) throws Throwable {
beva_w.bemd_1(937129243, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_7;
if (bevp_size.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_8;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_9;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bem_setIntUnchecked_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_10;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_6_tmpany_phold.bevi_int;
} /* Line: 359 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_11;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_12;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bem_setCodeUnchecked_2(bevt_3_tmpany_phold, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() throws Throwable {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_1_tmpany_phold = bem_ends_1(bevl_nl);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 371 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_13;
bevt_5_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpany_phold = bevp_size.bem_subtract_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold = bem_substring_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 372 */
bevl_nl = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_6_tmpany_phold = bem_ends_1(bevl_nl);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 375 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_14;
bevt_10_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpany_phold = bevp_size.bem_subtract_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return bevt_7_tmpany_phold;
} /* Line: 376 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_copy_0() throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_15;
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_c = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_4_6_TextString) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 389 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 389 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_16;
if (bevl_found.bevi_int != bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 389 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 389 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 389 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 389 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 390 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 396 */
bevt_3_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bevp_size.bem_subtract_1(bevt_3_tmpany_phold);
bevl_found = bem_find_2(beva_str, bevt_2_tmpany_phold);
if (bevl_found == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 399 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 405 */ {
bevt_3_tmpany_phold = bem_find_1(beva_str);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 405 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 405 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 405 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 406 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isIntegerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isInteger_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 417 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 417 */ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_17;
if (bevl_j.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_18;
if (bevl_ic.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_19;
if (bevl_ic.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 419 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 419 */
 else  /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 419 */ {
} /* Line: 419 */
 else  /* Line: 419 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_20;
if (bevl_ic.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 421 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_21;
if (bevl_ic.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 421 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 421 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 421 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 422 */
} /* Line: 419 */
bevl_j.bevi_int++;
} /* Line: 417 */
 else  /* Line: 417 */ {
break;
} /* Line: 417 */
} /* Line: 417 */
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 430 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 430 */ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_22;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 432 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_23;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 432 */
 else  /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 432 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_tmpany_phold.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 434 */
bevl_j.bevi_int++;
} /* Line: 430 */
 else  /* Line: 430 */ {
break;
} /* Line: 430 */
} /* Line: 430 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lowerValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 445 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 445 */ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_24;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 447 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_25;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 447 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 447 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 447 */
 else  /* Line: 447 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 447 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpany_phold);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 449 */
bevl_j.bevi_int++;
} /* Line: 445 */
 else  /* Line: 445 */ {
break;
} /* Line: 445 */
} /* Line: 445 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_upperValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bem_split_1(beva_from);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_to, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevt_1_tmpany_phold = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_2_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bem_sizeGet_0();
bevt_3_tmpany_phold = bem_substring_2(bevl_last, bevt_4_tmpany_phold);
bevl_res.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 473 */
 else  /* Line: 474 */ {
bevt_5_tmpany_phold = beva_from.bem_copy_0();
return bevt_5_tmpany_phold;
} /* Line: 475 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 485 */ {
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 485 */ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 487 */ {
bevt_2_tmpany_phold = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_3_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 490 */
 else  /* Line: 492 */ {
bevt_5_tmpany_phold = bem_sizeGet_0();
bevt_4_tmpany_phold = bem_substring_2(bevl_last, bevt_5_tmpany_phold);
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 493 */
} /* Line: 487 */
 else  /* Line: 485 */ {
break;
} /* Line: 485 */
} /* Line: 485 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_j = bem_mbiterGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 504 */ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 504 */ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 504 */
 else  /* Line: 504 */ {
break;
} /* Line: 504 */
} /* Line: 504 */
bevt_2_tmpany_phold = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_tmpany_phold.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_tmpany_phold.bevi_int;
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 514 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 514 */ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpany_phold);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 514 */
 else  /* Line: 514 */ {
break;
} /* Line: 514 */
} /* Line: 514 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_hashValue_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getCode_2(beva_pos, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_26;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 538 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 538 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 538 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 538 */
 else  /* Line: 538 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 538 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 566 */
 else  /* Line: 574 */ {
return null;
} /* Line: 575 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_27;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 588 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 588 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 588 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 588 */
 else  /* Line: 588 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 588 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int < 0) {
            beva_into.bevi_int += 256;
         }
         } /* Line: 617 */
 else  /* Line: 622 */ {
return null;
} /* Line: 623 */
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_28;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 629 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 629 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 629 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 629 */
 else  /* Line: 629 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 629 */ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 630 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_29;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 635 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 635 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 635 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 635 */
 else  /* Line: 635 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 635 */ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 636 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() throws Throwable {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevl_input = this;
bevt_3_tmpany_phold = bevl_input.bem_sizeGet_0();
bevl_insz = bevt_3_tmpany_phold.bem_copy_0();
bevl_output = (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (new BEC_2_4_3_MathInt());
bevl_p = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 646 */ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 646 */ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_30;
if (bevl_c.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_31;
if (bevl_c.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 648 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 648 */
 else  /* Line: 648 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 648 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 648 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_32;
if (bevl_c.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_33;
if (bevl_c.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 648 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 648 */
 else  /* Line: 648 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 648 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 648 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 648 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 648 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 648 */ {
bevt_14_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_34;
if (bevl_c.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_35;
if (bevl_c.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 648 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 648 */
 else  /* Line: 648 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 648 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 648 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 648 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 648 */ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 650 */
bevl_i.bevi_int++;
} /* Line: 646 */
 else  /* Line: 646 */ {
break;
} /* Line: 646 */
} /* Line: 646 */
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_36;
if (bevp_size.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 658 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 659 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b > 127) {
        twvls_b -= 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_rfind_1(beva_str);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_reverseBytes_0();
bevt_3_tmpany_phold = beva_str.bem_copy_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpany_phold.bem_find_1(bevt_2_tmpany_phold);
if (bevl_rpos == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 766 */ {
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpany_phold;
} /* Line: 768 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_37;
bevt_0_tmpany_phold = bem_find_2(beva_str, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
if (beva_str == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
if (beva_start == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 780 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 780 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_38;
if (beva_start.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 780 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 780 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 780 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 780 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_12_tmpany_phold = beva_str.bem_sizeGet_0();
if (bevt_12_tmpany_phold.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 780 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_14_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_39;
if (bevp_size.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 780 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 780 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_16_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_40;
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 780 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 780 */ {
return null;
} /* Line: 781 */
bevl_end = bevp_size;
bevl_current = beva_start.bem_copy_0();
bevl_myval = (new BEC_2_4_3_MathInt());
bevl_strfirst = (new BEC_2_4_3_MathInt());
bevt_18_tmpany_phold = (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpany_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_41;
if (bevl_strsize.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 792 */ {
bevl_strval = (new BEC_2_4_3_MathInt());
bevl_current2 = (new BEC_2_4_3_MathInt());
bevl_end2 = (new BEC_2_4_3_MathInt());
} /* Line: 795 */
bevl_currentstr2 = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 798 */ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 798 */ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 800 */ {
bevt_24_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_42;
if (bevl_strsize.bevi_int == bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 801 */ {
return bevl_current;
} /* Line: 802 */
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_tmpany_phold.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 808 */ {
return null;
} /* Line: 809 */
bevt_28_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_43;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_tmpany_phold.bevi_int;
while (true)
 /* Line: 812 */ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 812 */ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 815 */ {
break;
} /* Line: 816 */
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 819 */
 else  /* Line: 812 */ {
break;
} /* Line: 812 */
} /* Line: 812 */
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 821 */ {
return bevl_current;
} /* Line: 822 */
} /* Line: 821 */
bevl_current.bevi_int++;
} /* Line: 825 */
 else  /* Line: 798 */ {
break;
} /* Line: 798 */
} /* Line: 798 */
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 835 */ {
if (bevl_i == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 835 */ {
bevt_1_tmpany_phold = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpany_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 838 */
 else  /* Line: 835 */ {
break;
} /* Line: 835 */
} /* Line: 835 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 840 */ {
bevt_3_tmpany_phold = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 841 */
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lineSplitterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_stri == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 863 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 863 */ {
bevt_2_tmpany_phold = beva_stri.bemd_1(-1674802050, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 863 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 863 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 863 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 863 */ {
return null;
} /* Line: 864 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(-922319077);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 868 */ {
bevl_maxsize = bevl_osize;
} /* Line: 869 */
 else  /* Line: 870 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 871 */
bevl_myret = (new BEC_2_4_3_MathInt());
bevl_mv = (new BEC_2_4_3_MathInt());
bevl_ov = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 876 */ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 876 */ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(-1500283588, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 879 */ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 880 */ {
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpany_phold;
} /* Line: 881 */
 else  /* Line: 882 */ {
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpany_phold;
} /* Line: 883 */
} /* Line: 880 */
bevl_i.bevi_int++;
} /* Line: 876 */
 else  /* Line: 876 */ {
break;
} /* Line: 876 */
} /* Line: 876 */
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_44;
if (bevl_myret.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 887 */ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 888 */ {
bevl_myret = (new BEC_2_4_3_MathInt(1));
} /* Line: 889 */
 else  /* Line: 888 */ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 890 */ {
bevl_myret = (new BEC_2_4_3_MathInt(-1));
} /* Line: 891 */
} /* Line: 888 */
} /* Line: 888 */
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 898 */ {
return null;
} /* Line: 898 */
bevt_2_tmpany_phold = bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_45;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 899 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 900 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 906 */ {
return null;
} /* Line: 906 */
bevt_2_tmpany_phold = bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_46;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 907 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 908 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

    BEC_2_4_6_TextString bevls_stri = (BEC_2_4_6_TextString) beva_stri;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_str);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1349866592);
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpany_phold, bevp_size, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevp_size);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_create_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) throws Throwable {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_47;
if (beva_starti.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 984 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 984 */ {
bevt_4_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 984 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 984 */ {
bevt_6_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 984 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 984 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 984 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 984 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 984 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 984 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 984 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_7_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 985 */
 else  /* Line: 986 */ {
if (bevp_leni == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 989 */ {
bevp_leni = (new BEC_2_4_3_MathInt());
bevp_sizi = (new BEC_2_4_3_MathInt());
} /* Line: 991 */
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 1000 */ {
bem_capacitySet_1(bevp_sizi);
} /* Line: 1001 */

         //source, sourceStart, dest, destStart, length
         System.arraycopy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 1034 */ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 1038 */
return this;
} /* Line: 1040 */
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sizeGet_0();
bevt_0_tmpany_phold = bem_substring_2(beva_starti, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevi_bytes.length - 1);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_print_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevp_size.bevi_int);
System.out.write('\n');
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_echo_0() throws Throwable {
bem_output_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_snw == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1173 */ {
bem_new_0();
} /* Line: 1174 */
 else  /* Line: 1175 */ {
bevt_2_tmpany_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_48;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bem_new_1(bevt_1_tmpany_phold);
bem_addValue_1(beva_snw);
} /* Line: 1177 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_strip_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevl_vb = (new BEC_2_4_3_MathInt());
bevl_ve = (new BEC_2_4_3_MathInt());
bevl_b = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_49;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpany_phold);
while (true)
 /* Line: 1194 */ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1194 */ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1200 */
 else  /* Line: 1194 */ {
break;
} /* Line: 1194 */
} /* Line: 1194 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_TextString bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_4_3_MathInt bem_capacityGetDirect_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_4_6_TextString bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() throws Throwable {
return bevp_leni;
} /*method end*/
public final BEC_2_4_3_MathInt bem_leniGetDirect_0() throws Throwable {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_TextString bem_leniSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() throws Throwable {
return bevp_sizi;
} /*method end*/
public final BEC_2_4_3_MathInt bem_siziGetDirect_0() throws Throwable {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_TextString bem_siziSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {234, 235, 248, 248, 248, 252, 252, 253, 254, 254, 255, 291, 291, 292, 294, 298, 298, 298, 299, 299, 299, 300, 300, 300, 304, 304, 304, 304, 304, 304, 304, 308, 309, 313, 314, 314, 315, 316, 318, 318, 319, 321, 321, 322, 322, 322, 322, 322, 322, 323, 325, 325, 325, 329, 333, 337, 341, 351, 352, 353, 357, 357, 357, 358, 358, 358, 358, 358, 359, 359, 359, 364, 364, 365, 365, 365, 366, 366, 366, 370, 370, 371, 372, 372, 372, 372, 372, 374, 375, 376, 376, 376, 376, 376, 378, 382, 382, 382, 383, 384, 388, 389, 389, 0, 389, 389, 389, 0, 0, 390, 390, 392, 392, 396, 396, 396, 396, 397, 397, 397, 398, 398, 399, 399, 401, 401, 405, 405, 0, 405, 405, 405, 0, 0, 406, 406, 408, 408, 412, 412, 416, 417, 417, 417, 418, 419, 419, 419, 419, 419, 419, 0, 419, 419, 419, 0, 0, 0, 0, 0, 421, 421, 421, 0, 421, 421, 421, 0, 0, 422, 422, 417, 425, 425, 429, 430, 430, 430, 431, 432, 432, 432, 432, 432, 432, 0, 0, 0, 433, 433, 434, 430, 440, 440, 440, 444, 445, 445, 445, 446, 447, 447, 447, 447, 447, 447, 0, 0, 0, 448, 448, 449, 445, 455, 455, 455, 459, 459, 459, 459, 465, 466, 467, 468, 469, 469, 470, 470, 471, 472, 472, 473, 473, 473, 475, 475, 477, 482, 483, 484, 485, 485, 486, 487, 487, 488, 488, 489, 490, 490, 493, 493, 493, 497, 502, 502, 503, 504, 504, 504, 505, 504, 507, 507, 508, 512, 513, 513, 514, 514, 514, 515, 516, 516, 517, 514, 520, 524, 524, 524, 528, 528, 528, 538, 538, 538, 538, 538, 0, 0, 0, 575, 577, 588, 588, 588, 588, 588, 0, 0, 0, 623, 625, 629, 629, 629, 629, 629, 0, 0, 0, 630, 635, 635, 635, 635, 635, 0, 0, 0, 636, 641, 642, 642, 643, 644, 645, 646, 646, 646, 647, 648, 648, 648, 648, 648, 648, 0, 0, 0, 0, 648, 648, 648, 648, 648, 648, 0, 0, 0, 0, 0, 0, 648, 648, 648, 648, 648, 648, 0, 0, 0, 0, 0, 649, 650, 646, 653, 654, 658, 658, 658, 659, 659, 661, 661, 758, 758, 764, 764, 764, 764, 764, 766, 766, 767, 767, 768, 768, 770, 774, 774, 774, 780, 780, 0, 780, 780, 0, 0, 0, 780, 780, 780, 0, 0, 0, 780, 780, 0, 0, 0, 780, 780, 780, 0, 0, 0, 780, 780, 780, 0, 0, 0, 780, 780, 780, 780, 0, 0, 781, 784, 785, 786, 787, 788, 788, 790, 792, 792, 792, 793, 794, 795, 797, 798, 798, 799, 800, 800, 801, 801, 801, 802, 804, 805, 806, 807, 807, 808, 808, 809, 811, 811, 811, 812, 812, 813, 814, 815, 815, 818, 819, 821, 821, 822, 825, 827, 831, 832, 833, 834, 835, 835, 836, 836, 837, 838, 840, 840, 841, 841, 843, 847, 847, 847, 851, 851, 851, 851, 855, 863, 863, 0, 863, 0, 0, 864, 866, 867, 868, 868, 869, 871, 873, 874, 875, 876, 876, 876, 877, 878, 879, 879, 880, 880, 881, 881, 883, 883, 876, 887, 887, 887, 888, 888, 889, 890, 890, 891, 894, 898, 898, 898, 899, 899, 899, 899, 900, 900, 902, 902, 906, 906, 906, 907, 907, 907, 907, 908, 908, 910, 910, 965, 965, 969, 969, 969, 973, 974, 974, 974, 975, 975, 975, 976, 976, 976, 977, 980, 980, 984, 984, 984, 0, 984, 984, 984, 0, 984, 984, 984, 0, 0, 0, 0, 985, 985, 985, 989, 989, 990, 991, 993, 994, 995, 997, 998, 1000, 1000, 1001, 1034, 1034, 1038, 1040, 1045, 1045, 1045, 1049, 1049, 1049, 1049, 1049, 1141, 1145, 1145, 1149, 1149, 1153, 1153, 1157, 1157, 1161, 1161, 1165, 1165, 1169, 1173, 1173, 1174, 1176, 1176, 1176, 1176, 1177, 1182, 1182, 1186, 1186, 1186, 1190, 1191, 1192, 1193, 1193, 1194, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {106, 107, 113, 114, 115, 122, 127, 128, 131, 136, 137, 146, 151, 152, 154, 164, 165, 166, 167, 168, 169, 170, 171, 172, 182, 183, 184, 185, 186, 187, 188, 192, 193, 209, 210, 215, 216, 217, 219, 220, 221, 222, 227, 228, 229, 230, 231, 232, 233, 234, 236, 237, 238, 242, 245, 248, 252, 263, 264, 265, 276, 277, 282, 283, 284, 285, 286, 287, 288, 289, 290, 300, 301, 302, 303, 304, 305, 306, 307, 323, 324, 325, 327, 328, 329, 330, 331, 333, 334, 336, 337, 338, 339, 340, 342, 348, 349, 350, 351, 352, 362, 363, 368, 369, 372, 373, 378, 379, 382, 386, 387, 389, 390, 401, 406, 407, 408, 410, 411, 412, 413, 418, 419, 420, 422, 423, 432, 437, 438, 441, 442, 447, 448, 451, 455, 456, 458, 459, 463, 464, 484, 485, 488, 493, 494, 495, 496, 501, 502, 503, 508, 509, 512, 513, 518, 519, 522, 526, 529, 533, 538, 539, 544, 545, 548, 549, 554, 555, 558, 562, 563, 566, 572, 573, 585, 586, 589, 594, 595, 596, 597, 602, 603, 604, 609, 610, 613, 617, 620, 621, 622, 624, 635, 636, 637, 649, 650, 653, 658, 659, 660, 661, 666, 667, 668, 673, 674, 677, 681, 684, 685, 686, 688, 699, 700, 701, 707, 708, 709, 710, 722, 723, 724, 725, 726, 731, 732, 733, 734, 735, 736, 737, 738, 739, 742, 743, 745, 757, 758, 759, 762, 767, 768, 769, 774, 775, 776, 777, 778, 779, 782, 783, 784, 791, 801, 802, 803, 804, 807, 812, 813, 814, 820, 821, 822, 830, 831, 832, 833, 836, 841, 842, 843, 844, 845, 846, 852, 857, 858, 859, 864, 865, 866, 873, 874, 879, 880, 885, 886, 889, 893, 900, 902, 909, 910, 915, 916, 921, 922, 925, 929, 939, 941, 948, 949, 954, 955, 960, 961, 964, 968, 971, 980, 981, 986, 987, 992, 993, 996, 1000, 1003, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1040, 1045, 1046, 1047, 1048, 1053, 1054, 1055, 1060, 1061, 1064, 1068, 1071, 1074, 1075, 1080, 1081, 1082, 1087, 1088, 1091, 1095, 1098, 1101, 1105, 1108, 1109, 1114, 1115, 1116, 1121, 1122, 1125, 1129, 1132, 1135, 1139, 1140, 1142, 1148, 1149, 1156, 1157, 1162, 1163, 1164, 1166, 1167, 1185, 1186, 1197, 1198, 1199, 1200, 1201, 1202, 1207, 1208, 1209, 1210, 1211, 1213, 1218, 1219, 1220, 1264, 1269, 1270, 1273, 1278, 1279, 1282, 1286, 1289, 1290, 1295, 1296, 1299, 1303, 1306, 1311, 1312, 1315, 1319, 1322, 1323, 1328, 1329, 1332, 1336, 1339, 1340, 1345, 1346, 1349, 1353, 1356, 1357, 1358, 1363, 1364, 1367, 1371, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1386, 1387, 1388, 1389, 1391, 1394, 1399, 1400, 1401, 1406, 1407, 1408, 1413, 1414, 1416, 1417, 1418, 1419, 1420, 1421, 1426, 1427, 1429, 1430, 1431, 1434, 1439, 1440, 1441, 1442, 1447, 1450, 1451, 1457, 1462, 1463, 1466, 1472, 1483, 1484, 1485, 1486, 1489, 1494, 1495, 1496, 1497, 1498, 1504, 1509, 1510, 1511, 1513, 1518, 1519, 1520, 1526, 1527, 1528, 1529, 1532, 1555, 1560, 1561, 1564, 1566, 1569, 1573, 1575, 1576, 1577, 1582, 1583, 1586, 1588, 1589, 1590, 1591, 1594, 1599, 1600, 1601, 1602, 1607, 1608, 1613, 1614, 1615, 1618, 1619, 1622, 1628, 1629, 1634, 1635, 1640, 1641, 1644, 1649, 1650, 1654, 1663, 1668, 1669, 1671, 1672, 1673, 1678, 1679, 1680, 1682, 1683, 1692, 1697, 1698, 1700, 1701, 1702, 1707, 1708, 1709, 1711, 1712, 1726, 1727, 1732, 1733, 1738, 1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1763, 1764, 1781, 1782, 1787, 1788, 1791, 1792, 1797, 1798, 1801, 1802, 1807, 1808, 1811, 1815, 1818, 1822, 1823, 1824, 1827, 1832, 1833, 1834, 1836, 1837, 1838, 1839, 1840, 1841, 1846, 1847, 1852, 1857, 1858, 1860, 1866, 1867, 1868, 1875, 1876, 1877, 1878, 1879, 1893, 1898, 1899, 1903, 1904, 1908, 1909, 1913, 1914, 1918, 1919, 1923, 1924, 1927, 1934, 1939, 1940, 1943, 1944, 1945, 1946, 1947, 1953, 1954, 1959, 1960, 1961, 1970, 1971, 1972, 1973, 1974, 1977, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1997, 2000, 2003, 2007, 2011, 2014, 2017, 2021, 2024, 2027, 2031, 2035, 2038, 2041, 2045};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 234 106
new 0 234 106
capacitySet 1 235 107
assign 1 248 113
new 0 248 113
assign 1 248 114
once 0 248 114
new 1 248 115
assign 1 252 122
undef 1 252 127
assign 1 253 128
new 0 253 128
assign 1 254 131
equals 1 254 136
return 1 255 137
assign 1 291 146
greater 1 291 151
setValue 1 292 152
setValue 1 294 154
assign 1 298 164
new 0 298 164
assign 1 298 165
once 0 298 165
new 1 298 166
assign 1 299 167
new 0 299 167
assign 1 299 168
once 0 299 168
setValue 1 299 169
assign 1 300 170
new 0 300 170
assign 1 300 171
once 0 300 171
setHex 2 300 172
assign 1 304 182
new 0 304 182
assign 1 304 183
getCode 2 304 183
assign 1 304 184
new 0 304 184
assign 1 304 185
new 0 304 185
assign 1 304 186
new 0 304 186
assign 1 304 187
toString 3 304 187
return 1 304 188
assign 1 308 192
hexNew 1 308 192
setCode 2 309 193
assign 1 313 209
toString 0 313 209
assign 1 314 210
undef 1 314 215
assign 1 315 216
new 0 315 216
assign 1 316 217
new 0 316 217
assign 1 318 219
sizeGet 0 318 219
setValue 1 318 220
addValue 1 319 221
assign 1 321 222
lesser 1 321 227
assign 1 322 228
new 0 322 228
assign 1 322 229
add 1 322 229
assign 1 322 230
new 0 322 230
assign 1 322 231
multiply 1 322 231
assign 1 322 232
new 0 322 232
assign 1 322 233
divide 1 322 233
capacitySet 1 323 234
assign 1 325 236
new 0 325 236
assign 1 325 237
sizeGet 0 325 237
copyValue 4 325 238
return 1 329 242
return 1 333 245
addValue 1 337 248
write 1 341 252
assign 1 351 263
copy 0 351 263
clear 0 352 264
return 1 353 265
assign 1 357 276
new 0 357 276
assign 1 357 277
greater 1 357 282
assign 1 358 283
new 0 358 283
assign 1 358 284
once 0 358 284
assign 1 358 285
new 0 358 285
assign 1 358 286
once 0 358 286
setIntUnchecked 2 358 287
assign 1 359 288
new 0 359 288
assign 1 359 289
once 0 359 289
setValue 1 359 290
assign 1 364 300
new 0 364 300
new 1 364 301
assign 1 365 302
new 0 365 302
assign 1 365 303
once 0 365 303
setValue 1 365 304
assign 1 366 305
new 0 366 305
assign 1 366 306
once 0 366 306
setCodeUnchecked 2 366 307
assign 1 370 323
new 0 370 323
assign 1 370 324
newlineGet 0 370 324
assign 1 371 325
ends 1 371 325
assign 1 372 327
new 0 372 327
assign 1 372 328
sizeGet 0 372 328
assign 1 372 329
subtract 1 372 329
assign 1 372 330
substring 2 372 330
return 1 372 331
assign 1 374 333
new 0 374 333
assign 1 375 334
ends 1 375 334
assign 1 376 336
new 0 376 336
assign 1 376 337
sizeGet 0 376 337
assign 1 376 338
subtract 1 376 338
assign 1 376 339
substring 2 376 339
return 1 376 340
return 1 378 342
assign 1 382 348
new 0 382 348
assign 1 382 349
add 1 382 349
assign 1 382 350
new 1 382 350
addValue 1 383 351
return 1 384 352
assign 1 388 362
find 1 388 362
assign 1 389 363
undef 1 389 368
assign 1 0 369
assign 1 389 372
new 0 389 372
assign 1 389 373
notEquals 1 389 378
assign 1 0 379
assign 1 0 382
assign 1 390 386
new 0 390 386
return 1 390 387
assign 1 392 389
new 0 392 389
return 1 392 390
assign 1 396 401
undef 1 396 406
assign 1 396 407
new 0 396 407
return 1 396 408
assign 1 397 410
sizeGet 0 397 410
assign 1 397 411
subtract 1 397 411
assign 1 397 412
find 2 397 412
assign 1 398 413
undef 1 398 418
assign 1 399 419
new 0 399 419
return 1 399 420
assign 1 401 422
new 0 401 422
return 1 401 423
assign 1 405 432
undef 1 405 437
assign 1 0 438
assign 1 405 441
find 1 405 441
assign 1 405 442
undef 1 405 447
assign 1 0 448
assign 1 0 451
assign 1 406 455
new 0 406 455
return 1 406 456
assign 1 408 458
new 0 408 458
return 1 408 459
assign 1 412 463
isInteger 0 412 463
return 1 412 464
assign 1 416 484
new 0 416 484
assign 1 417 485
new 0 417 485
assign 1 417 488
lesser 1 417 493
getInt 2 418 494
assign 1 419 495
new 0 419 495
assign 1 419 496
equals 1 419 501
assign 1 419 502
new 0 419 502
assign 1 419 503
equals 1 419 508
assign 1 0 509
assign 1 419 512
new 0 419 512
assign 1 419 513
equals 1 419 518
assign 1 0 519
assign 1 0 522
assign 1 0 526
assign 1 0 529
assign 1 0 533
assign 1 421 538
new 0 421 538
assign 1 421 539
greater 1 421 544
assign 1 0 545
assign 1 421 548
new 0 421 548
assign 1 421 549
lesser 1 421 554
assign 1 0 555
assign 1 0 558
assign 1 422 562
new 0 422 562
return 1 422 563
incrementValue 0 417 566
assign 1 425 572
new 0 425 572
return 1 425 573
assign 1 429 585
new 0 429 585
assign 1 430 586
new 0 430 586
assign 1 430 589
lesser 1 430 594
getInt 2 431 595
assign 1 432 596
new 0 432 596
assign 1 432 597
greater 1 432 602
assign 1 432 603
new 0 432 603
assign 1 432 604
lesser 1 432 609
assign 1 0 610
assign 1 0 613
assign 1 0 617
assign 1 433 620
new 0 433 620
addValue 1 433 621
setIntUnchecked 2 434 622
incrementValue 0 430 624
assign 1 440 635
copy 0 440 635
assign 1 440 636
lowerValue 0 440 636
return 1 440 637
assign 1 444 649
new 0 444 649
assign 1 445 650
new 0 445 650
assign 1 445 653
lesser 1 445 658
getInt 2 446 659
assign 1 447 660
new 0 447 660
assign 1 447 661
greater 1 447 666
assign 1 447 667
new 0 447 667
assign 1 447 668
lesser 1 447 673
assign 1 0 674
assign 1 0 677
assign 1 0 681
assign 1 448 684
new 0 448 684
subtractValue 1 448 685
setIntUnchecked 2 449 686
incrementValue 0 445 688
assign 1 455 699
copy 0 455 699
assign 1 455 700
upperValue 0 455 700
return 1 455 701
assign 1 459 707
new 0 459 707
assign 1 459 708
split 1 459 708
assign 1 459 709
join 2 459 709
return 1 459 710
assign 1 465 722
new 0 465 722
assign 1 466 723
new 0 466 723
assign 1 467 724
new 0 467 724
assign 1 468 725
find 2 468 725
assign 1 469 726
def 1 469 731
assign 1 470 732
substring 2 470 732
addValue 1 470 733
addValue 1 471 734
assign 1 472 735
sizeGet 0 472 735
assign 1 472 736
add 1 472 736
assign 1 473 737
sizeGet 0 473 737
assign 1 473 738
substring 2 473 738
addValue 1 473 739
assign 1 475 742
copy 0 475 742
return 1 475 743
return 1 477 745
assign 1 482 757
new 0 482 757
assign 1 483 758
new 0 483 758
assign 1 484 759
new 0 484 759
assign 1 485 762
def 1 485 767
assign 1 486 768
find 2 486 768
assign 1 487 769
def 1 487 774
assign 1 488 775
substring 2 488 775
addValue 1 488 776
addValue 1 489 777
assign 1 490 778
sizeGet 0 490 778
assign 1 490 779
add 1 490 779
assign 1 493 782
sizeGet 0 493 782
assign 1 493 783
substring 2 493 783
addValue 1 493 784
return 1 497 791
assign 1 502 801
new 0 502 801
assign 1 502 802
new 1 502 802
assign 1 503 803
mbiterGet 0 503 803
assign 1 504 804
new 0 504 804
assign 1 504 807
lesser 1 504 812
next 1 505 813
incrementValue 0 504 814
assign 1 507 820
next 1 507 820
assign 1 507 821
toString 0 507 821
return 1 508 822
assign 1 512 830
new 0 512 830
assign 1 513 831
new 0 513 831
setValue 1 513 832
assign 1 514 833
new 0 514 833
assign 1 514 836
lesser 1 514 841
getInt 2 515 842
assign 1 516 843
new 0 516 843
multiplyValue 1 516 844
addValue 1 517 845
incrementValue 0 514 846
return 1 520 852
assign 1 524 857
new 0 524 857
assign 1 524 858
hashValue 1 524 858
return 1 524 859
assign 1 528 864
new 0 528 864
assign 1 528 865
getCode 2 528 865
return 1 528 866
assign 1 538 873
new 0 538 873
assign 1 538 874
greaterEquals 1 538 879
assign 1 538 880
greater 1 538 885
assign 1 0 886
assign 1 0 889
assign 1 0 893
return 1 575 900
return 1 577 902
assign 1 588 909
new 0 588 909
assign 1 588 910
greaterEquals 1 588 915
assign 1 588 916
greater 1 588 921
assign 1 0 922
assign 1 0 925
assign 1 0 929
return 1 623 939
return 1 625 941
assign 1 629 948
new 0 629 948
assign 1 629 949
greaterEquals 1 629 954
assign 1 629 955
greater 1 629 960
assign 1 0 961
assign 1 0 964
assign 1 0 968
setIntUnchecked 2 630 971
assign 1 635 980
new 0 635 980
assign 1 635 981
greaterEquals 1 635 986
assign 1 635 987
greater 1 635 992
assign 1 0 993
assign 1 0 996
assign 1 0 1000
setCodeUnchecked 2 636 1003
assign 1 641 1031
assign 1 642 1032
sizeGet 0 642 1032
assign 1 642 1033
copy 0 642 1033
assign 1 643 1034
new 1 643 1034
assign 1 644 1035
new 0 644 1035
assign 1 645 1036
new 0 645 1036
assign 1 646 1037
new 0 646 1037
assign 1 646 1040
lesser 1 646 1045
getInt 2 647 1046
assign 1 648 1047
new 0 648 1047
assign 1 648 1048
greater 1 648 1053
assign 1 648 1054
new 0 648 1054
assign 1 648 1055
lesser 1 648 1060
assign 1 0 1061
assign 1 0 1064
assign 1 0 1068
assign 1 0 1071
assign 1 648 1074
new 0 648 1074
assign 1 648 1075
greater 1 648 1080
assign 1 648 1081
new 0 648 1081
assign 1 648 1082
lesser 1 648 1087
assign 1 0 1088
assign 1 0 1091
assign 1 0 1095
assign 1 0 1098
assign 1 0 1101
assign 1 0 1105
assign 1 648 1108
new 0 648 1108
assign 1 648 1109
greater 1 648 1114
assign 1 648 1115
new 0 648 1115
assign 1 648 1116
lesser 1 648 1121
assign 1 0 1122
assign 1 0 1125
assign 1 0 1129
assign 1 0 1132
assign 1 0 1135
setIntUnchecked 2 649 1139
incrementValue 0 650 1140
incrementValue 0 646 1142
sizeSet 1 653 1148
return 1 654 1149
assign 1 658 1156
new 0 658 1156
assign 1 658 1157
lesserEquals 1 658 1162
assign 1 659 1163
new 0 659 1163
return 1 659 1164
assign 1 661 1166
new 0 661 1166
return 1 661 1167
assign 1 758 1185
rfind 1 758 1185
return 1 758 1186
assign 1 764 1197
copy 0 764 1197
assign 1 764 1198
reverseBytes 0 764 1198
assign 1 764 1199
copy 0 764 1199
assign 1 764 1200
reverseBytes 0 764 1200
assign 1 764 1201
find 1 764 1201
assign 1 766 1202
def 1 766 1207
assign 1 767 1208
sizeGet 0 767 1208
addValue 1 767 1209
assign 1 768 1210
subtract 1 768 1210
return 1 768 1211
return 1 770 1213
assign 1 774 1218
new 0 774 1218
assign 1 774 1219
find 2 774 1219
return 1 774 1220
assign 1 780 1264
undef 1 780 1269
assign 1 0 1270
assign 1 780 1273
undef 1 780 1278
assign 1 0 1279
assign 1 0 1282
assign 1 0 1286
assign 1 780 1289
new 0 780 1289
assign 1 780 1290
lesser 1 780 1295
assign 1 0 1296
assign 1 0 1299
assign 1 0 1303
assign 1 780 1306
greaterEquals 1 780 1311
assign 1 0 1312
assign 1 0 1315
assign 1 0 1319
assign 1 780 1322
sizeGet 0 780 1322
assign 1 780 1323
greater 1 780 1328
assign 1 0 1329
assign 1 0 1332
assign 1 0 1336
assign 1 780 1339
new 0 780 1339
assign 1 780 1340
equals 1 780 1345
assign 1 0 1346
assign 1 0 1349
assign 1 0 1353
assign 1 780 1356
sizeGet 0 780 1356
assign 1 780 1357
new 0 780 1357
assign 1 780 1358
equals 1 780 1363
assign 1 0 1364
assign 1 0 1367
return 1 781 1371
assign 1 784 1373
assign 1 785 1374
copy 0 785 1374
assign 1 786 1375
new 0 786 1375
assign 1 787 1376
new 0 787 1376
assign 1 788 1377
new 0 788 1377
getInt 2 788 1378
assign 1 790 1379
sizeGet 0 790 1379
assign 1 792 1380
new 0 792 1380
assign 1 792 1381
greater 1 792 1386
assign 1 793 1387
new 0 793 1387
assign 1 794 1388
new 0 794 1388
assign 1 795 1389
new 0 795 1389
assign 1 797 1391
new 0 797 1391
assign 1 798 1394
lesser 1 798 1399
getInt 2 799 1400
assign 1 800 1401
equals 1 800 1406
assign 1 801 1407
new 0 801 1407
assign 1 801 1408
equals 1 801 1413
return 1 802 1414
setValue 1 804 1416
incrementValue 0 805 1417
setValue 1 806 1418
assign 1 807 1419
sizeGet 0 807 1419
addValue 1 807 1420
assign 1 808 1421
greater 1 808 1426
return 1 809 1427
assign 1 811 1429
new 0 811 1429
assign 1 811 1430
once 0 811 1430
setValue 1 811 1431
assign 1 812 1434
lesser 1 812 1439
getInt 2 813 1440
getInt 2 814 1441
assign 1 815 1442
notEquals 1 815 1447
incrementValue 0 818 1450
incrementValue 0 819 1451
assign 1 821 1457
equals 1 821 1462
return 1 822 1463
incrementValue 0 825 1466
return 1 827 1472
assign 1 831 1483
new 0 831 1483
assign 1 832 1484
new 0 832 1484
assign 1 833 1485
find 2 833 1485
assign 1 834 1486
sizeGet 0 834 1486
assign 1 835 1489
def 1 835 1494
assign 1 836 1495
substring 2 836 1495
addValue 1 836 1496
assign 1 837 1497
add 1 837 1497
assign 1 838 1498
find 2 838 1498
assign 1 840 1504
lesser 1 840 1509
assign 1 841 1510
substring 2 841 1510
addValue 1 841 1511
return 1 843 1513
assign 1 847 1518
new 0 847 1518
assign 1 847 1519
join 2 847 1519
return 1 847 1520
assign 1 851 1526
new 0 851 1526
assign 1 851 1527
lineSplitterGet 0 851 1527
assign 1 851 1528
tokenize 1 851 1528
return 1 851 1529
return 1 855 1532
assign 1 863 1555
undef 1 863 1560
assign 1 0 1561
assign 1 863 1564
otherType 1 863 1564
assign 1 0 1566
assign 1 0 1569
return 1 864 1573
assign 1 866 1575
assign 1 867 1576
sizeGet 0 867 1576
assign 1 868 1577
greater 1 868 1582
assign 1 869 1583
assign 1 871 1586
assign 1 873 1588
new 0 873 1588
assign 1 874 1589
new 0 874 1589
assign 1 875 1590
new 0 875 1590
assign 1 876 1591
new 0 876 1591
assign 1 876 1594
lesser 1 876 1599
getCode 2 877 1600
getCode 2 878 1601
assign 1 879 1602
notEquals 1 879 1607
assign 1 880 1608
greater 1 880 1613
assign 1 881 1614
new 0 881 1614
return 1 881 1615
assign 1 883 1618
new 0 883 1618
return 1 883 1619
incrementValue 0 876 1622
assign 1 887 1628
new 0 887 1628
assign 1 887 1629
equals 1 887 1634
assign 1 888 1635
greater 1 888 1640
assign 1 889 1641
new 0 889 1641
assign 1 890 1644
greater 1 890 1649
assign 1 891 1650
new 0 891 1650
return 1 894 1654
assign 1 898 1663
undef 1 898 1668
return 1 898 1669
assign 1 899 1671
compare 1 899 1671
assign 1 899 1672
new 0 899 1672
assign 1 899 1673
equals 1 899 1678
assign 1 900 1679
new 0 900 1679
return 1 900 1680
assign 1 902 1682
new 0 902 1682
return 1 902 1683
assign 1 906 1692
undef 1 906 1697
return 1 906 1698
assign 1 907 1700
compare 1 907 1700
assign 1 907 1701
new 0 907 1701
assign 1 907 1702
equals 1 907 1707
assign 1 908 1708
new 0 908 1708
return 1 908 1709
assign 1 910 1711
new 0 910 1711
return 1 910 1712
assign 1 965 1726
new 0 965 1726
return 1 965 1727
assign 1 969 1732
equals 1 969 1732
assign 1 969 1733
not 0 969 1738
return 1 969 1738
assign 1 973 1749
toString 0 973 1749
assign 1 974 1750
sizeGet 0 974 1750
assign 1 974 1751
add 1 974 1751
assign 1 974 1752
new 1 974 1752
assign 1 975 1753
new 0 975 1753
assign 1 975 1754
new 0 975 1754
copyValue 4 975 1755
assign 1 976 1756
new 0 976 1756
assign 1 976 1757
sizeGet 0 976 1757
copyValue 4 976 1758
return 1 977 1759
assign 1 980 1763
new 0 980 1763
return 1 980 1764
assign 1 984 1781
new 0 984 1781
assign 1 984 1782
lesser 1 984 1787
assign 1 0 1788
assign 1 984 1791
sizeGet 0 984 1791
assign 1 984 1792
greater 1 984 1797
assign 1 0 1798
assign 1 984 1801
sizeGet 0 984 1801
assign 1 984 1802
greater 1 984 1807
assign 1 0 1808
assign 1 0 1811
assign 1 0 1815
assign 1 0 1818
assign 1 985 1822
new 0 985 1822
assign 1 985 1823
new 1 985 1823
throw 1 985 1824
assign 1 989 1827
undef 1 989 1832
assign 1 990 1833
new 0 990 1833
assign 1 991 1834
new 0 991 1834
setValue 1 993 1836
subtractValue 1 994 1837
assign 1 995 1838
setValue 1 997 1839
addValue 1 998 1840
assign 1 1000 1841
greater 1 1000 1846
capacitySet 1 1001 1847
assign 1 1034 1852
greater 1 1034 1857
setValue 1 1038 1858
return 1 1040 1860
assign 1 1045 1866
sizeGet 0 1045 1866
assign 1 1045 1867
substring 2 1045 1867
return 1 1045 1868
assign 1 1049 1875
subtract 1 1049 1875
assign 1 1049 1876
new 1 1049 1876
assign 1 1049 1877
new 0 1049 1877
assign 1 1049 1878
copyValue 4 1049 1878
return 1 1049 1879
output 0 1141 1893
assign 1 1145 1898
new 1 1145 1898
return 1 1145 1899
assign 1 1149 1903
new 1 1149 1903
return 1 1149 1904
assign 1 1153 1908
new 1 1153 1908
return 1 1153 1909
assign 1 1157 1913
new 1 1157 1913
return 1 1157 1914
assign 1 1161 1918
new 1 1161 1918
return 1 1161 1919
assign 1 1165 1923
new 1 1165 1923
return 1 1165 1924
return 1 1169 1927
assign 1 1173 1934
undef 1 1173 1939
new 0 1174 1940
assign 1 1176 1943
sizeGet 0 1176 1943
assign 1 1176 1944
new 0 1176 1944
assign 1 1176 1945
add 1 1176 1945
new 1 1176 1946
addValue 1 1177 1947
assign 1 1182 1953
new 0 1182 1953
return 1 1182 1954
assign 1 1186 1959
new 0 1186 1959
assign 1 1186 1960
strip 1 1186 1960
return 1 1186 1961
assign 1 1190 1970
new 0 1190 1970
assign 1 1191 1971
new 0 1191 1971
assign 1 1192 1972
new 0 1192 1972
assign 1 1193 1973
new 0 1193 1973
assign 1 1193 1974
subtract 1 1193 1974
assign 1 1194 1977
greater 1 1194 1982
getInt 2 1195 1983
getInt 2 1196 1984
setInt 2 1197 1985
setInt 2 1198 1986
incrementValue 0 1199 1987
decrementValue 0 1200 1988
return 1 0 1997
return 1 0 2000
assign 1 0 2003
assign 1 0 2007
return 1 0 2011
return 1 0 2014
assign 1 0 2017
return 1 0 2021
return 1 0 2024
assign 1 0 2027
assign 1 0 2031
return 1 0 2035
return 1 0 2038
assign 1 0 2041
assign 1 0 2045
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2091241279: return bem_create_0();
case -1400770094: return bem_many_0();
case 1299948053: return bem_serializeContents_0();
case 1398808446: return bem_output_0();
case -2113588581: return bem_lowerValue_0();
case -896472297: return bem_extractString_0();
case -2030922830: return bem_mbiterGet_0();
case -1423578661: return bem_print_0();
case 1480082499: return bem_stringIteratorGet_0();
case 758802515: return bem_once_0();
case -1900486105: return bem_readString_0();
case 2145286729: return bem_vstringGet_0();
case -512236724: return bem_deserializeClassNameGet_0();
case 1957608515: return bem_fieldIteratorGet_0();
case -922319077: return bem_sizeGet_0();
case 1471219385: return bem_isEmptyGet_0();
case -1073996822: return bem_siziGet_0();
case 2124070457: return bem_sizeGetDirect_0();
case -923057320: return bem_serializationIteratorGet_0();
case 1349866592: return bem_toString_0();
case 675566088: return bem_classNameGet_0();
case 640707394: return bem_siziGetDirect_0();
case 883318048: return bem_vstringSet_0();
case -1233681756: return bem_splitLines_0();
case -897003299: return bem_leniGet_0();
case -35248652: return bem_toAny_0();
case -2095163516: return bem_lower_0();
case 672818173: return bem_strip_0();
case -1515781765: return bem_biterGet_0();
case -914347833: return bem_new_0();
case -1295667197: return bem_capacityGetDirect_0();
case -245363326: return bem_copy_0();
case -518710385: return bem_fieldNamesGet_0();
case 207946039: return bem_toAlphaNum_0();
case 518862870: return bem_tagGet_0();
case -1009225112: return bem_upperValue_0();
case -837641177: return bem_isIntegerGet_0();
case 757042649: return bem_upper_0();
case 1677519287: return bem_multiByteIteratorGet_0();
case 1052263558: return bem_serializeToString_0();
case 13807179: return bem_hashGet_0();
case -2035208893: return bem_echo_0();
case -1235342010: return bem_byteIteratorGet_0();
case 646589914: return bem_sourceFileNameGet_0();
case -355066313: return bem_reverseBytes_0();
case -1817296654: return bem_close_0();
case 1992647389: return bem_isInteger_0();
case -764318191: return bem_chomp_0();
case 1932577111: return bem_readBuffer_0();
case -640933878: return bem_clear_0();
case -543665743: return bem_leniGetDirect_0();
case 993759307: return bem_iteratorGet_0();
case -319407083: return bem_open_0();
case -1879509652: return bem_capacityGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1301158157: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -1323169007: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1854173783: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case 1913486339: return bem_writeTo_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1886239833: return bem_siziSet_1(bevd_0);
case -992295107: return bem_addValue_1(bevd_0);
case 1645909378: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -230732600: return bem_leniSet_1(bevd_0);
case 120386761: return bem_siziSetDirect_1(bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -1862448714: return bem_codeNew_1(bevd_0);
case 2011962407: return bem_compare_1(bevd_0);
case 495742460: return bem_add_1(bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1717901033: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case 995471260: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 651617460: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 1673867046: return bem_sizeSetDirect_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case -78187461: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case 1849498103: return bem_leniSetDirect_1(bevd_0);
case -537932837: return bem_equals_1(bevd_0);
case 1433915672: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -340703588: return bem_sizeSet_1(bevd_0);
case -139749240: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case 1538321659: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case -208177763: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1631231618: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -606010297: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case -42820211: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 937129243: return bem_write_1(bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -1574511819: return bem_capacitySetDirect_1(bevd_0);
case -340377293: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1203859997: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 521761076: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1458616452: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1712405648: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 418153569: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -395754497: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 342958569: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1500283588: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -512042269: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -999237714: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 833337201: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 783403973: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -750359103: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1136209681: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -174301541: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_TextString();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
