package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_6_TextString extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) {
        this.bevi_bytes = bevi_bytes; 
        bevp_length = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) {
      //do copy, isOnce
      this.bevi_bytes = new byte[bevi_length];
      System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
      bevp_length = new BEC_2_4_3_MathInt(bevi_length);
      bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) {
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_length = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(String bevi_string) throws Exception {
        byte[] bevi_bytes = bevi_string.getBytes("UTF-8");
        this.bevi_bytes = bevi_bytes; 
        bevp_length = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public String bems_toJvString() throws Exception {
        String jvString = new String(bevi_bytes, 0, bevp_length.bevi_int, "UTF-8");
        return jvString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
public static BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) throws Throwable {
bevp_length = (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_capacity == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 263*/ {
bevp_capacity = (new BEC_2_4_3_MathInt(0));
} /* Line: 264*/
 else /* Line: 263*/ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 265*/ {
return this;
} /* Line: 266*/
} /* Line: 263*/

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        this.bevi_bytes = java.util.Arrays.copyOf(this.bevi_bytes, beva_ncap.bevi_int);
      }
      if (bevp_length.bevi_int > beva_ncap.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 302*/ {
bevp_length.bevi_int = beva_ncap.bevi_int;
} /* Line: 303*/
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_length.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setHex_2(bevt_2_ta_ph, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt());
bevt_1_ta_ph = bem_getCode_2(beva_pos, bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_toString_3(bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) throws Throwable {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_sizi = null;
BEC_2_4_3_MathInt bevl_nlength = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_7_TextStrings bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1870128138);
bevl_sizi = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bevl_str.bem_lengthGet_0();
bevl_sizi.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_sizi.bevi_int += bevp_length.bevi_int;
if (bevp_capacity.bevi_int < bevl_sizi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_3_ta_ph = bevl_sizi.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_2_ta_ph = bevt_3_ta_ph.bem_multiply_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_nlength = bevt_2_ta_ph.bem_divide_1(bevt_6_ta_ph);
bem_capacitySet_1(bevl_nlength);
} /* Line: 334*/
bevt_8_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_7_ta_ph = bevt_8_ta_ph.bem_zeroGet_0();
bevt_9_ta_ph = bevl_str.bem_lengthGet_0();
bem_copyValue_4(bevl_str, bevt_7_ta_ph, bevt_9_ta_ph, bevp_length);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) throws Throwable {
beva_w.bemd_1(-1439176248, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 368*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setIntUnchecked_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_length.bevi_int = bevt_4_ta_ph.bevi_int;
} /* Line: 370*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_length.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_setCodeUnchecked_2(bevt_2_ta_ph, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() throws Throwable {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_nl = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_0_ta_ph = bem_ends_1(bevl_nl);
if (bevt_0_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = bevl_nl.bem_lengthGet_0();
bevt_3_ta_ph = bevp_length.bem_subtract_1(bevt_4_ta_ph);
bevt_1_ta_ph = bem_substring_2(bevt_2_ta_ph, bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 383*/
bevl_nl = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_5_ta_ph = bem_ends_1(bevl_nl);
if (bevt_5_ta_ph.bevi_bool)/* Line: 386*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = bevl_nl.bem_lengthGet_0();
bevt_8_ta_ph = bevp_length.bem_subtract_1(bevt_9_ta_ph);
bevt_6_ta_ph = bem_substring_2(bevt_7_ta_ph, bevt_8_ta_ph);
return bevt_6_ta_ph;
} /* Line: 387*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_copy_0() throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevp_length.bem_add_1(bevt_1_ta_ph);
bevl_c = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_c.bem_addValue_1(this);
return (BEC_2_4_6_TextString) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 400*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_found.bevi_int != bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 400*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 400*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 400*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 401*/
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 407*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 407*/
bevt_3_ta_ph = beva_str.bem_lengthGet_0();
bevt_2_ta_ph = bevp_length.bem_subtract_1(bevt_3_ta_ph);
bevl_found = bem_find_2(beva_str, bevt_2_ta_ph);
if (bevl_found == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 409*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 410*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contains_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 416*/ {
bevt_3_ta_ph = bem_find_1(beva_str);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 416*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 416*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 417*/
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isIntegerGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 424*/ {
if (bevl_j.bevi_int < bevp_length.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 424*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 426*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 426*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 426*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 426*/
 else /* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 426*/ {
} /* Line: 426*/
 else /* Line: 426*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(57));
if (bevl_ic.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 428*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 428*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(48));
if (bevl_ic.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 428*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 428*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 428*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 428*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 429*/
} /* Line: 426*/
bevl_j.bevi_int++;
} /* Line: 424*/
 else /* Line: 424*/ {
break;
} /* Line: 424*/
} /* Line: 424*/
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 437*/ {
if (bevl_j.bevi_int < bevp_length.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 437*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ic.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 439*/
 else /* Line: 439*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_ic.bevi_int < bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 439*/
 else /* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 439*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 439*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ic.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 439*/
 else /* Line: 439*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 439*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 439*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 439*/
if (!(bevt_0_ta_anchor.bevi_bool))/* Line: 439*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 440*/
bevl_j.bevi_int++;
} /* Line: 437*/
 else /* Line: 437*/ {
break;
} /* Line: 437*/
} /* Line: 437*/
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumericGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAlphaNumGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 452*/ {
if (bevl_j.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 452*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 454*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 454*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 454*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 454*/
 else /* Line: 454*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 454*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_ta_ph.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 456*/
bevl_j.bevi_int++;
} /* Line: 452*/
 else /* Line: 452*/ {
break;
} /* Line: 452*/
} /* Line: 452*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_lowerValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 467*/ {
if (bevl_j.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 467*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 469*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 469*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 469*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 469*/
 else /* Line: 469*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 469*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_ta_ph);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 471*/
bevl_j.bevi_int++;
} /* Line: 467*/
 else /* Line: 467*/ {
break;
} /* Line: 467*/
} /* Line: 467*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_upperValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 486*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_2_ta_ph = beva_from.bem_lengthGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = bem_lengthGet_0();
bevt_3_ta_ph = bem_substring_2(bevl_last, bevt_4_ta_ph);
bevl_res.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 490*/
 else /* Line: 491*/ {
bevt_5_ta_ph = beva_from.bem_copy_0();
return bevt_5_ta_ph;
} /* Line: 492*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 502*/ {
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 502*/ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 504*/ {
bevt_2_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_3_ta_ph = beva_from.bem_lengthGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_ta_ph);
} /* Line: 507*/
 else /* Line: 509*/ {
bevt_5_ta_ph = bem_lengthGet_0();
bevt_4_ta_ph = bem_substring_2(bevl_last, bevt_5_ta_ph);
bevl_res.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 510*/
} /* Line: 504*/
 else /* Line: 502*/ {
break;
} /* Line: 502*/
} /* Line: 502*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_j = bem_mbiterGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 521*/ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 521*/ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 521*/
 else /* Line: 521*/ {
break;
} /* Line: 521*/
} /* Line: 521*/
bevt_2_ta_ph = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_ta_ph.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 531*/ {
if (bevl_j.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 531*/ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_ta_ph);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 531*/
 else /* Line: 531*/ {
break;
} /* Line: 531*/
} /* Line: 531*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_hashValue_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getCode_2(beva_pos, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 549*/ {
if (bevp_length.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 549*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 549*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 549*/
 else /* Line: 549*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 549*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 571*/
 else /* Line: 579*/ {
return null;
} /* Line: 580*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 586*/ {
if (bevp_length.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 586*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 586*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 586*/
 else /* Line: 586*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 586*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int < 0) {
            beva_into.bevi_int += 256;
         }
         } /* Line: 605*/
 else /* Line: 610*/ {
return null;
} /* Line: 611*/
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 617*/ {
if (bevp_length.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 617*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 617*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 617*/
 else /* Line: 617*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 617*/ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 618*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 623*/ {
if (bevp_length.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 623*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 623*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 623*/
 else /* Line: 623*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 623*/ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 624*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() throws Throwable {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevl_input = this;
bevt_3_ta_ph = bevl_input.bem_lengthGet_0();
bevl_insz = bevt_3_ta_ph.bem_copy_0();
bevl_output = (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (new BEC_2_4_3_MathInt());
bevl_p = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 634*/ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 634*/ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_c.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 636*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_c.bevi_int < bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 636*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 636*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 636*/
 else /* Line: 636*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 636*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 636*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_c.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 636*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_c.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 636*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 636*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 636*/
 else /* Line: 636*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 636*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 636*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 636*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 636*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 636*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_c.bevi_int > bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 636*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_c.bevi_int < bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 636*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 636*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 636*/
 else /* Line: 636*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 636*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 636*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 636*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 636*/ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 638*/
bevl_i.bevi_int++;
} /* Line: 634*/
 else /* Line: 634*/ {
break;
} /* Line: 634*/
} /* Line: 634*/
bevl_output.bem_lengthSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 646*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 647*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b > 127) {
        twvls_b -= 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_reverseBytes_0();
bevt_3_ta_ph = beva_str.bem_copy_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_reverseBytes_0();
bevl_rpos = bevt_0_ta_ph.bem_find_1(bevt_2_ta_ph);
if (bevl_rpos == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 721*/ {
bevt_5_ta_ph = beva_str.bem_lengthGet_0();
bevl_rpos.bevi_int += bevt_5_ta_ph.bevi_int;
bevt_6_ta_ph = bevp_length.bem_subtract_1(bevl_rpos);
return bevt_6_ta_ph;
} /* Line: 723*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_find_2(beva_str, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strlength = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
if (beva_str == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 735*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
if (beva_start == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 735*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 735*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 735*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_start.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 735*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 735*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 735*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
if (beva_start.bevi_int >= bevp_length.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 735*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 735*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 735*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_12_ta_ph = beva_str.bem_lengthGet_0();
if (bevt_12_ta_ph.bevi_int > bevp_length.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 735*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 735*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 735*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 735*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 735*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 735*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_16_ta_ph = beva_str.bem_lengthGet_0();
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 735*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 735*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 735*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 735*/ {
return null;
} /* Line: 736*/
bevl_end = bevp_length;
bevl_current = beva_start.bem_copy_0();
bevl_myval = (new BEC_2_4_3_MathInt());
bevl_strfirst = (new BEC_2_4_3_MathInt());
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_ta_ph, bevl_strfirst);
bevl_strlength = beva_str.bem_lengthGet_0();
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_strlength.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 747*/ {
bevl_strval = (new BEC_2_4_3_MathInt());
bevl_current2 = (new BEC_2_4_3_MathInt());
bevl_end2 = (new BEC_2_4_3_MathInt());
} /* Line: 750*/
bevl_currentstr2 = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 753*/ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 753*/ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 755*/ {
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_strlength.bevi_int == bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 756*/ {
return bevl_current;
} /* Line: 757*/
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_ta_ph = beva_str.bem_lengthGet_0();
bevl_end2.bevi_int += bevt_25_ta_ph.bevi_int;
if (bevl_end2.bevi_int > bevp_length.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 763*/ {
return null;
} /* Line: 764*/
bevt_27_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_currentstr2.bevi_int = bevt_27_ta_ph.bevi_int;
while (true)
/* Line: 767*/ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 767*/ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 770*/ {
break;
} /* Line: 771*/
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 774*/
 else /* Line: 767*/ {
break;
} /* Line: 767*/
} /* Line: 767*/
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 776*/ {
return bevl_current;
} /* Line: 777*/
} /* Line: 776*/
bevl_current.bevi_int++;
} /* Line: 780*/
 else /* Line: 753*/ {
break;
} /* Line: 753*/
} /* Line: 753*/
return null;
} /*method end*/
public BEC_2_9_4_ContainerList bem_split_1(BEC_2_4_6_TextString beva_delim) throws Throwable {
BEC_2_9_4_ContainerList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevl_splits = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_lengthGet_0();
while (true)
/* Line: 790*/ {
if (bevl_i == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 790*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_ta_ph);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 793*/
 else /* Line: 790*/ {
break;
} /* Line: 790*/
} /* Line: 790*/
if (bevl_last.bevi_int < bevp_length.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 795*/ {
bevt_3_ta_ph = bem_substring_2(bevl_last, bevp_length);
bevl_splits.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 796*/
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_join_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_4_3_MathInt bevl_mylength = null;
BEC_2_4_3_MathInt bevl_olength = null;
BEC_2_4_3_MathInt bevl_maxlength = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
if (beva_stri == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 814*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 814*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_otherType_2(beva_stri, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 814*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 814*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 814*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 814*/ {
return null;
} /* Line: 815*/
bevl_mylength = bevp_length;
bevl_olength = (BEC_2_4_3_MathInt) beva_stri.bemd_0(-250278628);
if (bevl_mylength.bevi_int > bevl_olength.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 819*/ {
bevl_maxlength = bevl_olength;
} /* Line: 820*/
 else /* Line: 821*/ {
bevl_maxlength = bevl_mylength;
} /* Line: 822*/
bevl_myret = (new BEC_2_4_3_MathInt());
bevl_mv = (new BEC_2_4_3_MathInt());
bevl_ov = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 827*/ {
if (bevl_i.bevi_int < bevl_maxlength.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 827*/ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(470106603, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 830*/ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 831*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(1));
return bevt_8_ta_ph;
} /* Line: 832*/
 else /* Line: 833*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(-1));
return bevt_9_ta_ph;
} /* Line: 834*/
} /* Line: 831*/
bevl_i.bevi_int++;
} /* Line: 827*/
 else /* Line: 827*/ {
break;
} /* Line: 827*/
} /* Line: 827*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_myret.bevi_int == bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 838*/ {
if (bevl_mylength.bevi_int > bevl_olength.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 839*/ {
bevl_myret = (new BEC_2_4_3_MathInt(1));
} /* Line: 840*/
 else /* Line: 839*/ {
if (bevl_olength.bevi_int > bevl_mylength.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 841*/ {
bevl_myret = (new BEC_2_4_3_MathInt(-1));
} /* Line: 842*/
} /* Line: 839*/
} /* Line: 839*/
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 849*/ {
return null;
} /* Line: 849*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(-1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 850*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 851*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 857*/ {
return null;
} /* Line: 857*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 858*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 859*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 865*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 865*/

    BEC_2_4_6_TextString bevls_stri = (BEC_2_4_6_TextString) beva_stri;
    if (this.bevp_length.bevi_int == bevls_stri.bevp_length.bevi_int) {
       for (int i = 0;i < this.bevp_length.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_str);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1870128138);
bevt_1_ta_ph = bevl_str.bem_lengthGet_0();
bevt_0_ta_ph = bevp_length.bem_add_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_ta_ph, bevp_length, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevl_str.bem_lengthGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_ta_ph, bevt_5_ta_ph, bevp_length);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_create_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) throws Throwable {
BEC_2_4_3_MathInt bevl_leni = null;
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_4_3_MathInt bevl_sizi = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_zeroGet_0();
if (beva_starti.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 944*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 944*/ {
bevt_5_ta_ph = beva_org.bem_lengthGet_0();
if (beva_starti.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 944*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 944*/ {
bevt_7_ta_ph = beva_org.bem_lengthGet_0();
if (beva_endi.bevi_int > bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 944*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 944*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 944*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 944*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 944*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 944*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 944*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_8_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 945*/
 else /* Line: 946*/ {
bevl_leni = (new BEC_2_4_3_MathInt());
bevl_leni.bevi_int = beva_endi.bevi_int;
bevl_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevl_leni;
bevl_sizi = (new BEC_2_4_3_MathInt());
bevl_sizi.bevi_int = beva_dstarti.bevi_int;
bevl_sizi.bevi_int += bevl_leni.bevi_int;
if (bevl_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 957*/ {
bem_capacitySet_1(bevl_sizi);
} /* Line: 958*/

         //source, sourceStart, dest, destStart, length
         System.arraycopy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevl_sizi.bevi_int > bevp_length.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 991*/ {
bevp_length.bevi_int = bevl_sizi.bevi_int;
} /* Line: 995*/
return this;
} /* Line: 997*/
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_lengthGet_0();
bevt_0_ta_ph = bem_substring_2(beva_starti, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_2_ta_ph = beva_endi.bem_subtract_1(beva_starti);
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bevt_1_ta_ph.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevi_bytes.length - 1);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_print_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevp_length.bevi_int);
System.out.write('\n');
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_snw == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1136*/ {
bem_new_0();
} /* Line: 1137*/
 else /* Line: 1138*/ {
bevt_2_ta_ph = beva_snw.bem_lengthGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_new_1(bevt_1_ta_ph);
bem_addValue_1(beva_snw);
} /* Line: 1140*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_strip_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevl_vb = (new BEC_2_4_3_MathInt());
bevl_ve = (new BEC_2_4_3_MathInt());
bevl_b = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_e = bevp_length.bem_subtract_1(bevt_0_ta_ph);
while (true)
/* Line: 1157*/ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1157*/ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1163*/
 else /* Line: 1157*/ {
break;
} /* Line: 1157*/
} /* Line: 1157*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_4_6_TextString bem_lengthSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {250, 251, 259, 259, 263, 263, 264, 265, 265, 266, 302, 302, 303, 305, 309, 309, 310, 310, 311, 311, 315, 315, 315, 315, 315, 315, 315, 319, 320, 324, 326, 327, 327, 328, 330, 330, 331, 331, 331, 331, 331, 331, 334, 336, 336, 336, 336, 340, 344, 348, 352, 362, 363, 364, 368, 368, 368, 369, 369, 369, 370, 370, 375, 375, 376, 376, 377, 377, 381, 382, 383, 383, 383, 383, 383, 385, 386, 387, 387, 387, 387, 387, 389, 393, 393, 393, 394, 395, 399, 400, 400, 0, 400, 400, 400, 0, 0, 401, 401, 403, 403, 407, 407, 407, 407, 408, 408, 408, 409, 409, 410, 410, 412, 412, 416, 416, 0, 416, 416, 416, 0, 0, 417, 417, 419, 419, 423, 424, 424, 424, 425, 426, 426, 426, 426, 426, 426, 0, 426, 426, 426, 0, 0, 0, 0, 0, 428, 428, 428, 0, 428, 428, 428, 0, 0, 429, 429, 424, 432, 432, 436, 437, 437, 437, 438, 439, 439, 439, 439, 439, 439, 0, 0, 0, 0, 439, 439, 439, 439, 439, 439, 0, 0, 0, 0, 0, 0, 439, 439, 439, 439, 439, 439, 0, 0, 0, 0, 0, 440, 440, 437, 443, 443, 447, 447, 451, 452, 452, 452, 453, 454, 454, 454, 454, 454, 454, 0, 0, 0, 455, 455, 456, 452, 462, 462, 462, 466, 467, 467, 467, 468, 469, 469, 469, 469, 469, 469, 0, 0, 0, 470, 470, 471, 467, 477, 477, 477, 482, 483, 484, 485, 486, 486, 487, 487, 488, 489, 489, 490, 490, 490, 492, 492, 494, 499, 500, 501, 502, 502, 503, 504, 504, 505, 505, 506, 507, 507, 510, 510, 510, 514, 519, 519, 520, 521, 521, 521, 522, 521, 524, 524, 525, 529, 530, 530, 531, 531, 531, 532, 533, 533, 534, 531, 537, 541, 541, 541, 545, 545, 545, 549, 549, 549, 549, 549, 0, 0, 0, 580, 582, 586, 586, 586, 586, 586, 0, 0, 0, 611, 613, 617, 617, 617, 617, 617, 0, 0, 0, 618, 623, 623, 623, 623, 623, 0, 0, 0, 624, 629, 630, 630, 631, 632, 633, 634, 634, 634, 635, 636, 636, 636, 636, 636, 636, 0, 0, 0, 0, 636, 636, 636, 636, 636, 636, 0, 0, 0, 0, 0, 0, 636, 636, 636, 636, 636, 636, 0, 0, 0, 0, 0, 637, 638, 634, 641, 642, 646, 646, 646, 647, 647, 649, 649, 719, 719, 719, 719, 719, 721, 721, 722, 722, 723, 723, 725, 729, 729, 729, 735, 735, 0, 735, 735, 0, 0, 0, 735, 735, 735, 0, 0, 0, 735, 735, 0, 0, 0, 735, 735, 735, 0, 0, 0, 735, 735, 735, 0, 0, 0, 735, 735, 735, 735, 0, 0, 736, 739, 740, 741, 742, 743, 743, 745, 747, 747, 747, 748, 749, 750, 752, 753, 753, 754, 755, 755, 756, 756, 756, 757, 759, 760, 761, 762, 762, 763, 763, 764, 766, 766, 767, 767, 768, 769, 770, 770, 773, 774, 776, 776, 777, 780, 782, 786, 787, 788, 789, 790, 790, 791, 791, 792, 793, 795, 795, 796, 796, 798, 802, 802, 802, 806, 814, 814, 0, 814, 814, 0, 0, 815, 817, 818, 819, 819, 820, 822, 824, 825, 826, 827, 827, 827, 828, 829, 830, 830, 831, 831, 832, 832, 834, 834, 827, 838, 838, 838, 839, 839, 840, 841, 841, 842, 845, 849, 849, 849, 850, 850, 850, 850, 851, 851, 853, 853, 857, 857, 857, 858, 858, 858, 858, 859, 859, 861, 861, 865, 865, 865, 865, 925, 925, 929, 929, 929, 933, 934, 934, 934, 935, 935, 935, 936, 936, 936, 937, 940, 940, 944, 944, 944, 944, 0, 944, 944, 944, 0, 944, 944, 944, 0, 0, 0, 0, 945, 945, 945, 948, 949, 950, 951, 953, 954, 955, 957, 957, 958, 991, 991, 995, 997, 1002, 1002, 1002, 1006, 1006, 1006, 1006, 1006, 1120, 1120, 1124, 1124, 1128, 1128, 1132, 1136, 1136, 1137, 1139, 1139, 1139, 1139, 1140, 1145, 1145, 1149, 1149, 1149, 1153, 1154, 1155, 1156, 1156, 1157, 1157, 1158, 1159, 1160, 1161, 1162, 1163, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {49, 50, 55, 56, 63, 68, 69, 72, 77, 78, 87, 92, 93, 95, 102, 103, 104, 105, 106, 107, 117, 118, 119, 120, 121, 122, 123, 127, 128, 145, 146, 147, 148, 149, 150, 155, 156, 157, 158, 159, 160, 161, 162, 164, 165, 166, 167, 171, 174, 177, 181, 192, 193, 194, 202, 203, 208, 209, 210, 211, 212, 213, 221, 222, 223, 224, 225, 226, 241, 242, 244, 245, 246, 247, 248, 250, 251, 253, 254, 255, 256, 257, 259, 265, 266, 267, 268, 269, 279, 280, 285, 286, 289, 290, 295, 296, 299, 303, 304, 306, 307, 318, 323, 324, 325, 327, 328, 329, 330, 335, 336, 337, 339, 340, 349, 354, 355, 358, 359, 364, 365, 368, 372, 373, 375, 376, 396, 397, 400, 405, 406, 407, 408, 413, 414, 415, 420, 421, 424, 425, 430, 431, 434, 438, 441, 445, 450, 451, 456, 457, 460, 461, 466, 467, 470, 474, 475, 478, 484, 485, 508, 509, 512, 517, 518, 519, 520, 525, 526, 527, 532, 533, 536, 540, 543, 546, 547, 552, 553, 554, 559, 560, 563, 567, 570, 573, 577, 580, 581, 586, 587, 588, 593, 594, 597, 601, 604, 607, 611, 612, 614, 620, 621, 625, 626, 638, 639, 642, 647, 648, 649, 650, 655, 656, 657, 662, 663, 666, 670, 673, 674, 675, 677, 688, 689, 690, 702, 703, 706, 711, 712, 713, 714, 719, 720, 721, 726, 727, 730, 734, 737, 738, 739, 741, 752, 753, 754, 766, 767, 768, 769, 770, 775, 776, 777, 778, 779, 780, 781, 782, 783, 786, 787, 789, 801, 802, 803, 806, 811, 812, 813, 818, 819, 820, 821, 822, 823, 826, 827, 828, 835, 845, 846, 847, 848, 851, 856, 857, 858, 864, 865, 866, 874, 875, 876, 877, 880, 885, 886, 887, 888, 889, 890, 896, 901, 902, 903, 908, 909, 910, 917, 918, 923, 924, 929, 930, 933, 937, 944, 946, 953, 954, 959, 960, 965, 966, 969, 973, 983, 985, 992, 993, 998, 999, 1004, 1005, 1008, 1012, 1015, 1024, 1025, 1030, 1031, 1036, 1037, 1040, 1044, 1047, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1084, 1089, 1090, 1091, 1092, 1097, 1098, 1099, 1104, 1105, 1108, 1112, 1115, 1118, 1119, 1124, 1125, 1126, 1131, 1132, 1135, 1139, 1142, 1145, 1149, 1152, 1153, 1158, 1159, 1160, 1165, 1166, 1169, 1173, 1176, 1179, 1183, 1184, 1186, 1192, 1193, 1200, 1201, 1206, 1207, 1208, 1210, 1211, 1236, 1237, 1238, 1239, 1240, 1241, 1246, 1247, 1248, 1249, 1250, 1252, 1257, 1258, 1259, 1302, 1307, 1308, 1311, 1316, 1317, 1320, 1324, 1327, 1328, 1333, 1334, 1337, 1341, 1344, 1349, 1350, 1353, 1357, 1360, 1361, 1366, 1367, 1370, 1374, 1377, 1378, 1383, 1384, 1387, 1391, 1394, 1395, 1396, 1401, 1402, 1405, 1409, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1424, 1425, 1426, 1427, 1429, 1432, 1437, 1438, 1439, 1444, 1445, 1446, 1451, 1452, 1454, 1455, 1456, 1457, 1458, 1459, 1464, 1465, 1467, 1468, 1471, 1476, 1477, 1478, 1479, 1484, 1487, 1488, 1494, 1499, 1500, 1503, 1509, 1520, 1521, 1522, 1523, 1526, 1531, 1532, 1533, 1534, 1535, 1541, 1546, 1547, 1548, 1550, 1555, 1556, 1557, 1560, 1584, 1589, 1590, 1593, 1594, 1596, 1599, 1603, 1605, 1606, 1607, 1612, 1613, 1616, 1618, 1619, 1620, 1621, 1624, 1629, 1630, 1631, 1632, 1637, 1638, 1643, 1644, 1645, 1648, 1649, 1652, 1658, 1659, 1664, 1665, 1670, 1671, 1674, 1679, 1680, 1684, 1693, 1698, 1699, 1701, 1702, 1703, 1708, 1709, 1710, 1712, 1713, 1722, 1727, 1728, 1730, 1731, 1732, 1737, 1738, 1739, 1741, 1742, 1748, 1753, 1754, 1755, 1767, 1768, 1773, 1774, 1779, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1800, 1804, 1805, 1823, 1824, 1825, 1830, 1831, 1834, 1835, 1840, 1841, 1844, 1845, 1850, 1851, 1854, 1858, 1861, 1865, 1866, 1867, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1882, 1883, 1888, 1893, 1894, 1896, 1902, 1903, 1904, 1911, 1912, 1913, 1914, 1915, 1930, 1931, 1935, 1936, 1940, 1941, 1944, 1951, 1956, 1957, 1960, 1961, 1962, 1963, 1964, 1970, 1971, 1976, 1977, 1978, 1987, 1988, 1989, 1990, 1991, 1994, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2014, 2017, 2021};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 250 49
new 0 250 49
capacitySet 1 251 50
assign 1 259 55
new 0 259 55
new 1 259 56
assign 1 263 63
undef 1 263 68
assign 1 264 69
new 0 264 69
assign 1 265 72
equals 1 265 77
return 1 266 78
assign 1 302 87
greater 1 302 92
setValue 1 303 93
setValue 1 305 95
assign 1 309 102
new 0 309 102
new 1 309 103
assign 1 310 104
new 0 310 104
setValue 1 310 105
assign 1 311 106
new 0 311 106
setHex 2 311 107
assign 1 315 117
new 0 315 117
assign 1 315 118
getCode 2 315 118
assign 1 315 119
new 0 315 119
assign 1 315 120
new 0 315 120
assign 1 315 121
new 0 315 121
assign 1 315 122
toString 3 315 122
return 1 315 123
assign 1 319 127
hexNew 1 319 127
setCode 2 320 128
assign 1 324 145
toString 0 324 145
assign 1 326 146
new 0 326 146
assign 1 327 147
lengthGet 0 327 147
setValue 1 327 148
addValue 1 328 149
assign 1 330 150
lesser 1 330 155
assign 1 331 156
new 0 331 156
assign 1 331 157
add 1 331 157
assign 1 331 158
new 0 331 158
assign 1 331 159
multiply 1 331 159
assign 1 331 160
new 0 331 160
assign 1 331 161
divide 1 331 161
capacitySet 1 334 162
assign 1 336 164
new 0 336 164
assign 1 336 165
zeroGet 0 336 165
assign 1 336 166
lengthGet 0 336 166
copyValue 4 336 167
return 1 340 171
return 1 344 174
addValue 1 348 177
write 1 352 181
assign 1 362 192
copy 0 362 192
clear 0 363 193
return 1 364 194
assign 1 368 202
new 0 368 202
assign 1 368 203
greater 1 368 208
assign 1 369 209
new 0 369 209
assign 1 369 210
new 0 369 210
setIntUnchecked 2 369 211
assign 1 370 212
new 0 370 212
setValue 1 370 213
assign 1 375 221
new 0 375 221
new 1 375 222
assign 1 376 223
new 0 376 223
setValue 1 376 224
assign 1 377 225
new 0 377 225
setCodeUnchecked 2 377 226
assign 1 381 241
new 0 381 241
assign 1 382 242
ends 1 382 242
assign 1 383 244
new 0 383 244
assign 1 383 245
lengthGet 0 383 245
assign 1 383 246
subtract 1 383 246
assign 1 383 247
substring 2 383 247
return 1 383 248
assign 1 385 250
new 0 385 250
assign 1 386 251
ends 1 386 251
assign 1 387 253
new 0 387 253
assign 1 387 254
lengthGet 0 387 254
assign 1 387 255
subtract 1 387 255
assign 1 387 256
substring 2 387 256
return 1 387 257
return 1 389 259
assign 1 393 265
new 0 393 265
assign 1 393 266
add 1 393 266
assign 1 393 267
new 1 393 267
addValue 1 394 268
return 1 395 269
assign 1 399 279
find 1 399 279
assign 1 400 280
undef 1 400 285
assign 1 0 286
assign 1 400 289
new 0 400 289
assign 1 400 290
notEquals 1 400 295
assign 1 0 296
assign 1 0 299
assign 1 401 303
new 0 401 303
return 1 401 304
assign 1 403 306
new 0 403 306
return 1 403 307
assign 1 407 318
undef 1 407 323
assign 1 407 324
new 0 407 324
return 1 407 325
assign 1 408 327
lengthGet 0 408 327
assign 1 408 328
subtract 1 408 328
assign 1 408 329
find 2 408 329
assign 1 409 330
undef 1 409 335
assign 1 410 336
new 0 410 336
return 1 410 337
assign 1 412 339
new 0 412 339
return 1 412 340
assign 1 416 349
undef 1 416 354
assign 1 0 355
assign 1 416 358
find 1 416 358
assign 1 416 359
undef 1 416 364
assign 1 0 365
assign 1 0 368
assign 1 417 372
new 0 417 372
return 1 417 373
assign 1 419 375
new 0 419 375
return 1 419 376
assign 1 423 396
new 0 423 396
assign 1 424 397
new 0 424 397
assign 1 424 400
lesser 1 424 405
getInt 2 425 406
assign 1 426 407
new 0 426 407
assign 1 426 408
equals 1 426 413
assign 1 426 414
new 0 426 414
assign 1 426 415
equals 1 426 420
assign 1 0 421
assign 1 426 424
new 0 426 424
assign 1 426 425
equals 1 426 430
assign 1 0 431
assign 1 0 434
assign 1 0 438
assign 1 0 441
assign 1 0 445
assign 1 428 450
new 0 428 450
assign 1 428 451
greater 1 428 456
assign 1 0 457
assign 1 428 460
new 0 428 460
assign 1 428 461
lesser 1 428 466
assign 1 0 467
assign 1 0 470
assign 1 429 474
new 0 429 474
return 1 429 475
incrementValue 0 424 478
assign 1 432 484
new 0 432 484
return 1 432 485
assign 1 436 508
new 0 436 508
assign 1 437 509
new 0 437 509
assign 1 437 512
lesser 1 437 517
getInt 2 438 518
assign 1 439 519
new 0 439 519
assign 1 439 520
greater 1 439 525
assign 1 439 526
new 0 439 526
assign 1 439 527
lesser 1 439 532
assign 1 0 533
assign 1 0 536
assign 1 0 540
assign 1 0 543
assign 1 439 546
new 0 439 546
assign 1 439 547
greater 1 439 552
assign 1 439 553
new 0 439 553
assign 1 439 554
lesser 1 439 559
assign 1 0 560
assign 1 0 563
assign 1 0 567
assign 1 0 570
assign 1 0 573
assign 1 0 577
assign 1 439 580
new 0 439 580
assign 1 439 581
greater 1 439 586
assign 1 439 587
new 0 439 587
assign 1 439 588
lesser 1 439 593
assign 1 0 594
assign 1 0 597
assign 1 0 601
assign 1 0 604
assign 1 0 607
assign 1 440 611
new 0 440 611
return 1 440 612
incrementValue 0 437 614
assign 1 443 620
new 0 443 620
return 1 443 621
assign 1 447 625
isAlphaNumGet 0 447 625
return 1 447 626
assign 1 451 638
new 0 451 638
assign 1 452 639
new 0 452 639
assign 1 452 642
lesser 1 452 647
getInt 2 453 648
assign 1 454 649
new 0 454 649
assign 1 454 650
greater 1 454 655
assign 1 454 656
new 0 454 656
assign 1 454 657
lesser 1 454 662
assign 1 0 663
assign 1 0 666
assign 1 0 670
assign 1 455 673
new 0 455 673
addValue 1 455 674
setIntUnchecked 2 456 675
incrementValue 0 452 677
assign 1 462 688
copy 0 462 688
assign 1 462 689
lowerValue 0 462 689
return 1 462 690
assign 1 466 702
new 0 466 702
assign 1 467 703
new 0 467 703
assign 1 467 706
lesser 1 467 711
getInt 2 468 712
assign 1 469 713
new 0 469 713
assign 1 469 714
greater 1 469 719
assign 1 469 720
new 0 469 720
assign 1 469 721
lesser 1 469 726
assign 1 0 727
assign 1 0 730
assign 1 0 734
assign 1 470 737
new 0 470 737
subtractValue 1 470 738
setIntUnchecked 2 471 739
incrementValue 0 467 741
assign 1 477 752
copy 0 477 752
assign 1 477 753
upperValue 0 477 753
return 1 477 754
assign 1 482 766
new 0 482 766
assign 1 483 767
new 0 483 767
assign 1 484 768
new 0 484 768
assign 1 485 769
find 2 485 769
assign 1 486 770
def 1 486 775
assign 1 487 776
substring 2 487 776
addValue 1 487 777
addValue 1 488 778
assign 1 489 779
lengthGet 0 489 779
assign 1 489 780
add 1 489 780
assign 1 490 781
lengthGet 0 490 781
assign 1 490 782
substring 2 490 782
addValue 1 490 783
assign 1 492 786
copy 0 492 786
return 1 492 787
return 1 494 789
assign 1 499 801
new 0 499 801
assign 1 500 802
new 0 500 802
assign 1 501 803
new 0 501 803
assign 1 502 806
def 1 502 811
assign 1 503 812
find 2 503 812
assign 1 504 813
def 1 504 818
assign 1 505 819
substring 2 505 819
addValue 1 505 820
addValue 1 506 821
assign 1 507 822
lengthGet 0 507 822
assign 1 507 823
add 1 507 823
assign 1 510 826
lengthGet 0 510 826
assign 1 510 827
substring 2 510 827
addValue 1 510 828
return 1 514 835
assign 1 519 845
new 0 519 845
assign 1 519 846
new 1 519 846
assign 1 520 847
mbiterGet 0 520 847
assign 1 521 848
new 0 521 848
assign 1 521 851
lesser 1 521 856
next 1 522 857
incrementValue 0 521 858
assign 1 524 864
next 1 524 864
assign 1 524 865
toString 0 524 865
return 1 525 866
assign 1 529 874
new 0 529 874
assign 1 530 875
new 0 530 875
setValue 1 530 876
assign 1 531 877
new 0 531 877
assign 1 531 880
lesser 1 531 885
getInt 2 532 886
assign 1 533 887
new 0 533 887
multiplyValue 1 533 888
addValue 1 534 889
incrementValue 0 531 890
return 1 537 896
assign 1 541 901
new 0 541 901
assign 1 541 902
hashValue 1 541 902
return 1 541 903
assign 1 545 908
new 0 545 908
assign 1 545 909
getCode 2 545 909
return 1 545 910
assign 1 549 917
new 0 549 917
assign 1 549 918
greaterEquals 1 549 923
assign 1 549 924
greater 1 549 929
assign 1 0 930
assign 1 0 933
assign 1 0 937
return 1 580 944
return 1 582 946
assign 1 586 953
new 0 586 953
assign 1 586 954
greaterEquals 1 586 959
assign 1 586 960
greater 1 586 965
assign 1 0 966
assign 1 0 969
assign 1 0 973
return 1 611 983
return 1 613 985
assign 1 617 992
new 0 617 992
assign 1 617 993
greaterEquals 1 617 998
assign 1 617 999
greater 1 617 1004
assign 1 0 1005
assign 1 0 1008
assign 1 0 1012
setIntUnchecked 2 618 1015
assign 1 623 1024
new 0 623 1024
assign 1 623 1025
greaterEquals 1 623 1030
assign 1 623 1031
greater 1 623 1036
assign 1 0 1037
assign 1 0 1040
assign 1 0 1044
setCodeUnchecked 2 624 1047
assign 1 629 1075
assign 1 630 1076
lengthGet 0 630 1076
assign 1 630 1077
copy 0 630 1077
assign 1 631 1078
new 1 631 1078
assign 1 632 1079
new 0 632 1079
assign 1 633 1080
new 0 633 1080
assign 1 634 1081
new 0 634 1081
assign 1 634 1084
lesser 1 634 1089
getInt 2 635 1090
assign 1 636 1091
new 0 636 1091
assign 1 636 1092
greater 1 636 1097
assign 1 636 1098
new 0 636 1098
assign 1 636 1099
lesser 1 636 1104
assign 1 0 1105
assign 1 0 1108
assign 1 0 1112
assign 1 0 1115
assign 1 636 1118
new 0 636 1118
assign 1 636 1119
greater 1 636 1124
assign 1 636 1125
new 0 636 1125
assign 1 636 1126
lesser 1 636 1131
assign 1 0 1132
assign 1 0 1135
assign 1 0 1139
assign 1 0 1142
assign 1 0 1145
assign 1 0 1149
assign 1 636 1152
new 0 636 1152
assign 1 636 1153
greater 1 636 1158
assign 1 636 1159
new 0 636 1159
assign 1 636 1160
lesser 1 636 1165
assign 1 0 1166
assign 1 0 1169
assign 1 0 1173
assign 1 0 1176
assign 1 0 1179
setIntUnchecked 2 637 1183
incrementValue 0 638 1184
incrementValue 0 634 1186
lengthSet 1 641 1192
return 1 642 1193
assign 1 646 1200
new 0 646 1200
assign 1 646 1201
lesserEquals 1 646 1206
assign 1 647 1207
new 0 647 1207
return 1 647 1208
assign 1 649 1210
new 0 649 1210
return 1 649 1211
assign 1 719 1236
copy 0 719 1236
assign 1 719 1237
reverseBytes 0 719 1237
assign 1 719 1238
copy 0 719 1238
assign 1 719 1239
reverseBytes 0 719 1239
assign 1 719 1240
find 1 719 1240
assign 1 721 1241
def 1 721 1246
assign 1 722 1247
lengthGet 0 722 1247
addValue 1 722 1248
assign 1 723 1249
subtract 1 723 1249
return 1 723 1250
return 1 725 1252
assign 1 729 1257
new 0 729 1257
assign 1 729 1258
find 2 729 1258
return 1 729 1259
assign 1 735 1302
undef 1 735 1307
assign 1 0 1308
assign 1 735 1311
undef 1 735 1316
assign 1 0 1317
assign 1 0 1320
assign 1 0 1324
assign 1 735 1327
new 0 735 1327
assign 1 735 1328
lesser 1 735 1333
assign 1 0 1334
assign 1 0 1337
assign 1 0 1341
assign 1 735 1344
greaterEquals 1 735 1349
assign 1 0 1350
assign 1 0 1353
assign 1 0 1357
assign 1 735 1360
lengthGet 0 735 1360
assign 1 735 1361
greater 1 735 1366
assign 1 0 1367
assign 1 0 1370
assign 1 0 1374
assign 1 735 1377
new 0 735 1377
assign 1 735 1378
equals 1 735 1383
assign 1 0 1384
assign 1 0 1387
assign 1 0 1391
assign 1 735 1394
lengthGet 0 735 1394
assign 1 735 1395
new 0 735 1395
assign 1 735 1396
equals 1 735 1401
assign 1 0 1402
assign 1 0 1405
return 1 736 1409
assign 1 739 1411
assign 1 740 1412
copy 0 740 1412
assign 1 741 1413
new 0 741 1413
assign 1 742 1414
new 0 742 1414
assign 1 743 1415
new 0 743 1415
getInt 2 743 1416
assign 1 745 1417
lengthGet 0 745 1417
assign 1 747 1418
new 0 747 1418
assign 1 747 1419
greater 1 747 1424
assign 1 748 1425
new 0 748 1425
assign 1 749 1426
new 0 749 1426
assign 1 750 1427
new 0 750 1427
assign 1 752 1429
new 0 752 1429
assign 1 753 1432
lesser 1 753 1437
getInt 2 754 1438
assign 1 755 1439
equals 1 755 1444
assign 1 756 1445
new 0 756 1445
assign 1 756 1446
equals 1 756 1451
return 1 757 1452
setValue 1 759 1454
incrementValue 0 760 1455
setValue 1 761 1456
assign 1 762 1457
lengthGet 0 762 1457
addValue 1 762 1458
assign 1 763 1459
greater 1 763 1464
return 1 764 1465
assign 1 766 1467
new 0 766 1467
setValue 1 766 1468
assign 1 767 1471
lesser 1 767 1476
getInt 2 768 1477
getInt 2 769 1478
assign 1 770 1479
notEquals 1 770 1484
incrementValue 0 773 1487
incrementValue 0 774 1488
assign 1 776 1494
equals 1 776 1499
return 1 777 1500
incrementValue 0 780 1503
return 1 782 1509
assign 1 786 1520
new 0 786 1520
assign 1 787 1521
new 0 787 1521
assign 1 788 1522
find 2 788 1522
assign 1 789 1523
lengthGet 0 789 1523
assign 1 790 1526
def 1 790 1531
assign 1 791 1532
substring 2 791 1532
addValue 1 791 1533
assign 1 792 1534
add 1 792 1534
assign 1 793 1535
find 2 793 1535
assign 1 795 1541
lesser 1 795 1546
assign 1 796 1547
substring 2 796 1547
addValue 1 796 1548
return 1 798 1550
assign 1 802 1555
new 0 802 1555
assign 1 802 1556
join 2 802 1556
return 1 802 1557
return 1 806 1560
assign 1 814 1584
undef 1 814 1589
assign 1 0 1590
assign 1 814 1593
new 0 814 1593
assign 1 814 1594
otherType 2 814 1594
assign 1 0 1596
assign 1 0 1599
return 1 815 1603
assign 1 817 1605
assign 1 818 1606
lengthGet 0 818 1606
assign 1 819 1607
greater 1 819 1612
assign 1 820 1613
assign 1 822 1616
assign 1 824 1618
new 0 824 1618
assign 1 825 1619
new 0 825 1619
assign 1 826 1620
new 0 826 1620
assign 1 827 1621
new 0 827 1621
assign 1 827 1624
lesser 1 827 1629
getCode 2 828 1630
getCode 2 829 1631
assign 1 830 1632
notEquals 1 830 1637
assign 1 831 1638
greater 1 831 1643
assign 1 832 1644
new 0 832 1644
return 1 832 1645
assign 1 834 1648
new 0 834 1648
return 1 834 1649
incrementValue 0 827 1652
assign 1 838 1658
new 0 838 1658
assign 1 838 1659
equals 1 838 1664
assign 1 839 1665
greater 1 839 1670
assign 1 840 1671
new 0 840 1671
assign 1 841 1674
greater 1 841 1679
assign 1 842 1680
new 0 842 1680
return 1 845 1684
assign 1 849 1693
undef 1 849 1698
return 1 849 1699
assign 1 850 1701
compare 1 850 1701
assign 1 850 1702
new 0 850 1702
assign 1 850 1703
equals 1 850 1708
assign 1 851 1709
new 0 851 1709
return 1 851 1710
assign 1 853 1712
new 0 853 1712
return 1 853 1713
assign 1 857 1722
undef 1 857 1727
return 1 857 1728
assign 1 858 1730
compare 1 858 1730
assign 1 858 1731
new 0 858 1731
assign 1 858 1732
equals 1 858 1737
assign 1 859 1738
new 0 859 1738
return 1 859 1739
assign 1 861 1741
new 0 861 1741
return 1 861 1742
assign 1 865 1748
undef 1 865 1753
assign 1 865 1754
new 0 865 1754
return 1 865 1755
assign 1 925 1767
new 0 925 1767
return 1 925 1768
assign 1 929 1773
equals 1 929 1773
assign 1 929 1774
not 0 929 1779
return 1 929 1779
assign 1 933 1790
toString 0 933 1790
assign 1 934 1791
lengthGet 0 934 1791
assign 1 934 1792
add 1 934 1792
assign 1 934 1793
new 1 934 1793
assign 1 935 1794
new 0 935 1794
assign 1 935 1795
new 0 935 1795
copyValue 4 935 1796
assign 1 936 1797
new 0 936 1797
assign 1 936 1798
lengthGet 0 936 1798
copyValue 4 936 1799
return 1 937 1800
assign 1 940 1804
new 0 940 1804
return 1 940 1805
assign 1 944 1823
new 0 944 1823
assign 1 944 1824
zeroGet 0 944 1824
assign 1 944 1825
lesser 1 944 1830
assign 1 0 1831
assign 1 944 1834
lengthGet 0 944 1834
assign 1 944 1835
greater 1 944 1840
assign 1 0 1841
assign 1 944 1844
lengthGet 0 944 1844
assign 1 944 1845
greater 1 944 1850
assign 1 0 1851
assign 1 0 1854
assign 1 0 1858
assign 1 0 1861
assign 1 945 1865
new 0 945 1865
assign 1 945 1866
new 1 945 1866
throw 1 945 1867
assign 1 948 1870
new 0 948 1870
setValue 1 949 1871
subtractValue 1 950 1872
assign 1 951 1873
assign 1 953 1874
new 0 953 1874
setValue 1 954 1875
addValue 1 955 1876
assign 1 957 1877
greater 1 957 1882
capacitySet 1 958 1883
assign 1 991 1888
greater 1 991 1893
setValue 1 995 1894
return 1 997 1896
assign 1 1002 1902
lengthGet 0 1002 1902
assign 1 1002 1903
substring 2 1002 1903
return 1 1002 1904
assign 1 1006 1911
subtract 1 1006 1911
assign 1 1006 1912
new 1 1006 1912
assign 1 1006 1913
new 0 1006 1913
assign 1 1006 1914
copyValue 4 1006 1914
return 1 1006 1915
assign 1 1120 1930
new 1 1120 1930
return 1 1120 1931
assign 1 1124 1935
new 1 1124 1935
return 1 1124 1936
assign 1 1128 1940
new 1 1128 1940
return 1 1128 1941
return 1 1132 1944
assign 1 1136 1951
undef 1 1136 1956
new 0 1137 1957
assign 1 1139 1960
lengthGet 0 1139 1960
assign 1 1139 1961
new 0 1139 1961
assign 1 1139 1962
add 1 1139 1962
new 1 1139 1963
addValue 1 1140 1964
assign 1 1145 1970
new 0 1145 1970
return 1 1145 1971
assign 1 1149 1976
new 0 1149 1976
assign 1 1149 1977
strip 1 1149 1977
return 1 1149 1978
assign 1 1153 1987
new 0 1153 1987
assign 1 1154 1988
new 0 1154 1988
assign 1 1155 1989
new 0 1155 1989
assign 1 1156 1990
new 0 1156 1990
assign 1 1156 1991
subtract 1 1156 1991
assign 1 1157 1994
greater 1 1157 1999
getInt 2 1158 2000
getInt 2 1159 2001
setInt 2 1160 2002
setInt 2 1161 2003
incrementValue 0 1162 2004
decrementValue 0 1163 2005
return 1 0 2014
assign 1 0 2017
return 1 0 2021
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1641886805: return bem_mbiterGet_0();
case -1295279118: return bem_isAlphaNumericGet_0();
case -2064035655: return bem_close_0();
case 189070720: return bem_new_0();
case -1280653305: return bem_reverseBytes_0();
case -1011005498: return bem_capacityGet_0();
case 441331165: return bem_print_0();
case -1255709644: return bem_readString_0();
case 1029376900: return bem_output_0();
case 446711025: return bem_serializeToString_0();
case 1682640222: return bem_extractString_0();
case 1870128138: return bem_toString_0();
case -1387028723: return bem_toAlphaNum_0();
case 1631380984: return bem_isIntegerGet_0();
case 499674580: return bem_isEmptyGet_0();
case -1343400940: return bem_readBuffer_0();
case 1510436970: return bem_isAlphaNumGet_0();
case -1184569870: return bem_serializeContentsGet_0();
case 2095304189: return bem_upperValue_0();
case -559059286: return bem_create_0();
case -626778710: return bem_upper_0();
case 1210646718: return bem_open_0();
case -1694970114: return bem_chomp_0();
case -365700573: return bem_biterGet_0();
case 1684508629: return bem_copy_0();
case -1583834374: return bem_clear_0();
case 1630056911: return bem_strip_0();
case 711048290: return bem_lowerValue_0();
case -250278628: return bem_lengthGet_0();
case 1991657606: return bem_hashGet_0();
case -1399615900: return bem_iteratorGet_0();
case 1385659641: return bem_lower_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -514952459: return bem_notEquals_1(bevd_0);
case 404372174: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case -1375104016: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -582625005: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case -907308916: return bem_print_1(bevd_0);
case -704280640: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -1146215684: return bem_def_1(bevd_0);
case 1310959758: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case 765830110: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 305443687: return bem_equals_1(bevd_0);
case -162148908: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case -1439176248: return bem_write_1(bevd_0);
case -1008483961: return bem_writeTo_1(bevd_0);
case 1243915518: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -128095426: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case 139317253: return bem_add_1(bevd_0);
case 1394624585: return bem_lengthSet_1(bevd_0);
case 1536396624: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 477267035: return bem_compare_1(bevd_0);
case -741638175: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 637301921: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 833082405: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case -342422765: return bem_undef_1(bevd_0);
case 122918959: return bem_codeNew_1(bevd_0);
case -62278256: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -1204606264: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case 319100732: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 1849784828: return bem_addValue_1(bevd_0);
case -461789566: return bem_copyTo_1(bevd_0);
case -442084607: return bem_contains_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1880857460: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1536623154: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 902496809: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 470106603: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1532908424: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1390994923: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -287586809: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1743996026: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -416266252: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1261857099: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1918971160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 285163624: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 99764285: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1861692223: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -734031807: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -698261906: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 456977788: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_TextString();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
