package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_10_XmlEndElement extends BEC_2_3_3_XmlTag {
public BEC_2_3_10_XmlEndElement() { }
private static byte[] becc_BEC_2_3_10_XmlEndElement_clname = {0x58,0x6D,0x6C,0x3A,0x45,0x6E,0x64,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_10_XmlEndElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_10_XmlEndElement_bels_0 = {0x3C,0x2F};
private static byte[] bece_BEC_2_3_10_XmlEndElement_bels_1 = {0x3E};
public static BEC_2_3_10_XmlEndElement bece_BEC_2_3_10_XmlEndElement_bevs_inst;

public static BET_2_3_10_XmlEndElement bece_BEC_2_3_10_XmlEndElement_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_3_10_XmlEndElement bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_10_XmlEndElement_bels_0));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_name);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_10_XmlEndElement_bels_1));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_3_10_XmlEndElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {83, 83, 83, 83, 83, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 25, 26, 29, 32};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 83 22
new 0 83 22
assign 1 83 23
add 1 83 23
assign 1 83 24
new 0 83 24
assign 1 83 25
add 1 83 25
return 1 83 26
return 1 0 29
assign 1 0 32
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 441331165: return bem_print_0();
case 1684508629: return bem_copy_0();
case -1399615900: return bem_iteratorGet_0();
case 189070720: return bem_new_0();
case 1991657606: return bem_hashGet_0();
case -559059286: return bem_create_0();
case -1545739058: return bem_nameGet_0();
case 1870128138: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -907308916: return bem_print_1(bevd_0);
case -514952459: return bem_notEquals_1(bevd_0);
case 527922677: return bem_nameSet_1(bevd_0);
case -342422765: return bem_undef_1(bevd_0);
case -1146215684: return bem_def_1(bevd_0);
case 305443687: return bem_equals_1(bevd_0);
case -461789566: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1532908424: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -734031807: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 99764285: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1918971160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_3_10_XmlEndElement_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_10_XmlEndElement_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_10_XmlEndElement();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_inst = (BEC_2_3_10_XmlEndElement) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_type;
}
}
