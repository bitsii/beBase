package be;
public class BET_3_3_6_8_NetSocketListener extends BETS_Object {
public BET_3_3_6_8_NetSocketListener() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_2", "new_1", "bind_0", "accept_0", "addressGet_0", "addressSet_1", "portGet_0", "portSet_1", "backlogGet_0", "backlogSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "address", "port", "backlog" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_3_6_8_NetSocketListener();
}
}
