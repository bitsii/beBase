package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure extends BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;
public BEC_2_4_7_TestFailure bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
super.bem_new_1(beva_descr);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {9};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 15 9
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 18033612: return bem_vvGet_0();
case -748130189: return bem_echo_0();
case -1974795239: return bem_getFrameText_0();
case 1031162942: return bem_methodNameGet_0();
case 582617508: return bem_translateEmittedException_0();
case -1256903143: return bem_print_0();
case 1559897463: return bem_descriptionGet_0();
case -1693411633: return bem_fieldIteratorGet_0();
case 159988590: return bem_fileNameGet_0();
case -524348629: return bem_emitLangGet_0();
case 755495975: return bem_translatedGet_0();
case -2089883321: return bem_new_0();
case -1043517810: return bem_framesGet_0();
case 721298840: return bem_serializationIteratorGet_0();
case 1330053746: return bem_classNameGet_0();
case -1666892068: return bem_once_0();
case 1673454803: return bem_translateEmittedExceptionInner_0();
case 394710523: return bem_toAny_0();
case 978873391: return bem_deserializeClassNameGet_0();
case -1755437106: return bem_serializeContents_0();
case -1350870997: return bem_lineNumberGet_0();
case -266150550: return bem_many_0();
case -744762843: return bem_langGet_0();
case -67323485: return bem_create_0();
case 895906767: return bem_toString_0();
case -907223016: return bem_iteratorGet_0();
case 648643859: return bem_sourceFileNameGet_0();
case -139539224: return bem_klassNameGet_0();
case -499046296: return bem_framesTextGet_0();
case 19655765: return bem_tagGet_0();
case 1781926555: return bem_copy_0();
case 1740583826: return bem_serializeToString_0();
case 1782125853: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2119054446: return bem_otherType_1(bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case 1659419859: return bem_klassNameSet_1(bevd_0);
case -240742466: return bem_lineNumberSet_1(bevd_0);
case 803845413: return bem_def_1(bevd_0);
case -45642090: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case -1842584050: return bem_new_1(bevd_0);
case -1983158998: return bem_vvSet_1(bevd_0);
case -2104676074: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1333534008: return bem_descriptionSet_1(bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case 1979243658: return bem_emitLangSet_1(bevd_0);
case -165782289: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -333205960: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1836861418: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1867530746: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
case -581090127: return bem_langSet_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2097315666: return bem_sameClass_1(bevd_0);
case 1923599819: return bem_methodNameSet_1(bevd_0);
case 449451389: return bem_fileNameSet_1(bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case -1111260844: return bem_translatedSet_1(bevd_0);
case -1729585582: return bem_framesTextSet_1(bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 160725974: return bem_framesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1784211713: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TestFailure();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
}
