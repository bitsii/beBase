package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure extends BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public BEC_2_4_7_TestFailure bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
super.bem_new_1(beva_descr);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 20 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1989712623: return bem_hashGet_0();
case 1033905511: return bem_new_0();
case -435024496: return bem_methodNameGet_0();
case -1936627647: return bem_emitLangGet_0();
case -1865108104: return bem_langGet_0();
case -451680896: return bem_print_0();
case 118216530: return bem_vvGet_0();
case 2044861343: return bem_klassNameGet_0();
case -17029487: return bem_lineNumberGet_0();
case -223643344: return bem_descriptionGet_0();
case 1123340312: return bem_framesGet_0();
case 1332556390: return bem_create_0();
case 369530633: return bem_translatedGet_0();
case 1297296473: return bem_toString_0();
case 940631698: return bem_copy_0();
case 1251156318: return bem_framesTextGet_0();
case -1245364861: return bem_getFrameText_0();
case 355565519: return bem_iteratorGet_0();
case 1784568029: return bem_fileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1110937156: return bem_copyTo_1(bevd_0);
case -497140666: return bem_methodNameSet_1(bevd_0);
case 968880155: return bem_new_1(bevd_0);
case 1161478433: return bem_equals_1(bevd_0);
case -1653523413: return bem_langSet_1(bevd_0);
case -2069842105: return bem_notEquals_1(bevd_0);
case -723333435: return bem_framesSet_1(bevd_0);
case -1186385886: return bem_lineNumberSet_1(bevd_0);
case 159582032: return bem_def_1(bevd_0);
case -618247473: return bem_undef_1(bevd_0);
case -1277290978: return bem_vvSet_1(bevd_0);
case 318397427: return bem_klassNameSet_1(bevd_0);
case -1999335492: return bem_framesTextSet_1(bevd_0);
case 293572694: return bem_translatedSet_1(bevd_0);
case 1953847240: return bem_print_1(bevd_0);
case -1346289592: return bem_fileNameSet_1(bevd_0);
case 870467994: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -198975838: return bem_descriptionSet_1(bevd_0);
case -1256624207: return bem_emitLangSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1744432305: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 681643689: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1355956619: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142010341: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -862858043: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TestFailure();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
