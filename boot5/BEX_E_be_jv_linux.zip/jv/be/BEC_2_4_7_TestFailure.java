package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure extends BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public BEC_2_4_7_TestFailure bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
super.bem_new_1(beva_descr);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 14 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -777537417: return bem_serializeContents_0();
case 221458969: return bem_serializeToString_0();
case -1238524057: return bem_print_0();
case 1093555039: return bem_translatedGet_0();
case -206443424: return bem_getFrameText_0();
case 415591329: return bem_lineNumberGetDirect_0();
case 2071247075: return bem_sourceFileNameGet_0();
case 351993640: return bem_framesTextGet_0();
case -293728371: return bem_fileNameGetDirect_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 310047227: return bem_fieldNamesGet_0();
case 814015164: return bem_copy_0();
case 2013999809: return bem_klassNameGet_0();
case -1079456517: return bem_many_0();
case 705947398: return bem_klassNameGetDirect_0();
case -992634121: return bem_tagGet_0();
case 205150354: return bem_new_0();
case 993286746: return bem_echo_0();
case -204615836: return bem_translateEmittedException_0();
case 1392309220: return bem_methodNameGetDirect_0();
case 846158885: return bem_descriptionGetDirect_0();
case -1426056679: return bem_hashGet_0();
case -2021736875: return bem_vvGet_0();
case 438314037: return bem_descriptionGet_0();
case 137910263: return bem_create_0();
case 78412540: return bem_toAny_0();
case 1215209407: return bem_vvGetDirect_0();
case 539725573: return bem_framesGetDirect_0();
case -1392846471: return bem_toString_0();
case 1477793617: return bem_lineNumberGet_0();
case 1422899281: return bem_emitLangGet_0();
case 1744152723: return bem_translateEmittedExceptionInner_0();
case 957655064: return bem_fileNameGet_0();
case -1302527580: return bem_langGet_0();
case -616491421: return bem_framesTextGetDirect_0();
case -314990175: return bem_langGetDirect_0();
case -145122790: return bem_emitLangGetDirect_0();
case 217381802: return bem_serializationIteratorGet_0();
case -438289515: return bem_fieldIteratorGet_0();
case -1714583788: return bem_classNameGet_0();
case -1331626162: return bem_iteratorGet_0();
case -459804280: return bem_framesGet_0();
case 1833881080: return bem_methodNameGet_0();
case -1851472893: return bem_once_0();
case -315715966: return bem_translatedGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -453643441: return bem_defined_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case -1034299799: return bem_framesSet_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case -202882393: return bem_new_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -807053893: return bem_methodNameSetDirect_1(bevd_0);
case 1289284938: return bem_langSetDirect_1(bevd_0);
case -398787829: return bem_lineNumberSet_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -416673685: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -913894142: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1854310921: return bem_langSet_1(bevd_0);
case -431916983: return bem_vvSet_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 901047781: return bem_translatedSetDirect_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case -2033827070: return bem_lineNumberSetDirect_1(bevd_0);
case 486751541: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1943803388: return bem_fileNameSetDirect_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 1385952468: return bem_methodNameSet_1(bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 542423214: return bem_framesTextSetDirect_1(bevd_0);
case -716767446: return bem_klassNameSetDirect_1(bevd_0);
case -271352651: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 1315134324: return bem_klassNameSet_1(bevd_0);
case -831681449: return bem_emitLangSet_1(bevd_0);
case -671224660: return bem_fileNameSet_1(bevd_0);
case 377248089: return bem_framesTextSet_1(bevd_0);
case -753481537: return bem_emitLangSetDirect_1(bevd_0);
case -1432883040: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1655713256: return bem_framesSetDirect_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case -1419541899: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -644418178: return bem_descriptionSet_1(bevd_0);
case 1253750142: return bem_vvSetDirect_1(bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 1214467840: return bem_translatedSet_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 130399362: return bem_descriptionSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -925620157: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TestFailure();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
