package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure extends BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public BEC_2_4_7_TestFailure bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
super.bem_new_1(beva_descr);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 20 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1978701672: return bem_iteratorGet_0();
case 1729883448: return bem_langGet_0();
case 920185877: return bem_descriptionGet_0();
case 1293883485: return bem_print_0();
case 911032708: return bem_methodNameGet_0();
case 76040359: return bem_lineNumberGet_0();
case 1836285625: return bem_new_0();
case -1130869080: return bem_fileNameGet_0();
case 1148282929: return bem_translatedGet_0();
case 22555546: return bem_framesGet_0();
case 1230276296: return bem_hashGet_0();
case 992700193: return bem_copy_0();
case -1111080986: return bem_framesTextGet_0();
case -1333052675: return bem_klassNameGet_0();
case -986591826: return bem_getFrameText_0();
case -1073618022: return bem_emitLangGet_0();
case -1250586953: return bem_create_0();
case -10560512: return bem_toString_0();
case 170473004: return bem_vvGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1201758172: return bem_emitLangSet_1(bevd_0);
case -1083278353: return bem_framesSet_1(bevd_0);
case 1409349899: return bem_undef_1(bevd_0);
case -223349665: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 626929624: return bem_lineNumberSet_1(bevd_0);
case 588436859: return bem_vvSet_1(bevd_0);
case -681059589: return bem_framesTextSet_1(bevd_0);
case 236311581: return bem_methodNameSet_1(bevd_0);
case -305715842: return bem_notEquals_1(bevd_0);
case -767774281: return bem_langSet_1(bevd_0);
case 1359464210: return bem_fileNameSet_1(bevd_0);
case 907966167: return bem_new_1(bevd_0);
case 52329100: return bem_copyTo_1(bevd_0);
case -1978152287: return bem_print_1(bevd_0);
case -923254720: return bem_klassNameSet_1(bevd_0);
case 1374165016: return bem_translatedSet_1(bevd_0);
case -1926574247: return bem_def_1(bevd_0);
case 850514472: return bem_equals_1(bevd_0);
case -1565157107: return bem_descriptionSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1507992233: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1974138487: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1007047738: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 530385415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 202270905: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TestFailure();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
