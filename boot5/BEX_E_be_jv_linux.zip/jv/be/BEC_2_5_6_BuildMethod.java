package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_6_BuildMethod extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
private static byte[] becc_BEC_2_5_6_BuildMethod_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_5_6_BuildMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_0 = {0x20};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
public static BEC_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_inst;

public static BET_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public BEC_2_5_6_BuildMethod bem_new_0() throws Throwable {
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = be.BECS_Runtime.boolFalse;
bevp_tryDepth = (new BEC_2_4_3_MathInt(0));
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_amax = (new BEC_2_4_3_MathInt(0));
bevp_hmax = (new BEC_2_4_3_MathInt(0));
bevp_mmax = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_0_ta_ph = bem_classNameGet_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_6_BuildMethod_bels_0));
bevl_ret = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
if (bevp_name == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 182*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMethod_bels_1));
bevt_3_ta_ph = bevl_ret.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
} /* Line: 183*/
if (bevp_numargs == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 185*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_6_BuildMethod_bels_2));
bevt_7_ta_ph = bevl_ret.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_numargs.bem_toString_0();
bevl_ret = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
} /* Line: 186*/
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public final BEC_2_4_6_TextString bem_orgNameGetDirect_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_numargsGetDirect_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() throws Throwable {
return bevp_property;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_propertyGetDirect_0() throws Throwable {
return bevp_property;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_property = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_propertySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_property = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() throws Throwable {
return bevp_rtype;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_rtypeGetDirect_0() throws Throwable {
return bevp_rtype;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rtype = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_rtypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rtype = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() throws Throwable {
return bevp_tmpVars;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_tmpVarsGetDirect_0() throws Throwable {
return bevp_tmpVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tmpVars = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_tmpVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tmpVars = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() throws Throwable {
return bevp_tmpCnt;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tmpCntGetDirect_0() throws Throwable {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_tmpCntSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isGenAccessorGetDirect_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_isGenAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() throws Throwable {
return bevp_tryDepth;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tryDepthGetDirect_0() throws Throwable {
return bevp_tryDepth;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_tryDepthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() throws Throwable {
return bevp_amax;
} /*method end*/
public final BEC_2_4_3_MathInt bem_amaxGetDirect_0() throws Throwable {
return bevp_amax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_amaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() throws Throwable {
return bevp_hmax;
} /*method end*/
public final BEC_2_4_3_MathInt bem_hmaxGetDirect_0() throws Throwable {
return bevp_hmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_hmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() throws Throwable {
return bevp_mmax;
} /*method end*/
public final BEC_2_4_3_MathInt bem_mmaxGetDirect_0() throws Throwable {
return bevp_mmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_mmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {166, 167, 168, 169, 170, 171, 173, 174, 175, 181, 181, 181, 182, 182, 183, 183, 183, 183, 185, 185, 186, 186, 186, 186, 188, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 31, 32, 33, 34, 35, 36, 37, 38, 53, 54, 55, 56, 61, 62, 63, 64, 65, 67, 72, 73, 74, 75, 76, 78, 81, 84, 87, 91, 95, 98, 101, 105, 109, 112, 115, 119, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203, 207, 210, 213, 217, 221, 224, 227, 231, 235, 238, 241, 245, 249, 252, 255, 259, 263, 266, 269, 273, 277, 280, 283, 287};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 166 30
new 0 166 30
assign 1 167 31
new 0 167 31
assign 1 168 32
new 0 168 32
assign 1 169 33
new 0 169 33
assign 1 170 34
new 0 170 34
assign 1 171 35
new 0 171 35
assign 1 173 36
new 0 173 36
assign 1 174 37
new 0 174 37
assign 1 175 38
new 0 175 38
assign 1 181 53
classNameGet 0 181 53
assign 1 181 54
new 0 181 54
assign 1 181 55
add 1 181 55
assign 1 182 56
def 1 182 61
assign 1 183 62
new 0 183 62
assign 1 183 63
add 1 183 63
assign 1 183 64
toString 0 183 64
assign 1 183 65
add 1 183 65
assign 1 185 67
def 1 185 72
assign 1 186 73
new 0 186 73
assign 1 186 74
add 1 186 74
assign 1 186 75
toString 0 186 75
assign 1 186 76
add 1 186 76
return 1 188 78
return 1 0 81
return 1 0 84
assign 1 0 87
assign 1 0 91
return 1 0 95
return 1 0 98
assign 1 0 101
assign 1 0 105
return 1 0 109
return 1 0 112
assign 1 0 115
assign 1 0 119
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
return 1 0 235
return 1 0 238
assign 1 0 241
assign 1 0 245
return 1 0 249
return 1 0 252
assign 1 0 255
assign 1 0 259
return 1 0 263
return 1 0 266
assign 1 0 269
assign 1 0 273
return 1 0 277
return 1 0 280
assign 1 0 283
assign 1 0 287
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1067735371: return bem_isGenAccessorGetDirect_0();
case 1342623754: return bem_copy_0();
case 2066839134: return bem_iteratorGet_0();
case 1483992330: return bem_tmpCntGet_0();
case -1273085011: return bem_nameGetDirect_0();
case -1718188704: return bem_hashGet_0();
case -1112733019: return bem_propertyGet_0();
case 247576523: return bem_classNameGet_0();
case -225222698: return bem_create_0();
case 1812537910: return bem_hmaxGet_0();
case 498101216: return bem_echo_0();
case 1576697112: return bem_isFinalGetDirect_0();
case 749770559: return bem_nameGet_0();
case -46722824: return bem_propertyGetDirect_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case -71240575: return bem_tmpVarsGetDirect_0();
case -432236674: return bem_numargsGetDirect_0();
case -2124354635: return bem_serializeToString_0();
case 556565361: return bem_serializationIteratorGet_0();
case -1794485421: return bem_serializeContents_0();
case 269900546: return bem_hmaxGetDirect_0();
case -1749437314: return bem_tagGet_0();
case 2021632555: return bem_mmaxGet_0();
case -677150073: return bem_toString_0();
case 856172166: return bem_numargsGet_0();
case -1837529947: return bem_rtypeGetDirect_0();
case -681217388: return bem_orgNameGet_0();
case -1968175080: return bem_rtypeGet_0();
case -20657436: return bem_amaxGet_0();
case 1881401080: return bem_mmaxGetDirect_0();
case 398187407: return bem_sourceFileNameGet_0();
case 1852599198: return bem_amaxGetDirect_0();
case 1749524346: return bem_tryDepthGetDirect_0();
case -1890734576: return bem_isFinalGet_0();
case -976499117: return bem_tmpCntGetDirect_0();
case 126387064: return bem_new_0();
case 409380620: return bem_fieldIteratorGet_0();
case 807655445: return bem_print_0();
case 272017749: return bem_orgNameGetDirect_0();
case -86420065: return bem_isGenAccessorGet_0();
case -543330026: return bem_fieldNamesGet_0();
case 408949676: return bem_orderedVarsGet_0();
case 672323507: return bem_anyMapGet_0();
case -506866789: return bem_anyMapGetDirect_0();
case 536013845: return bem_tmpVarsGet_0();
case -1149862932: return bem_tryDepthGet_0();
case 327158909: return bem_orderedVarsGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1345446963: return bem_hmaxSet_1(bevd_0);
case -1585081495: return bem_nameSet_1(bevd_0);
case 2048540339: return bem_amaxSetDirect_1(bevd_0);
case 88732428: return bem_amaxSet_1(bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case -1706248073: return bem_tmpCntSetDirect_1(bevd_0);
case -1773182409: return bem_orderedVarsSetDirect_1(bevd_0);
case 1502842604: return bem_def_1(bevd_0);
case 6382588: return bem_mmaxSetDirect_1(bevd_0);
case -674189729: return bem_isGenAccessorSet_1(bevd_0);
case 1607773487: return bem_isFinalSetDirect_1(bevd_0);
case 734836500: return bem_orgNameSetDirect_1(bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case 1850432492: return bem_mmaxSet_1(bevd_0);
case -503523034: return bem_hmaxSetDirect_1(bevd_0);
case -340228865: return bem_tmpVarsSet_1(bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case 1655802611: return bem_rtypeSet_1(bevd_0);
case -1833517422: return bem_numargsSetDirect_1(bevd_0);
case 771982468: return bem_tmpVarsSetDirect_1(bevd_0);
case -1422281341: return bem_rtypeSetDirect_1(bevd_0);
case 624222199: return bem_numargsSet_1(bevd_0);
case 841830699: return bem_isGenAccessorSetDirect_1(bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
case -971629925: return bem_tryDepthSetDirect_1(bevd_0);
case 1290248031: return bem_tmpCntSet_1(bevd_0);
case -455646862: return bem_orderedVarsSet_1(bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -404194174: return bem_copyTo_1(bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case 1152878547: return bem_anyMapSetDirect_1(bevd_0);
case -185162387: return bem_orgNameSet_1(bevd_0);
case 2059566153: return bem_nameSetDirect_1(bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case -2065024019: return bem_tryDepthSet_1(bevd_0);
case 798306363: return bem_isFinalSet_1(bevd_0);
case -1490082135: return bem_anyMapSet_1(bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case -241370397: return bem_propertySetDirect_1(bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1011294755: return bem_propertySet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMethod_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_6_BuildMethod_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMethod();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst = (BEC_2_5_6_BuildMethod) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_type;
}
}
