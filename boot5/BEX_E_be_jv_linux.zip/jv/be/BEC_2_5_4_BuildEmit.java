package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildEmit extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildEmit() { }
private static byte[] becc_BEC_2_5_4_BuildEmit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74};
private static byte[] becc_BEC_2_5_4_BuildEmit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_inst;
public BEC_2_4_6_TextString bevp_text;
public BEC_2_9_3_ContainerSet bevp_langs;
public BEC_2_5_4_BuildEmit bem_new_2(BEC_2_4_6_TextString beva__text, BEC_2_9_3_ContainerSet beva__langs) throws Throwable {
bevp_text = beva__text;
bevp_langs = beva__langs;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_textGet_0() throws Throwable {
return bevp_text;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_text = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGet_0() throws Throwable {
return bevp_langs;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {74, 75, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {11, 12, 16, 19, 23, 26};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 74 11
assign 1 75 12
return 1 0 16
assign 1 0 19
return 1 0 23
assign 1 0 26
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -145312000: return bem_serializationIteratorGet_0();
case -176876439: return bem_fieldIteratorGet_0();
case 904467476: return bem_create_0();
case -629628110: return bem_toAny_0();
case 714053375: return bem_many_0();
case -820547047: return bem_new_0();
case -1735377102: return bem_textGet_0();
case -131080468: return bem_print_0();
case -1239151636: return bem_sourceFileNameGet_0();
case -863935940: return bem_copy_0();
case 1030499827: return bem_iteratorGet_0();
case 865364657: return bem_serializeContents_0();
case 1532804167: return bem_langsGet_0();
case -1895992021: return bem_deserializeClassNameGet_0();
case 1021615634: return bem_classNameGet_0();
case -316245103: return bem_echo_0();
case 521055509: return bem_serializeToString_0();
case -1196329855: return bem_tagGet_0();
case 1797341089: return bem_once_0();
case 269723613: return bem_hashGet_0();
case 657801083: return bem_toString_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case -1074673344: return bem_copyTo_1(bevd_0);
case 788271940: return bem_sameObject_1(bevd_0);
case -455244874: return bem_undefined_1(bevd_0);
case 2065581034: return bem_langsSet_1(bevd_0);
case 2016817692: return bem_equals_1(bevd_0);
case 1354444477: return bem_undef_1(bevd_0);
case 681555470: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1584774500: return bem_sameClass_1(bevd_0);
case 1693196376: return bem_otherType_1(bevd_0);
case 153472398: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1986492654: return bem_textSet_1(bevd_0);
case 218874128: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2063004658: return bem_sameType_1(bevd_0);
case 544484580: return bem_defined_1(bevd_0);
case -560471223: return bem_otherClass_1(bevd_0);
case 80790810: return bem_notEquals_1(bevd_0);
case 779198300: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1808338509: return bem_def_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 423661912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 338963035: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1655996947: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_3_ContainerSet) bevd_1);
case -236631668: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -539434931: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 901264448: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 883042907: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -884026318: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildEmit_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildEmit_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildEmit();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst = (BEC_2_5_4_BuildEmit) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst;
}
}
