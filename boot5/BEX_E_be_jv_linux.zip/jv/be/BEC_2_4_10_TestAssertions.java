package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_10_TestAssertions extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_TestAssertions() { }
private static byte[] becc_BEC_2_4_10_TestAssertions_clname = {0x54,0x65,0x73,0x74,0x3A,0x41,0x73,0x73,0x65,0x72,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_2_4_10_TestAssertions_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_0 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_1 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_2 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_3 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_4 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_5 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_6 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_7 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_8 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_9 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_9, 36));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_10 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_10, 1));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_11 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x55,0x4E,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_12 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_13 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_14 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x4F,0x54,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_15 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x54,0x52,0x55,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_16 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x46,0x41,0x4C,0x53,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
public static BEC_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_inst;

public static BET_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_type;

public BEC_2_4_10_TestAssertions bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_10_tmpany_phold = null;
bevt_2_tmpany_phold = beva_v1.bemd_1(-762893825, beva_v2);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(111297745);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 27 */ {
bevl_msg = (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_0));
if (beva_v1 == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 29 */ {
if (beva_v2 == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 29 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_7_tmpany_phold = bevl_msg.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(beva_v1);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(beva_v2);
} /* Line: 30 */
bevt_10_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 32 */
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v1.bemd_1(-762893825, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 36 */ {
bevl_msg = (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_3));
if (beva_v1 == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 38 */ {
if (beva_v2 == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 38 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 38 */ {
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_4));
bevt_6_tmpany_phold = bevl_msg.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(beva_v1);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_5));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(beva_v2);
} /* Line: 39 */
bevt_9_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_9_tmpany_phold);
} /* Line: 41 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_10_TestAssertions bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_assertEqual_2(beva_v1, beva_v2);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertNotEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_10_TestAssertions bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_assertNotEqual_2(beva_v1, beva_v2);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_v1v = null;
BEC_2_4_6_TextString bevl_v2v = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (beva_v1 == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(56, bece_BEC_2_4_10_TestAssertions_bels_6));
bevt_1_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 52 */
bevt_3_tmpany_phold = beva_v1.bemd_1(1273353241, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 54 */ {
if (beva_v1 == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevl_v1v = (BEC_2_4_6_TextString) beva_v1.bemd_0(-1762356041);
} /* Line: 56 */
 else  /* Line: 57 */ {
bevl_v1v = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_7));
} /* Line: 58 */
if (beva_v2 == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevl_v2v = (BEC_2_4_6_TextString) beva_v2.bemd_0(-1762356041);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevl_v2v = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_8));
} /* Line: 63 */
bevt_10_tmpany_phold = bece_BEC_2_4_10_TestAssertions_bevo_0;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_v1v);
bevt_11_tmpany_phold = bece_BEC_2_4_10_TestAssertions_bevo_1;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_v2v);
bevt_6_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 65 */
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v1.bemd_1(-408502512, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 69 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(36, bece_BEC_2_4_10_TestAssertions_bels_11));
bevt_1_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 70 */
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_12));
bevt_1_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 75 */
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertIsNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_13));
bevt_1_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 80 */
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_4_10_TestAssertions_bels_14));
bevt_1_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 85 */
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertTrue_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bemd_0(111297745);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_15));
bevt_1_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 90 */
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertFalse_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_4_7_TestFailure bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (((BEC_2_5_4_LogicBool) beva_v).bevi_bool) /* Line: 94 */ {
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_4_10_TestAssertions_bels_16));
bevt_0_tmpany_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 95 */
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {27, 27, 28, 29, 29, 29, 29, 0, 0, 0, 30, 30, 30, 30, 30, 30, 32, 32, 36, 37, 38, 38, 38, 38, 0, 0, 0, 39, 39, 39, 39, 39, 39, 41, 41, 45, 45, 48, 48, 51, 51, 52, 52, 52, 54, 55, 55, 56, 58, 60, 60, 61, 63, 65, 65, 65, 65, 65, 65, 65, 69, 70, 70, 70, 74, 74, 75, 75, 75, 79, 79, 80, 80, 80, 84, 84, 85, 85, 85, 89, 90, 90, 90, 95, 95, 95};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {49, 50, 52, 53, 58, 59, 64, 65, 68, 72, 75, 76, 77, 78, 79, 80, 82, 83, 99, 101, 102, 107, 108, 113, 114, 117, 121, 124, 125, 126, 127, 128, 129, 131, 132, 138, 139, 143, 144, 161, 166, 167, 168, 169, 171, 173, 178, 179, 182, 184, 189, 190, 193, 195, 196, 197, 198, 199, 200, 201, 209, 211, 212, 213, 221, 226, 227, 228, 229, 237, 242, 243, 244, 245, 253, 258, 259, 260, 261, 269, 271, 272, 273, 281, 282, 283};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 27 49
has 1 27 49
assign 1 27 50
not 0 27 50
assign 1 28 52
new 0 28 52
assign 1 29 53
def 1 29 58
assign 1 29 59
def 1 29 64
assign 1 0 65
assign 1 0 68
assign 1 0 72
assign 1 30 75
new 0 30 75
assign 1 30 76
addValue 1 30 76
assign 1 30 77
addValue 1 30 77
assign 1 30 78
new 0 30 78
assign 1 30 79
addValue 1 30 79
addValue 1 30 80
assign 1 32 82
new 1 32 82
throw 1 32 83
assign 1 36 99
has 1 36 99
assign 1 37 101
new 0 37 101
assign 1 38 102
def 1 38 107
assign 1 38 108
def 1 38 113
assign 1 0 114
assign 1 0 117
assign 1 0 121
assign 1 39 124
new 0 39 124
assign 1 39 125
addValue 1 39 125
assign 1 39 126
addValue 1 39 126
assign 1 39 127
new 0 39 127
assign 1 39 128
addValue 1 39 128
addValue 1 39 129
assign 1 41 131
new 1 41 131
throw 1 41 132
assign 1 45 138
assertEqual 2 45 138
return 1 45 139
assign 1 48 143
assertNotEqual 2 48 143
return 1 48 144
assign 1 51 161
undef 1 51 166
assign 1 52 167
new 0 52 167
assign 1 52 168
new 1 52 168
throw 1 52 169
assign 1 54 171
notEquals 1 54 171
assign 1 55 173
def 1 55 178
assign 1 56 179
toString 0 56 179
assign 1 58 182
new 0 58 182
assign 1 60 184
def 1 60 189
assign 1 61 190
toString 0 61 190
assign 1 63 193
new 0 63 193
assign 1 65 195
new 0 65 195
assign 1 65 196
add 1 65 196
assign 1 65 197
new 0 65 197
assign 1 65 198
add 1 65 198
assign 1 65 199
add 1 65 199
assign 1 65 200
new 1 65 200
throw 1 65 201
assign 1 69 209
equals 1 69 209
assign 1 70 211
new 0 70 211
assign 1 70 212
new 1 70 212
throw 1 70 213
assign 1 74 221
def 1 74 226
assign 1 75 227
new 0 75 227
assign 1 75 228
new 1 75 228
throw 1 75 229
assign 1 79 237
def 1 79 242
assign 1 80 243
new 0 80 243
assign 1 80 244
new 1 80 244
throw 1 80 245
assign 1 84 253
undef 1 84 258
assign 1 85 259
new 0 85 259
assign 1 85 260
new 1 85 260
throw 1 85 261
assign 1 89 269
not 0 89 269
assign 1 90 271
new 0 90 271
assign 1 90 272
new 1 90 272
throw 1 90 273
assign 1 95 281
new 0 95 281
assign 1 95 282
new 1 95 282
throw 1 95 283
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -507124439: return bem_new_0();
case -22393727: return bem_create_0();
case 1981654959: return bem_once_0();
case -1278273894: return bem_toAny_0();
case 847337627: return bem_copy_0();
case -915808255: return bem_serializationIteratorGet_0();
case 718789172: return bem_iteratorGet_0();
case -360613383: return bem_serializeContents_0();
case -207569400: return bem_serializeToString_0();
case -397559289: return bem_fieldIteratorGet_0();
case 1611055106: return bem_fieldNamesGet_0();
case -480687649: return bem_print_0();
case -1308933810: return bem_deserializeClassNameGet_0();
case -638442685: return bem_echo_0();
case -1762356041: return bem_toString_0();
case 346235852: return bem_sourceFileNameGet_0();
case -217835874: return bem_tagGet_0();
case -1629544591: return bem_many_0();
case 1230302912: return bem_hashGet_0();
case 357537975: return bem_classNameGet_0();
case 2059101640: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -665968375: return bem_sameType_1(bevd_0);
case 321693734: return bem_undef_1(bevd_0);
case -436547338: return bem_undefined_1(bevd_0);
case 1849763669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1530291279: return bem_sameObject_1(bevd_0);
case 1418552655: return bem_def_1(bevd_0);
case -1263961885: return bem_otherClass_1(bevd_0);
case -794657115: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 105870070: return bem_assertNull_1(bevd_0);
case 245035405: return bem_assertTrue_1(bevd_0);
case -408502512: return bem_equals_1(bevd_0);
case 1787128072: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1379835000: return bem_defined_1(bevd_0);
case -1290269135: return bem_assertNotNull_1(bevd_0);
case -1858553954: return bem_assertFalse_1(bevd_0);
case 1273353241: return bem_notEquals_1(bevd_0);
case 1387628079: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1256041694: return bem_copyTo_1(bevd_0);
case 580318355: return bem_otherType_1(bevd_0);
case -1046677598: return bem_assertIsNull_1(bevd_0);
case -2056947488: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -318431301: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -519879364: return bem_assertNotEquals_2(bevd_0, bevd_1);
case 795609287: return bem_assertHas_2(bevd_0, bevd_1);
case 1138830036: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 975610887: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -554397969: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1103544796: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1297894686: return bem_assertEquals_2(bevd_0, bevd_1);
case -799307739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1665467124: return bem_assertNotHas_2(bevd_0, bevd_1);
case -1560495963: return bem_assertNotEqual_2(bevd_0, bevd_1);
case -2122183893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1357560120: return bem_assertEqual_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_TestAssertions_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_10_TestAssertions_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_TestAssertions();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst = (BEC_2_4_10_TestAssertions) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_type;
}
}
