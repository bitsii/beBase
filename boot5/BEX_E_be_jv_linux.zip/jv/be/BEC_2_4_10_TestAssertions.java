package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_10_TestAssertions extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_TestAssertions() { }
private static byte[] becc_BEC_2_4_10_TestAssertions_clname = {0x54,0x65,0x73,0x74,0x3A,0x41,0x73,0x73,0x65,0x72,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_2_4_10_TestAssertions_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_0 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_1 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_2 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_3 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_4 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_5 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_6 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_6, 36));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_7 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_7, 1));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_8 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x55,0x4E,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_9 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_10 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x4F,0x54,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_11 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x54,0x52,0x55,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_12 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x46,0x41,0x4C,0x53,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
public static BEC_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_inst;

public static BET_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_type;

public BEC_2_4_10_TestAssertions bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_7_TestFailure bevt_10_ta_ph = null;
bevt_2_ta_ph = beva_v1.bemd_1(-1742042817, beva_v2);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-244976954);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 26*/ {
bevl_msg = (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_0));
if (beva_v1 == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 28*/ {
if (beva_v2 == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 28*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 28*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 28*/
 else /* Line: 28*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 28*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_7_ta_ph = bevl_msg.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(beva_v1);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_5_ta_ph.bem_addValue_1(beva_v2);
} /* Line: 29*/
bevt_10_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 31*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_7_TestFailure bevt_9_ta_ph = null;
bevt_1_ta_ph = beva_v1.bemd_1(-1742042817, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 35*/ {
bevl_msg = (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_3));
if (beva_v1 == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 37*/ {
if (beva_v2 == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 37*/
 else /* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 37*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_6_ta_ph = bevl_msg.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(beva_v1);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(beva_v2);
} /* Line: 38*/
bevt_9_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_9_ta_ph);
} /* Line: 40*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_10_TestAssertions bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_assertEqual_2(beva_v1, beva_v2);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertNotEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_10_TestAssertions bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_assertNotEqual_2(beva_v1, beva_v2);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_v1v = null;
BEC_2_4_6_TextString bevl_v2v = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_7_TestFailure bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (beva_v1 == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 50*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(56, bece_BEC_2_4_10_TestAssertions_bels_4));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 51*/
bevt_3_ta_ph = beva_v1.bemd_1(960896697, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 53*/ {
if (beva_v1 == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 54*/ {
bevl_v1v = (BEC_2_4_6_TextString) beva_v1.bemd_0(-1392846471);
} /* Line: 55*/
 else /* Line: 56*/ {
bevl_v1v = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_5));
} /* Line: 57*/
if (beva_v2 == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 59*/ {
bevl_v2v = (BEC_2_4_6_TextString) beva_v2.bemd_0(-1392846471);
} /* Line: 60*/
 else /* Line: 61*/ {
bevl_v2v = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_5));
} /* Line: 62*/
bevt_10_ta_ph = bece_BEC_2_4_10_TestAssertions_bevo_0;
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_v1v);
bevt_11_ta_ph = bece_BEC_2_4_10_TestAssertions_bevo_1;
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_v2v);
bevt_6_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_7_ta_ph);
throw new be.BECS_ThrowBack(bevt_6_ta_ph);
} /* Line: 64*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = beva_v1.bemd_1(1070255022, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 68*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(36, bece_BEC_2_4_10_TestAssertions_bels_8));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 69*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_v == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_9));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 74*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertIsNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_v == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 78*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_9));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 79*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_v == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_4_10_TestAssertions_bels_10));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 84*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertTrue_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = beva_v.bemd_0(-244976954);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 88*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_11));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 89*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertFalse_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_4_7_TestFailure bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (((BEC_2_5_4_LogicBool) beva_v).bevi_bool)/* Line: 93*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_4_10_TestAssertions_bels_12));
bevt_0_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_1_ta_ph);
throw new be.BECS_ThrowBack(bevt_0_ta_ph);
} /* Line: 94*/
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 26, 27, 28, 28, 28, 28, 0, 0, 0, 29, 29, 29, 29, 29, 29, 31, 31, 35, 36, 37, 37, 37, 37, 0, 0, 0, 38, 38, 38, 38, 38, 38, 40, 40, 44, 44, 47, 47, 50, 50, 51, 51, 51, 53, 54, 54, 55, 57, 59, 59, 60, 62, 64, 64, 64, 64, 64, 64, 64, 68, 69, 69, 69, 73, 73, 74, 74, 74, 78, 78, 79, 79, 79, 83, 83, 84, 84, 84, 88, 89, 89, 89, 94, 94, 94};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {45, 46, 48, 49, 54, 55, 60, 61, 64, 68, 71, 72, 73, 74, 75, 76, 78, 79, 95, 97, 98, 103, 104, 109, 110, 113, 117, 120, 121, 122, 123, 124, 125, 127, 128, 134, 135, 139, 140, 157, 162, 163, 164, 165, 167, 169, 174, 175, 178, 180, 185, 186, 189, 191, 192, 193, 194, 195, 196, 197, 205, 207, 208, 209, 217, 222, 223, 224, 225, 233, 238, 239, 240, 241, 249, 254, 255, 256, 257, 265, 267, 268, 269, 277, 278, 279};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 26 45
has 1 26 45
assign 1 26 46
not 0 26 46
assign 1 27 48
new 0 27 48
assign 1 28 49
def 1 28 54
assign 1 28 55
def 1 28 60
assign 1 0 61
assign 1 0 64
assign 1 0 68
assign 1 29 71
new 0 29 71
assign 1 29 72
addValue 1 29 72
assign 1 29 73
addValue 1 29 73
assign 1 29 74
new 0 29 74
assign 1 29 75
addValue 1 29 75
addValue 1 29 76
assign 1 31 78
new 1 31 78
throw 1 31 79
assign 1 35 95
has 1 35 95
assign 1 36 97
new 0 36 97
assign 1 37 98
def 1 37 103
assign 1 37 104
def 1 37 109
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 38 120
new 0 38 120
assign 1 38 121
addValue 1 38 121
assign 1 38 122
addValue 1 38 122
assign 1 38 123
new 0 38 123
assign 1 38 124
addValue 1 38 124
addValue 1 38 125
assign 1 40 127
new 1 40 127
throw 1 40 128
assign 1 44 134
assertEqual 2 44 134
return 1 44 135
assign 1 47 139
assertNotEqual 2 47 139
return 1 47 140
assign 1 50 157
undef 1 50 162
assign 1 51 163
new 0 51 163
assign 1 51 164
new 1 51 164
throw 1 51 165
assign 1 53 167
notEquals 1 53 167
assign 1 54 169
def 1 54 174
assign 1 55 175
toString 0 55 175
assign 1 57 178
new 0 57 178
assign 1 59 180
def 1 59 185
assign 1 60 186
toString 0 60 186
assign 1 62 189
new 0 62 189
assign 1 64 191
new 0 64 191
assign 1 64 192
add 1 64 192
assign 1 64 193
new 0 64 193
assign 1 64 194
add 1 64 194
assign 1 64 195
add 1 64 195
assign 1 64 196
new 1 64 196
throw 1 64 197
assign 1 68 205
equals 1 68 205
assign 1 69 207
new 0 69 207
assign 1 69 208
new 1 69 208
throw 1 69 209
assign 1 73 217
def 1 73 222
assign 1 74 223
new 0 74 223
assign 1 74 224
new 1 74 224
throw 1 74 225
assign 1 78 233
def 1 78 238
assign 1 79 239
new 0 79 239
assign 1 79 240
new 1 79 240
throw 1 79 241
assign 1 83 249
undef 1 83 254
assign 1 84 255
new 0 84 255
assign 1 84 256
new 1 84 256
throw 1 84 257
assign 1 88 265
not 0 88 265
assign 1 89 267
new 0 89 267
assign 1 89 268
new 1 89 268
throw 1 89 269
assign 1 94 277
new 0 94 277
assign 1 94 278
new 1 94 278
throw 1 94 279
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 310047227: return bem_fieldNamesGet_0();
case 221458969: return bem_serializeToString_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 78412540: return bem_toAny_0();
case -1079456517: return bem_many_0();
case -992634121: return bem_tagGet_0();
case -1238524057: return bem_print_0();
case -1851472893: return bem_once_0();
case -777537417: return bem_serializeContents_0();
case -1714583788: return bem_classNameGet_0();
case 205150354: return bem_new_0();
case -1331626162: return bem_iteratorGet_0();
case 217381802: return bem_serializationIteratorGet_0();
case 814015164: return bem_copy_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -1392846471: return bem_toString_0();
case -438289515: return bem_fieldIteratorGet_0();
case -1426056679: return bem_hashGet_0();
case 993286746: return bem_echo_0();
case 137910263: return bem_create_0();
case -1201862288: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -986755535: return bem_assertTrue_1(bevd_0);
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1853188445: return bem_assertFalse_1(bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1133218949: return bem_assertNotNull_1(bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 680502522: return bem_assertIsNull_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 241985310: return bem_assertNull_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 35514436: return bem_assertEquals_2(bevd_0, bevd_1);
case -872977660: return bem_assertNotEquals_2(bevd_0, bevd_1);
case -1173524602: return bem_assertHas_2(bevd_0, bevd_1);
case 1779449783: return bem_assertEqual_2(bevd_0, bevd_1);
case 1758714557: return bem_assertNotEqual_2(bevd_0, bevd_1);
case -466966221: return bem_assertNotHas_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_TestAssertions_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_10_TestAssertions_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_TestAssertions();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst = (BEC_2_4_10_TestAssertions) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_type;
}
}
