package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildVarSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildVarSyn() { }
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_inst;

public static BET_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public BEC_2_5_6_BuildVarSyn bem_new_0() throws Throwable {
bevp_isTyped = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_npNew_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
bevp_namepath = beva_np;
bevp_isTyped = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_anyNew_1(BEC_2_5_3_BuildVar beva_full) throws Throwable {
bevp_name = beva_full.bem_nameGet_0();
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_5_6_BuildVarSyn beva_o) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
if (beva_o == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 43*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 43*/
if (bevp_name == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_7_ta_ph = beva_o.bem_nameGet_0();
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_9_ta_ph = beva_o.bem_nameGet_0();
bevt_8_ta_ph = bevp_name.bem_notEquals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 45*/
bevt_12_ta_ph = beva_o.bem_isTypedGet_0();
bevt_11_ta_ph = bevp_isTyped.bem_notEquals_1(bevt_12_ta_ph);
if (bevt_11_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 48*/
if (bevp_isTyped.bevi_bool)/* Line: 50*/ {
bevt_15_ta_ph = beva_o.bem_namepathGet_0();
bevt_14_ta_ph = bevp_namepath.bem_notEquals_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_bool)/* Line: 50*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 50*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 50*/
 else /* Line: 50*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 50*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 51*/
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() throws Throwable {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() throws Throwable {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() throws Throwable {
return bevp_isThis;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 28, 29, 34, 35, 36, 37, 38, 43, 43, 43, 43, 44, 44, 44, 44, 44, 0, 0, 0, 44, 44, 0, 0, 0, 45, 45, 47, 47, 48, 48, 50, 50, 0, 0, 0, 51, 51, 53, 53, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 21, 22, 26, 27, 28, 29, 30, 52, 57, 58, 59, 61, 66, 67, 68, 73, 74, 77, 81, 84, 85, 87, 90, 94, 97, 98, 100, 101, 103, 104, 107, 108, 110, 113, 117, 120, 121, 123, 124, 127, 130, 134, 137, 141, 144, 148, 151, 155, 158};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 17
new 0 24 17
assign 1 28 21
assign 1 29 22
new 0 29 22
assign 1 34 26
nameGet 0 34 26
assign 1 35 27
namepathGet 0 35 27
assign 1 36 28
isTypedGet 0 36 28
assign 1 37 29
isSelfGet 0 37 29
assign 1 38 30
isThisGet 0 38 30
assign 1 43 52
undef 1 43 57
assign 1 43 58
new 0 43 58
return 1 43 59
assign 1 44 61
def 1 44 66
assign 1 44 67
nameGet 0 44 67
assign 1 44 68
def 1 44 73
assign 1 0 74
assign 1 0 77
assign 1 0 81
assign 1 44 84
nameGet 0 44 84
assign 1 44 85
notEquals 1 44 85
assign 1 0 87
assign 1 0 90
assign 1 0 94
assign 1 45 97
new 0 45 97
return 1 45 98
assign 1 47 100
isTypedGet 0 47 100
assign 1 47 101
notEquals 1 47 101
assign 1 48 103
new 0 48 103
return 1 48 104
assign 1 50 107
namepathGet 0 50 107
assign 1 50 108
notEquals 1 50 108
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 51 120
new 0 51 120
return 1 51 121
assign 1 53 123
new 0 53 123
return 1 53 124
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1668207848: return bem_create_0();
case -752204173: return bem_hashGet_0();
case 1462038275: return bem_namepathGet_0();
case -1558425735: return bem_print_0();
case 1959786844: return bem_isTypedGet_0();
case 184194385: return bem_copy_0();
case 1866521645: return bem_nameGet_0();
case -1459622248: return bem_new_0();
case 275008169: return bem_iteratorGet_0();
case -185807531: return bem_isSelfGet_0();
case 2101401855: return bem_toString_0();
case -933081407: return bem_isThisGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1623260912: return bem_isSelfSet_1(bevd_0);
case -421714234: return bem_anyNew_1((BEC_2_5_3_BuildVar) bevd_0);
case -204935993: return bem_contentsEqual_1((BEC_2_5_6_BuildVarSyn) bevd_0);
case 1790102834: return bem_notEquals_1(bevd_0);
case 154368609: return bem_copyTo_1(bevd_0);
case -1486272003: return bem_undef_1(bevd_0);
case 758469861: return bem_nameSet_1(bevd_0);
case 674741335: return bem_isTypedSet_1(bevd_0);
case -224640862: return bem_isThisSet_1(bevd_0);
case -1464753817: return bem_npNew_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -652861342: return bem_equals_1(bevd_0);
case 387294236: return bem_namepathSet_1(bevd_0);
case -1703868814: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 145687102: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 648898220: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2076042115: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1494362942: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildVarSyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildVarSyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildVarSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst = (BEC_2_5_6_BuildVarSyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_type;
}
}
