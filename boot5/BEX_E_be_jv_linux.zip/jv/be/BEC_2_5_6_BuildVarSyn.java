package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildVarSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildVarSyn() { }
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public BEC_2_5_6_BuildVarSyn bem_new_0() throws Throwable {
bevp_isTyped = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_npNew_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
bevp_namepath = beva_np;
bevp_isTyped = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_anyNew_1(BEC_2_5_3_BuildVar beva_full) throws Throwable {
bevp_name = beva_full.bem_nameGet_0();
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_5_6_BuildVarSyn beva_o) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_o == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 39 */
if (bevp_name == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_7_tmpany_phold = beva_o.bem_nameGet_0();
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_9_tmpany_phold = beva_o.bem_nameGet_0();
bevt_8_tmpany_phold = bevp_name.bem_notEquals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 41 */
bevt_12_tmpany_phold = beva_o.bem_isTypedGet_0();
bevt_11_tmpany_phold = bevp_isTyped.bem_notEquals_1(bevt_12_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 44 */
if (bevp_isTyped.bevi_bool) /* Line: 46 */ {
bevt_15_tmpany_phold = beva_o.bem_namepathGet_0();
bevt_14_tmpany_phold = bevp_namepath.bem_notEquals_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
 else  /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 46 */ {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 47 */
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() throws Throwable {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() throws Throwable {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() throws Throwable {
return bevp_isThis;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 24, 25, 30, 31, 32, 33, 34, 39, 39, 39, 39, 40, 40, 40, 40, 40, 0, 0, 0, 40, 40, 0, 0, 0, 41, 41, 43, 43, 44, 44, 46, 46, 0, 0, 0, 47, 47, 49, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 18, 19, 23, 24, 25, 26, 27, 49, 54, 55, 56, 58, 63, 64, 65, 70, 71, 74, 78, 81, 82, 84, 87, 91, 94, 95, 97, 98, 100, 101, 104, 105, 107, 110, 114, 117, 118, 120, 121, 124, 127, 131, 134, 138, 141, 145, 148, 152, 155};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 14
new 0 20 14
assign 1 24 18
assign 1 25 19
new 0 25 19
assign 1 30 23
nameGet 0 30 23
assign 1 31 24
namepathGet 0 31 24
assign 1 32 25
isTypedGet 0 32 25
assign 1 33 26
isSelfGet 0 33 26
assign 1 34 27
isThisGet 0 34 27
assign 1 39 49
undef 1 39 54
assign 1 39 55
new 0 39 55
return 1 39 56
assign 1 40 58
def 1 40 63
assign 1 40 64
nameGet 0 40 64
assign 1 40 65
def 1 40 70
assign 1 0 71
assign 1 0 74
assign 1 0 78
assign 1 40 81
nameGet 0 40 81
assign 1 40 82
notEquals 1 40 82
assign 1 0 84
assign 1 0 87
assign 1 0 91
assign 1 41 94
new 0 41 94
return 1 41 95
assign 1 43 97
isTypedGet 0 43 97
assign 1 43 98
notEquals 1 43 98
assign 1 44 100
new 0 44 100
return 1 44 101
assign 1 46 104
namepathGet 0 46 104
assign 1 46 105
notEquals 1 46 105
assign 1 0 107
assign 1 0 110
assign 1 0 114
assign 1 47 117
new 0 47 117
return 1 47 118
assign 1 49 120
new 0 49 120
return 1 49 121
return 1 0 124
assign 1 0 127
return 1 0 131
assign 1 0 134
return 1 0 138
assign 1 0 141
return 1 0 145
assign 1 0 148
return 1 0 152
assign 1 0 155
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1823731495: return bem_fieldIteratorGet_0();
case 380917179: return bem_deserializeClassNameGet_0();
case 2007419844: return bem_sourceFileNameGet_0();
case -1997732490: return bem_serializeToString_0();
case -288603233: return bem_serializationIteratorGet_0();
case -486730947: return bem_tagGet_0();
case -64889092: return bem_namepathGet_0();
case 89921707: return bem_echo_0();
case -2002314890: return bem_serializeContents_0();
case -706394436: return bem_classNameGet_0();
case -145517521: return bem_iteratorGet_0();
case 603913985: return bem_isSelfGet_0();
case 991850509: return bem_hashGet_0();
case -438931987: return bem_many_0();
case 903380622: return bem_copy_0();
case 192353495: return bem_toString_0();
case -163625765: return bem_isTypedGet_0();
case 938035288: return bem_isThisGet_0();
case 1071338406: return bem_once_0();
case 150815360: return bem_new_0();
case -610207516: return bem_print_0();
case 1733022581: return bem_create_0();
case 1222559837: return bem_toAny_0();
case -40755554: return bem_nameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -177732522: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 754254864: return bem_sameType_1(bevd_0);
case 1234343289: return bem_def_1(bevd_0);
case 1213238271: return bem_npNew_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1623932547: return bem_anyNew_1((BEC_2_5_3_BuildVar) bevd_0);
case -186471458: return bem_namepathSet_1(bevd_0);
case 698316509: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1886873191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1794454226: return bem_undef_1(bevd_0);
case -907803894: return bem_otherType_1(bevd_0);
case -2038181641: return bem_copyTo_1(bevd_0);
case -1587661946: return bem_sameObject_1(bevd_0);
case -174280441: return bem_otherClass_1(bevd_0);
case 1702402169: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -707814510: return bem_nameSet_1(bevd_0);
case -1812425724: return bem_notEquals_1(bevd_0);
case -2087149042: return bem_undefined_1(bevd_0);
case -226295549: return bem_sameClass_1(bevd_0);
case 980436961: return bem_isThisSet_1(bevd_0);
case -1245865568: return bem_contentsEqual_1((BEC_2_5_6_BuildVarSyn) bevd_0);
case 1211215967: return bem_isTypedSet_1(bevd_0);
case 568764092: return bem_equals_1(bevd_0);
case 1511228153: return bem_isSelfSet_1(bevd_0);
case -1951248711: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -862992684: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 608937217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1346377346: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1911273797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1789964230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2066895296: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1538374916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildVarSyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildVarSyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildVarSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst = (BEC_2_5_6_BuildVarSyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst;
}
}
