package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerQueue extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerQueue() { }
private static byte[] becc_BEC_2_9_5_ContainerQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_5_ContainerQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_inst;

public static BET_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_bottom;
public BEC_3_9_5_4_ContainerStackNode bevp_end;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_5_ContainerQueue bem_new_0() throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_enqueue_1(beva_item);
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_end = bevp_top;
bevp_bottom = bevp_top;
} /* Line: 128 */
 else  /* Line: 125 */ {
if (bevp_bottom == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_4_tmpany_phold = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
bevp_end = bevp_top;
} /* Line: 134 */
 else  /* Line: 135 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 136 */
} /* Line: 130 */
 else  /* Line: 138 */ {
bevp_bottom = bevp_top;
} /* Line: 139 */
} /* Line: 125 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dequeue_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_item = null;
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 146 */ {
return null;
} /* Line: 147 */
bevl_item = bevp_bottom.bem_heldGet_0();
bevp_bottom.bem_heldSet_1(null);
bevt_1_tmpany_phold = bevp_bottom.bem_equals_1(bevp_top);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevp_bottom = null;
} /* Line: 152 */
 else  /* Line: 153 */ {
bevl_last = bevp_bottom;
bevp_bottom = bevp_bottom.bem_nextGet_0();
bevl_last.bem_nextSet_1(null);
bevl_last.bem_priorSet_1(bevp_end);
bevp_end.bem_nextSet_1(bevl_last);
bevp_end = bevl_last;
} /* Line: 160 */
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_dequeue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_9_5_ContainerQueue bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_enqueue_1(beva_item);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_topGetDirect_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerQueue bem_topSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_bottomGet_0() throws Throwable {
return bevp_bottom;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_bottomGetDirect_0() throws Throwable {
return bevp_bottom;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_bottomSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerQueue bem_bottomSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_endGet_0() throws Throwable {
return bevp_end;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_endGetDirect_0() throws Throwable {
return bevp_end;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_endSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerQueue bem_endSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerQueue bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {115, 121, 125, 125, 126, 127, 128, 129, 129, 130, 130, 130, 131, 131, 132, 132, 133, 134, 136, 139, 141, 142, 146, 146, 147, 149, 150, 151, 152, 155, 156, 157, 158, 159, 160, 162, 163, 167, 167, 171, 171, 175, 175, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 20, 30, 35, 36, 37, 38, 41, 46, 47, 48, 53, 54, 55, 56, 57, 58, 59, 62, 66, 69, 70, 78, 83, 84, 86, 87, 88, 90, 93, 94, 95, 96, 97, 98, 100, 101, 105, 110, 114, 115, 119, 120, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 115 16
new 0 115 16
enqueue 1 121 20
assign 1 125 30
undef 1 125 35
assign 1 126 36
new 0 126 36
assign 1 127 37
assign 1 128 38
assign 1 129 41
def 1 129 46
assign 1 130 47
nextGet 0 130 47
assign 1 130 48
undef 1 130 53
assign 1 131 54
new 0 131 54
nextSet 1 131 55
assign 1 132 56
nextGet 0 132 56
priorSet 1 132 57
assign 1 133 58
nextGet 0 133 58
assign 1 134 59
assign 1 136 62
nextGet 0 136 62
assign 1 139 66
heldSet 1 141 69
assign 1 142 70
increment 0 142 70
assign 1 146 78
undef 1 146 83
return 1 147 84
assign 1 149 86
heldGet 0 149 86
heldSet 1 150 87
assign 1 151 88
equals 1 151 88
assign 1 152 90
assign 1 155 93
assign 1 156 94
nextGet 0 156 94
nextSet 1 157 95
priorSet 1 158 96
nextSet 1 159 97
assign 1 160 98
assign 1 162 100
decrement 0 162 100
return 1 163 101
assign 1 167 105
undef 1 167 110
return 1 167 110
assign 1 171 114
dequeue 0 171 114
return 1 171 115
assign 1 175 119
enqueue 1 175 119
return 1 175 120
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2121557728: return bem_topGetDirect_0();
case -730850057: return bem_new_0();
case -1388155929: return bem_bottomGetDirect_0();
case -1002865577: return bem_classNameGet_0();
case -241911646: return bem_sizeGet_0();
case -1535960526: return bem_bottomGet_0();
case -943150204: return bem_isEmptyGet_0();
case 1951393559: return bem_once_0();
case 655131956: return bem_topGet_0();
case -973144672: return bem_endGetDirect_0();
case 216516509: return bem_copy_0();
case 1309277187: return bem_serializationIteratorGet_0();
case 1810328254: return bem_fieldNamesGet_0();
case -184894195: return bem_create_0();
case -749676617: return bem_serializeToString_0();
case -1903112833: return bem_serializeContents_0();
case -1714302458: return bem_tagGet_0();
case -452381319: return bem_hashGet_0();
case 1780712404: return bem_toAny_0();
case -1477376721: return bem_endGet_0();
case 985150622: return bem_sizeGetDirect_0();
case 2087395772: return bem_print_0();
case 1796117718: return bem_get_0();
case 1016157954: return bem_deserializeClassNameGet_0();
case -743672203: return bem_toString_0();
case 535585918: return bem_echo_0();
case -2016637928: return bem_dequeue_0();
case -333666649: return bem_iteratorGet_0();
case 764172461: return bem_sourceFileNameGet_0();
case 643429711: return bem_many_0();
case 1466941499: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -557613368: return bem_sameClass_1(bevd_0);
case 810638297: return bem_sizeSetDirect_1(bevd_0);
case -826993135: return bem_put_1(bevd_0);
case -639114335: return bem_bottomSet_1(bevd_0);
case -1938939824: return bem_sameType_1(bevd_0);
case 807453833: return bem_topSet_1(bevd_0);
case 1190344604: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 732303652: return bem_undefined_1(bevd_0);
case -1603118850: return bem_endSetDirect_1(bevd_0);
case -1763815494: return bem_undef_1(bevd_0);
case 1162023135: return bem_bottomSetDirect_1(bevd_0);
case -536421745: return bem_def_1(bevd_0);
case 842198181: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 217750778: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 221919936: return bem_otherType_1(bevd_0);
case -1645106897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1522004802: return bem_otherClass_1(bevd_0);
case 1426897534: return bem_notEquals_1(bevd_0);
case -1244949432: return bem_endSet_1(bevd_0);
case -1764703892: return bem_enqueue_1(bevd_0);
case -1327170073: return bem_copyTo_1(bevd_0);
case -1334547320: return bem_sizeSet_1(bevd_0);
case 1578318955: return bem_topSetDirect_1(bevd_0);
case 884363775: return bem_addValue_1(bevd_0);
case 254544143: return bem_defined_1(bevd_0);
case 674985673: return bem_equals_1(bevd_0);
case 275261050: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1213162260: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1183971462: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1639843562: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 758918507: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -36988574: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1804891568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1644786359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerQueue_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerQueue_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerQueue();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst = (BEC_2_9_5_ContainerQueue) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_type;
}
}
