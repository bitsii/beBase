package be;
/* IO:File: source/base/OpiFc.be */
public final class BEC_2_6_19_SystemObjectFieldIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0 = {0x47,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0, 9));
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1 = {0x53,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1, 9));
public static BEC_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;

public static BET_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_9_4_ContainerList bevp_instFieldNames;
public BEC_2_4_3_MathInt bevp_lastidx;
public BEC_2_6_19_SystemObjectFieldIterator bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_new_2(beva__instance, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevp_instance.bemd_0(1810328254);
bevt_0_tmpany_phold = bevp_instFieldNames.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_0;
bevp_lastidx = bevt_0_tmpany_phold.bem_subtract_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 30 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_pos.bevi_int < bevp_lastidx.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 36 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_pos.bevi_int <= bevp_lastidx.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 43 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bem_advance_0();
bevt_0_tmpany_phold = bem_currentNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 54 */ {
bevt_1_tmpany_phold = bevp_instFieldNames.bem_get_1(bevp_pos);
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /* Line: 55 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bem_advance_0();
bevt_0_tmpany_phold = bem_currentGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_1;
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_res = bevp_instance.bemd_2(758918507, bevl_invokeName, bevt_2_tmpany_phold);
return bevl_res;
} /* Line: 70 */
return null;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bem_advance_0();
bem_currentSet_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_9_4_ContainerList bevl_args = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_2;
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_args = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_args.bem_put_2(bevt_3_tmpany_phold, beva_value);
bevp_instance.bemd_2(758918507, bevl_invokeName, bevl_args);
} /* Line: 86 */
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 91 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 91 */ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 91 */
 else  /* Line: 91 */ {
break;
} /* Line: 91 */
} /* Line: 91 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_posGetDirect_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() throws Throwable {
return bevp_instance;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_instanceGetDirect_0() throws Throwable {
return bevp_instance;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_instanceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_instFieldNamesGet_0() throws Throwable {
return bevp_instFieldNames;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_instFieldNamesGetDirect_0() throws Throwable {
return bevp_instFieldNames;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instFieldNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_instFieldNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lastidxGet_0() throws Throwable {
return bevp_lastidx;
} /*method end*/
public final BEC_2_4_3_MathInt bem_lastidxGetDirect_0() throws Throwable {
return bevp_lastidx;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_lastidxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastidx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_lastidxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastidx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 16, 16, 21, 22, 23, 24, 24, 24, 29, 30, 35, 35, 36, 36, 38, 38, 42, 42, 43, 43, 45, 45, 49, 50, 50, 54, 55, 55, 57, 61, 62, 62, 66, 67, 68, 68, 69, 69, 70, 72, 76, 77, 81, 82, 83, 83, 84, 84, 85, 85, 86, 91, 91, 91, 92, 91, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 33, 34, 35, 36, 37, 38, 43, 45, 53, 58, 59, 60, 62, 63, 69, 74, 75, 76, 78, 79, 83, 84, 85, 90, 92, 93, 95, 99, 100, 101, 110, 112, 113, 114, 115, 116, 117, 119, 122, 123, 134, 136, 137, 138, 139, 140, 141, 142, 143, 150, 153, 158, 159, 160, 169, 172, 175, 179, 183, 186, 189, 193, 197, 200, 203, 207, 211, 214, 217, 221};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 26
new 0 16 26
assign 1 16 27
new 2 16 27
return 1 16 28
assign 1 21 33
new 0 21 33
assign 1 22 34
assign 1 23 35
fieldNamesGet 0 23 35
assign 1 24 36
sizeGet 0 24 36
assign 1 24 37
new 0 24 37
assign 1 24 38
subtract 1 24 38
assign 1 29 43
hasNextGet 0 29 43
assign 1 30 45
increment 0 30 45
assign 1 35 53
lesser 1 35 58
assign 1 36 59
new 0 36 59
return 1 36 60
assign 1 38 62
new 0 38 62
return 1 38 63
assign 1 42 69
lesserEquals 1 42 74
assign 1 43 75
new 0 43 75
return 1 43 76
assign 1 45 78
new 0 45 78
return 1 45 79
advance 0 49 83
assign 1 50 84
currentNameGet 0 50 84
return 1 50 85
assign 1 54 90
hasCurrentGet 0 54 90
assign 1 55 92
get 1 55 92
return 1 55 93
return 1 57 95
advance 0 61 99
assign 1 62 100
currentGet 0 62 100
return 1 62 101
assign 1 66 110
hasCurrentGet 0 66 110
assign 1 67 112
currentNameGet 0 67 112
assign 1 68 113
new 0 68 113
assign 1 68 114
add 1 68 114
assign 1 69 115
new 0 69 115
assign 1 69 116
invoke 2 69 116
return 1 70 117
return 1 72 119
advance 0 76 122
currentSet 1 77 123
assign 1 81 134
hasCurrentGet 0 81 134
assign 1 82 136
currentNameGet 0 82 136
assign 1 83 137
new 0 83 137
assign 1 83 138
add 1 83 138
assign 1 84 139
new 0 84 139
assign 1 84 140
new 1 84 140
assign 1 85 141
new 0 85 141
put 2 85 142
invoke 2 86 143
assign 1 91 150
new 0 91 150
assign 1 91 153
lesser 1 91 158
nextSet 1 92 159
incrementValue 0 91 160
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1805391595: return bem_instFieldNamesGetDirect_0();
case -768031062: return bem_nextGet_0();
case -730850057: return bem_new_0();
case -1147606710: return bem_nextNameGet_0();
case 1328300159: return bem_posGetDirect_0();
case -1002865577: return bem_classNameGet_0();
case -1785373112: return bem_currentNameGet_0();
case 1951393559: return bem_once_0();
case -517323157: return bem_instanceGetDirect_0();
case 216516509: return bem_copy_0();
case 1765963524: return bem_lastidxGet_0();
case 728473118: return bem_hasNextGet_0();
case 1309277187: return bem_serializationIteratorGet_0();
case 1810328254: return bem_fieldNamesGet_0();
case 1377411668: return bem_instanceGet_0();
case -184894195: return bem_create_0();
case -749676617: return bem_serializeToString_0();
case 753190635: return bem_instFieldNamesGet_0();
case 728019512: return bem_posGet_0();
case -1903112833: return bem_serializeContents_0();
case -1714302458: return bem_tagGet_0();
case -452381319: return bem_hashGet_0();
case 1780712404: return bem_toAny_0();
case -1046063950: return bem_lastidxGetDirect_0();
case 2087395772: return bem_print_0();
case 1016157954: return bem_deserializeClassNameGet_0();
case -743672203: return bem_toString_0();
case 535585918: return bem_echo_0();
case -333666649: return bem_iteratorGet_0();
case -138679152: return bem_advance_0();
case 1892936415: return bem_currentGet_0();
case 764172461: return bem_sourceFileNameGet_0();
case 643429711: return bem_many_0();
case -566574560: return bem_hasCurrentGet_0();
case 1466941499: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 705847969: return bem_currentSet_1(bevd_0);
case -325873265: return bem_posSetDirect_1(bevd_0);
case 1718024904: return bem_instFieldNamesSetDirect_1(bevd_0);
case -1763815494: return bem_undef_1(bevd_0);
case 1152102231: return bem_lastidxSet_1(bevd_0);
case -536421745: return bem_def_1(bevd_0);
case -1645106897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 217750778: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 674985673: return bem_equals_1(bevd_0);
case 221919936: return bem_otherType_1(bevd_0);
case -1938939824: return bem_sameType_1(bevd_0);
case 380153281: return bem_new_1(bevd_0);
case 254544143: return bem_defined_1(bevd_0);
case -557613368: return bem_sameClass_1(bevd_0);
case 732303652: return bem_undefined_1(bevd_0);
case 1685933779: return bem_lastidxSetDirect_1(bevd_0);
case 1731078287: return bem_instFieldNamesSet_1(bevd_0);
case 1426897534: return bem_notEquals_1(bevd_0);
case -1327170073: return bem_copyTo_1(bevd_0);
case -1176679177: return bem_instanceSet_1(bevd_0);
case 842198181: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1190344604: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1243694279: return bem_posSet_1(bevd_0);
case 275261050: return bem_sameObject_1(bevd_0);
case 1619487855: return bem_instanceSetDirect_1(bevd_0);
case 1522004802: return bem_otherClass_1(bevd_0);
case -1514564738: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 948771836: return bem_nextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1213162260: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1183971462: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1639843562: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 758918507: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -36988574: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1804891568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1644786359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -675903939: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemObjectFieldIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_19_SystemObjectFieldIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;
}
}
