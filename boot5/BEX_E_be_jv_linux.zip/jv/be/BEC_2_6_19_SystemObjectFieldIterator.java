package be;
/* IO:File: source/base/OpiFc.be */
public final class BEC_2_6_19_SystemObjectFieldIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1 = {0x53,0x65,0x74};
public static BEC_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;

public static BET_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_9_4_ContainerList bevp_instFieldNames;
public BEC_2_4_3_MathInt bevp_lastidx;
public BEC_2_6_19_SystemObjectFieldIterator bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_new_2(beva__instance, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) throws Throwable {
BEC_2_6_5_SystemTypes bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevt_0_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevp_instFieldNames = bevt_0_ta_ph.bem_fieldNames_1(bevp_instance);
bevt_1_ta_ph = bevp_instFieldNames.bem_sizeGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_lastidx = bevt_1_ta_ph.bem_subtract_1(bevt_2_ta_ph);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 35*/ {
bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 36*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_pos.bevi_int < bevp_lastidx.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 41*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 42*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_pos.bevi_int <= bevp_lastidx.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 49*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bem_advance_0();
bevt_0_ta_ph = bem_currentNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_1_ta_ph = bevp_instFieldNames.bem_get_1(bevp_pos);
return (BEC_2_4_6_TextString) bevt_1_ta_ph;
} /* Line: 61*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bem_advance_0();
bevt_0_ta_ph = bem_currentGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 72*/ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0));
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_res = bevp_instance.bemd_2(664895809, bevl_invokeName, bevt_2_ta_ph);
return bevl_res;
} /* Line: 76*/
return null;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bem_advance_0();
bem_currentSet_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_9_4_ContainerList bevl_args = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 87*/ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1));
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_args = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_args.bem_put_2(bevt_3_ta_ph, beva_value);
bevp_instance.bemd_2(664895809, bevl_invokeName, bevl_args);
} /* Line: 92*/
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 97*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 97*/ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 97*/
 else /* Line: 97*/ {
break;
} /* Line: 97*/
} /* Line: 97*/
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {22, 22, 22, 27, 28, 29, 29, 30, 30, 30, 35, 36, 41, 41, 42, 42, 44, 44, 48, 48, 49, 49, 51, 51, 55, 56, 56, 60, 61, 61, 63, 67, 68, 68, 72, 73, 74, 74, 75, 75, 76, 78, 82, 83, 87, 88, 89, 89, 90, 90, 91, 91, 92, 97, 97, 97, 98, 97};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 31, 32, 33, 34, 35, 36, 37, 42, 44, 52, 57, 58, 59, 61, 62, 68, 73, 74, 75, 77, 78, 82, 83, 84, 89, 91, 92, 94, 98, 99, 100, 109, 111, 112, 113, 114, 115, 116, 118, 121, 122, 133, 135, 136, 137, 138, 139, 140, 141, 142, 149, 152, 157, 158, 159};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 22 23
new 0 22 23
assign 1 22 24
new 2 22 24
return 1 22 25
assign 1 27 31
new 0 27 31
assign 1 28 32
assign 1 29 33
new 0 29 33
assign 1 29 34
fieldNames 1 29 34
assign 1 30 35
sizeGet 0 30 35
assign 1 30 36
new 0 30 36
assign 1 30 37
subtract 1 30 37
assign 1 35 42
hasNextGet 0 35 42
assign 1 36 44
increment 0 36 44
assign 1 41 52
lesser 1 41 57
assign 1 42 58
new 0 42 58
return 1 42 59
assign 1 44 61
new 0 44 61
return 1 44 62
assign 1 48 68
lesserEquals 1 48 73
assign 1 49 74
new 0 49 74
return 1 49 75
assign 1 51 77
new 0 51 77
return 1 51 78
advance 0 55 82
assign 1 56 83
currentNameGet 0 56 83
return 1 56 84
assign 1 60 89
hasCurrentGet 0 60 89
assign 1 61 91
get 1 61 91
return 1 61 92
return 1 63 94
advance 0 67 98
assign 1 68 99
currentGet 0 68 99
return 1 68 100
assign 1 72 109
hasCurrentGet 0 72 109
assign 1 73 111
currentNameGet 0 73 111
assign 1 74 112
new 0 74 112
assign 1 74 113
add 1 74 113
assign 1 75 114
new 0 75 114
assign 1 75 115
invoke 2 75 115
return 1 76 116
return 1 78 118
advance 0 82 121
currentSet 1 83 122
assign 1 87 133
hasCurrentGet 0 87 133
assign 1 88 135
currentNameGet 0 88 135
assign 1 89 136
new 0 89 136
assign 1 89 137
add 1 89 137
assign 1 90 138
new 0 90 138
assign 1 90 139
new 1 90 139
assign 1 91 140
new 0 91 140
put 2 91 141
invoke 2 92 142
assign 1 97 149
new 0 97 149
assign 1 97 152
lesser 1 97 157
nextSet 1 98 158
incrementValue 0 97 159
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1501634450: return bem_new_0();
case 1952943856: return bem_iteratorGet_0();
case -702300199: return bem_nextNameGet_0();
case 1962668450: return bem_hashGet_0();
case -1906193552: return bem_advance_0();
case -750042975: return bem_currentNameGet_0();
case 517610545: return bem_create_0();
case -11439861: return bem_toString_0();
case 1058063301: return bem_currentGet_0();
case 1213754288: return bem_hasCurrentGet_0();
case -953066157: return bem_nextGet_0();
case -86063738: return bem_hasNextGet_0();
case 1027167395: return bem_print_0();
case -981204172: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 978237725: return bem_def_1(bevd_0);
case -2047953674: return bem_undef_1(bevd_0);
case -749398745: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 857299362: return bem_copyTo_1(bevd_0);
case -1622730438: return bem_currentSet_1(bevd_0);
case -1108230193: return bem_nextSet_1(bevd_0);
case 105007733: return bem_equals_1(bevd_0);
case 234623522: return bem_notEquals_1(bevd_0);
case -460873787: return bem_new_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -976124908: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -450201493: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 664895809: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1815776256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -917399680: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemObjectFieldIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_19_SystemObjectFieldIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;
}
}
