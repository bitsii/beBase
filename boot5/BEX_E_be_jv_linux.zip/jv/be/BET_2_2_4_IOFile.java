package be;
public class BET_2_2_4_IOFile extends BETS_Object {
public BET_2_2_4_IOFile() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "apNew_1", "pathNew_1", "readerGet_0", "writerGet_0", "delete_0", "copyFile_1", "mkdirs_0", "mkdir_0", "makeDirs_0", "isDirectoryGet_0", "lastUpdatedGet_0", "lastUpdatedSet_1", "isDirGet_0", "isFileGet_0", "makeFile_0", "contentsGet_0", "contentsNoCheckGet_0", "contentsSet_1", "contentsNoCheckSet_1", "sizeGet_0", "existsGet_0", "absPathGet_0", "close_0", "pathGet_0", "pathSet_1", "readerSet_1", "writerSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "path", "reader", "writer" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_2_4_IOFile();
}
}
