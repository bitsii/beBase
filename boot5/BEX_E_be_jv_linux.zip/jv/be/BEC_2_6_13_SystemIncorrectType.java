package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_13_SystemIncorrectType extends BEC_2_6_9_SystemException {
public BEC_2_6_13_SystemIncorrectType() { }
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x54,0x79,0x70,0x65};
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;

public static BET_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_type;

public BEC_2_6_13_SystemIncorrectType bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {397};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 397 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 627830370: return bem_vvGet_0();
case 653341959: return bem_print_0();
case -1439875774: return bem_new_0();
case 631831062: return bem_framesTextGetDirect_0();
case 1265980009: return bem_framesGetDirect_0();
case -658402665: return bem_methodNameGet_0();
case 1280049671: return bem_fileNameGet_0();
case 2036147796: return bem_toString_0();
case 1430998361: return bem_serializationIteratorGet_0();
case -606112690: return bem_framesTextGet_0();
case 1611852149: return bem_methodNameGetDirect_0();
case -1551806822: return bem_toAny_0();
case -1195111829: return bem_create_0();
case -124614786: return bem_lineNumberGet_0();
case -1500978633: return bem_tagGet_0();
case -1737009900: return bem_many_0();
case 1586760974: return bem_vvGetDirect_0();
case 2142839666: return bem_translateEmittedExceptionInner_0();
case 573647971: return bem_iteratorGet_0();
case 1916750716: return bem_descriptionGet_0();
case -1976480232: return bem_once_0();
case -1066226610: return bem_fieldNamesGet_0();
case 776526411: return bem_langGetDirect_0();
case -189650229: return bem_emitLangGetDirect_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case -463663025: return bem_langGet_0();
case -1680697389: return bem_lineNumberGetDirect_0();
case 29133491: return bem_translatedGet_0();
case -680143754: return bem_klassNameGet_0();
case 1201799861: return bem_serializeToString_0();
case -1597211827: return bem_translateEmittedException_0();
case -187637321: return bem_descriptionGetDirect_0();
case 1525639803: return bem_sourceFileNameGet_0();
case -1006582910: return bem_getFrameText_0();
case 1733539906: return bem_klassNameGetDirect_0();
case 191896611: return bem_copy_0();
case -1759630984: return bem_classNameGet_0();
case -785287907: return bem_translatedGetDirect_0();
case 640358082: return bem_fileNameGetDirect_0();
case -1748925107: return bem_echo_0();
case -2072472298: return bem_hashGet_0();
case -114079936: return bem_serializeContents_0();
case 2102651338: return bem_fieldIteratorGet_0();
case -1260421489: return bem_framesGet_0();
case -268634707: return bem_emitLangGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case -971362589: return bem_descriptionSet_1(bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case -2086425665: return bem_lineNumberSet_1(bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 640359244: return bem_translatedSetDirect_1(bevd_0);
case -1545100961: return bem_vvSet_1(bevd_0);
case 1385377819: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1531874058: return bem_klassNameSet_1(bevd_0);
case 1071493048: return bem_langSetDirect_1(bevd_0);
case 1953339794: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1644095380: return bem_langSet_1(bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2096880070: return bem_methodNameSetDirect_1(bevd_0);
case 1229124650: return bem_framesSetDirect_1(bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 884462515: return bem_def_1(bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
case -1394702385: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -192271885: return bem_equals_1(bevd_0);
case -1881282586: return bem_framesSet_1(bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
case 837512208: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
case -112765537: return bem_vvSetDirect_1(bevd_0);
case -712903169: return bem_new_1(bevd_0);
case -1400050056: return bem_methodNameSet_1(bevd_0);
case -1831129367: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1260506688: return bem_framesTextSet_1(bevd_0);
case 2052371309: return bem_klassNameSetDirect_1(bevd_0);
case 307063595: return bem_translatedSet_1(bevd_0);
case -102295312: return bem_sameObject_1(bevd_0);
case -444611263: return bem_emitLangSetDirect_1(bevd_0);
case -1047868306: return bem_fileNameSetDirect_1(bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case 1432377711: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 110202403: return bem_lineNumberSetDirect_1(bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case -553138837: return bem_framesTextSetDirect_1(bevd_0);
case -1755840098: return bem_emitLangSet_1(bevd_0);
case 1258788057: return bem_fileNameSet_1(bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case 1111150584: return bem_descriptionSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1857242177: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_13_SystemIncorrectType_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_13_SystemIncorrectType_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_13_SystemIncorrectType();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst = (BEC_2_6_13_SystemIncorrectType) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_type;
}
}
