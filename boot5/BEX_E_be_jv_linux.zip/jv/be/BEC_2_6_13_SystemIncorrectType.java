package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_13_SystemIncorrectType extends BEC_2_6_9_SystemException {
public BEC_2_6_13_SystemIncorrectType() { }
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x54,0x79,0x70,0x65};
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;

public static BET_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_type;

public BEC_2_6_13_SystemIncorrectType bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {146};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 146 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 560315918: return bem_descriptionGet_0();
case -2133162976: return bem_fileNameGet_0();
case -1191703617: return bem_klassNameGet_0();
case -1759402304: return bem_emitLangGetDirect_0();
case -129556018: return bem_fieldNamesGet_0();
case 1117951917: return bem_fileNameGetDirect_0();
case 715553388: return bem_serializationIteratorGet_0();
case -1915513690: return bem_classNameGet_0();
case 1534778339: return bem_serializeContents_0();
case 1476209067: return bem_translatedGet_0();
case 842069038: return bem_langGet_0();
case -1051909066: return bem_vvGetDirect_0();
case 1057028028: return bem_fieldIteratorGet_0();
case 198473032: return bem_tagGet_0();
case -131794502: return bem_klassNameGetDirect_0();
case -683041353: return bem_langGetDirect_0();
case 2116689770: return bem_vvGet_0();
case -1232195019: return bem_emitLangGet_0();
case 708488762: return bem_create_0();
case -443351197: return bem_methodNameGet_0();
case -1330871297: return bem_lineNumberGetDirect_0();
case -255547051: return bem_framesGet_0();
case 290193605: return bem_toString_0();
case 619471017: return bem_descriptionGetDirect_0();
case 1528097206: return bem_serializeToString_0();
case 807844599: return bem_copy_0();
case -1781364078: return bem_print_0();
case 210349252: return bem_deserializeClassNameGet_0();
case -1904617992: return bem_framesGetDirect_0();
case 363290539: return bem_methodNameGetDirect_0();
case -1902821230: return bem_sourceFileNameGet_0();
case -150929565: return bem_getFrameText_0();
case -424344631: return bem_framesTextGet_0();
case -450907329: return bem_iteratorGet_0();
case -436514878: return bem_echo_0();
case -593653793: return bem_lineNumberGet_0();
case -1140704937: return bem_framesTextGetDirect_0();
case 1982674913: return bem_translatedGetDirect_0();
case 1476572399: return bem_new_0();
case 1604055525: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1173782294: return bem_langSet_1(bevd_0);
case -568655712: return bem_framesSet_1(bevd_0);
case 1349055927: return bem_framesTextSetDirect_1(bevd_0);
case 1880525273: return bem_otherType_1(bevd_0);
case -999927226: return bem_notEquals_1(bevd_0);
case -789495842: return bem_klassNameSetDirect_1(bevd_0);
case -1865008630: return bem_equals_1(bevd_0);
case 625212932: return bem_descriptionSet_1(bevd_0);
case 1141872328: return bem_new_1(bevd_0);
case 659202532: return bem_lineNumberSet_1(bevd_0);
case 884004765: return bem_translatedSet_1(bevd_0);
case 1999303058: return bem_descriptionSetDirect_1(bevd_0);
case 909428606: return bem_otherClass_1(bevd_0);
case 1805655428: return bem_vvSet_1(bevd_0);
case 1528010380: return bem_sameClass_1(bevd_0);
case -1619363964: return bem_klassNameSet_1(bevd_0);
case -422515563: return bem_emitLangSetDirect_1(bevd_0);
case -787993115: return bem_fileNameSetDirect_1(bevd_0);
case -87514762: return bem_lineNumberSetDirect_1(bevd_0);
case -630448500: return bem_fileNameSet_1(bevd_0);
case -753791146: return bem_vvSetDirect_1(bevd_0);
case -1606202955: return bem_copyTo_1(bevd_0);
case 938863663: return bem_def_1(bevd_0);
case -1740780605: return bem_framesTextSet_1(bevd_0);
case -1108730664: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1998996953: return bem_methodNameSet_1(bevd_0);
case -209196700: return bem_translatedSetDirect_1(bevd_0);
case 541805438: return bem_methodNameSetDirect_1(bevd_0);
case -575460023: return bem_sameType_1(bevd_0);
case -336338528: return bem_langSetDirect_1(bevd_0);
case -1680828786: return bem_framesSetDirect_1(bevd_0);
case 1859153072: return bem_undef_1(bevd_0);
case 1342151407: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -746609219: return bem_sameObject_1(bevd_0);
case -1768944168: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1709373754: return bem_emitLangSet_1(bevd_0);
case -835119407: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 506082618: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1582482490: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1978405023: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953140974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1983033893: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 57365655: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_13_SystemIncorrectType_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_13_SystemIncorrectType_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_13_SystemIncorrectType();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst = (BEC_2_6_13_SystemIncorrectType) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_type;
}
}
