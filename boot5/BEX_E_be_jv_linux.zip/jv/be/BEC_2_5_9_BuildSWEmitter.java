package be;
/* IO:File: source/build/SWEmitter.be */
public final class BEC_2_5_9_BuildSWEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildSWEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildSWEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x53,0x57,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildSWEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x57,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_0 = {0x73,0x77};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_1 = {0x2E,0x73,0x77,0x69,0x66,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_3 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_4 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_5 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_6 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_8 = {0x2F,0x2A,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_9 = {0x20,0x2A,0x2F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_10 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_11 = {0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_12 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_12, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_13 = {0x5F,0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_13, 6));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_14 = {};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_15 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_16 = {0x3A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_17 = {0x3F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_18 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_18, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_19 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_19, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_20 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_21 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_22 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_22, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_23 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_24 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_24, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_25 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_25, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_26 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_26, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_27 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_28 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_29 = {0x3A,0x5B,0x55,0x49,0x6E,0x74,0x38,0x5D,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_30, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_31 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_31, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_32 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_32, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_33 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_34 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_35 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_36 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_37 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_38 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_39 = {0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_40 = {0x20,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_41 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_42 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_43 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_44 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_45 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_46 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_47 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_48 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_49 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_50 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_51 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_52 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_53 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_54 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_55 = {0x20,0x2D,0x3E,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_56 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_57 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_58 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_59 = {0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_60 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_61 = {0x20,0x2D,0x3E,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_62 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_63 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_64 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_65 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_66 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_66, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_67 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_67, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_68 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_68, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_69 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_70 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_70, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_71 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_72 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_73 = {0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_73, 28));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_74 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_74, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_75 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_76 = {0x66,0x75,0x6E,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_77 = {0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x75,0x6E,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_78 = {};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_79 = {0x20,0x61,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_79, 4));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_80 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_81 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_82 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_83 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_84 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_85 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_85, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_86 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_86, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_87 = {0x3F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_87, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_88 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_88, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_89 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_89, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_90 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_90, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_91 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_91, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_92 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_92, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_93 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_93, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_94 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_94, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_95 = {0x6D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_95, 19));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_96 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_96, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_97 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_98 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_99 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_100 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_101 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_102 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_102, 3));
public static BEC_2_5_9_BuildSWEmitter bece_BEC_2_5_9_BuildSWEmitter_bevs_inst;

public static BET_2_5_9_BuildSWEmitter bece_BEC_2_5_9_BuildSWEmitter_bevs_type;

public BEC_2_5_9_BuildSWEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildSWEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildSWEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildSWEmitter_bels_4));
return this;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_5));
bevt_2_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildSWEmitter_bels_6));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_clb = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 36 */
 else  /* Line: 37 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildSWEmitter_bels_7));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 38 */
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildSWEmitter_bels_8));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_inFilePathed);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_9));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevl_clb = bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = beva_csyn.bem_isFinalGet_0();
bevt_12_tmpany_phold = bem_klassDec_1(bevt_13_tmpany_phold);
bevt_11_tmpany_phold = bevl_clb.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_10));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildSWEmitter_bels_11));
bevt_16_tmpany_phold = bevl_clb.bem_addValue_1(bevt_17_tmpany_phold);
bevt_16_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_clb;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_0;
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildSWEmitter_bels_14));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
if (!(beva_isArg.bevi_bool)) /* Line: 55 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_15));
beva_b.bem_addValue_1(bevt_0_tmpany_phold);
} /* Line: 56 */
bevt_1_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_16));
beva_b.bem_addValue_1(bevt_2_tmpany_phold);
bem_typeDecForVar_2(beva_b, beva_v);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_17));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bevp_csyn.bem_namepathGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_equals_1(bevp_objectNp);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 68 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_2;
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_3;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_4_tmpany_phold = bem_baseSpropDec_2(bevt_5_tmpany_phold, bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_4_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_20));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 69 */
 else  /* Line: 70 */ {
bevt_15_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_4;
bevt_19_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_5;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_14_tmpany_phold = bem_overrideSpropDec_2(bevt_15_tmpany_phold, bevt_16_tmpany_phold);
bevt_13_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_14_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_23));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 71 */
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_6;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_newcc.bem_emitNameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_8;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildSWEmitter_bels_27));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_28));
bevt_1_tmpany_phold = beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildSWEmitter_bels_29));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_9;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_anyName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_10;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
bevt_6_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_5_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildSWEmitter_bels_33));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_34));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_11_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_relEmitName_1(bevt_11_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_35));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_36));
bevt_15_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_16_tmpany_phold);
bevt_20_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(657081007);
bevt_18_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_19_tmpany_phold );
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_37));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_38));
bevt_23_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_24_tmpany_phold);
bevt_23_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_4_6_TextString bevl_tname = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_vcast = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_0_tmpany_phold.bem_relEmitName_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevl_tname = bevt_2_tmpany_phold.bem_typeEmitNameGet_0();
bevl_mname = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(657081007);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_11_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_10_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(27, bece_BEC_2_5_9_BuildSWEmitter_bels_39));
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_40));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_41));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = bevl_mname.bem_notEquals_1(bevl_oname);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_42));
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_43));
bevl_vcast = bem_formCast_3(bevp_classConf, bevt_16_tmpany_phold, bevt_17_tmpany_phold);
} /* Line: 110 */
 else  /* Line: 111 */ {
bevl_vcast = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_44));
} /* Line: 112 */
bevt_21_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_45));
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_addValue_1(bevl_vcast);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_46));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevt_23_tmpany_phold);
bevt_18_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_47));
bevt_24_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_25_tmpany_phold);
bevt_24_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_32_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_31_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildSWEmitter_bels_48));
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_addValue_1(bevt_33_tmpany_phold);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_49));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_50));
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_51));
bevt_38_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_39_tmpany_phold);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_52));
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_36_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_53));
bevt_41_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_42_tmpany_phold);
bevt_41_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_47_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_46_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_47_tmpany_phold);
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildSWEmitter_bels_54));
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_addValue_1(bevt_48_tmpany_phold);
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildSWEmitter_bels_55));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_addValue_1(bevt_49_tmpany_phold);
bevt_43_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_56));
bevt_52_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_53_tmpany_phold);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_54_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_57));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_58));
bevt_55_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_56_tmpany_phold);
bevt_55_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_6_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_5_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_59));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_60));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildSWEmitter_bels_61));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildSWEmitter_bels_62));
bevt_14_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_addValue_1(beva_len);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_63));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_64));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_10_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_65));
bevt_18_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_18_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_12;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_anyName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_13;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_14;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_69));
bevt_0_tmpany_phold = beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_71));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_72));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(152774500);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1189786665);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_75));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_76));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildSWEmitter_bels_77));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_newDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildSWEmitter_bels_78));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_18;
bevt_3_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_2_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_3(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type, BEC_2_4_6_TextString beva_targ) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCast_2(beva_cc, beva_type);
bevt_0_tmpany_phold = beva_targ.bem_add_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_80));
bevt_0_tmpany_phold.bem_addValue_1(bevt_2_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_81));
bevt_7_tmpany_phold = bevp_methods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_82));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_10_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_11_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_83));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_84));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_19;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_anyName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_21;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 209 */ {
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 210 */
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_25;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_lisz);
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_26;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(beva_belsName);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_27;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_28;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_29;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_30;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildSWEmitter_bels_97));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_98));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_99));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildSWEmitter_bels_100));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-223555590);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_101));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_31;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 19, 20, 24, 26, 27, 31, 31, 31, 31, 31, 31, 31, 31, 35, 35, 36, 36, 36, 38, 38, 40, 40, 40, 40, 40, 41, 41, 41, 41, 41, 41, 41, 41, 41, 42, 42, 42, 43, 47, 47, 47, 47, 47, 47, 47, 51, 51, 56, 56, 58, 58, 59, 59, 60, 61, 61, 66, 68, 68, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 74, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 82, 82, 86, 86, 86, 86, 86, 90, 90, 90, 90, 90, 90, 90, 90, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 97, 97, 97, 101, 101, 101, 102, 102, 103, 104, 104, 104, 105, 107, 107, 107, 107, 107, 107, 107, 107, 107, 107, 107, 109, 110, 110, 110, 112, 115, 115, 115, 115, 115, 115, 115, 117, 117, 117, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 122, 122, 122, 122, 122, 122, 124, 124, 124, 126, 128, 128, 128, 128, 128, 128, 128, 128, 130, 130, 130, 130, 130, 130, 132, 132, 132, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 143, 143, 143, 143, 143, 143, 143, 143, 143, 145, 145, 145, 149, 149, 149, 149, 149, 149, 149, 149, 154, 154, 154, 158, 158, 158, 159, 160, 160, 160, 160, 160, 160, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 167, 167, 171, 171, 175, 175, 179, 179, 183, 183, 183, 183, 183, 187, 187, 187, 192, 192, 192, 192, 194, 196, 196, 196, 196, 196, 196, 196, 196, 196, 196, 196, 201, 201, 205, 205, 205, 205, 205, 205, 205, 205, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 212, 212, 212, 212, 212, 212, 212, 212, 212, 212, 212, 217, 218, 219, 219, 219, 220, 225, 225, 225, 225, 225, 226, 226, 226, 226, 226, 226, 227, 227, 227, 228, 228, 228, 228, 228, 228, 228, 228, 229, 233, 233, 233, 233};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {147, 148, 149, 150, 151, 152, 163, 164, 165, 166, 167, 168, 169, 170, 194, 199, 200, 201, 202, 205, 206, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 234, 235, 236, 237, 238, 239, 240, 244, 245, 253, 254, 256, 257, 258, 259, 260, 261, 262, 289, 290, 291, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 318, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 345, 346, 353, 354, 355, 356, 357, 368, 369, 370, 371, 372, 373, 374, 375, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 521, 522, 523, 526, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 632, 633, 634, 635, 636, 637, 638, 639, 644, 645, 646, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 691, 692, 696, 697, 701, 702, 706, 707, 714, 715, 716, 717, 718, 723, 724, 725, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 761, 762, 772, 773, 774, 775, 776, 777, 778, 779, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 831, 832, 833, 834, 835, 836, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 887, 888, 889, 890};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 147
new 0 18 147
assign 1 19 148
new 0 19 148
assign 1 20 149
new 0 20 149
new 1 24 150
assign 1 26 151
new 0 26 151
assign 1 27 152
new 0 27 152
assign 1 31 163
new 0 31 163
assign 1 31 164
addValue 1 31 164
assign 1 31 165
secondGet 0 31 165
assign 1 31 166
formTarg 1 31 166
assign 1 31 167
addValue 1 31 167
assign 1 31 168
new 0 31 168
assign 1 31 169
addValue 1 31 169
addValue 1 31 170
assign 1 35 194
def 1 35 199
assign 1 36 200
libNameGet 0 36 200
assign 1 36 201
relEmitName 1 36 201
assign 1 36 202
extend 1 36 202
assign 1 38 205
new 0 38 205
assign 1 38 206
extend 1 38 206
assign 1 40 208
new 0 40 208
assign 1 40 209
addValue 1 40 209
assign 1 40 210
new 0 40 210
assign 1 40 211
addValue 1 40 211
assign 1 40 212
addValue 1 40 212
assign 1 41 213
isFinalGet 0 41 213
assign 1 41 214
klassDec 1 41 214
assign 1 41 215
addValue 1 41 215
assign 1 41 216
emitNameGet 0 41 216
assign 1 41 217
addValue 1 41 217
assign 1 41 218
addValue 1 41 218
assign 1 41 219
new 0 41 219
assign 1 41 220
addValue 1 41 220
addValue 1 41 221
assign 1 42 222
new 0 42 222
assign 1 42 223
addValue 1 42 223
addValue 1 42 224
return 1 43 225
assign 1 47 234
new 0 47 234
assign 1 47 235
emitNameGet 0 47 235
assign 1 47 236
add 1 47 236
assign 1 47 237
new 0 47 237
assign 1 47 238
add 1 47 238
assign 1 47 239
add 1 47 239
return 1 47 240
assign 1 51 244
new 0 51 244
return 1 51 245
assign 1 56 253
new 0 56 253
addValue 1 56 254
assign 1 58 256
nameForVar 1 58 256
addValue 1 58 257
assign 1 59 258
new 0 59 258
addValue 1 59 259
typeDecForVar 2 60 260
assign 1 61 261
new 0 61 261
addValue 1 61 262
assign 1 66 289
new 0 66 289
assign 1 68 290
namepathGet 0 68 290
assign 1 68 291
equals 1 68 291
assign 1 69 293
emitNameGet 0 69 293
assign 1 69 294
new 0 69 294
assign 1 69 295
emitNameGet 0 69 295
assign 1 69 296
add 1 69 296
assign 1 69 297
new 0 69 297
assign 1 69 298
add 1 69 298
assign 1 69 299
baseSpropDec 2 69 299
assign 1 69 300
addValue 1 69 300
assign 1 69 301
new 0 69 301
assign 1 69 302
addValue 1 69 302
addValue 1 69 303
assign 1 71 306
emitNameGet 0 71 306
assign 1 71 307
new 0 71 307
assign 1 71 308
emitNameGet 0 71 308
assign 1 71 309
add 1 71 309
assign 1 71 310
new 0 71 310
assign 1 71 311
add 1 71 311
assign 1 71 312
overrideSpropDec 2 71 312
assign 1 71 313
addValue 1 71 313
assign 1 71 314
new 0 71 314
assign 1 71 315
addValue 1 71 315
addValue 1 71 316
return 1 74 318
assign 1 78 331
libNameGet 0 78 331
assign 1 78 332
relEmitName 1 78 332
assign 1 78 333
new 0 78 333
assign 1 78 334
add 1 78 334
assign 1 78 335
new 0 78 335
assign 1 78 336
add 1 78 336
assign 1 78 337
emitNameGet 0 78 337
assign 1 78 338
add 1 78 338
assign 1 78 339
new 0 78 339
assign 1 78 340
add 1 78 340
return 1 78 341
assign 1 82 345
new 0 82 345
return 1 82 346
assign 1 86 353
new 0 86 353
assign 1 86 354
addValue 1 86 354
assign 1 86 355
addValue 1 86 355
assign 1 86 356
new 0 86 356
addValue 1 86 357
assign 1 90 368
new 0 90 368
assign 1 90 369
add 1 90 369
assign 1 90 370
new 0 90 370
assign 1 90 371
add 1 90 371
assign 1 90 372
add 1 90 372
assign 1 90 373
new 0 90 373
assign 1 90 374
add 1 90 374
return 1 90 375
assign 1 94 403
overrideMtdDecGet 0 94 403
assign 1 94 404
addValue 1 94 404
assign 1 94 405
new 0 94 405
assign 1 94 406
addValue 1 94 406
assign 1 94 407
addValue 1 94 407
assign 1 94 408
new 0 94 408
assign 1 94 409
addValue 1 94 409
assign 1 94 410
getClassConfig 1 94 410
assign 1 94 411
libNameGet 0 94 411
assign 1 94 412
relEmitName 1 94 412
assign 1 94 413
addValue 1 94 413
assign 1 94 414
new 0 94 414
assign 1 94 415
addValue 1 94 415
addValue 1 94 416
assign 1 95 417
new 0 95 417
assign 1 95 418
addValue 1 95 418
assign 1 95 419
heldGet 0 95 419
assign 1 95 420
namepathGet 0 95 420
assign 1 95 421
getClassConfig 1 95 421
assign 1 95 422
libNameGet 0 95 422
assign 1 95 423
relEmitName 1 95 423
assign 1 95 424
addValue 1 95 424
assign 1 95 425
new 0 95 425
assign 1 95 426
addValue 1 95 426
addValue 1 95 427
assign 1 97 428
new 0 97 428
assign 1 97 429
addValue 1 97 429
addValue 1 97 430
assign 1 101 498
getClassConfig 1 101 498
assign 1 101 499
libNameGet 0 101 499
assign 1 101 500
relEmitName 1 101 500
assign 1 102 501
getClassConfig 1 102 501
assign 1 102 502
typeEmitNameGet 0 102 502
assign 1 103 503
emitNameGet 0 103 503
assign 1 104 504
heldGet 0 104 504
assign 1 104 505
namepathGet 0 104 505
assign 1 104 506
getClassConfig 1 104 506
assign 1 105 507
getInitialInst 1 105 507
assign 1 107 508
overrideMtdDecGet 0 107 508
assign 1 107 509
addValue 1 107 509
assign 1 107 510
new 0 107 510
assign 1 107 511
addValue 1 107 511
assign 1 107 512
addValue 1 107 512
assign 1 107 513
new 0 107 513
assign 1 107 514
addValue 1 107 514
assign 1 107 515
addValue 1 107 515
assign 1 107 516
new 0 107 516
assign 1 107 517
addValue 1 107 517
addValue 1 107 518
assign 1 109 519
notEquals 1 109 519
assign 1 110 521
new 0 110 521
assign 1 110 522
new 0 110 522
assign 1 110 523
formCast 3 110 523
assign 1 112 526
new 0 112 526
assign 1 115 528
addValue 1 115 528
assign 1 115 529
new 0 115 529
assign 1 115 530
addValue 1 115 530
assign 1 115 531
addValue 1 115 531
assign 1 115 532
new 0 115 532
assign 1 115 533
addValue 1 115 533
addValue 1 115 534
assign 1 117 535
new 0 117 535
assign 1 117 536
addValue 1 117 536
addValue 1 117 537
assign 1 120 538
overrideMtdDecGet 0 120 538
assign 1 120 539
addValue 1 120 539
assign 1 120 540
new 0 120 540
assign 1 120 541
addValue 1 120 541
assign 1 120 542
addValue 1 120 542
assign 1 120 543
new 0 120 543
assign 1 120 544
addValue 1 120 544
assign 1 120 545
addValue 1 120 545
assign 1 120 546
new 0 120 546
assign 1 120 547
addValue 1 120 547
addValue 1 120 548
assign 1 122 549
new 0 122 549
assign 1 122 550
addValue 1 122 550
assign 1 122 551
addValue 1 122 551
assign 1 122 552
new 0 122 552
assign 1 122 553
addValue 1 122 553
addValue 1 122 554
assign 1 124 555
new 0 124 555
assign 1 124 556
addValue 1 124 556
addValue 1 124 557
assign 1 126 558
getTypeInst 1 126 558
assign 1 128 559
overrideMtdDecGet 0 128 559
assign 1 128 560
addValue 1 128 560
assign 1 128 561
new 0 128 561
assign 1 128 562
addValue 1 128 562
assign 1 128 563
addValue 1 128 563
assign 1 128 564
new 0 128 564
assign 1 128 565
addValue 1 128 565
addValue 1 128 566
assign 1 130 567
new 0 130 567
assign 1 130 568
addValue 1 130 568
assign 1 130 569
addValue 1 130 569
assign 1 130 570
new 0 130 570
assign 1 130 571
addValue 1 130 571
addValue 1 130 572
assign 1 132 573
new 0 132 573
assign 1 132 574
addValue 1 132 574
addValue 1 132 575
assign 1 142 599
overrideMtdDecGet 0 142 599
assign 1 142 600
addValue 1 142 600
assign 1 142 601
new 0 142 601
assign 1 142 602
addValue 1 142 602
assign 1 142 603
addValue 1 142 603
assign 1 142 604
new 0 142 604
assign 1 142 605
addValue 1 142 605
assign 1 142 606
addValue 1 142 606
assign 1 142 607
new 0 142 607
assign 1 142 608
addValue 1 142 608
addValue 1 142 609
assign 1 143 610
new 0 143 610
assign 1 143 611
addValue 1 143 611
assign 1 143 612
addValue 1 143 612
assign 1 143 613
new 0 143 613
assign 1 143 614
addValue 1 143 614
assign 1 143 615
addValue 1 143 615
assign 1 143 616
new 0 143 616
assign 1 143 617
addValue 1 143 617
addValue 1 143 618
assign 1 145 619
new 0 145 619
assign 1 145 620
addValue 1 145 620
addValue 1 145 621
assign 1 149 632
new 0 149 632
assign 1 149 633
add 1 149 633
assign 1 149 634
new 0 149 634
assign 1 149 635
add 1 149 635
assign 1 149 636
add 1 149 636
assign 1 149 637
new 0 149 637
assign 1 149 638
add 1 149 638
return 1 149 639
assign 1 154 644
new 0 154 644
assign 1 154 645
addValue 1 154 645
addValue 1 154 646
assign 1 158 667
new 0 158 667
assign 1 158 668
toString 0 158 668
assign 1 158 669
add 1 158 669
incrementValue 0 159 670
assign 1 160 671
new 0 160 671
assign 1 160 672
addValue 1 160 672
assign 1 160 673
addValue 1 160 673
assign 1 160 674
new 0 160 674
assign 1 160 675
addValue 1 160 675
addValue 1 160 676
assign 1 162 677
containedGet 0 162 677
assign 1 162 678
firstGet 0 162 678
assign 1 162 679
containedGet 0 162 679
assign 1 162 680
firstGet 0 162 680
assign 1 162 681
new 0 162 681
assign 1 162 682
add 1 162 682
assign 1 162 683
new 0 162 683
assign 1 162 684
add 1 162 684
assign 1 162 685
finalAssign 4 162 685
addValue 1 162 686
assign 1 167 691
new 0 167 691
return 1 167 692
assign 1 171 696
new 0 171 696
return 1 171 697
assign 1 175 701
new 0 175 701
return 1 175 702
assign 1 179 706
new 0 179 706
return 1 179 707
assign 1 183 714
new 0 183 714
assign 1 183 715
libNameGet 0 183 715
assign 1 183 716
relEmitName 1 183 716
assign 1 183 717
add 1 183 717
return 1 183 718
assign 1 187 723
formCast 2 187 723
assign 1 187 724
add 1 187 724
return 1 187 725
assign 1 192 741
addValue 1 192 741
assign 1 192 742
addValue 1 192 742
assign 1 192 743
new 0 192 743
addValue 1 192 744
addValue 1 194 745
assign 1 196 746
new 0 196 746
assign 1 196 747
addValue 1 196 747
assign 1 196 748
addValue 1 196 748
assign 1 196 749
new 0 196 749
assign 1 196 750
addValue 1 196 750
assign 1 196 751
libNameGet 0 196 751
assign 1 196 752
relEmitName 1 196 752
assign 1 196 753
addValue 1 196 753
assign 1 196 754
new 0 196 754
assign 1 196 755
addValue 1 196 755
addValue 1 196 756
assign 1 201 761
new 0 201 761
return 1 201 762
assign 1 205 772
new 0 205 772
assign 1 205 773
add 1 205 773
assign 1 205 774
new 0 205 774
assign 1 205 775
add 1 205 775
assign 1 205 776
add 1 205 776
assign 1 205 777
new 0 205 777
assign 1 205 778
add 1 205 778
return 1 205 779
assign 1 210 803
libNameGet 0 210 803
assign 1 210 804
relEmitName 1 210 804
assign 1 210 805
new 0 210 805
assign 1 210 806
add 1 210 806
assign 1 210 807
add 1 210 807
assign 1 210 808
new 0 210 808
assign 1 210 809
add 1 210 809
assign 1 210 810
add 1 210 810
assign 1 210 811
new 0 210 811
assign 1 210 812
add 1 210 812
return 1 210 813
assign 1 212 815
libNameGet 0 212 815
assign 1 212 816
relEmitName 1 212 816
assign 1 212 817
new 0 212 817
assign 1 212 818
add 1 212 818
assign 1 212 819
add 1 212 819
assign 1 212 820
new 0 212 820
assign 1 212 821
add 1 212 821
assign 1 212 822
add 1 212 822
assign 1 212 823
new 0 212 823
assign 1 212 824
add 1 212 824
return 1 212 825
getCode 2 217 831
assign 1 218 832
toHexString 1 218 832
assign 1 219 833
new 0 219 833
assign 1 219 834
once 0 219 834
addValue 1 219 835
addValue 1 220 836
assign 1 225 859
new 0 225 859
assign 1 225 860
add 1 225 860
assign 1 225 861
new 0 225 861
assign 1 225 862
add 1 225 862
assign 1 225 863
add 1 225 863
assign 1 226 864
new 0 226 864
assign 1 226 865
addValue 1 226 865
assign 1 226 866
addValue 1 226 866
assign 1 226 867
new 0 226 867
assign 1 226 868
addValue 1 226 868
addValue 1 226 869
assign 1 227 870
new 0 227 870
assign 1 227 871
addValue 1 227 871
addValue 1 227 872
assign 1 228 873
new 0 228 873
assign 1 228 874
addValue 1 228 874
assign 1 228 875
outputPlatformGet 0 228 875
assign 1 228 876
nameGet 0 228 876
assign 1 228 877
addValue 1 228 877
assign 1 228 878
new 0 228 878
assign 1 228 879
addValue 1 228 879
addValue 1 228 880
return 1 229 881
assign 1 233 887
new 0 233 887
assign 1 233 888
once 0 233 888
assign 1 233 889
add 1 233 889
return 1 233 890
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 904098359: return bem_exceptDecGetDirect_0();
case 951880127: return bem_maxDynArgsGet_0();
case -10557012: return bem_objectCcGet_0();
case -1996890191: return bem_doEmit_0();
case -1916918185: return bem_stringNpGetDirect_0();
case -927688222: return bem_boolTypeGet_0();
case 900515287: return bem_idToNamePathGet_0();
case 774165989: return bem_nlGet_0();
case 1384498222: return bem_libEmitPathGetDirect_0();
case -1400770094: return bem_many_0();
case 1349866592: return bem_toString_0();
case -1860156019: return bem_nameToIdPathGetDirect_0();
case 433902202: return bem_inFilePathedGet_0();
case -1150150083: return bem_saveIds_0();
case -2019854520: return bem_mnodeGetDirect_0();
case -512236724: return bem_deserializeClassNameGet_0();
case 1538042429: return bem_lastMethodsSizeGetDirect_0();
case -1582607053: return bem_csynGet_0();
case -197605295: return bem_baseSmtdDecGet_0();
case -1785127862: return bem_dynMethodsGet_0();
case -923057320: return bem_serializationIteratorGet_0();
case 14862859: return bem_smnlcsGetDirect_0();
case 1756265821: return bem_superCallsGetDirect_0();
case -1228375161: return bem_inClassGetDirect_0();
case -560712952: return bem_onceCountGetDirect_0();
case 13807179: return bem_hashGet_0();
case -1189362761: return bem_returnTypeGet_0();
case 181172395: return bem_methodCatchGetDirect_0();
case -840639254: return bem_methodBodyGet_0();
case -1415105850: return bem_dynMethodsGetDirect_0();
case 425899322: return bem_mnodeGet_0();
case 1255831246: return bem_msynGet_0();
case 1110391771: return bem_nlGetDirect_0();
case -806692689: return bem_floatNpGet_0();
case -391835447: return bem_cnodeGet_0();
case 491606151: return bem_onceDecsGet_0();
case 1706380594: return bem_csynGetDirect_0();
case 740114807: return bem_classesInDepthOrderGet_0();
case 1282735229: return bem_nameToIdPathGet_0();
case -298538185: return bem_lineCountGet_0();
case 2142502016: return bem_constGetDirect_0();
case -782294349: return bem_objectCcGetDirect_0();
case 940109770: return bem_smnlcsGet_0();
case -396558779: return bem_lineCountGetDirect_0();
case -241435004: return bem_inFilePathedGetDirect_0();
case 1445872969: return bem_transGetDirect_0();
case 1799150864: return bem_classEndGet_0();
case -948863498: return bem_qGet_0();
case -1272095381: return bem_parentConfGet_0();
case 1267620781: return bem_loadIds_0();
case 915079544: return bem_trueValueGetDirect_0();
case -63497197: return bem_parentConfGetDirect_0();
case 1139264885: return bem_scvpGetDirect_0();
case -1102551550: return bem_classCallsGet_0();
case 1070455145: return bem_initialDecGet_0();
case -924194557: return bem_mainInClassGet_0();
case -1473654348: return bem_ccCacheGetDirect_0();
case -78611717: return bem_qGetDirect_0();
case -965215173: return bem_msynGetDirect_0();
case -518710385: return bem_fieldNamesGet_0();
case -2121830718: return bem_instOfGet_0();
case -2098441127: return bem_baseMtdDecGet_0();
case 2132329886: return bem_smnlecsGetDirect_0();
case 263323309: return bem_classEmitsGetDirect_0();
case -884820945: return bem_methodCatchGet_0();
case -887462544: return bem_methodCallsGet_0();
case 1421232299: return bem_libEmitNameGetDirect_0();
case 1872072505: return bem_lastMethodsSizeGet_0();
case -380976808: return bem_returnTypeGetDirect_0();
case -1345902280: return bem_fullLibEmitNameGetDirect_0();
case -962115471: return bem_runtimeInitGet_0();
case 938248842: return bem_fullLibEmitNameGet_0();
case -1638642456: return bem_invpGetDirect_0();
case -103115082: return bem_saveSyns_0();
case -663638612: return bem_buildGetDirect_0();
case 1279377604: return bem_endNs_0();
case 1660113079: return bem_classConfGetDirect_0();
case -914347833: return bem_new_0();
case 1432885778: return bem_superCallsGet_0();
case 1975762696: return bem_overrideMtdDecGet_0();
case 1364662558: return bem_mainStartGet_0();
case -1412750866: return bem_nameToIdGet_0();
case 2118554369: return bem_methodBodyGetDirect_0();
case 1468640431: return bem_constGet_0();
case 20642314: return bem_ntypesGetDirect_0();
case 2073589382: return bem_maxSpillArgsLenGet_0();
case -2033802824: return bem_methodCallsGetDirect_0();
case -1611877854: return bem_inClassGet_0();
case -1505729203: return bem_callNamesGetDirect_0();
case -2035208893: return bem_echo_0();
case -784012026: return bem_nativeCSlotsGetDirect_0();
case -1156014135: return bem_ccCacheGet_0();
case 896768623: return bem_lastMethodsLinesGetDirect_0();
case -1648095457: return bem_falseValueGetDirect_0();
case -610725550: return bem_onceDecsGetDirect_0();
case 1421620452: return bem_classesInDepthOrderGetDirect_0();
case 141993206: return bem_classConfGet_0();
case -35248652: return bem_toAny_0();
case 294217345: return bem_emitLib_0();
case -355280605: return bem_useDynMethodsGet_0();
case -162534812: return bem_instanceNotEqualGet_0();
case -1893180608: return bem_lastMethodBodyLinesGetDirect_0();
case -1423578661: return bem_print_0();
case 1381691626: return bem_onceCountGet_0();
case 572263777: return bem_newDecGet_0();
case -1670065093: return bem_classEmitsGet_0();
case -1554579341: return bem_lastMethodBodyLinesGet_0();
case -452883670: return bem_intNpGet_0();
case 1600703273: return bem_maxSpillArgsLenGetDirect_0();
case -1924959573: return bem_trueValueGet_0();
case -1419568616: return bem_classCallsGetDirect_0();
case -637396584: return bem_preClassGetDirect_0();
case 590082463: return bem_fileExtGet_0();
case 1282629484: return bem_fileExtGetDirect_0();
case 1023490356: return bem_afterCast_0();
case -641034494: return bem_boolNpGet_0();
case 237522501: return bem_ccMethodsGetDirect_0();
case -616445294: return bem_nativeCSlotsGet_0();
case 675566088: return bem_classNameGet_0();
case -458575187: return bem_covariantReturnsGet_0();
case -756545341: return bem_preClassOutput_0();
case -791760369: return bem_preClassGet_0();
case 693563076: return bem_nameToIdGetDirect_0();
case 1777898358: return bem_lastCallGetDirect_0();
case 646589914: return bem_sourceFileNameGet_0();
case 1897478688: return bem_libEmitNameGet_0();
case -321348318: return bem_objectNpGetDirect_0();
case 338370901: return bem_idToNameGet_0();
case 654255123: return bem_instanceEqualGet_0();
case -224516420: return bem_lastMethodsLinesGet_0();
case 1720257205: return bem_boolCcGet_0();
case 1390864752: return bem_randGet_0();
case -367040643: return bem_idToNameGetDirect_0();
case -770183546: return bem_idToNamePathGetDirect_0();
case -1248529827: return bem_nullValueGet_0();
case -1287196600: return bem_instanceEqualGetDirect_0();
case -1589888476: return bem_propDecGet_0();
case 968129667: return bem_ntypesGet_0();
case 1516441490: return bem_propertyDecsGetDirect_0();
case -655317167: return bem_methodsGetDirect_0();
case 1468981912: return bem_scvpGet_0();
case -1868585484: return bem_mainOutsideNsGet_0();
case 518862870: return bem_tagGet_0();
case -173700588: return bem_emitLangGetDirect_0();
case -745156484: return bem_intNpGetDirect_0();
case 981237603: return bem_instanceNotEqualGetDirect_0();
case -1642750174: return bem_nullValueGetDirect_0();
case 1052263558: return bem_serializeToString_0();
case 2039563584: return bem_gcMarksGetDirect_0();
case -2091241279: return bem_create_0();
case 1986889638: return bem_beginNs_0();
case 574364616: return bem_stringNpGet_0();
case -1898755129: return bem_buildInitial_0();
case 460566422: return bem_callNamesGet_0();
case -1995114746: return bem_smnlecsGet_0();
case 282642681: return bem_maxDynArgsGetDirect_0();
case -821556420: return bem_synEmitPathGetDirect_0();
case 1494772401: return bem_getLibOutput_0();
case 1299948053: return bem_serializeContents_0();
case 1634116989: return bem_spropDecGet_0();
case 560285543: return bem_invpGet_0();
case 565230916: return bem_emitLangGet_0();
case 2111093216: return bem_lastMethodBodySizeGet_0();
case 1957608515: return bem_fieldIteratorGet_0();
case 758802515: return bem_once_0();
case -538433353: return bem_exceptDecGet_0();
case 7826052: return bem_buildCreate_0();
case -1076044322: return bem_randGetDirect_0();
case -497073434: return bem_mainEndGet_0();
case -659630913: return bem_cnodeGetDirect_0();
case 1278992119: return bem_writeBET_0();
case -1644401952: return bem_lastMethodBodySizeGetDirect_0();
case -1538367452: return bem_buildClassInfo_0();
case -1675861833: return bem_libEmitPathGet_0();
case 1698901126: return bem_falseValueGet_0();
case 423940839: return bem_floatNpGetDirect_0();
case -245363326: return bem_copy_0();
case 1431618231: return bem_instOfGetDirect_0();
case -549379925: return bem_synEmitPathGet_0();
case 1243168774: return bem_typeDecGet_0();
case 1155045196: return bem_boolCcGetDirect_0();
case -296507733: return bem_buildGet_0();
case 57805369: return bem_objectNpGet_0();
case -848729554: return bem_lastCallGet_0();
case -39063961: return bem_methodsGet_0();
case -1965996428: return bem_ccMethodsGet_0();
case -1649830716: return bem_propertyDecsGet_0();
case 1652871134: return bem_transGet_0();
case 993759307: return bem_iteratorGet_0();
case -599284105: return bem_superNameGet_0();
case -338848394: return bem_boolNpGetDirect_0();
case 1390047216: return bem_getClassOutput_0();
case -1746121542: return bem_gcMarksGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 633698095: return bem_lineCountSet_1(bevd_0);
case -413042493: return bem_falseValueSetDirect_1(bevd_0);
case 1565144389: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 618622735: return bem_gcMarksSetDirect_1(bevd_0);
case 1295388294: return bem_onceCountSet_1(bevd_0);
case -1240501020: return bem_dynMethodsSetDirect_1(bevd_0);
case 1220718207: return bem_propertyDecsSetDirect_1(bevd_0);
case 2110429003: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case -1079670432: return bem_returnTypeSetDirect_1(bevd_0);
case 1327927977: return bem_lastMethodBodySizeSet_1(bevd_0);
case -303960361: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -657201864: return bem_classEmitsSet_1(bevd_0);
case -407823426: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -802598951: return bem_boolNpSetDirect_1(bevd_0);
case -1322656123: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1527556781: return bem_methodBodySet_1(bevd_0);
case 912528616: return bem_parentConfSet_1(bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case 725458432: return bem_classEmitsSetDirect_1(bevd_0);
case -952233414: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -245305929: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -875705285: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1569640908: return bem_idToNamePathSetDirect_1(bevd_0);
case 1447785920: return bem_methodCatchSetDirect_1(bevd_0);
case -1093177295: return bem_superCallsSetDirect_1(bevd_0);
case -574437726: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 966426209: return bem_callNamesSetDirect_1(bevd_0);
case -191891404: return bem_idToNamePathSet_1(bevd_0);
case -798718302: return bem_buildSetDirect_1(bevd_0);
case 832019084: return bem_nullValueSetDirect_1(bevd_0);
case -1426052384: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1707409230: return bem_instanceEqualSet_1(bevd_0);
case 1839218015: return bem_invpSetDirect_1(bevd_0);
case 293826090: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1071267891: return bem_methodCatchSet_1(bevd_0);
case -1243566542: return bem_classesInDepthOrderSet_1(bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case -1710981437: return bem_mnodeSetDirect_1(bevd_0);
case -565899169: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1226495638: return bem_nlSetDirect_1(bevd_0);
case 2135069829: return bem_constSetDirect_1(bevd_0);
case 513180149: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 1538665222: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 2096988064: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1844529958: return bem_lastCallSet_1(bevd_0);
case 507772367: return bem_superCallsSet_1(bevd_0);
case -1620598029: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1219021982: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1545433858: return bem_synEmitPathSet_1(bevd_0);
case 1349334101: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1832305663: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1876036738: return bem_maxSpillArgsLenSet_1(bevd_0);
case 809690823: return bem_ccMethodsSetDirect_1(bevd_0);
case -1509502775: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -896489358: return bem_exceptDecSet_1(bevd_0);
case 1367898560: return bem_objectCcSetDirect_1(bevd_0);
case 1849207161: return bem_randSetDirect_1(bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -537932837: return bem_equals_1(bevd_0);
case 2088054606: return bem_floatNpSetDirect_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case -1906763198: return bem_smnlcsSetDirect_1(bevd_0);
case -1011537466: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1026366597: return bem_classCallsSet_1(bevd_0);
case -1950817258: return bem_objectCcSet_1(bevd_0);
case 972916849: return bem_cnodeSetDirect_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -1589743904: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 801468889: return bem_stringNpSetDirect_1(bevd_0);
case -1427763618: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2106289676: return bem_falseValueSet_1(bevd_0);
case -655865586: return bem_callNamesSet_1(bevd_0);
case -675026406: return bem_onceDecsSetDirect_1(bevd_0);
case 227747733: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -434276174: return bem_intNpSetDirect_1(bevd_0);
case 1502257889: return bem_nlSet_1(bevd_0);
case -1193443029: return bem_fileExtSetDirect_1(bevd_0);
case -2078922868: return bem_lastMethodsSizeSet_1(bevd_0);
case -1247463656: return bem_methodsSetDirect_1(bevd_0);
case -445042292: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -481280433: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -693199110: return bem_trueValueSetDirect_1(bevd_0);
case 1691886545: return bem_csynSet_1(bevd_0);
case 33047172: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -730962704: return bem_boolCcSet_1(bevd_0);
case -1898667638: return bem_parentConfSetDirect_1(bevd_0);
case -689115283: return bem_instanceNotEqualSet_1(bevd_0);
case 28608364: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1534732054: return bem_methodCallsSet_1(bevd_0);
case -1661358493: return bem_boolCcSetDirect_1(bevd_0);
case -372351826: return bem_nativeCSlotsSet_1(bevd_0);
case -101532401: return bem_nameToIdPathSet_1(bevd_0);
case 842740862: return bem_instanceEqualSetDirect_1(bevd_0);
case -32976889: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -991689342: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1444048065: return bem_fullLibEmitNameSet_1(bevd_0);
case 1261629358: return bem_transSetDirect_1(bevd_0);
case -323708732: return bem_lastMethodsLinesSet_1(bevd_0);
case -1495841299: return bem_buildSet_1(bevd_0);
case -1632587786: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1330583058: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 220096750: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -562983119: return bem_inFilePathedSet_1(bevd_0);
case -141222888: return bem_constSet_1(bevd_0);
case -515985333: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 653931073: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -137286182: return bem_nameToIdSet_1(bevd_0);
case 292016629: return bem_intNpSet_1(bevd_0);
case 1105621431: return bem_scvpSet_1(bevd_0);
case 2075595621: return bem_floatNpSet_1(bevd_0);
case -1767874470: return bem_onceDecsSet_1(bevd_0);
case 1811162608: return bem_transSet_1(bevd_0);
case -1436769554: return bem_csynSetDirect_1(bevd_0);
case 1324654072: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1356239131: return bem_qSet_1(bevd_0);
case -1963245123: return bem_preClassSetDirect_1(bevd_0);
case 1712261296: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1811090690: return bem_end_1(bevd_0);
case 946361087: return bem_methodBodySetDirect_1(bevd_0);
case -734876: return bem_boolNpSet_1(bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case 1634828147: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1456122317: return bem_objectNpSet_1(bevd_0);
case 1151677520: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -81996108: return bem_ccCacheSet_1(bevd_0);
case 742074504: return bem_classCallsSetDirect_1(bevd_0);
case 1344667252: return bem_invpSet_1(bevd_0);
case 1532065256: return bem_methodCallsSetDirect_1(bevd_0);
case 1535565471: return bem_nameToIdPathSetDirect_1(bevd_0);
case -1610865597: return bem_inClassSet_1(bevd_0);
case -2018385139: return bem_ntypesSetDirect_1(bevd_0);
case 83606345: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -685516323: return bem_instOfSetDirect_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1191011412: return bem_classConfSetDirect_1(bevd_0);
case 1218638944: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -339409609: return bem_emitLangSet_1(bevd_0);
case -755990687: return bem_randSet_1(bevd_0);
case -2094564755: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -540650170: return bem_libEmitNameSet_1(bevd_0);
case -1695368029: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1098953825: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 1573097305: return bem_methodsSet_1(bevd_0);
case -1946449430: return bem_preClassSet_1(bevd_0);
case -1774971084: return bem_gcMarksSet_1(bevd_0);
case 90965052: return bem_begin_1(bevd_0);
case 1142761677: return bem_emitLangSetDirect_1(bevd_0);
case -1983736569: return bem_msynSetDirect_1(bevd_0);
case 1318976305: return bem_mnodeSet_1(bevd_0);
case -51815182: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 228044181: return bem_inFilePathedSetDirect_1(bevd_0);
case -1227801343: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1809541529: return bem_nullValueSet_1(bevd_0);
case -1191962969: return bem_maxDynArgsSet_1(bevd_0);
case -565215734: return bem_dynMethodsSet_1(bevd_0);
case 672076917: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -2074593399: return bem_maxDynArgsSetDirect_1(bevd_0);
case 1552708590: return bem_propertyDecsSet_1(bevd_0);
case 478711464: return bem_objectNpSetDirect_1(bevd_0);
case -1469439074: return bem_libEmitNameSetDirect_1(bevd_0);
case -235372458: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1470425670: return bem_libEmitPathSetDirect_1(bevd_0);
case 947838894: return bem_msynSet_1(bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case -915220907: return bem_lastCallSetDirect_1(bevd_0);
case -987000021: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -122793315: return bem_stringNpSet_1(bevd_0);
case 784090150: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 2103258765: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -321716932: return bem_trueValueSet_1(bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case -170547481: return bem_idToNameSetDirect_1(bevd_0);
case -340377293: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1768433000: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 115653838: return bem_lineCountSetDirect_1(bevd_0);
case 1509260691: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -695558377: return bem_ccMethodsSet_1(bevd_0);
case -1792374839: return bem_onceCountSetDirect_1(bevd_0);
case 109128336: return bem_smnlecsSet_1(bevd_0);
case -726198430: return bem_smnlcsSet_1(bevd_0);
case -58435250: return bem_instOfSet_1(bevd_0);
case -964134440: return bem_qSetDirect_1(bevd_0);
case 2076358873: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 301328175: return bem_fileExtSet_1(bevd_0);
case 2084093253: return bem_idToNameSet_1(bevd_0);
case -45411426: return bem_ccCacheSetDirect_1(bevd_0);
case 378065796: return bem_cnodeSet_1(bevd_0);
case 320760836: return bem_inClassSetDirect_1(bevd_0);
case -1179286332: return bem_smnlecsSetDirect_1(bevd_0);
case 685889302: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1707340098: return bem_scvpSetDirect_1(bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case 882284903: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 369800628: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1322972549: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 924161164: return bem_exceptDecSetDirect_1(bevd_0);
case 481789825: return bem_ntypesSet_1(bevd_0);
case -1601873346: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -941049821: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -73763422: return bem_libEmitPathSet_1(bevd_0);
case -1501104376: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1733330347: return bem_classConfSet_1(bevd_0);
case 1869331694: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1302315104: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 2065084484: return bem_synEmitPathSetDirect_1(bevd_0);
case -1383635460: return bem_nameToIdSetDirect_1(bevd_0);
case 103706318: return bem_returnTypeSet_1(bevd_0);
case -1666231543: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 547117027: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 816307078: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1592034811: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -389834743: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -670827910: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1694315141: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1367115910: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2036185880: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1607354642: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -6943355: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 976284892: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -557944166: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1745773606: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1463868954: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1187763042: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1168412109: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1906686445: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 18836074: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1839289328: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -966971962: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1033522712: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1359672143: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildSWEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildSWEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildSWEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_inst = (BEC_2_5_9_BuildSWEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_type;
}
}
