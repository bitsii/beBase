package be;
/* IO:File: source/build/EmitData.be */
public final class BEC_2_5_13_BuildPropertyIndex extends BEC_2_6_6_SystemObject {
public BEC_2_5_13_BuildPropertyIndex() { }
private static byte[] becc_BEC_2_5_13_BuildPropertyIndex_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_BEC_2_5_13_BuildPropertyIndex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static BEC_2_5_13_BuildPropertyIndex bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst;

public static BET_2_5_13_BuildPropertyIndex bece_BEC_2_5_13_BuildPropertyIndex_bevs_type;

public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildPtySyn bevp_psyn;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_13_BuildPropertyIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildPtySyn beva__psyn) throws Throwable {
bevp_syn = beva__syn;
bevp_psyn = beva__psyn;
bevp_origin = bevp_psyn.bem_originGet_0();
bevp_name = bevp_psyn.bem_nameGet_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_origin.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_4_tmpany_phold = bem_sameClass_1(beva_x);
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 87 */
bevt_7_tmpany_phold = beva_x.bemd_0(2136694441);
bevt_6_tmpany_phold = bevp_origin.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_9_tmpany_phold = beva_x.bemd_0(29768415);
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
 else  /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 88 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 89 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_13_BuildPropertyIndex bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_psynGet_0() throws Throwable {
return bevp_psyn;
} /*method end*/
public final BEC_2_5_6_BuildPtySyn bem_psynGetDirect_0() throws Throwable {
return bevp_psyn;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_psynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_psyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_13_BuildPropertyIndex bem_psynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_psyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_originGetDirect_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_13_BuildPropertyIndex bem_originSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_13_BuildPropertyIndex bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {75, 76, 77, 78, 83, 83, 83, 83, 87, 87, 0, 87, 87, 87, 0, 0, 87, 87, 88, 88, 88, 88, 0, 0, 0, 89, 89, 91, 91, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 26, 27, 28, 29, 44, 49, 50, 53, 54, 59, 60, 63, 67, 68, 70, 71, 73, 74, 76, 79, 83, 86, 87, 89, 90, 93, 96, 99, 103, 107, 110, 113, 117, 121, 124, 127, 131, 135, 138, 141, 145};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 75 16
assign 1 76 17
assign 1 77 18
originGet 0 77 18
assign 1 78 19
nameGet 0 78 19
assign 1 83 26
toString 0 83 26
assign 1 83 27
add 1 83 27
assign 1 83 28
hashGet 0 83 28
return 1 83 29
assign 1 87 44
undef 1 87 49
assign 1 0 50
assign 1 87 53
sameClass 1 87 53
assign 1 87 54
not 0 87 59
assign 1 0 60
assign 1 0 63
assign 1 87 67
new 0 87 67
return 1 87 68
assign 1 88 70
originGet 0 88 70
assign 1 88 71
equals 1 88 71
assign 1 88 73
nameGet 0 88 73
assign 1 88 74
equals 1 88 74
assign 1 0 76
assign 1 0 79
assign 1 0 83
assign 1 89 86
new 0 89 86
return 1 89 87
assign 1 91 89
new 0 91 89
return 1 91 90
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
return 1 0 107
return 1 0 110
assign 1 0 113
assign 1 0 117
return 1 0 121
return 1 0 124
assign 1 0 127
assign 1 0 131
return 1 0 135
return 1 0 138
assign 1 0 141
assign 1 0 145
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1770146810: return bem_serializeToString_0();
case -289105412: return bem_psynGetDirect_0();
case -1897113414: return bem_psynGet_0();
case 29768415: return bem_nameGet_0();
case 1361603917: return bem_create_0();
case -512745226: return bem_tagGet_0();
case 150594226: return bem_toAny_0();
case 475849232: return bem_fieldNamesGet_0();
case -481458436: return bem_once_0();
case 2136694441: return bem_originGet_0();
case 970559243: return bem_hashGet_0();
case -232339846: return bem_classNameGet_0();
case 189063253: return bem_serializeContents_0();
case -696933955: return bem_toString_0();
case -791198660: return bem_serializationIteratorGet_0();
case 734719264: return bem_copy_0();
case 865626065: return bem_many_0();
case -1010395565: return bem_deserializeClassNameGet_0();
case -1782114567: return bem_nameGetDirect_0();
case 15052169: return bem_iteratorGet_0();
case 1031863671: return bem_synGetDirect_0();
case -866769073: return bem_new_0();
case 1238422180: return bem_originGetDirect_0();
case -1238312381: return bem_print_0();
case 1064240293: return bem_sourceFileNameGet_0();
case -96306095: return bem_echo_0();
case -997814696: return bem_synGet_0();
case 1703076999: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1689607871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2018144381: return bem_sameType_1(bevd_0);
case -1258943525: return bem_equals_1(bevd_0);
case -1648069036: return bem_psynSetDirect_1(bevd_0);
case -1555556152: return bem_defined_1(bevd_0);
case 1429540364: return bem_nameSet_1(bevd_0);
case -1378821005: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1613509862: return bem_originSet_1(bevd_0);
case 789848846: return bem_copyTo_1(bevd_0);
case -1814510964: return bem_notEquals_1(bevd_0);
case -1973562246: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 721379891: return bem_otherType_1(bevd_0);
case -1657467808: return bem_def_1(bevd_0);
case 954777710: return bem_undefined_1(bevd_0);
case -1575506760: return bem_synSetDirect_1(bevd_0);
case -218414282: return bem_psynSet_1(bevd_0);
case -1120668425: return bem_sameClass_1(bevd_0);
case -1696224976: return bem_otherClass_1(bevd_0);
case 952631001: return bem_undef_1(bevd_0);
case 144059211: return bem_nameSetDirect_1(bevd_0);
case -304012900: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1411547316: return bem_sameObject_1(bevd_0);
case 2128188082: return bem_synSet_1(bevd_0);
case -1951340181: return bem_originSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -133579010: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 621008714: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildPtySyn) bevd_1);
case -750254672: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1191848195: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 514912045: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2072659817: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1041788971: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 84003596: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_5_13_BuildPropertyIndex_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_13_BuildPropertyIndex_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_13_BuildPropertyIndex();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_13_BuildPropertyIndex.bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst = (BEC_2_5_13_BuildPropertyIndex) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_13_BuildPropertyIndex.bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_13_BuildPropertyIndex.bece_BEC_2_5_13_BuildPropertyIndex_bevs_type;
}
}
