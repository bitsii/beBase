package be;
/* IO:File: source/extended/Startup.be */
public class BEC_3_6_7_18_SystemStartupMainWithParameters extends BEC_2_6_6_SystemObject {
public BEC_3_6_7_18_SystemStartupMainWithParameters() { }
private static byte[] becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x3A,0x4D,0x61,0x69,0x6E,0x57,0x69,0x74,0x68,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
public static BEC_3_6_7_18_SystemStartupMainWithParameters bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst;

public static BET_3_6_7_18_SystemStartupMainWithParameters bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_type;

public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_3_ta_ph = null;
bevt_3_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_main_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_6_10_SystemParameters beva_params) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_4_ContainerList bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_3_ta_ph = beva_params.bem_orderedGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_2_ta_ph = bevt_3_ta_ph.bem_get_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_createInstance_1((BEC_2_4_6_TextString) bevt_2_ta_ph );
bevl_x = bevt_0_ta_ph.bemd_0(-1459622248);
bevt_5_ta_ph = bevl_x.bemd_1(585935842, beva_params);
return bevt_5_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {315, 315, 315, 315, 315, 322, 322, 322, 322, 322, 322, 323, 323};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 20, 30, 31, 32, 33, 34, 35, 36, 37};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 315 16
new 0 315 16
assign 1 315 17
argsGet 0 315 17
assign 1 315 18
new 1 315 18
assign 1 315 19
main 1 315 19
return 1 315 20
assign 1 322 30
new 0 322 30
assign 1 322 31
orderedGet 0 322 31
assign 1 322 32
new 0 322 32
assign 1 322 33
get 1 322 33
assign 1 322 34
createInstance 1 322 34
assign 1 322 35
new 0 322 35
assign 1 323 36
main 1 323 36
return 1 323 37
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 184194385: return bem_copy_0();
case 1143177466: return bem_main_0();
case 2101401855: return bem_toString_0();
case -752204173: return bem_hashGet_0();
case -1459622248: return bem_new_0();
case 275008169: return bem_iteratorGet_0();
case -1558425735: return bem_print_0();
case 1668207848: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1790102834: return bem_notEquals_1(bevd_0);
case 585935842: return bem_main_1((BEC_2_6_10_SystemParameters) bevd_0);
case 154368609: return bem_copyTo_1(bevd_0);
case -652861342: return bem_equals_1(bevd_0);
case -1703868814: return bem_def_1(bevd_0);
case -1486272003: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 145687102: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 648898220: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2076042115: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1494362942: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(33, becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_7_18_SystemStartupMainWithParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst = (BEC_3_6_7_18_SystemStartupMainWithParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_type;
}
}
