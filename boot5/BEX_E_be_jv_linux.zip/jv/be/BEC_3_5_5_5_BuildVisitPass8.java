package be;
/* IO:File: source/build/Pass8.be */
public final class BEC_3_5_5_5_BuildVisitPass8 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass8() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_24 = {0x67,0x65,0x74,0x5F,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_25 = {0x67,0x65,0x74,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_26 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_27 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_28 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_29 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_30 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
public static BEC_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;

public BEC_3_5_5_5_BuildVisitPass8 bem_acceptClass_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_8_BuildEmitData bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_0_ta_ph.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepOps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(10));
bevl_ops = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 19*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = bevl_i.bemd_1(-128113126, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 19*/ {
bevt_3_ta_ph = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(-1730357245, bevl_i, bevt_3_ta_ph);
bevl_i = bevl_i.bemd_0(1982779509);
} /* Line: 19*/
 else /* Line: 19*/ {
break;
} /* Line: 19*/
} /* Line: 19*/
return bevl_ops;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_prec = null;
BEC_2_6_6_SystemObject bevl_cont = null;
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_onode = null;
BEC_2_6_6_SystemObject bevl_mo = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_mt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
bevt_3_ta_ph = beva_node.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 29*/ {
bem_acceptClass_1(beva_node);
bevt_5_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_5_ta_ph;
} /* Line: 31*/
bevt_6_ta_ph = bevp_const.bem_operGet_0();
bevt_7_ta_ph = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_ta_ph.bem_get_1(bevt_7_ta_ph);
if (bevl_prec == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 34*/ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
/* Line: 44*/ {
if (bevl_onode == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevl_prec == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_12_ta_ph = bevl_onode.bemd_0(-639730360);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(-774009453, bevl_cont);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_13_ta_ph = bevl_ops.bemd_1(855551287, bevl_prec);
bevt_13_ta_ph.bemd_1(986443427, bevl_onode);
bevl_inode = bevl_onode.bemd_0(991089365);
if (bevl_inode == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 47*/ {
bevl_inode = bevl_inode.bemd_0(991089365);
if (bevl_inode == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_17_ta_ph = bevl_inode.bemd_0(570366090);
bevt_18_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(-774009453, bevt_18_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_inode = bevl_inode.bemd_0(991089365);
if (bevl_inode == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 52*/ {
bevl_inode = bevl_inode.bemd_0(991089365);
} /* Line: 53*/
} /* Line: 52*/
} /* Line: 50*/
} /* Line: 49*/
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_21_ta_ph = bevp_const.bem_operGet_0();
bevt_22_ta_ph = bevl_onode.bemd_0(570366090);
bevl_prec = bevt_21_ta_ph.bem_get_1(bevt_22_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
bevl_prec = null;
} /* Line: 62*/
} /* Line: 59*/
 else /* Line: 44*/ {
break;
} /* Line: 44*/
} /* Line: 44*/
bevl_prec = (new BEC_2_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(2011135674);
while (true)
/* Line: 66*/ {
bevt_23_ta_ph = bevl_it.bemd_0(2079194339);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 66*/ {
bevl_i = bevl_it.bemd_0(1790843424);
bevt_25_ta_ph = bevl_i.bemd_0(1297396705);
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(1205665157, bevt_26_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 68*/ {
bevl_mt = bevl_i.bemd_0(2011135674);
while (true)
/* Line: 69*/ {
bevt_27_ta_ph = bevl_mt.bemd_0(2079194339);
if (((BEC_2_5_4_LogicBool) bevt_27_ta_ph).bevi_bool)/* Line: 69*/ {
bevl_mo = bevl_mt.bemd_0(1790843424);
bevt_28_ta_ph = bevl_mo.bemd_0(358457980);
bevt_29_ta_ph = bevl_mo.bemd_0(991089365);
bevl_mo = bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_ta_ph, bevt_29_ta_ph);
beva_node = (BEC_2_5_4_BuildNode) bevl_mo;
} /* Line: 72*/
 else /* Line: 69*/ {
break;
} /* Line: 69*/
} /* Line: 69*/
} /* Line: 69*/
bevl_prec = bevl_prec.bemd_0(1982779509);
} /* Line: 75*/
 else /* Line: 66*/ {
break;
} /* Line: 66*/
} /* Line: 66*/
} /* Line: 66*/
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callFromOper_4(BEC_2_6_6_SystemObject beva_op, BEC_2_6_6_SystemObject beva_prec, BEC_2_6_6_SystemObject beva_pr, BEC_2_6_6_SystemObject beva_nx) throws Throwable {
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_5_4_LogicBool bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-813147566, bevt_0_ta_ph);
bevt_3_ta_ph = bevp_const.bem_operNamesGet_0();
bevt_4_ta_ph = beva_op.bemd_0(570366090);
bevt_2_ta_ph = bevt_3_ta_ph.bem_get_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-88555650);
bevl_gc.bemd_1(-783373260, bevt_1_ta_ph);
bevt_6_ta_ph = bevl_gc.bemd_0(474531258);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_0));
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(-774009453, bevt_7_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 87*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_1));
bevl_gc.bemd_1(-783373260, bevt_8_ta_ph);
} /* Line: 88*/
bevt_10_ta_ph = bevl_gc.bemd_0(474531258);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_2));
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(-774009453, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 90*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_3));
bevl_gc.bemd_1(-783373260, bevt_12_ta_ph);
} /* Line: 91*/
bevt_14_ta_ph = bevl_gc.bemd_0(474531258);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_4));
bevt_13_ta_ph = bevt_14_ta_ph.bemd_1(-774009453, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 93*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_5));
bevl_gc.bemd_1(-783373260, bevt_16_ta_ph);
} /* Line: 94*/
bevt_18_ta_ph = bevl_gc.bemd_0(474531258);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_6));
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(-774009453, bevt_19_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 96*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_7));
bevl_gc.bemd_1(-783373260, bevt_20_ta_ph);
} /* Line: 97*/
bevt_22_ta_ph = bevl_gc.bemd_0(474531258);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_8));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(-774009453, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 99*/ {
bevt_24_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_9));
bevl_gc.bemd_1(-783373260, bevt_24_ta_ph);
} /* Line: 100*/
bevt_26_ta_ph = bevl_gc.bemd_0(474531258);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_10));
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(-774009453, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 102*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_11));
bevl_gc.bemd_1(-783373260, bevt_28_ta_ph);
} /* Line: 103*/
bevt_30_ta_ph = bevl_gc.bemd_0(474531258);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_12));
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(-774009453, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_29_ta_ph).bevi_bool)/* Line: 105*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_13));
bevl_gc.bemd_1(-783373260, bevt_32_ta_ph);
} /* Line: 106*/
bevt_34_ta_ph = bevl_gc.bemd_0(474531258);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_14));
bevt_33_ta_ph = bevt_34_ta_ph.bemd_1(-774009453, bevt_35_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 108*/ {
bevt_36_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_15));
bevl_gc.bemd_1(-783373260, bevt_36_ta_ph);
} /* Line: 109*/
bevt_38_ta_ph = bevl_gc.bemd_0(474531258);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_16));
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(-774009453, bevt_39_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_37_ta_ph).bevi_bool)/* Line: 111*/ {
bevt_40_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_17));
bevl_gc.bemd_1(-783373260, bevt_40_ta_ph);
} /* Line: 112*/
bevt_42_ta_ph = bevl_gc.bemd_0(474531258);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_18));
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(-774009453, bevt_43_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 114*/ {
bevt_44_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_19));
bevl_gc.bemd_1(-783373260, bevt_44_ta_ph);
} /* Line: 115*/
bevt_46_ta_ph = bevl_gc.bemd_0(474531258);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_20));
bevt_45_ta_ph = bevt_46_ta_ph.bemd_1(-774009453, bevt_47_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 117*/ {
bevt_48_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_21));
bevl_gc.bemd_1(-783373260, bevt_48_ta_ph);
} /* Line: 118*/
bevt_50_ta_ph = bevl_gc.bemd_0(474531258);
bevt_51_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_22));
bevt_49_ta_ph = bevt_50_ta_ph.bemd_1(-774009453, bevt_51_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_49_ta_ph).bevi_bool)/* Line: 120*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_23));
bevl_gc.bemd_1(-783373260, bevt_52_ta_ph);
} /* Line: 121*/
bevt_54_ta_ph = bevl_gc.bemd_0(474531258);
bevt_55_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(-774009453, bevt_55_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 123*/ {
bevt_56_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_25));
bevl_gc.bemd_1(-783373260, bevt_56_ta_ph);
} /* Line: 125*/
bevt_58_ta_ph = bevl_gc.bemd_0(474531258);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_26));
bevt_57_ta_ph = bevt_58_ta_ph.bemd_1(-774009453, bevt_59_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_57_ta_ph).bevi_bool)/* Line: 127*/ {
bevt_60_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_27));
bevl_gc.bemd_1(-783373260, bevt_60_ta_ph);
} /* Line: 128*/
bevt_62_ta_ph = bevl_gc.bemd_0(474531258);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_28));
bevt_61_ta_ph = bevt_62_ta_ph.bemd_1(-774009453, bevt_63_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 130*/ {
bevt_64_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass8_bels_29));
bevl_gc.bemd_1(-783373260, bevt_64_ta_ph);
} /* Line: 131*/
bevt_65_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1547965524, bevt_65_ta_ph);
bevt_67_ta_ph = beva_op.bemd_0(570366090);
bevt_68_ta_ph = bevp_ntypes.bem_GET_METHODGet_0();
bevt_66_ta_ph = bevt_67_ta_ph.bemd_1(-774009453, bevt_68_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_66_ta_ph).bevi_bool)/* Line: 135*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_30));
bevp_build.bem_buildLiteral_2(beva_nx, bevt_69_ta_ph);
} /* Line: 136*/
bevt_70_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(-1954410673, bevt_70_ta_ph);
beva_op.bemd_1(-653122309, bevl_gc);
beva_pr.bemd_0(1994778350);
beva_op.bemd_1(986443427, beva_pr);
bevt_72_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_71_ta_ph = beva_prec.bemd_1(1205665157, bevt_72_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_71_ta_ph).bevi_bool)/* Line: 142*/ {
beva_nx.bemd_0(1994778350);
beva_op.bemd_1(986443427, beva_nx);
} /* Line: 144*/
return beva_op;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 14, 18, 18, 19, 19, 19, 20, 20, 19, 22, 29, 29, 29, 29, 30, 31, 31, 33, 33, 33, 34, 34, 39, 40, 41, 43, 44, 44, 44, 44, 0, 0, 0, 44, 44, 0, 0, 0, 45, 45, 46, 47, 47, 48, 49, 49, 50, 50, 50, 51, 52, 52, 53, 58, 59, 59, 60, 60, 60, 62, 65, 66, 66, 67, 68, 68, 68, 69, 69, 70, 71, 71, 71, 72, 75, 80, 80, 84, 85, 85, 86, 86, 86, 86, 86, 87, 87, 87, 88, 88, 90, 90, 90, 91, 91, 93, 93, 93, 94, 94, 96, 96, 96, 97, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 109, 109, 111, 111, 111, 112, 112, 114, 114, 114, 115, 115, 117, 117, 117, 118, 118, 120, 120, 120, 121, 121, 123, 123, 123, 125, 125, 127, 127, 127, 128, 128, 130, 130, 130, 131, 131, 134, 134, 135, 135, 135, 136, 136, 138, 138, 139, 140, 141, 142, 142, 143, 144, 146};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 55, 56, 57, 60, 61, 63, 64, 65, 71, 114, 115, 116, 121, 122, 123, 124, 126, 127, 128, 129, 134, 135, 136, 137, 138, 141, 146, 147, 152, 153, 156, 160, 163, 164, 166, 169, 173, 176, 177, 178, 179, 184, 185, 186, 191, 192, 193, 194, 196, 197, 202, 203, 208, 209, 214, 215, 216, 217, 220, 227, 228, 231, 233, 234, 235, 236, 238, 241, 243, 244, 245, 246, 247, 254, 261, 262, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 351, 352, 354, 355, 356, 358, 359, 361, 362, 363, 365, 366, 368, 369, 370, 372, 373, 375, 376, 377, 379, 380, 382, 383, 384, 386, 387, 389, 390, 391, 393, 394, 396, 397, 398, 400, 401, 403, 404, 405, 407, 408, 410, 411, 412, 414, 415, 417, 418, 419, 421, 422, 424, 425, 426, 428, 429, 431, 432, 433, 435, 436, 438, 439, 440, 442, 443, 445, 446, 447, 449, 450, 452, 453, 454, 455, 456, 458, 459, 461, 462, 463, 464, 465, 466, 467, 469, 470, 472};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 44
emitDataGet 0 14 44
addParsedClass 1 14 45
assign 1 18 55
new 0 18 55
assign 1 18 56
new 1 18 56
assign 1 19 57
new 0 19 57
assign 1 19 60
new 0 19 60
assign 1 19 61
lesser 1 19 61
assign 1 20 63
new 0 20 63
put 2 20 64
assign 1 19 65
increment 0 19 65
return 1 22 71
assign 1 29 114
typenameGet 0 29 114
assign 1 29 115
CLASSGet 0 29 115
assign 1 29 116
equals 1 29 121
acceptClass 1 30 122
assign 1 31 123
nextDescendGet 0 31 123
return 1 31 124
assign 1 33 126
operGet 0 33 126
assign 1 33 127
typenameGet 0 33 127
assign 1 33 128
get 1 33 128
assign 1 34 129
def 1 34 134
assign 1 39 135
containerGet 0 39 135
assign 1 40 136
prepOps 0 40 136
assign 1 41 137
assign 1 43 138
assign 1 44 141
def 1 44 146
assign 1 44 147
def 1 44 152
assign 1 0 153
assign 1 0 156
assign 1 0 160
assign 1 44 163
containerGet 0 44 163
assign 1 44 164
equals 1 44 164
assign 1 0 166
assign 1 0 169
assign 1 0 173
assign 1 45 176
get 1 45 176
addValue 1 45 177
assign 1 46 178
nextPeerGet 0 46 178
assign 1 47 179
def 1 47 184
assign 1 48 185
nextPeerGet 0 48 185
assign 1 49 186
def 1 49 191
assign 1 50 192
typenameGet 0 50 192
assign 1 50 193
COMMAGet 0 50 193
assign 1 50 194
equals 1 50 194
assign 1 51 196
nextPeerGet 0 51 196
assign 1 52 197
def 1 52 202
assign 1 53 203
nextPeerGet 0 53 203
assign 1 58 208
assign 1 59 209
def 1 59 214
assign 1 60 215
operGet 0 60 215
assign 1 60 216
typenameGet 0 60 216
assign 1 60 217
get 1 60 217
assign 1 62 220
assign 1 65 227
new 0 65 227
assign 1 66 228
iteratorGet 0 66 228
assign 1 66 231
hasNextGet 0 66 231
assign 1 67 233
nextGet 0 67 233
assign 1 68 234
lengthGet 0 68 234
assign 1 68 235
new 0 68 235
assign 1 68 236
greater 1 68 236
assign 1 69 238
iteratorGet 0 69 238
assign 1 69 241
hasNextGet 0 69 241
assign 1 70 243
nextGet 0 70 243
assign 1 71 244
priorPeerGet 0 71 244
assign 1 71 245
nextPeerGet 0 71 245
assign 1 71 246
callFromOper 4 71 246
assign 1 72 247
assign 1 75 254
increment 0 75 254
assign 1 80 261
nextDescendGet 0 80 261
return 1 80 262
assign 1 84 339
new 0 84 339
assign 1 85 340
new 0 85 340
wasOperSet 1 85 341
assign 1 86 342
operNamesGet 0 86 342
assign 1 86 343
typenameGet 0 86 343
assign 1 86 344
get 1 86 344
assign 1 86 345
lower 0 86 345
nameSet 1 86 346
assign 1 87 347
nameGet 0 87 347
assign 1 87 348
new 0 87 348
assign 1 87 349
equals 1 87 349
assign 1 88 351
new 0 88 351
nameSet 1 88 352
assign 1 90 354
nameGet 0 90 354
assign 1 90 355
new 0 90 355
assign 1 90 356
equals 1 90 356
assign 1 91 358
new 0 91 358
nameSet 1 91 359
assign 1 93 361
nameGet 0 93 361
assign 1 93 362
new 0 93 362
assign 1 93 363
equals 1 93 363
assign 1 94 365
new 0 94 365
nameSet 1 94 366
assign 1 96 368
nameGet 0 96 368
assign 1 96 369
new 0 96 369
assign 1 96 370
equals 1 96 370
assign 1 97 372
new 0 97 372
nameSet 1 97 373
assign 1 99 375
nameGet 0 99 375
assign 1 99 376
new 0 99 376
assign 1 99 377
equals 1 99 377
assign 1 100 379
new 0 100 379
nameSet 1 100 380
assign 1 102 382
nameGet 0 102 382
assign 1 102 383
new 0 102 383
assign 1 102 384
equals 1 102 384
assign 1 103 386
new 0 103 386
nameSet 1 103 387
assign 1 105 389
nameGet 0 105 389
assign 1 105 390
new 0 105 390
assign 1 105 391
equals 1 105 391
assign 1 106 393
new 0 106 393
nameSet 1 106 394
assign 1 108 396
nameGet 0 108 396
assign 1 108 397
new 0 108 397
assign 1 108 398
equals 1 108 398
assign 1 109 400
new 0 109 400
nameSet 1 109 401
assign 1 111 403
nameGet 0 111 403
assign 1 111 404
new 0 111 404
assign 1 111 405
equals 1 111 405
assign 1 112 407
new 0 112 407
nameSet 1 112 408
assign 1 114 410
nameGet 0 114 410
assign 1 114 411
new 0 114 411
assign 1 114 412
equals 1 114 412
assign 1 115 414
new 0 115 414
nameSet 1 115 415
assign 1 117 417
nameGet 0 117 417
assign 1 117 418
new 0 117 418
assign 1 117 419
equals 1 117 419
assign 1 118 421
new 0 118 421
nameSet 1 118 422
assign 1 120 424
nameGet 0 120 424
assign 1 120 425
new 0 120 425
assign 1 120 426
equals 1 120 426
assign 1 121 428
new 0 121 428
nameSet 1 121 429
assign 1 123 431
nameGet 0 123 431
assign 1 123 432
new 0 123 432
assign 1 123 433
equals 1 123 433
assign 1 125 435
new 0 125 435
nameSet 1 125 436
assign 1 127 438
nameGet 0 127 438
assign 1 127 439
new 0 127 439
assign 1 127 440
equals 1 127 440
assign 1 128 442
new 0 128 442
nameSet 1 128 443
assign 1 130 445
nameGet 0 130 445
assign 1 130 446
new 0 130 446
assign 1 130 447
equals 1 130 447
assign 1 131 449
new 0 131 449
nameSet 1 131 450
assign 1 134 452
new 0 134 452
wasBoundSet 1 134 453
assign 1 135 454
typenameGet 0 135 454
assign 1 135 455
GET_METHODGet 0 135 455
assign 1 135 456
equals 1 135 456
assign 1 136 458
new 0 136 458
buildLiteral 2 136 459
assign 1 138 461
CALLGet 0 138 461
typenameSet 1 138 462
heldSet 1 139 463
delete 0 140 464
addValue 1 141 465
assign 1 142 466
new 0 142 466
assign 1 142 467
greater 1 142 467
delete 0 143 469
addValue 1 144 470
return 1 146 472
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1724453868: return bem_serializeToString_0();
case 1777587047: return bem_hashGet_0();
case 1797865600: return bem_new_0();
case 791802958: return bem_ntypesGetDirect_0();
case -180175097: return bem_classNameGet_0();
case 967234853: return bem_fieldIteratorGet_0();
case 766881626: return bem_print_0();
case 1095297479: return bem_echo_0();
case 992286008: return bem_transGetDirect_0();
case -404516557: return bem_constGetDirect_0();
case 2011135674: return bem_iteratorGet_0();
case 617445256: return bem_sourceFileNameGet_0();
case -1455899172: return bem_create_0();
case -862722877: return bem_transGet_0();
case -1004023772: return bem_ntypesGet_0();
case 1546918554: return bem_prepOps_0();
case 888353027: return bem_buildGetDirect_0();
case 1955915393: return bem_fieldNamesGet_0();
case -194416815: return bem_tagGet_0();
case 1818057755: return bem_constGet_0();
case -119499799: return bem_serializationIteratorGet_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case -665649433: return bem_serializeContents_0();
case -1715766851: return bem_toAny_0();
case 378307569: return bem_copy_0();
case 509361355: return bem_once_0();
case -533443118: return bem_many_0();
case 1374272360: return bem_buildGet_0();
case 280712282: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -445857610: return bem_notEquals_1(bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case 1525819013: return bem_transSet_1(bevd_0);
case 457461480: return bem_transSetDirect_1(bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case 1863238097: return bem_constSetDirect_1(bevd_0);
case -427578580: return bem_ntypesSetDirect_1(bevd_0);
case -1391031501: return bem_begin_1(bevd_0);
case 1927957525: return bem_buildSetDirect_1(bevd_0);
case 906320876: return bem_defined_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
case 594913348: return bem_constSet_1(bevd_0);
case 1838349708: return bem_end_1(bevd_0);
case 756151160: return bem_ntypesSet_1(bevd_0);
case -375031861: return bem_acceptClass_1(bevd_0);
case 20780357: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -12217689: return bem_buildSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 603825181: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass8_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass8_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass8();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst = (BEC_3_5_5_5_BuildVisitPass8) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;
}
}
