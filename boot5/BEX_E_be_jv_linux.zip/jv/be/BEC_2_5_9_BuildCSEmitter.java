package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_24, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_27, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_38, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_39, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_40, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_41, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_42, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_46 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_47 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_48 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_48, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_49 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_49, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_50 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_50, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_51 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_51, 3));
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(-1769365769);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_tmpany_phold = bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_tmpany_phold = bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1759131101);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 42 */
bevt_27_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 51 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(1759131101);
if (bevl_firstptsyn.bevi_bool) /* Line: 52 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 53 */
 else  /* Line: 54 */ {
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 55 */
bevt_36_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 57 */
 else  /* Line: 51 */ {
break;
} /* Line: 51 */
} /* Line: 51 */
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevt_41_tmpany_phold = bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_40_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevl_bet.bem_addValue_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_47_tmpany_phold = bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_addValue_1(bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_46_tmpany_phold.bem_addValue_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevl_bet.bem_addValue_1(bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevl_bet.bem_addValue_1(bevt_53_tmpany_phold);
bevl_tout.bemd_1(-978336250, bevl_bet);
bevl_tout.bemd_0(-1223869755);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1327301284);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1473587806);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
return bevt_4_tmpany_phold;
} /* Line: 88 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
return bevt_3_tmpany_phold;
} /* Line: 95 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_45));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_46));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-391498004);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_47));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 49, 49, 50, 51, 51, 0, 51, 51, 53, 55, 55, 57, 57, 57, 57, 59, 59, 61, 61, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 65, 65, 65, 65, 66, 66, 67, 67, 68, 68, 69, 70, 74, 74, 74, 75, 76, 76, 76, 76, 76, 76, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 83, 83, 87, 0, 87, 87, 87, 0, 0, 0, 0, 0, 88, 88, 90, 90, 94, 94, 94, 0, 0, 0, 95, 95, 97, 97, 101, 101, 105, 105, 105, 105, 105, 110, 111, 112, 112, 112, 113, 119, 119, 119, 119, 119, 119, 123, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 127, 131, 131, 131, 135, 135, 135, 135, 135, 135, 135, 139, 139, 143, 143, 143, 147, 147, 147, 147, 151, 151};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {78, 79, 80, 81, 145, 146, 147, 148, 153, 154, 155, 156, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 181, 184, 186, 188, 191, 192, 194, 195, 196, 197, 203, 204, 205, 206, 207, 208, 209, 210, 211, 211, 214, 216, 218, 221, 222, 224, 225, 226, 227, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 305, 306, 315, 317, 320, 325, 326, 328, 331, 335, 338, 341, 345, 346, 348, 349, 357, 362, 363, 365, 368, 372, 375, 376, 378, 379, 383, 384, 391, 392, 393, 394, 395, 401, 402, 403, 404, 405, 406, 415, 416, 417, 418, 419, 420, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 469, 470, 471, 480, 481, 482, 483, 484, 485, 486, 490, 491, 496, 497, 498, 504, 505, 506, 507, 511, 512};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 78
new 0 17 78
assign 1 18 79
new 0 18 79
assign 1 19 80
new 0 19 80
new 1 23 81
assign 1 27 145
classDirGet 0 27 145
assign 1 27 146
fileGet 0 27 146
assign 1 27 147
existsGet 0 27 147
assign 1 27 148
not 0 27 153
assign 1 28 154
classDirGet 0 28 154
assign 1 28 155
fileGet 0 28 155
makeDirs 0 28 156
assign 1 30 158
typePathGet 0 30 158
assign 1 30 159
fileGet 0 30 159
assign 1 30 160
writerGet 0 30 160
assign 1 30 161
open 0 30 161
assign 1 31 162
new 0 31 162
assign 1 32 163
new 0 32 163
addValue 1 32 164
assign 1 33 165
new 0 33 165
assign 1 33 166
addValue 1 33 166
assign 1 33 167
typeEmitNameGet 0 33 167
assign 1 33 168
addValue 1 33 168
assign 1 33 169
new 0 33 169
addValue 1 33 170
assign 1 34 171
new 0 34 171
assign 1 34 172
addValue 1 34 172
assign 1 34 173
typeEmitNameGet 0 34 173
assign 1 34 174
addValue 1 34 174
assign 1 34 175
new 0 34 175
addValue 1 34 176
assign 1 36 177
new 0 36 177
addValue 1 36 178
assign 1 37 179
new 0 37 179
assign 1 38 180
mtdListGet 0 38 180
assign 1 38 181
iteratorGet 0 0 181
assign 1 38 184
hasNextGet 0 38 184
assign 1 38 186
nextGet 0 38 186
assign 1 40 188
new 0 40 188
assign 1 42 191
new 0 42 191
addValue 1 42 192
assign 1 44 194
addValue 1 44 194
assign 1 44 195
nameGet 0 44 195
assign 1 44 196
addValue 1 44 196
addValue 1 44 197
assign 1 46 203
new 0 46 203
addValue 1 46 204
assign 1 47 205
new 0 47 205
addValue 1 47 206
assign 1 49 207
new 0 49 207
addValue 1 49 208
assign 1 50 209
new 0 50 209
assign 1 51 210
ptyListGet 0 51 210
assign 1 51 211
iteratorGet 0 0 211
assign 1 51 214
hasNextGet 0 51 214
assign 1 51 216
nextGet 0 51 216
assign 1 53 218
new 0 53 218
assign 1 55 221
new 0 55 221
addValue 1 55 222
assign 1 57 224
addValue 1 57 224
assign 1 57 225
nameGet 0 57 225
assign 1 57 226
addValue 1 57 226
addValue 1 57 227
assign 1 59 233
new 0 59 233
addValue 1 59 234
assign 1 61 235
new 0 61 235
addValue 1 61 236
assign 1 63 237
new 0 63 237
assign 1 63 238
addValue 1 63 238
assign 1 63 239
typeEmitNameGet 0 63 239
assign 1 63 240
addValue 1 63 240
assign 1 63 241
new 0 63 241
addValue 1 63 242
assign 1 64 243
new 0 64 243
addValue 1 64 244
assign 1 65 245
new 0 65 245
assign 1 65 246
addValue 1 65 246
assign 1 65 247
emitNameGet 0 65 247
assign 1 65 248
addValue 1 65 248
assign 1 65 249
new 0 65 249
addValue 1 65 250
assign 1 66 251
new 0 66 251
addValue 1 66 252
assign 1 67 253
new 0 67 253
addValue 1 67 254
assign 1 68 255
new 0 68 255
addValue 1 68 256
write 1 69 257
close 0 70 258
assign 1 74 280
new 0 74 280
assign 1 74 281
toString 0 74 281
assign 1 74 282
add 1 74 282
incrementValue 0 75 283
assign 1 76 284
new 0 76 284
assign 1 76 285
addValue 1 76 285
assign 1 76 286
addValue 1 76 286
assign 1 76 287
new 0 76 287
assign 1 76 288
addValue 1 76 288
addValue 1 76 289
assign 1 78 290
containedGet 0 78 290
assign 1 78 291
firstGet 0 78 291
assign 1 78 292
containedGet 0 78 292
assign 1 78 293
firstGet 0 78 293
assign 1 78 294
new 0 78 294
assign 1 78 295
add 1 78 295
assign 1 78 296
new 0 78 296
assign 1 78 297
add 1 78 297
assign 1 78 298
new 0 78 298
assign 1 78 299
finalAssign 4 78 299
addValue 1 78 300
assign 1 83 305
new 0 83 305
return 1 83 306
assign 1 87 315
isFinalGet 0 87 315
assign 1 0 317
assign 1 87 320
def 1 87 325
assign 1 87 326
isFinalGet 0 87 326
assign 1 0 328
assign 1 0 331
assign 1 0 335
assign 1 0 338
assign 1 0 341
assign 1 88 345
new 0 88 345
return 1 88 346
assign 1 90 348
new 0 90 348
return 1 90 349
assign 1 94 357
def 1 94 362
assign 1 94 363
isFinalGet 0 94 363
assign 1 0 365
assign 1 0 368
assign 1 0 372
assign 1 95 375
new 0 95 375
return 1 95 376
assign 1 97 378
new 0 97 378
return 1 97 379
assign 1 101 383
new 0 101 383
return 1 101 384
assign 1 105 391
new 0 105 391
assign 1 105 392
add 1 105 392
assign 1 105 393
new 0 105 393
assign 1 105 394
add 1 105 394
return 1 105 395
getCode 2 110 401
assign 1 111 402
toHexString 1 111 402
assign 1 112 403
new 0 112 403
assign 1 112 404
once 0 112 404
addValue 1 112 405
addValue 1 113 406
assign 1 119 415
new 0 119 415
assign 1 119 416
add 1 119 416
assign 1 119 417
new 0 119 417
assign 1 119 418
add 1 119 418
assign 1 119 419
add 1 119 419
return 1 119 420
assign 1 123 442
new 0 123 442
assign 1 123 443
add 1 123 443
assign 1 123 444
new 0 123 444
assign 1 123 445
add 1 123 445
assign 1 123 446
add 1 123 446
assign 1 124 447
new 0 124 447
assign 1 124 448
addValue 1 124 448
assign 1 124 449
addValue 1 124 449
assign 1 124 450
new 0 124 450
assign 1 124 451
addValue 1 124 451
addValue 1 124 452
assign 1 125 453
new 0 125 453
assign 1 125 454
addValue 1 125 454
addValue 1 125 455
assign 1 126 456
new 0 126 456
assign 1 126 457
addValue 1 126 457
assign 1 126 458
outputPlatformGet 0 126 458
assign 1 126 459
nameGet 0 126 459
assign 1 126 460
addValue 1 126 460
assign 1 126 461
new 0 126 461
assign 1 126 462
addValue 1 126 462
addValue 1 126 463
return 1 127 464
assign 1 131 469
libNameGet 0 131 469
assign 1 131 470
beginNs 1 131 470
return 1 131 471
assign 1 135 480
new 0 135 480
assign 1 135 481
libNs 1 135 481
assign 1 135 482
add 1 135 482
assign 1 135 483
new 0 135 483
assign 1 135 484
add 1 135 484
assign 1 135 485
add 1 135 485
return 1 135 486
assign 1 139 490
getNameSpace 1 139 490
return 1 139 491
assign 1 143 496
new 0 143 496
assign 1 143 497
add 1 143 497
return 1 143 498
assign 1 147 504
new 0 147 504
assign 1 147 505
once 0 147 505
assign 1 147 506
add 1 147 506
return 1 147 507
assign 1 151 511
new 0 151 511
return 1 151 512
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1093085716: return bem_lastMethodsLinesGetDirect_0();
case -283396003: return bem_classEndGet_0();
case -754551371: return bem_smnlcsGetDirect_0();
case 1004853414: return bem_libEmitNameGet_0();
case 72694489: return bem_stringNpGet_0();
case -1588608331: return bem_iteratorGet_0();
case -1602918313: return bem_idToNamePathGet_0();
case 1161293428: return bem_classCallsGet_0();
case 95401045: return bem_preClassOutput_0();
case 1564374252: return bem_ccCacheGet_0();
case 1202859281: return bem_fieldIteratorGet_0();
case 1557144728: return bem_superNameGet_0();
case 2029762031: return bem_typeDecGet_0();
case 56079504: return bem_classEmitsGetDirect_0();
case -603645081: return bem_propertyDecsGet_0();
case 1380050120: return bem_maxSpillArgsLenGet_0();
case -2112752566: return bem_doEmit_0();
case 1110294080: return bem_nameToIdPathGet_0();
case -1627101286: return bem_many_0();
case -100814457: return bem_ntypesGetDirect_0();
case 582860610: return bem_methodBodyGet_0();
case 1512066816: return bem_getLibOutput_0();
case -1845643109: return bem_getClassOutput_0();
case -513219895: return bem_parentConfGetDirect_0();
case 786795891: return bem_cnodeGet_0();
case -4634496: return bem_once_0();
case 1246209306: return bem_buildGetDirect_0();
case -1111347317: return bem_gcMarksGetDirect_0();
case -1721224705: return bem_copy_0();
case -1556518060: return bem_saveSyns_0();
case 303589218: return bem_boolCcGetDirect_0();
case 419402773: return bem_fieldNamesGet_0();
case 2025123065: return bem_idToNamePathGetDirect_0();
case -479976948: return bem_classesInDepthOrderGetDirect_0();
case -1561631662: return bem_libEmitNameGetDirect_0();
case -353694220: return bem_constGet_0();
case 149646750: return bem_callNamesGet_0();
case -1865178957: return bem_idToNameGet_0();
case 1210303768: return bem_intNpGet_0();
case 242917326: return bem_mainOutsideNsGet_0();
case -459295076: return bem_propDecGet_0();
case -1927067601: return bem_instanceNotEqualGet_0();
case 868332592: return bem_superCallsGet_0();
case -314683662: return bem_trueValueGet_0();
case 1391064500: return bem_boolCcGet_0();
case -467957724: return bem_objectNpGetDirect_0();
case 1662643176: return bem_new_0();
case 1206855817: return bem_onceCountGet_0();
case -344629384: return bem_superCallsGetDirect_0();
case 1759078114: return bem_lastCallGet_0();
case -171689742: return bem_classCallsGetDirect_0();
case 2142058906: return bem_coanyiantReturnsGet_0();
case 1597561486: return bem_initialDecGet_0();
case 974008916: return bem_qGetDirect_0();
case 1839420530: return bem_mainStartGet_0();
case -497698315: return bem_smnlecsGetDirect_0();
case -1760283647: return bem_sourceFileNameGet_0();
case -1699295924: return bem_dynMethodsGet_0();
case 470691008: return bem_methodCatchGet_0();
case 147269736: return bem_preClassGet_0();
case -489591995: return bem_lastCallGetDirect_0();
case -1062799150: return bem_loadIds_0();
case -207635536: return bem_objectCcGet_0();
case 1761864287: return bem_lastMethodBodyLinesGetDirect_0();
case 742999095: return bem_mnodeGetDirect_0();
case 130322879: return bem_methodsGetDirect_0();
case 2111755914: return bem_inClassGet_0();
case -387900945: return bem_floatNpGetDirect_0();
case -115926348: return bem_nlGetDirect_0();
case 335195916: return bem_trueValueGetDirect_0();
case -1095636681: return bem_idToNameGetDirect_0();
case -872325961: return bem_classConfGet_0();
case 1394903963: return bem_maxSpillArgsLenGetDirect_0();
case -1521156245: return bem_instOfGetDirect_0();
case -910709803: return bem_falseValueGet_0();
case -982910531: return bem_floatNpGet_0();
case -1692893660: return bem_synEmitPathGetDirect_0();
case -1855742442: return bem_deserializeClassNameGet_0();
case 1191480107: return bem_randGetDirect_0();
case -144607300: return bem_emitLangGetDirect_0();
case -2075550655: return bem_maxDynArgsGetDirect_0();
case 521705053: return bem_afterCast_0();
case 272848921: return bem_lineCountGet_0();
case 323304959: return bem_fullLibEmitNameGet_0();
case 646945866: return bem_runtimeInitGet_0();
case -1885688168: return bem_scvpGetDirect_0();
case 1475961368: return bem_inFilePathedGetDirect_0();
case -1234434160: return bem_lineCountGetDirect_0();
case 737627600: return bem_classNameGet_0();
case -119541260: return bem_onceDecsGet_0();
case 595465554: return bem_msynGetDirect_0();
case -550587972: return bem_lastMethodBodyLinesGet_0();
case -659220089: return bem_onceCountGetDirect_0();
case -2124219423: return bem_methodsGet_0();
case -2028012180: return bem_randGet_0();
case 358183114: return bem_buildInitial_0();
case -1530362442: return bem_onceDecsGetDirect_0();
case 2098731743: return bem_dynMethodsGetDirect_0();
case 1501482800: return bem_stringNpGetDirect_0();
case -1060640173: return bem_fullLibEmitNameGetDirect_0();
case 459784483: return bem_fileExtGetDirect_0();
case -388340383: return bem_csynGetDirect_0();
case -362750095: return bem_nameToIdGetDirect_0();
case 854609813: return bem_mnodeGet_0();
case 939629729: return bem_lastMethodsLinesGet_0();
case 2035599254: return bem_endNs_0();
case 576221642: return bem_lastMethodsSizeGet_0();
case 939185730: return bem_buildGet_0();
case -1556234938: return bem_boolTypeGet_0();
case 1267836020: return bem_cnodeGetDirect_0();
case 586787044: return bem_toAny_0();
case 2116805682: return bem_fileExtGet_0();
case 211374093: return bem_boolNpGet_0();
case -1470992263: return bem_baseMtdDecGet_0();
case -165877765: return bem_create_0();
case -1842285567: return bem_useDynMethodsGet_0();
case -1915645260: return bem_baseSmtdDecGet_0();
case 835192816: return bem_methodCatchGetDirect_0();
case -1650946699: return bem_emitLib_0();
case 72488635: return bem_falseValueGetDirect_0();
case 1113228370: return bem_preClassGetDirect_0();
case -597701970: return bem_lastMethodBodySizeGetDirect_0();
case -511925450: return bem_buildClassInfo_0();
case -137209775: return bem_transGetDirect_0();
case -653168993: return bem_constGetDirect_0();
case -1178068153: return bem_invpGetDirect_0();
case -1287234058: return bem_instanceEqualGet_0();
case -494242792: return bem_overrideMtdDecGet_0();
case 276470433: return bem_exceptDecGet_0();
case 1800213309: return bem_serializeContents_0();
case 441265266: return bem_beginNs_0();
case -392511625: return bem_classesInDepthOrderGet_0();
case 981768014: return bem_mainInClassGet_0();
case 2032439951: return bem_smnlcsGet_0();
case -975986011: return bem_boolNpGetDirect_0();
case -695988398: return bem_inClassGetDirect_0();
case -511071132: return bem_spropDecGet_0();
case -252928832: return bem_classEmitsGet_0();
case 2039853873: return bem_writeBET_0();
case 1560728406: return bem_invpGet_0();
case -664128834: return bem_ccCacheGetDirect_0();
case -1761834400: return bem_gcMarksGet_0();
case -12708128: return bem_hashGet_0();
case -846048525: return bem_nativeCSlotsGet_0();
case -745232665: return bem_objectCcGetDirect_0();
case -169510412: return bem_toString_0();
case -1862621457: return bem_saveIds_0();
case 336704923: return bem_parentConfGet_0();
case -109234441: return bem_csynGet_0();
case -1566162686: return bem_lastMethodBodySizeGet_0();
case -993617581: return bem_buildCreate_0();
case 262231222: return bem_exceptDecGetDirect_0();
case -510558373: return bem_propertyDecsGetDirect_0();
case -1198649333: return bem_returnTypeGetDirect_0();
case 1515796479: return bem_returnTypeGet_0();
case -179811431: return bem_instanceNotEqualGetDirect_0();
case -1143466111: return bem_classConfGetDirect_0();
case -2059713661: return bem_transGet_0();
case -788364745: return bem_methodCallsGetDirect_0();
case 1816155455: return bem_ccMethodsGetDirect_0();
case -907262473: return bem_synEmitPathGet_0();
case 221369236: return bem_echo_0();
case -1397891100: return bem_methodBodyGetDirect_0();
case 1166902012: return bem_print_0();
case -9710743: return bem_objectNpGet_0();
case 1426087889: return bem_emitLangGet_0();
case 1550410170: return bem_mainEndGet_0();
case 1017932049: return bem_nativeCSlotsGetDirect_0();
case 732780796: return bem_nullValueGetDirect_0();
case 31598141: return bem_maxDynArgsGet_0();
case -1145946037: return bem_serializeToString_0();
case 1347630701: return bem_libEmitPathGetDirect_0();
case -1869540263: return bem_nullValueGet_0();
case 1722509898: return bem_libEmitPathGet_0();
case -458279913: return bem_serializationIteratorGet_0();
case -1200024888: return bem_tagGet_0();
case 1853279452: return bem_nlGet_0();
case 540632450: return bem_nameToIdPathGetDirect_0();
case 1054621592: return bem_ntypesGet_0();
case -1623059821: return bem_nameToIdGet_0();
case 192917752: return bem_intNpGetDirect_0();
case 2127277089: return bem_scvpGet_0();
case 2057711701: return bem_callNamesGetDirect_0();
case -445282875: return bem_inFilePathedGet_0();
case -1580484215: return bem_qGet_0();
case 994892288: return bem_smnlecsGet_0();
case -1637057300: return bem_lastMethodsSizeGetDirect_0();
case -1653153035: return bem_ccMethodsGet_0();
case 113219868: return bem_methodCallsGet_0();
case -471107257: return bem_instanceEqualGetDirect_0();
case -710568213: return bem_instOfGet_0();
case -1195198401: return bem_msynGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1322944702: return bem_classesInDepthOrderSet_1(bevd_0);
case 1520364034: return bem_trueValueSetDirect_1(bevd_0);
case 1819288759: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1936389329: return bem_msynSetDirect_1(bevd_0);
case 1689964653: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1819630603: return bem_methodCatchSetDirect_1(bevd_0);
case 987201415: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1143294403: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1802945522: return bem_objectNpSet_1(bevd_0);
case -399368056: return bem_libEmitPathSetDirect_1(bevd_0);
case -1486790811: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 938189990: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1989092718: return bem_nlSetDirect_1(bevd_0);
case 55240576: return bem_ccCacheSet_1(bevd_0);
case 2047027206: return bem_inClassSet_1(bevd_0);
case 764885426: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 100163209: return bem_exceptDecSetDirect_1(bevd_0);
case 1110395429: return bem_smnlcsSet_1(bevd_0);
case 2146235744: return bem_mnodeSet_1(bevd_0);
case -551560068: return bem_classConfSet_1(bevd_0);
case -39094467: return bem_equals_1(bevd_0);
case -1618710767: return bem_callNamesSetDirect_1(bevd_0);
case 1616376889: return bem_smnlcsSetDirect_1(bevd_0);
case -1288986837: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1693025540: return bem_onceCountSet_1(bevd_0);
case 1706157484: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1807364215: return bem_parentConfSetDirect_1(bevd_0);
case 1209838081: return bem_buildSet_1(bevd_0);
case -1617140536: return bem_defined_1(bevd_0);
case -474283486: return bem_constSetDirect_1(bevd_0);
case 1396222332: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1651797817: return bem_fileExtSet_1(bevd_0);
case -1034492196: return bem_stringNpSet_1(bevd_0);
case -726465964: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -43112724: return bem_lineCountSetDirect_1(bevd_0);
case -1694968514: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1265971461: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -2050626933: return bem_def_1(bevd_0);
case 1127647431: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 136184828: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1416118972: return bem_lastMethodBodySizeSet_1(bevd_0);
case -141782472: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -883889211: return bem_sameObject_1(bevd_0);
case -1704365736: return bem_inFilePathedSetDirect_1(bevd_0);
case 1162058423: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -247570810: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1793219583: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 2132180555: return bem_methodBodySet_1(bevd_0);
case 581506878: return bem_constSet_1(bevd_0);
case 446646701: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 791870347: return bem_invpSetDirect_1(bevd_0);
case 545784370: return bem_instOfSetDirect_1(bevd_0);
case -270678816: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1421424282: return bem_objectNpSetDirect_1(bevd_0);
case -2014335012: return bem_inFilePathedSet_1(bevd_0);
case 1951320212: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1486548250: return bem_cnodeSet_1(bevd_0);
case -347192012: return bem_callNamesSet_1(bevd_0);
case 1600111015: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -91912175: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -424219410: return bem_floatNpSet_1(bevd_0);
case -391905348: return bem_instanceEqualSet_1(bevd_0);
case 983144175: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 326094850: return bem_returnTypeSetDirect_1(bevd_0);
case 1268228847: return bem_lastMethodsSizeSet_1(bevd_0);
case 132724474: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 904038627: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1465608210: return bem_boolNpSetDirect_1(bevd_0);
case -1962509606: return bem_libEmitNameSet_1(bevd_0);
case 2029816561: return bem_qSet_1(bevd_0);
case 806739242: return bem_propertyDecsSet_1(bevd_0);
case -1562636847: return bem_dynMethodsSetDirect_1(bevd_0);
case -1475578133: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -254218891: return bem_methodCallsSet_1(bevd_0);
case -802514914: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -1960951718: return bem_methodsSet_1(bevd_0);
case 963552784: return bem_emitLangSetDirect_1(bevd_0);
case 1650003521: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1122974173: return bem_mnodeSetDirect_1(bevd_0);
case -708546940: return bem_methodCallsSetDirect_1(bevd_0);
case 69420446: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1776159439: return bem_fullLibEmitNameSet_1(bevd_0);
case 1725008072: return bem_buildSetDirect_1(bevd_0);
case -3837837: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1058481552: return bem_undef_1(bevd_0);
case 286179063: return bem_copyTo_1(bevd_0);
case -1932865217: return bem_boolNpSet_1(bevd_0);
case 445819062: return bem_transSet_1(bevd_0);
case -409899450: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1793503524: return bem_classCallsSet_1(bevd_0);
case -470700470: return bem_lastMethodsLinesSet_1(bevd_0);
case 384919535: return bem_instanceEqualSetDirect_1(bevd_0);
case -1563933337: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1029495916: return bem_nameToIdPathSetDirect_1(bevd_0);
case -467393701: return bem_superCallsSetDirect_1(bevd_0);
case 1396328003: return bem_otherClass_1(bevd_0);
case 1861777358: return bem_floatNpSetDirect_1(bevd_0);
case 1113875953: return bem_nativeCSlotsSet_1(bevd_0);
case 1300996026: return bem_smnlecsSetDirect_1(bevd_0);
case 709495499: return bem_libEmitNameSetDirect_1(bevd_0);
case -994087512: return bem_lastCallSet_1(bevd_0);
case 1069002684: return bem_nlSet_1(bevd_0);
case 258335862: return bem_ccMethodsSet_1(bevd_0);
case -306633068: return bem_undefined_1(bevd_0);
case -119189706: return bem_methodBodySetDirect_1(bevd_0);
case -1672157279: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1880368515: return bem_notEquals_1(bevd_0);
case -1370932579: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 358261798: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -675740584: return bem_boolCcSetDirect_1(bevd_0);
case 1493716971: return bem_libEmitPathSet_1(bevd_0);
case -559052675: return bem_exceptDecSet_1(bevd_0);
case 405456764: return bem_methodCatchSet_1(bevd_0);
case 244252646: return bem_csynSet_1(bevd_0);
case -833366957: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1335788945: return bem_scvpSetDirect_1(bevd_0);
case -1628869730: return bem_intNpSetDirect_1(bevd_0);
case 752789578: return bem_nullValueSet_1(bevd_0);
case -327804541: return bem_sameClass_1(bevd_0);
case -1556993688: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 704252345: return bem_cnodeSetDirect_1(bevd_0);
case -277133471: return bem_superCallsSet_1(bevd_0);
case 45250919: return bem_instanceNotEqualSet_1(bevd_0);
case 2008433664: return bem_gcMarksSetDirect_1(bevd_0);
case 1174135522: return bem_sameType_1(bevd_0);
case 1105338352: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1000720093: return bem_fileExtSetDirect_1(bevd_0);
case 1931852804: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 755887257: return bem_intNpSet_1(bevd_0);
case 1990443100: return bem_nameToIdPathSet_1(bevd_0);
case -996092370: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 401839231: return bem_idToNameSetDirect_1(bevd_0);
case 553606270: return bem_onceCountSetDirect_1(bevd_0);
case 525867578: return bem_qSetDirect_1(bevd_0);
case 1651232842: return bem_maxDynArgsSet_1(bevd_0);
case -1846429143: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1714373942: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -481622398: return bem_invpSet_1(bevd_0);
case -389055345: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1495601791: return bem_csynSetDirect_1(bevd_0);
case 2086963771: return bem_idToNameSet_1(bevd_0);
case 1057780314: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1152373374: return bem_synEmitPathSet_1(bevd_0);
case 1546990352: return bem_randSetDirect_1(bevd_0);
case 799464576: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1112090867: return bem_ccCacheSetDirect_1(bevd_0);
case -1913671571: return bem_preClassSetDirect_1(bevd_0);
case -105827489: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -522336170: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 2055336408: return bem_trueValueSet_1(bevd_0);
case -1551088579: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1013341233: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1491999499: return bem_lastCallSetDirect_1(bevd_0);
case 247975749: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 354761634: return bem_onceDecsSet_1(bevd_0);
case -309965282: return bem_falseValueSet_1(bevd_0);
case 1725086001: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1370505311: return bem_ntypesSet_1(bevd_0);
case -1879322390: return bem_inClassSetDirect_1(bevd_0);
case 143964122: return bem_msynSet_1(bevd_0);
case 1900841537: return bem_ccMethodsSetDirect_1(bevd_0);
case 391411053: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 782862832: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 119621604: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1166090576: return bem_transSetDirect_1(bevd_0);
case 2112027131: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1116577203: return bem_end_1(bevd_0);
case -1578461083: return bem_methodsSetDirect_1(bevd_0);
case -62789474: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1064363565: return bem_synEmitPathSetDirect_1(bevd_0);
case 476693313: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -409395627: return bem_idToNamePathSet_1(bevd_0);
case -1906002079: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -539267871: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1691066355: return bem_falseValueSetDirect_1(bevd_0);
case -1012390097: return bem_randSet_1(bevd_0);
case -1625505230: return bem_classConfSetDirect_1(bevd_0);
case 1805860734: return bem_begin_1(bevd_0);
case -1979116079: return bem_emitLangSet_1(bevd_0);
case -591380070: return bem_onceDecsSetDirect_1(bevd_0);
case 192526423: return bem_ntypesSetDirect_1(bevd_0);
case 720390236: return bem_nullValueSetDirect_1(bevd_0);
case -615350166: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1193521707: return bem_idToNamePathSetDirect_1(bevd_0);
case 1883996725: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1839126479: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 993208196: return bem_preClassSet_1(bevd_0);
case 1039180755: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1995527400: return bem_scvpSet_1(bevd_0);
case 35519170: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1855029601: return bem_nameToIdSet_1(bevd_0);
case 1075106586: return bem_objectCcSetDirect_1(bevd_0);
case 1703903046: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1289331095: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 233378828: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 1127120159: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1747720323: return bem_smnlecsSet_1(bevd_0);
case 505817994: return bem_classEmitsSet_1(bevd_0);
case 1534631981: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 67808698: return bem_objectCcSet_1(bevd_0);
case -2038137777: return bem_otherType_1(bevd_0);
case 824971765: return bem_parentConfSet_1(bevd_0);
case -1357866619: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1554251407: return bem_instOfSet_1(bevd_0);
case -1565569812: return bem_nameToIdSetDirect_1(bevd_0);
case -1246086623: return bem_dynMethodsSet_1(bevd_0);
case 1621576845: return bem_gcMarksSet_1(bevd_0);
case 1762361048: return bem_returnTypeSet_1(bevd_0);
case 598994785: return bem_lineCountSet_1(bevd_0);
case -1662912450: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -851506663: return bem_stringNpSetDirect_1(bevd_0);
case 179176223: return bem_classEmitsSetDirect_1(bevd_0);
case -1564495303: return bem_classCallsSetDirect_1(bevd_0);
case 956362021: return bem_boolCcSet_1(bevd_0);
case -455593465: return bem_propertyDecsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2008233122: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1776809505: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1666962597: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1835923968: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1853281410: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2013844302: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -549233499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1507293234: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -586529345: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1426080127: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2062617509: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 916702235: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 660425451: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1998827071: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 992175762: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1731663629: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 2126382926: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -136430353: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1983260459: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 2082824503: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -238374165: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1819010281: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -920308147: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 611009316: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1498015255: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -251738564: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 1012354528: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
