package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_19, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_22, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_30, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_31, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_32, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_33, 18));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_31, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_34, 9));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_35, 48));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 38));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_43, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_44, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_45, 3));
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(1587354648);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(1590161492);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(-920607504);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(1590161492);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(-920607504);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_41_ta_ph = bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_43_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_ta_ph = bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevt_40_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_45_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_47_ta_ph = bevl_bet.bem_addValue_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_46_ta_ph = bevt_47_ta_ph.bem_addValue_1(bevt_49_ta_ph);
bevt_50_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevt_46_ta_ph.bem_addValue_1(bevt_50_ta_ph);
bevt_51_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevl_tout.bemd_1(375025622, bevl_bet);
bevl_tout.bemd_0(-68577615);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevt_0_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1438444622);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(554933596);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, bevt_16_ta_ph);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_1_ta_ph = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
if (beva_msyn == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_3_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
return bevt_4_ta_ph;
} /* Line: 87*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 93*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 93*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 94*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_typeName);
bevt_3_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 122*/ {
bevt_5_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_exceptDec);
bevt_6_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevl_ms = bevt_3_ta_ph.bem_add_1(bevp_nl);
} /* Line: 123*/
 else /* Line: 124*/ {
bevt_9_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_exceptDec);
bevt_10_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_10_ta_ph);
bevl_ms = bevt_7_ta_ph.bem_add_1(bevp_nl);
} /* Line: 125*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_38));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_39));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_16_ta_ph = bevl_ms.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_20_ta_ph = bevl_ms.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(-1466994215);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_18_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_14;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_15;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_16;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_once_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 62, 62, 62, 62, 63, 63, 64, 64, 64, 64, 64, 64, 65, 65, 66, 66, 67, 67, 68, 69, 73, 73, 73, 74, 75, 75, 75, 75, 75, 75, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 82, 82, 86, 0, 86, 86, 86, 0, 0, 0, 0, 0, 87, 87, 89, 89, 93, 93, 93, 0, 0, 0, 94, 94, 96, 96, 100, 100, 104, 104, 104, 104, 104, 109, 110, 111, 111, 111, 112, 118, 118, 118, 118, 118, 118, 122, 122, 122, 123, 123, 123, 123, 123, 125, 125, 125, 125, 125, 127, 127, 127, 127, 127, 127, 128, 128, 128, 129, 129, 129, 129, 129, 129, 129, 129, 130, 134, 134, 134, 138, 138, 138, 138, 138, 138, 138, 142, 142, 146, 146, 146, 150, 150, 150, 150, 154, 154};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {75, 76, 77, 78, 142, 143, 144, 145, 150, 151, 152, 153, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 178, 181, 183, 185, 188, 189, 191, 192, 193, 194, 200, 201, 202, 203, 204, 205, 206, 207, 208, 208, 211, 213, 215, 218, 219, 221, 222, 223, 224, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 302, 303, 312, 314, 317, 322, 323, 325, 328, 332, 335, 338, 342, 343, 345, 346, 354, 359, 360, 362, 365, 369, 372, 373, 375, 376, 380, 381, 388, 389, 390, 391, 392, 398, 399, 400, 401, 402, 403, 412, 413, 414, 415, 416, 417, 446, 447, 448, 450, 451, 452, 453, 454, 457, 458, 459, 460, 461, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 485, 486, 487, 496, 497, 498, 499, 500, 501, 502, 506, 507, 512, 513, 514, 520, 521, 522, 523, 527, 528};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 75
new 0 16 75
assign 1 17 76
new 0 17 76
assign 1 18 77
new 0 18 77
new 1 22 78
assign 1 26 142
classDirGet 0 26 142
assign 1 26 143
fileGet 0 26 143
assign 1 26 144
existsGet 0 26 144
assign 1 26 145
not 0 26 150
assign 1 27 151
classDirGet 0 27 151
assign 1 27 152
fileGet 0 27 152
makeDirs 0 27 153
assign 1 29 155
typePathGet 0 29 155
assign 1 29 156
fileGet 0 29 156
assign 1 29 157
writerGet 0 29 157
assign 1 29 158
open 0 29 158
assign 1 30 159
new 0 30 159
assign 1 31 160
new 0 31 160
addValue 1 31 161
assign 1 32 162
new 0 32 162
assign 1 32 163
addValue 1 32 163
assign 1 32 164
typeEmitNameGet 0 32 164
assign 1 32 165
addValue 1 32 165
assign 1 32 166
new 0 32 166
addValue 1 32 167
assign 1 33 168
new 0 33 168
assign 1 33 169
addValue 1 33 169
assign 1 33 170
typeEmitNameGet 0 33 170
assign 1 33 171
addValue 1 33 171
assign 1 33 172
new 0 33 172
addValue 1 33 173
assign 1 35 174
new 0 35 174
addValue 1 35 175
assign 1 36 176
new 0 36 176
assign 1 37 177
mtdListGet 0 37 177
assign 1 37 178
iteratorGet 0 0 178
assign 1 37 181
hasNextGet 0 37 181
assign 1 37 183
nextGet 0 37 183
assign 1 39 185
new 0 39 185
assign 1 41 188
new 0 41 188
addValue 1 41 189
assign 1 43 191
addValue 1 43 191
assign 1 43 192
nameGet 0 43 192
assign 1 43 193
addValue 1 43 193
addValue 1 43 194
assign 1 45 200
new 0 45 200
addValue 1 45 201
assign 1 46 202
new 0 46 202
addValue 1 46 203
assign 1 48 204
new 0 48 204
addValue 1 48 205
assign 1 49 206
new 0 49 206
assign 1 50 207
ptyListGet 0 50 207
assign 1 50 208
iteratorGet 0 0 208
assign 1 50 211
hasNextGet 0 50 211
assign 1 50 213
nextGet 0 50 213
assign 1 52 215
new 0 52 215
assign 1 54 218
new 0 54 218
addValue 1 54 219
assign 1 56 221
addValue 1 56 221
assign 1 56 222
nameGet 0 56 222
assign 1 56 223
addValue 1 56 223
addValue 1 56 224
assign 1 58 230
new 0 58 230
addValue 1 58 231
assign 1 60 232
new 0 60 232
addValue 1 60 233
assign 1 62 234
new 0 62 234
assign 1 62 235
addValue 1 62 235
assign 1 62 236
typeEmitNameGet 0 62 236
assign 1 62 237
addValue 1 62 237
assign 1 62 238
new 0 62 238
addValue 1 62 239
assign 1 63 240
new 0 63 240
addValue 1 63 241
assign 1 64 242
new 0 64 242
assign 1 64 243
addValue 1 64 243
assign 1 64 244
emitNameGet 0 64 244
assign 1 64 245
addValue 1 64 245
assign 1 64 246
new 0 64 246
addValue 1 64 247
assign 1 65 248
new 0 65 248
addValue 1 65 249
assign 1 66 250
new 0 66 250
addValue 1 66 251
assign 1 67 252
new 0 67 252
addValue 1 67 253
write 1 68 254
close 0 69 255
assign 1 73 277
new 0 73 277
assign 1 73 278
toString 0 73 278
assign 1 73 279
add 1 73 279
incrementValue 0 74 280
assign 1 75 281
new 0 75 281
assign 1 75 282
addValue 1 75 282
assign 1 75 283
addValue 1 75 283
assign 1 75 284
new 0 75 284
assign 1 75 285
addValue 1 75 285
addValue 1 75 286
assign 1 77 287
containedGet 0 77 287
assign 1 77 288
firstGet 0 77 288
assign 1 77 289
containedGet 0 77 289
assign 1 77 290
firstGet 0 77 290
assign 1 77 291
new 0 77 291
assign 1 77 292
add 1 77 292
assign 1 77 293
new 0 77 293
assign 1 77 294
add 1 77 294
assign 1 77 295
new 0 77 295
assign 1 77 296
finalAssign 4 77 296
addValue 1 77 297
assign 1 82 302
new 0 82 302
return 1 82 303
assign 1 86 312
isFinalGet 0 86 312
assign 1 0 314
assign 1 86 317
def 1 86 322
assign 1 86 323
isFinalGet 0 86 323
assign 1 0 325
assign 1 0 328
assign 1 0 332
assign 1 0 335
assign 1 0 338
assign 1 87 342
new 0 87 342
return 1 87 343
assign 1 89 345
new 0 89 345
return 1 89 346
assign 1 93 354
def 1 93 359
assign 1 93 360
isFinalGet 0 93 360
assign 1 0 362
assign 1 0 365
assign 1 0 369
assign 1 94 372
new 0 94 372
return 1 94 373
assign 1 96 375
new 0 96 375
return 1 96 376
assign 1 100 380
new 0 100 380
return 1 100 381
assign 1 104 388
new 0 104 388
assign 1 104 389
add 1 104 389
assign 1 104 390
new 0 104 390
assign 1 104 391
add 1 104 391
return 1 104 392
getCode 2 109 398
assign 1 110 399
toHexString 1 110 399
assign 1 111 400
new 0 111 400
assign 1 111 401
once 0 111 401
addValue 1 111 402
addValue 1 112 403
assign 1 118 412
new 0 118 412
assign 1 118 413
add 1 118 413
assign 1 118 414
new 0 118 414
assign 1 118 415
add 1 118 415
assign 1 118 416
add 1 118 416
return 1 118 417
assign 1 122 446
emitChecksGet 0 122 446
assign 1 122 447
new 0 122 447
assign 1 122 448
has 1 122 448
assign 1 123 450
new 0 123 450
assign 1 123 451
add 1 123 451
assign 1 123 452
new 0 123 452
assign 1 123 453
add 1 123 453
assign 1 123 454
add 1 123 454
assign 1 125 457
new 0 125 457
assign 1 125 458
add 1 125 458
assign 1 125 459
new 0 125 459
assign 1 125 460
add 1 125 460
assign 1 125 461
add 1 125 461
assign 1 127 463
new 0 127 463
assign 1 127 464
addValue 1 127 464
assign 1 127 465
addValue 1 127 465
assign 1 127 466
new 0 127 466
assign 1 127 467
addValue 1 127 467
addValue 1 127 468
assign 1 128 469
new 0 128 469
assign 1 128 470
addValue 1 128 470
addValue 1 128 471
assign 1 129 472
new 0 129 472
assign 1 129 473
addValue 1 129 473
assign 1 129 474
outputPlatformGet 0 129 474
assign 1 129 475
nameGet 0 129 475
assign 1 129 476
addValue 1 129 476
assign 1 129 477
new 0 129 477
assign 1 129 478
addValue 1 129 478
addValue 1 129 479
return 1 130 480
assign 1 134 485
libNameGet 0 134 485
assign 1 134 486
beginNs 1 134 486
return 1 134 487
assign 1 138 496
new 0 138 496
assign 1 138 497
libNs 1 138 497
assign 1 138 498
add 1 138 498
assign 1 138 499
new 0 138 499
assign 1 138 500
add 1 138 500
assign 1 138 501
add 1 138 501
return 1 138 502
assign 1 142 506
getNameSpace 1 142 506
return 1 142 507
assign 1 146 512
new 0 146 512
assign 1 146 513
add 1 146 513
return 1 146 514
assign 1 150 520
new 0 150 520
assign 1 150 521
once 0 150 521
assign 1 150 522
add 1 150 522
return 1 150 523
assign 1 154 527
new 0 154 527
return 1 154 528
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1046717763: return bem_methodBodyGet_0();
case 1519459694: return bem_objectNpGetDirect_0();
case 828383831: return bem_nativeCSlotsGet_0();
case -75143440: return bem_mainInClassGet_0();
case -918723286: return bem_doEmit_0();
case 672276188: return bem_ntypesGetDirect_0();
case -820351971: return bem_classesInDepthOrderGetDirect_0();
case 1205388540: return bem_buildClassInfo_0();
case -362000157: return bem_intNpGetDirect_0();
case 1977163123: return bem_fileExtGetDirect_0();
case 1606420959: return bem_msynGet_0();
case 1217468837: return bem_callNamesGetDirect_0();
case -869420358: return bem_preClassOutput_0();
case 659349905: return bem_mnodeGetDirect_0();
case 1069096625: return bem_dynMethodsGetDirect_0();
case 137910263: return bem_create_0();
case -620614080: return bem_lineCountGetDirect_0();
case 1641812593: return bem_exceptDecGetDirect_0();
case 834482789: return bem_intNpGet_0();
case -406257483: return bem_synEmitPathGet_0();
case 1493187172: return bem_writeBET_0();
case -908282920: return bem_nameToIdPathGet_0();
case 1700435208: return bem_invpGet_0();
case 1794199242: return bem_classEmitsGetDirect_0();
case 384814434: return bem_methodsGetDirect_0();
case 1885384827: return bem_superNameGet_0();
case 1451965504: return bem_ccCacheGet_0();
case -1331626162: return bem_iteratorGet_0();
case -1605201356: return bem_propertyDecsGetDirect_0();
case -603142291: return bem_idToNameGet_0();
case -1395149456: return bem_transGetDirect_0();
case 1826305290: return bem_classEndGet_0();
case -1869944915: return bem_classCallsGetDirect_0();
case -845124189: return bem_instanceNotEqualGet_0();
case 372589172: return bem_invpGetDirect_0();
case -2043428804: return bem_floatNpGet_0();
case 193089954: return bem_smnlcsGet_0();
case -438289515: return bem_fieldIteratorGet_0();
case -1747502704: return bem_afterCast_0();
case -860196824: return bem_buildCreate_0();
case 1207260241: return bem_methodBodyGetDirect_0();
case 2005841751: return bem_typeDecGet_0();
case -218161500: return bem_callNamesGet_0();
case -1619539148: return bem_belslitsGet_0();
case 204243904: return bem_stringNpGet_0();
case -1056902464: return bem_preClassGet_0();
case 1613730630: return bem_newDecGet_0();
case 693018734: return bem_floatNpGetDirect_0();
case 702542166: return bem_smnlecsGetDirect_0();
case 1712713465: return bem_instOfGet_0();
case 1970107535: return bem_buildGet_0();
case 937983694: return bem_constGet_0();
case -424779711: return bem_lastCallGetDirect_0();
case -777537417: return bem_serializeContents_0();
case 185385628: return bem_nlGet_0();
case -1999162578: return bem_lastMethodBodyLinesGet_0();
case 1661934469: return bem_boolCcGetDirect_0();
case 993286746: return bem_echo_0();
case -1111856686: return bem_fullLibEmitNameGet_0();
case 1457589191: return bem_classConfGet_0();
case 1404738077: return bem_libEmitNameGetDirect_0();
case 1629982988: return bem_objectNpGet_0();
case -1851472893: return bem_once_0();
case -450462736: return bem_mainStartGet_0();
case -882112661: return bem_instOfGetDirect_0();
case -335567572: return bem_returnTypeGetDirect_0();
case -1431137521: return bem_endNs_0();
case -83966654: return bem_methodCatchGetDirect_0();
case -201075975: return bem_randGetDirect_0();
case 1341165620: return bem_libEmitNameGet_0();
case 1104918192: return bem_falseValueGetDirect_0();
case -1301386048: return bem_boolCcGet_0();
case -1985402758: return bem_parentConfGet_0();
case -1989796995: return bem_getLibOutput_0();
case -645726471: return bem_emitLib_0();
case -1625508727: return bem_onceDecsGetDirect_0();
case -1392846471: return bem_toString_0();
case -1110773117: return bem_lastMethodBodyLinesGetDirect_0();
case -1507565680: return bem_onceCountGet_0();
case 953942877: return bem_ccMethodsGet_0();
case -2138663377: return bem_useDynMethodsGet_0();
case -1535153980: return bem_synEmitPathGetDirect_0();
case -439784890: return bem_mainOutsideNsGet_0();
case 78414811: return bem_covariantReturnsGet_0();
case 442798817: return bem_propDecGet_0();
case -1264117282: return bem_maxDynArgsGetDirect_0();
case -1354916839: return bem_spropDecGet_0();
case 1268113165: return bem_inFilePathedGet_0();
case 785045001: return bem_cnodeGet_0();
case -1921892238: return bem_lastCallGet_0();
case 1197537021: return bem_methodCallsGetDirect_0();
case -1238524057: return bem_print_0();
case -526483754: return bem_maxSpillArgsLenGetDirect_0();
case 1422899281: return bem_emitLangGet_0();
case -326464737: return bem_ntypesGet_0();
case -55295116: return bem_qGetDirect_0();
case -153654110: return bem_buildGetDirect_0();
case -718832253: return bem_maxSpillArgsLenGet_0();
case 1001921567: return bem_ccMethodsGetDirect_0();
case -525084973: return bem_falseValueGet_0();
case -2058283164: return bem_instanceNotEqualGetDirect_0();
case 1017386308: return bem_lastMethodsSizeGet_0();
case 1961218157: return bem_lastMethodsLinesGet_0();
case -1613648329: return bem_maxDynArgsGet_0();
case 607235161: return bem_classCallsGet_0();
case -1895487023: return bem_onceCountGetDirect_0();
case -1058614328: return bem_methodsGet_0();
case 177141642: return bem_stringNpGetDirect_0();
case -1876949789: return bem_nullValueGetDirect_0();
case -719224621: return bem_nlGetDirect_0();
case -258464144: return bem_inFilePathedGetDirect_0();
case -1962052042: return bem_getClassOutput_0();
case -1238805393: return bem_mnodeGet_0();
case 510614876: return bem_transGet_0();
case -1235763740: return bem_nameToIdGet_0();
case 572362560: return bem_libEmitPathGet_0();
case 1176619329: return bem_lineCountGet_0();
case -1961382070: return bem_classConfGetDirect_0();
case 47115430: return bem_nameToIdPathGetDirect_0();
case -1708048790: return bem_smnlecsGet_0();
case 1238296080: return bem_trueValueGet_0();
case -1278696412: return bem_inClassGetDirect_0();
case 164617051: return bem_parentConfGetDirect_0();
case 2071247075: return bem_sourceFileNameGet_0();
case 933779194: return bem_lastMethodsLinesGetDirect_0();
case -1194597859: return bem_baseMtdDecGet_0();
case -1363838810: return bem_saveIds_0();
case -1002308123: return bem_trueValueGetDirect_0();
case -193252123: return bem_nullValueGet_0();
case 1179843445: return bem_objectCcGetDirect_0();
case -516247704: return bem_libEmitPathGetDirect_0();
case 217381802: return bem_serializationIteratorGet_0();
case 78412540: return bem_toAny_0();
case -532496770: return bem_smnlcsGetDirect_0();
case 1300692362: return bem_instanceEqualGetDirect_0();
case -823370956: return bem_inClassGet_0();
case 986908350: return bem_cnodeGetDirect_0();
case 885554047: return bem_classesInDepthOrderGet_0();
case 205150354: return bem_new_0();
case -769837486: return bem_fullLibEmitNameGetDirect_0();
case -145122790: return bem_emitLangGetDirect_0();
case -2080035837: return bem_beginNs_0();
case -1963559587: return bem_msynGetDirect_0();
case 645505490: return bem_nameToIdGetDirect_0();
case 2142972419: return bem_idToNamePathGet_0();
case 472682502: return bem_loadIds_0();
case -414560184: return bem_fileExtGet_0();
case 1007224586: return bem_ccCacheGetDirect_0();
case -332907294: return bem_saveSyns_0();
case -1164548960: return bem_preClassGetDirect_0();
case -2122233492: return bem_randGet_0();
case -912342775: return bem_deserializeClassNameGet_0();
case -54085675: return bem_nativeCSlotsGetDirect_0();
case 1218125805: return bem_csynGet_0();
case -456436639: return bem_classEmitsGet_0();
case -1071513765: return bem_objectCcGet_0();
case 352466801: return bem_qGet_0();
case -774371033: return bem_initialDecGet_0();
case 953209494: return bem_idToNamePathGetDirect_0();
case -1585736888: return bem_overrideMtdDecGet_0();
case -859655458: return bem_returnTypeGet_0();
case -1467182466: return bem_baseSmtdDecGet_0();
case -1254904099: return bem_instanceEqualGet_0();
case -1714583788: return bem_classNameGet_0();
case -1461580874: return bem_idToNameGetDirect_0();
case -992634121: return bem_tagGet_0();
case -1089967893: return bem_constGetDirect_0();
case 565103657: return bem_gcMarksGet_0();
case 1742508650: return bem_lastMethodsSizeGetDirect_0();
case -2113516412: return bem_csynGetDirect_0();
case 310047227: return bem_fieldNamesGet_0();
case 365952395: return bem_methodCatchGet_0();
case 1520120194: return bem_onceDecsGet_0();
case 943856171: return bem_boolNpGet_0();
case 997500928: return bem_dynMethodsGet_0();
case -190723875: return bem_gcMarksGetDirect_0();
case -1862205784: return bem_methodCallsGet_0();
case 1323985918: return bem_superCallsGet_0();
case -887111122: return bem_mainEndGet_0();
case -1426056679: return bem_hashGet_0();
case -2119510326: return bem_runtimeInitGet_0();
case -1171812394: return bem_belslitsGetDirect_0();
case -1079456517: return bem_many_0();
case 814015164: return bem_copy_0();
case 1258174558: return bem_scvpGetDirect_0();
case 202297885: return bem_lastMethodBodySizeGet_0();
case -1533476030: return bem_propertyDecsGet_0();
case -829835098: return bem_exceptDecGet_0();
case 1029276668: return bem_boolTypeGet_0();
case 221458969: return bem_serializeToString_0();
case 1282616203: return bem_boolNpGetDirect_0();
case -1819505155: return bem_lastMethodBodySizeGetDirect_0();
case -1318406139: return bem_superCallsGetDirect_0();
case -497056812: return bem_buildInitial_0();
case 300187548: return bem_scvpGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 378883791: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case -342772452: return bem_stringNpSet_1(bevd_0);
case 1136451556: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1101595942: return bem_onceCountSet_1(bevd_0);
case -1986999393: return bem_classCallsSet_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case -1366602798: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case -728366131: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1173755279: return bem_exceptDecSet_1(bevd_0);
case 8184468: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1180588792: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1861218587: return bem_onceDecsSetDirect_1(bevd_0);
case -1682367854: return bem_maxDynArgsSet_1(bevd_0);
case 346473127: return bem_lastCallSet_1(bevd_0);
case 1879895819: return bem_nlSet_1(bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 941730112: return bem_mnodeSet_1(bevd_0);
case -1603077067: return bem_fileExtSetDirect_1(bevd_0);
case 1584555266: return bem_classCallsSetDirect_1(bevd_0);
case 1353922114: return bem_intNpSetDirect_1(bevd_0);
case -1447599817: return bem_belslitsSet_1(bevd_0);
case -470475204: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -132544912: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -514206489: return bem_nameToIdPathSetDirect_1(bevd_0);
case -1092387618: return bem_csynSetDirect_1(bevd_0);
case -1062142638: return bem_invpSet_1(bevd_0);
case -1205991882: return bem_preClassSetDirect_1(bevd_0);
case 2095263965: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1244820797: return bem_classConfSetDirect_1(bevd_0);
case 728661308: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 911729482: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -2102760263: return bem_gcMarksSet_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case -2000955315: return bem_ntypesSet_1(bevd_0);
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -949622973: return bem_gcMarksSetDirect_1(bevd_0);
case 1539422637: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1089308730: return bem_objectCcSetDirect_1(bevd_0);
case -1592971360: return bem_methodsSet_1(bevd_0);
case 1184974648: return bem_parentConfSet_1(bevd_0);
case 938898736: return bem_libEmitNameSetDirect_1(bevd_0);
case 1899347097: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1992336703: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1474651929: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1260317704: return bem_instanceNotEqualSet_1(bevd_0);
case -843559518: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -1937725837: return bem_ntypesSetDirect_1(bevd_0);
case 676837939: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 589610073: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1360156734: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1956063776: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -2082250551: return bem_buildSetDirect_1(bevd_0);
case -1411324051: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 1728325760: return bem_cnodeSetDirect_1(bevd_0);
case 66334901: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 868401302: return bem_objectNpSet_1(bevd_0);
case 504735193: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1427835584: return bem_callNamesSet_1(bevd_0);
case -710057537: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -94195511: return bem_floatNpSet_1(bevd_0);
case -933403863: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1705380654: return bem_instOfSet_1(bevd_0);
case 1911286374: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -431561426: return bem_intNpSet_1(bevd_0);
case 1357743951: return bem_lastCallSetDirect_1(bevd_0);
case 1393443099: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -869061172: return bem_libEmitPathSet_1(bevd_0);
case -831681449: return bem_emitLangSet_1(bevd_0);
case -1932002602: return bem_superCallsSetDirect_1(bevd_0);
case 1193774778: return bem_csynSet_1(bevd_0);
case 1951745260: return bem_buildSet_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1573226169: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -1582155709: return bem_idToNameSet_1(bevd_0);
case 481317701: return bem_maxSpillArgsLenSet_1(bevd_0);
case 706373084: return bem_lastMethodsLinesSet_1(bevd_0);
case -1170667806: return bem_methodBodySet_1(bevd_0);
case -753481537: return bem_emitLangSetDirect_1(bevd_0);
case -1745490837: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1940868841: return bem_end_1(bevd_0);
case 2001805956: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1237772552: return bem_trueValueSetDirect_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 605643232: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -871395257: return bem_lineCountSetDirect_1(bevd_0);
case 1234620633: return bem_methodBodySetDirect_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 168029434: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 892209748: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1274381880: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -276354032: return bem_fileExtSet_1(bevd_0);
case -1025693061: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -299515043: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1512520847: return bem_boolCcSetDirect_1(bevd_0);
case 244326965: return bem_smnlcsSetDirect_1(bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 99545477: return bem_methodsSetDirect_1(bevd_0);
case 234668161: return bem_trueValueSet_1(bevd_0);
case 1581873864: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1113494976: return bem_instOfSetDirect_1(bevd_0);
case -1955753813: return bem_smnlcsSet_1(bevd_0);
case 1694628305: return bem_lineCountSet_1(bevd_0);
case -393227721: return bem_belslitsSetDirect_1(bevd_0);
case 33252661: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 641561452: return bem_returnTypeSetDirect_1(bevd_0);
case 1514131893: return bem_inFilePathedSetDirect_1(bevd_0);
case -1560409476: return bem_nlSetDirect_1(bevd_0);
case 151071212: return bem_cnodeSet_1(bevd_0);
case 1036436633: return bem_boolNpSetDirect_1(bevd_0);
case -493523403: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -876015807: return bem_returnTypeSet_1(bevd_0);
case 196010712: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1041570556: return bem_libEmitNameSet_1(bevd_0);
case 631246336: return bem_nameToIdSetDirect_1(bevd_0);
case 825562062: return bem_begin_1(bevd_0);
case 745700446: return bem_nullValueSet_1(bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 1033088226: return bem_msynSetDirect_1(bevd_0);
case 1306022547: return bem_randSetDirect_1(bevd_0);
case -202882393: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -2049901118: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1584506132: return bem_falseValueSetDirect_1(bevd_0);
case 64214601: return bem_invpSetDirect_1(bevd_0);
case -1647571007: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1344892717: return bem_methodCallsSet_1(bevd_0);
case -2127742899: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 652191028: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 342514348: return bem_qSetDirect_1(bevd_0);
case -1175203118: return bem_dynMethodsSet_1(bevd_0);
case -649543299: return bem_mnodeSetDirect_1(bevd_0);
case 718721846: return bem_objectCcSet_1(bevd_0);
case -1810059571: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 106909158: return bem_dynMethodsSetDirect_1(bevd_0);
case -222025979: return bem_instanceEqualSetDirect_1(bevd_0);
case -1326548703: return bem_methodCatchSet_1(bevd_0);
case 1742273154: return bem_nativeCSlotsSet_1(bevd_0);
case 718750482: return bem_boolNpSet_1(bevd_0);
case -1079775175: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1535206907: return bem_inClassSetDirect_1(bevd_0);
case -1607876714: return bem_propertyDecsSetDirect_1(bevd_0);
case -1445264681: return bem_msynSet_1(bevd_0);
case 1937746355: return bem_callNamesSetDirect_1(bevd_0);
case 1537061968: return bem_ccCacheSetDirect_1(bevd_0);
case 701830097: return bem_onceCountSetDirect_1(bevd_0);
case -330800921: return bem_constSet_1(bevd_0);
case 1158869521: return bem_idToNamePathSet_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case -1982568518: return bem_boolCcSet_1(bevd_0);
case -1606284993: return bem_classEmitsSetDirect_1(bevd_0);
case 1495160492: return bem_objectNpSetDirect_1(bevd_0);
case 647339748: return bem_idToNamePathSetDirect_1(bevd_0);
case -2031804704: return bem_nameToIdSet_1(bevd_0);
case -1798970900: return bem_qSet_1(bevd_0);
case -980253590: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1701970019: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -1870343797: return bem_ccCacheSet_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2063679703: return bem_nullValueSetDirect_1(bevd_0);
case -162344954: return bem_inClassSet_1(bevd_0);
case -537395028: return bem_classConfSet_1(bevd_0);
case 1208971617: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -480748296: return bem_randSet_1(bevd_0);
case 421260340: return bem_libEmitPathSetDirect_1(bevd_0);
case 806337076: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 327436808: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -2048845874: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -494259956: return bem_classesInDepthOrderSet_1(bevd_0);
case -618271449: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 790409187: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1346849927: return bem_instanceEqualSet_1(bevd_0);
case 1012724839: return bem_ccMethodsSetDirect_1(bevd_0);
case -1180981290: return bem_falseValueSet_1(bevd_0);
case -338272228: return bem_constSetDirect_1(bevd_0);
case -1528951050: return bem_exceptDecSetDirect_1(bevd_0);
case -521597284: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1158365808: return bem_lastMethodsSizeSet_1(bevd_0);
case -927894364: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 107531311: return bem_nameToIdPathSet_1(bevd_0);
case 1578621634: return bem_synEmitPathSetDirect_1(bevd_0);
case -390885544: return bem_preClassSet_1(bevd_0);
case -1668253136: return bem_methodCatchSetDirect_1(bevd_0);
case 392972078: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 2000472478: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 528386464: return bem_parentConfSetDirect_1(bevd_0);
case -1854355989: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 140525627: return bem_idToNameSetDirect_1(bevd_0);
case 1201355195: return bem_transSet_1(bevd_0);
case 705819859: return bem_stringNpSetDirect_1(bevd_0);
case 633692296: return bem_floatNpSetDirect_1(bevd_0);
case 2016828595: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1443331050: return bem_inFilePathedSet_1(bevd_0);
case 75691458: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1431240056: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1071724764: return bem_scvpSetDirect_1(bevd_0);
case 1885003829: return bem_methodCallsSetDirect_1(bevd_0);
case -1825201950: return bem_smnlecsSetDirect_1(bevd_0);
case 1696941349: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1299519919: return bem_superCallsSet_1(bevd_0);
case 463136963: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1991549471: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2113344414: return bem_ccMethodsSet_1(bevd_0);
case -658216923: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 2028409201: return bem_transSetDirect_1(bevd_0);
case 5951747: return bem_smnlecsSet_1(bevd_0);
case 1172121883: return bem_propertyDecsSet_1(bevd_0);
case 714514876: return bem_onceDecsSet_1(bevd_0);
case 127090300: return bem_fullLibEmitNameSet_1(bevd_0);
case 1853376457: return bem_classEmitsSet_1(bevd_0);
case 196858757: return bem_scvpSet_1(bevd_0);
case -394183749: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 1017091822: return bem_synEmitPathSet_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -939456286: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1987696951: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -132992163: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1207999347: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2141384048: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1612553505: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -455337611: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1872831782: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -992670976: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1592505593: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -54124074: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1682927952: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 918452494: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 697747791: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -2099708550: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1358923: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1689658789: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 2116209554: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1315809758: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 65892281: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 673323908: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2111537599: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1187160708: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
