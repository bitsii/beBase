package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_24, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_33, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_34, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_35, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_38, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_45, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_46 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_46, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_47 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_47, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_48 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_48, 3));
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
bevt_4_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_existsGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_6_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_9_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_7_tmpany_phold.bemd_0(362530552);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_12_tmpany_phold = bevl_bet.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_17_tmpany_phold = bevl_bet.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_16_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_21_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_22_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_22_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-253989360);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-1101915058);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_24_tmpany_phold);
} /* Line: 42 */
bevt_26_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_27_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevt_32_tmpany_phold = bevl_bet.bem_addValue_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_31_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_36_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevt_38_tmpany_phold = bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_37_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
bevl_tout.bemd_1(1920320664, bevl_bet);
bevl_tout.bemd_0(2089446489);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-756181446);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1162828276);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_tmpany_phold;
} /* Line: 75 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
return bevt_3_tmpany_phold;
} /* Line: 82 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-121133516);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 48, 48, 50, 50, 50, 50, 50, 50, 51, 51, 52, 52, 52, 52, 52, 52, 53, 53, 54, 54, 55, 55, 56, 57, 61, 61, 61, 62, 63, 63, 63, 63, 63, 63, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 70, 70, 74, 0, 74, 74, 74, 0, 0, 0, 0, 0, 75, 75, 77, 77, 81, 81, 81, 0, 0, 0, 82, 82, 84, 84, 88, 88, 92, 92, 92, 92, 92, 97, 98, 99, 99, 99, 100, 106, 106, 106, 106, 106, 106, 110, 110, 110, 110, 110, 111, 111, 111, 111, 111, 111, 112, 112, 112, 113, 113, 113, 113, 113, 113, 113, 113, 114, 118, 118, 118, 122, 122, 122, 122, 122, 122, 122, 126, 126, 130, 130, 130, 134, 134, 134, 134, 138, 138};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {75, 76, 77, 78, 131, 132, 133, 134, 139, 140, 141, 142, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 167, 170, 172, 174, 177, 178, 180, 181, 182, 183, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 263, 264, 273, 275, 278, 283, 284, 286, 289, 293, 296, 299, 303, 304, 306, 307, 315, 320, 321, 323, 326, 330, 333, 334, 336, 337, 341, 342, 349, 350, 351, 352, 353, 359, 360, 361, 362, 363, 364, 373, 374, 375, 376, 377, 378, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 427, 428, 429, 438, 439, 440, 441, 442, 443, 444, 448, 449, 454, 455, 456, 462, 463, 464, 465, 469, 470};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 75
new 0 17 75
assign 1 18 76
new 0 18 76
assign 1 19 77
new 0 19 77
new 1 23 78
assign 1 27 131
classDirGet 0 27 131
assign 1 27 132
fileGet 0 27 132
assign 1 27 133
existsGet 0 27 133
assign 1 27 134
not 0 27 139
assign 1 28 140
classDirGet 0 28 140
assign 1 28 141
fileGet 0 28 141
makeDirs 0 28 142
assign 1 30 144
typePathGet 0 30 144
assign 1 30 145
fileGet 0 30 145
assign 1 30 146
writerGet 0 30 146
assign 1 30 147
open 0 30 147
assign 1 31 148
new 0 31 148
assign 1 32 149
new 0 32 149
addValue 1 32 150
assign 1 33 151
new 0 33 151
assign 1 33 152
addValue 1 33 152
assign 1 33 153
typeEmitNameGet 0 33 153
assign 1 33 154
addValue 1 33 154
assign 1 33 155
new 0 33 155
addValue 1 33 156
assign 1 34 157
new 0 34 157
assign 1 34 158
addValue 1 34 158
assign 1 34 159
typeEmitNameGet 0 34 159
assign 1 34 160
addValue 1 34 160
assign 1 34 161
new 0 34 161
addValue 1 34 162
assign 1 36 163
new 0 36 163
addValue 1 36 164
assign 1 37 165
new 0 37 165
assign 1 38 166
mtdListGet 0 38 166
assign 1 38 167
iteratorGet 0 0 167
assign 1 38 170
hasNextGet 0 38 170
assign 1 38 172
nextGet 0 38 172
assign 1 40 174
new 0 40 174
assign 1 42 177
new 0 42 177
addValue 1 42 178
assign 1 44 180
addValue 1 44 180
assign 1 44 181
nameGet 0 44 181
assign 1 44 182
addValue 1 44 182
addValue 1 44 183
assign 1 46 189
new 0 46 189
addValue 1 46 190
assign 1 47 191
new 0 47 191
addValue 1 47 192
assign 1 48 193
new 0 48 193
addValue 1 48 194
assign 1 50 195
new 0 50 195
assign 1 50 196
addValue 1 50 196
assign 1 50 197
typeEmitNameGet 0 50 197
assign 1 50 198
addValue 1 50 198
assign 1 50 199
new 0 50 199
addValue 1 50 200
assign 1 51 201
new 0 51 201
addValue 1 51 202
assign 1 52 203
new 0 52 203
assign 1 52 204
addValue 1 52 204
assign 1 52 205
emitNameGet 0 52 205
assign 1 52 206
addValue 1 52 206
assign 1 52 207
new 0 52 207
addValue 1 52 208
assign 1 53 209
new 0 53 209
addValue 1 53 210
assign 1 54 211
new 0 54 211
addValue 1 54 212
assign 1 55 213
new 0 55 213
addValue 1 55 214
write 1 56 215
close 0 57 216
assign 1 61 238
new 0 61 238
assign 1 61 239
toString 0 61 239
assign 1 61 240
add 1 61 240
incrementValue 0 62 241
assign 1 63 242
new 0 63 242
assign 1 63 243
addValue 1 63 243
assign 1 63 244
addValue 1 63 244
assign 1 63 245
new 0 63 245
assign 1 63 246
addValue 1 63 246
addValue 1 63 247
assign 1 65 248
containedGet 0 65 248
assign 1 65 249
firstGet 0 65 249
assign 1 65 250
containedGet 0 65 250
assign 1 65 251
firstGet 0 65 251
assign 1 65 252
new 0 65 252
assign 1 65 253
add 1 65 253
assign 1 65 254
new 0 65 254
assign 1 65 255
add 1 65 255
assign 1 65 256
new 0 65 256
assign 1 65 257
finalAssign 4 65 257
addValue 1 65 258
assign 1 70 263
new 0 70 263
return 1 70 264
assign 1 74 273
isFinalGet 0 74 273
assign 1 0 275
assign 1 74 278
def 1 74 283
assign 1 74 284
isFinalGet 0 74 284
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 0 296
assign 1 0 299
assign 1 75 303
new 0 75 303
return 1 75 304
assign 1 77 306
new 0 77 306
return 1 77 307
assign 1 81 315
def 1 81 320
assign 1 81 321
isFinalGet 0 81 321
assign 1 0 323
assign 1 0 326
assign 1 0 330
assign 1 82 333
new 0 82 333
return 1 82 334
assign 1 84 336
new 0 84 336
return 1 84 337
assign 1 88 341
new 0 88 341
return 1 88 342
assign 1 92 349
new 0 92 349
assign 1 92 350
add 1 92 350
assign 1 92 351
new 0 92 351
assign 1 92 352
add 1 92 352
return 1 92 353
getCode 2 97 359
assign 1 98 360
toHexString 1 98 360
assign 1 99 361
new 0 99 361
assign 1 99 362
once 0 99 362
addValue 1 99 363
addValue 1 100 364
assign 1 106 373
new 0 106 373
assign 1 106 374
add 1 106 374
assign 1 106 375
new 0 106 375
assign 1 106 376
add 1 106 376
assign 1 106 377
add 1 106 377
return 1 106 378
assign 1 110 400
new 0 110 400
assign 1 110 401
add 1 110 401
assign 1 110 402
new 0 110 402
assign 1 110 403
add 1 110 403
assign 1 110 404
add 1 110 404
assign 1 111 405
new 0 111 405
assign 1 111 406
addValue 1 111 406
assign 1 111 407
addValue 1 111 407
assign 1 111 408
new 0 111 408
assign 1 111 409
addValue 1 111 409
addValue 1 111 410
assign 1 112 411
new 0 112 411
assign 1 112 412
addValue 1 112 412
addValue 1 112 413
assign 1 113 414
new 0 113 414
assign 1 113 415
addValue 1 113 415
assign 1 113 416
outputPlatformGet 0 113 416
assign 1 113 417
nameGet 0 113 417
assign 1 113 418
addValue 1 113 418
assign 1 113 419
new 0 113 419
assign 1 113 420
addValue 1 113 420
addValue 1 113 421
return 1 114 422
assign 1 118 427
libNameGet 0 118 427
assign 1 118 428
beginNs 1 118 428
return 1 118 429
assign 1 122 438
new 0 122 438
assign 1 122 439
libNs 1 122 439
assign 1 122 440
add 1 122 440
assign 1 122 441
new 0 122 441
assign 1 122 442
add 1 122 442
assign 1 122 443
add 1 122 443
return 1 122 444
assign 1 126 448
getNameSpace 1 126 448
return 1 126 449
assign 1 130 454
new 0 130 454
assign 1 130 455
add 1 130 455
return 1 130 456
assign 1 134 462
new 0 134 462
assign 1 134 463
once 0 134 463
assign 1 134 464
add 1 134 464
return 1 134 465
assign 1 138 469
new 0 138 469
return 1 138 470
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 897786897: return bem_mainStartGet_0();
case -2133057956: return bem_constGet_0();
case -1924351130: return bem_boolCcGet_0();
case -1643246227: return bem_smnlecsGet_0();
case 2033350872: return bem_serializeToString_0();
case 605404858: return bem_tagGet_0();
case -41023079: return bem_iteratorGet_0();
case -1041270964: return bem_lastMethodsSizeGet_0();
case -1018107849: return bem_preClassGet_0();
case -1637794734: return bem_returnTypeGet_0();
case 485101121: return bem_coanyiantReturnsGet_0();
case 2064765098: return bem_randGet_0();
case 889544878: return bem_fileExtGet_0();
case -881614937: return bem_nlGet_0();
case 761778979: return bem_create_0();
case 83759291: return bem_exceptDecGet_0();
case 751706402: return bem_copy_0();
case 2090767709: return bem_many_0();
case -131063548: return bem_intNpGet_0();
case -2116635008: return bem_cnodeGet_0();
case -1813693817: return bem_libEmitNameGet_0();
case 1891402457: return bem_mainOutsideNsGet_0();
case -1165063866: return bem_serializeContents_0();
case -1120421430: return bem_print_0();
case 1387818040: return bem_new_0();
case 255044658: return bem_classCallsGet_0();
case -1754970668: return bem_buildInitial_0();
case 314613834: return bem_methodsGet_0();
case -69575126: return bem_smnlcsGet_0();
case 191864253: return bem_classesInDepthOrderGet_0();
case 195211465: return bem_baseMtdDecGet_0();
case -2027804166: return bem_buildClassInfo_0();
case 2007002929: return bem_beginNs_0();
case 1080862205: return bem_lastMethodBodySizeGet_0();
case 1253048074: return bem_getClassOutput_0();
case 1088925822: return bem_buildGet_0();
case 1184874957: return bem_instanceEqualGet_0();
case 847123484: return bem_maxSpillArgsLenGet_0();
case -555759356: return bem_instOfGet_0();
case 461934929: return bem_methodCallsGet_0();
case -713869366: return bem_lastMethodBodyLinesGet_0();
case 600465387: return bem_falseValueGet_0();
case -515275077: return bem_writeBET_0();
case 1776243080: return bem_csynGet_0();
case 1181742148: return bem_boolTypeGet_0();
case -497767253: return bem_superNameGet_0();
case -1553103418: return bem_trueValueGet_0();
case 78640469: return bem_parentConfGet_0();
case -554300554: return bem_lastMethodsLinesGet_0();
case -314631066: return bem_idToNameGet_0();
case 1459407781: return bem_ntypesGet_0();
case 1240627561: return bem_propDecGet_0();
case 998961316: return bem_propertyDecsGet_0();
case 318566726: return bem_nullValueGet_0();
case -423215178: return bem_scvpGet_0();
case -1327628830: return bem_classEmitsGet_0();
case 1043984390: return bem_once_0();
case 1385183333: return bem_maxDynArgsGet_0();
case 1315558702: return bem_sourceFileNameGet_0();
case 1336339576: return bem_mnodeGet_0();
case -1930439533: return bem_buildCreate_0();
case 1894636586: return bem_objectCcGet_0();
case 1698628274: return bem_nameToIdGet_0();
case -1315878201: return bem_fullLibEmitNameGet_0();
case -1484259648: return bem_libEmitPathGet_0();
case -1340179880: return bem_inFilePathedGet_0();
case 2079084965: return bem_toString_0();
case -1011016075: return bem_afterCast_0();
case 170925491: return bem_saveSyns_0();
case -364109840: return bem_serializationIteratorGet_0();
case -1457832513: return bem_classEndGet_0();
case 629755849: return bem_qGet_0();
case -268528295: return bem_fieldIteratorGet_0();
case -1530585953: return bem_lineCountGet_0();
case -770613938: return bem_onceDecsGet_0();
case 2010908668: return bem_floatNpGet_0();
case -566372518: return bem_ccMethodsGet_0();
case 1851391985: return bem_methodCatchGet_0();
case -1937660553: return bem_lastCallGet_0();
case -1472624838: return bem_emitLangGet_0();
case -208047206: return bem_ccCacheGet_0();
case 512670579: return bem_deserializeClassNameGet_0();
case 1366014700: return bem_objectNpGet_0();
case -1499447321: return bem_msynGet_0();
case 160935350: return bem_dynMethodsGet_0();
case -1363797930: return bem_instanceNotEqualGet_0();
case 685159657: return bem_boolNpGet_0();
case -1032373300: return bem_echo_0();
case 763461621: return bem_toAny_0();
case -1135619966: return bem_typeDecGet_0();
case 1910336978: return bem_methodBodyGet_0();
case 390064505: return bem_onceCountGet_0();
case 1604013535: return bem_classConfGet_0();
case 993739094: return bem_runtimeInitGet_0();
case -1626406481: return bem_spropDecGet_0();
case -1662177650: return bem_classNameGet_0();
case 516746498: return bem_doEmit_0();
case -223432074: return bem_nativeCSlotsGet_0();
case 201293416: return bem_invpGet_0();
case 2052493382: return bem_baseSmtdDecGet_0();
case 1887367903: return bem_mainInClassGet_0();
case 169398438: return bem_hashGet_0();
case -1352256842: return bem_useDynMethodsGet_0();
case 1415144694: return bem_mainEndGet_0();
case 1946447272: return bem_endNs_0();
case -1676968365: return bem_superCallsGet_0();
case 134464327: return bem_synEmitPathGet_0();
case 196700176: return bem_initialDecGet_0();
case 1332825667: return bem_overrideMtdDecGet_0();
case 1735688348: return bem_getLibOutput_0();
case 1150782418: return bem_stringNpGet_0();
case -1573128462: return bem_transGet_0();
case -355555139: return bem_callNamesGet_0();
case -1542554557: return bem_emitLib_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -132994488: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1493263393: return bem_msynSet_1(bevd_0);
case 258918390: return bem_dynMethodsSet_1(bevd_0);
case 1281999548: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 45908285: return bem_classesInDepthOrderSet_1(bevd_0);
case -1628072592: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1179778534: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -507940794: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1372317099: return bem_buildSet_1(bevd_0);
case 103300284: return bem_falseValueSet_1(bevd_0);
case -550476304: return bem_sameType_1(bevd_0);
case -322135452: return bem_superCallsSet_1(bevd_0);
case 1337681116: return bem_constSet_1(bevd_0);
case -522677626: return bem_transSet_1(bevd_0);
case 1557904888: return bem_classCallsSet_1(bevd_0);
case 1228506129: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 379770025: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1596975821: return bem_maxDynArgsSet_1(bevd_0);
case -1630612031: return bem_preClassSet_1(bevd_0);
case -1290499323: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -157254209: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1896146957: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1477208197: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1841883709: return bem_instanceEqualSet_1(bevd_0);
case -1659158772: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -497981186: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 69035991: return bem_ccMethodsSet_1(bevd_0);
case -1969858700: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -667090593: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -591954553: return bem_nativeCSlotsSet_1(bevd_0);
case -904133244: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 57407757: return bem_libEmitPathSet_1(bevd_0);
case 1484496570: return bem_begin_1(bevd_0);
case 1656297638: return bem_stringNpSet_1(bevd_0);
case 491800161: return bem_scvpSet_1(bevd_0);
case -753651294: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1655300947: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 25452579: return bem_csynSet_1(bevd_0);
case -2012552890: return bem_fullLibEmitNameSet_1(bevd_0);
case 333222868: return bem_instanceNotEqualSet_1(bevd_0);
case 2047986681: return bem_lineCountSet_1(bevd_0);
case -1330281098: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -490153532: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1975450659: return bem_onceCountSet_1(bevd_0);
case 1479785081: return bem_otherType_1(bevd_0);
case -608495259: return bem_emitLangSet_1(bevd_0);
case 167652759: return bem_exceptDecSet_1(bevd_0);
case -2080176861: return bem_lastMethodsSizeSet_1(bevd_0);
case 1707035969: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -935071779: return bem_invpSet_1(bevd_0);
case 1456820936: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1095756156: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1530873155: return bem_qSet_1(bevd_0);
case -129115304: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 436047433: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 260658995: return bem_nameToIdSet_1(bevd_0);
case 1062861741: return bem_instOfSet_1(bevd_0);
case 553762523: return bem_idToNameSet_1(bevd_0);
case -21929201: return bem_callNamesSet_1(bevd_0);
case -1706309886: return bem_nullValueSet_1(bevd_0);
case -1639717020: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 108912828: return bem_libEmitNameSet_1(bevd_0);
case -354184580: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1646725461: return bem_copyTo_1(bevd_0);
case -683586455: return bem_ntypesSet_1(bevd_0);
case 932249623: return bem_sameClass_1(bevd_0);
case -1768142986: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -952727433: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -2097173232: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1803276680: return bem_synEmitPathSet_1(bevd_0);
case 635714267: return bem_objectNpSet_1(bevd_0);
case -310448709: return bem_trueValueSet_1(bevd_0);
case 360246050: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1371981923: return bem_cnodeSet_1(bevd_0);
case 1316574181: return bem_nlSet_1(bevd_0);
case 422623345: return bem_ccCacheSet_1(bevd_0);
case -1036758165: return bem_smnlecsSet_1(bevd_0);
case -1630640660: return bem_methodCallsSet_1(bevd_0);
case 1905163480: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1886831606: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 5488458: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1845796750: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1277817455: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 327020484: return bem_sameObject_1(bevd_0);
case -623331960: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -337457655: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -400783475: return bem_undefined_1(bevd_0);
case 341496017: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1466910173: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1807890583: return bem_lastCallSet_1(bevd_0);
case -676562786: return bem_end_1(bevd_0);
case -1014943228: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 64749631: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 882749611: return bem_objectCcSet_1(bevd_0);
case 1296533558: return bem_otherClass_1(bevd_0);
case 1418884069: return bem_methodBodySet_1(bevd_0);
case 1974919447: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1953673516: return bem_undef_1(bevd_0);
case -1578179895: return bem_defined_1(bevd_0);
case 611966660: return bem_equals_1(bevd_0);
case -2008470192: return bem_methodCatchSet_1(bevd_0);
case -629216294: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -95156212: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1604560510: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1195059039: return bem_classEmitsSet_1(bevd_0);
case -147278276: return bem_methodsSet_1(bevd_0);
case -856222992: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -301307256: return bem_onceDecsSet_1(bevd_0);
case -772859453: return bem_boolNpSet_1(bevd_0);
case 646470630: return bem_inFilePathedSet_1(bevd_0);
case 1819405580: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1984946229: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 467176040: return bem_returnTypeSet_1(bevd_0);
case -1474669914: return bem_boolCcSet_1(bevd_0);
case 180375001: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1707241964: return bem_intNpSet_1(bevd_0);
case -726192464: return bem_randSet_1(bevd_0);
case -1608962865: return bem_parentConfSet_1(bevd_0);
case -46023056: return bem_notEquals_1(bevd_0);
case -879336676: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -862513132: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1985120502: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1476063269: return bem_propertyDecsSet_1(bevd_0);
case 1364593101: return bem_smnlcsSet_1(bevd_0);
case -1889105487: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 890542061: return bem_mnodeSet_1(bevd_0);
case -39006964: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1552597325: return bem_fileExtSet_1(bevd_0);
case -1896005093: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1883815467: return bem_floatNpSet_1(bevd_0);
case -945068215: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -173923543: return bem_def_1(bevd_0);
case 1456408266: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1350375938: return bem_lastMethodsLinesSet_1(bevd_0);
case -1421700688: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 2070256983: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1920928785: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1553897502: return bem_classConfSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1815708233: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1806507047: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -501684028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -931222247: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1424200790: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -715111135: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1465498474: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1106450434: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1158206039: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1366713268: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 886058979: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1037823579: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1534788139: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1222311321: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1733811664: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 175070671: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -469146476: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1920722583: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1854883996: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1576581833: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1673116715: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -55889645: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -534893798: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -906274456: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 2014302047: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -729245588: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
