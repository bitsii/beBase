package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_24, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_27, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_38, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_39, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_40, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_41, 9));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_42, 48));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_43, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_44, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_45, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_46 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_47 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_48 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_49 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_50 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_51 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_51, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_52 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_52, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_53 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_53, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_54 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_54, 3));
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(-1551817007);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_tmpany_phold = bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_tmpany_phold = bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-505537007);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(844391958);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 42 */
bevt_27_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 51 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-505537007);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(844391958);
if (bevl_firstptsyn.bevi_bool) /* Line: 52 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 53 */
 else  /* Line: 54 */ {
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 55 */
bevt_36_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 57 */
 else  /* Line: 51 */ {
break;
} /* Line: 51 */
} /* Line: 51 */
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevt_41_tmpany_phold = bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_40_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevl_bet.bem_addValue_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_47_tmpany_phold = bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_addValue_1(bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_46_tmpany_phold.bem_addValue_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevl_bet.bem_addValue_1(bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevl_bet.bem_addValue_1(bevt_53_tmpany_phold);
bevl_tout.bemd_1(-1739174364, bevl_bet);
bevl_tout.bemd_0(-1578603026);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-1375462113);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(307652204);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
return bevt_4_tmpany_phold;
} /* Line: 88 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
return bevt_3_tmpany_phold;
} /* Line: 95 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_has_1(bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevl_ms = bevt_3_tmpany_phold.bem_add_1(bevp_nl);
} /* Line: 124 */
 else  /* Line: 125 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevl_ms = bevt_7_tmpany_phold.bem_add_1(bevp_nl);
} /* Line: 126 */
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_46));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_47));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_48));
bevt_16_tmpany_phold = bevl_ms.bem_addValue_1(bevt_17_tmpany_phold);
bevt_16_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_49));
bevt_20_tmpany_phold = bevl_ms.bem_addValue_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(29768415);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_50));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_18_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_14;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_15;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_16;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 49, 49, 50, 51, 51, 0, 51, 51, 53, 55, 55, 57, 57, 57, 57, 59, 59, 61, 61, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 65, 65, 65, 65, 66, 66, 67, 67, 68, 68, 69, 70, 74, 74, 74, 75, 76, 76, 76, 76, 76, 76, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 83, 83, 87, 0, 87, 87, 87, 0, 0, 0, 0, 0, 88, 88, 90, 90, 94, 94, 94, 0, 0, 0, 95, 95, 97, 97, 101, 101, 105, 105, 105, 105, 105, 110, 111, 112, 112, 112, 113, 119, 119, 119, 119, 119, 119, 123, 123, 123, 124, 124, 124, 124, 124, 126, 126, 126, 126, 126, 128, 128, 128, 128, 128, 128, 129, 129, 129, 130, 130, 130, 130, 130, 130, 130, 130, 131, 135, 135, 135, 139, 139, 139, 139, 139, 139, 139, 143, 143, 147, 147, 147, 151, 151, 151, 151, 155, 155};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {84, 85, 86, 87, 151, 152, 153, 154, 159, 160, 161, 162, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 187, 190, 192, 194, 197, 198, 200, 201, 202, 203, 209, 210, 211, 212, 213, 214, 215, 216, 217, 217, 220, 222, 224, 227, 228, 230, 231, 232, 233, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 311, 312, 321, 323, 326, 331, 332, 334, 337, 341, 344, 347, 351, 352, 354, 355, 363, 368, 369, 371, 374, 378, 381, 382, 384, 385, 389, 390, 397, 398, 399, 400, 401, 407, 408, 409, 410, 411, 412, 421, 422, 423, 424, 425, 426, 455, 456, 457, 459, 460, 461, 462, 463, 466, 467, 468, 469, 470, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 494, 495, 496, 505, 506, 507, 508, 509, 510, 511, 515, 516, 521, 522, 523, 529, 530, 531, 532, 536, 537};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 84
new 0 17 84
assign 1 18 85
new 0 18 85
assign 1 19 86
new 0 19 86
new 1 23 87
assign 1 27 151
classDirGet 0 27 151
assign 1 27 152
fileGet 0 27 152
assign 1 27 153
existsGet 0 27 153
assign 1 27 154
not 0 27 159
assign 1 28 160
classDirGet 0 28 160
assign 1 28 161
fileGet 0 28 161
makeDirs 0 28 162
assign 1 30 164
typePathGet 0 30 164
assign 1 30 165
fileGet 0 30 165
assign 1 30 166
writerGet 0 30 166
assign 1 30 167
open 0 30 167
assign 1 31 168
new 0 31 168
assign 1 32 169
new 0 32 169
addValue 1 32 170
assign 1 33 171
new 0 33 171
assign 1 33 172
addValue 1 33 172
assign 1 33 173
typeEmitNameGet 0 33 173
assign 1 33 174
addValue 1 33 174
assign 1 33 175
new 0 33 175
addValue 1 33 176
assign 1 34 177
new 0 34 177
assign 1 34 178
addValue 1 34 178
assign 1 34 179
typeEmitNameGet 0 34 179
assign 1 34 180
addValue 1 34 180
assign 1 34 181
new 0 34 181
addValue 1 34 182
assign 1 36 183
new 0 36 183
addValue 1 36 184
assign 1 37 185
new 0 37 185
assign 1 38 186
mtdListGet 0 38 186
assign 1 38 187
iteratorGet 0 0 187
assign 1 38 190
hasNextGet 0 38 190
assign 1 38 192
nextGet 0 38 192
assign 1 40 194
new 0 40 194
assign 1 42 197
new 0 42 197
addValue 1 42 198
assign 1 44 200
addValue 1 44 200
assign 1 44 201
nameGet 0 44 201
assign 1 44 202
addValue 1 44 202
addValue 1 44 203
assign 1 46 209
new 0 46 209
addValue 1 46 210
assign 1 47 211
new 0 47 211
addValue 1 47 212
assign 1 49 213
new 0 49 213
addValue 1 49 214
assign 1 50 215
new 0 50 215
assign 1 51 216
ptyListGet 0 51 216
assign 1 51 217
iteratorGet 0 0 217
assign 1 51 220
hasNextGet 0 51 220
assign 1 51 222
nextGet 0 51 222
assign 1 53 224
new 0 53 224
assign 1 55 227
new 0 55 227
addValue 1 55 228
assign 1 57 230
addValue 1 57 230
assign 1 57 231
nameGet 0 57 231
assign 1 57 232
addValue 1 57 232
addValue 1 57 233
assign 1 59 239
new 0 59 239
addValue 1 59 240
assign 1 61 241
new 0 61 241
addValue 1 61 242
assign 1 63 243
new 0 63 243
assign 1 63 244
addValue 1 63 244
assign 1 63 245
typeEmitNameGet 0 63 245
assign 1 63 246
addValue 1 63 246
assign 1 63 247
new 0 63 247
addValue 1 63 248
assign 1 64 249
new 0 64 249
addValue 1 64 250
assign 1 65 251
new 0 65 251
assign 1 65 252
addValue 1 65 252
assign 1 65 253
emitNameGet 0 65 253
assign 1 65 254
addValue 1 65 254
assign 1 65 255
new 0 65 255
addValue 1 65 256
assign 1 66 257
new 0 66 257
addValue 1 66 258
assign 1 67 259
new 0 67 259
addValue 1 67 260
assign 1 68 261
new 0 68 261
addValue 1 68 262
write 1 69 263
close 0 70 264
assign 1 74 286
new 0 74 286
assign 1 74 287
toString 0 74 287
assign 1 74 288
add 1 74 288
incrementValue 0 75 289
assign 1 76 290
new 0 76 290
assign 1 76 291
addValue 1 76 291
assign 1 76 292
addValue 1 76 292
assign 1 76 293
new 0 76 293
assign 1 76 294
addValue 1 76 294
addValue 1 76 295
assign 1 78 296
containedGet 0 78 296
assign 1 78 297
firstGet 0 78 297
assign 1 78 298
containedGet 0 78 298
assign 1 78 299
firstGet 0 78 299
assign 1 78 300
new 0 78 300
assign 1 78 301
add 1 78 301
assign 1 78 302
new 0 78 302
assign 1 78 303
add 1 78 303
assign 1 78 304
new 0 78 304
assign 1 78 305
finalAssign 4 78 305
addValue 1 78 306
assign 1 83 311
new 0 83 311
return 1 83 312
assign 1 87 321
isFinalGet 0 87 321
assign 1 0 323
assign 1 87 326
def 1 87 331
assign 1 87 332
isFinalGet 0 87 332
assign 1 0 334
assign 1 0 337
assign 1 0 341
assign 1 0 344
assign 1 0 347
assign 1 88 351
new 0 88 351
return 1 88 352
assign 1 90 354
new 0 90 354
return 1 90 355
assign 1 94 363
def 1 94 368
assign 1 94 369
isFinalGet 0 94 369
assign 1 0 371
assign 1 0 374
assign 1 0 378
assign 1 95 381
new 0 95 381
return 1 95 382
assign 1 97 384
new 0 97 384
return 1 97 385
assign 1 101 389
new 0 101 389
return 1 101 390
assign 1 105 397
new 0 105 397
assign 1 105 398
add 1 105 398
assign 1 105 399
new 0 105 399
assign 1 105 400
add 1 105 400
return 1 105 401
getCode 2 110 407
assign 1 111 408
toHexString 1 111 408
assign 1 112 409
new 0 112 409
assign 1 112 410
once 0 112 410
addValue 1 112 411
addValue 1 113 412
assign 1 119 421
new 0 119 421
assign 1 119 422
add 1 119 422
assign 1 119 423
new 0 119 423
assign 1 119 424
add 1 119 424
assign 1 119 425
add 1 119 425
return 1 119 426
assign 1 123 455
emitChecksGet 0 123 455
assign 1 123 456
new 0 123 456
assign 1 123 457
has 1 123 457
assign 1 124 459
new 0 124 459
assign 1 124 460
add 1 124 460
assign 1 124 461
new 0 124 461
assign 1 124 462
add 1 124 462
assign 1 124 463
add 1 124 463
assign 1 126 466
new 0 126 466
assign 1 126 467
add 1 126 467
assign 1 126 468
new 0 126 468
assign 1 126 469
add 1 126 469
assign 1 126 470
add 1 126 470
assign 1 128 472
new 0 128 472
assign 1 128 473
addValue 1 128 473
assign 1 128 474
addValue 1 128 474
assign 1 128 475
new 0 128 475
assign 1 128 476
addValue 1 128 476
addValue 1 128 477
assign 1 129 478
new 0 129 478
assign 1 129 479
addValue 1 129 479
addValue 1 129 480
assign 1 130 481
new 0 130 481
assign 1 130 482
addValue 1 130 482
assign 1 130 483
outputPlatformGet 0 130 483
assign 1 130 484
nameGet 0 130 484
assign 1 130 485
addValue 1 130 485
assign 1 130 486
new 0 130 486
assign 1 130 487
addValue 1 130 487
addValue 1 130 488
return 1 131 489
assign 1 135 494
libNameGet 0 135 494
assign 1 135 495
beginNs 1 135 495
return 1 135 496
assign 1 139 505
new 0 139 505
assign 1 139 506
libNs 1 139 506
assign 1 139 507
add 1 139 507
assign 1 139 508
new 0 139 508
assign 1 139 509
add 1 139 509
assign 1 139 510
add 1 139 510
return 1 139 511
assign 1 143 515
getNameSpace 1 143 515
return 1 143 516
assign 1 147 521
new 0 147 521
assign 1 147 522
add 1 147 522
return 1 147 523
assign 1 151 529
new 0 151 529
assign 1 151 530
once 0 151 530
assign 1 151 531
add 1 151 531
return 1 151 532
assign 1 155 536
new 0 155 536
return 1 155 537
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1283126622: return bem_inClassGet_0();
case 1860102684: return bem_emitLangGetDirect_0();
case 743392663: return bem_parentConfGetDirect_0();
case 141518450: return bem_lastCallGetDirect_0();
case -2108916214: return bem_inClassGetDirect_0();
case 865626065: return bem_many_0();
case 714112130: return bem_trueValueGet_0();
case -371092323: return bem_onceCountGet_0();
case -1014833872: return bem_idToNameGet_0();
case 150594226: return bem_toAny_0();
case 645821136: return bem_libEmitPathGet_0();
case -646783144: return bem_ccCacheGetDirect_0();
case -1301171272: return bem_boolNpGetDirect_0();
case 249467983: return bem_stringNpGetDirect_0();
case -1555283801: return bem_instOfGetDirect_0();
case -581980546: return bem_floatNpGetDirect_0();
case 2967194: return bem_typeDecGet_0();
case -886961554: return bem_csynGet_0();
case 1282783553: return bem_nullValueGetDirect_0();
case 1314402674: return bem_scvpGetDirect_0();
case -223034634: return bem_intNpGet_0();
case -203856562: return bem_gcMarksGet_0();
case -1809283124: return bem_transGet_0();
case -279704264: return bem_exceptDecGetDirect_0();
case 1345425965: return bem_falseValueGetDirect_0();
case -2006936652: return bem_idToNamePathGet_0();
case -848997408: return bem_trueValueGetDirect_0();
case -192552573: return bem_msynGet_0();
case 803094369: return bem_fileExtGetDirect_0();
case -481458436: return bem_once_0();
case -802252247: return bem_callNamesGet_0();
case 15052169: return bem_iteratorGet_0();
case -1435068651: return bem_emitLib_0();
case -183470469: return bem_maxSpillArgsLenGetDirect_0();
case 1822650634: return bem_scvpGet_0();
case 1017283006: return bem_nlGet_0();
case -1238312381: return bem_print_0();
case 1179346390: return bem_buildClassInfo_0();
case 1772915815: return bem_useDynMethodsGet_0();
case 68732196: return bem_ntypesGetDirect_0();
case -822923661: return bem_preClassOutput_0();
case 771990398: return bem_propertyDecsGetDirect_0();
case 279102071: return bem_maxDynArgsGet_0();
case 1410805432: return bem_superCallsGetDirect_0();
case 734719264: return bem_copy_0();
case -585809478: return bem_objectCcGetDirect_0();
case -923361883: return bem_qGetDirect_0();
case -502230346: return bem_saveSyns_0();
case 1259408140: return bem_instanceNotEqualGet_0();
case 528890579: return bem_boolCcGet_0();
case -743150455: return bem_fileExtGet_0();
case 628774931: return bem_libEmitPathGetDirect_0();
case -1255955476: return bem_returnTypeGet_0();
case -1533871410: return bem_ccMethodsGetDirect_0();
case 2019718173: return bem_csynGetDirect_0();
case -1146441672: return bem_falseValueGet_0();
case -2032431276: return bem_callNamesGetDirect_0();
case -96306095: return bem_echo_0();
case 1770146810: return bem_serializeToString_0();
case 518998873: return bem_stringNpGet_0();
case -581696288: return bem_methodCatchGet_0();
case 141182595: return bem_instanceEqualGet_0();
case 372874749: return bem_objectNpGetDirect_0();
case 1703076999: return bem_fieldIteratorGet_0();
case 1517258828: return bem_baseSmtdDecGet_0();
case -1639087339: return bem_lastMethodBodySizeGetDirect_0();
case 1497740622: return bem_transGetDirect_0();
case -394553430: return bem_nlGetDirect_0();
case -1396874940: return bem_classConfGetDirect_0();
case -837026771: return bem_maxSpillArgsLenGet_0();
case 860367008: return bem_overrideMtdDecGet_0();
case -218714696: return bem_getClassOutput_0();
case -1080534861: return bem_baseMtdDecGet_0();
case -738389586: return bem_nameToIdGet_0();
case 352806076: return bem_objectNpGet_0();
case 1337944689: return bem_objectCcGet_0();
case 1296517886: return bem_methodsGetDirect_0();
case 475849232: return bem_fieldNamesGet_0();
case 310222969: return bem_instanceNotEqualGetDirect_0();
case -1127348176: return bem_nameToIdPathGet_0();
case -2065547209: return bem_lastMethodBodySizeGet_0();
case 1102508309: return bem_cnodeGet_0();
case -74268330: return bem_classEndGet_0();
case 621371070: return bem_returnTypeGetDirect_0();
case -1972743469: return bem_lineCountGetDirect_0();
case 1575360285: return bem_classesInDepthOrderGetDirect_0();
case -954155738: return bem_fullLibEmitNameGetDirect_0();
case 2119664580: return bem_onceDecsGet_0();
case 1999977075: return bem_preClassGet_0();
case -1989654388: return bem_lastCallGet_0();
case 1142069631: return bem_smnlcsGet_0();
case 2110401096: return bem_propertyDecsGet_0();
case 1992245618: return bem_writeBET_0();
case -91078991: return bem_synEmitPathGetDirect_0();
case -1280566121: return bem_invpGetDirect_0();
case -696933955: return bem_toString_0();
case 1851388081: return bem_inFilePathedGetDirect_0();
case -926776693: return bem_synEmitPathGet_0();
case 1987510328: return bem_propDecGet_0();
case 448554560: return bem_classConfGet_0();
case -1841403: return bem_mnodeGet_0();
case -791198660: return bem_serializationIteratorGet_0();
case -333942565: return bem_mainEndGet_0();
case 567931170: return bem_cnodeGetDirect_0();
case -573314391: return bem_libEmitNameGetDirect_0();
case -350163525: return bem_smnlecsGetDirect_0();
case 1628726404: return bem_endNs_0();
case 615282212: return bem_methodCallsGetDirect_0();
case -512745226: return bem_tagGet_0();
case 942009897: return bem_mainOutsideNsGet_0();
case 2069651568: return bem_msynGetDirect_0();
case -1374477964: return bem_lastMethodBodyLinesGetDirect_0();
case 995557092: return bem_ccCacheGet_0();
case -2044264328: return bem_constGetDirect_0();
case 727733914: return bem_superNameGet_0();
case -2013866322: return bem_lastMethodsLinesGetDirect_0();
case -1480370637: return bem_boolNpGet_0();
case -1767870795: return bem_getLibOutput_0();
case 1680722270: return bem_randGet_0();
case -419763405: return bem_classEmitsGet_0();
case -1228156289: return bem_onceCountGetDirect_0();
case 381254961: return bem_preClassGetDirect_0();
case -733658165: return bem_buildInitial_0();
case -681950777: return bem_exceptDecGet_0();
case -1127650138: return bem_classCallsGetDirect_0();
case -931658262: return bem_dynMethodsGet_0();
case -176397971: return bem_nameToIdPathGetDirect_0();
case 1936023590: return bem_boolCcGetDirect_0();
case 1064240293: return bem_sourceFileNameGet_0();
case -1897829372: return bem_ntypesGet_0();
case 630434587: return bem_intNpGetDirect_0();
case -688490428: return bem_doEmit_0();
case -1469808504: return bem_ccMethodsGet_0();
case 404860950: return bem_fullLibEmitNameGet_0();
case -1152490178: return bem_classCallsGet_0();
case -2230592: return bem_smnlcsGetDirect_0();
case 906177206: return bem_buildCreate_0();
case 48415513: return bem_idToNameGetDirect_0();
case 1453850037: return bem_superCallsGet_0();
case -1230002761: return bem_mainInClassGet_0();
case 610307651: return bem_gcMarksGetDirect_0();
case -561253016: return bem_randGetDirect_0();
case -1000616906: return bem_smnlecsGet_0();
case 249123565: return bem_onceDecsGetDirect_0();
case 443152637: return bem_libEmitNameGet_0();
case -885509351: return bem_classesInDepthOrderGet_0();
case 1754160569: return bem_newDecGet_0();
case -2122292357: return bem_constGet_0();
case -575608328: return bem_lastMethodBodyLinesGet_0();
case -1983161153: return bem_mainStartGet_0();
case 1131255568: return bem_lastMethodsSizeGet_0();
case -1010395565: return bem_deserializeClassNameGet_0();
case 1720513936: return bem_qGet_0();
case 1403049839: return bem_lineCountGet_0();
case 542091259: return bem_lastMethodsLinesGet_0();
case -47832858: return bem_runtimeInitGet_0();
case 296034201: return bem_buildGet_0();
case -2048346157: return bem_initialDecGet_0();
case -1016238852: return bem_beginNs_0();
case -1286808722: return bem_spropDecGet_0();
case -1841957129: return bem_idToNamePathGetDirect_0();
case 970559243: return bem_hashGet_0();
case -334027767: return bem_covariantReturnsGet_0();
case 1592006789: return bem_methodsGet_0();
case -1278335617: return bem_saveIds_0();
case 538509154: return bem_methodCatchGetDirect_0();
case 271252786: return bem_nameToIdGetDirect_0();
case -1441092141: return bem_afterCast_0();
case 1381815222: return bem_inFilePathedGet_0();
case -1642111000: return bem_instOfGet_0();
case -1032712591: return bem_methodBodyGet_0();
case -755710090: return bem_lastMethodsSizeGetDirect_0();
case 1361603917: return bem_create_0();
case 189063253: return bem_serializeContents_0();
case 798545957: return bem_parentConfGet_0();
case 112629438: return bem_invpGet_0();
case 193037622: return bem_maxDynArgsGetDirect_0();
case -866769073: return bem_new_0();
case 2136784234: return bem_mnodeGetDirect_0();
case -2035167103: return bem_instanceEqualGetDirect_0();
case -1022101850: return bem_classEmitsGetDirect_0();
case -445537179: return bem_nullValueGet_0();
case -1817950071: return bem_buildGetDirect_0();
case -2002537448: return bem_methodCallsGet_0();
case -1485819779: return bem_floatNpGet_0();
case -1487095976: return bem_loadIds_0();
case 1550007097: return bem_emitLangGet_0();
case -1581564679: return bem_methodBodyGetDirect_0();
case 170886276: return bem_boolTypeGet_0();
case -232339846: return bem_classNameGet_0();
case -1710842943: return bem_nativeCSlotsGet_0();
case -871187272: return bem_dynMethodsGetDirect_0();
case 2119925499: return bem_nativeCSlotsGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1639491775: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -733700792: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -907246538: return bem_scvpSetDirect_1(bevd_0);
case -947293077: return bem_csynSetDirect_1(bevd_0);
case -1708031237: return bem_begin_1(bevd_0);
case -630812499: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -811377723: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1251906518: return bem_callNamesSetDirect_1(bevd_0);
case 894175932: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1457348126: return bem_cnodeSetDirect_1(bevd_0);
case 1399022051: return bem_lastMethodsLinesSet_1(bevd_0);
case 2019571973: return bem_randSetDirect_1(bevd_0);
case -667728220: return bem_libEmitPathSet_1(bevd_0);
case 1226815052: return bem_nameToIdSet_1(bevd_0);
case 814603949: return bem_methodsSetDirect_1(bevd_0);
case 1147224590: return bem_msynSetDirect_1(bevd_0);
case 869347313: return bem_nlSet_1(bevd_0);
case 2130701742: return bem_lineCountSetDirect_1(bevd_0);
case 140154575: return bem_stringNpSet_1(bevd_0);
case -93200769: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 320227965: return bem_trueValueSetDirect_1(bevd_0);
case -104892748: return bem_maxDynArgsSet_1(bevd_0);
case -1350440668: return bem_libEmitNameSetDirect_1(bevd_0);
case -348092279: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 832052089: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1342784893: return bem_libEmitNameSet_1(bevd_0);
case -552176687: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -105051094: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1115285844: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1120668425: return bem_sameClass_1(bevd_0);
case 80703520: return bem_classCallsSetDirect_1(bevd_0);
case 850542264: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 940533625: return bem_onceDecsSet_1(bevd_0);
case -364708873: return bem_constSet_1(bevd_0);
case -930029780: return bem_synEmitPathSetDirect_1(bevd_0);
case 1146800586: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1411547316: return bem_sameObject_1(bevd_0);
case -166972331: return bem_parentConfSetDirect_1(bevd_0);
case -978097961: return bem_callNamesSet_1(bevd_0);
case -1734412628: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 216892569: return bem_classesInDepthOrderSet_1(bevd_0);
case -1370801473: return bem_boolCcSet_1(bevd_0);
case -330137199: return bem_objectCcSet_1(bevd_0);
case 2134567515: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1091105903: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2018144381: return bem_sameType_1(bevd_0);
case -1266453018: return bem_boolNpSet_1(bevd_0);
case 1160767366: return bem_methodCallsSet_1(bevd_0);
case 806983781: return bem_methodCatchSetDirect_1(bevd_0);
case -284658926: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 182476093: return bem_ccMethodsSet_1(bevd_0);
case -1395554881: return bem_idToNameSet_1(bevd_0);
case 676338788: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2097329104: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1365886180: return bem_returnTypeSet_1(bevd_0);
case 621916708: return bem_smnlcsSet_1(bevd_0);
case 1199516699: return bem_fileExtSet_1(bevd_0);
case 912632577: return bem_nameToIdSetDirect_1(bevd_0);
case -649697995: return bem_constSetDirect_1(bevd_0);
case -1992021577: return bem_cnodeSet_1(bevd_0);
case 63722904: return bem_synEmitPathSet_1(bevd_0);
case -659511760: return bem_methodCatchSet_1(bevd_0);
case -1283742794: return bem_superCallsSet_1(bevd_0);
case -304012900: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1660489177: return bem_invpSetDirect_1(bevd_0);
case -1973562246: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -263755810: return bem_inClassSetDirect_1(bevd_0);
case 964128291: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -307131501: return bem_propertyDecsSet_1(bevd_0);
case 479247843: return bem_onceDecsSetDirect_1(bevd_0);
case 1334136476: return bem_instanceNotEqualSet_1(bevd_0);
case -945908721: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1936960180: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1581435184: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 125594934: return bem_exceptDecSet_1(bevd_0);
case 544124659: return bem_trueValueSet_1(bevd_0);
case 2120828448: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 429904052: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1184486521: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1853770106: return bem_objectNpSet_1(bevd_0);
case 1359169655: return bem_nativeCSlotsSet_1(bevd_0);
case -148737587: return bem_mnodeSet_1(bevd_0);
case 860380885: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1037138962: return bem_lastCallSetDirect_1(bevd_0);
case 1066225154: return bem_maxDynArgsSetDirect_1(bevd_0);
case 39819628: return bem_preClassSet_1(bevd_0);
case 1029784427: return bem_nullValueSet_1(bevd_0);
case -298432183: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1790232092: return bem_inClassSet_1(bevd_0);
case 647841498: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1817793606: return bem_inFilePathedSetDirect_1(bevd_0);
case -168618738: return bem_smnlecsSet_1(bevd_0);
case -1830118816: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1354783124: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 2051076402: return bem_ntypesSet_1(bevd_0);
case 1062743909: return bem_returnTypeSetDirect_1(bevd_0);
case 374001917: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 516606327: return bem_stringNpSetDirect_1(bevd_0);
case -1258943525: return bem_equals_1(bevd_0);
case -269207746: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 1755852563: return bem_onceCountSet_1(bevd_0);
case -1227287490: return bem_boolNpSetDirect_1(bevd_0);
case 1689607871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -855347330: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1385389484: return bem_preClassSetDirect_1(bevd_0);
case 1530596043: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -298566048: return bem_fullLibEmitNameSet_1(bevd_0);
case 1373606870: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1285109505: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 796695478: return bem_gcMarksSetDirect_1(bevd_0);
case -344883572: return bem_classEmitsSet_1(bevd_0);
case -2087123796: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -127582518: return bem_boolCcSetDirect_1(bevd_0);
case 1676352893: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1709197053: return bem_nameToIdPathSet_1(bevd_0);
case -575950050: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1854651057: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1112486027: return bem_nullValueSetDirect_1(bevd_0);
case -372750986: return bem_classConfSet_1(bevd_0);
case -1657467808: return bem_def_1(bevd_0);
case -1257389782: return bem_emitLangSetDirect_1(bevd_0);
case 1896517434: return bem_smnlecsSetDirect_1(bevd_0);
case -334908535: return bem_transSet_1(bevd_0);
case 1879318417: return bem_lastCallSet_1(bevd_0);
case 1485950942: return bem_falseValueSetDirect_1(bevd_0);
case 1553563575: return bem_propertyDecsSetDirect_1(bevd_0);
case -1867509662: return bem_methodBodySet_1(bevd_0);
case -643213870: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 247348765: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -437421871: return bem_objectCcSetDirect_1(bevd_0);
case 1271720842: return bem_mnodeSetDirect_1(bevd_0);
case 1995417293: return bem_classConfSetDirect_1(bevd_0);
case -380223955: return bem_ccCacheSet_1(bevd_0);
case 1507595021: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1429404759: return bem_fileExtSetDirect_1(bevd_0);
case -799325447: return bem_ccCacheSetDirect_1(bevd_0);
case -1123294320: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1122925441: return bem_ccMethodsSetDirect_1(bevd_0);
case 1160992331: return bem_qSetDirect_1(bevd_0);
case -288337531: return bem_falseValueSet_1(bevd_0);
case 1357491644: return bem_instOfSetDirect_1(bevd_0);
case -744851132: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1320703554: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -933917: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1870857346: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 329553750: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -248893528: return bem_gcMarksSet_1(bevd_0);
case -2063355864: return bem_csynSet_1(bevd_0);
case -567821052: return bem_transSetDirect_1(bevd_0);
case 954777710: return bem_undefined_1(bevd_0);
case -1696224976: return bem_otherClass_1(bevd_0);
case -1814510964: return bem_notEquals_1(bevd_0);
case 387031451: return bem_libEmitPathSetDirect_1(bevd_0);
case 1661637889: return bem_idToNamePathSet_1(bevd_0);
case -1361821450: return bem_superCallsSetDirect_1(bevd_0);
case -23105232: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -185069684: return bem_intNpSet_1(bevd_0);
case 208581178: return bem_inFilePathedSet_1(bevd_0);
case 1568211397: return bem_classCallsSet_1(bevd_0);
case 323490393: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -750063225: return bem_end_1(bevd_0);
case 1581346605: return bem_lastMethodsSizeSet_1(bevd_0);
case 943276438: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 651828974: return bem_classEmitsSetDirect_1(bevd_0);
case -331324516: return bem_floatNpSet_1(bevd_0);
case -66686949: return bem_smnlcsSetDirect_1(bevd_0);
case 1483860897: return bem_dynMethodsSetDirect_1(bevd_0);
case -1139022662: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1884452317: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -969715992: return bem_objectNpSetDirect_1(bevd_0);
case 548631808: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -62590911: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1964700656: return bem_idToNamePathSetDirect_1(bevd_0);
case -738137797: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -237907317: return bem_instOfSet_1(bevd_0);
case 721379891: return bem_otherType_1(bevd_0);
case 346651613: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -36134590: return bem_methodsSet_1(bevd_0);
case 1110603654: return bem_emitLangSet_1(bevd_0);
case -1053255112: return bem_nlSetDirect_1(bevd_0);
case -209057872: return bem_exceptDecSetDirect_1(bevd_0);
case 1333666940: return bem_intNpSetDirect_1(bevd_0);
case -1260408910: return bem_methodCallsSetDirect_1(bevd_0);
case 1312067492: return bem_onceCountSetDirect_1(bevd_0);
case -864127302: return bem_invpSet_1(bevd_0);
case -1120531188: return bem_buildSetDirect_1(bevd_0);
case 825095196: return bem_dynMethodsSet_1(bevd_0);
case 525587695: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 222795622: return bem_randSet_1(bevd_0);
case 1661921012: return bem_msynSet_1(bevd_0);
case -1113090591: return bem_instanceEqualSetDirect_1(bevd_0);
case -256855558: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -2076726585: return bem_methodBodySetDirect_1(bevd_0);
case -2056392080: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -1617578581: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1378821005: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1310020282: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1808687636: return bem_qSet_1(bevd_0);
case 315521343: return bem_floatNpSetDirect_1(bevd_0);
case -1924898682: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -362701105: return bem_instanceEqualSet_1(bevd_0);
case 1018532877: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1514694923: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -465918371: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1823759535: return bem_lineCountSet_1(bevd_0);
case -711912180: return bem_idToNameSetDirect_1(bevd_0);
case 789848846: return bem_copyTo_1(bevd_0);
case -802075689: return bem_buildSet_1(bevd_0);
case 952631001: return bem_undef_1(bevd_0);
case -1555556152: return bem_defined_1(bevd_0);
case -401516611: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 202870130: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 989329987: return bem_scvpSet_1(bevd_0);
case -18716042: return bem_parentConfSet_1(bevd_0);
case -759839001: return bem_ntypesSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -133579010: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1762709957: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -225915630: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -430494103: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -750254672: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1191848195: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 514912045: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 348903518: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1646498224: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2072659817: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 113238137: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1041788971: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 84003596: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1201085541: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1757476558: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 982683550: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -363819380: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 2135169357: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -150192783: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 798528559: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 2104908824: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 791534665: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 751717746: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 685679441: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -324630068: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1669128491: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1675750295: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
