package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError extends BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -145312000: return bem_serializationIteratorGet_0();
case -1505231120: return bem_klassNameGet_0();
case -1756765378: return bem_methodNameGet_0();
case 1002458540: return bem_nodeGet_0();
case 1241960384: return bem_langGet_0();
case -176876439: return bem_fieldIteratorGet_0();
case 904467476: return bem_create_0();
case -1929512824: return bem_lineNumberGet_0();
case -629628110: return bem_toAny_0();
case 714053375: return bem_many_0();
case -820547047: return bem_new_0();
case 585911108: return bem_vvGet_0();
case -131080468: return bem_print_0();
case -1239151636: return bem_sourceFileNameGet_0();
case 378980218: return bem_msgGet_0();
case 790525540: return bem_framesGet_0();
case -863935940: return bem_copy_0();
case 1030499827: return bem_iteratorGet_0();
case 865364657: return bem_serializeContents_0();
case 448061581: return bem_translateEmittedException_0();
case -1918074861: return bem_descriptionGet_0();
case 805374728: return bem_translatedGet_0();
case 2071886229: return bem_emitLangGet_0();
case -1895992021: return bem_deserializeClassNameGet_0();
case 1021615634: return bem_classNameGet_0();
case -469922514: return bem_getFrameText_0();
case -316245103: return bem_echo_0();
case 521055509: return bem_serializeToString_0();
case -1196329855: return bem_tagGet_0();
case 1012200761: return bem_framesTextGet_0();
case 1797341089: return bem_once_0();
case 237070779: return bem_translateEmittedExceptionInner_0();
case 1970008436: return bem_fileNameGet_0();
case 269723613: return bem_hashGet_0();
case 657801083: return bem_toString_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 1808338509: return bem_def_1(bevd_0);
case 681555470: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 544484580: return bem_defined_1(bevd_0);
case 2088667933: return bem_langSet_1(bevd_0);
case -455244874: return bem_undefined_1(bevd_0);
case 1354444477: return bem_undef_1(bevd_0);
case 779198300: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 537823890: return bem_framesSet_1(bevd_0);
case -934156288: return bem_methodNameSet_1(bevd_0);
case 1465508810: return bem_descriptionSet_1(bevd_0);
case 2063004658: return bem_sameType_1(bevd_0);
case 7355535: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1475596912: return bem_fileNameSet_1(bevd_0);
case 218874128: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1544041665: return bem_klassNameSet_1(bevd_0);
case -7849173: return bem_vvSet_1(bevd_0);
case 497112617: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -703109093: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -588824569: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1681761888: return bem_nodeSet_1(bevd_0);
case 1296587887: return bem_msgSet_1(bevd_0);
case -1584774500: return bem_sameClass_1(bevd_0);
case 566034428: return bem_new_1(bevd_0);
case -475836758: return bem_emitLangSet_1(bevd_0);
case -1074673344: return bem_copyTo_1(bevd_0);
case 153472398: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1157078825: return bem_framesTextSet_1(bevd_0);
case 1500700647: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1693196376: return bem_otherType_1(bevd_0);
case -243906770: return bem_translatedSet_1(bevd_0);
case 1864758635: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 600260136: return bem_lineNumberSet_1(bevd_0);
case 788271940: return bem_sameObject_1(bevd_0);
case -560471223: return bem_otherClass_1(bevd_0);
case 80790810: return bem_notEquals_1(bevd_0);
case 2016817692: return bem_equals_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 423661912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 338963035: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1655996947: return bem_new_2(bevd_0, bevd_1);
case -236631668: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -539434931: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 901264448: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 883042907: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -884026318: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callCase) {
case 93330013: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callCase, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildEmitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
}
