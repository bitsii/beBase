package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildMtdSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMtdSyn() { }
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x74,0x64,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_2 = {0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_3 = {0x6E,0x75,0x6D,0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_4 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_5 = {0x6C,0x61,0x73,0x74,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_6 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_7 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_8 = {0x69,0x73,0x47,0x65,0x6E,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_9 = {0x72,0x73,0x79,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_10 = {0x64,0x79,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_11 = {0x61,0x72,0x67,0x54,0x79,0x70,0x65};
public static BEC_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;

public static BET_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_type;

public BEC_2_4_3_MathInt bevp_hpos;
public BEC_2_4_3_MathInt bevp_mtdx;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_9_4_ContainerList bevp_argSyns;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_5_4_LogicBool bevp_lastDef;
public BEC_2_5_4_LogicBool bevp_isOverride;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_6_TextString bevp_propertyName;
public BEC_2_5_6_BuildVarSyn bevp_rsyn;
public BEC_2_5_6_BuildMtdSyn bem_new_2(BEC_2_6_6_SystemObject beva_snode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_args = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_6_BuildVarSyn bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
bevl_s = beva_snode.bemd_0(1911780709);
bevp_numargs = (BEC_2_4_3_MathInt) bevl_s.bemd_0(-1510258965);
bevp_name = (BEC_2_4_6_TextString) bevl_s.bemd_0(-1948989061);
bevp_orgName = (BEC_2_4_6_TextString) bevl_s.bemd_0(882711031);
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(-1847502646);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevp_numargs.bem_add_1(bevt_1_ta_ph);
bevp_argSyns = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_lastDef = be.BECS_Runtime.boolTrue;
bevp_isOverride = be.BECS_Runtime.boolFalse;
bevp_isFinal = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(-1711970993);
bevt_3_ta_ph = bevl_s.bemd_0(1704161591);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 435*/ {
bevt_4_ta_ph = bevl_s.bemd_0(1704161591);
bevp_propertyName = (BEC_2_4_6_TextString) bevt_4_ta_ph.bemd_0(-1948989061);
} /* Line: 436*/
bevt_6_ta_ph = bevl_s.bemd_0(884125065);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_7_ta_ph = bevl_s.bemd_0(884125065);
bevp_rsyn = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_7_ta_ph );
} /* Line: 439*/
bevt_9_ta_ph = beva_snode.bemd_0(622225510);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(435309593);
bevl_args = bevt_8_ta_ph.bemd_0(622225510);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 444*/ {
bevt_11_ta_ph = bevp_argSyns.bem_lengthGet_0();
bevt_10_ta_ph = bevl_i.bemd_1(1870109470, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 444*/ {
bevt_14_ta_ph = bevl_args.bemd_1(-1453226628, bevl_i);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(1911780709);
bevt_12_ta_ph = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_13_ta_ph );
bevp_argSyns.bem_put_2((BEC_2_4_3_MathInt) bevl_i , bevt_12_ta_ph);
bevl_i = bevl_i.bemd_0(322754171);
} /* Line: 444*/
 else /* Line: 444*/ {
break;
} /* Line: 444*/
} /* Line: 444*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_arg = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_1_ta_ph.bem_newlineGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_0));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevl_nl);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevp_name);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_nl);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_2));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_nl);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevp_orgName);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevl_nl);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_3));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_17_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevl_nl);
bevt_18_ta_ph = bevp_numargs.bem_toString_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_18_ta_ph);
bevl_toRet = bevt_2_ta_ph.bem_add_1(bevl_nl);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_4));
bevt_21_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_22_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_23_ta_ph = bevp_origin.bem_toString_0();
bevt_19_ta_ph = bevt_20_ta_ph.bemd_1(-782071312, bevt_23_ta_ph);
bevl_toRet = bevt_19_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_5));
bevt_26_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_27_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_28_ta_ph = bevp_lastDef.bem_toString_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(-782071312, bevt_28_ta_ph);
bevl_toRet = bevt_24_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_6));
bevt_31_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_32_ta_ph);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_33_ta_ph = bevp_isFinal.bem_toString_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(-782071312, bevt_33_ta_ph);
bevl_toRet = bevt_29_ta_ph.bemd_1(-782071312, bevl_nl);
if (bevp_propertyName == null) {
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 456*/ {
bevt_38_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_6_BuildMtdSyn_bels_7));
bevt_37_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_38_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_35_ta_ph = bevt_36_ta_ph.bemd_1(-782071312, bevp_propertyName);
bevl_toRet = bevt_35_ta_ph.bemd_1(-782071312, bevl_nl);
} /* Line: 457*/
bevt_42_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_6_BuildMtdSyn_bels_8));
bevt_41_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_42_ta_ph);
bevt_40_ta_ph = bevt_41_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_43_ta_ph = bevp_isGenAccessor.bem_toString_0();
bevt_39_ta_ph = bevt_40_ta_ph.bemd_1(-782071312, bevt_43_ta_ph);
bevl_toRet = bevt_39_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_9));
bevt_44_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_45_ta_ph);
bevl_toRet = bevt_44_ta_ph.bemd_1(-782071312, bevl_nl);
if (bevp_rsyn == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 461*/ {
bevt_47_ta_ph = bevp_rsyn.bem_isTypedGet_0();
if (bevt_47_ta_ph.bevi_bool)/* Line: 461*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 461*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 461*/
 else /* Line: 461*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 461*/ {
bevt_50_ta_ph = bevp_rsyn.bem_namepathGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_toString_0();
bevt_48_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_49_ta_ph);
bevl_toRet = bevt_48_ta_ph.bemd_1(-782071312, bevl_nl);
} /* Line: 462*/
 else /* Line: 463*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_51_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_52_ta_ph);
bevl_toRet = bevt_51_ta_ph.bemd_1(-782071312, bevl_nl);
} /* Line: 464*/
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 466*/ {
bevt_54_ta_ph = bevp_argSyns.bem_lengthGet_0();
bevt_53_ta_ph = bevl_i.bemd_1(1870109470, bevt_54_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 466*/ {
bevl_arg = bevp_argSyns.bem_get_1((BEC_2_4_3_MathInt) bevl_i );
bevt_56_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_11));
bevt_55_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_56_ta_ph);
bevl_toRet = bevt_55_ta_ph.bemd_1(-782071312, bevl_nl);
bevt_57_ta_ph = bevl_arg.bemd_0(-2854699);
if (((BEC_2_5_4_LogicBool) bevt_57_ta_ph).bevi_bool)/* Line: 470*/ {
bevt_60_ta_ph = bevl_arg.bemd_0(-152378021);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(1297296473);
bevt_58_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_59_ta_ph);
bevl_toRet = bevt_58_ta_ph.bemd_1(-782071312, bevl_nl);
} /* Line: 471*/
 else /* Line: 472*/ {
bevt_62_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_61_ta_ph = bevl_toRet.bemd_1(-782071312, bevt_62_ta_ph);
bevl_toRet = bevt_61_ta_ph.bemd_1(-782071312, bevl_nl);
} /* Line: 473*/
bevl_i = bevl_i.bemd_0(322754171);
} /* Line: 466*/
 else /* Line: 466*/ {
break;
} /* Line: 466*/
} /* Line: 466*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_getEmitReturnType_2(BEC_2_5_8_BuildClassSyn beva_csyn, BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_4_LogicBool bevl_covariantReturns = null;
BEC_2_5_10_BuildEmitCommon bevl_ec = null;
BEC_2_5_8_BuildClassSyn bevl_cs = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_3_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_7_ta_ph = null;
BEC_2_5_6_BuildVarSyn bevt_8_ta_ph = null;
bevl_covariantReturns = be.BECS_Runtime.boolTrue;
bevl_ec = beva_build.bem_emitCommonGet_0();
if (bevl_ec == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 482*/ {
bevl_covariantReturns = (BEC_2_5_4_LogicBool) bevl_ec.bem_covariantReturnsGet_0();
} /* Line: 483*/
if (bevp_rsyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 485*/ {
if (bevl_covariantReturns.bevi_bool)/* Line: 486*/ {
bevt_2_ta_ph = bevp_rsyn.bem_isSelfGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 487*/ {
bevt_3_ta_ph = beva_csyn.bem_namepathGet_0();
return bevt_3_ta_ph;
} /* Line: 488*/
 else /* Line: 489*/ {
bevt_4_ta_ph = bevp_rsyn.bem_namepathGet_0();
return bevt_4_ta_ph;
} /* Line: 490*/
} /* Line: 487*/
 else /* Line: 492*/ {
bevt_5_ta_ph = bevp_rsyn.bem_isSelfGet_0();
if (bevt_5_ta_ph.bevi_bool)/* Line: 493*/ {
return bevp_declaration;
} /* Line: 494*/
 else /* Line: 495*/ {
bevl_cs = beva_build.bem_getSynNp_1(bevp_declaration);
bevt_6_ta_ph = bevl_cs.bem_mtdMapGet_0();
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevt_6_ta_ph.bem_get_1(bevp_name);
bevt_8_ta_ph = bevl_ms.bem_rsynGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_namepathGet_0();
return bevt_7_ta_ph;
} /* Line: 498*/
} /* Line: 493*/
} /* Line: 486*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_hposGet_0() throws Throwable {
return bevp_hpos;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_hposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxGet_0() throws Throwable {
return bevp_mtdx;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_mtdxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argSynsGet_0() throws Throwable {
return bevp_argSyns;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_argSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lastDefGet_0() throws Throwable {
return bevp_lastDef;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_lastDefSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOverrideGet_0() throws Throwable {
return bevp_isOverride;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isOverrideSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_propertyNameGet_0() throws Throwable {
return bevp_propertyName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_propertyNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_rsynGet_0() throws Throwable {
return bevp_rsyn;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_rsynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {418, 424, 425, 426, 427, 428, 428, 428, 430, 432, 433, 434, 435, 435, 435, 436, 436, 438, 438, 438, 439, 439, 443, 443, 443, 444, 444, 444, 445, 445, 445, 445, 444, 451, 451, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 452, 453, 453, 453, 453, 453, 453, 454, 454, 454, 454, 454, 454, 455, 455, 455, 455, 455, 455, 456, 456, 457, 457, 457, 457, 457, 459, 459, 459, 459, 459, 459, 460, 460, 460, 461, 461, 461, 0, 0, 0, 462, 462, 462, 462, 464, 464, 464, 466, 466, 466, 467, 469, 469, 469, 470, 471, 471, 471, 471, 473, 473, 473, 466, 476, 480, 481, 482, 482, 483, 485, 485, 487, 488, 488, 490, 490, 493, 494, 496, 497, 497, 498, 498, 498, 502, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 74, 75, 76, 78, 79, 84, 85, 86, 88, 89, 90, 91, 94, 95, 97, 98, 99, 100, 101, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 220, 221, 222, 223, 224, 225, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 241, 242, 244, 247, 251, 254, 255, 256, 257, 260, 261, 262, 264, 267, 268, 270, 271, 272, 273, 274, 276, 277, 278, 279, 282, 283, 284, 286, 292, 308, 309, 310, 315, 316, 318, 323, 325, 327, 328, 331, 332, 336, 338, 341, 342, 343, 344, 345, 346, 350, 353, 356, 360, 363, 367, 370, 374, 377, 381, 384, 388, 391, 395, 398, 402, 405, 409, 412, 416, 419, 423, 426, 430, 433, 437, 440, 444, 447};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 418 56
heldGet 0 418 56
assign 1 424 57
numargsGet 0 424 57
assign 1 425 58
nameGet 0 425 58
assign 1 426 59
orgNameGet 0 426 59
assign 1 427 60
isGenAccessorGet 0 427 60
assign 1 428 61
new 0 428 61
assign 1 428 62
add 1 428 62
assign 1 428 63
new 1 428 63
assign 1 430 64
assign 1 432 65
new 0 432 65
assign 1 433 66
new 0 433 66
assign 1 434 67
isFinalGet 0 434 67
assign 1 435 68
propertyGet 0 435 68
assign 1 435 69
def 1 435 74
assign 1 436 75
propertyGet 0 436 75
assign 1 436 76
nameGet 0 436 76
assign 1 438 78
rtypeGet 0 438 78
assign 1 438 79
def 1 438 84
assign 1 439 85
rtypeGet 0 439 85
assign 1 439 86
anyNew 1 439 86
assign 1 443 88
containedGet 0 443 88
assign 1 443 89
firstGet 0 443 89
assign 1 443 90
containedGet 0 443 90
assign 1 444 91
new 0 444 91
assign 1 444 94
lengthGet 0 444 94
assign 1 444 95
lesser 1 444 95
assign 1 445 97
get 1 445 97
assign 1 445 98
heldGet 0 445 98
assign 1 445 99
anyNew 1 445 99
put 2 445 100
assign 1 444 101
increment 0 444 101
assign 1 451 177
new 0 451 177
assign 1 451 178
newlineGet 0 451 178
assign 1 452 179
new 0 452 179
assign 1 452 180
add 1 452 180
assign 1 452 181
new 0 452 181
assign 1 452 182
add 1 452 182
assign 1 452 183
add 1 452 183
assign 1 452 184
add 1 452 184
assign 1 452 185
add 1 452 185
assign 1 452 186
new 0 452 186
assign 1 452 187
add 1 452 187
assign 1 452 188
add 1 452 188
assign 1 452 189
add 1 452 189
assign 1 452 190
add 1 452 190
assign 1 452 191
new 0 452 191
assign 1 452 192
add 1 452 192
assign 1 452 193
add 1 452 193
assign 1 452 194
toString 0 452 194
assign 1 452 195
add 1 452 195
assign 1 452 196
add 1 452 196
assign 1 453 197
new 0 453 197
assign 1 453 198
add 1 453 198
assign 1 453 199
add 1 453 199
assign 1 453 200
toString 0 453 200
assign 1 453 201
add 1 453 201
assign 1 453 202
add 1 453 202
assign 1 454 203
new 0 454 203
assign 1 454 204
add 1 454 204
assign 1 454 205
add 1 454 205
assign 1 454 206
toString 0 454 206
assign 1 454 207
add 1 454 207
assign 1 454 208
add 1 454 208
assign 1 455 209
new 0 455 209
assign 1 455 210
add 1 455 210
assign 1 455 211
add 1 455 211
assign 1 455 212
toString 0 455 212
assign 1 455 213
add 1 455 213
assign 1 455 214
add 1 455 214
assign 1 456 215
def 1 456 220
assign 1 457 221
new 0 457 221
assign 1 457 222
add 1 457 222
assign 1 457 223
add 1 457 223
assign 1 457 224
add 1 457 224
assign 1 457 225
add 1 457 225
assign 1 459 227
new 0 459 227
assign 1 459 228
add 1 459 228
assign 1 459 229
add 1 459 229
assign 1 459 230
toString 0 459 230
assign 1 459 231
add 1 459 231
assign 1 459 232
add 1 459 232
assign 1 460 233
new 0 460 233
assign 1 460 234
add 1 460 234
assign 1 460 235
add 1 460 235
assign 1 461 236
def 1 461 241
assign 1 461 242
isTypedGet 0 461 242
assign 1 0 244
assign 1 0 247
assign 1 0 251
assign 1 462 254
namepathGet 0 462 254
assign 1 462 255
toString 0 462 255
assign 1 462 256
add 1 462 256
assign 1 462 257
add 1 462 257
assign 1 464 260
new 0 464 260
assign 1 464 261
add 1 464 261
assign 1 464 262
add 1 464 262
assign 1 466 264
new 0 466 264
assign 1 466 267
lengthGet 0 466 267
assign 1 466 268
lesser 1 466 268
assign 1 467 270
get 1 467 270
assign 1 469 271
new 0 469 271
assign 1 469 272
add 1 469 272
assign 1 469 273
add 1 469 273
assign 1 470 274
isTypedGet 0 470 274
assign 1 471 276
namepathGet 0 471 276
assign 1 471 277
toString 0 471 277
assign 1 471 278
add 1 471 278
assign 1 471 279
add 1 471 279
assign 1 473 282
new 0 473 282
assign 1 473 283
add 1 473 283
assign 1 473 284
add 1 473 284
assign 1 466 286
increment 0 466 286
return 1 476 292
assign 1 480 308
new 0 480 308
assign 1 481 309
emitCommonGet 0 481 309
assign 1 482 310
def 1 482 315
assign 1 483 316
covariantReturnsGet 0 483 316
assign 1 485 318
def 1 485 323
assign 1 487 325
isSelfGet 0 487 325
assign 1 488 327
namepathGet 0 488 327
return 1 488 328
assign 1 490 331
namepathGet 0 490 331
return 1 490 332
assign 1 493 336
isSelfGet 0 493 336
return 1 494 338
assign 1 496 341
getSynNp 1 496 341
assign 1 497 342
mtdMapGet 0 497 342
assign 1 497 343
get 1 497 343
assign 1 498 344
rsynGet 0 498 344
assign 1 498 345
namepathGet 0 498 345
return 1 498 346
return 1 502 350
return 1 0 353
assign 1 0 356
return 1 0 360
assign 1 0 363
return 1 0 367
assign 1 0 370
return 1 0 374
assign 1 0 377
return 1 0 381
assign 1 0 384
return 1 0 388
assign 1 0 391
return 1 0 395
assign 1 0 398
return 1 0 402
assign 1 0 405
return 1 0 409
assign 1 0 412
return 1 0 416
assign 1 0 419
return 1 0 423
assign 1 0 426
return 1 0 430
assign 1 0 433
return 1 0 437
assign 1 0 440
return 1 0 444
assign 1 0 447
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 697147549: return bem_rsynGet_0();
case -1510258965: return bem_numargsGet_0();
case -1158554532: return bem_mtdxGet_0();
case 1033905511: return bem_new_0();
case -1084478186: return bem_hposGet_0();
case -451680896: return bem_print_0();
case 1332556390: return bem_create_0();
case -1711970993: return bem_isFinalGet_0();
case 355565519: return bem_iteratorGet_0();
case 940631698: return bem_copy_0();
case -667301419: return bem_propertyNameGet_0();
case -1076766427: return bem_isOverrideGet_0();
case 1248421647: return bem_lastDefGet_0();
case 1297296473: return bem_toString_0();
case 882711031: return bem_orgNameGet_0();
case -569225936: return bem_argSynsGet_0();
case -1948989061: return bem_nameGet_0();
case -1989712623: return bem_hashGet_0();
case -1847502646: return bem_isGenAccessorGet_0();
case -424827578: return bem_declarationGet_0();
case 1525836075: return bem_originGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 355221820: return bem_argSynsSet_1(bevd_0);
case 1953847240: return bem_print_1(bevd_0);
case -618247473: return bem_undef_1(bevd_0);
case -1507640800: return bem_mtdxSet_1(bevd_0);
case -988973480: return bem_originSet_1(bevd_0);
case -1276962946: return bem_propertyNameSet_1(bevd_0);
case 169451331: return bem_numargsSet_1(bevd_0);
case 213200826: return bem_orgNameSet_1(bevd_0);
case -1267449748: return bem_hposSet_1(bevd_0);
case 1110937156: return bem_copyTo_1(bevd_0);
case 276927890: return bem_rsynSet_1(bevd_0);
case -1797378574: return bem_lastDefSet_1(bevd_0);
case -13718717: return bem_declarationSet_1(bevd_0);
case -839494729: return bem_isOverrideSet_1(bevd_0);
case -2069842105: return bem_notEquals_1(bevd_0);
case -178932475: return bem_isGenAccessorSet_1(bevd_0);
case 1161478433: return bem_equals_1(bevd_0);
case -1502338721: return bem_isFinalSet_1(bevd_0);
case 159582032: return bem_def_1(bevd_0);
case 869275925: return bem_nameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 681643689: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2142010341: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -585707959: return bem_getEmitReturnType_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case 1355956619: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1744432305: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -744009288: return bem_new_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMtdSyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildMtdSyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMtdSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst = (BEC_2_5_6_BuildMtdSyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_type;
}
}
