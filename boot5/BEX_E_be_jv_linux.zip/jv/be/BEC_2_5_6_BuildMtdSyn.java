package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildMtdSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMtdSyn() { }
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x74,0x64,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_2 = {0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_3 = {0x6E,0x75,0x6D,0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_4 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_5 = {0x6C,0x61,0x73,0x74,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_6 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_7 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_8 = {0x69,0x73,0x47,0x65,0x6E,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_9 = {0x72,0x73,0x79,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_10 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_11 = {0x61,0x72,0x67,0x54,0x79,0x70,0x65};
public static BEC_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;

public static BET_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_type;

public BEC_2_4_3_MathInt bevp_hpos;
public BEC_2_4_3_MathInt bevp_mtdx;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_9_4_ContainerList bevp_argSyns;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_5_4_LogicBool bevp_lastDef;
public BEC_2_5_4_LogicBool bevp_isOverride;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_6_TextString bevp_propertyName;
public BEC_2_5_6_BuildVarSyn bevp_rsyn;
public BEC_2_5_6_BuildMtdSyn bem_new_2(BEC_2_6_6_SystemObject beva_snode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_args = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_6_BuildVarSyn bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
bevl_s = beva_snode.bemd_0(1057163409);
bevp_numargs = (BEC_2_4_3_MathInt) bevl_s.bemd_0(-101668690);
bevp_name = (BEC_2_4_6_TextString) bevl_s.bemd_0(270119447);
bevp_orgName = (BEC_2_4_6_TextString) bevl_s.bemd_0(-1578035348);
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(-2030236274);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevp_numargs.bem_add_1(bevt_1_ta_ph);
bevp_argSyns = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_lastDef = be.BECS_Runtime.boolTrue;
bevp_isOverride = be.BECS_Runtime.boolFalse;
bevp_isFinal = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(-1250468677);
bevt_3_ta_ph = bevl_s.bemd_0(-404694434);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 430*/ {
bevt_4_ta_ph = bevl_s.bemd_0(-404694434);
bevp_propertyName = (BEC_2_4_6_TextString) bevt_4_ta_ph.bemd_0(270119447);
} /* Line: 431*/
bevt_6_ta_ph = bevl_s.bemd_0(2011856661);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 433*/ {
bevt_7_ta_ph = bevl_s.bemd_0(2011856661);
bevp_rsyn = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_7_ta_ph );
} /* Line: 434*/
bevt_9_ta_ph = beva_snode.bemd_0(1699813941);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1722773489);
bevl_args = bevt_8_ta_ph.bemd_0(1699813941);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 439*/ {
bevt_11_ta_ph = bevp_argSyns.bem_lengthGet_0();
bevt_10_ta_ph = bevl_i.bemd_1(-718131056, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 439*/ {
bevt_14_ta_ph = bevl_args.bemd_1(-448571762, bevl_i);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(1057163409);
bevt_12_ta_ph = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_13_ta_ph );
bevp_argSyns.bem_put_2((BEC_2_4_3_MathInt) bevl_i , bevt_12_ta_ph);
bevl_i = bevl_i.bemd_0(936320339);
} /* Line: 439*/
 else /* Line: 439*/ {
break;
} /* Line: 439*/
} /* Line: 439*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_arg = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_1_ta_ph.bem_newlineGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_0));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevl_nl);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevp_name);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_nl);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_2));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_nl);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevp_orgName);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevl_nl);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_3));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_17_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevl_nl);
bevt_18_ta_ph = bevp_numargs.bem_toString_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_18_ta_ph);
bevl_toRet = bevt_2_ta_ph.bem_add_1(bevl_nl);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_4));
bevt_21_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_22_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_23_ta_ph = bevp_origin.bem_toString_0();
bevt_19_ta_ph = bevt_20_ta_ph.bemd_1(-150118586, bevt_23_ta_ph);
bevl_toRet = bevt_19_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_5));
bevt_26_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_27_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_28_ta_ph = bevp_lastDef.bem_toString_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(-150118586, bevt_28_ta_ph);
bevl_toRet = bevt_24_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_6));
bevt_31_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_32_ta_ph);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_33_ta_ph = bevp_isFinal.bem_toString_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(-150118586, bevt_33_ta_ph);
bevl_toRet = bevt_29_ta_ph.bemd_1(-150118586, bevl_nl);
if (bevp_propertyName == null) {
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 451*/ {
bevt_38_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_6_BuildMtdSyn_bels_7));
bevt_37_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_38_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_35_ta_ph = bevt_36_ta_ph.bemd_1(-150118586, bevp_propertyName);
bevl_toRet = bevt_35_ta_ph.bemd_1(-150118586, bevl_nl);
} /* Line: 452*/
bevt_42_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_6_BuildMtdSyn_bels_8));
bevt_41_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_42_ta_ph);
bevt_40_ta_ph = bevt_41_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_43_ta_ph = bevp_isGenAccessor.bem_toString_0();
bevt_39_ta_ph = bevt_40_ta_ph.bemd_1(-150118586, bevt_43_ta_ph);
bevl_toRet = bevt_39_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_9));
bevt_44_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_45_ta_ph);
bevl_toRet = bevt_44_ta_ph.bemd_1(-150118586, bevl_nl);
if (bevp_rsyn == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 456*/ {
bevt_47_ta_ph = bevp_rsyn.bem_isTypedGet_0();
if (bevt_47_ta_ph.bevi_bool)/* Line: 456*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 456*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 456*/
 else /* Line: 456*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 456*/ {
bevt_50_ta_ph = bevp_rsyn.bem_namepathGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_toString_0();
bevt_48_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_49_ta_ph);
bevl_toRet = bevt_48_ta_ph.bemd_1(-150118586, bevl_nl);
} /* Line: 457*/
 else /* Line: 458*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_51_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_52_ta_ph);
bevl_toRet = bevt_51_ta_ph.bemd_1(-150118586, bevl_nl);
} /* Line: 459*/
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 461*/ {
bevt_54_ta_ph = bevp_argSyns.bem_lengthGet_0();
bevt_53_ta_ph = bevl_i.bemd_1(-718131056, bevt_54_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 461*/ {
bevl_arg = bevp_argSyns.bem_get_1((BEC_2_4_3_MathInt) bevl_i );
bevt_56_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_11));
bevt_55_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_56_ta_ph);
bevl_toRet = bevt_55_ta_ph.bemd_1(-150118586, bevl_nl);
bevt_57_ta_ph = bevl_arg.bemd_0(57827996);
if (((BEC_2_5_4_LogicBool) bevt_57_ta_ph).bevi_bool)/* Line: 465*/ {
bevt_60_ta_ph = bevl_arg.bemd_0(-851723463);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(634420526);
bevt_58_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_59_ta_ph);
bevl_toRet = bevt_58_ta_ph.bemd_1(-150118586, bevl_nl);
} /* Line: 466*/
 else /* Line: 467*/ {
bevt_62_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_61_ta_ph = bevl_toRet.bemd_1(-150118586, bevt_62_ta_ph);
bevl_toRet = bevt_61_ta_ph.bemd_1(-150118586, bevl_nl);
} /* Line: 468*/
bevl_i = bevl_i.bemd_0(936320339);
} /* Line: 461*/
 else /* Line: 461*/ {
break;
} /* Line: 461*/
} /* Line: 461*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_getEmitReturnType_2(BEC_2_5_8_BuildClassSyn beva_csyn, BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_4_LogicBool bevl_covariantReturns = null;
BEC_2_5_10_BuildEmitCommon bevl_ec = null;
BEC_2_5_8_BuildClassSyn bevl_cs = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_3_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_7_ta_ph = null;
BEC_2_5_6_BuildVarSyn bevt_8_ta_ph = null;
bevl_covariantReturns = be.BECS_Runtime.boolTrue;
bevl_ec = beva_build.bem_emitCommonGet_0();
if (bevl_ec == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 477*/ {
bevl_covariantReturns = (BEC_2_5_4_LogicBool) bevl_ec.bem_covariantReturnsGet_0();
} /* Line: 478*/
if (bevp_rsyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 480*/ {
if (bevl_covariantReturns.bevi_bool)/* Line: 481*/ {
bevt_2_ta_ph = bevp_rsyn.bem_isSelfGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 482*/ {
bevt_3_ta_ph = beva_csyn.bem_namepathGet_0();
return bevt_3_ta_ph;
} /* Line: 483*/
 else /* Line: 484*/ {
bevt_4_ta_ph = bevp_rsyn.bem_namepathGet_0();
return bevt_4_ta_ph;
} /* Line: 485*/
} /* Line: 482*/
 else /* Line: 487*/ {
bevt_5_ta_ph = bevp_rsyn.bem_isSelfGet_0();
if (bevt_5_ta_ph.bevi_bool)/* Line: 488*/ {
return bevp_declaration;
} /* Line: 489*/
 else /* Line: 490*/ {
bevl_cs = beva_build.bem_getSynNp_1(bevp_declaration);
bevt_6_ta_ph = bevl_cs.bem_mtdMapGet_0();
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevt_6_ta_ph.bem_get_1(bevp_name);
bevt_8_ta_ph = bevl_ms.bem_rsynGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_namepathGet_0();
return bevt_7_ta_ph;
} /* Line: 493*/
} /* Line: 488*/
} /* Line: 481*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_hposGet_0() throws Throwable {
return bevp_hpos;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_hposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxGet_0() throws Throwable {
return bevp_mtdx;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_mtdxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argSynsGet_0() throws Throwable {
return bevp_argSyns;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_argSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lastDefGet_0() throws Throwable {
return bevp_lastDef;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_lastDefSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOverrideGet_0() throws Throwable {
return bevp_isOverride;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isOverrideSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_propertyNameGet_0() throws Throwable {
return bevp_propertyName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_propertyNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_rsynGet_0() throws Throwable {
return bevp_rsyn;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_rsynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {413, 419, 420, 421, 422, 423, 423, 423, 425, 427, 428, 429, 430, 430, 430, 431, 431, 433, 433, 433, 434, 434, 438, 438, 438, 439, 439, 439, 440, 440, 440, 440, 439, 446, 446, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 448, 448, 448, 448, 448, 448, 449, 449, 449, 449, 449, 449, 450, 450, 450, 450, 450, 450, 451, 451, 452, 452, 452, 452, 452, 454, 454, 454, 454, 454, 454, 455, 455, 455, 456, 456, 456, 0, 0, 0, 457, 457, 457, 457, 459, 459, 459, 461, 461, 461, 462, 464, 464, 464, 465, 466, 466, 466, 466, 468, 468, 468, 461, 471, 475, 476, 477, 477, 478, 480, 480, 482, 483, 483, 485, 485, 488, 489, 491, 492, 492, 493, 493, 493, 497, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 74, 75, 76, 78, 79, 84, 85, 86, 88, 89, 90, 91, 94, 95, 97, 98, 99, 100, 101, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 220, 221, 222, 223, 224, 225, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 241, 242, 244, 247, 251, 254, 255, 256, 257, 260, 261, 262, 264, 267, 268, 270, 271, 272, 273, 274, 276, 277, 278, 279, 282, 283, 284, 286, 292, 308, 309, 310, 315, 316, 318, 323, 325, 327, 328, 331, 332, 336, 338, 341, 342, 343, 344, 345, 346, 350, 353, 356, 360, 363, 367, 370, 374, 377, 381, 384, 388, 391, 395, 398, 402, 405, 409, 412, 416, 419, 423, 426, 430, 433, 437, 440, 444, 447};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 413 56
heldGet 0 413 56
assign 1 419 57
numargsGet 0 419 57
assign 1 420 58
nameGet 0 420 58
assign 1 421 59
orgNameGet 0 421 59
assign 1 422 60
isGenAccessorGet 0 422 60
assign 1 423 61
new 0 423 61
assign 1 423 62
add 1 423 62
assign 1 423 63
new 1 423 63
assign 1 425 64
assign 1 427 65
new 0 427 65
assign 1 428 66
new 0 428 66
assign 1 429 67
isFinalGet 0 429 67
assign 1 430 68
propertyGet 0 430 68
assign 1 430 69
def 1 430 74
assign 1 431 75
propertyGet 0 431 75
assign 1 431 76
nameGet 0 431 76
assign 1 433 78
rtypeGet 0 433 78
assign 1 433 79
def 1 433 84
assign 1 434 85
rtypeGet 0 434 85
assign 1 434 86
anyNew 1 434 86
assign 1 438 88
containedGet 0 438 88
assign 1 438 89
firstGet 0 438 89
assign 1 438 90
containedGet 0 438 90
assign 1 439 91
new 0 439 91
assign 1 439 94
lengthGet 0 439 94
assign 1 439 95
lesser 1 439 95
assign 1 440 97
get 1 440 97
assign 1 440 98
heldGet 0 440 98
assign 1 440 99
anyNew 1 440 99
put 2 440 100
assign 1 439 101
increment 0 439 101
assign 1 446 177
new 0 446 177
assign 1 446 178
newlineGet 0 446 178
assign 1 447 179
new 0 447 179
assign 1 447 180
add 1 447 180
assign 1 447 181
new 0 447 181
assign 1 447 182
add 1 447 182
assign 1 447 183
add 1 447 183
assign 1 447 184
add 1 447 184
assign 1 447 185
add 1 447 185
assign 1 447 186
new 0 447 186
assign 1 447 187
add 1 447 187
assign 1 447 188
add 1 447 188
assign 1 447 189
add 1 447 189
assign 1 447 190
add 1 447 190
assign 1 447 191
new 0 447 191
assign 1 447 192
add 1 447 192
assign 1 447 193
add 1 447 193
assign 1 447 194
toString 0 447 194
assign 1 447 195
add 1 447 195
assign 1 447 196
add 1 447 196
assign 1 448 197
new 0 448 197
assign 1 448 198
add 1 448 198
assign 1 448 199
add 1 448 199
assign 1 448 200
toString 0 448 200
assign 1 448 201
add 1 448 201
assign 1 448 202
add 1 448 202
assign 1 449 203
new 0 449 203
assign 1 449 204
add 1 449 204
assign 1 449 205
add 1 449 205
assign 1 449 206
toString 0 449 206
assign 1 449 207
add 1 449 207
assign 1 449 208
add 1 449 208
assign 1 450 209
new 0 450 209
assign 1 450 210
add 1 450 210
assign 1 450 211
add 1 450 211
assign 1 450 212
toString 0 450 212
assign 1 450 213
add 1 450 213
assign 1 450 214
add 1 450 214
assign 1 451 215
def 1 451 220
assign 1 452 221
new 0 452 221
assign 1 452 222
add 1 452 222
assign 1 452 223
add 1 452 223
assign 1 452 224
add 1 452 224
assign 1 452 225
add 1 452 225
assign 1 454 227
new 0 454 227
assign 1 454 228
add 1 454 228
assign 1 454 229
add 1 454 229
assign 1 454 230
toString 0 454 230
assign 1 454 231
add 1 454 231
assign 1 454 232
add 1 454 232
assign 1 455 233
new 0 455 233
assign 1 455 234
add 1 455 234
assign 1 455 235
add 1 455 235
assign 1 456 236
def 1 456 241
assign 1 456 242
isTypedGet 0 456 242
assign 1 0 244
assign 1 0 247
assign 1 0 251
assign 1 457 254
namepathGet 0 457 254
assign 1 457 255
toString 0 457 255
assign 1 457 256
add 1 457 256
assign 1 457 257
add 1 457 257
assign 1 459 260
new 0 459 260
assign 1 459 261
add 1 459 261
assign 1 459 262
add 1 459 262
assign 1 461 264
new 0 461 264
assign 1 461 267
lengthGet 0 461 267
assign 1 461 268
lesser 1 461 268
assign 1 462 270
get 1 462 270
assign 1 464 271
new 0 464 271
assign 1 464 272
add 1 464 272
assign 1 464 273
add 1 464 273
assign 1 465 274
isTypedGet 0 465 274
assign 1 466 276
namepathGet 0 466 276
assign 1 466 277
toString 0 466 277
assign 1 466 278
add 1 466 278
assign 1 466 279
add 1 466 279
assign 1 468 282
new 0 468 282
assign 1 468 283
add 1 468 283
assign 1 468 284
add 1 468 284
assign 1 461 286
increment 0 461 286
return 1 471 292
assign 1 475 308
new 0 475 308
assign 1 476 309
emitCommonGet 0 476 309
assign 1 477 310
def 1 477 315
assign 1 478 316
covariantReturnsGet 0 478 316
assign 1 480 318
def 1 480 323
assign 1 482 325
isSelfGet 0 482 325
assign 1 483 327
namepathGet 0 483 327
return 1 483 328
assign 1 485 331
namepathGet 0 485 331
return 1 485 332
assign 1 488 336
isSelfGet 0 488 336
return 1 489 338
assign 1 491 341
getSynNp 1 491 341
assign 1 492 342
mtdMapGet 0 492 342
assign 1 492 343
get 1 492 343
assign 1 493 344
rsynGet 0 493 344
assign 1 493 345
namepathGet 0 493 345
return 1 493 346
return 1 497 350
return 1 0 353
assign 1 0 356
return 1 0 360
assign 1 0 363
return 1 0 367
assign 1 0 370
return 1 0 374
assign 1 0 377
return 1 0 381
assign 1 0 384
return 1 0 388
assign 1 0 391
return 1 0 395
assign 1 0 398
return 1 0 402
assign 1 0 405
return 1 0 409
assign 1 0 412
return 1 0 416
assign 1 0 419
return 1 0 423
assign 1 0 426
return 1 0 430
assign 1 0 433
return 1 0 437
assign 1 0 440
return 1 0 444
assign 1 0 447
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2031361809: return bem_copy_0();
case -1309846856: return bem_iteratorGet_0();
case 634420526: return bem_toString_0();
case 344895826: return bem_hposGet_0();
case -1578035348: return bem_orgNameGet_0();
case 270119447: return bem_nameGet_0();
case 430355937: return bem_argSynsGet_0();
case 1049095145: return bem_propertyNameGet_0();
case 1682619900: return bem_create_0();
case -2030236274: return bem_isGenAccessorGet_0();
case -1375469734: return bem_declarationGet_0();
case 1781514768: return bem_hashGet_0();
case -1250468677: return bem_isFinalGet_0();
case 1444670188: return bem_mtdxGet_0();
case -101668690: return bem_numargsGet_0();
case 928421251: return bem_print_0();
case -1685684837: return bem_new_0();
case 680770976: return bem_originGet_0();
case -2087171434: return bem_lastDefGet_0();
case 1401252734: return bem_rsynGet_0();
case -77128315: return bem_isOverrideGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 700312642: return bem_declarationSet_1(bevd_0);
case 174250008: return bem_numargsSet_1(bevd_0);
case -924277835: return bem_hposSet_1(bevd_0);
case -1892373240: return bem_argSynsSet_1(bevd_0);
case -1275184899: return bem_copyTo_1(bevd_0);
case -1306683820: return bem_undef_1(bevd_0);
case -149203720: return bem_equals_1(bevd_0);
case -629509142: return bem_isFinalSet_1(bevd_0);
case 346401413: return bem_isOverrideSet_1(bevd_0);
case 2115522970: return bem_def_1(bevd_0);
case 1264542268: return bem_rsynSet_1(bevd_0);
case 1818875884: return bem_originSet_1(bevd_0);
case -316860505: return bem_notEquals_1(bevd_0);
case -1195809874: return bem_propertyNameSet_1(bevd_0);
case -2029997580: return bem_isGenAccessorSet_1(bevd_0);
case -1874277100: return bem_lastDefSet_1(bevd_0);
case 421213927: return bem_nameSet_1(bevd_0);
case -522160868: return bem_orgNameSet_1(bevd_0);
case 1966194621: return bem_mtdxSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034668989: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1926350793: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1406125671: return bem_getEmitReturnType_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case -1233479200: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1286246883: return bem_new_2(bevd_0, bevd_1);
case 1163897030: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMtdSyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildMtdSyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMtdSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst = (BEC_2_5_6_BuildMtdSyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_type;
}
}
