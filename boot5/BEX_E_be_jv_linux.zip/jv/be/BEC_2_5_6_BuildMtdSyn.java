package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildMtdSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMtdSyn() { }
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x74,0x64,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_5_6_BuildMtdSyn_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMtdSyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_0, 6));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMtdSyn_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_1, 4));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_2 = {0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMtdSyn_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_2, 7));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_3 = {0x6E,0x75,0x6D,0x61,0x72,0x67,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMtdSyn_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_3, 7));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_4 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_5 = {0x6C,0x61,0x73,0x74,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_6 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_7 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_8 = {0x69,0x73,0x47,0x65,0x6E,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_9 = {0x72,0x73,0x79,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_10 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_11 = {0x61,0x72,0x67,0x54,0x79,0x70,0x65};
public static BEC_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;

public static BET_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_type;

public BEC_2_4_3_MathInt bevp_hpos;
public BEC_2_4_3_MathInt bevp_mtdx;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_9_4_ContainerList bevp_argSyns;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_5_4_LogicBool bevp_lastDef;
public BEC_2_5_4_LogicBool bevp_isOverride;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_6_TextString bevp_propertyName;
public BEC_2_5_6_BuildVarSyn bevp_rsyn;
public BEC_2_5_6_BuildMtdSyn bem_new_2(BEC_2_6_6_SystemObject beva_snode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_args = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_6_BuildVarSyn bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevl_s = beva_snode.bemd_0(-1155282071);
bevp_numargs = (BEC_2_4_3_MathInt) bevl_s.bemd_0(-736386230);
bevp_name = (BEC_2_4_6_TextString) bevl_s.bemd_0(-1284507729);
bevp_orgName = (BEC_2_4_6_TextString) bevl_s.bemd_0(963489153);
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(-1824735868);
bevt_1_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_0;
bevt_0_tmpany_phold = bevp_numargs.bem_add_1(bevt_1_tmpany_phold);
bevp_argSyns = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_lastDef = be.BECS_Runtime.boolTrue;
bevp_isOverride = be.BECS_Runtime.boolFalse;
bevp_isFinal = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(-944159272);
bevt_3_tmpany_phold = bevl_s.bemd_0(-392616842);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 430 */ {
bevt_4_tmpany_phold = bevl_s.bemd_0(-392616842);
bevp_propertyName = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bemd_0(-1284507729);
} /* Line: 431 */
bevt_6_tmpany_phold = bevl_s.bemd_0(692074320);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 433 */ {
bevt_7_tmpany_phold = bevl_s.bemd_0(692074320);
bevp_rsyn = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_7_tmpany_phold );
} /* Line: 434 */
bevt_9_tmpany_phold = beva_snode.bemd_0(784618553);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-755903458);
bevl_args = bevt_8_tmpany_phold.bemd_0(784618553);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 439 */ {
bevt_11_tmpany_phold = bevp_argSyns.bem_lengthGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_1(-949787536, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 439 */ {
bevt_14_tmpany_phold = bevl_args.bemd_1(143367740, bevl_i);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-1155282071);
bevt_12_tmpany_phold = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_13_tmpany_phold );
bevp_argSyns.bem_put_2((BEC_2_4_3_MathInt) bevl_i , bevt_12_tmpany_phold);
bevl_i = bevl_i.bemd_0(604879763);
} /* Line: 439 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_arg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_1_tmpany_phold.bem_newlineGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_nl);
bevt_15_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevl_nl);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevp_name);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_nl);
bevt_16_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_3;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_16_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_nl);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_orgName);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevl_nl);
bevt_17_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_4;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevl_nl);
bevt_18_tmpany_phold = bevp_numargs.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevl_toRet = bevt_2_tmpany_phold.bem_add_1(bevl_nl);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_4));
bevt_21_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_22_tmpany_phold);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_23_tmpany_phold = bevp_origin.bem_toString_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(994704700, bevt_23_tmpany_phold);
bevl_toRet = bevt_19_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_5));
bevt_26_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_27_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_28_tmpany_phold = bevp_lastDef.bem_toString_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(994704700, bevt_28_tmpany_phold);
bevl_toRet = bevt_24_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_6));
bevt_31_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_32_tmpany_phold);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_33_tmpany_phold = bevp_isFinal.bem_toString_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_1(994704700, bevt_33_tmpany_phold);
bevl_toRet = bevt_29_tmpany_phold.bemd_1(994704700, bevl_nl);
if (bevp_propertyName == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 451 */ {
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_6_BuildMtdSyn_bels_7));
bevt_37_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_38_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_1(994704700, bevp_propertyName);
bevl_toRet = bevt_35_tmpany_phold.bemd_1(994704700, bevl_nl);
} /* Line: 452 */
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_6_BuildMtdSyn_bels_8));
bevt_41_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_42_tmpany_phold);
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_43_tmpany_phold = bevp_isGenAccessor.bem_toString_0();
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(994704700, bevt_43_tmpany_phold);
bevl_toRet = bevt_39_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_9));
bevt_44_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_45_tmpany_phold);
bevl_toRet = bevt_44_tmpany_phold.bemd_1(994704700, bevl_nl);
if (bevp_rsyn == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_47_tmpany_phold = bevp_rsyn.bem_isTypedGet_0();
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 456 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 456 */
 else  /* Line: 456 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 456 */ {
bevt_50_tmpany_phold = bevp_rsyn.bem_namepathGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_toString_0();
bevt_48_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_49_tmpany_phold);
bevl_toRet = bevt_48_tmpany_phold.bemd_1(994704700, bevl_nl);
} /* Line: 457 */
 else  /* Line: 458 */ {
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_51_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_52_tmpany_phold);
bevl_toRet = bevt_51_tmpany_phold.bemd_1(994704700, bevl_nl);
} /* Line: 459 */
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 461 */ {
bevt_54_tmpany_phold = bevp_argSyns.bem_lengthGet_0();
bevt_53_tmpany_phold = bevl_i.bemd_1(-949787536, bevt_54_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_53_tmpany_phold).bevi_bool) /* Line: 461 */ {
bevl_arg = bevp_argSyns.bem_get_1((BEC_2_4_3_MathInt) bevl_i );
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_11));
bevt_55_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_56_tmpany_phold);
bevl_toRet = bevt_55_tmpany_phold.bemd_1(994704700, bevl_nl);
bevt_57_tmpany_phold = bevl_arg.bemd_0(-407978987);
if (((BEC_2_5_4_LogicBool) bevt_57_tmpany_phold).bevi_bool) /* Line: 465 */ {
bevt_60_tmpany_phold = bevl_arg.bemd_0(-1548759582);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(2036147796);
bevt_58_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_59_tmpany_phold);
bevl_toRet = bevt_58_tmpany_phold.bemd_1(994704700, bevl_nl);
} /* Line: 466 */
 else  /* Line: 467 */ {
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_61_tmpany_phold = bevl_toRet.bemd_1(994704700, bevt_62_tmpany_phold);
bevl_toRet = bevt_61_tmpany_phold.bemd_1(994704700, bevl_nl);
} /* Line: 468 */
bevl_i = bevl_i.bemd_0(604879763);
} /* Line: 461 */
 else  /* Line: 461 */ {
break;
} /* Line: 461 */
} /* Line: 461 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_getEmitReturnType_2(BEC_2_5_8_BuildClassSyn beva_csyn, BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_4_LogicBool bevl_covariantReturns = null;
BEC_2_5_10_BuildEmitCommon bevl_ec = null;
BEC_2_5_8_BuildClassSyn bevl_cs = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_3_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_7_tmpany_phold = null;
BEC_2_5_6_BuildVarSyn bevt_8_tmpany_phold = null;
bevl_covariantReturns = be.BECS_Runtime.boolTrue;
bevl_ec = beva_build.bem_emitCommonGet_0();
if (bevl_ec == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 477 */ {
bevl_covariantReturns = (BEC_2_5_4_LogicBool) bevl_ec.bem_covariantReturnsGet_0();
} /* Line: 478 */
if (bevp_rsyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 480 */ {
if (bevl_covariantReturns.bevi_bool) /* Line: 481 */ {
bevt_2_tmpany_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_3_tmpany_phold = beva_csyn.bem_namepathGet_0();
return bevt_3_tmpany_phold;
} /* Line: 483 */
 else  /* Line: 484 */ {
bevt_4_tmpany_phold = bevp_rsyn.bem_namepathGet_0();
return bevt_4_tmpany_phold;
} /* Line: 485 */
} /* Line: 482 */
 else  /* Line: 487 */ {
bevt_5_tmpany_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 488 */ {
return bevp_declaration;
} /* Line: 489 */
 else  /* Line: 490 */ {
bevl_cs = beva_build.bem_getSynNp_1(bevp_declaration);
bevt_6_tmpany_phold = bevl_cs.bem_mtdMapGet_0();
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevt_6_tmpany_phold.bem_get_1(bevp_name);
bevt_8_tmpany_phold = bevl_ms.bem_rsynGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_namepathGet_0();
return bevt_7_tmpany_phold;
} /* Line: 493 */
} /* Line: 488 */
} /* Line: 481 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_hposGet_0() throws Throwable {
return bevp_hpos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_hposGetDirect_0() throws Throwable {
return bevp_hpos;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_hposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_hposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxGet_0() throws Throwable {
return bevp_mtdx;
} /*method end*/
public final BEC_2_4_3_MathInt bem_mtdxGetDirect_0() throws Throwable {
return bevp_mtdx;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_mtdxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_mtdxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_numargsGetDirect_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public final BEC_2_4_6_TextString bem_orgNameGetDirect_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isGenAccessorGetDirect_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argSynsGet_0() throws Throwable {
return bevp_argSyns;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argSynsGetDirect_0() throws Throwable {
return bevp_argSyns;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_argSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_argSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_originGetDirect_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_originSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_declarationGetDirect_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_declarationSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lastDefGet_0() throws Throwable {
return bevp_lastDef;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_lastDefGetDirect_0() throws Throwable {
return bevp_lastDef;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_lastDefSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_lastDefSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOverrideGet_0() throws Throwable {
return bevp_isOverride;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isOverrideGetDirect_0() throws Throwable {
return bevp_isOverride;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isOverrideSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_isOverrideSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_propertyNameGet_0() throws Throwable {
return bevp_propertyName;
} /*method end*/
public final BEC_2_4_6_TextString bem_propertyNameGetDirect_0() throws Throwable {
return bevp_propertyName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_propertyNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_propertyNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_rsynGet_0() throws Throwable {
return bevp_rsyn;
} /*method end*/
public final BEC_2_5_6_BuildVarSyn bem_rsynGetDirect_0() throws Throwable {
return bevp_rsyn;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_rsynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_rsynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {413, 419, 420, 421, 422, 423, 423, 423, 425, 427, 428, 429, 430, 430, 430, 431, 431, 433, 433, 433, 434, 434, 438, 438, 438, 439, 439, 439, 440, 440, 440, 440, 439, 446, 446, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 448, 448, 448, 448, 448, 448, 449, 449, 449, 449, 449, 449, 450, 450, 450, 450, 450, 450, 451, 451, 452, 452, 452, 452, 452, 454, 454, 454, 454, 454, 454, 455, 455, 455, 456, 456, 456, 0, 0, 0, 457, 457, 457, 457, 459, 459, 459, 461, 461, 461, 462, 464, 464, 464, 465, 466, 466, 466, 466, 468, 468, 468, 461, 471, 475, 476, 477, 477, 478, 480, 480, 482, 483, 483, 485, 485, 488, 489, 491, 492, 492, 493, 493, 493, 497, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 79, 80, 81, 83, 84, 89, 90, 91, 93, 94, 95, 96, 99, 100, 102, 103, 104, 105, 106, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 225, 226, 227, 228, 229, 230, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 246, 247, 249, 252, 256, 259, 260, 261, 262, 265, 266, 267, 269, 272, 273, 275, 276, 277, 278, 279, 281, 282, 283, 284, 287, 288, 289, 291, 297, 313, 314, 315, 320, 321, 323, 328, 330, 332, 333, 336, 337, 341, 343, 346, 347, 348, 349, 350, 351, 355, 358, 361, 364, 368, 372, 375, 378, 382, 386, 389, 392, 396, 400, 403, 406, 410, 414, 417, 420, 424, 428, 431, 434, 438, 442, 445, 448, 452, 456, 459, 462, 466, 470, 473, 476, 480, 484, 487, 490, 494, 498, 501, 504, 508, 512, 515, 518, 522, 526, 529, 532, 536, 540, 543, 546, 550};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 413 61
heldGet 0 413 61
assign 1 419 62
numargsGet 0 419 62
assign 1 420 63
nameGet 0 420 63
assign 1 421 64
orgNameGet 0 421 64
assign 1 422 65
isGenAccessorGet 0 422 65
assign 1 423 66
new 0 423 66
assign 1 423 67
add 1 423 67
assign 1 423 68
new 1 423 68
assign 1 425 69
assign 1 427 70
new 0 427 70
assign 1 428 71
new 0 428 71
assign 1 429 72
isFinalGet 0 429 72
assign 1 430 73
propertyGet 0 430 73
assign 1 430 74
def 1 430 79
assign 1 431 80
propertyGet 0 431 80
assign 1 431 81
nameGet 0 431 81
assign 1 433 83
rtypeGet 0 433 83
assign 1 433 84
def 1 433 89
assign 1 434 90
rtypeGet 0 434 90
assign 1 434 91
anyNew 1 434 91
assign 1 438 93
containedGet 0 438 93
assign 1 438 94
firstGet 0 438 94
assign 1 438 95
containedGet 0 438 95
assign 1 439 96
new 0 439 96
assign 1 439 99
lengthGet 0 439 99
assign 1 439 100
lesser 1 439 100
assign 1 440 102
get 1 440 102
assign 1 440 103
heldGet 0 440 103
assign 1 440 104
anyNew 1 440 104
put 2 440 105
assign 1 439 106
increment 0 439 106
assign 1 446 182
new 0 446 182
assign 1 446 183
newlineGet 0 446 183
assign 1 447 184
new 0 447 184
assign 1 447 185
add 1 447 185
assign 1 447 186
new 0 447 186
assign 1 447 187
add 1 447 187
assign 1 447 188
add 1 447 188
assign 1 447 189
add 1 447 189
assign 1 447 190
add 1 447 190
assign 1 447 191
new 0 447 191
assign 1 447 192
add 1 447 192
assign 1 447 193
add 1 447 193
assign 1 447 194
add 1 447 194
assign 1 447 195
add 1 447 195
assign 1 447 196
new 0 447 196
assign 1 447 197
add 1 447 197
assign 1 447 198
add 1 447 198
assign 1 447 199
toString 0 447 199
assign 1 447 200
add 1 447 200
assign 1 447 201
add 1 447 201
assign 1 448 202
new 0 448 202
assign 1 448 203
add 1 448 203
assign 1 448 204
add 1 448 204
assign 1 448 205
toString 0 448 205
assign 1 448 206
add 1 448 206
assign 1 448 207
add 1 448 207
assign 1 449 208
new 0 449 208
assign 1 449 209
add 1 449 209
assign 1 449 210
add 1 449 210
assign 1 449 211
toString 0 449 211
assign 1 449 212
add 1 449 212
assign 1 449 213
add 1 449 213
assign 1 450 214
new 0 450 214
assign 1 450 215
add 1 450 215
assign 1 450 216
add 1 450 216
assign 1 450 217
toString 0 450 217
assign 1 450 218
add 1 450 218
assign 1 450 219
add 1 450 219
assign 1 451 220
def 1 451 225
assign 1 452 226
new 0 452 226
assign 1 452 227
add 1 452 227
assign 1 452 228
add 1 452 228
assign 1 452 229
add 1 452 229
assign 1 452 230
add 1 452 230
assign 1 454 232
new 0 454 232
assign 1 454 233
add 1 454 233
assign 1 454 234
add 1 454 234
assign 1 454 235
toString 0 454 235
assign 1 454 236
add 1 454 236
assign 1 454 237
add 1 454 237
assign 1 455 238
new 0 455 238
assign 1 455 239
add 1 455 239
assign 1 455 240
add 1 455 240
assign 1 456 241
def 1 456 246
assign 1 456 247
isTypedGet 0 456 247
assign 1 0 249
assign 1 0 252
assign 1 0 256
assign 1 457 259
namepathGet 0 457 259
assign 1 457 260
toString 0 457 260
assign 1 457 261
add 1 457 261
assign 1 457 262
add 1 457 262
assign 1 459 265
new 0 459 265
assign 1 459 266
add 1 459 266
assign 1 459 267
add 1 459 267
assign 1 461 269
new 0 461 269
assign 1 461 272
lengthGet 0 461 272
assign 1 461 273
lesser 1 461 273
assign 1 462 275
get 1 462 275
assign 1 464 276
new 0 464 276
assign 1 464 277
add 1 464 277
assign 1 464 278
add 1 464 278
assign 1 465 279
isTypedGet 0 465 279
assign 1 466 281
namepathGet 0 466 281
assign 1 466 282
toString 0 466 282
assign 1 466 283
add 1 466 283
assign 1 466 284
add 1 466 284
assign 1 468 287
new 0 468 287
assign 1 468 288
add 1 468 288
assign 1 468 289
add 1 468 289
assign 1 461 291
increment 0 461 291
return 1 471 297
assign 1 475 313
new 0 475 313
assign 1 476 314
emitCommonGet 0 476 314
assign 1 477 315
def 1 477 320
assign 1 478 321
covariantReturnsGet 0 478 321
assign 1 480 323
def 1 480 328
assign 1 482 330
isSelfGet 0 482 330
assign 1 483 332
namepathGet 0 483 332
return 1 483 333
assign 1 485 336
namepathGet 0 485 336
return 1 485 337
assign 1 488 341
isSelfGet 0 488 341
return 1 489 343
assign 1 491 346
getSynNp 1 491 346
assign 1 492 347
mtdMapGet 0 492 347
assign 1 492 348
get 1 492 348
assign 1 493 349
rsynGet 0 493 349
assign 1 493 350
namepathGet 0 493 350
return 1 493 351
return 1 497 355
return 1 0 358
return 1 0 361
assign 1 0 364
assign 1 0 368
return 1 0 372
return 1 0 375
assign 1 0 378
assign 1 0 382
return 1 0 386
return 1 0 389
assign 1 0 392
assign 1 0 396
return 1 0 400
return 1 0 403
assign 1 0 406
assign 1 0 410
return 1 0 414
return 1 0 417
assign 1 0 420
assign 1 0 424
return 1 0 428
return 1 0 431
assign 1 0 434
assign 1 0 438
return 1 0 442
return 1 0 445
assign 1 0 448
assign 1 0 452
return 1 0 456
return 1 0 459
assign 1 0 462
assign 1 0 466
return 1 0 470
return 1 0 473
assign 1 0 476
assign 1 0 480
return 1 0 484
return 1 0 487
assign 1 0 490
assign 1 0 494
return 1 0 498
return 1 0 501
assign 1 0 504
assign 1 0 508
return 1 0 512
return 1 0 515
assign 1 0 518
assign 1 0 522
return 1 0 526
return 1 0 529
assign 1 0 532
assign 1 0 536
return 1 0 540
return 1 0 543
assign 1 0 546
assign 1 0 550
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1196464323: return bem_propertyNameGetDirect_0();
case -1799004294: return bem_mtdxGetDirect_0();
case -1500978633: return bem_tagGet_0();
case 2102651338: return bem_fieldIteratorGet_0();
case 1935079892: return bem_isOverrideGetDirect_0();
case -126294549: return bem_rsynGet_0();
case -1589675737: return bem_numargsGetDirect_0();
case -744998425: return bem_rsynGetDirect_0();
case -1551806822: return bem_toAny_0();
case -944159272: return bem_isFinalGet_0();
case 1316278315: return bem_lastDefGetDirect_0();
case -1061682091: return bem_propertyNameGet_0();
case -1683807411: return bem_isGenAccessorGetDirect_0();
case 1201799861: return bem_serializeToString_0();
case 930967743: return bem_originGetDirect_0();
case -114079936: return bem_serializeContents_0();
case 919386304: return bem_isFinalGetDirect_0();
case -1797568580: return bem_isOverrideGet_0();
case 382911813: return bem_mtdxGet_0();
case -2067124685: return bem_argSynsGetDirect_0();
case -1284507729: return bem_nameGet_0();
case -1451511826: return bem_argSynsGet_0();
case 2036147796: return bem_toString_0();
case -773572117: return bem_originGet_0();
case 1430998361: return bem_serializationIteratorGet_0();
case 191896611: return bem_copy_0();
case 396948391: return bem_hposGet_0();
case -2072472298: return bem_hashGet_0();
case -1737009900: return bem_many_0();
case -1066226610: return bem_fieldNamesGet_0();
case 1319683316: return bem_lastDefGet_0();
case 1478640887: return bem_hposGetDirect_0();
case 1525639803: return bem_sourceFileNameGet_0();
case -1824735868: return bem_isGenAccessorGet_0();
case 963489153: return bem_orgNameGet_0();
case 653341959: return bem_print_0();
case -1759630984: return bem_classNameGet_0();
case 1617352083: return bem_orgNameGetDirect_0();
case -1195111829: return bem_create_0();
case -1237954331: return bem_declarationGet_0();
case 573647971: return bem_iteratorGet_0();
case -935190118: return bem_nameGetDirect_0();
case -1976480232: return bem_once_0();
case -1748925107: return bem_echo_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case -736386230: return bem_numargsGet_0();
case 458030968: return bem_declarationGetDirect_0();
case -1439875774: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1098806105: return bem_orgNameSetDirect_1(bevd_0);
case -113521893: return bem_isFinalSet_1(bevd_0);
case 884462515: return bem_def_1(bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
case 2061494599: return bem_rsynSet_1(bevd_0);
case -2011647532: return bem_declarationSetDirect_1(bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
case 213074863: return bem_lastDefSet_1(bevd_0);
case 1070067814: return bem_propertyNameSetDirect_1(bevd_0);
case -102295312: return bem_sameObject_1(bevd_0);
case 876864451: return bem_argSynsSet_1(bevd_0);
case -621616996: return bem_isFinalSetDirect_1(bevd_0);
case -1020735923: return bem_isGenAccessorSet_1(bevd_0);
case 1081373953: return bem_nameSetDirect_1(bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case 824730773: return bem_hposSet_1(bevd_0);
case -192271885: return bem_equals_1(bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1676265411: return bem_hposSetDirect_1(bevd_0);
case 1193349327: return bem_numargsSet_1(bevd_0);
case 759564511: return bem_argSynsSetDirect_1(bevd_0);
case -286281893: return bem_declarationSet_1(bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case 397796439: return bem_propertyNameSet_1(bevd_0);
case 43770127: return bem_lastDefSetDirect_1(bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
case -483075912: return bem_mtdxSetDirect_1(bevd_0);
case -2118907284: return bem_numargsSetDirect_1(bevd_0);
case -714992280: return bem_nameSet_1(bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 145168057: return bem_originSetDirect_1(bevd_0);
case -1463054301: return bem_originSet_1(bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1106889746: return bem_rsynSetDirect_1(bevd_0);
case 1866001617: return bem_mtdxSet_1(bevd_0);
case 1397160658: return bem_orgNameSet_1(bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case -531996206: return bem_isGenAccessorSetDirect_1(bevd_0);
case 1771653708: return bem_isOverrideSet_1(bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1348373010: return bem_isOverrideSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2112530015: return bem_new_2(bevd_0, bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1236087900: return bem_getEmitReturnType_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMtdSyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildMtdSyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMtdSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst = (BEC_2_5_6_BuildMtdSyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_type;
}
}
