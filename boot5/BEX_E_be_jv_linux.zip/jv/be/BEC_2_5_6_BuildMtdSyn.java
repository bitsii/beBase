package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildMtdSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMtdSyn() { }
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x74,0x64,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_5_6_BuildMtdSyn_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMtdSyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_0, 6));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMtdSyn_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_1, 4));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_2 = {0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMtdSyn_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_2, 7));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_3 = {0x6E,0x75,0x6D,0x61,0x72,0x67,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMtdSyn_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_3, 7));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_4 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_5 = {0x6C,0x61,0x73,0x74,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_6 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_7 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_8 = {0x69,0x73,0x47,0x65,0x6E,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_9 = {0x72,0x73,0x79,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_10 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_11 = {0x61,0x72,0x67,0x54,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_12 = {0x61,0x6E,0x79};
public static BEC_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;

public static BET_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_type;

public BEC_2_4_3_MathInt bevp_hpos;
public BEC_2_4_3_MathInt bevp_mtdx;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_9_4_ContainerList bevp_argSyns;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_5_4_LogicBool bevp_lastDef;
public BEC_2_5_4_LogicBool bevp_isOverride;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_6_TextString bevp_propertyName;
public BEC_2_5_6_BuildVarSyn bevp_rsyn;
public BEC_2_5_6_BuildMtdSyn bem_new_2(BEC_2_6_6_SystemObject beva_snode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_args = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_6_BuildVarSyn bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevl_s = beva_snode.bemd_0(45432222);
bevp_numargs = (BEC_2_4_3_MathInt) bevl_s.bemd_0(41306043);
bevp_name = (BEC_2_4_6_TextString) bevl_s.bemd_0(-391498004);
bevp_orgName = (BEC_2_4_6_TextString) bevl_s.bemd_0(1631654986);
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(-292553833);
bevt_1_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_0;
bevt_0_tmpany_phold = bevp_numargs.bem_add_1(bevt_1_tmpany_phold);
bevp_argSyns = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_lastDef = be.BECS_Runtime.boolTrue;
bevp_isOverride = be.BECS_Runtime.boolFalse;
bevp_isFinal = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(827741506);
bevt_3_tmpany_phold = bevl_s.bemd_0(58265813);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 431 */ {
bevt_4_tmpany_phold = bevl_s.bemd_0(58265813);
bevp_propertyName = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bemd_0(-391498004);
} /* Line: 432 */
bevt_6_tmpany_phold = bevl_s.bemd_0(2035941246);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 434 */ {
bevt_7_tmpany_phold = bevl_s.bemd_0(2035941246);
bevp_rsyn = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_7_tmpany_phold );
} /* Line: 435 */
bevt_9_tmpany_phold = beva_snode.bemd_0(1327301284);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1473587806);
bevl_args = bevt_8_tmpany_phold.bemd_0(1327301284);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 440 */ {
bevt_11_tmpany_phold = bevp_argSyns.bem_lengthGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_1(-2109949123, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 440 */ {
bevt_14_tmpany_phold = bevl_args.bemd_1(-1183192776, bevl_i);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(45432222);
bevt_12_tmpany_phold = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_13_tmpany_phold );
bevp_argSyns.bem_put_2((BEC_2_4_3_MathInt) bevl_i , bevt_12_tmpany_phold);
bevl_i = bevl_i.bemd_0(-706494002);
} /* Line: 440 */
 else  /* Line: 440 */ {
break;
} /* Line: 440 */
} /* Line: 440 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_arg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_1_tmpany_phold.bem_newlineGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_nl);
bevt_15_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevl_nl);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevp_name);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_nl);
bevt_16_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_3;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_16_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_nl);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_orgName);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevl_nl);
bevt_17_tmpany_phold = bece_BEC_2_5_6_BuildMtdSyn_bevo_4;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevl_nl);
bevt_18_tmpany_phold = bevp_numargs.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevl_toRet = bevt_2_tmpany_phold.bem_add_1(bevl_nl);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_4));
bevt_21_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_22_tmpany_phold);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_23_tmpany_phold = bevp_origin.bem_toString_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(300779148, bevt_23_tmpany_phold);
bevl_toRet = bevt_19_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_5));
bevt_26_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_27_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_28_tmpany_phold = bevp_lastDef.bem_toString_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(300779148, bevt_28_tmpany_phold);
bevl_toRet = bevt_24_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_6));
bevt_31_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_32_tmpany_phold);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_33_tmpany_phold = bevp_isFinal.bem_toString_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_1(300779148, bevt_33_tmpany_phold);
bevl_toRet = bevt_29_tmpany_phold.bemd_1(300779148, bevl_nl);
if (bevp_propertyName == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 452 */ {
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_6_BuildMtdSyn_bels_7));
bevt_37_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_38_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_1(300779148, bevp_propertyName);
bevl_toRet = bevt_35_tmpany_phold.bemd_1(300779148, bevl_nl);
} /* Line: 453 */
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_6_BuildMtdSyn_bels_8));
bevt_41_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_42_tmpany_phold);
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_43_tmpany_phold = bevp_isGenAccessor.bem_toString_0();
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(300779148, bevt_43_tmpany_phold);
bevl_toRet = bevt_39_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_9));
bevt_44_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_45_tmpany_phold);
bevl_toRet = bevt_44_tmpany_phold.bemd_1(300779148, bevl_nl);
if (bevp_rsyn == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_47_tmpany_phold = bevp_rsyn.bem_isTypedGet_0();
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 457 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 457 */ {
bevt_50_tmpany_phold = bevp_rsyn.bem_namepathGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_toString_0();
bevt_48_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_49_tmpany_phold);
bevl_toRet = bevt_48_tmpany_phold.bemd_1(300779148, bevl_nl);
} /* Line: 458 */
 else  /* Line: 459 */ {
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_51_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_52_tmpany_phold);
bevl_toRet = bevt_51_tmpany_phold.bemd_1(300779148, bevl_nl);
} /* Line: 460 */
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 462 */ {
bevt_54_tmpany_phold = bevp_argSyns.bem_lengthGet_0();
bevt_53_tmpany_phold = bevl_i.bemd_1(-2109949123, bevt_54_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_53_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevl_arg = bevp_argSyns.bem_get_1((BEC_2_4_3_MathInt) bevl_i );
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_11));
bevt_55_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_56_tmpany_phold);
bevl_toRet = bevt_55_tmpany_phold.bemd_1(300779148, bevl_nl);
bevt_57_tmpany_phold = bevl_arg.bemd_0(-2015010121);
if (((BEC_2_5_4_LogicBool) bevt_57_tmpany_phold).bevi_bool) /* Line: 466 */ {
bevt_60_tmpany_phold = bevl_arg.bemd_0(592530042);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-169510412);
bevt_58_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_59_tmpany_phold);
bevl_toRet = bevt_58_tmpany_phold.bemd_1(300779148, bevl_nl);
} /* Line: 467 */
 else  /* Line: 468 */ {
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_12));
bevt_61_tmpany_phold = bevl_toRet.bemd_1(300779148, bevt_62_tmpany_phold);
bevl_toRet = bevt_61_tmpany_phold.bemd_1(300779148, bevl_nl);
} /* Line: 469 */
bevl_i = bevl_i.bemd_0(-706494002);
} /* Line: 462 */
 else  /* Line: 462 */ {
break;
} /* Line: 462 */
} /* Line: 462 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_getEmitReturnType_2(BEC_2_5_8_BuildClassSyn beva_csyn, BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_4_LogicBool bevl_coanyiantReturns = null;
BEC_2_5_10_BuildEmitCommon bevl_ec = null;
BEC_2_5_8_BuildClassSyn bevl_cs = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_3_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_7_tmpany_phold = null;
BEC_2_5_6_BuildVarSyn bevt_8_tmpany_phold = null;
bevl_coanyiantReturns = be.BECS_Runtime.boolTrue;
bevl_ec = beva_build.bem_emitCommonGet_0();
if (bevl_ec == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 478 */ {
bevl_coanyiantReturns = (BEC_2_5_4_LogicBool) bevl_ec.bem_coanyiantReturnsGet_0();
} /* Line: 479 */
if (bevp_rsyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 481 */ {
if (bevl_coanyiantReturns.bevi_bool) /* Line: 482 */ {
bevt_2_tmpany_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 483 */ {
bevt_3_tmpany_phold = beva_csyn.bem_namepathGet_0();
return bevt_3_tmpany_phold;
} /* Line: 484 */
 else  /* Line: 485 */ {
bevt_4_tmpany_phold = bevp_rsyn.bem_namepathGet_0();
return bevt_4_tmpany_phold;
} /* Line: 486 */
} /* Line: 483 */
 else  /* Line: 488 */ {
bevt_5_tmpany_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 489 */ {
return bevp_declaration;
} /* Line: 490 */
 else  /* Line: 491 */ {
bevl_cs = beva_build.bem_getSynNp_1(bevp_declaration);
bevt_6_tmpany_phold = bevl_cs.bem_mtdMapGet_0();
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevt_6_tmpany_phold.bem_get_1(bevp_name);
bevt_8_tmpany_phold = bevl_ms.bem_rsynGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_namepathGet_0();
return bevt_7_tmpany_phold;
} /* Line: 494 */
} /* Line: 489 */
} /* Line: 482 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_hposGet_0() throws Throwable {
return bevp_hpos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_hposGetDirect_0() throws Throwable {
return bevp_hpos;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_hposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_hposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxGet_0() throws Throwable {
return bevp_mtdx;
} /*method end*/
public final BEC_2_4_3_MathInt bem_mtdxGetDirect_0() throws Throwable {
return bevp_mtdx;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_mtdxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_mtdxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_numargsGetDirect_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public final BEC_2_4_6_TextString bem_orgNameGetDirect_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isGenAccessorGetDirect_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argSynsGet_0() throws Throwable {
return bevp_argSyns;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argSynsGetDirect_0() throws Throwable {
return bevp_argSyns;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_argSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_argSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_originGetDirect_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_originSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_declarationGetDirect_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_declarationSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lastDefGet_0() throws Throwable {
return bevp_lastDef;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_lastDefGetDirect_0() throws Throwable {
return bevp_lastDef;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_lastDefSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_lastDefSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOverrideGet_0() throws Throwable {
return bevp_isOverride;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isOverrideGetDirect_0() throws Throwable {
return bevp_isOverride;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isOverrideSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_isOverrideSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_propertyNameGet_0() throws Throwable {
return bevp_propertyName;
} /*method end*/
public final BEC_2_4_6_TextString bem_propertyNameGetDirect_0() throws Throwable {
return bevp_propertyName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_propertyNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_propertyNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_rsynGet_0() throws Throwable {
return bevp_rsyn;
} /*method end*/
public final BEC_2_5_6_BuildVarSyn bem_rsynGetDirect_0() throws Throwable {
return bevp_rsyn;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_rsynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_rsynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {414, 420, 421, 422, 423, 424, 424, 424, 426, 428, 429, 430, 431, 431, 431, 432, 432, 434, 434, 434, 435, 435, 439, 439, 439, 440, 440, 440, 441, 441, 441, 441, 440, 447, 447, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 449, 449, 449, 449, 449, 449, 450, 450, 450, 450, 450, 450, 451, 451, 451, 451, 451, 451, 452, 452, 453, 453, 453, 453, 453, 455, 455, 455, 455, 455, 455, 456, 456, 456, 457, 457, 457, 0, 0, 0, 458, 458, 458, 458, 460, 460, 460, 462, 462, 462, 463, 465, 465, 465, 466, 467, 467, 467, 467, 469, 469, 469, 462, 472, 476, 477, 478, 478, 479, 481, 481, 483, 484, 484, 486, 486, 489, 490, 492, 493, 493, 494, 494, 494, 498, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 80, 81, 82, 84, 85, 90, 91, 92, 94, 95, 96, 97, 100, 101, 103, 104, 105, 106, 107, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 226, 227, 228, 229, 230, 231, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 247, 248, 250, 253, 257, 260, 261, 262, 263, 266, 267, 268, 270, 273, 274, 276, 277, 278, 279, 280, 282, 283, 284, 285, 288, 289, 290, 292, 298, 314, 315, 316, 321, 322, 324, 329, 331, 333, 334, 337, 338, 342, 344, 347, 348, 349, 350, 351, 352, 356, 359, 362, 365, 369, 373, 376, 379, 383, 387, 390, 393, 397, 401, 404, 407, 411, 415, 418, 421, 425, 429, 432, 435, 439, 443, 446, 449, 453, 457, 460, 463, 467, 471, 474, 477, 481, 485, 488, 491, 495, 499, 502, 505, 509, 513, 516, 519, 523, 527, 530, 533, 537, 541, 544, 547, 551};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 414 62
heldGet 0 414 62
assign 1 420 63
numargsGet 0 420 63
assign 1 421 64
nameGet 0 421 64
assign 1 422 65
orgNameGet 0 422 65
assign 1 423 66
isGenAccessorGet 0 423 66
assign 1 424 67
new 0 424 67
assign 1 424 68
add 1 424 68
assign 1 424 69
new 1 424 69
assign 1 426 70
assign 1 428 71
new 0 428 71
assign 1 429 72
new 0 429 72
assign 1 430 73
isFinalGet 0 430 73
assign 1 431 74
propertyGet 0 431 74
assign 1 431 75
def 1 431 80
assign 1 432 81
propertyGet 0 432 81
assign 1 432 82
nameGet 0 432 82
assign 1 434 84
rtypeGet 0 434 84
assign 1 434 85
def 1 434 90
assign 1 435 91
rtypeGet 0 435 91
assign 1 435 92
anyNew 1 435 92
assign 1 439 94
containedGet 0 439 94
assign 1 439 95
firstGet 0 439 95
assign 1 439 96
containedGet 0 439 96
assign 1 440 97
new 0 440 97
assign 1 440 100
lengthGet 0 440 100
assign 1 440 101
lesser 1 440 101
assign 1 441 103
get 1 441 103
assign 1 441 104
heldGet 0 441 104
assign 1 441 105
anyNew 1 441 105
put 2 441 106
assign 1 440 107
increment 0 440 107
assign 1 447 183
new 0 447 183
assign 1 447 184
newlineGet 0 447 184
assign 1 448 185
new 0 448 185
assign 1 448 186
add 1 448 186
assign 1 448 187
new 0 448 187
assign 1 448 188
add 1 448 188
assign 1 448 189
add 1 448 189
assign 1 448 190
add 1 448 190
assign 1 448 191
add 1 448 191
assign 1 448 192
new 0 448 192
assign 1 448 193
add 1 448 193
assign 1 448 194
add 1 448 194
assign 1 448 195
add 1 448 195
assign 1 448 196
add 1 448 196
assign 1 448 197
new 0 448 197
assign 1 448 198
add 1 448 198
assign 1 448 199
add 1 448 199
assign 1 448 200
toString 0 448 200
assign 1 448 201
add 1 448 201
assign 1 448 202
add 1 448 202
assign 1 449 203
new 0 449 203
assign 1 449 204
add 1 449 204
assign 1 449 205
add 1 449 205
assign 1 449 206
toString 0 449 206
assign 1 449 207
add 1 449 207
assign 1 449 208
add 1 449 208
assign 1 450 209
new 0 450 209
assign 1 450 210
add 1 450 210
assign 1 450 211
add 1 450 211
assign 1 450 212
toString 0 450 212
assign 1 450 213
add 1 450 213
assign 1 450 214
add 1 450 214
assign 1 451 215
new 0 451 215
assign 1 451 216
add 1 451 216
assign 1 451 217
add 1 451 217
assign 1 451 218
toString 0 451 218
assign 1 451 219
add 1 451 219
assign 1 451 220
add 1 451 220
assign 1 452 221
def 1 452 226
assign 1 453 227
new 0 453 227
assign 1 453 228
add 1 453 228
assign 1 453 229
add 1 453 229
assign 1 453 230
add 1 453 230
assign 1 453 231
add 1 453 231
assign 1 455 233
new 0 455 233
assign 1 455 234
add 1 455 234
assign 1 455 235
add 1 455 235
assign 1 455 236
toString 0 455 236
assign 1 455 237
add 1 455 237
assign 1 455 238
add 1 455 238
assign 1 456 239
new 0 456 239
assign 1 456 240
add 1 456 240
assign 1 456 241
add 1 456 241
assign 1 457 242
def 1 457 247
assign 1 457 248
isTypedGet 0 457 248
assign 1 0 250
assign 1 0 253
assign 1 0 257
assign 1 458 260
namepathGet 0 458 260
assign 1 458 261
toString 0 458 261
assign 1 458 262
add 1 458 262
assign 1 458 263
add 1 458 263
assign 1 460 266
new 0 460 266
assign 1 460 267
add 1 460 267
assign 1 460 268
add 1 460 268
assign 1 462 270
new 0 462 270
assign 1 462 273
lengthGet 0 462 273
assign 1 462 274
lesser 1 462 274
assign 1 463 276
get 1 463 276
assign 1 465 277
new 0 465 277
assign 1 465 278
add 1 465 278
assign 1 465 279
add 1 465 279
assign 1 466 280
isTypedGet 0 466 280
assign 1 467 282
namepathGet 0 467 282
assign 1 467 283
toString 0 467 283
assign 1 467 284
add 1 467 284
assign 1 467 285
add 1 467 285
assign 1 469 288
new 0 469 288
assign 1 469 289
add 1 469 289
assign 1 469 290
add 1 469 290
assign 1 462 292
increment 0 462 292
return 1 472 298
assign 1 476 314
new 0 476 314
assign 1 477 315
emitCommonGet 0 477 315
assign 1 478 316
def 1 478 321
assign 1 479 322
coanyiantReturnsGet 0 479 322
assign 1 481 324
def 1 481 329
assign 1 483 331
isSelfGet 0 483 331
assign 1 484 333
namepathGet 0 484 333
return 1 484 334
assign 1 486 337
namepathGet 0 486 337
return 1 486 338
assign 1 489 342
isSelfGet 0 489 342
return 1 490 344
assign 1 492 347
getSynNp 1 492 347
assign 1 493 348
mtdMapGet 0 493 348
assign 1 493 349
get 1 493 349
assign 1 494 350
rsynGet 0 494 350
assign 1 494 351
namepathGet 0 494 351
return 1 494 352
return 1 498 356
return 1 0 359
return 1 0 362
assign 1 0 365
assign 1 0 369
return 1 0 373
return 1 0 376
assign 1 0 379
assign 1 0 383
return 1 0 387
return 1 0 390
assign 1 0 393
assign 1 0 397
return 1 0 401
return 1 0 404
assign 1 0 407
assign 1 0 411
return 1 0 415
return 1 0 418
assign 1 0 421
assign 1 0 425
return 1 0 429
return 1 0 432
assign 1 0 435
assign 1 0 439
return 1 0 443
return 1 0 446
assign 1 0 449
assign 1 0 453
return 1 0 457
return 1 0 460
assign 1 0 463
assign 1 0 467
return 1 0 471
return 1 0 474
assign 1 0 477
assign 1 0 481
return 1 0 485
return 1 0 488
assign 1 0 491
assign 1 0 495
return 1 0 499
return 1 0 502
assign 1 0 505
assign 1 0 509
return 1 0 513
return 1 0 516
assign 1 0 519
assign 1 0 523
return 1 0 527
return 1 0 530
assign 1 0 533
assign 1 0 537
return 1 0 541
return 1 0 544
assign 1 0 547
assign 1 0 551
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1202859281: return bem_fieldIteratorGet_0();
case 1459838927: return bem_isOverrideGetDirect_0();
case 1800213309: return bem_serializeContents_0();
case 41306043: return bem_numargsGet_0();
case 827741506: return bem_isFinalGet_0();
case -169510412: return bem_toString_0();
case -458279913: return bem_serializationIteratorGet_0();
case 1166902012: return bem_print_0();
case 221369236: return bem_echo_0();
case -1787512772: return bem_declarationGet_0();
case -1188524968: return bem_argSynsGetDirect_0();
case 1631654986: return bem_orgNameGet_0();
case 737627600: return bem_classNameGet_0();
case -1627101286: return bem_many_0();
case -1721224705: return bem_copy_0();
case 405873321: return bem_isFinalGetDirect_0();
case 1088887689: return bem_rsynGet_0();
case -1588608331: return bem_iteratorGet_0();
case -86990153: return bem_isOverrideGet_0();
case -1760283647: return bem_sourceFileNameGet_0();
case 203118002: return bem_mtdxGetDirect_0();
case -1886121314: return bem_argSynsGet_0();
case -1795410350: return bem_rsynGetDirect_0();
case 1051987946: return bem_propertyNameGet_0();
case -165877765: return bem_create_0();
case 586787044: return bem_toAny_0();
case -1339700361: return bem_lastDefGet_0();
case 419402773: return bem_fieldNamesGet_0();
case 238043725: return bem_originGetDirect_0();
case -391498004: return bem_nameGet_0();
case -1272397972: return bem_declarationGetDirect_0();
case 894872688: return bem_propertyNameGetDirect_0();
case 456060581: return bem_mtdxGet_0();
case 162960848: return bem_nameGetDirect_0();
case 903643430: return bem_originGet_0();
case -292553833: return bem_isGenAccessorGet_0();
case -1145946037: return bem_serializeToString_0();
case 1823794563: return bem_hposGet_0();
case -1200024888: return bem_tagGet_0();
case 1662643176: return bem_new_0();
case 761146123: return bem_numargsGetDirect_0();
case -1855742442: return bem_deserializeClassNameGet_0();
case 2080729457: return bem_lastDefGetDirect_0();
case -4634496: return bem_once_0();
case -12708128: return bem_hashGet_0();
case 1056343534: return bem_orgNameGetDirect_0();
case -1474522735: return bem_hposGetDirect_0();
case 1296599024: return bem_isGenAccessorGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 475333261: return bem_orgNameSet_1(bevd_0);
case 1396328003: return bem_otherClass_1(bevd_0);
case -1129560464: return bem_numargsSet_1(bevd_0);
case -1516117771: return bem_mtdxSet_1(bevd_0);
case -1617140536: return bem_defined_1(bevd_0);
case 1113431578: return bem_declarationSet_1(bevd_0);
case -683317602: return bem_rsynSet_1(bevd_0);
case 1423668476: return bem_isFinalSetDirect_1(bevd_0);
case 639831022: return bem_propertyNameSet_1(bevd_0);
case 498138257: return bem_rsynSetDirect_1(bevd_0);
case -1356610189: return bem_argSynsSetDirect_1(bevd_0);
case 1394516086: return bem_argSynsSet_1(bevd_0);
case 18497077: return bem_isOverrideSetDirect_1(bevd_0);
case -958755189: return bem_declarationSetDirect_1(bevd_0);
case -1694968514: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 418700681: return bem_hposSetDirect_1(bevd_0);
case -1070230026: return bem_mtdxSetDirect_1(bevd_0);
case 1104119798: return bem_orgNameSetDirect_1(bevd_0);
case -2050626933: return bem_def_1(bevd_0);
case -39094467: return bem_equals_1(bevd_0);
case -1880368515: return bem_notEquals_1(bevd_0);
case 684862742: return bem_originSetDirect_1(bevd_0);
case -1058481552: return bem_undef_1(bevd_0);
case -327804541: return bem_sameClass_1(bevd_0);
case -306633068: return bem_undefined_1(bevd_0);
case -1864370670: return bem_numargsSetDirect_1(bevd_0);
case -409899450: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2038137777: return bem_otherType_1(bevd_0);
case -1962816622: return bem_nameSetDirect_1(bevd_0);
case -289953436: return bem_originSet_1(bevd_0);
case 158016071: return bem_hposSet_1(bevd_0);
case -1708488168: return bem_nameSet_1(bevd_0);
case 794930909: return bem_isFinalSet_1(bevd_0);
case 712126324: return bem_isGenAccessorSetDirect_1(bevd_0);
case 1039180755: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1457041804: return bem_isOverrideSet_1(bevd_0);
case -883889211: return bem_sameObject_1(bevd_0);
case -676584356: return bem_isGenAccessorSet_1(bevd_0);
case 286179063: return bem_copyTo_1(bevd_0);
case 1761016699: return bem_lastDefSetDirect_1(bevd_0);
case -1143294403: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 123651906: return bem_lastDefSet_1(bevd_0);
case 1174135522: return bem_sameType_1(bevd_0);
case 1654953339: return bem_propertyNameSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -433647024: return bem_getEmitReturnType_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case -136430353: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -549233499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1776809505: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1983260459: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2126382926: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1853281410: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666962597: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1575283390: return bem_new_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMtdSyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildMtdSyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMtdSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst = (BEC_2_5_6_BuildMtdSyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_type;
}
}
