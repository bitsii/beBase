package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_10_SystemThinThread extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemThinThread() { }

   volatile public Thread bevi_thread;
   static class BECS_Runnable implements Runnable {
    volatile BEC_2_6_10_SystemThinThread bevi_sysThread = null;
    BECS_Runnable(BEC_2_6_10_SystemThinThread bevi_sysThread) {
      this.bevi_sysThread = bevi_sysThread;
    }
    public void run() {
      try {
        bevi_sysThread.bem_main_0();
      } catch (Throwable t) {
        throw new RuntimeException(t.getMessage(), t);
      }
    }
   }
   private static byte[] becc_BEC_2_6_10_SystemThinThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x69,0x6E,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_10_SystemThinThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemThinThread bece_BEC_2_6_10_SystemThinThread_bevs_inst;

public static BET_2_6_10_SystemThinThread bece_BEC_2_6_10_SystemThinThread_bevs_type;

public BEC_2_6_6_SystemObject bevp_toRun;
public BEC_2_6_10_SystemThinThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) throws Throwable {
bevp_toRun = beva__toRun;
return this;
} /*method end*/
public BEC_2_6_10_SystemThinThread bem_start_0() throws Throwable {

     BECS_Runnable bevi_runnable = new BECS_Runnable(this);
     bevi_thread = new Thread(bevi_runnable);
     bevi_thread.start();
     return this;
} /*method end*/
public BEC_2_6_10_SystemThinThread bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
try  /* Line: 742 */ {
bevp_toRun.bemd_0(1528862471);
} /* Line: 743 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 744 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wait_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

     bevi_thread.join();
     bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toRunGet_0() throws Throwable {
return bevp_toRun;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_toRunGetDirect_0() throws Throwable {
return bevp_toRun;
} /*method end*/
public BEC_2_6_10_SystemThinThread bem_toRunSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toRun = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemThinThread bem_toRunSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toRun = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {714, 743, 768, 768, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 43, 54, 55, 58, 61, 64, 68};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 714 30
main 0 743 43
assign 1 768 54
new 0 768 54
return 1 768 55
return 1 0 58
return 1 0 61
assign 1 0 64
assign 1 0 68
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2091241279: return bem_create_0();
case -1400770094: return bem_many_0();
case 1299948053: return bem_serializeContents_0();
case -1942211916: return bem_wait_0();
case 1528862471: return bem_main_0();
case -1423578661: return bem_print_0();
case 758802515: return bem_once_0();
case -512236724: return bem_deserializeClassNameGet_0();
case 1957608515: return bem_fieldIteratorGet_0();
case 660208872: return bem_toRunGet_0();
case -923057320: return bem_serializationIteratorGet_0();
case 1349866592: return bem_toString_0();
case 675566088: return bem_classNameGet_0();
case 2077134217: return bem_start_0();
case -35248652: return bem_toAny_0();
case -914347833: return bem_new_0();
case 345136990: return bem_toRunGetDirect_0();
case -245363326: return bem_copy_0();
case -518710385: return bem_fieldNamesGet_0();
case 518862870: return bem_tagGet_0();
case 1052263558: return bem_serializeToString_0();
case 13807179: return bem_hashGet_0();
case -2035208893: return bem_echo_0();
case 646589914: return bem_sourceFileNameGet_0();
case 993759307: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -537932837: return bem_equals_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case -1599570265: return bem_toRunSetDirect_1(bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case -340377293: return bem_new_1(bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case 758025080: return bem_toRunSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemThinThread_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_10_SystemThinThread_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemThinThread();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_inst = (BEC_2_6_10_SystemThinThread) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_type;
}
}
