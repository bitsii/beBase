package be;
public class BET_2_6_6_SystemThread extends BETS_Object {
public BET_2_6_6_SystemThread() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameType_1", "otherType_1", "new_1", "start_0", "main_0", "wait_0", "toRunGet_0", "toRunSet_1", "startedGet_0", "startedSet_1", "finishedGet_0", "finishedSet_1", "threwExceptionGet_0", "threwExceptionSet_1", "returnedGet_0", "returnedSet_1", "exceptionGet_0", "exceptionSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "toRun", "started", "finished", "threwException", "returned", "exception" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_6_SystemThread();
}
}
