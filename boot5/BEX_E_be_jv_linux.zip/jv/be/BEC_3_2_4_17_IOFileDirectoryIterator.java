package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public final class BEC_3_2_4_17_IOFileDirectoryIterator extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }

   java.io.File[] bevi_dir;
   int bevi_pos = 0;
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_0() throws Throwable {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolFalse;
bevp_current = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) throws Throwable {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 551 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 552 */
 else  /* Line: 554 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 555 */
if (bevp_closed.bevi_bool) /* Line: 558 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 560 */
if (bevp_opened.bevi_bool) /* Line: 562 */ {
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 563 */

      java.io.File bevls_f = new java.io.File(bevl_path.bems_toJvString());
      bevi_dir = bevls_f.listFiles();
      bevi_pos = 0;
      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 584 */ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 587 */
 else  /* Line: 588 */ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
} /* Line: 591 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 596 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 596 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 597 */ {
bem_open_0();
} /* Line: 597 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() throws Throwable {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 602 */ {
return null;
} /* Line: 602 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 603 */ {
bem_open_0();
} /* Line: 603 */
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() throws Throwable {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 613 */ {
return this;
} /* Line: 613 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 614 */ {
return this;
} /* Line: 614 */
if (bevp_current == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 615 */ {
return this;
} /* Line: 615 */

      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 633 */
 else  /* Line: 634 */ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 637 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() throws Throwable {

      bevi_dir = null;
      bevi_pos = 0;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() throws Throwable {
return bevp_dir;
} /*method end*/
public final BEC_2_2_4_IOFile bem_dirGetDirect_0() throws Throwable {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() throws Throwable {
return bevp_opened;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_openedGetDirect_0() throws Throwable {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() throws Throwable {
return bevp_closed;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_closedGetDirect_0() throws Throwable {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public final BEC_2_2_4_IOFile bem_currentGetDirect_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {534, 535, 536, 542, 543, 551, 551, 552, 552, 555, 555, 555, 560, 560, 560, 563, 563, 563, 584, 584, 586, 587, 590, 591, 596, 596, 597, 597, 597, 598, 598, 602, 603, 603, 603, 604, 605, 606, 613, 614, 614, 614, 615, 615, 615, 631, 631, 632, 633, 635, 636, 637, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 25, 26, 30, 31, 46, 51, 52, 53, 56, 57, 58, 61, 62, 63, 66, 67, 68, 78, 83, 84, 85, 88, 89, 98, 99, 101, 106, 107, 109, 114, 120, 122, 127, 128, 130, 131, 132, 140, 142, 147, 148, 150, 155, 156, 163, 168, 169, 170, 173, 174, 175, 186, 189, 192, 196, 200, 203, 206, 210, 214, 217, 220, 224, 228, 231, 234, 238};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 534 24
new 0 534 24
assign 1 535 25
new 0 535 25
assign 1 536 26
new 0 542 30
assign 1 543 31
assign 1 551 46
def 1 551 51
assign 1 552 52
pathGet 0 552 52
assign 1 552 53
toString 0 552 53
assign 1 555 56
new 0 555 56
assign 1 555 57
new 1 555 57
throw 1 555 58
assign 1 560 61
new 0 560 61
assign 1 560 62
new 1 560 62
throw 1 560 63
assign 1 563 66
new 0 563 66
assign 1 563 67
new 1 563 67
throw 1 563 68
assign 1 584 78
def 1 584 83
assign 1 586 84
new 0 586 84
assign 1 587 85
apNew 1 587 85
assign 1 590 88
new 0 590 88
assign 1 591 89
new 0 591 89
assign 1 596 98
new 0 596 98
return 1 596 99
assign 1 597 101
not 0 597 106
open 0 597 107
assign 1 598 109
def 1 598 114
return 1 598 114
return 1 602 120
assign 1 603 122
not 0 603 127
open 0 603 128
assign 1 604 130
advance 0 605 131
return 1 606 132
return 1 613 140
assign 1 614 142
not 0 614 147
return 1 614 148
assign 1 615 150
undef 1 615 155
return 1 615 156
assign 1 631 163
def 1 631 168
assign 1 632 169
new 0 632 169
assign 1 633 170
apNew 1 633 170
assign 1 635 173
new 0 635 173
assign 1 636 174
new 0 636 174
assign 1 637 175
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
return 1 0 214
return 1 0 217
assign 1 0 220
assign 1 0 224
return 1 0 228
return 1 0 231
assign 1 0 234
assign 1 0 238
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1814349985: return bem_openedGet_0();
case -1627101286: return bem_many_0();
case 221369236: return bem_echo_0();
case -169510412: return bem_toString_0();
case -1200024888: return bem_tagGet_0();
case -954578442: return bem_openedGetDirect_0();
case -1145946037: return bem_serializeToString_0();
case -458279913: return bem_serializationIteratorGet_0();
case 1360505099: return bem_currentGetDirect_0();
case 1476711456: return bem_hasNextGet_0();
case 586787044: return bem_toAny_0();
case -708776910: return bem_closedGet_0();
case -4634496: return bem_once_0();
case -1285626820: return bem_advance_0();
case -477751175: return bem_currentGet_0();
case -1721224705: return bem_copy_0();
case 1166902012: return bem_print_0();
case -1760283647: return bem_sourceFileNameGet_0();
case 1662643176: return bem_new_0();
case -1588608331: return bem_iteratorGet_0();
case -1855742442: return bem_deserializeClassNameGet_0();
case -1769365769: return bem_open_0();
case 737627600: return bem_classNameGet_0();
case 1076114865: return bem_dirGetDirect_0();
case -1223869755: return bem_close_0();
case -165877765: return bem_create_0();
case 419402773: return bem_fieldNamesGet_0();
case 1800213309: return bem_serializeContents_0();
case -434574370: return bem_dirGet_0();
case 1759131101: return bem_nextGet_0();
case 1202859281: return bem_fieldIteratorGet_0();
case -12708128: return bem_hashGet_0();
case 1553302: return bem_closedGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -409899450: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1058481552: return bem_undef_1(bevd_0);
case 611716502: return bem_currentSet_1(bevd_0);
case -327804541: return bem_sameClass_1(bevd_0);
case 286179063: return bem_copyTo_1(bevd_0);
case 1174135522: return bem_sameType_1(bevd_0);
case -1641317023: return bem_openedSet_1(bevd_0);
case -306633068: return bem_undefined_1(bevd_0);
case 1396328003: return bem_otherClass_1(bevd_0);
case -2050626933: return bem_def_1(bevd_0);
case 271176995: return bem_closedSet_1(bevd_0);
case -39094467: return bem_equals_1(bevd_0);
case -185617152: return bem_closedSetDirect_1(bevd_0);
case -1880368515: return bem_notEquals_1(bevd_0);
case 1039180755: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -133758080: return bem_dirSetDirect_1(bevd_0);
case -1694968514: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 987201415: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case -2038137777: return bem_otherType_1(bevd_0);
case -300734839: return bem_dirSet_1(bevd_0);
case -1143294403: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1294454508: return bem_openedSetDirect_1(bevd_0);
case -883889211: return bem_sameObject_1(bevd_0);
case -1617140536: return bem_defined_1(bevd_0);
case 23143803: return bem_currentSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -549233499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853281410: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666962597: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1983260459: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -136430353: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2126382926: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1776809505: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
