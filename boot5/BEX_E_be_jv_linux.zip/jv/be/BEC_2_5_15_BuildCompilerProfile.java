package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_15_BuildCompilerProfile extends BEC_2_6_6_SystemObject {
public BEC_2_5_15_BuildCompilerProfile() { }
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72,0x50,0x72,0x6F,0x66,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_0 = {0x2E,0x65,0x78,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_1 = {0x2E,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_2 = {0x2D,0x49,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_3 = {0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_4 = {0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_5 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_6 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_7 = {0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_8 = {0x2E,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_9 = {0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_10 = {0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_11 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_12 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_13 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_14 = {0x61,0x70,0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_15 = {0x61,0x70,0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_16 = {0x61,0x70,0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_17 = {0x61,0x70,0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_18 = {0x6D,0x61,0x63,0x6F,0x73};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_19 = {0x2E,0x64,0x79,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_20 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_21 = {0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_22 = {0x6C,0x69,0x62,0x74,0x6F,0x6F,0x6C,0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6C,0x63,0x63,0x5F,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_23 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_24 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_25 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_26 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_27 = {0x6C,0x69,0x6E,0x75,0x78};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_28 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_29 = {0x2E,0x73,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_30 = {0x20,0x2D,0x66,0x50,0x49,0x43,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_31 = {0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_32 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_33 = {0x6D,0x73,0x76,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_34 = {0x63,0x6C,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_35 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_36 = {0x2D,0x6E,0x6F,0x6C,0x6F,0x67,0x6F,0x20,0x2D,0x4D,0x44,0x20,0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x4D,0x53,0x56,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_37 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x53,0x45,0x43,0x55,0x52,0x45,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x4E,0x4F,0x4E,0x53,0x54,0x44,0x43,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_38 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x44,0x4C,0x4C,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_39 = {0x20,0x2D,0x46,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_40 = {0x63,0x6F,0x70,0x79,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_41 = {0x6D,0x6B,0x64,0x69,0x72,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_42 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_43 = {0x2E,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_44 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_45 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_46 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_47 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_48 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_49 = {0x65,0x78,0x65,0x45,0x78,0x74,0x4F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x5F};
public static BEC_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;

public static BET_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;

public BEC_2_4_6_TextString bevp_exeExt;
public BEC_2_4_6_TextString bevp_libExt;
public BEC_2_4_6_TextString bevp_ccObj;
public BEC_2_4_6_TextString bevp_cc;
public BEC_2_4_6_TextString bevp_cext;
public BEC_2_4_6_TextString bevp_oext;
public BEC_2_4_6_TextString bevp_lBuild;
public BEC_2_4_6_TextString bevp_ccout;
public BEC_2_4_6_TextString bevp_doCopy;
public BEC_2_4_6_TextString bevp_mkdirs;
public BEC_2_4_6_TextString bevp_lexe;
public BEC_2_4_6_TextString bevp_exeLibExt;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_di;
public BEC_2_4_6_TextString bevp_smac;
public BEC_2_4_6_TextString bevp_dialect;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_5_15_BuildCompilerProfile bem_new_1(BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_4_6_TextString bevl_dialectMacro = null;
BEC_2_6_6_SystemObject bevl_exeExtOverride = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
bevp_exeExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_2_ta_ph = beva_build.bemd_0(-1621615340);
bevp_name = (BEC_2_4_6_TextString) bevt_2_ta_ph.bemd_0(1866521645);
bevp_oext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_1));
bevp_di = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_2));
bevp_smac = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_3));
bevp_dialect = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_15_BuildCompilerProfile_bels_4));
bevl_dialectMacro = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_5));
bevt_4_ta_ph = beva_build.bemd_0(1208162359);
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 851*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
beva_build.bemd_1(1662168612, bevt_5_ta_ph);
} /* Line: 852*/
bevp_compiler = (BEC_2_4_6_TextString) beva_build.bemd_0(1208162359);
bevt_7_ta_ph = beva_build.bemd_0(1208162359);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(-652861342, bevt_8_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 855*/ {
bevp_cc = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_7));
bevp_cext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
} /* Line: 857*/
 else /* Line: 855*/ {
bevt_10_ta_ph = beva_build.bemd_0(1208162359);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_9));
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(-652861342, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 858*/ {
bevp_cc = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_10));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
} /* Line: 863*/
 else /* Line: 855*/ {
bevt_13_ta_ph = beva_build.bemd_0(1208162359);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_14));
bevt_12_ta_ph = bevt_13_ta_ph.bemd_1(-652861342, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 864*/ {
bevp_cc = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_15));
bevp_cext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
} /* Line: 867*/
 else /* Line: 855*/ {
bevt_16_ta_ph = beva_build.bemd_0(1208162359);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_16));
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-652861342, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 868*/ {
bevp_cc = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_17));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
} /* Line: 873*/
} /* Line: 855*/
} /* Line: 855*/
} /* Line: 855*/
bevt_20_ta_ph = beva_build.bemd_0(-1621615340);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(1866521645);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_18));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-652861342, bevt_21_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 875*/ {
bevp_libExt = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_19));
bevt_24_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_20));
bevt_23_ta_ph = bevp_cc.bem_add_1(bevt_24_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_15_BuildCompilerProfile_bels_21));
bevp_ccObj = bevt_22_ta_ph.bem_add_1(bevt_25_ta_ph);
bevp_lBuild = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_15_BuildCompilerProfile_bels_22));
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_28_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_15_BuildCompilerProfile_bels_26));
bevt_27_ta_ph = bevp_cc.bem_add_1(bevt_28_ta_ph);
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_lexe = bevt_26_ta_ph.bem_add_1(bevt_29_ta_ph);
bevp_exeLibExt = bevp_libExt;
} /* Line: 883*/
bevt_32_ta_ph = beva_build.bemd_0(-1621615340);
bevt_31_ta_ph = bevt_32_ta_ph.bemd_0(1866521645);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_27));
bevt_30_ta_ph = bevt_31_ta_ph.bemd_1(-652861342, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 885*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 885*/ {
bevt_36_ta_ph = beva_build.bemd_0(-1621615340);
bevt_35_ta_ph = bevt_36_ta_ph.bemd_0(1866521645);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_28));
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(-652861342, bevt_37_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 885*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 885*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 885*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 885*/ {
bevp_libExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_29));
bevt_40_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_20));
bevt_39_ta_ph = bevp_cc.bem_add_1(bevt_40_ta_ph);
bevt_38_ta_ph = bevt_39_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_30));
bevp_ccObj = bevt_38_ta_ph.bem_add_1(bevt_41_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_15_BuildCompilerProfile_bels_26));
bevt_43_ta_ph = bevp_cc.bem_add_1(bevt_44_ta_ph);
bevt_42_ta_ph = bevt_43_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_15_BuildCompilerProfile_bels_31));
bevp_lBuild = bevt_42_ta_ph.bem_add_1(bevt_45_ta_ph);
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_48_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_15_BuildCompilerProfile_bels_26));
bevt_47_ta_ph = bevp_cc.bem_add_1(bevt_48_ta_ph);
bevt_46_ta_ph = bevt_47_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_49_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_lexe = bevt_46_ta_ph.bem_add_1(bevt_49_ta_ph);
bevp_exeLibExt = bevp_libExt;
} /* Line: 893*/
bevt_52_ta_ph = beva_build.bemd_0(-1621615340);
bevt_51_ta_ph = bevt_52_ta_ph.bemd_0(1866521645);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_32));
bevt_50_ta_ph = bevt_51_ta_ph.bemd_1(-652861342, bevt_53_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_50_ta_ph).bevi_bool)/* Line: 895*/ {
bevp_exeExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_55_ta_ph = beva_build.bemd_0(1208162359);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_33));
bevt_54_ta_ph = bevt_55_ta_ph.bemd_1(-652861342, bevt_56_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_54_ta_ph).bevi_bool)/* Line: 897*/ {
bevp_cc = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_34));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
bevp_libExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_59_ta_ph = (new BEC_2_4_6_TextString(45, bece_BEC_2_5_15_BuildCompilerProfile_bels_36));
bevt_58_ta_ph = bevp_cc.bem_add_1(bevt_59_ta_ph);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(76, bece_BEC_2_5_15_BuildCompilerProfile_bels_37));
bevp_ccObj = bevt_57_ta_ph.bem_add_1(bevt_60_ta_ph);
bevp_lBuild = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_15_BuildCompilerProfile_bels_38));
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_39));
bevp_doCopy = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_40));
bevp_mkdirs = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_41));
bevp_lexe = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_42));
bevp_exeLibExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_43));
} /* Line: 909*/
 else /* Line: 910*/ {
bevp_libExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_63_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_15_BuildCompilerProfile_bels_44));
bevt_62_ta_ph = bevp_cc.bem_add_1(bevt_63_ta_ph);
bevt_61_ta_ph = bevt_62_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_64_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_15_BuildCompilerProfile_bels_45));
bevp_ccObj = bevt_61_ta_ph.bem_add_1(bevt_64_ta_ph);
bevt_65_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_15_BuildCompilerProfile_bels_46));
bevp_lBuild = bevp_cc.bem_add_1(bevt_65_ta_ph);
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_68_ta_ph = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_15_BuildCompilerProfile_bels_47));
bevt_67_ta_ph = bevp_cc.bem_add_1(bevt_68_ta_ph);
bevt_66_ta_ph = bevt_67_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_69_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_15_BuildCompilerProfile_bels_48));
bevp_lexe = bevt_66_ta_ph.bem_add_1(bevt_69_ta_ph);
bevp_exeLibExt = bevp_libExt;
} /* Line: 918*/
} /* Line: 897*/
bevt_70_ta_ph = beva_build.bemd_0(1166795459);
bevt_72_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_15_BuildCompilerProfile_bels_49));
bevt_74_ta_ph = beva_build.bemd_0(-1621615340);
bevt_73_ta_ph = bevt_74_ta_ph.bemd_0(1866521645);
bevt_71_ta_ph = bevt_72_ta_ph.bem_add_1(bevt_73_ta_ph);
bevl_exeExtOverride = bevt_70_ta_ph.bemd_1(568678635, bevt_71_ta_ph);
if (bevl_exeExtOverride == null) {
bevt_75_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_75_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_75_ta_ph.bevi_bool)/* Line: 922*/ {
bevt_77_ta_ph = bevl_exeExtOverride.bemd_0(1947029806);
if (bevt_77_ta_ph == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 922*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 922*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 922*/
 else /* Line: 922*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 922*/ {
bevp_exeExt = (BEC_2_4_6_TextString) bevl_exeExtOverride.bemd_0(1947029806);
} /* Line: 923*/
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doMakeDirs_1(BEC_2_4_6_TextString beva_path) throws Throwable {
BEC_2_2_4_IOFile bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(beva_path);
bevt_0_ta_ph.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeExtGet_0() throws Throwable {
return bevp_exeExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libExtGet_0() throws Throwable {
return bevp_libExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_libExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccObjGet_0() throws Throwable {
return bevp_ccObj;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccObjSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccGet_0() throws Throwable {
return bevp_cc;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cextGet_0() throws Throwable {
return bevp_cext;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_oextGet_0() throws Throwable {
return bevp_oext;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_oextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lBuildGet_0() throws Throwable {
return bevp_lBuild;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccoutGet_0() throws Throwable {
return bevp_ccout;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccoutSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_doCopyGet_0() throws Throwable {
return bevp_doCopy;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doCopySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mkdirsGet_0() throws Throwable {
return bevp_mkdirs;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_mkdirsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lexeGet_0() throws Throwable {
return bevp_lexe;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lexeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeLibExtGet_0() throws Throwable {
return bevp_exeLibExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_diGet_0() throws Throwable {
return bevp_di;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_diSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_di = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_smacGet_0() throws Throwable {
return bevp_smac;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_smacSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dialectGet_0() throws Throwable {
return bevp_dialect;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_dialectSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {844, 845, 845, 846, 847, 848, 849, 850, 851, 851, 851, 852, 852, 854, 855, 855, 855, 856, 857, 858, 858, 858, 860, 861, 862, 863, 864, 864, 864, 866, 867, 868, 868, 868, 870, 871, 872, 873, 875, 875, 875, 875, 876, 877, 877, 877, 877, 877, 878, 879, 880, 881, 882, 882, 882, 882, 882, 883, 885, 885, 885, 885, 0, 885, 885, 885, 885, 0, 0, 886, 887, 887, 887, 887, 887, 888, 888, 888, 888, 888, 889, 890, 891, 892, 892, 892, 892, 892, 893, 895, 895, 895, 895, 896, 897, 897, 897, 898, 899, 900, 901, 902, 903, 903, 903, 903, 903, 904, 905, 906, 907, 908, 909, 911, 912, 912, 912, 912, 912, 913, 913, 914, 915, 916, 917, 917, 917, 917, 917, 918, 921, 921, 921, 921, 921, 921, 922, 922, 922, 922, 922, 0, 0, 0, 923, 928, 928, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 173, 174, 175, 177, 178, 179, 180, 182, 183, 186, 187, 188, 190, 191, 192, 193, 196, 197, 198, 200, 201, 204, 205, 206, 208, 209, 210, 211, 216, 217, 218, 219, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 238, 239, 240, 241, 243, 246, 247, 248, 249, 251, 254, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 279, 280, 281, 282, 284, 285, 286, 287, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 326, 327, 328, 329, 330, 331, 332, 337, 338, 339, 344, 345, 348, 352, 355, 361, 362, 366, 369, 373, 376, 380, 383, 387, 390, 394, 397, 401, 404, 408, 411, 415, 418, 422, 425, 429, 432, 436, 439, 443, 446, 450, 453, 457, 460, 464, 467, 471, 474, 478, 481};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 844 159
new 0 844 159
assign 1 845 160
platformGet 0 845 160
assign 1 845 161
nameGet 0 845 161
assign 1 846 162
new 0 846 162
assign 1 847 163
new 0 847 163
assign 1 848 164
new 0 848 164
assign 1 849 165
new 0 849 165
assign 1 850 166
new 0 850 166
assign 1 851 167
compilerGet 0 851 167
assign 1 851 168
undef 1 851 173
assign 1 852 174
new 0 852 174
compilerSet 1 852 175
assign 1 854 177
compilerGet 0 854 177
assign 1 855 178
compilerGet 0 855 178
assign 1 855 179
new 0 855 179
assign 1 855 180
equals 1 855 180
assign 1 856 182
new 0 856 182
assign 1 857 183
new 0 857 183
assign 1 858 186
compilerGet 0 858 186
assign 1 858 187
new 0 858 187
assign 1 858 188
equals 1 858 188
assign 1 860 190
new 0 860 190
assign 1 861 191
new 0 861 191
assign 1 862 192
new 0 862 192
assign 1 863 193
new 0 863 193
assign 1 864 196
compilerGet 0 864 196
assign 1 864 197
new 0 864 197
assign 1 864 198
equals 1 864 198
assign 1 866 200
new 0 866 200
assign 1 867 201
new 0 867 201
assign 1 868 204
compilerGet 0 868 204
assign 1 868 205
new 0 868 205
assign 1 868 206
equals 1 868 206
assign 1 870 208
new 0 870 208
assign 1 871 209
new 0 871 209
assign 1 872 210
new 0 872 210
assign 1 873 211
new 0 873 211
assign 1 875 216
platformGet 0 875 216
assign 1 875 217
nameGet 0 875 217
assign 1 875 218
new 0 875 218
assign 1 875 219
equals 1 875 219
assign 1 876 221
new 0 876 221
assign 1 877 222
new 0 877 222
assign 1 877 223
add 1 877 223
assign 1 877 224
add 1 877 224
assign 1 877 225
new 0 877 225
assign 1 877 226
add 1 877 226
assign 1 878 227
new 0 878 227
assign 1 879 228
new 0 879 228
assign 1 880 229
new 0 880 229
assign 1 881 230
new 0 881 230
assign 1 882 231
new 0 882 231
assign 1 882 232
add 1 882 232
assign 1 882 233
add 1 882 233
assign 1 882 234
new 0 882 234
assign 1 882 235
add 1 882 235
assign 1 883 236
assign 1 885 238
platformGet 0 885 238
assign 1 885 239
nameGet 0 885 239
assign 1 885 240
new 0 885 240
assign 1 885 241
equals 1 885 241
assign 1 0 243
assign 1 885 246
platformGet 0 885 246
assign 1 885 247
nameGet 0 885 247
assign 1 885 248
new 0 885 248
assign 1 885 249
equals 1 885 249
assign 1 0 251
assign 1 0 254
assign 1 886 258
new 0 886 258
assign 1 887 259
new 0 887 259
assign 1 887 260
add 1 887 260
assign 1 887 261
add 1 887 261
assign 1 887 262
new 0 887 262
assign 1 887 263
add 1 887 263
assign 1 888 264
new 0 888 264
assign 1 888 265
add 1 888 265
assign 1 888 266
add 1 888 266
assign 1 888 267
new 0 888 267
assign 1 888 268
add 1 888 268
assign 1 889 269
new 0 889 269
assign 1 890 270
new 0 890 270
assign 1 891 271
new 0 891 271
assign 1 892 272
new 0 892 272
assign 1 892 273
add 1 892 273
assign 1 892 274
add 1 892 274
assign 1 892 275
new 0 892 275
assign 1 892 276
add 1 892 276
assign 1 893 277
assign 1 895 279
platformGet 0 895 279
assign 1 895 280
nameGet 0 895 280
assign 1 895 281
new 0 895 281
assign 1 895 282
equals 1 895 282
assign 1 896 284
new 0 896 284
assign 1 897 285
compilerGet 0 897 285
assign 1 897 286
new 0 897 286
assign 1 897 287
equals 1 897 287
assign 1 898 289
new 0 898 289
assign 1 899 290
new 0 899 290
assign 1 900 291
new 0 900 291
assign 1 901 292
new 0 901 292
assign 1 902 293
new 0 902 293
assign 1 903 294
new 0 903 294
assign 1 903 295
add 1 903 295
assign 1 903 296
add 1 903 296
assign 1 903 297
new 0 903 297
assign 1 903 298
add 1 903 298
assign 1 904 299
new 0 904 299
assign 1 905 300
new 0 905 300
assign 1 906 301
new 0 906 301
assign 1 907 302
new 0 907 302
assign 1 908 303
new 0 908 303
assign 1 909 304
new 0 909 304
assign 1 911 307
new 0 911 307
assign 1 912 308
new 0 912 308
assign 1 912 309
add 1 912 309
assign 1 912 310
add 1 912 310
assign 1 912 311
new 0 912 311
assign 1 912 312
add 1 912 312
assign 1 913 313
new 0 913 313
assign 1 913 314
add 1 913 314
assign 1 914 315
new 0 914 315
assign 1 915 316
new 0 915 316
assign 1 916 317
new 0 916 317
assign 1 917 318
new 0 917 318
assign 1 917 319
add 1 917 319
assign 1 917 320
add 1 917 320
assign 1 917 321
new 0 917 321
assign 1 917 322
add 1 917 322
assign 1 918 323
assign 1 921 326
paramsGet 0 921 326
assign 1 921 327
new 0 921 327
assign 1 921 328
platformGet 0 921 328
assign 1 921 329
nameGet 0 921 329
assign 1 921 330
add 1 921 330
assign 1 921 331
get 1 921 331
assign 1 922 332
def 1 922 337
assign 1 922 338
firstGet 0 922 338
assign 1 922 339
def 1 922 344
assign 1 0 345
assign 1 0 348
assign 1 0 352
assign 1 923 355
firstGet 0 923 355
assign 1 928 361
new 1 928 361
makeDirs 0 928 362
return 1 0 366
assign 1 0 369
return 1 0 373
assign 1 0 376
return 1 0 380
assign 1 0 383
return 1 0 387
assign 1 0 390
return 1 0 394
assign 1 0 397
return 1 0 401
assign 1 0 404
return 1 0 408
assign 1 0 411
return 1 0 415
assign 1 0 418
return 1 0 422
assign 1 0 425
return 1 0 429
assign 1 0 432
return 1 0 436
assign 1 0 439
return 1 0 443
assign 1 0 446
return 1 0 450
assign 1 0 453
return 1 0 457
assign 1 0 460
return 1 0 464
assign 1 0 467
return 1 0 471
assign 1 0 474
return 1 0 478
assign 1 0 481
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2018070291: return bem_mkdirsGet_0();
case -223144946: return bem_diGet_0();
case 184194385: return bem_copy_0();
case 1866521645: return bem_nameGet_0();
case 1746753159: return bem_libExtGet_0();
case -1558425735: return bem_print_0();
case 533675655: return bem_cextGet_0();
case 178183568: return bem_doCopyGet_0();
case 1208162359: return bem_compilerGet_0();
case -520918680: return bem_exeLibExtGet_0();
case 2101401855: return bem_toString_0();
case -855272897: return bem_ccGet_0();
case 1668207848: return bem_create_0();
case -1596774973: return bem_oextGet_0();
case -752204173: return bem_hashGet_0();
case -1459622248: return bem_new_0();
case 869702373: return bem_ccObjGet_0();
case -777971609: return bem_lBuildGet_0();
case 275008169: return bem_iteratorGet_0();
case -1985602872: return bem_lexeGet_0();
case -1013587859: return bem_ccoutGet_0();
case -854475781: return bem_dialectGet_0();
case 26008430: return bem_smacGet_0();
case 1036694053: return bem_exeExtGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1486272003: return bem_undef_1(bevd_0);
case -754197126: return bem_diSet_1(bevd_0);
case 305205708: return bem_ccoutSet_1(bevd_0);
case -86783069: return bem_smacSet_1(bevd_0);
case 459156703: return bem_lexeSet_1(bevd_0);
case 154368609: return bem_copyTo_1(bevd_0);
case 1662168612: return bem_compilerSet_1(bevd_0);
case -658149740: return bem_ccSet_1(bevd_0);
case -1587096431: return bem_oextSet_1(bevd_0);
case 1790102834: return bem_notEquals_1(bevd_0);
case -1373193079: return bem_mkdirsSet_1(bevd_0);
case -1722625601: return bem_doMakeDirs_1((BEC_2_4_6_TextString) bevd_0);
case 1017238726: return bem_exeLibExtSet_1(bevd_0);
case -1137989077: return bem_ccObjSet_1(bevd_0);
case -491676189: return bem_exeExtSet_1(bevd_0);
case -652861342: return bem_equals_1(bevd_0);
case 71926007: return bem_dialectSet_1(bevd_0);
case -1703868814: return bem_def_1(bevd_0);
case -1247632464: return bem_doCopySet_1(bevd_0);
case -866846179: return bem_new_1(bevd_0);
case 758469861: return bem_nameSet_1(bevd_0);
case -461317997: return bem_lBuildSet_1(bevd_0);
case 526832241: return bem_libExtSet_1(bevd_0);
case -625696318: return bem_cextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 145687102: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 648898220: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2076042115: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1494362942: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_15_BuildCompilerProfile_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_15_BuildCompilerProfile_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_15_BuildCompilerProfile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst = (BEC_2_5_15_BuildCompilerProfile) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;
}
}
