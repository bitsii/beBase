package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_15_BuildCompilerProfile extends BEC_2_6_6_SystemObject {
public BEC_2_5_15_BuildCompilerProfile() { }
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72,0x50,0x72,0x6F,0x66,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_0 = {0x2E,0x65,0x78,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_1 = {0x2E,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_2 = {0x2D,0x49,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_3 = {0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_4 = {0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_5 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_6 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_7 = {0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_8 = {0x2E,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_9 = {0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_10 = {0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_11 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_12 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_13 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_14 = {0x61,0x70,0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_15 = {0x61,0x70,0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_16 = {0x61,0x70,0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_17 = {0x61,0x70,0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_18 = {0x6D,0x61,0x63,0x6F,0x73};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_19 = {0x2E,0x64,0x79,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_20 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_21 = {0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_22 = {0x6C,0x69,0x62,0x74,0x6F,0x6F,0x6C,0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6C,0x63,0x63,0x5F,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_23 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_24 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_25 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_26 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_27 = {0x6C,0x69,0x6E,0x75,0x78};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_28 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_29 = {0x2E,0x73,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_30 = {0x20,0x2D,0x66,0x50,0x49,0x43,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_31 = {0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_32 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_33 = {0x6D,0x73,0x76,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_34 = {0x63,0x6C,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_35 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_36 = {0x2D,0x6E,0x6F,0x6C,0x6F,0x67,0x6F,0x20,0x2D,0x4D,0x44,0x20,0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x4D,0x53,0x56,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_37 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x53,0x45,0x43,0x55,0x52,0x45,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x4E,0x4F,0x4E,0x53,0x54,0x44,0x43,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_38 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x44,0x4C,0x4C,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_39 = {0x20,0x2D,0x46,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_40 = {0x63,0x6F,0x70,0x79,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_41 = {0x6D,0x6B,0x64,0x69,0x72,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_42 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_43 = {0x2E,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_44 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_45 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_46 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_47 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_48 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_49 = {0x65,0x78,0x65,0x45,0x78,0x74,0x4F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x5F};
public static BEC_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;

public static BET_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;

public BEC_2_4_6_TextString bevp_exeExt;
public BEC_2_4_6_TextString bevp_libExt;
public BEC_2_4_6_TextString bevp_ccObj;
public BEC_2_4_6_TextString bevp_cc;
public BEC_2_4_6_TextString bevp_cext;
public BEC_2_4_6_TextString bevp_oext;
public BEC_2_4_6_TextString bevp_lBuild;
public BEC_2_4_6_TextString bevp_ccout;
public BEC_2_4_6_TextString bevp_doCopy;
public BEC_2_4_6_TextString bevp_mkdirs;
public BEC_2_4_6_TextString bevp_lexe;
public BEC_2_4_6_TextString bevp_exeLibExt;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_di;
public BEC_2_4_6_TextString bevp_smac;
public BEC_2_4_6_TextString bevp_dialect;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_5_15_BuildCompilerProfile bem_new_1(BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_4_6_TextString bevl_dialectMacro = null;
BEC_2_6_6_SystemObject bevl_exeExtOverride = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
bevp_exeExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_2_ta_ph = beva_build.bemd_0(925294717);
bevp_name = (BEC_2_4_6_TextString) bevt_2_ta_ph.bemd_0(1668656978);
bevp_oext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_1));
bevp_di = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_2));
bevp_smac = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_3));
bevp_dialect = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_15_BuildCompilerProfile_bels_4));
bevl_dialectMacro = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_5));
bevt_4_ta_ph = beva_build.bemd_0(1529748446);
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 845*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
beva_build.bemd_1(-1238022831, bevt_5_ta_ph);
} /* Line: 846*/
bevp_compiler = (BEC_2_4_6_TextString) beva_build.bemd_0(1529748446);
bevt_7_ta_ph = beva_build.bemd_0(1529748446);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(-900950688, bevt_8_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 849*/ {
bevp_cc = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_7));
bevp_cext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
} /* Line: 851*/
 else /* Line: 849*/ {
bevt_10_ta_ph = beva_build.bemd_0(1529748446);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_9));
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(-900950688, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 852*/ {
bevp_cc = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_10));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
} /* Line: 857*/
 else /* Line: 849*/ {
bevt_13_ta_ph = beva_build.bemd_0(1529748446);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_14));
bevt_12_ta_ph = bevt_13_ta_ph.bemd_1(-900950688, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 858*/ {
bevp_cc = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_15));
bevp_cext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
} /* Line: 861*/
 else /* Line: 849*/ {
bevt_16_ta_ph = beva_build.bemd_0(1529748446);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_16));
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-900950688, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 862*/ {
bevp_cc = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_17));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
} /* Line: 867*/
} /* Line: 849*/
} /* Line: 849*/
} /* Line: 849*/
bevt_20_ta_ph = beva_build.bemd_0(925294717);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(1668656978);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_18));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-900950688, bevt_21_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 869*/ {
bevp_libExt = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_19));
bevt_24_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_20));
bevt_23_ta_ph = bevp_cc.bem_add_1(bevt_24_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_15_BuildCompilerProfile_bels_21));
bevp_ccObj = bevt_22_ta_ph.bem_add_1(bevt_25_ta_ph);
bevp_lBuild = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_15_BuildCompilerProfile_bels_22));
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_28_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_15_BuildCompilerProfile_bels_26));
bevt_27_ta_ph = bevp_cc.bem_add_1(bevt_28_ta_ph);
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_lexe = bevt_26_ta_ph.bem_add_1(bevt_29_ta_ph);
bevp_exeLibExt = bevp_libExt;
} /* Line: 877*/
bevt_32_ta_ph = beva_build.bemd_0(925294717);
bevt_31_ta_ph = bevt_32_ta_ph.bemd_0(1668656978);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_27));
bevt_30_ta_ph = bevt_31_ta_ph.bemd_1(-900950688, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 879*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 879*/ {
bevt_36_ta_ph = beva_build.bemd_0(925294717);
bevt_35_ta_ph = bevt_36_ta_ph.bemd_0(1668656978);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_28));
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(-900950688, bevt_37_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 879*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 879*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 879*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 879*/ {
bevp_libExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_29));
bevt_40_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_20));
bevt_39_ta_ph = bevp_cc.bem_add_1(bevt_40_ta_ph);
bevt_38_ta_ph = bevt_39_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_30));
bevp_ccObj = bevt_38_ta_ph.bem_add_1(bevt_41_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_15_BuildCompilerProfile_bels_26));
bevt_43_ta_ph = bevp_cc.bem_add_1(bevt_44_ta_ph);
bevt_42_ta_ph = bevt_43_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_15_BuildCompilerProfile_bels_31));
bevp_lBuild = bevt_42_ta_ph.bem_add_1(bevt_45_ta_ph);
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_48_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_15_BuildCompilerProfile_bels_26));
bevt_47_ta_ph = bevp_cc.bem_add_1(bevt_48_ta_ph);
bevt_46_ta_ph = bevt_47_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_49_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_lexe = bevt_46_ta_ph.bem_add_1(bevt_49_ta_ph);
bevp_exeLibExt = bevp_libExt;
} /* Line: 887*/
bevt_52_ta_ph = beva_build.bemd_0(925294717);
bevt_51_ta_ph = bevt_52_ta_ph.bemd_0(1668656978);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_32));
bevt_50_ta_ph = bevt_51_ta_ph.bemd_1(-900950688, bevt_53_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_50_ta_ph).bevi_bool)/* Line: 889*/ {
bevp_exeExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_55_ta_ph = beva_build.bemd_0(1529748446);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_33));
bevt_54_ta_ph = bevt_55_ta_ph.bemd_1(-900950688, bevt_56_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_54_ta_ph).bevi_bool)/* Line: 891*/ {
bevp_cc = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_34));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
bevp_libExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_59_ta_ph = (new BEC_2_4_6_TextString(45, bece_BEC_2_5_15_BuildCompilerProfile_bels_36));
bevt_58_ta_ph = bevp_cc.bem_add_1(bevt_59_ta_ph);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(76, bece_BEC_2_5_15_BuildCompilerProfile_bels_37));
bevp_ccObj = bevt_57_ta_ph.bem_add_1(bevt_60_ta_ph);
bevp_lBuild = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_15_BuildCompilerProfile_bels_38));
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_39));
bevp_doCopy = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_40));
bevp_mkdirs = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_41));
bevp_lexe = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_42));
bevp_exeLibExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_43));
} /* Line: 903*/
 else /* Line: 904*/ {
bevp_libExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_63_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_15_BuildCompilerProfile_bels_44));
bevt_62_ta_ph = bevp_cc.bem_add_1(bevt_63_ta_ph);
bevt_61_ta_ph = bevt_62_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_64_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_15_BuildCompilerProfile_bels_45));
bevp_ccObj = bevt_61_ta_ph.bem_add_1(bevt_64_ta_ph);
bevt_65_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_15_BuildCompilerProfile_bels_46));
bevp_lBuild = bevp_cc.bem_add_1(bevt_65_ta_ph);
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_68_ta_ph = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_15_BuildCompilerProfile_bels_47));
bevt_67_ta_ph = bevp_cc.bem_add_1(bevt_68_ta_ph);
bevt_66_ta_ph = bevt_67_ta_ph.bem_add_1(bevl_dialectMacro);
bevt_69_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_15_BuildCompilerProfile_bels_48));
bevp_lexe = bevt_66_ta_ph.bem_add_1(bevt_69_ta_ph);
bevp_exeLibExt = bevp_libExt;
} /* Line: 912*/
} /* Line: 891*/
bevt_70_ta_ph = beva_build.bemd_0(-1766025035);
bevt_72_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_15_BuildCompilerProfile_bels_49));
bevt_74_ta_ph = beva_build.bemd_0(925294717);
bevt_73_ta_ph = bevt_74_ta_ph.bemd_0(1668656978);
bevt_71_ta_ph = bevt_72_ta_ph.bem_add_1(bevt_73_ta_ph);
bevl_exeExtOverride = bevt_70_ta_ph.bemd_1(-1266318437, bevt_71_ta_ph);
if (bevl_exeExtOverride == null) {
bevt_75_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_75_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_75_ta_ph.bevi_bool)/* Line: 916*/ {
bevt_77_ta_ph = bevl_exeExtOverride.bemd_0(912870842);
if (bevt_77_ta_ph == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 916*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 916*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 916*/
 else /* Line: 916*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 916*/ {
bevp_exeExt = (BEC_2_4_6_TextString) bevl_exeExtOverride.bemd_0(912870842);
} /* Line: 917*/
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doMakeDirs_1(BEC_2_4_6_TextString beva_path) throws Throwable {
BEC_2_2_4_IOFile bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(beva_path);
bevt_0_ta_ph.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeExtGet_0() throws Throwable {
return bevp_exeExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libExtGet_0() throws Throwable {
return bevp_libExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_libExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccObjGet_0() throws Throwable {
return bevp_ccObj;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccObjSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccGet_0() throws Throwable {
return bevp_cc;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cextGet_0() throws Throwable {
return bevp_cext;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_oextGet_0() throws Throwable {
return bevp_oext;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_oextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lBuildGet_0() throws Throwable {
return bevp_lBuild;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccoutGet_0() throws Throwable {
return bevp_ccout;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccoutSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_doCopyGet_0() throws Throwable {
return bevp_doCopy;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doCopySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mkdirsGet_0() throws Throwable {
return bevp_mkdirs;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_mkdirsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lexeGet_0() throws Throwable {
return bevp_lexe;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lexeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeLibExtGet_0() throws Throwable {
return bevp_exeLibExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_diGet_0() throws Throwable {
return bevp_di;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_diSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_di = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_smacGet_0() throws Throwable {
return bevp_smac;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_smacSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dialectGet_0() throws Throwable {
return bevp_dialect;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_dialectSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {838, 839, 839, 840, 841, 842, 843, 844, 845, 845, 845, 846, 846, 848, 849, 849, 849, 850, 851, 852, 852, 852, 854, 855, 856, 857, 858, 858, 858, 860, 861, 862, 862, 862, 864, 865, 866, 867, 869, 869, 869, 869, 870, 871, 871, 871, 871, 871, 872, 873, 874, 875, 876, 876, 876, 876, 876, 877, 879, 879, 879, 879, 0, 879, 879, 879, 879, 0, 0, 880, 881, 881, 881, 881, 881, 882, 882, 882, 882, 882, 883, 884, 885, 886, 886, 886, 886, 886, 887, 889, 889, 889, 889, 890, 891, 891, 891, 892, 893, 894, 895, 896, 897, 897, 897, 897, 897, 898, 899, 900, 901, 902, 903, 905, 906, 906, 906, 906, 906, 907, 907, 908, 909, 910, 911, 911, 911, 911, 911, 912, 915, 915, 915, 915, 915, 915, 916, 916, 916, 916, 916, 0, 0, 0, 917, 922, 922, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 173, 174, 175, 177, 178, 179, 180, 182, 183, 186, 187, 188, 190, 191, 192, 193, 196, 197, 198, 200, 201, 204, 205, 206, 208, 209, 210, 211, 216, 217, 218, 219, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 238, 239, 240, 241, 243, 246, 247, 248, 249, 251, 254, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 279, 280, 281, 282, 284, 285, 286, 287, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 326, 327, 328, 329, 330, 331, 332, 337, 338, 339, 344, 345, 348, 352, 355, 361, 362, 366, 369, 373, 376, 380, 383, 387, 390, 394, 397, 401, 404, 408, 411, 415, 418, 422, 425, 429, 432, 436, 439, 443, 446, 450, 453, 457, 460, 464, 467, 471, 474, 478, 481};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 838 159
new 0 838 159
assign 1 839 160
platformGet 0 839 160
assign 1 839 161
nameGet 0 839 161
assign 1 840 162
new 0 840 162
assign 1 841 163
new 0 841 163
assign 1 842 164
new 0 842 164
assign 1 843 165
new 0 843 165
assign 1 844 166
new 0 844 166
assign 1 845 167
compilerGet 0 845 167
assign 1 845 168
undef 1 845 173
assign 1 846 174
new 0 846 174
compilerSet 1 846 175
assign 1 848 177
compilerGet 0 848 177
assign 1 849 178
compilerGet 0 849 178
assign 1 849 179
new 0 849 179
assign 1 849 180
equals 1 849 180
assign 1 850 182
new 0 850 182
assign 1 851 183
new 0 851 183
assign 1 852 186
compilerGet 0 852 186
assign 1 852 187
new 0 852 187
assign 1 852 188
equals 1 852 188
assign 1 854 190
new 0 854 190
assign 1 855 191
new 0 855 191
assign 1 856 192
new 0 856 192
assign 1 857 193
new 0 857 193
assign 1 858 196
compilerGet 0 858 196
assign 1 858 197
new 0 858 197
assign 1 858 198
equals 1 858 198
assign 1 860 200
new 0 860 200
assign 1 861 201
new 0 861 201
assign 1 862 204
compilerGet 0 862 204
assign 1 862 205
new 0 862 205
assign 1 862 206
equals 1 862 206
assign 1 864 208
new 0 864 208
assign 1 865 209
new 0 865 209
assign 1 866 210
new 0 866 210
assign 1 867 211
new 0 867 211
assign 1 869 216
platformGet 0 869 216
assign 1 869 217
nameGet 0 869 217
assign 1 869 218
new 0 869 218
assign 1 869 219
equals 1 869 219
assign 1 870 221
new 0 870 221
assign 1 871 222
new 0 871 222
assign 1 871 223
add 1 871 223
assign 1 871 224
add 1 871 224
assign 1 871 225
new 0 871 225
assign 1 871 226
add 1 871 226
assign 1 872 227
new 0 872 227
assign 1 873 228
new 0 873 228
assign 1 874 229
new 0 874 229
assign 1 875 230
new 0 875 230
assign 1 876 231
new 0 876 231
assign 1 876 232
add 1 876 232
assign 1 876 233
add 1 876 233
assign 1 876 234
new 0 876 234
assign 1 876 235
add 1 876 235
assign 1 877 236
assign 1 879 238
platformGet 0 879 238
assign 1 879 239
nameGet 0 879 239
assign 1 879 240
new 0 879 240
assign 1 879 241
equals 1 879 241
assign 1 0 243
assign 1 879 246
platformGet 0 879 246
assign 1 879 247
nameGet 0 879 247
assign 1 879 248
new 0 879 248
assign 1 879 249
equals 1 879 249
assign 1 0 251
assign 1 0 254
assign 1 880 258
new 0 880 258
assign 1 881 259
new 0 881 259
assign 1 881 260
add 1 881 260
assign 1 881 261
add 1 881 261
assign 1 881 262
new 0 881 262
assign 1 881 263
add 1 881 263
assign 1 882 264
new 0 882 264
assign 1 882 265
add 1 882 265
assign 1 882 266
add 1 882 266
assign 1 882 267
new 0 882 267
assign 1 882 268
add 1 882 268
assign 1 883 269
new 0 883 269
assign 1 884 270
new 0 884 270
assign 1 885 271
new 0 885 271
assign 1 886 272
new 0 886 272
assign 1 886 273
add 1 886 273
assign 1 886 274
add 1 886 274
assign 1 886 275
new 0 886 275
assign 1 886 276
add 1 886 276
assign 1 887 277
assign 1 889 279
platformGet 0 889 279
assign 1 889 280
nameGet 0 889 280
assign 1 889 281
new 0 889 281
assign 1 889 282
equals 1 889 282
assign 1 890 284
new 0 890 284
assign 1 891 285
compilerGet 0 891 285
assign 1 891 286
new 0 891 286
assign 1 891 287
equals 1 891 287
assign 1 892 289
new 0 892 289
assign 1 893 290
new 0 893 290
assign 1 894 291
new 0 894 291
assign 1 895 292
new 0 895 292
assign 1 896 293
new 0 896 293
assign 1 897 294
new 0 897 294
assign 1 897 295
add 1 897 295
assign 1 897 296
add 1 897 296
assign 1 897 297
new 0 897 297
assign 1 897 298
add 1 897 298
assign 1 898 299
new 0 898 299
assign 1 899 300
new 0 899 300
assign 1 900 301
new 0 900 301
assign 1 901 302
new 0 901 302
assign 1 902 303
new 0 902 303
assign 1 903 304
new 0 903 304
assign 1 905 307
new 0 905 307
assign 1 906 308
new 0 906 308
assign 1 906 309
add 1 906 309
assign 1 906 310
add 1 906 310
assign 1 906 311
new 0 906 311
assign 1 906 312
add 1 906 312
assign 1 907 313
new 0 907 313
assign 1 907 314
add 1 907 314
assign 1 908 315
new 0 908 315
assign 1 909 316
new 0 909 316
assign 1 910 317
new 0 910 317
assign 1 911 318
new 0 911 318
assign 1 911 319
add 1 911 319
assign 1 911 320
add 1 911 320
assign 1 911 321
new 0 911 321
assign 1 911 322
add 1 911 322
assign 1 912 323
assign 1 915 326
paramsGet 0 915 326
assign 1 915 327
new 0 915 327
assign 1 915 328
platformGet 0 915 328
assign 1 915 329
nameGet 0 915 329
assign 1 915 330
add 1 915 330
assign 1 915 331
get 1 915 331
assign 1 916 332
def 1 916 337
assign 1 916 338
firstGet 0 916 338
assign 1 916 339
def 1 916 344
assign 1 0 345
assign 1 0 348
assign 1 0 352
assign 1 917 355
firstGet 0 917 355
assign 1 922 361
new 1 922 361
makeDirs 0 922 362
return 1 0 366
assign 1 0 369
return 1 0 373
assign 1 0 376
return 1 0 380
assign 1 0 383
return 1 0 387
assign 1 0 390
return 1 0 394
assign 1 0 397
return 1 0 401
assign 1 0 404
return 1 0 408
assign 1 0 411
return 1 0 415
assign 1 0 418
return 1 0 422
assign 1 0 425
return 1 0 429
assign 1 0 432
return 1 0 436
assign 1 0 439
return 1 0 443
assign 1 0 446
return 1 0 450
assign 1 0 453
return 1 0 457
assign 1 0 460
return 1 0 464
assign 1 0 467
return 1 0 471
assign 1 0 474
return 1 0 478
assign 1 0 481
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1009317920: return bem_copy_0();
case 3341359: return bem_diGet_0();
case -1953689920: return bem_ccoutGet_0();
case -1579498783: return bem_ccGet_0();
case 580458197: return bem_exeExtGet_0();
case 1529748446: return bem_compilerGet_0();
case -1101374226: return bem_mkdirsGet_0();
case -659864182: return bem_print_0();
case -82638510: return bem_toString_0();
case -287668799: return bem_hashGet_0();
case 360738156: return bem_doCopyGet_0();
case 462080281: return bem_oextGet_0();
case 1414915502: return bem_libExtGet_0();
case -593575409: return bem_new_0();
case -610848114: return bem_iteratorGet_0();
case 147475623: return bem_cextGet_0();
case -1504194683: return bem_exeLibExtGet_0();
case -1052462495: return bem_smacGet_0();
case -1003496782: return bem_lBuildGet_0();
case -408488619: return bem_lexeGet_0();
case 282781408: return bem_create_0();
case -680219560: return bem_ccObjGet_0();
case -1723975159: return bem_dialectGet_0();
case 1668656978: return bem_nameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 485126053: return bem_nameSet_1(bevd_0);
case 497111257: return bem_smacSet_1(bevd_0);
case 1813277075: return bem_lexeSet_1(bevd_0);
case -1820231174: return bem_undef_1(bevd_0);
case 1979914784: return bem_ccObjSet_1(bevd_0);
case -1748226314: return bem_diSet_1(bevd_0);
case -1238022831: return bem_compilerSet_1(bevd_0);
case 954956095: return bem_exeLibExtSet_1(bevd_0);
case -900950688: return bem_equals_1(bevd_0);
case -1529382338: return bem_lBuildSet_1(bevd_0);
case -1485664386: return bem_ccSet_1(bevd_0);
case 2059962377: return bem_copyTo_1(bevd_0);
case -69069333: return bem_cextSet_1(bevd_0);
case 1485690810: return bem_doMakeDirs_1((BEC_2_4_6_TextString) bevd_0);
case -2083459216: return bem_ccoutSet_1(bevd_0);
case -1099650712: return bem_dialectSet_1(bevd_0);
case -300716008: return bem_notEquals_1(bevd_0);
case 917108689: return bem_def_1(bevd_0);
case -392760656: return bem_new_1(bevd_0);
case 21423614: return bem_libExtSet_1(bevd_0);
case 50034203: return bem_doCopySet_1(bevd_0);
case -427698923: return bem_mkdirsSet_1(bevd_0);
case 532794289: return bem_oextSet_1(bevd_0);
case 1833721919: return bem_exeExtSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 549639695: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1893163472: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2023386676: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1439381859: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_15_BuildCompilerProfile_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_15_BuildCompilerProfile_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_15_BuildCompilerProfile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst = (BEC_2_5_15_BuildCompilerProfile) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;
}
}
