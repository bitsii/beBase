package be;
/* IO:File: source/base/System.be */
public final class BEC_2_6_2_SystemGC extends BEC_2_6_6_SystemObject {
public BEC_2_6_2_SystemGC() { }
private static byte[] becc_BEC_2_6_2_SystemGC_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x47,0x43};
private static byte[] becc_BEC_2_6_2_SystemGC_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_2_SystemGC bece_BEC_2_6_2_SystemGC_bevs_inst;

public static BET_2_6_2_SystemGC bece_BEC_2_6_2_SystemGC_bevs_type;

public BEC_2_6_2_SystemGC bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_2_SystemGC bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_2_SystemGC bem_maybeGc_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1915513690: return bem_classNameGet_0();
case 1604055525: return bem_hashGet_0();
case -1540487614: return bem_default_0();
case -1902821230: return bem_sourceFileNameGet_0();
case 1476572399: return bem_new_0();
case 807844599: return bem_copy_0();
case 708488762: return bem_create_0();
case -436514878: return bem_echo_0();
case 1534778339: return bem_serializeContents_0();
case 712001867: return bem_maybeGc_0();
case 290193605: return bem_toString_0();
case -129556018: return bem_fieldNamesGet_0();
case 210349252: return bem_deserializeClassNameGet_0();
case 1528097206: return bem_serializeToString_0();
case 198473032: return bem_tagGet_0();
case -1781364078: return bem_print_0();
case 1057028028: return bem_fieldIteratorGet_0();
case 715553388: return bem_serializationIteratorGet_0();
case -450907329: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -835119407: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1880525273: return bem_otherType_1(bevd_0);
case 1528010380: return bem_sameClass_1(bevd_0);
case -575460023: return bem_sameType_1(bevd_0);
case 1859153072: return bem_undef_1(bevd_0);
case -999927226: return bem_notEquals_1(bevd_0);
case -746609219: return bem_sameObject_1(bevd_0);
case 938863663: return bem_def_1(bevd_0);
case -1865008630: return bem_equals_1(bevd_0);
case 909428606: return bem_otherClass_1(bevd_0);
case 1342151407: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1768944168: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1606202955: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 506082618: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1582482490: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1978405023: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953140974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1983033893: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_6_2_SystemGC_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_2_SystemGC_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_2_SystemGC();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_2_SystemGC.bece_BEC_2_6_2_SystemGC_bevs_inst = (BEC_2_6_2_SystemGC) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_2_SystemGC.bece_BEC_2_6_2_SystemGC_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_2_SystemGC.bece_BEC_2_6_2_SystemGC_bevs_type;
}
}
