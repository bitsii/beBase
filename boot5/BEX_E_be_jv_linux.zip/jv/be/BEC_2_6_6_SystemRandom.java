package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_0 = (new BEC_2_4_3_MathInt(26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_1 = (new BEC_2_4_3_MathInt(65));
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;
public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getInt_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_2_tmpany_phold = bem_getInt_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_getInt_1(beva_value);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_tmpany_phold = bem_getString_2(bevt_1_tmpany_phold, beva_size);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_str.bem_capacityGet_0();
if (bevt_1_tmpany_phold.bevi_int < beva_size.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 278 */ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 279 */
bevt_2_tmpany_phold = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_tmpany_phold);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 287 */ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 287 */ {
bevt_9_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_0;
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) bevt_9_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bem_getIntMax_2(bevl_value, bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_1;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevt_7_tmpany_phold;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 287 */
 else  /* Line: 287 */ {
break;
} /* Line: 287 */
} /* Line: 287 */
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {218, 241, 241, 241, 262, 266, 266, 266, 266, 266, 270, 270, 270, 270, 274, 274, 274, 278, 278, 278, 279, 281, 281, 286, 287, 287, 287, 289, 289, 289, 289, 289, 289, 289, 287, 291};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 31, 32, 33, 38, 45, 46, 47, 48, 49, 55, 56, 57, 58, 63, 64, 65, 82, 83, 88, 89, 91, 92, 93, 94, 97, 102, 103, 104, 105, 106, 107, 108, 110, 111, 117};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 218 20
assign 1 241 31
new 0 241 31
assign 1 241 32
getInt 1 241 32
return 1 241 33
return 1 262 38
assign 1 266 45
new 0 266 45
assign 1 266 46
getInt 1 266 46
assign 1 266 47
absValue 0 266 47
assign 1 266 48
modulusValue 1 266 48
return 1 266 49
assign 1 270 55
getInt 1 270 55
assign 1 270 56
absValue 0 270 56
assign 1 270 57
modulusValue 1 270 57
return 1 270 58
assign 1 274 63
new 1 274 63
assign 1 274 64
getString 2 274 64
return 1 274 65
assign 1 278 82
capacityGet 0 278 82
assign 1 278 83
lesser 1 278 88
capacitySet 1 279 89
assign 1 281 91
copy 0 281 91
sizeSet 1 281 92
assign 1 286 93
new 0 286 93
assign 1 287 94
new 0 287 94
assign 1 287 97
lesser 1 287 102
assign 1 289 103
new 0 289 103
assign 1 289 104
once 0 289 104
assign 1 289 105
getIntMax 2 289 105
assign 1 289 106
new 0 289 106
assign 1 289 107
once 0 289 107
assign 1 289 108
addValue 1 289 108
setIntUnchecked 2 289 110
incrementValue 0 287 111
return 1 291 117
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 648643859: return bem_sourceFileNameGet_0();
case -266150550: return bem_many_0();
case 1740583826: return bem_serializeToString_0();
case 895906767: return bem_toString_0();
case 978873391: return bem_deserializeClassNameGet_0();
case 1330053746: return bem_classNameGet_0();
case -1666892068: return bem_once_0();
case -1256903143: return bem_print_0();
case -748130189: return bem_echo_0();
case 1782125853: return bem_hashGet_0();
case 721298840: return bem_serializationIteratorGet_0();
case -67323485: return bem_create_0();
case 302903797: return bem_seedNow_0();
case -907223016: return bem_iteratorGet_0();
case 394710523: return bem_toAny_0();
case -1956375704: return bem_getInt_0();
case 19655765: return bem_tagGet_0();
case -1755437106: return bem_serializeContents_0();
case 1781926555: return bem_copy_0();
case -805848244: return bem_default_0();
case -2089883321: return bem_new_0();
case -1693411633: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2097315666: return bem_sameClass_1(bevd_0);
case 2119054446: return bem_otherType_1(bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 803845413: return bem_def_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1960220659: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case 1470514201: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case -1019992618: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -890470044: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1529304260: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
}
