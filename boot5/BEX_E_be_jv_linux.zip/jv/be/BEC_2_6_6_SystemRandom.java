package be;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getInt_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt());
bevt_2_ta_ph = bem_getInt_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_getInt_1(beva_value);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_ta_ph = bem_getString_2(bevt_1_ta_ph, beva_size);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
bevt_1_ta_ph = beva_str.bem_capacityGet_0();
if (bevt_1_ta_ph.bevi_int < beva_size.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 254*/ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 255*/
bevt_2_ta_ph = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_ta_ph);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 263*/ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(26));
bevt_6_ta_ph = bem_getIntMax_2(bevl_value, bevt_7_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_6_ta_ph.bevi_int += bevt_8_ta_ph.bevi_int;
bevt_5_ta_ph = bevt_6_ta_ph;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_5_ta_ph);
bevl_i.bevi_int++;
} /* Line: 263*/
 else /* Line: 263*/ {
break;
} /* Line: 263*/
} /* Line: 263*/
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {179, 207, 207, 207, 238, 242, 242, 242, 242, 242, 246, 246, 246, 246, 250, 250, 250, 254, 254, 254, 255, 257, 257, 262, 263, 263, 263, 265, 265, 265, 265, 265, 263, 267};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 30, 31, 32, 37, 44, 45, 46, 47, 48, 54, 55, 56, 57, 62, 63, 64, 78, 79, 84, 85, 87, 88, 89, 90, 93, 98, 99, 100, 101, 102, 104, 105, 111};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 179 19
assign 1 207 30
new 0 207 30
assign 1 207 31
getInt 1 207 31
return 1 207 32
return 1 238 37
assign 1 242 44
new 0 242 44
assign 1 242 45
getInt 1 242 45
assign 1 242 46
absValue 0 242 46
assign 1 242 47
modulusValue 1 242 47
return 1 242 48
assign 1 246 54
getInt 1 246 54
assign 1 246 55
absValue 0 246 55
assign 1 246 56
modulusValue 1 246 56
return 1 246 57
assign 1 250 62
new 1 250 62
assign 1 250 63
getString 2 250 63
return 1 250 64
assign 1 254 78
capacityGet 0 254 78
assign 1 254 79
lesser 1 254 84
capacitySet 1 255 85
assign 1 257 87
copy 0 257 87
sizeSet 1 257 88
assign 1 262 89
new 0 262 89
assign 1 263 90
new 0 263 90
assign 1 263 93
lesser 1 263 98
assign 1 265 99
new 0 265 99
assign 1 265 100
getIntMax 2 265 100
assign 1 265 101
new 0 265 101
assign 1 265 102
addValue 1 265 102
setIntUnchecked 2 265 104
incrementValue 0 263 105
return 1 267 111
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1718188704: return bem_hashGet_0();
case 807655445: return bem_print_0();
case -677150073: return bem_toString_0();
case 1342623754: return bem_copy_0();
case 247576523: return bem_classNameGet_0();
case -2124354635: return bem_serializeToString_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case 351949843: return bem_getInt_0();
case -543330026: return bem_fieldNamesGet_0();
case -225222698: return bem_create_0();
case 2066839134: return bem_iteratorGet_0();
case 498101216: return bem_echo_0();
case 556565361: return bem_serializationIteratorGet_0();
case -1749437314: return bem_tagGet_0();
case -313059782: return bem_default_0();
case 126387064: return bem_new_0();
case 2014723240: return bem_seedNow_0();
case 409380620: return bem_fieldIteratorGet_0();
case -1794485421: return bem_serializeContents_0();
case 398187407: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -404194174: return bem_copyTo_1(bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 954208860: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1779458514: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case 1502842604: return bem_def_1(bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
case -1626575522: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1958120901: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -959268026: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
