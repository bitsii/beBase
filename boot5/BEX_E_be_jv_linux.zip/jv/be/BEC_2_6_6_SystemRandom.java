package be;
/* IO:File: source/base/Random.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x52,0x61,0x6E,0x64,0x6F,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seed_1(BEC_2_4_3_MathInt beva_seed) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getInt_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt());
bevt_2_ta_ph = bem_getInt_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_getInt_1(beva_value);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_length) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_length);
bevt_0_ta_ph = bem_getString_2(bevt_1_ta_ph, beva_length);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_length) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
bevt_1_ta_ph = beva_str.bem_capacityGet_0();
if (bevt_1_ta_ph.bevi_int < beva_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 127*/ {
beva_str.bem_capacitySet_1(beva_length);
} /* Line: 128*/
bevt_2_ta_ph = beva_length.bem_copy_0();
beva_str.bem_lengthSet_1(bevt_2_ta_ph);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 136*/ {
if (bevl_i.bevi_int < beva_length.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 136*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(26));
bevt_5_ta_ph = bem_getIntMax_2(bevl_value, bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_5_ta_ph.bevi_int += bevt_7_ta_ph.bevi_int;
bevt_4_ta_ph = bevt_5_ta_ph;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_4_ta_ph);
bevl_i.bevi_int++;
} /* Line: 136*/
 else /* Line: 136*/ {
break;
} /* Line: 136*/
} /* Line: 136*/
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {44, 80, 80, 80, 111, 115, 115, 115, 115, 115, 119, 119, 119, 119, 123, 123, 123, 127, 127, 127, 128, 130, 130, 135, 136, 136, 136, 138, 138, 138, 138, 138, 136, 140};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 33, 34, 35, 40, 47, 48, 49, 50, 51, 57, 58, 59, 60, 65, 66, 67, 80, 81, 86, 87, 89, 90, 91, 92, 95, 100, 101, 102, 103, 104, 106, 107, 113};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 44 19
assign 1 80 33
new 0 80 33
assign 1 80 34
getInt 1 80 34
return 1 80 35
return 1 111 40
assign 1 115 47
new 0 115 47
assign 1 115 48
getInt 1 115 48
assign 1 115 49
absValue 0 115 49
assign 1 115 50
modulusValue 1 115 50
return 1 115 51
assign 1 119 57
getInt 1 119 57
assign 1 119 58
absValue 0 119 58
assign 1 119 59
modulusValue 1 119 59
return 1 119 60
assign 1 123 65
new 1 123 65
assign 1 123 66
getString 2 123 66
return 1 123 67
assign 1 127 80
capacityGet 0 127 80
assign 1 127 81
lesser 1 127 86
capacitySet 1 128 87
assign 1 130 89
copy 0 130 89
lengthSet 1 130 90
assign 1 135 91
new 0 135 91
assign 1 136 92
new 0 136 92
assign 1 136 95
lesser 1 136 100
assign 1 138 101
new 0 138 101
assign 1 138 102
getIntMax 2 138 102
assign 1 138 103
new 0 138 103
assign 1 138 104
addValue 1 138 104
setIntUnchecked 2 138 106
incrementValue 0 136 107
return 1 140 113
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1870128138: return bem_toString_0();
case 189070720: return bem_new_0();
case -1399615900: return bem_iteratorGet_0();
case -559059286: return bem_create_0();
case 441331165: return bem_print_0();
case 1684508629: return bem_copy_0();
case -1600902755: return bem_default_0();
case 1129629309: return bem_getInt_0();
case 1629329382: return bem_seedNow_0();
case 1991657606: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -907308916: return bem_print_1(bevd_0);
case -514952459: return bem_notEquals_1(bevd_0);
case 871472653: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case -1230159139: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case -804131024: return bem_seed_1((BEC_2_4_3_MathInt) bevd_0);
case -342422765: return bem_undef_1(bevd_0);
case -1146215684: return bem_def_1(bevd_0);
case 305443687: return bem_equals_1(bevd_0);
case -461789566: return bem_copyTo_1(bevd_0);
case 1420459329: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1396281933: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1532908424: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -734031807: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 99764285: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2108428878: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1918971160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
