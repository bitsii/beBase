package be;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getInt_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt());
bevt_2_ta_ph = bem_getInt_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_getInt_1(beva_value);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_ta_ph = bem_getString_2(bevt_1_ta_ph, beva_size);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
bevt_1_ta_ph = beva_str.bem_capacityGet_0();
if (bevt_1_ta_ph.bevi_int < beva_size.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 117*/ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 118*/
bevt_2_ta_ph = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_ta_ph);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 126*/ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 126*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(26));
bevt_6_ta_ph = bem_getIntMax_2(bevl_value, bevt_7_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_6_ta_ph.bevi_int += bevt_8_ta_ph.bevi_int;
bevt_5_ta_ph = bevt_6_ta_ph;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_5_ta_ph);
bevl_i.bevi_int++;
} /* Line: 126*/
 else /* Line: 126*/ {
break;
} /* Line: 126*/
} /* Line: 126*/
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {42, 70, 70, 70, 101, 105, 105, 105, 105, 105, 109, 109, 109, 109, 113, 113, 113, 117, 117, 117, 118, 120, 120, 125, 126, 126, 126, 128, 128, 128, 128, 128, 126, 130};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 30, 31, 32, 37, 44, 45, 46, 47, 48, 54, 55, 56, 57, 62, 63, 64, 78, 79, 84, 85, 87, 88, 89, 90, 93, 98, 99, 100, 101, 102, 104, 105, 111};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 42 19
assign 1 70 30
new 0 70 30
assign 1 70 31
getInt 1 70 31
return 1 70 32
return 1 101 37
assign 1 105 44
new 0 105 44
assign 1 105 45
getInt 1 105 45
assign 1 105 46
absValue 0 105 46
assign 1 105 47
modulusValue 1 105 47
return 1 105 48
assign 1 109 54
getInt 1 109 54
assign 1 109 55
absValue 0 109 55
assign 1 109 56
modulusValue 1 109 56
return 1 109 57
assign 1 113 62
new 1 113 62
assign 1 113 63
getString 2 113 63
return 1 113 64
assign 1 117 78
capacityGet 0 117 78
assign 1 117 79
lesser 1 117 84
capacitySet 1 118 85
assign 1 120 87
copy 0 120 87
sizeSet 1 120 88
assign 1 125 89
new 0 125 89
assign 1 126 90
new 0 126 90
assign 1 126 93
lesser 1 126 98
assign 1 128 99
new 0 128 99
assign 1 128 100
getIntMax 2 128 100
assign 1 128 101
new 0 128 101
assign 1 128 102
addValue 1 128 102
setIntUnchecked 2 128 104
incrementValue 0 126 105
return 1 130 111
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1915513690: return bem_classNameGet_0();
case 1604055525: return bem_hashGet_0();
case -1540487614: return bem_default_0();
case -1902821230: return bem_sourceFileNameGet_0();
case -1070785970: return bem_seedNow_0();
case 1476572399: return bem_new_0();
case 807844599: return bem_copy_0();
case 708488762: return bem_create_0();
case -436514878: return bem_echo_0();
case 1534778339: return bem_serializeContents_0();
case 290193605: return bem_toString_0();
case -129556018: return bem_fieldNamesGet_0();
case 210349252: return bem_deserializeClassNameGet_0();
case 1890496645: return bem_getInt_0();
case 1528097206: return bem_serializeToString_0();
case 198473032: return bem_tagGet_0();
case -1781364078: return bem_print_0();
case 1057028028: return bem_fieldIteratorGet_0();
case 715553388: return bem_serializationIteratorGet_0();
case -450907329: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -835119407: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1880525273: return bem_otherType_1(bevd_0);
case 1528010380: return bem_sameClass_1(bevd_0);
case -575460023: return bem_sameType_1(bevd_0);
case 1408327236: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case 1859153072: return bem_undef_1(bevd_0);
case -999927226: return bem_notEquals_1(bevd_0);
case -746609219: return bem_sameObject_1(bevd_0);
case 938863663: return bem_def_1(bevd_0);
case -1865008630: return bem_equals_1(bevd_0);
case 1560463295: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case 909428606: return bem_otherClass_1(bevd_0);
case 1342151407: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2929648: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case -1768944168: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1606202955: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 506082618: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1582482490: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1978405023: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 996475731: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1919529811: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953140974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1983033893: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
