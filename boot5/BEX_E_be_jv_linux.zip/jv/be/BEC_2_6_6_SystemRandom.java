package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_0 = (new BEC_2_4_3_MathInt(26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_1 = (new BEC_2_4_3_MathInt(65));
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getInt_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_2_tmpany_phold = bem_getInt_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_getInt_1(beva_value);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_tmpany_phold = bem_getString_2(bevt_1_tmpany_phold, beva_size);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_str.bem_capacityGet_0();
if (bevt_1_tmpany_phold.bevi_int < beva_size.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 248 */ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 249 */
bevt_2_tmpany_phold = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_tmpany_phold);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 257 */ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevt_9_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_0;
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) bevt_9_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bem_getIntMax_2(bevl_value, bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_1;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevt_7_tmpany_phold;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 257 */
 else  /* Line: 257 */ {
break;
} /* Line: 257 */
} /* Line: 257 */
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {188, 211, 211, 211, 232, 236, 236, 236, 236, 236, 240, 240, 240, 240, 244, 244, 244, 248, 248, 248, 249, 251, 251, 256, 257, 257, 257, 259, 259, 259, 259, 259, 259, 259, 257, 261};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 34, 35, 36, 41, 48, 49, 50, 51, 52, 58, 59, 60, 61, 66, 67, 68, 85, 86, 91, 92, 94, 95, 96, 97, 100, 105, 106, 107, 108, 109, 110, 111, 113, 114, 120};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 188 23
assign 1 211 34
new 0 211 34
assign 1 211 35
getInt 1 211 35
return 1 211 36
return 1 232 41
assign 1 236 48
new 0 236 48
assign 1 236 49
getInt 1 236 49
assign 1 236 50
absValue 0 236 50
assign 1 236 51
modulusValue 1 236 51
return 1 236 52
assign 1 240 58
getInt 1 240 58
assign 1 240 59
absValue 0 240 59
assign 1 240 60
modulusValue 1 240 60
return 1 240 61
assign 1 244 66
new 1 244 66
assign 1 244 67
getString 2 244 67
return 1 244 68
assign 1 248 85
capacityGet 0 248 85
assign 1 248 86
lesser 1 248 91
capacitySet 1 249 92
assign 1 251 94
copy 0 251 94
sizeSet 1 251 95
assign 1 256 96
new 0 256 96
assign 1 257 97
new 0 257 97
assign 1 257 100
lesser 1 257 105
assign 1 259 106
new 0 259 106
assign 1 259 107
once 0 259 107
assign 1 259 108
getIntMax 2 259 108
assign 1 259 109
new 0 259 109
assign 1 259 110
once 0 259 110
assign 1 259 111
addValue 1 259 111
setIntUnchecked 2 259 113
incrementValue 0 257 114
return 1 261 120
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1009286812: return bem_iteratorGet_0();
case 357618761: return bem_new_0();
case -2036889336: return bem_toAny_0();
case -162465408: return bem_classNameGet_0();
case -702348589: return bem_toString_0();
case -275244597: return bem_hashGet_0();
case 216387563: return bem_many_0();
case -1118611827: return bem_copy_0();
case -1774143633: return bem_once_0();
case -138934452: return bem_serializationIteratorGet_0();
case -1081679068: return bem_seedNow_0();
case 35710370: return bem_default_0();
case -826924838: return bem_fieldIteratorGet_0();
case 1899370103: return bem_echo_0();
case 1881523822: return bem_deserializeClassNameGet_0();
case 1555639231: return bem_print_0();
case -716934857: return bem_serializeContents_0();
case -1653065356: return bem_serializeToString_0();
case -1528945516: return bem_fieldNamesGet_0();
case -2101622436: return bem_sourceFileNameGet_0();
case 71860751: return bem_create_0();
case 1901482140: return bem_tagGet_0();
case -1705864635: return bem_getInt_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -959745115: return bem_otherType_1(bevd_0);
case -1082439894: return bem_sameObject_1(bevd_0);
case -68723535: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1193778385: return bem_undefined_1(bevd_0);
case 1137403549: return bem_copyTo_1(bevd_0);
case 1240886992: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case 1353620660: return bem_sameClass_1(bevd_0);
case -2109980302: return bem_undef_1(bevd_0);
case 2082558825: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 560417487: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1339829082: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 66254795: return bem_sameType_1(bevd_0);
case 1459678776: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2027670755: return bem_defined_1(bevd_0);
case 82358262: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case -2130714868: return bem_equals_1(bevd_0);
case 1325575386: return bem_def_1(bevd_0);
case 814727407: return bem_notEquals_1(bevd_0);
case -1493100314: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 70790709: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020619337: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 163657925: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1186365239: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1726380154: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686267336: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271558857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 980938792: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1157880701: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
