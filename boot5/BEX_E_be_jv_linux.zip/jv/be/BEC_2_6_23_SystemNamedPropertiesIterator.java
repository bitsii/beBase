package be;
/* IO:File: source/extended/Serialize.be */
public final class BEC_2_6_23_SystemNamedPropertiesIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_23_SystemNamedPropertiesIterator() { }
private static byte[] becc_BEC_2_6_23_SystemNamedPropertiesIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_23_SystemNamedPropertiesIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_0 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_1 = {0x53,0x65,0x74};
public static BEC_2_6_23_SystemNamedPropertiesIterator bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst;

public static BET_2_6_23_SystemNamedPropertiesIterator bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_propNames;
public BEC_3_9_4_8_ContainerListIterator bevp_subIter;
public BEC_2_6_6_SystemObject bevp_inst;
public BEC_2_9_4_ContainerList bevp_setArgs;
public BEC_2_9_4_ContainerList bevp_getArgs;
public BEC_2_6_23_SystemNamedPropertiesIterator bem_new_2(BEC_2_6_6_SystemObject beva__inst, BEC_2_9_4_ContainerList beva__propNames) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_propNames = beva__propNames;
bevp_inst = beva__inst;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_setArgs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_getArgs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_subIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_subIter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 478*/ {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevp_propNames.bem_iteratorGet_0();
} /* Line: 479*/
return bevp_subIter;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_subIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_hasNextGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_1_ta_ph = bem_subIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_nextGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_0));
bevl_name = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(715945325, bevt_2_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = bevp_inst.bemd_2(-1411462266, bevl_name, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 490*/ {
bevt_5_ta_ph = bevp_inst.bemd_2(-1745573040, bevl_name, bevp_getArgs);
return bevt_5_ta_ph;
} /* Line: 491*/
return null;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_1_ta_ph = bem_subIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_nextGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_1));
bevl_name = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(715945325, bevt_2_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_3_ta_ph = bevp_inst.bemd_2(-1411462266, bevl_name, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 498*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_setArgs.bem_put_2(bevt_5_ta_ph, beva_value);
bevp_inst.bemd_2(-1745573040, bevl_name, bevp_setArgs);
} /* Line: 500*/
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 505*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 505*/ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 505*/
 else /* Line: 505*/ {
break;
} /* Line: 505*/
} /* Line: 505*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_propNamesGet_0() throws Throwable {
return bevp_propNames;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_propNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_propNames = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_subIterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instGet_0() throws Throwable {
return bevp_inst;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_instSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inst = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_setArgsGet_0() throws Throwable {
return bevp_setArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_setArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_setArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_getArgsGet_0() throws Throwable {
return bevp_getArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_getArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {469, 471, 472, 472, 473, 473, 478, 478, 479, 481, 485, 485, 485, 489, 489, 489, 489, 490, 490, 491, 491, 493, 497, 497, 497, 497, 498, 498, 499, 499, 500, 505, 505, 505, 506, 505, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 24, 25, 26, 31, 36, 37, 39, 44, 45, 46, 56, 57, 58, 59, 60, 61, 63, 64, 66, 76, 77, 78, 79, 80, 81, 83, 84, 85, 92, 95, 100, 101, 102, 111, 114, 118, 122, 125, 129, 132, 136, 139};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 469 21
assign 1 471 22
assign 1 472 23
new 0 472 23
assign 1 472 24
new 1 472 24
assign 1 473 25
new 0 473 25
assign 1 473 26
new 1 473 26
assign 1 478 31
undef 1 478 36
assign 1 479 37
iteratorGet 0 479 37
return 1 481 39
assign 1 485 44
subIterGet 0 485 44
assign 1 485 45
hasNextGet 0 485 45
return 1 485 46
assign 1 489 56
subIterGet 0 489 56
assign 1 489 57
nextGet 0 489 57
assign 1 489 58
new 0 489 58
assign 1 489 59
add 1 489 59
assign 1 490 60
new 0 490 60
assign 1 490 61
can 2 490 61
assign 1 491 63
invoke 2 491 63
return 1 491 64
return 1 493 66
assign 1 497 76
subIterGet 0 497 76
assign 1 497 77
nextGet 0 497 77
assign 1 497 78
new 0 497 78
assign 1 497 79
add 1 497 79
assign 1 498 80
new 0 498 80
assign 1 498 81
can 2 498 81
assign 1 499 83
new 0 499 83
put 2 499 84
invoke 2 500 85
assign 1 505 92
new 0 505 92
assign 1 505 95
lesser 1 505 100
nextSet 1 506 101
incrementValue 0 505 102
return 1 0 111
assign 1 0 114
assign 1 0 118
return 1 0 122
assign 1 0 125
return 1 0 129
assign 1 0 132
return 1 0 136
assign 1 0 139
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1303921009: return bem_propNamesGet_0();
case 412131171: return bem_hasNextGet_0();
case 1862660644: return bem_new_0();
case -452826053: return bem_nextGet_0();
case 817716151: return bem_setArgsGet_0();
case 1160937609: return bem_instGet_0();
case -393844090: return bem_copy_0();
case -748394026: return bem_hashGet_0();
case 1160279532: return bem_create_0();
case 463441174: return bem_getArgsGet_0();
case -1079825495: return bem_iteratorGet_0();
case 2066241869: return bem_print_0();
case -1233241901: return bem_toString_0();
case -1954361942: return bem_subIterGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1902022464: return bem_print_1(bevd_0);
case -511875923: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -1944972717: return bem_setArgsSet_1(bevd_0);
case 310887766: return bem_undef_1(bevd_0);
case 1921787435: return bem_equals_1(bevd_0);
case -1215278694: return bem_def_1(bevd_0);
case -858534551: return bem_propNamesSet_1(bevd_0);
case -465513410: return bem_copyTo_1(bevd_0);
case 429623741: return bem_subIterSet_1(bevd_0);
case 669019845: return bem_instSet_1(bevd_0);
case 1633476346: return bem_notEquals_1(bevd_0);
case 1331040794: return bem_getArgsSet_1(bevd_0);
case -1581159522: return bem_nextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1745573040: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1324104974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1411462266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 193877296: return bem_new_2(bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1926749857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_2_6_23_SystemNamedPropertiesIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_23_SystemNamedPropertiesIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_23_SystemNamedPropertiesIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst = (BEC_2_6_23_SystemNamedPropertiesIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_type;
}
}
