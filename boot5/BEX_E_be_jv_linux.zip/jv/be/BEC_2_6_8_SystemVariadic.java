package be;
/* IO:File: source/base/Object.be */
public class BEC_2_6_8_SystemVariadic extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemVariadic() { }
private static byte[] becc_BEC_2_6_8_SystemVariadic_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x56,0x61,0x72,0x69,0x61,0x64,0x69,0x63};
private static byte[] becc_BEC_2_6_8_SystemVariadic_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
public static BEC_2_6_8_SystemVariadic bece_BEC_2_6_8_SystemVariadic_bevs_inst;

public static BET_2_6_8_SystemVariadic bece_BEC_2_6_8_SystemVariadic_bevs_type;

public final BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_9_4_ContainerList bevl_varargs = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = bem_can_2(beva_name, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 907 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_varargs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_varargs.bem_put_2(bevt_3_tmpany_phold, beva_args);
bevl_result = bem_invoke_2(beva_name, bevl_varargs);
} /* Line: 910 */
return bevl_result;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {907, 907, 908, 908, 909, 909, 910, 912};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 21, 22, 23, 24, 25, 27};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 907 18
new 0 907 18
assign 1 907 19
can 2 907 19
assign 1 908 21
new 0 908 21
assign 1 908 22
new 1 908 22
assign 1 909 23
new 0 909 23
put 2 909 24
assign 1 910 25
invoke 2 910 25
return 1 912 27
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1202859281: return bem_fieldIteratorGet_0();
case 1800213309: return bem_serializeContents_0();
case -169510412: return bem_toString_0();
case -458279913: return bem_serializationIteratorGet_0();
case 1166902012: return bem_print_0();
case 221369236: return bem_echo_0();
case 737627600: return bem_classNameGet_0();
case -1627101286: return bem_many_0();
case -1721224705: return bem_copy_0();
case -1588608331: return bem_iteratorGet_0();
case -1760283647: return bem_sourceFileNameGet_0();
case -165877765: return bem_create_0();
case 586787044: return bem_toAny_0();
case 419402773: return bem_fieldNamesGet_0();
case -1145946037: return bem_serializeToString_0();
case -1200024888: return bem_tagGet_0();
case 1662643176: return bem_new_0();
case -1855742442: return bem_deserializeClassNameGet_0();
case -4634496: return bem_once_0();
case -12708128: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -409899450: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1058481552: return bem_undef_1(bevd_0);
case -327804541: return bem_sameClass_1(bevd_0);
case 286179063: return bem_copyTo_1(bevd_0);
case 1174135522: return bem_sameType_1(bevd_0);
case -306633068: return bem_undefined_1(bevd_0);
case 1396328003: return bem_otherClass_1(bevd_0);
case -2050626933: return bem_def_1(bevd_0);
case -39094467: return bem_equals_1(bevd_0);
case -1880368515: return bem_notEquals_1(bevd_0);
case 1039180755: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1694968514: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2038137777: return bem_otherType_1(bevd_0);
case -1143294403: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -883889211: return bem_sameObject_1(bevd_0);
case -1617140536: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -549233499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853281410: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666962597: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1983260459: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -136430353: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2126382926: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1776809505: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemVariadic_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemVariadic_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemVariadic();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_inst = (BEC_2_6_8_SystemVariadic) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_type;
}
}
