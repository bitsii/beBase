package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_6_IOFileWriterStderr extends BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_6_IOFileWriterStderr() { }
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStderr_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x53,0x74,0x64,0x65,0x72,0x72};
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStderr_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_6_IOFileWriterStderr bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst;

public static BET_4_2_4_6_6_IOFileWriterStderr bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_type;

public BEC_4_2_4_6_6_IOFileWriterStderr bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {714, 719, 719};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 23, 24};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 714 15
new 0 714 15
assign 1 719 23
new 0 719 23
return 1 719 24
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1915513690: return bem_classNameGet_0();
case 1604055525: return bem_hashGet_0();
case 291628629: return bem_isClosedGet_0();
case 428447159: return bem_close_0();
case -1540487614: return bem_default_0();
case -1081907606: return bem_vfileGet_0();
case -1902821230: return bem_sourceFileNameGet_0();
case 1845392880: return bem_pathGet_0();
case 1476572399: return bem_new_0();
case 807844599: return bem_copy_0();
case 708488762: return bem_create_0();
case -436514878: return bem_echo_0();
case 1534778339: return bem_serializeContents_0();
case 886843570: return bem_open_0();
case 290193605: return bem_toString_0();
case -129556018: return bem_fieldNamesGet_0();
case -656810579: return bem_pathGetDirect_0();
case -523484640: return bem_vfileGetDirect_0();
case 210349252: return bem_deserializeClassNameGet_0();
case -490903157: return bem_openAppend_0();
case 1528097206: return bem_serializeToString_0();
case -129423987: return bem_openTruncate_0();
case 1599267410: return bem_extOpen_0();
case 198473032: return bem_tagGet_0();
case -1781364078: return bem_print_0();
case 1057028028: return bem_fieldIteratorGet_0();
case 1524789695: return bem_isClosedGetDirect_0();
case 715553388: return bem_serializationIteratorGet_0();
case -450907329: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -658117728: return bem_vfileSet_1(bevd_0);
case 1825333525: return bem_pathSetDirect_1(bevd_0);
case -472492109: return bem_pathSet_1(bevd_0);
case 1859153072: return bem_undef_1(bevd_0);
case 1114174001: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 938863663: return bem_def_1(bevd_0);
case -746609219: return bem_sameObject_1(bevd_0);
case -2140357933: return bem_vfileSetDirect_1(bevd_0);
case -1606202955: return bem_copyTo_1(bevd_0);
case 1342151407: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 530665401: return bem_isClosedSetDirect_1(bevd_0);
case -835119407: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 909428606: return bem_otherClass_1(bevd_0);
case 1141872328: return bem_new_1(bevd_0);
case -999927226: return bem_notEquals_1(bevd_0);
case 1528010380: return bem_sameClass_1(bevd_0);
case -1865008630: return bem_equals_1(bevd_0);
case -73400120: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 1880525273: return bem_otherType_1(bevd_0);
case -596782293: return bem_isClosedSet_1(bevd_0);
case 84273825: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -575460023: return bem_sameType_1(bevd_0);
case -1768944168: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 506082618: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1582482490: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1978405023: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953140974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1983033893: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_4_2_4_6_6_IOFileWriterStderr_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_6_IOFileWriterStderr_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_6_IOFileWriterStderr();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst = (BEC_4_2_4_6_6_IOFileWriterStderr) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_type;
}
}
