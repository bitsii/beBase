package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue extends BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_9_12_ContainerBoundedQueue bem_new_0() throws Throwable {
super.bem_new_0();
bevp_max = (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
super.bem_enqueue_1(beva_item);
if (bevp_size.bevi_int > bevp_max.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {
bem_dequeue_0();
} /* Line: 192 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() throws Throwable {
return bevp_max;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {184, 186, 190, 191, 191, 192, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 19, 20, 25, 26, 31, 34};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 184 13
assign 1 186 14
new 0 186 14
enqueue 1 190 19
assign 1 191 20
greater 1 191 25
dequeue 0 192 26
return 1 0 31
assign 1 0 34
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 512670579: return bem_deserializeClassNameGet_0();
case -364109840: return bem_serializationIteratorGet_0();
case 1315558702: return bem_sourceFileNameGet_0();
case -268528295: return bem_fieldIteratorGet_0();
case 2033350872: return bem_serializeToString_0();
case 326615681: return bem_isEmptyGet_0();
case 751706402: return bem_copy_0();
case 2090767709: return bem_many_0();
case 1759214880: return bem_maxGet_0();
case -1165063866: return bem_serializeContents_0();
case -1032373300: return bem_echo_0();
case 169398438: return bem_hashGet_0();
case -41023079: return bem_iteratorGet_0();
case 1043984390: return bem_once_0();
case 1387818040: return bem_new_0();
case -1662177650: return bem_classNameGet_0();
case 761778979: return bem_create_0();
case -2068649084: return bem_bottomGet_0();
case 472216694: return bem_dequeue_0();
case 258432052: return bem_endGet_0();
case 605404858: return bem_tagGet_0();
case -1510846211: return bem_topGet_0();
case -1625699850: return bem_get_0();
case -1120421430: return bem_print_0();
case 763461621: return bem_toAny_0();
case 2079084965: return bem_toString_0();
case 1524018105: return bem_sizeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1179778534: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1479785081: return bem_otherType_1(bevd_0);
case -173923543: return bem_def_1(bevd_0);
case 1646725461: return bem_copyTo_1(bevd_0);
case -1628072592: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -400783475: return bem_undefined_1(bevd_0);
case -95156212: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2058883742: return bem_maxSet_1(bevd_0);
case -46023056: return bem_notEquals_1(bevd_0);
case 1296533558: return bem_otherClass_1(bevd_0);
case -1983033016: return bem_endSet_1(bevd_0);
case -1385908387: return bem_topSet_1(bevd_0);
case -132994488: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 327020484: return bem_sameObject_1(bevd_0);
case 1953673516: return bem_undef_1(bevd_0);
case 611966660: return bem_equals_1(bevd_0);
case -131660880: return bem_sizeSet_1(bevd_0);
case -550476304: return bem_sameType_1(bevd_0);
case -1284332181: return bem_addValue_1(bevd_0);
case -1578179895: return bem_defined_1(bevd_0);
case 932249623: return bem_sameClass_1(bevd_0);
case -335791426: return bem_enqueue_1(bevd_0);
case -1899083519: return bem_put_1(bevd_0);
case -1875439670: return bem_bottomSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -501684028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815708233: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1424200790: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1920722583: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806507047: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1733811664: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1465498474: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
