package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue extends BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_9_12_ContainerBoundedQueue bem_new_0() throws Throwable {
super.bem_new_0();
bevp_max = (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
super.bem_enqueue_1(beva_item);
if (bevp_size.bevi_int > bevp_max.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {
bem_dequeue_0();
} /* Line: 192 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() throws Throwable {
return bevp_max;
} /*method end*/
public final BEC_2_4_3_MathInt bem_maxGetDirect_0() throws Throwable {
return bevp_max;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_12_ContainerBoundedQueue bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {184, 186, 190, 191, 191, 192, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 19, 20, 25, 26, 31, 34, 37, 41};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 184 13
assign 1 186 14
new 0 186 14
enqueue 1 190 19
assign 1 191 20
greater 1 191 25
dequeue 0 192 26
return 1 0 31
return 1 0 34
assign 1 0 37
assign 1 0 41
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1278273894: return bem_toAny_0();
case -638442685: return bem_echo_0();
case -480687649: return bem_print_0();
case -1475537716: return bem_topGetDirect_0();
case -2121857146: return bem_topGet_0();
case -397559289: return bem_fieldIteratorGet_0();
case 1912264799: return bem_maxGetDirect_0();
case -207569400: return bem_serializeToString_0();
case 346235852: return bem_sourceFileNameGet_0();
case 1284099845: return bem_bottomGet_0();
case -1474382176: return bem_endGetDirect_0();
case -507124439: return bem_new_0();
case 1230302912: return bem_hashGet_0();
case 357537975: return bem_classNameGet_0();
case 376852389: return bem_sizeGet_0();
case 1689278436: return bem_get_0();
case -915808255: return bem_serializationIteratorGet_0();
case 97668500: return bem_endGet_0();
case -360613383: return bem_serializeContents_0();
case -22393727: return bem_create_0();
case -1629544591: return bem_many_0();
case 1259887718: return bem_isEmptyGet_0();
case -1762356041: return bem_toString_0();
case -1308933810: return bem_deserializeClassNameGet_0();
case -88057563: return bem_dequeue_0();
case -419706700: return bem_sizeGetDirect_0();
case 847337627: return bem_copy_0();
case 797222886: return bem_maxGet_0();
case 718789172: return bem_iteratorGet_0();
case 1981654959: return bem_once_0();
case -217835874: return bem_tagGet_0();
case -1834983554: return bem_bottomGetDirect_0();
case 1611055106: return bem_fieldNamesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2000939055: return bem_endSetDirect_1(bevd_0);
case -794657115: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1760916230: return bem_topSet_1(bevd_0);
case 580318355: return bem_otherType_1(bevd_0);
case 82449186: return bem_bottomSetDirect_1(bevd_0);
case 1379835000: return bem_defined_1(bevd_0);
case -386454063: return bem_bottomSet_1(bevd_0);
case -1570066456: return bem_topSetDirect_1(bevd_0);
case -2056947488: return bem_sameClass_1(bevd_0);
case -1256041694: return bem_copyTo_1(bevd_0);
case 1418552655: return bem_def_1(bevd_0);
case 1329351894: return bem_put_1(bevd_0);
case -408502512: return bem_equals_1(bevd_0);
case 321693734: return bem_undef_1(bevd_0);
case -665968375: return bem_sameType_1(bevd_0);
case 1787128072: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -65090510: return bem_sizeSet_1(bevd_0);
case -756695074: return bem_addValue_1(bevd_0);
case 1273353241: return bem_notEquals_1(bevd_0);
case -722068809: return bem_maxSetDirect_1(bevd_0);
case 1530291279: return bem_sameObject_1(bevd_0);
case -436547338: return bem_undefined_1(bevd_0);
case 1387628079: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1921037633: return bem_sizeSetDirect_1(bevd_0);
case -293078434: return bem_endSet_1(bevd_0);
case 1740079670: return bem_enqueue_1(bevd_0);
case 1622258979: return bem_maxSet_1(bevd_0);
case -1263961885: return bem_otherClass_1(bevd_0);
case 1849763669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -318431301: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1103544796: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138830036: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -554397969: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2122183893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 975610887: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -799307739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
