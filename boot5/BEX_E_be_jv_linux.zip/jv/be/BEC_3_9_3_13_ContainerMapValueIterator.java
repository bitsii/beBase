package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_13_ContainerMapValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_13_ContainerMapValueIterator() { }
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_tr = super.bem_nextGet_0();
if (bevl_tr == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevt_1_tmpany_phold = bevl_tr.bemd_0(2020727446, BEX_E.bevn_valueGet_0);
return bevt_1_tmpany_phold;
} /* Line: 632 */
return bevl_tr;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {630, 631, 631, 632, 632, 634};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 13, 18, 19, 20, 22};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 630 12
nextGet 0 630 12
assign 1 631 13
def 1 631 18
assign 1 632 19
valueGet 0 632 19
return 1 632 20
return 1 634 22
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 1392959045: return bem_setGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1586230380: return bem_moduGet_0();
case 104713553: return bem_new_0();
case -1471882487: return bem_nodeIteratorIteratorGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 1194623572: return bem_nextGet_0();
case 819712668: return bem_delete_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case 108485850: return bem_hasNextGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1404041298: return bem_setSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1575148127: return bem_moduSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_3_9_3_13_ContainerMapValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_13_ContainerMapValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst = (BEC_3_9_3_13_ContainerMapValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;
}
}
