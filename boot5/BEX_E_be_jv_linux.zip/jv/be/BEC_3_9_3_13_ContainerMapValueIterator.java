package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_13_ContainerMapValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_13_ContainerMapValueIterator() { }
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;

public static BET_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_tr = super.bem_nextGet_0();
if (bevl_tr == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevt_1_tmpany_phold = bevl_tr.bemd_0(1173515901);
return bevt_1_tmpany_phold;
} /* Line: 632 */
return bevl_tr;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {630, 631, 631, 632, 632, 634};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 21, 22, 23, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 630 15
nextGet 0 630 15
assign 1 631 16
def 1 631 21
assign 1 632 22
valueGet 0 632 22
return 1 632 23
return 1 634 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 813558846: return bem_containerGet_0();
case -1101915058: return bem_nextGet_0();
case -41023079: return bem_iteratorGet_0();
case 1043984390: return bem_once_0();
case 761778979: return bem_create_0();
case -253989360: return bem_hasNextGet_0();
case 169398438: return bem_hashGet_0();
case 512670579: return bem_deserializeClassNameGet_0();
case -1697254436: return bem_currentGet_0();
case 2090767709: return bem_many_0();
case 501982769: return bem_setGet_0();
case -1662177650: return bem_classNameGet_0();
case -1120421430: return bem_print_0();
case 605404858: return bem_tagGet_0();
case 1503984489: return bem_nodeIteratorIteratorGet_0();
case 918791404: return bem_moduGet_0();
case 751706402: return bem_copy_0();
case 2079084965: return bem_toString_0();
case 1387818040: return bem_new_0();
case 1315558702: return bem_sourceFileNameGet_0();
case 935587613: return bem_slotsGet_0();
case -1385874303: return bem_delete_0();
case -1165063866: return bem_serializeContents_0();
case -1032373300: return bem_echo_0();
case 2033350872: return bem_serializeToString_0();
case -364109840: return bem_serializationIteratorGet_0();
case 763461621: return bem_toAny_0();
case -268528295: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -550476304: return bem_sameType_1(bevd_0);
case 1646725461: return bem_copyTo_1(bevd_0);
case -132994488: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -205180062: return bem_currentSet_1(bevd_0);
case 327020484: return bem_sameObject_1(bevd_0);
case 1466032264: return bem_moduSet_1(bevd_0);
case -1628072592: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -95156212: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -173923543: return bem_def_1(bevd_0);
case 932249623: return bem_sameClass_1(bevd_0);
case -1095756156: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 603828544: return bem_setSet_1(bevd_0);
case 1329202050: return bem_slotsSet_1(bevd_0);
case 611966660: return bem_equals_1(bevd_0);
case -1179778534: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1953673516: return bem_undef_1(bevd_0);
case -46023056: return bem_notEquals_1(bevd_0);
case -400783475: return bem_undefined_1(bevd_0);
case 1296533558: return bem_otherClass_1(bevd_0);
case -1578179895: return bem_defined_1(bevd_0);
case 1479785081: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -501684028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815708233: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1424200790: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1920722583: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806507047: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1733811664: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1465498474: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_3_9_3_13_ContainerMapValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_13_ContainerMapValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst = (BEC_3_9_3_13_ContainerMapValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_type;
}
}
