package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_17_TextMultiByteIterator extends BEC_2_4_12_TextByteIterator {
public BEC_2_4_17_TextMultiByteIterator() { }
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x4D,0x75,0x6C,0x74,0x69,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(127));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(-64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(-32));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(-16));
private static byte[] bece_BEC_2_4_17_TextMultiByteIterator_bels_0 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x2C,0x20,0x75,0x74,0x66,0x2D,0x38,0x20,0x6D,0x75,0x6C,0x74,0x69,0x62,0x79,0x74,0x65,0x20,0x73,0x65,0x71,0x75,0x65,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x20,0x74,0x68,0x61,0x6E,0x20,0x34,0x20,0x62,0x79,0x74,0x65,0x73};
public static BEC_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;

public static BET_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_bcount;
public BEC_2_4_3_MathInt bevp_ival;
public BEC_2_4_17_TextMultiByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_bcount = (new BEC_2_4_3_MathInt());
bevp_ival = (new BEC_2_4_3_MathInt());
super.bem_new_1(beva__str);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1345 */ {
bevp_str.bem_getInt_2(bevp_pos, bevp_ival);
bevt_4_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_0;
if (bevp_ival.bevi_int >= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1347 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_1;
if (bevp_ival.bevi_int <= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 1347 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1347 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1347 */
 else  /* Line: 1347 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1347 */ {
bevp_bcount = (new BEC_2_4_3_MathInt(1));
} /* Line: 1348 */
 else  /* Line: 1347 */ {
bevt_9_tmpany_phold = (new BEC_2_4_3_MathInt(-32));
bevt_8_tmpany_phold = bevp_ival.bem_and_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_2;
if (bevt_8_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1349 */ {
bevp_bcount = (new BEC_2_4_3_MathInt(2));
} /* Line: 1350 */
 else  /* Line: 1347 */ {
bevt_13_tmpany_phold = (new BEC_2_4_3_MathInt(-16));
bevt_12_tmpany_phold = bevp_ival.bem_and_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_3;
if (bevt_12_tmpany_phold.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 1351 */ {
bevp_bcount = (new BEC_2_4_3_MathInt(3));
} /* Line: 1352 */
 else  /* Line: 1347 */ {
bevt_17_tmpany_phold = (new BEC_2_4_3_MathInt(-8));
bevt_16_tmpany_phold = bevp_ival.bem_and_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_4;
if (bevt_16_tmpany_phold.bevi_int == bevt_18_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 1353 */ {
bevp_bcount = (new BEC_2_4_3_MathInt(4));
} /* Line: 1354 */
 else  /* Line: 1355 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(66, bece_BEC_2_4_17_TextMultiByteIterator_bels_0));
bevt_19_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_20_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 1356 */
} /* Line: 1347 */
} /* Line: 1347 */
} /* Line: 1347 */
bevt_22_tmpany_phold = beva_buf.bem_sizeGet_0();
if (bevt_22_tmpany_phold.bevi_int != bevp_bcount.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 1358 */ {
bevt_23_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_23_tmpany_phold.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1359 */
bevp_bcount.bevi_int += bevp_pos.bevi_int;
bevt_24_tmpany_phold = (new BEC_2_4_3_MathInt(0));
beva_buf.bem_copyValue_4(bevp_str, bevp_pos, bevp_bcount, bevt_24_tmpany_phold);
bevp_pos.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1363 */
return beva_buf;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_bcountGet_0() throws Throwable {
return bevp_bcount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_bcountGetDirect_0() throws Throwable {
return bevp_bcount;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_bcountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_bcountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ivalGet_0() throws Throwable {
return bevp_ival;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ivalGetDirect_0() throws Throwable {
return bevp_ival;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_ivalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_ivalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1334, 1335, 1337, 1341, 1341, 1341, 1341, 1345, 1345, 1345, 1346, 1347, 1347, 1347, 1347, 1347, 1347, 0, 0, 0, 1348, 1349, 1349, 1349, 1349, 1349, 1350, 1351, 1351, 1351, 1351, 1351, 1352, 1353, 1353, 1353, 1353, 1353, 1354, 1356, 1356, 1356, 1358, 1358, 1358, 1359, 1359, 1361, 1362, 1362, 1363, 1365, 1369, 1373, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 22, 29, 30, 31, 32, 60, 61, 66, 67, 68, 69, 74, 75, 76, 81, 82, 85, 89, 92, 95, 96, 97, 98, 103, 104, 107, 108, 109, 110, 115, 116, 119, 120, 121, 122, 127, 128, 131, 132, 133, 138, 139, 144, 145, 146, 148, 149, 150, 151, 153, 156, 159, 162, 165, 168, 172, 176, 179, 182, 186};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1334 20
new 0 1334 20
assign 1 1335 21
new 0 1335 21
new 1 1337 22
assign 1 1341 29
new 0 1341 29
assign 1 1341 30
new 1 1341 30
assign 1 1341 31
next 1 1341 31
return 1 1341 32
assign 1 1345 60
sizeGet 0 1345 60
assign 1 1345 61
greater 1 1345 66
getInt 2 1346 67
assign 1 1347 68
new 0 1347 68
assign 1 1347 69
greaterEquals 1 1347 74
assign 1 1347 75
new 0 1347 75
assign 1 1347 76
lesserEquals 1 1347 81
assign 1 0 82
assign 1 0 85
assign 1 0 89
assign 1 1348 92
new 0 1348 92
assign 1 1349 95
new 0 1349 95
assign 1 1349 96
and 1 1349 96
assign 1 1349 97
new 0 1349 97
assign 1 1349 98
equals 1 1349 103
assign 1 1350 104
new 0 1350 104
assign 1 1351 107
new 0 1351 107
assign 1 1351 108
and 1 1351 108
assign 1 1351 109
new 0 1351 109
assign 1 1351 110
equals 1 1351 115
assign 1 1352 116
new 0 1352 116
assign 1 1353 119
new 0 1353 119
assign 1 1353 120
and 1 1353 120
assign 1 1353 121
new 0 1353 121
assign 1 1353 122
equals 1 1353 127
assign 1 1354 128
new 0 1354 128
assign 1 1356 131
new 0 1356 131
assign 1 1356 132
new 1 1356 132
throw 1 1356 133
assign 1 1358 138
sizeGet 0 1358 138
assign 1 1358 139
notEquals 1 1358 144
assign 1 1359 145
sizeGet 0 1359 145
setValue 1 1359 146
addValue 1 1361 148
assign 1 1362 149
new 0 1362 149
copyValue 4 1362 150
setValue 1 1363 151
return 1 1365 153
return 1 1369 156
return 1 1373 159
return 1 0 162
return 1 0 165
assign 1 0 168
assign 1 0 172
return 1 0 176
return 1 0 179
assign 1 0 182
assign 1 0 186
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2022113180: return bem_toAny_0();
case -1002223418: return bem_deserializeClassNameGet_0();
case 248110533: return bem_posGetDirect_0();
case 1226301190: return bem_create_0();
case -609608989: return bem_posGet_0();
case 1212400791: return bem_hasNextGet_0();
case -372099163: return bem_ivalGet_0();
case 2128158896: return bem_iteratorGet_0();
case 520256150: return bem_print_0();
case -402973175: return bem_toString_0();
case 304205171: return bem_sourceFileNameGet_0();
case -1016349443: return bem_strGetDirect_0();
case -728251540: return bem_echo_0();
case -1347713072: return bem_many_0();
case 1971636542: return bem_fieldIteratorGet_0();
case 1895351716: return bem_multiByteIteratorIteratorGet_0();
case -59938177: return bem_bcountGet_0();
case 1545963265: return bem_tagGet_0();
case -28758016: return bem_vcopyGet_0();
case 502686321: return bem_serializeToString_0();
case -92297996: return bem_serializeContents_0();
case 1362114893: return bem_hashGet_0();
case 592499503: return bem_serializationIteratorGet_0();
case -592589470: return bem_vcopyGetDirect_0();
case -1541237194: return bem_once_0();
case 2082915487: return bem_copy_0();
case -1349248202: return bem_nextGet_0();
case -1670320540: return bem_containerGet_0();
case 1196862871: return bem_bcountGetDirect_0();
case 580957788: return bem_fieldNamesGet_0();
case 1073869018: return bem_ivalGetDirect_0();
case -1837535538: return bem_strGet_0();
case -302299890: return bem_new_0();
case -1909928939: return bem_classNameGet_0();
case -218596632: return bem_byteIteratorIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1860890400: return bem_strSet_1(bevd_0);
case -1422004651: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case 14285247: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1896863293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 225439950: return bem_def_1(bevd_0);
case -1793329166: return bem_bcountSet_1(bevd_0);
case -1634733697: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 456193338: return bem_equals_1(bevd_0);
case 52206223: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 427509615: return bem_ivalSetDirect_1(bevd_0);
case 843456674: return bem_undef_1(bevd_0);
case -1543668236: return bem_sameObject_1(bevd_0);
case -1265978299: return bem_otherType_1(bevd_0);
case 729139192: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1675072243: return bem_sameType_1(bevd_0);
case -1397629494: return bem_bcountSetDirect_1(bevd_0);
case -1241317639: return bem_sameClass_1(bevd_0);
case -1990059666: return bem_notEquals_1(bevd_0);
case -1133289250: return bem_copyTo_1(bevd_0);
case 1848239305: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -799657616: return bem_defined_1(bevd_0);
case 1517081658: return bem_posSet_1(bevd_0);
case 1280688220: return bem_ivalSet_1(bevd_0);
case 468336390: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 80239256: return bem_vcopySet_1(bevd_0);
case 1104827466: return bem_undefined_1(bevd_0);
case -865495494: return bem_strSetDirect_1(bevd_0);
case -841166565: return bem_posSetDirect_1(bevd_0);
case 456190183: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 294741010: return bem_otherClass_1(bevd_0);
case 400110834: return bem_vcopySetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -602636079: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -679395862: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2109649093: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -541558230: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1478248032: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1942858685: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1297550285: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_4_17_TextMultiByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_17_TextMultiByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_17_TextMultiByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst = (BEC_2_4_17_TextMultiByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;
}
}
