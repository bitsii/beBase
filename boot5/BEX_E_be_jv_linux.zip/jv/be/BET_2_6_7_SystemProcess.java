package be;
public class BET_2_6_7_SystemProcess extends BETS_Object {
public BET_2_6_7_SystemProcess() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "default_0", "execNameGet_0", "execPathGet_0", "fullExecNameGet_0", "prepArgs_0", "exit_0", "exit_1", "start_1", "startByName_1", "argsGet_0", "argsSet_1", "numArgsGet_0", "numArgsSet_1", "execNameSet_1", "targetGet_0", "targetSet_1", "resultGet_0", "resultSet_1", "exceptGet_0", "exceptSet_1", "platformGet_0", "platformSet_1", "fullExecNameSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "args", "numArgs", "execName", "target", "result", "except", "platform", "fullExecName" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_7_SystemProcess();
}
}
