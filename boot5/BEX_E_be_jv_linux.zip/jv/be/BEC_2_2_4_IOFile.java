package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
private static byte[] becc_BEC_2_2_4_IOFile_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_2_4_IOFile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_inst;

public static BET_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public BEC_2_2_4_IOFile bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) throws Throwable {
bem_pathSet_1(beva__path);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_reader == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 64*/ {
bevt_1_ta_ph = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_ta_ph);
} /* Line: 65*/
return bevp_reader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_writer == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_1_ta_ph = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_ta_ph);
} /* Line: 72*/
return bevp_writer;
} /*method end*/
public BEC_2_2_4_IOFile bem_delete_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_existsGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 88*/ {

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
         bevls_f.delete();
         } /* Line: 114*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_other.bemd_0(-1191646143);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-949067316);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-128333537);
bevt_0_ta_ph.bemd_0(1591661729);
bevt_3_ta_ph = beva_other.bemd_0(-494730966);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_ta_ph.bemd_0(-2038526121);
bevt_4_ta_ph = bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_ta_ph.bemd_0(-2038526121);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_2_4_IOFile bem_mkdirs_0() throws Throwable {
bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_mkdir_0() throws Throwable {
bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_makeDirs_0() throws Throwable {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = be.BECS_Runtime.boolFalse;
bevl_t = be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevp_path.bem_toString_0();
bevt_3_ta_ph = bevl_strn.bemd_0(692845878);
bevt_1_ta_ph = bevt_2_ta_ph.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 156*/ {
bevt_5_ta_ph = bem_existsGet_0();
if (bevt_5_ta_ph.bevi_bool) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 156*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 156*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 156*/
 else /* Line: 156*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 156*/ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_ta_ph = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_ta_ph.bevi_bool)/* Line: 158*/ {
return this;
} /* Line: 160*/
bevt_7_ta_ph = bevl_parentpath.bemd_0(-128333537);
bevt_7_ta_ph.bemd_0(1591661729);

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
         bevls_f.mkdir();
         } /* Line: 201*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirectoryGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isDirGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_lastUpdatedGet_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_lu = null;
bevl_lu = (new BEC_2_4_8_TimeInterval()).bem_new_0();

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
        long ctm = bevls_f.lastModified();
        bevl_lu.bevp_secs.bevi_int = (int) (ctm / 1000);
        bevl_lu.bevp_millis.bevi_int = (int) (ctm % 1000);
        return bevl_lu;
} /*method end*/
public BEC_2_2_4_IOFile bem_lastUpdatedSet_1(BEC_2_4_8_TimeInterval beva_lu) throws Throwable {

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
        long ts = ((long)(beva_lu.bevp_secs.bevi_int)) * 1000L;
        ts = ts + beva_lu.bevp_millis.bevi_int;
        bevls_f.setLastModified(ts);
        return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_ta_ph = bem_existsGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 280*/ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
          if (bevls_f.isDirectory()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 313*/
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFileGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_ta_ph = bem_existsGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 337*/ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
          if (bevls_f.isFile()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 370*/
return bevl_result;
} /*method end*/
public BEC_2_2_4_IOFile bem_makeFile_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_0_ta_ph = bem_writerGet_0();
bevt_0_ta_ph.bemd_0(-2038526121);
bevt_1_ta_ph = bem_writerGet_0();
bevt_1_ta_ph.bemd_0(-913743481);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_existsGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 389*/ {
return null;
} /* Line: 390*/
bevt_2_ta_ph = bem_contentsNoCheckGet_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsNoCheckGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_6_6_SystemObject bevl_r = null;
bevl_r = bem_readerGet_0();
bevl_r.bemd_0(-2038526121);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(-1131334894);
bevl_r.bemd_0(-913743481);
return bevl_res;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_2_4_IOFile bevt_2_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
bevt_4_ta_ph = bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_parentGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_fileGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_existsGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 417*/ {
bevt_7_ta_ph = bem_pathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_5_ta_ph.bem_makeDirs_0();
} /* Line: 418*/
bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_6_6_SystemObject bevl_w = null;
bevl_w = bem_writerGet_0();
bevl_w.bemd_0(-2038526121);
bevl_w.bemd_1(428269575, beva_contents);
bevl_w.bemd_0(-913743481);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (new BEC_2_4_3_MathInt());

    java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
    bevl_sz.bevi_int = (int) bevls_f.length();
    return bevl_sz;
} /*method end*/
public BEC_2_5_4_LogicBool bem_existsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
bevl_tvala = be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
      if (bevls_f.exists()) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
      return bevl_tvala;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_absPathGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
        //bevl_abstr = new BEC_2_4_6_TextString(bevls_f.toPath().toRealPath().toString());
        bevl_abstr = new BEC_2_4_6_TextString(bevls_f.getCanonicalPath());
        bevl_absp = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public BEC_2_2_4_IOFile bem_close_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevp_reader == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 546*/ {
bevp_reader.bemd_0(-913743481);
} /* Line: 547*/
if (bevp_writer == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 549*/ {
bevp_writer.bemd_0(-913743481);
} /* Line: 550*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_reader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_writer = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {52, 52, 56, 56, 60, 64, 64, 65, 65, 67, 71, 71, 72, 72, 74, 88, 127, 127, 127, 127, 128, 128, 129, 129, 130, 131, 132, 133, 133, 138, 141, 152, 153, 154, 155, 156, 156, 156, 156, 156, 156, 0, 0, 0, 157, 158, 160, 162, 162, 218, 218, 223, 242, 278, 279, 280, 323, 335, 336, 337, 380, 384, 384, 385, 385, 389, 389, 389, 390, 392, 392, 408, 409, 410, 411, 413, 417, 417, 417, 417, 417, 417, 418, 418, 418, 418, 420, 434, 435, 436, 437, 443, 450, 462, 463, 521, 541, 542, 546, 546, 547, 549, 549, 550, 555, 555, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 27, 28, 32, 38, 43, 44, 45, 47, 52, 57, 58, 59, 61, 65, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 97, 101, 118, 119, 120, 121, 122, 123, 124, 126, 127, 132, 133, 136, 140, 143, 144, 146, 148, 149, 158, 159, 163, 169, 183, 184, 185, 193, 199, 200, 201, 209, 214, 215, 216, 217, 224, 225, 230, 231, 233, 234, 239, 240, 241, 242, 243, 254, 255, 256, 257, 258, 263, 264, 265, 266, 267, 269, 274, 275, 276, 277, 282, 286, 291, 292, 298, 307, 308, 313, 318, 319, 321, 326, 327, 333, 334, 337, 340, 344, 348};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 52 21
new 1 52 21
pathSet 1 52 22
assign 1 56 27
apNew 1 56 27
pathSet 1 56 28
pathSet 1 60 32
assign 1 64 38
undef 1 64 43
assign 1 65 44
toString 0 65 44
assign 1 65 45
new 1 65 45
return 1 67 47
assign 1 71 52
undef 1 71 57
assign 1 72 58
toString 0 72 58
assign 1 72 59
new 1 72 59
return 1 74 61
assign 1 88 65
existsGet 0 88 65
assign 1 127 82
pathGet 0 127 82
assign 1 127 83
parentGet 0 127 83
assign 1 127 84
fileGet 0 127 84
makeDirs 0 127 85
assign 1 128 86
writerGet 0 128 86
assign 1 128 87
open 0 128 87
assign 1 129 88
readerGet 0 129 88
assign 1 129 89
open 0 129 89
copyData 1 130 90
close 0 131 91
close 0 132 92
assign 1 133 93
new 0 133 93
return 1 133 94
makeDirs 0 138 97
makeDirs 0 141 101
assign 1 152 118
toString 0 152 118
assign 1 153 119
new 0 153 119
assign 1 154 120
new 0 154 120
assign 1 155 121
new 0 155 121
assign 1 156 122
toString 0 156 122
assign 1 156 123
emptyGet 0 156 123
assign 1 156 124
notEquals 1 156 124
assign 1 156 126
existsGet 0 156 126
assign 1 156 127
not 0 156 132
assign 1 0 133
assign 1 0 136
assign 1 0 140
assign 1 157 143
parentGet 0 157 143
assign 1 158 144
equals 1 158 144
return 1 160 146
assign 1 162 148
fileGet 0 162 148
makeDirs 0 162 149
assign 1 218 158
isDirGet 0 218 158
return 1 218 159
assign 1 223 163
new 0 223 163
return 1 242 169
assign 1 278 183
new 0 278 183
assign 1 279 184
toString 0 279 184
assign 1 280 185
existsGet 0 280 185
return 1 323 193
assign 1 335 199
new 0 335 199
assign 1 336 200
toString 0 336 200
assign 1 337 201
existsGet 0 337 201
return 1 380 209
assign 1 384 214
writerGet 0 384 214
open 0 384 215
assign 1 385 216
writerGet 0 385 216
close 0 385 217
assign 1 389 224
existsGet 0 389 224
assign 1 389 225
not 0 389 230
return 1 390 231
assign 1 392 233
contentsNoCheckGet 0 392 233
return 1 392 234
assign 1 408 239
readerGet 0 408 239
open 0 409 240
assign 1 410 241
readString 0 410 241
close 0 411 242
return 1 413 243
assign 1 417 254
pathGet 0 417 254
assign 1 417 255
parentGet 0 417 255
assign 1 417 256
fileGet 0 417 256
assign 1 417 257
existsGet 0 417 257
assign 1 417 258
not 0 417 263
assign 1 418 264
pathGet 0 418 264
assign 1 418 265
parentGet 0 418 265
assign 1 418 266
fileGet 0 418 266
makeDirs 0 418 267
contentsNoCheckSet 1 420 269
assign 1 434 274
writerGet 0 434 274
open 0 435 275
write 1 436 276
close 0 437 277
assign 1 443 282
new 0 443 282
return 1 450 286
assign 1 462 291
new 0 462 291
assign 1 463 292
toString 0 463 292
return 1 521 298
assign 1 541 307
apNew 1 541 307
return 1 542 308
assign 1 546 313
def 1 546 318
close 0 547 319
assign 1 549 321
def 1 549 326
close 0 550 327
assign 1 555 333
new 1 555 333
return 1 555 334
return 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 0 348
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1474801658: return bem_contentsNoCheckGet_0();
case -1191646143: return bem_pathGet_0();
case -1989712623: return bem_hashGet_0();
case -913743481: return bem_close_0();
case 355565519: return bem_iteratorGet_0();
case -1958410252: return bem_makeFile_0();
case 1297296473: return bem_toString_0();
case 969409102: return bem_lastUpdatedGet_0();
case 940631698: return bem_copy_0();
case -494730966: return bem_writerGet_0();
case 1332556390: return bem_create_0();
case -935962885: return bem_contentsGet_0();
case -905585974: return bem_mkdir_0();
case 1591661729: return bem_makeDirs_0();
case 735421667: return bem_delete_0();
case 1033905511: return bem_new_0();
case -451680896: return bem_print_0();
case 424949979: return bem_lengthGet_0();
case -1001718297: return bem_existsGet_0();
case 337485574: return bem_isDirectoryGet_0();
case -1276023196: return bem_isDirGet_0();
case 1445742489: return bem_readerGet_0();
case -640749668: return bem_mkdirs_0();
case -787250898: return bem_isFileGet_0();
case 160657278: return bem_absPathGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1953847240: return bem_print_1(bevd_0);
case 968880155: return bem_new_1(bevd_0);
case -1014578993: return bem_readerSet_1(bevd_0);
case -618247473: return bem_undef_1(bevd_0);
case 1110937156: return bem_copyTo_1(bevd_0);
case 134302648: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case 1408207335: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case -2069842105: return bem_notEquals_1(bevd_0);
case 1161478433: return bem_equals_1(bevd_0);
case 88944782: return bem_writerSet_1(bevd_0);
case -884552850: return bem_pathSet_1(bevd_0);
case 159582032: return bem_def_1(bevd_0);
case -1998952975: return bem_apNew_1(bevd_0);
case 1122576505: return bem_copyFile_1(bevd_0);
case -469887374: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
case -1571055533: return bem_lastUpdatedSet_1((BEC_2_4_8_TimeInterval) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1744432305: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 681643689: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1355956619: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142010341: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOFile_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_2_4_IOFile_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOFile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst = (BEC_2_2_4_IOFile) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_type;
}
}
