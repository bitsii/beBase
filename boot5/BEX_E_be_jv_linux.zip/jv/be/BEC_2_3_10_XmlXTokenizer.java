package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_10_XmlXTokenizer extends BEC_2_6_6_SystemObject {
public BEC_2_3_10_XmlXTokenizer() { }
private static byte[] becc_BEC_2_3_10_XmlXTokenizer_clname = {0x58,0x6D,0x6C,0x3A,0x58,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_3_10_XmlXTokenizer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_10_XmlXTokenizer_bels_0 = {0x3C,0x3E,0x3D,0x2F,0x3F,0x21,0x20,0x22};
public static BEC_2_3_10_XmlXTokenizer bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;

public static BET_2_3_10_XmlXTokenizer bece_BEC_2_3_10_XmlXTokenizer_bevs_type;

public BEC_2_4_9_TextTokenizer bevp_tok;
public BEC_2_3_10_XmlXTokenizer bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_tokString = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_tokString = (new BEC_2_4_6_TextString(8, bece_BEC_2_3_10_XmlXTokenizer_bels_0));
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
bevp_tok = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevl_tokString, bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokGet_0() throws Throwable {
return bevp_tok;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_tokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {131, 133, 133, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 25, 28};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 131 19
new 0 131 19
assign 1 133 20
new 0 133 20
assign 1 133 21
new 2 133 21
return 1 0 25
assign 1 0 28
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1424738458: return bem_print_0();
case -903358941: return bem_toString_0();
case -902820172: return bem_default_0();
case -50780742: return bem_tokGet_0();
case -1639054862: return bem_hashGet_0();
case 743152734: return bem_create_0();
case 1242460733: return bem_new_0();
case 812771584: return bem_iteratorGet_0();
case -176347951: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -149548840: return bem_def_1(bevd_0);
case -893961213: return bem_copyTo_1(bevd_0);
case 1475300950: return bem_tokSet_1(bevd_0);
case -941197725: return bem_equals_1(bevd_0);
case 1686036436: return bem_undef_1(bevd_0);
case 1864059490: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1551948487: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 625211722: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1456032033: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 217238601: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_3_10_XmlXTokenizer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_10_XmlXTokenizer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_10_XmlXTokenizer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst = (BEC_2_3_10_XmlXTokenizer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_type;
}
}
