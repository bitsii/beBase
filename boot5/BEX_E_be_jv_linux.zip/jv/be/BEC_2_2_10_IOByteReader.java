package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_10_IOByteReader extends BEC_2_6_6_SystemObject {
public BEC_2_2_10_IOByteReader() { }
private static byte[] becc_BEC_2_2_10_IOByteReader_clname = {0x49,0x4F,0x3A,0x42,0x79,0x74,0x65,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_10_IOByteReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_inst;

public static BET_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_type;

public BEC_2_2_6_IOReader bevp_reader;
public BEC_2_4_6_TextString bevp_buf;
public BEC_2_4_12_TextByteIterator bevp_iter;
public BEC_2_2_10_IOByteReader bem_readerBufferNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_6_TextString beva__buf) throws Throwable {
bevp_reader = beva__reader;
bevp_buf = beva__buf;
bevp_iter = bevp_buf.bem_biterGet_0();
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerNew_1(BEC_2_2_6_IOReader beva__reader) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(256));
bevt_0_tmpany_phold = bem_readerBlockNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerBlockNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_3_MathInt beva__blockSize) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva__blockSize);
bevt_0_tmpany_phold = bem_readerBufferNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 41 */
bevt_3_tmpany_phold = bevp_iter.bem_hasNextGet_0();
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_dest) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 53 */
bevt_3_tmpany_phold = bevp_iter.bem_next_1(beva_dest);
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_2_6_IOReader bem_readerGet_0() throws Throwable {
return bevp_reader;
} /*method end*/
public final BEC_2_2_6_IOReader bem_readerGetDirect_0() throws Throwable {
return bevp_reader;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_bufGet_0() throws Throwable {
return bevp_buf;
} /*method end*/
public final BEC_2_4_6_TextString bem_bufGetDirect_0() throws Throwable {
return bevp_buf;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_bufSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_bufSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_iterGetDirect_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 25, 26, 31, 31, 31, 35, 35, 35, 39, 39, 39, 40, 41, 41, 43, 43, 47, 47, 47, 47, 51, 51, 51, 52, 53, 53, 55, 55, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 23, 24, 25, 30, 31, 32, 39, 40, 45, 46, 47, 48, 50, 51, 57, 58, 59, 60, 67, 68, 73, 74, 75, 76, 78, 79, 82, 85, 88, 92, 96, 99, 102, 106, 110, 113, 116, 120};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 15
assign 1 25 16
assign 1 26 17
biterGet 0 26 17
assign 1 31 23
new 0 31 23
assign 1 31 24
readerBlockNew 2 31 24
return 1 31 25
assign 1 35 30
new 1 35 30
assign 1 35 31
readerBufferNew 2 35 31
return 1 35 32
assign 1 39 39
hasNextGet 0 39 39
assign 1 39 40
not 0 39 45
readIntoBuffer 1 40 46
assign 1 41 47
new 0 41 47
posSet 1 41 48
assign 1 43 50
hasNextGet 0 43 50
return 1 43 51
assign 1 47 57
new 0 47 57
assign 1 47 58
new 1 47 58
assign 1 47 59
next 1 47 59
return 1 47 60
assign 1 51 67
hasNextGet 0 51 67
assign 1 51 68
not 0 51 73
readIntoBuffer 1 52 74
assign 1 53 75
new 0 53 75
posSet 1 53 76
assign 1 55 78
next 1 55 78
return 1 55 79
return 1 0 82
return 1 0 85
assign 1 0 88
assign 1 0 92
return 1 0 96
return 1 0 99
assign 1 0 102
assign 1 0 106
return 1 0 110
return 1 0 113
assign 1 0 116
assign 1 0 120
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1995804558: return bem_toString_0();
case -858518329: return bem_many_0();
case -1890761825: return bem_hashGet_0();
case 1592801927: return bem_serializeContents_0();
case -1845402369: return bem_create_0();
case 944745844: return bem_iteratorGet_0();
case 607044499: return bem_bufGet_0();
case -1074656634: return bem_iterGetDirect_0();
case -918254534: return bem_readerGetDirect_0();
case -703952395: return bem_toAny_0();
case 1835904283: return bem_fieldIteratorGet_0();
case -513985458: return bem_once_0();
case 745980876: return bem_serializeToString_0();
case -1038670564: return bem_iterGet_0();
case 1562045422: return bem_print_0();
case -1648763323: return bem_hasNextGet_0();
case -1661579204: return bem_nextGet_0();
case -1155411626: return bem_classNameGet_0();
case 319885107: return bem_readerGet_0();
case -1247813666: return bem_tagGet_0();
case 841207683: return bem_new_0();
case -225078823: return bem_serializationIteratorGet_0();
case 1313549684: return bem_bufGetDirect_0();
case -1154985755: return bem_echo_0();
case -967525204: return bem_fieldNamesGet_0();
case 285074277: return bem_deserializeClassNameGet_0();
case 232809271: return bem_copy_0();
case 863596927: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 88808523: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -527356374: return bem_bufSetDirect_1(bevd_0);
case 227345253: return bem_iterSetDirect_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case -1063605340: return bem_readerNew_1((BEC_2_2_6_IOReader) bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1200297939: return bem_undef_1(bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1449411238: return bem_readerSet_1(bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
case 98173735: return bem_readerSetDirect_1(bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
case -497281228: return bem_iterSet_1(bevd_0);
case 12031225: return bem_def_1(bevd_0);
case -1815546435: return bem_copyTo_1(bevd_0);
case 1542124784: return bem_bufSet_1(bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1971244994: return bem_readerBufferNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -747913088: return bem_readerBlockNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_2_10_IOByteReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_10_IOByteReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_10_IOByteReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst = (BEC_2_2_10_IOByteReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_type;
}
}
