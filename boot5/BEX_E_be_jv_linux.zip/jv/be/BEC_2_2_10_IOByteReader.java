package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_10_IOByteReader extends BEC_2_6_6_SystemObject {
public BEC_2_2_10_IOByteReader() { }
private static byte[] becc_BEC_2_2_10_IOByteReader_clname = {0x49,0x4F,0x3A,0x42,0x79,0x74,0x65,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_10_IOByteReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_inst;

public static BET_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_type;

public BEC_2_2_6_IOReader bevp_reader;
public BEC_2_4_6_TextString bevp_buf;
public BEC_2_4_12_TextByteIterator bevp_iter;
public BEC_2_2_10_IOByteReader bem_readerBufferNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_6_TextString beva__buf) throws Throwable {
bevp_reader = beva__reader;
bevp_buf = beva__buf;
bevp_iter = bevp_buf.bem_biterGet_0();
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerNew_1(BEC_2_2_6_IOReader beva__reader) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(256));
bevt_0_tmpany_phold = bem_readerBlockNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerBlockNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_3_MathInt beva__blockSize) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva__blockSize);
bevt_0_tmpany_phold = bem_readerBufferNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 42 */
bevt_3_tmpany_phold = bevp_iter.bem_hasNextGet_0();
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_dest) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 54 */
bevt_3_tmpany_phold = bevp_iter.bem_next_1(beva_dest);
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_2_6_IOReader bem_readerGet_0() throws Throwable {
return bevp_reader;
} /*method end*/
public final BEC_2_2_6_IOReader bem_readerGetDirect_0() throws Throwable {
return bevp_reader;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_bufGet_0() throws Throwable {
return bevp_buf;
} /*method end*/
public final BEC_2_4_6_TextString bem_bufGetDirect_0() throws Throwable {
return bevp_buf;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_bufSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_bufSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_iterGetDirect_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {25, 26, 27, 32, 32, 32, 36, 36, 36, 40, 40, 40, 41, 42, 42, 44, 44, 48, 48, 48, 48, 52, 52, 52, 53, 54, 54, 56, 56, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 23, 24, 25, 30, 31, 32, 39, 40, 45, 46, 47, 48, 50, 51, 57, 58, 59, 60, 67, 68, 73, 74, 75, 76, 78, 79, 82, 85, 88, 92, 96, 99, 102, 106, 110, 113, 116, 120};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 25 15
assign 1 26 16
assign 1 27 17
biterGet 0 27 17
assign 1 32 23
new 0 32 23
assign 1 32 24
readerBlockNew 2 32 24
return 1 32 25
assign 1 36 30
new 1 36 30
assign 1 36 31
readerBufferNew 2 36 31
return 1 36 32
assign 1 40 39
hasNextGet 0 40 39
assign 1 40 40
not 0 40 45
readIntoBuffer 1 41 46
assign 1 42 47
new 0 42 47
posSet 1 42 48
assign 1 44 50
hasNextGet 0 44 50
return 1 44 51
assign 1 48 57
new 0 48 57
assign 1 48 58
new 1 48 58
assign 1 48 59
next 1 48 59
return 1 48 60
assign 1 52 67
hasNextGet 0 52 67
assign 1 52 68
not 0 52 73
readIntoBuffer 1 53 74
assign 1 54 75
new 0 54 75
posSet 1 54 76
assign 1 56 78
next 1 56 78
return 1 56 79
return 1 0 82
return 1 0 85
assign 1 0 88
assign 1 0 92
return 1 0 96
return 1 0 99
assign 1 0 102
assign 1 0 106
return 1 0 110
return 1 0 113
assign 1 0 116
assign 1 0 120
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1143714699: return bem_iterGetDirect_0();
case -302299890: return bem_new_0();
case 580957788: return bem_fieldNamesGet_0();
case -1909928939: return bem_classNameGet_0();
case 535289201: return bem_bufGet_0();
case 2082915487: return bem_copy_0();
case -1002223418: return bem_deserializeClassNameGet_0();
case -1614787794: return bem_bufGetDirect_0();
case -1832151313: return bem_readerGetDirect_0();
case -403090829: return bem_iterGet_0();
case -1347713072: return bem_many_0();
case 376180278: return bem_readerGet_0();
case -1541237194: return bem_once_0();
case 1362114893: return bem_hashGet_0();
case 1545963265: return bem_tagGet_0();
case 520256150: return bem_print_0();
case 1226301190: return bem_create_0();
case 2128158896: return bem_iteratorGet_0();
case 1212400791: return bem_hasNextGet_0();
case -1349248202: return bem_nextGet_0();
case -728251540: return bem_echo_0();
case 304205171: return bem_sourceFileNameGet_0();
case -92297996: return bem_serializeContents_0();
case 1971636542: return bem_fieldIteratorGet_0();
case 592499503: return bem_serializationIteratorGet_0();
case -402973175: return bem_toString_0();
case -2022113180: return bem_toAny_0();
case 502686321: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 14285247: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1896863293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 225439950: return bem_def_1(bevd_0);
case 456193338: return bem_equals_1(bevd_0);
case 1311457915: return bem_bufSet_1(bevd_0);
case 52206223: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 843456674: return bem_undef_1(bevd_0);
case -1543668236: return bem_sameObject_1(bevd_0);
case 2594578: return bem_iterSetDirect_1(bevd_0);
case -1265978299: return bem_otherType_1(bevd_0);
case -1675072243: return bem_sameType_1(bevd_0);
case -1241317639: return bem_sameClass_1(bevd_0);
case 1841958559: return bem_readerNew_1((BEC_2_2_6_IOReader) bevd_0);
case -1990059666: return bem_notEquals_1(bevd_0);
case -1133289250: return bem_copyTo_1(bevd_0);
case -1505003636: return bem_readerSetDirect_1(bevd_0);
case -799657616: return bem_defined_1(bevd_0);
case 468336390: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -336197187: return bem_bufSetDirect_1(bevd_0);
case 1104827466: return bem_undefined_1(bevd_0);
case -2051048181: return bem_iterSet_1(bevd_0);
case 456190183: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 466482673: return bem_readerSet_1(bevd_0);
case 294741010: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -541558230: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -694552100: return bem_readerBufferNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -679395862: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1478248032: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2109649093: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -602636079: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1942858685: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1297550285: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1489493565: return bem_readerBlockNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_2_10_IOByteReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_10_IOByteReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_10_IOByteReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst = (BEC_2_2_10_IOByteReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_type;
}
}
