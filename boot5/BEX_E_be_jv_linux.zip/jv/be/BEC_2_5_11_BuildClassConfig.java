package be;
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig extends BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x2E,0x73,0x79,0x6E};
public static BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_1_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_ta_ph = bevp_emitPath.bem_copy_0();
bevt_3_ta_ph = bevp_emitter.bem_emitLangGet_0();
bevt_1_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_2_ta_ph.bem_addStep_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_1_ta_ph.bem_addStep_1(bevt_4_ta_ph);
bevt_6_ta_ph = bevp_emitter.bem_fileExtGet_0();
bevt_5_ta_ph = bevp_emitName.bem_add_1(bevt_6_ta_ph);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_ph.bem_addStep_1(bevt_5_ta_ph);
bevt_9_ta_ph = bevp_emitPath.bem_copy_0();
bevt_10_ta_ph = bevp_emitter.bem_emitLangGet_0();
bevt_8_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_9_ta_ph.bem_addStep_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_7_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_8_ta_ph.bem_addStep_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_emitter.bem_fileExtGet_0();
bevt_12_ta_ph = bevp_typeEmitName.bem_add_1(bevt_13_ta_ph);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_ta_ph.bem_addStep_1(bevt_12_ta_ph);
bevp_classDir = bevp_classPath.bem_parentGet_0();
bevt_14_ta_ph = bevp_classDir.bem_copy_0();
bevt_16_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_11_BuildClassConfig_bels_1));
bevt_15_ta_ph = bevp_emitName.bem_add_1(bevt_16_ta_ph);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_ta_ph.bem_addStep_1(bevt_15_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGet_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGet_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGet_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGet_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGet_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGet_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGet_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGet_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {2458, 2459, 2460, 2461, 2463, 2464, 2465, 2466, 2467, 2467, 2467, 2467, 2467, 2467, 2467, 2467, 2468, 2468, 2468, 2468, 2468, 2468, 2468, 2468, 2469, 2470, 2470, 2470, 2470, 2477, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 75, 78, 81, 85, 88, 92, 95, 99, 102, 106, 109, 113, 116, 120, 123, 127, 130, 134, 137, 141, 144, 148, 151, 155, 158};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 2458 43
assign 1 2459 44
assign 1 2460 45
assign 1 2461 46
assign 1 2463 47
getNameSpace 1 2463 47
assign 1 2464 48
getEmitName 1 2464 48
assign 1 2465 49
getTypeEmitName 1 2465 49
assign 1 2466 50
getFullEmitName 2 2466 50
assign 1 2467 51
copy 0 2467 51
assign 1 2467 52
emitLangGet 0 2467 52
assign 1 2467 53
addStep 1 2467 53
assign 1 2467 54
new 0 2467 54
assign 1 2467 55
addStep 1 2467 55
assign 1 2467 56
fileExtGet 0 2467 56
assign 1 2467 57
add 1 2467 57
assign 1 2467 58
addStep 1 2467 58
assign 1 2468 59
copy 0 2468 59
assign 1 2468 60
emitLangGet 0 2468 60
assign 1 2468 61
addStep 1 2468 61
assign 1 2468 62
new 0 2468 62
assign 1 2468 63
addStep 1 2468 63
assign 1 2468 64
fileExtGet 0 2468 64
assign 1 2468 65
add 1 2468 65
assign 1 2468 66
addStep 1 2468 66
assign 1 2469 67
parentGet 0 2469 67
assign 1 2470 68
copy 0 2470 68
assign 1 2470 69
new 0 2470 69
assign 1 2470 70
add 1 2470 70
assign 1 2470 71
addStep 1 2470 71
return 1 2477 75
return 1 0 78
assign 1 0 81
return 1 0 85
assign 1 0 88
return 1 0 92
assign 1 0 95
return 1 0 99
assign 1 0 102
return 1 0 106
assign 1 0 109
return 1 0 113
assign 1 0 116
return 1 0 120
assign 1 0 123
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -553059238: return bem_emitPathGet_0();
case -1118382469: return bem_fullEmitNameGet_0();
case 891454005: return bem_libNameGet_0();
case -2043497378: return bem_emitNameGet_0();
case 1769965429: return bem_toString_0();
case 1327010431: return bem_hashGet_0();
case 532380883: return bem_new_0();
case 827177183: return bem_nameSpaceGet_0();
case 1210752379: return bem_npGet_0();
case 1318937193: return bem_create_0();
case -1338265248: return bem_typePathGet_0();
case -443788944: return bem_typeEmitNameGet_0();
case 1434765549: return bem_synPathGet_0();
case 2120153411: return bem_copy_0();
case 703317858: return bem_classPathGet_0();
case -469226465: return bem_print_0();
case 626780527: return bem_classDirGet_0();
case -980675249: return bem_emitterGet_0();
case 966722567: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -268811991: return bem_equals_1(bevd_0);
case -672769576: return bem_nameSpaceSet_1(bevd_0);
case -1355574345: return bem_emitPathSet_1(bevd_0);
case -859758655: return bem_typeEmitNameSet_1(bevd_0);
case -1388256124: return bem_classPathSet_1(bevd_0);
case 1651277717: return bem_classDirSet_1(bevd_0);
case -861338237: return bem_fullEmitNameSet_1(bevd_0);
case -16136112: return bem_notEquals_1(bevd_0);
case -159077213: return bem_npSet_1(bevd_0);
case -533094380: return bem_undef_1(bevd_0);
case 596223794: return bem_libNameSet_1(bevd_0);
case -2053271830: return bem_emitNameSet_1(bevd_0);
case 1649090632: return bem_typePathSet_1(bevd_0);
case 1371038542: return bem_synPathSet_1(bevd_0);
case 1194286113: return bem_def_1(bevd_0);
case 2022432883: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 2147027771: return bem_copyTo_1(bevd_0);
case -608947554: return bem_emitterSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1665151698: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 792362948: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -672637344: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1688602503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -513403753: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_11_BuildClassConfig();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
