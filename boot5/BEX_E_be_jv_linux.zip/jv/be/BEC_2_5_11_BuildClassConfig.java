package be;
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig extends BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_11_BuildClassConfig_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_11_BuildClassConfig_bels_1, 4));
public static BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_1_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_ta_ph = bevp_emitPath.bem_copy_0();
bevt_3_ta_ph = bevp_emitter.bem_emitLangGet_0();
bevt_1_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_2_ta_ph.bem_addStep_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_1_ta_ph.bem_addStep_1(bevt_4_ta_ph);
bevt_6_ta_ph = bevp_emitter.bem_fileExtGet_0();
bevt_5_ta_ph = bevp_emitName.bem_add_1(bevt_6_ta_ph);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_ph.bem_addStep_1(bevt_5_ta_ph);
bevt_9_ta_ph = bevp_emitPath.bem_copy_0();
bevt_10_ta_ph = bevp_emitter.bem_emitLangGet_0();
bevt_8_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_9_ta_ph.bem_addStep_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_7_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_8_ta_ph.bem_addStep_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_emitter.bem_fileExtGet_0();
bevt_12_ta_ph = bevp_typeEmitName.bem_add_1(bevt_13_ta_ph);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_ta_ph.bem_addStep_1(bevt_12_ta_ph);
bevp_classDir = bevp_classPath.bem_parentGet_0();
bevt_14_ta_ph = bevp_classDir.bem_copy_0();
bevt_16_ta_ph = bece_BEC_2_5_11_BuildClassConfig_bevo_0;
bevt_15_ta_ph = bevp_emitName.bem_add_1(bevt_16_ta_ph);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_ta_ph.bem_addStep_1(bevt_15_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_npGetDirect_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGet_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGet_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_emitNameGetDirect_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGet_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGet_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGet_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGet_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGet_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGet_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {2555, 2556, 2557, 2558, 2560, 2561, 2562, 2563, 2564, 2564, 2564, 2564, 2564, 2564, 2564, 2564, 2565, 2565, 2565, 2565, 2565, 2565, 2565, 2565, 2566, 2567, 2567, 2567, 2567, 2574, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 76, 79, 82, 85, 89, 93, 96, 99, 103, 107, 110, 113, 117, 121, 124, 127, 131, 135, 138, 141, 145, 149, 152, 155, 159, 163, 166, 169, 173, 177, 180, 183, 187, 191, 194, 197, 201, 205, 208, 211, 215, 219, 222, 225, 229, 233, 236, 239, 243};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 2555 44
assign 1 2556 45
assign 1 2557 46
assign 1 2558 47
assign 1 2560 48
getNameSpace 1 2560 48
assign 1 2561 49
getEmitName 1 2561 49
assign 1 2562 50
getTypeEmitName 1 2562 50
assign 1 2563 51
getFullEmitName 2 2563 51
assign 1 2564 52
copy 0 2564 52
assign 1 2564 53
emitLangGet 0 2564 53
assign 1 2564 54
addStep 1 2564 54
assign 1 2564 55
new 0 2564 55
assign 1 2564 56
addStep 1 2564 56
assign 1 2564 57
fileExtGet 0 2564 57
assign 1 2564 58
add 1 2564 58
assign 1 2564 59
addStep 1 2564 59
assign 1 2565 60
copy 0 2565 60
assign 1 2565 61
emitLangGet 0 2565 61
assign 1 2565 62
addStep 1 2565 62
assign 1 2565 63
new 0 2565 63
assign 1 2565 64
addStep 1 2565 64
assign 1 2565 65
fileExtGet 0 2565 65
assign 1 2565 66
add 1 2565 66
assign 1 2565 67
addStep 1 2565 67
assign 1 2566 68
parentGet 0 2566 68
assign 1 2567 69
copy 0 2567 69
assign 1 2567 70
new 0 2567 70
assign 1 2567 71
add 1 2567 71
assign 1 2567 72
addStep 1 2567 72
return 1 2574 76
return 1 0 79
return 1 0 82
assign 1 0 85
assign 1 0 89
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
return 1 0 107
return 1 0 110
assign 1 0 113
assign 1 0 117
return 1 0 121
return 1 0 124
assign 1 0 127
assign 1 0 131
return 1 0 135
return 1 0 138
assign 1 0 141
assign 1 0 145
return 1 0 149
return 1 0 152
assign 1 0 155
assign 1 0 159
return 1 0 163
return 1 0 166
assign 1 0 169
assign 1 0 173
return 1 0 177
return 1 0 180
assign 1 0 183
assign 1 0 187
return 1 0 191
return 1 0 194
assign 1 0 197
assign 1 0 201
return 1 0 205
return 1 0 208
assign 1 0 211
assign 1 0 215
return 1 0 219
return 1 0 222
assign 1 0 225
assign 1 0 229
return 1 0 233
return 1 0 236
assign 1 0 239
assign 1 0 243
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1925469690: return bem_classPathGet_0();
case 137910263: return bem_create_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 427210854: return bem_typeEmitNameGet_0();
case -438289515: return bem_fieldIteratorGet_0();
case -650342445: return bem_classDirGet_0();
case 1197496250: return bem_npGetDirect_0();
case -1027570260: return bem_typePathGet_0();
case -1714583788: return bem_classNameGet_0();
case -959754001: return bem_emitNameGet_0();
case -307590837: return bem_nameSpaceGetDirect_0();
case -111466503: return bem_libNameGet_0();
case -1238524057: return bem_print_0();
case -714038893: return bem_typePathGetDirect_0();
case -1079456517: return bem_many_0();
case 1128317001: return bem_emitterGetDirect_0();
case 1639582202: return bem_synPathGetDirect_0();
case 78412540: return bem_toAny_0();
case -549895508: return bem_classPathGetDirect_0();
case 217381802: return bem_serializationIteratorGet_0();
case -1515232092: return bem_emitNameGetDirect_0();
case -340425176: return bem_synPathGet_0();
case -1426056679: return bem_hashGet_0();
case -581423335: return bem_fullEmitNameGetDirect_0();
case 205150354: return bem_new_0();
case -2013185743: return bem_classDirGetDirect_0();
case 765953524: return bem_emitPathGet_0();
case -1331626162: return bem_iteratorGet_0();
case 1659042909: return bem_fullEmitNameGet_0();
case -1373967212: return bem_nameSpaceGet_0();
case 228997531: return bem_emitPathGetDirect_0();
case -1570949102: return bem_emitterGet_0();
case 310047227: return bem_fieldNamesGet_0();
case -777537417: return bem_serializeContents_0();
case 2071247075: return bem_sourceFileNameGet_0();
case 1934724046: return bem_npGet_0();
case 1414587077: return bem_libNameGetDirect_0();
case 221458969: return bem_serializeToString_0();
case -1392846471: return bem_toString_0();
case -1851472893: return bem_once_0();
case -2132343660: return bem_typeEmitNameGetDirect_0();
case 814015164: return bem_copy_0();
case 993286746: return bem_echo_0();
case -992634121: return bem_tagGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1618221926: return bem_emitterSetDirect_1(bevd_0);
case 878810136: return bem_typeEmitNameSet_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1939284887: return bem_nameSpaceSetDirect_1(bevd_0);
case -904591535: return bem_fullEmitNameSet_1(bevd_0);
case 71608307: return bem_emitNameSet_1(bevd_0);
case -890860243: return bem_classDirSet_1(bevd_0);
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case -1584191910: return bem_libNameSetDirect_1(bevd_0);
case 917823712: return bem_npSet_1(bevd_0);
case -1158300656: return bem_nameSpaceSet_1(bevd_0);
case 1389040156: return bem_emitterSet_1(bevd_0);
case -922629382: return bem_typePathSetDirect_1(bevd_0);
case 824102803: return bem_emitNameSetDirect_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 704807417: return bem_libNameSet_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case -1646057843: return bem_classDirSetDirect_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case -541629297: return bem_classPathSet_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case -1489605993: return bem_emitPathSetDirect_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 1439728225: return bem_synPathSet_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case -1314706677: return bem_classPathSetDirect_1(bevd_0);
case -895416336: return bem_typePathSet_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case -1277330024: return bem_synPathSetDirect_1(bevd_0);
case -1489640675: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1300148739: return bem_fullEmitNameSetDirect_1(bevd_0);
case 2081674741: return bem_typeEmitNameSetDirect_1(bevd_0);
case -2031592231: return bem_npSetDirect_1(bevd_0);
case 1435851625: return bem_emitPathSet_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -685979409: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_11_BuildClassConfig();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
