package be;
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig extends BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x2E,0x73,0x79,0x6E};
public static BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_1_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_ta_ph = bevp_emitPath.bem_copy_0();
bevt_3_ta_ph = bevp_emitter.bem_emitLangGet_0();
bevt_1_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_2_ta_ph.bem_addStep_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_1_ta_ph.bem_addStep_1(bevt_4_ta_ph);
bevt_6_ta_ph = bevp_emitter.bem_fileExtGet_0();
bevt_5_ta_ph = bevp_emitName.bem_add_1(bevt_6_ta_ph);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_ph.bem_addStep_1(bevt_5_ta_ph);
bevt_9_ta_ph = bevp_emitPath.bem_copy_0();
bevt_10_ta_ph = bevp_emitter.bem_emitLangGet_0();
bevt_8_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_9_ta_ph.bem_addStep_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_7_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_8_ta_ph.bem_addStep_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_emitter.bem_fileExtGet_0();
bevt_12_ta_ph = bevp_typeEmitName.bem_add_1(bevt_13_ta_ph);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_ta_ph.bem_addStep_1(bevt_12_ta_ph);
bevp_classDir = bevp_classPath.bem_parentGet_0();
bevt_14_ta_ph = bevp_classDir.bem_copy_0();
bevt_16_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_11_BuildClassConfig_bels_1));
bevt_15_ta_ph = bevp_emitName.bem_add_1(bevt_16_ta_ph);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_ta_ph.bem_addStep_1(bevt_15_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_npGetDirect_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGet_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGet_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_emitNameGetDirect_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGet_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGet_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGet_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGet_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGet_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGet_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {2470, 2471, 2472, 2473, 2475, 2476, 2477, 2478, 2479, 2479, 2479, 2479, 2479, 2479, 2479, 2479, 2480, 2480, 2480, 2480, 2480, 2480, 2480, 2480, 2481, 2482, 2482, 2482, 2482, 2489, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 75, 78, 81, 84, 88, 92, 95, 98, 102, 106, 109, 112, 116, 120, 123, 126, 130, 134, 137, 140, 144, 148, 151, 154, 158, 162, 165, 168, 172, 176, 179, 182, 186, 190, 193, 196, 200, 204, 207, 210, 214, 218, 221, 224, 228, 232, 235, 238, 242};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 2470 43
assign 1 2471 44
assign 1 2472 45
assign 1 2473 46
assign 1 2475 47
getNameSpace 1 2475 47
assign 1 2476 48
getEmitName 1 2476 48
assign 1 2477 49
getTypeEmitName 1 2477 49
assign 1 2478 50
getFullEmitName 2 2478 50
assign 1 2479 51
copy 0 2479 51
assign 1 2479 52
emitLangGet 0 2479 52
assign 1 2479 53
addStep 1 2479 53
assign 1 2479 54
new 0 2479 54
assign 1 2479 55
addStep 1 2479 55
assign 1 2479 56
fileExtGet 0 2479 56
assign 1 2479 57
add 1 2479 57
assign 1 2479 58
addStep 1 2479 58
assign 1 2480 59
copy 0 2480 59
assign 1 2480 60
emitLangGet 0 2480 60
assign 1 2480 61
addStep 1 2480 61
assign 1 2480 62
new 0 2480 62
assign 1 2480 63
addStep 1 2480 63
assign 1 2480 64
fileExtGet 0 2480 64
assign 1 2480 65
add 1 2480 65
assign 1 2480 66
addStep 1 2480 66
assign 1 2481 67
parentGet 0 2481 67
assign 1 2482 68
copy 0 2482 68
assign 1 2482 69
new 0 2482 69
assign 1 2482 70
add 1 2482 70
assign 1 2482 71
addStep 1 2482 71
return 1 2489 75
return 1 0 78
return 1 0 81
assign 1 0 84
assign 1 0 88
return 1 0 92
return 1 0 95
assign 1 0 98
assign 1 0 102
return 1 0 106
return 1 0 109
assign 1 0 112
assign 1 0 116
return 1 0 120
return 1 0 123
assign 1 0 126
assign 1 0 130
return 1 0 134
return 1 0 137
assign 1 0 140
assign 1 0 144
return 1 0 148
return 1 0 151
assign 1 0 154
assign 1 0 158
return 1 0 162
return 1 0 165
assign 1 0 168
assign 1 0 172
return 1 0 176
return 1 0 179
assign 1 0 182
assign 1 0 186
return 1 0 190
return 1 0 193
assign 1 0 196
assign 1 0 200
return 1 0 204
return 1 0 207
assign 1 0 210
assign 1 0 214
return 1 0 218
return 1 0 221
assign 1 0 224
assign 1 0 228
return 1 0 232
return 1 0 235
assign 1 0 238
assign 1 0 242
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 210349252: return bem_deserializeClassNameGet_0();
case 290193605: return bem_toString_0();
case -628003973: return bem_classPathGetDirect_0();
case -558028231: return bem_emitPathGetDirect_0();
case 1406929937: return bem_fullEmitNameGetDirect_0();
case -251498323: return bem_nameSpaceGet_0();
case 388851681: return bem_fullEmitNameGet_0();
case 1534778339: return bem_serializeContents_0();
case -1186698663: return bem_libNameGetDirect_0();
case -1902821230: return bem_sourceFileNameGet_0();
case 1476572399: return bem_new_0();
case -306937017: return bem_typeEmitNameGet_0();
case 1057028028: return bem_fieldIteratorGet_0();
case 884246657: return bem_classDirGetDirect_0();
case -2028607558: return bem_emitPathGet_0();
case 1083224906: return bem_emitNameGet_0();
case 28875736: return bem_nameSpaceGetDirect_0();
case 1961529114: return bem_synPathGetDirect_0();
case -1876336609: return bem_synPathGet_0();
case -64119651: return bem_typeEmitNameGetDirect_0();
case 715553388: return bem_serializationIteratorGet_0();
case -1318199347: return bem_emitterGet_0();
case 1528097206: return bem_serializeToString_0();
case 708488762: return bem_create_0();
case -450907329: return bem_iteratorGet_0();
case -354533313: return bem_emitNameGetDirect_0();
case 198473032: return bem_tagGet_0();
case -1853421262: return bem_typePathGet_0();
case 364760594: return bem_npGet_0();
case -1715737113: return bem_emitterGetDirect_0();
case -1915513690: return bem_classNameGet_0();
case 511890203: return bem_typePathGetDirect_0();
case 2128200156: return bem_classPathGet_0();
case 1604055525: return bem_hashGet_0();
case -177367462: return bem_classDirGet_0();
case -1781364078: return bem_print_0();
case -129556018: return bem_fieldNamesGet_0();
case 1631345076: return bem_npGetDirect_0();
case 807844599: return bem_copy_0();
case -436514878: return bem_echo_0();
case 1951525247: return bem_libNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1837174700: return bem_emitPathSetDirect_1(bevd_0);
case -2140305926: return bem_typePathSetDirect_1(bevd_0);
case -1935643818: return bem_npSet_1(bevd_0);
case 1079185382: return bem_emitterSet_1(bevd_0);
case -1673028008: return bem_typeEmitNameSetDirect_1(bevd_0);
case -2116120548: return bem_typePathSet_1(bevd_0);
case 1990894123: return bem_emitterSetDirect_1(bevd_0);
case -2045405219: return bem_nameSpaceSet_1(bevd_0);
case 540741071: return bem_classPathSet_1(bevd_0);
case 1136696118: return bem_synPathSetDirect_1(bevd_0);
case -848749409: return bem_emitNameSetDirect_1(bevd_0);
case -1814609660: return bem_fullEmitNameSet_1(bevd_0);
case 1859153072: return bem_undef_1(bevd_0);
case -567760692: return bem_npSetDirect_1(bevd_0);
case 1034398319: return bem_emitNameSet_1(bevd_0);
case 938863663: return bem_def_1(bevd_0);
case -746609219: return bem_sameObject_1(bevd_0);
case -1649449319: return bem_typeEmitNameSet_1(bevd_0);
case -1680443551: return bem_nameSpaceSetDirect_1(bevd_0);
case -1606202955: return bem_copyTo_1(bevd_0);
case 1342151407: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 260398093: return bem_libNameSetDirect_1(bevd_0);
case -1521329959: return bem_classDirSetDirect_1(bevd_0);
case 698883230: return bem_classDirSet_1(bevd_0);
case -835119407: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1956600113: return bem_libNameSet_1(bevd_0);
case 909428606: return bem_otherClass_1(bevd_0);
case -1542078069: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -999927226: return bem_notEquals_1(bevd_0);
case 1528010380: return bem_sameClass_1(bevd_0);
case -1865008630: return bem_equals_1(bevd_0);
case -15279308: return bem_classPathSetDirect_1(bevd_0);
case 1880525273: return bem_otherType_1(bevd_0);
case 165601234: return bem_fullEmitNameSetDirect_1(bevd_0);
case 917969505: return bem_synPathSet_1(bevd_0);
case -575460023: return bem_sameType_1(bevd_0);
case -1768944168: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 231624435: return bem_emitPathSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 506082618: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1582482490: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1978405023: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953140974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1983033893: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -304233608: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_11_BuildClassConfig();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
