package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x64,0x6F,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6C,0x6F,0x61,0x64,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x63,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_9_3_ContainerSet bevp_emitChecks;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_doMain;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_loadIds;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_ta_ph);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_singleCC = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_doMain = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevp_saveIds = be.BECS_Runtime.boolFalse;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevt_2_ta_ph = beva_name.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 106*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_2));
bevt_4_ta_ph = beva_name.bem_ends_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 106*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 106*/
 else /* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 106*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 107*/
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_ta_ph = beva_arg.bem_swap_2(bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bem_main_1(bevl__args);
bevt_1_ta_ph.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_ta_ph );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_ta_ph = bevp_params.bem_get_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 125*/ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 125*/ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 125*/
 else /* Line: 125*/ {
break;
} /* Line: 125*/
} /* Line: 125*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try /* Line: 134*/ {
bem_config_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 138*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1215577796);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_5_BuildBuild_bels_9));
bevp_buildMessage = bevt_1_ta_ph.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 143*/
if (bevp_printSteps.bevi_bool)/* Line: 145*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 145*/ {
if (bevl_buildFailed.bevi_bool)/* Line: 145*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 145*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 145*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 145*/ {
bevp_buildMessage.bem_print_0();
} /* Line: 146*/
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bevp_platform.bemd_0(980656079);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-1338082599, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 152*/ {
} /* Line: 152*/
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_ec = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_ta_loop = null;
BEC_2_6_6_SystemObject bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_6_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_2_4_IOFile bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_2_4_IOFile bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_108_ta_ph = null;
BEC_2_4_6_TextString bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_9_4_ContainerList bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_5_4_LogicBool bevt_127_ta_ph = null;
BEC_2_9_4_ContainerList bevt_128_ta_ph = null;
BEC_2_9_4_ContainerList bevt_129_ta_ph = null;
BEC_2_6_6_SystemObject bevt_130_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_5_4_LogicBool bevt_133_ta_ph = null;
BEC_2_2_4_IOFile bevt_134_ta_ph = null;
BEC_2_2_4_IOFile bevt_135_ta_ph = null;
BEC_2_5_4_LogicBool bevt_136_ta_ph = null;
BEC_2_2_4_IOFile bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_6_ta_ph = bevp_params.bem_get_1(bevl_bkey);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 162*/ {
bevt_7_ta_ph = bevp_params.bem_get_1(bevl_bkey);
bevt_0_ta_loop = bevt_7_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 163*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 163*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(188383538);
bevt_10_ta_ph = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_10_ta_ph.bevi_bool) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 164*/ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_11_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_11_ta_ph);
} /* Line: 166*/
} /* Line: 164*/
 else /* Line: 163*/ {
break;
} /* Line: 163*/
} /* Line: 163*/
} /* Line: 163*/
bevt_14_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_nameGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_12_ta_ph = bevt_13_ta_ph.bem_equals_1(bevt_15_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 171*/ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 172*/
bevt_17_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_12));
bevt_16_ta_ph = bevp_params.bem_get_1(bevt_17_ta_ph);
bevp_libName = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_firstGet_0();
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_18_ta_ph = bevp_params.bem_has_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 175*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_20_ta_ph = bevp_params.bem_get_1(bevt_21_ta_ph);
bevp_exeName = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_firstGet_0();
} /* Line: 176*/
 else /* Line: 177*/ {
bevp_exeName = bevp_libName;
} /* Line: 178*/
bevt_25_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_26_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_24_ta_ph = bevp_params.bem_get_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_firstGet_0();
bevt_22_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_23_ta_ph);
bevp_buildPath = bevt_22_ta_ph.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevp_buildPath.bem_addStep_1(bevt_27_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_32_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_30_ta_ph = bevp_params.bem_get_2(bevt_31_ta_ph, bevt_32_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bem_firstGet_0();
bevt_28_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_29_ta_ph);
bevp_includePath = bevt_28_ta_ph.bem_pathGet_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_18));
bevt_37_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_nameGet_0();
bevt_34_ta_ph = bevp_params.bem_get_2(bevt_35_ta_ph, bevt_36_ta_ph);
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_33_ta_ph );
bevt_40_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_41_ta_ph = bevp_platform.bemd_0(980656079);
bevt_39_ta_ph = bevp_params.bem_get_2(bevt_40_ta_ph, (BEC_2_4_6_TextString) bevt_41_ta_ph );
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_38_ta_ph );
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_43_ta_ph = bevp_params.bem_get_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_42_ta_ph = bevt_43_ta_ph.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_42_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_49_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_47_ta_ph = bevp_params.bem_get_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_46_ta_ph = bevt_47_ta_ph.bem_firstGet_0();
bevp_doMain = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_46_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_53_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_51_ta_ph = bevp_params.bem_get_2(bevt_52_ta_ph, bevt_53_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_50_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_57_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_55_ta_ph = bevp_params.bem_get_2(bevt_56_ta_ph, bevt_57_ta_ph);
bevt_54_ta_ph = bevt_55_ta_ph.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_54_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_26));
bevp_loadSyns = bevp_params.bem_get_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevp_loadIds = bevp_params.bem_get_1(bevt_59_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_28));
bevp_initLibs = bevp_params.bem_get_1(bevt_60_ta_ph);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_29));
bevt_61_ta_ph = bevp_params.bem_get_1(bevt_62_ta_ph);
bevp_mainName = (BEC_2_4_6_TextString) bevt_61_ta_ph.bem_firstGet_0();
bevt_64_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_30));
bevt_63_ta_ph = bevp_params.bem_get_1(bevt_64_ta_ph);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_firstGet_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_65_ta_ph);
if (bevp_usedLibrarysStr == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 197*/ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 198*/
bevt_67_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_67_ta_ph);
if (bevp_closeLibrariesStr == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 201*/ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 202*/
bevt_69_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_69_ta_ph);
if (bevp_deployFilesFrom == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 205*/ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 206*/
bevt_71_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_71_ta_ph);
if (bevp_deployFilesTo == null) {
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_72_ta_ph.bevi_bool)/* Line: 209*/ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 210*/
bevt_73_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_73_ta_ph);
if (bevp_extIncludes == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 213*/ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 214*/
bevt_75_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_75_ta_ph);
if (bevp_ccObjArgs == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 217*/ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 218*/
bevt_77_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_77_ta_ph);
if (bevp_extLibs == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 221*/ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 222*/
bevt_79_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_79_ta_ph);
if (bevp_linkLibArgs == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 225*/ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 226*/
bevt_81_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_81_ta_ph);
if (bevp_extLinkObjects == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 229*/ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 230*/
bevt_83_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_83_ta_ph);
if (bevp_emitFileHeader == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 233*/ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(1814177547);
} /* Line: 234*/
bevt_85_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_85_ta_ph);
if (bevp_runArgs == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 237*/ {
bevp_runArgs = bevp_runArgs.bemd_0(1814177547);
} /* Line: 238*/
 else /* Line: 239*/ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 240*/
bevt_87_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_42));
bevt_88_ta_ph = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_87_ta_ph, bevt_88_ta_ph);
bevt_89_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_89_ta_ph, bevt_90_ta_ph);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_92_ta_ph);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_93_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_93_ta_ph);
if (bevl_pacm == null) {
bevt_94_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_94_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_96_ta_ph = bevl_pacm.bem_isEmptyGet_0();
if (bevt_96_ta_ph.bevi_bool) {
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 248*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 248*/
 else /* Line: 248*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 248*/ {
bevt_1_ta_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
/* Line: 249*/ {
bevt_97_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 249*/ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 250*/
 else /* Line: 249*/ {
break;
} /* Line: 249*/
} /* Line: 249*/
} /* Line: 249*/
bevt_98_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_98_ta_ph);
bevt_99_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_100_ta_ph);
bevt_101_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_101_ta_ph);
bevt_102_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_51));
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_102_ta_ph, bevt_103_ta_ph);
bevt_104_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_emitLangs = bevp_params.bem_get_1(bevt_104_ta_ph);
bevt_105_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevp_emitFlags = bevp_params.bem_get_1(bevt_105_ta_ph);
bevp_emitChecks = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (bevp_emitFlags == null) {
bevt_106_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_106_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_106_ta_ph.bevi_bool)/* Line: 261*/ {
bevt_2_ta_loop = bevp_emitFlags.bem_linkedListIteratorGet_0();
while (true)
/* Line: 262*/ {
bevt_107_ta_ph = bevt_2_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 262*/ {
bevl_ec = (BEC_2_4_6_TextString) bevt_2_ta_loop.bem_nextGet_0();
bevp_emitChecks.bem_addValue_1(bevl_ec);
} /* Line: 264*/
 else /* Line: 262*/ {
break;
} /* Line: 262*/
} /* Line: 262*/
} /* Line: 262*/
bevt_109_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_110_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_108_ta_ph = bevp_params.bem_get_2(bevt_109_ta_ph, bevt_110_ta_ph);
bevp_compiler = (BEC_2_4_6_TextString) bevt_108_ta_ph.bem_firstGet_0();
bevt_112_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_113_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_111_ta_ph = bevp_params.bem_get_2(bevt_112_ta_ph, bevt_113_ta_ph);
bevp_makeName = (BEC_2_4_6_TextString) bevt_111_ta_ph.bem_firstGet_0();
bevt_116_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_115_ta_ph = bevt_116_ta_ph.bem_add_1(bevp_makeName);
bevt_117_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_114_ta_ph = bevp_params.bem_get_2(bevt_115_ta_ph, bevt_117_ta_ph);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_114_ta_ph.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 277*/ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 278*/
 else /* Line: 279*/ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_59));
} /* Line: 280*/
bevt_121_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_60));
bevt_120_ta_ph = bevl_outLang.bem_add_1(bevt_121_ta_ph);
bevt_122_ta_ph = bevp_platform.bemd_0(980656079);
bevt_119_ta_ph = bevt_120_ta_ph.bem_add_1(bevt_122_ta_ph);
bevl_platformSources = bevp_params.bem_get_1(bevt_119_ta_ph);
if (bevl_platformSources == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 288*/ {
bevt_124_ta_ph = bevp_params.bem_orderedGet_0();
bevt_124_ta_ph.bem_addAll_1(bevl_platformSources);
} /* Line: 289*/
bevt_126_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_125_ta_ph = bevl_outLang.bem_add_1(bevt_126_ta_ph);
bevl_langSources = bevp_params.bem_get_1(bevt_125_ta_ph);
if (bevl_langSources == null) {
bevt_127_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_127_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_128_ta_ph = bevp_params.bem_orderedGet_0();
bevt_128_ta_ph.bem_addAll_1(bevl_langSources);
} /* Line: 294*/
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_129_ta_ph = bevp_params.bem_orderedGet_0();
bevt_3_ta_loop = bevt_129_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 298*/ {
bevt_130_ta_ph = bevt_3_ta_loop.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_130_ta_ph).bevi_bool)/* Line: 298*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_3_ta_loop.bemd_0(188383538);
bevt_131_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_131_ta_ph);
} /* Line: 299*/
 else /* Line: 298*/ {
break;
} /* Line: 298*/
} /* Line: 298*/
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-1589924343);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_134_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_133_ta_ph = bevt_134_ta_ph.bem_existsGet_0();
if (bevt_133_ta_ph.bevi_bool) {
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_135_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_135_ta_ph.bem_makeDirs_0();
} /* Line: 307*/
if (bevp_emitFileHeader == null) {
bevt_136_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_136_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_136_ta_ph.bevi_bool)/* Line: 309*/ {
bevt_137_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_137_ta_ph.bem_readerGet_0();
bevt_138_ta_ph = bevl_emr.bemd_0(351923736);
bevp_emitFileHeader = bevt_138_ta_ph.bemd_0(854913103);
bevl_emr.bemd_0(-792133517);
} /* Line: 312*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_7_SystemClasses bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_toRet = bevt_0_ta_ph.bem_className_1(this);
bevt_2_ta_ph = bevl_toRet.bemd_1(-232318351, bevp_nl);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_62));
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(-232318351, bevt_3_ta_ph);
bevt_4_ta_ph = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_1_ta_ph.bemd_1(-232318351, bevt_4_ta_ph);
bevt_6_ta_ph = bevl_toRet.bemd_1(-232318351, bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_63));
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(-232318351, bevt_7_ta_ph);
bevt_8_ta_ph = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_5_ta_ph.bemd_1(-232318351, bevt_8_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 325*/ {
bevt_3_ta_ph = bevl_ci.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 325*/ {
bevl_clnode = bevl_ci.bemd_0(188383538);
bevt_5_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_ta_ph = bevl_clnode.bemd_0(432682471);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(63408817);
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 327*/ {
bevt_10_ta_ph = bevl_clnode.bemd_0(432682471);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1330323692);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1215577796);
bevl_toEmit.bem_put_1(bevt_8_ta_ph);
bevt_11_ta_ph = bevp_emitData.bem_usedByGet_0();
bevt_14_ta_ph = bevl_clnode.bemd_0(432682471);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(-1330323692);
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(1215577796);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_ta_ph.bem_get_1(bevt_12_ta_ph);
if (bevl_usedBy == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_0_ta_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
/* Line: 331*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 331*/ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 332*/
 else /* Line: 331*/ {
break;
} /* Line: 331*/
} /* Line: 331*/
} /* Line: 331*/
bevt_17_ta_ph = bevp_emitData.bem_subClassesGet_0();
bevt_20_ta_ph = bevl_clnode.bemd_0(432682471);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-1330323692);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1215577796);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_ta_ph.bem_get_1(bevt_18_ta_ph);
if (bevl_subClasses == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_1_ta_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
/* Line: 337*/ {
bevt_22_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 337*/ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 338*/
 else /* Line: 337*/ {
break;
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 336*/
} /* Line: 327*/
 else /* Line: 325*/ {
break;
} /* Line: 325*/
} /* Line: 325*/
bevt_23_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 343*/ {
bevt_24_ta_ph = bevl_ci.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 343*/ {
bevl_clnode = bevl_ci.bemd_0(188383538);
bevt_25_ta_ph = bevl_clnode.bemd_0(432682471);
bevt_29_ta_ph = bevl_clnode.bemd_0(432682471);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-1330323692);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(1215577796);
bevt_26_ta_ph = bevl_toEmit.bem_has_1(bevt_27_ta_ph);
bevt_25_ta_ph.bemd_1(1628214011, bevt_26_ta_ph);
} /* Line: 345*/
 else /* Line: 343*/ {
break;
} /* Line: 343*/
} /* Line: 343*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_9_SystemException bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (bevp_emitCommon == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 356*/ {
return bevp_emitCommon;
} /* Line: 357*/
if (bevp_emitLangs == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 362*/ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_64));
bevt_2_ta_ph = bevl_emitLang.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 364*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 365*/
 else /* Line: 364*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_4_ta_ph = bevl_emitLang.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 366*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 367*/
 else /* Line: 364*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_6_ta_ph = bevl_emitLang.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 368*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 369*/
 else /* Line: 364*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_67));
bevt_8_ta_ph = bevl_emitLang.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 370*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 371*/
 else /* Line: 372*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_68));
bevt_10_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_ta_ph);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 373*/
} /* Line: 364*/
} /* Line: 364*/
} /* Line: 364*/
return bevp_emitCommon;
} /* Line: 375*/
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_2_6_10_SystemSerializer bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_7_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_69));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_lsp);
bevt_0_ta_ph.bem_print_0();
bevt_2_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_ta_ph.bem_now_0();
bevt_4_ta_ph = bevl_synEmitPath.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_ta_ph.bemd_0(351923736);
bevt_5_ta_ph = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_ta_ph.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevt_6_ta_ph.bem_addValue_1(bevl_scls);
bevt_8_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_now_0();
bevl_sse = bevt_7_ta_ph.bem_subtract_1(bevl_sst);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_sse);
bevt_9_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_22_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_25_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_26_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_27_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_28_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_29_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_30_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_43_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_82_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_3_MathInt bevt_98_ta_ph = null;
bevt_5_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_ta_ph.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 398*/ {
bevt_0_ta_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
/* Line: 399*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 399*/ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 400*/
 else /* Line: 399*/ {
break;
} /* Line: 399*/
} /* Line: 399*/
} /* Line: 399*/
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 404*/ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool)/* Line: 407*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_libName);
bevt_9_ta_ph.bem_print_0();
} /* Line: 408*/
} /* Line: 407*/
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_ta_loop = bevp_usedLibrarysStr.bemd_0(1765703420);
while (true)
/* Line: 413*/ {
bevt_11_ta_ph = bevt_1_ta_loop.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 413*/ {
bevl_ups = bevt_1_ta_loop.bemd_0(188383538);
bevt_13_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 414*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 417*/
} /* Line: 414*/
 else /* Line: 413*/ {
break;
} /* Line: 413*/
} /* Line: 413*/
bevt_2_ta_loop = bevp_closeLibrariesStr.bemd_0(1765703420);
while (true)
/* Line: 420*/ {
bevt_14_ta_ph = bevt_2_ta_loop.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 420*/ {
bevl_ups = bevt_2_ta_loop.bemd_0(188383538);
bevt_16_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_ta_ph.bevi_bool) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 421*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_ta_ph = bevl_pack.bemd_0(-475647431);
bevp_closeLibraries.bem_put_1(bevt_17_ta_ph);
} /* Line: 425*/
} /* Line: 421*/
 else /* Line: 420*/ {
break;
} /* Line: 420*/
} /* Line: 420*/
if (bevp_parse.bevi_bool)/* Line: 428*/ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
/* Line: 431*/ {
bevt_18_ta_ph = bevl_i.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 431*/ {
bevl_tb = bevl_i.bemd_0(188383538);
bevt_20_ta_ph = bevl_tb.bemd_0(1215577796);
bevt_19_ta_ph = bevl_built.bem_has_1(bevt_20_ta_ph);
if (!(bevt_19_ta_ph.bevi_bool))/* Line: 434*/ {
bevt_21_ta_ph = bevl_tb.bemd_0(1215577796);
bevl_built.bem_put_1(bevt_21_ta_ph);
bem_doParse_1(bevl_tb);
} /* Line: 436*/
} /* Line: 434*/
 else /* Line: 431*/ {
break;
} /* Line: 431*/
} /* Line: 431*/
bem_buildSyns_1(bevl_em);
} /* Line: 439*/
bevt_23_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_now_0();
bevp_parseTime = bevt_22_ta_ph.bem_subtract_1(bevp_startTime);
bevt_25_ta_ph = bem_emitCommonGet_0();
if (bevt_25_ta_ph == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 445*/ {
bevt_26_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_ta_ph.bem_now_0();
bevt_27_ta_ph = bem_emitCommonGet_0();
bevt_27_ta_ph.bem_doEmit_0();
bevt_29_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_28_ta_ph.bem_subtract_1(bevp_startTime);
bevt_31_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_now_0();
bevl_emitTime = bevt_30_ta_ph.bem_subtract_1(bevl_emitStart);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevp_parseTime);
bevt_32_ta_ph.bem_print_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_5_BuildBuild_bels_73));
bevt_34_ta_ph = bevt_35_ta_ph.bem_add_1(bevl_emitTime);
bevt_34_ta_ph.bem_print_0();
bevt_37_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_36_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_38_ta_ph;
} /* Line: 454*/
if (bevp_doEmit.bevi_bool)/* Line: 456*/ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-1135285621);
bevt_39_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 460*/ {
bevt_40_ta_ph = bevl_ci.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 460*/ {
bevl_clnode = bevl_ci.bemd_0(188383538);
bevl_em.bemd_1(-115165926, bevl_clnode);
} /* Line: 462*/
 else /* Line: 460*/ {
break;
} /* Line: 460*/
} /* Line: 460*/
bevl_em.bemd_0(209782761);
bevl_em.bemd_0(-1452253549);
bevt_41_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 466*/ {
bevt_42_ta_ph = bevl_ci.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 466*/ {
bevl_clnode = bevl_ci.bemd_0(188383538);
bevl_em.bemd_1(1479207550, bevl_clnode);
} /* Line: 468*/
 else /* Line: 466*/ {
break;
} /* Line: 466*/
} /* Line: 466*/
} /* Line: 466*/
bevt_44_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_ta_ph = bevt_44_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_43_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 473*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_46_ta_ph = bevt_47_ta_ph.bem_add_1(bevp_parseTime);
bevt_46_ta_ph.bem_print_0();
} /* Line: 474*/
bevt_49_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_48_ta_ph.bem_print_0();
if (bevp_prepMake.bevi_bool)/* Line: 477*/ {
bevl_em.bemd_1(-770023349, bevp_deployLibrary);
} /* Line: 479*/
if (bevp_make.bevi_bool)/* Line: 482*/ {
if (bevp_genOnly.bevi_bool) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 483*/ {
bevl_em.bemd_1(-1064863292, bevp_deployLibrary);
bevl_em.bemd_1(2114975524, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool)/* Line: 486*/ {
bevt_3_ta_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
/* Line: 487*/ {
bevt_51_ta_ph = bevt_3_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 487*/ {
bevl_bp = bevt_3_ta_loop.bem_nextGet_0();
bevt_52_ta_ph = bevl_bp.bemd_0(-1135285621);
bevl_cpFrom = bevt_52_ta_ph.bemd_0(-1428466090);
bevt_53_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_ta_ph.bem_copy_0();
bevt_55_ta_ph = bevl_cpFrom.bemd_0(-2142432313);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(1671200598);
bevl_cpTo.bemd_1(67962782, bevt_54_ta_ph);
bevt_57_ta_ph = bevl_cpTo.bemd_0(-666075389);
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(1832073796);
if (((BEC_2_5_4_LogicBool) bevt_56_ta_ph).bevi_bool)/* Line: 491*/ {
bevt_58_ta_ph = bevl_cpTo.bemd_0(-666075389);
bevt_58_ta_ph.bemd_0(-32714580);
} /* Line: 492*/
bevt_61_ta_ph = bevl_cpTo.bemd_0(-666075389);
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(1832073796);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(2020761406);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 494*/ {
bevt_62_ta_ph = bevl_cpFrom.bemd_0(-666075389);
bevt_63_ta_ph = bevl_cpTo.bemd_0(-666075389);
bevl_em.bemd_2(-1591366383, bevt_62_ta_ph, bevt_63_ta_ph);
} /* Line: 495*/
} /* Line: 494*/
 else /* Line: 487*/ {
break;
} /* Line: 487*/
} /* Line: 487*/
} /* Line: 487*/
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
/* Line: 502*/ {
bevt_64_ta_ph = bevl_fIter.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 502*/ {
bevt_65_ta_ph = bevl_tIter.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_65_ta_ph).bevi_bool)/* Line: 502*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 502*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 502*/
 else /* Line: 502*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 502*/ {
bevt_66_ta_ph = bevl_fIter.bemd_0(188383538);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_ta_ph );
bevt_71_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_ta_ph = bevt_71_ta_ph.bem_copy_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_toString_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_68_ta_ph = bevt_69_ta_ph.bem_add_1(bevt_72_ta_ph);
bevt_73_ta_ph = bevl_tIter.bemd_0(188383538);
bevt_67_ta_ph = bevt_68_ta_ph.bem_add_1(bevt_73_ta_ph);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_ta_ph);
bevt_75_ta_ph = bevl_cpTo.bemd_0(-666075389);
bevt_74_ta_ph = bevt_75_ta_ph.bemd_0(1832073796);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 506*/ {
bevt_76_ta_ph = bevl_cpTo.bemd_0(-666075389);
bevt_76_ta_ph.bemd_0(-32714580);
} /* Line: 507*/
bevt_79_ta_ph = bevl_cpTo.bemd_0(-666075389);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(1832073796);
bevt_77_ta_ph = bevt_78_ta_ph.bemd_0(2020761406);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 509*/ {
bevt_80_ta_ph = bevl_cpFrom.bemd_0(-666075389);
bevt_81_ta_ph = bevl_cpTo.bemd_0(-666075389);
bevl_em.bemd_2(-1591366383, bevt_80_ta_ph, bevt_81_ta_ph);
} /* Line: 510*/
} /* Line: 509*/
 else /* Line: 502*/ {
break;
} /* Line: 502*/
} /* Line: 502*/
} /* Line: 502*/
} /* Line: 483*/
bevt_83_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_ta_ph = bevt_83_ta_ph.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 517*/ {
bevt_86_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_85_ta_ph = bevt_86_ta_ph.bem_add_1(bevp_parseTime);
bevt_85_ta_ph.bem_print_0();
} /* Line: 518*/
if (bevp_parseEmitTime == null) {
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 520*/ {
bevt_89_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_88_ta_ph = bevt_89_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_88_ta_ph.bem_print_0();
} /* Line: 521*/
if (bevp_parseEmitCompileTime == null) {
bevt_90_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_90_ta_ph.bevi_bool)/* Line: 523*/ {
bevt_92_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_5_BuildBuild_bels_75));
bevt_91_ta_ph = bevt_92_ta_ph.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_ta_ph.bem_print_0();
} /* Line: 524*/
if (bevp_run.bevi_bool)/* Line: 527*/ {
bevt_93_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_76));
bevt_93_ta_ph.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(-2070437180, bevp_deployLibrary, bevp_runArgs);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_77));
bevt_95_ta_ph = bevt_96_ta_ph.bem_add_1(bevl_result);
bevt_97_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_78));
bevt_94_ta_ph = bevt_95_ta_ph.bem_add_1(bevt_97_ta_ph);
bevt_94_ta_ph.bem_print_0();
return bevl_result;
} /* Line: 531*/
bevt_98_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_98_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 537*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 537*/ {
bevl_kls = bevl_ci.bemd_0(188383538);
bevt_2_ta_ph = bevl_kls.bemd_0(432682471);
bevt_2_ta_ph.bemd_1(1544476916, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1544476916, bevp_libName);
} /* Line: 541*/
 else /* Line: 537*/ {
break;
} /* Line: 537*/
} /* Line: 537*/
bevt_3_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 543*/ {
bevt_4_ta_ph = bevl_ci.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 543*/ {
bevl_kls = bevl_ci.bemd_0(188383538);
bevt_5_ta_ph = bevl_kls.bemd_0(432682471);
bevl_syn = bevt_5_ta_ph.bemd_0(-1202049855);
bevl_syn.bemd_2(-279308237, this, bevl_kls);
bevl_syn.bemd_1(1395022766, this);
} /* Line: 547*/
 else /* Line: 543*/ {
break;
} /* Line: 543*/
} /* Line: 543*/
bevt_6_ta_ph = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
bevt_2_ta_ph = beva_klass.bemd_0(432682471);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1202049855);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 553*/ {
bevt_4_ta_ph = beva_klass.bemd_0(432682471);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-1202049855);
return bevt_3_ta_ph;
} /* Line: 554*/
bevt_5_ta_ph = beva_klass.bemd_0(432682471);
bevt_5_ta_ph.bemd_1(1544476916, bevp_libName);
bevt_8_ta_ph = beva_klass.bemd_0(432682471);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-774251339);
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 557*/ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 558*/
 else /* Line: 559*/ {
bevt_9_ta_ph = bevp_emitData.bem_classesGet_0();
bevt_12_ta_ph = beva_klass.bemd_0(432682471);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-774251339);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(1215577796);
bevl_pklass = bevt_9_ta_ph.bem_get_1(bevt_10_ta_ph);
if (bevl_pklass == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 562*/ {
bevt_14_ta_ph = bevl_pklass.bemd_0(432682471);
bevt_14_ta_ph.bemd_1(1544476916, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 564*/
 else /* Line: 565*/ {
bevt_16_ta_ph = beva_klass.bemd_0(432682471);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-774251339);
bevl_psyn = bem_getSynNp_1(bevt_15_ta_ph);
} /* Line: 568*/
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 570*/
bevt_17_ta_ph = beva_klass.bemd_0(432682471);
bevt_17_ta_ph.bemd_1(996071751, bevl_syn);
bevt_20_ta_ph = beva_klass.bemd_0(432682471);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-1330323692);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1215577796);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_ta_ph , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_nps = beva_np.bemd_0(1215577796);
bevt_0_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_ta_ph.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 580*/ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 581*/
bevt_2_ta_ph = bem_emitterGet_0();
bevl_syn = bevt_2_ta_ph.bemd_1(2011740014, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_sharedEmitter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 596*/ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 597*/
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_ta_ph.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool)/* Line: 610*/ {
if (bevp_printSteps.bevi_bool)/* Line: 611*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 611*/ {
if (bevp_printPlaces.bevi_bool)/* Line: 611*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 611*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 611*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 611*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_79));
bevt_5_ta_ph = beva_toParse.bemd_0(1215577796);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_3_ta_ph.bem_print_0();
} /* Line: 612*/
bevp_fromFile = beva_toParse;
bevt_8_ta_ph = beva_toParse.bemd_0(-666075389);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-895452537);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(351923736);
bevl_src = bevt_6_ta_ph.bemd_1(783511079, bevp_readBuffer);
bevt_10_ta_ph = beva_toParse.bemd_0(-666075389);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-895452537);
bevt_9_ta_ph.bemd_0(-792133517);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool)/* Line: 623*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_80));
bevt_11_ta_ph.bem_output_0();
} /* Line: 624*/
bevt_12_ta_ph = bevl_trans.bemd_0(807888883);
bem_nodify_2(bevt_12_ta_ph, bevl_toks);
if (bevp_printAllAst.bevi_bool)/* Line: 627*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_5_BuildBuild_bels_81));
bevt_13_ta_ph.bem_print_0();
bevt_14_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_14_ta_ph);
} /* Line: 629*/
if (bevp_printSteps.bevi_bool)/* Line: 632*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_82));
bevt_15_ta_ph.bem_output_0();
} /* Line: 633*/
bevt_16_ta_ph = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-759414861, bevt_16_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 636*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_83));
bevt_17_ta_ph.bem_print_0();
bevt_18_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_18_ta_ph);
} /* Line: 638*/
if (bevp_printSteps.bevi_bool)/* Line: 640*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_84));
bevt_19_ta_ph.bem_output_0();
} /* Line: 641*/
bevt_20_ta_ph = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-759414861, bevt_20_ta_ph);
bevl_trans.bemd_0(1137044991);
if (bevp_printAllAst.bevi_bool)/* Line: 646*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_85));
bevt_21_ta_ph.bem_print_0();
bevt_22_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_22_ta_ph);
} /* Line: 648*/
if (bevp_printSteps.bevi_bool)/* Line: 651*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_86));
bevt_23_ta_ph.bem_output_0();
} /* Line: 652*/
bevt_24_ta_ph = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-759414861, bevt_24_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 655*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_87));
bevt_25_ta_ph.bem_print_0();
bevt_26_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_26_ta_ph);
} /* Line: 657*/
if (bevp_printSteps.bevi_bool)/* Line: 660*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_88));
bevt_27_ta_ph.bem_output_0();
} /* Line: 661*/
bevt_28_ta_ph = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-759414861, bevt_28_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 664*/ {
bevt_29_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_89));
bevt_29_ta_ph.bem_print_0();
bevt_30_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_30_ta_ph);
} /* Line: 666*/
if (bevp_printSteps.bevi_bool)/* Line: 669*/ {
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_90));
bevt_31_ta_ph.bem_output_0();
} /* Line: 670*/
bevt_32_ta_ph = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-759414861, bevt_32_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 673*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_91));
bevt_33_ta_ph.bem_print_0();
bevt_34_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_34_ta_ph);
} /* Line: 675*/
if (bevp_printSteps.bevi_bool)/* Line: 678*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_92));
bevt_35_ta_ph.bem_output_0();
} /* Line: 679*/
bevt_36_ta_ph = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-759414861, bevt_36_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 682*/ {
bevt_37_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_93));
bevt_37_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_38_ta_ph);
} /* Line: 684*/
if (bevp_printSteps.bevi_bool)/* Line: 687*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_94));
bevt_39_ta_ph.bem_output_0();
} /* Line: 688*/
bevt_40_ta_ph = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-759414861, bevt_40_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 691*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_95));
bevt_41_ta_ph.bem_print_0();
bevt_42_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_42_ta_ph);
} /* Line: 693*/
if (bevp_printSteps.bevi_bool)/* Line: 696*/ {
bevt_43_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_96));
bevt_43_ta_ph.bem_output_0();
} /* Line: 697*/
bevt_44_ta_ph = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-759414861, bevt_44_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 700*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_97));
bevt_45_ta_ph.bem_print_0();
bevt_46_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_46_ta_ph);
} /* Line: 702*/
if (bevp_printSteps.bevi_bool)/* Line: 705*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_98));
bevt_47_ta_ph.bem_output_0();
} /* Line: 706*/
bevt_48_ta_ph = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-759414861, bevt_48_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 709*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_99));
bevt_49_ta_ph.bem_print_0();
bevt_50_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_50_ta_ph);
} /* Line: 711*/
if (bevp_printSteps.bevi_bool)/* Line: 713*/ {
bevt_51_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_100));
bevt_51_ta_ph.bem_output_0();
} /* Line: 714*/
bevt_52_ta_ph = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-759414861, bevt_52_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 717*/ {
bevt_53_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_101));
bevt_53_ta_ph.bem_print_0();
bevt_54_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_54_ta_ph);
} /* Line: 719*/
if (bevp_printSteps.bevi_bool)/* Line: 722*/ {
bevt_55_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_102));
bevt_55_ta_ph.bem_output_0();
bevt_56_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_103));
bevt_56_ta_ph.bem_print_0();
} /* Line: 724*/
bevt_57_ta_ph = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-759414861, bevt_57_ta_ph);
if (bevp_printAst.bevi_bool)/* Line: 727*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 727*/ {
if (bevp_printAllAst.bevi_bool)/* Line: 727*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 727*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 727*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 727*/ {
bevt_58_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_104));
bevt_58_ta_ph.bem_print_0();
bevt_59_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-759414861, bevt_59_ta_ph);
} /* Line: 729*/
bevt_60_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 731*/ {
bevt_61_ta_ph = bevl_ci.bemd_0(1290413940);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 731*/ {
bevl_clnode = bevl_ci.bemd_0(188383538);
bevl_tunode = bevl_clnode.bemd_0(1260640045);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(1607070701, bevt_62_ta_ph);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_ta_ph = bevl_tunode.bemd_0(432682471);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(1958508869);
bevl_ntt.bemd_1(975856447, bevt_63_ta_ph);
bevl_ntunode.bemd_1(633297178, bevl_ntt);
bevl_clnode.bemd_0(1766234144);
bevl_ntunode.bemd_1(-1741074284, bevl_clnode);
bevl_ntunode.bemd_1(-59976346, bevl_clnode);
} /* Line: 742*/
 else /* Line: 731*/ {
break;
} /* Line: 731*/
} /* Line: 731*/
} /* Line: 731*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
beva_parnode.bemd_0(1899307873);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(896775241);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_ta_ph.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 752*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 752*/ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_ta_ph = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(633297178, bevt_2_ta_ph);
bevt_3_ta_ph = bevl_nlc.bem_copy_0();
bevl_node.bemd_1(-1403580988, bevt_3_ta_ph);
bevt_5_ta_ph = bevl_node.bemd_0(432682471);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(-1338082599, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 756*/ {
bevl_nlc.bevi_int++;
} /* Line: 757*/
bevt_7_ta_ph = bevl_node.bemd_0(432682471);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(-949091010, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 759*/ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(1655172543, beva_parnode);
} /* Line: 761*/
} /* Line: 759*/
 else /* Line: 752*/ {
break;
} /* Line: 752*/
} /* Line: 752*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(400371416, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(1607070701, bevt_5_ta_ph);
bevl_nlnpn.bemd_1(633297178, bevl_nlnp);
bevl_nlnpn.bemd_1(-59976346, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevl_nlc.bemd_1(1637997403, bevt_6_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(462482714, bevt_7_ta_ph);
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1155059186, bevt_8_ta_ph);
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1319863444, bevt_9_ta_ph);
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1569883686, bevt_10_ta_ph);
bevt_11_ta_ph = beva_node.bemd_0(432682471);
bevl_nlc.bemd_1(409179514, bevt_11_ta_ph);
beva_node.bemd_1(-1741074284, bevl_nlnpn);
bevt_12_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(1607070701, bevt_12_ta_ph);
beva_node.bemd_1(633297178, bevl_nlc);
bevl_nlnpn.bemd_0(1683945046);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_105));
bevt_13_ta_ph = beva_tName.bemd_1(-1338082599, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 791*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_106));
bevt_15_ta_ph = beva_tName.bemd_1(-1338082599, bevt_16_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 791*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 791*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 791*/ {
bevl_pn = beva_node.bemd_0(835389283);
if (bevl_pn == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 793*/ {
bevt_19_ta_ph = bevl_pn.bemd_0(-792720728);
bevt_20_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-1338082599, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_22_ta_ph = bevl_pn.bemd_0(-792720728);
bevt_23_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(-1338082599, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 793*/ {
bevl_pn2 = bevl_pn.bemd_0(835389283);
if (bevl_pn2 == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 795*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 795*/ {
bevt_26_ta_ph = bevl_pn2.bemd_0(-792720728);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(-949091010, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 795*/ {
bevt_29_ta_ph = bevl_pn2.bemd_0(-792720728);
bevt_30_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(-949091010, bevt_30_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 795*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 795*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 795*/
 else /* Line: 795*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 795*/ {
bevt_32_ta_ph = bevl_pn2.bemd_0(-792720728);
bevt_33_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bemd_1(-949091010, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_31_ta_ph).bevi_bool)/* Line: 795*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 795*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 795*/
 else /* Line: 795*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 795*/ {
bevt_35_ta_ph = bevl_pn2.bemd_0(-792720728);
bevt_36_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(-949091010, bevt_36_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 795*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 795*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 795*/
 else /* Line: 795*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 795*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 795*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 795*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 795*/ {
bevt_38_ta_ph = bevl_pn.bemd_0(432682471);
bevt_39_ta_ph = bevl_nlc.bemd_0(-183975662);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(-232318351, bevt_39_ta_ph);
bevl_nlc.bemd_1(409179514, bevt_37_ta_ph);
bevl_pn.bemd_0(1766234144);
} /* Line: 802*/
} /* Line: 795*/
} /* Line: 793*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_platform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_outputPlatform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLibrary = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runArgs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_includePath = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_code = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGet_0() throws Throwable {
return bevp_emitChecks;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doMainGet_0() throws Throwable {
return bevp_doMain;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doMainSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doMain = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadIdsGet_0() throws Throwable {
return bevp_loadIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loadIds = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {56, 58, 59, 60, 61, 63, 64, 65, 66, 67, 68, 69, 73, 75, 76, 77, 78, 78, 81, 84, 85, 86, 93, 94, 95, 96, 97, 98, 98, 106, 106, 106, 106, 0, 106, 106, 0, 0, 0, 0, 0, 107, 107, 109, 109, 113, 113, 113, 113, 117, 117, 118, 118, 118, 122, 123, 124, 124, 124, 124, 124, 125, 125, 125, 126, 125, 128, 132, 133, 135, 136, 137, 138, 140, 141, 142, 142, 143, 0, 0, 0, 146, 148, 152, 152, 152, 154, 159, 161, 162, 162, 162, 163, 163, 0, 163, 163, 164, 164, 164, 165, 166, 166, 171, 171, 171, 171, 172, 174, 174, 174, 175, 175, 176, 176, 176, 178, 180, 180, 180, 180, 180, 180, 181, 182, 182, 183, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 184, 185, 185, 185, 185, 185, 186, 186, 186, 186, 186, 187, 187, 187, 187, 187, 188, 188, 188, 188, 188, 189, 189, 189, 189, 189, 190, 190, 191, 191, 192, 192, 194, 194, 194, 195, 195, 195, 196, 196, 197, 197, 198, 200, 200, 201, 201, 202, 204, 204, 205, 205, 206, 208, 208, 209, 209, 210, 212, 212, 213, 213, 214, 216, 216, 217, 217, 218, 220, 220, 221, 221, 222, 224, 224, 225, 225, 226, 228, 228, 229, 229, 230, 232, 232, 233, 233, 234, 236, 236, 237, 237, 238, 240, 242, 242, 242, 243, 243, 243, 244, 244, 245, 245, 246, 247, 247, 248, 248, 248, 248, 248, 0, 0, 0, 249, 0, 249, 249, 250, 253, 253, 254, 254, 255, 255, 256, 256, 257, 257, 257, 258, 258, 259, 259, 260, 261, 261, 262, 0, 262, 262, 264, 267, 267, 267, 267, 268, 268, 268, 268, 269, 269, 269, 269, 269, 270, 271, 272, 273, 274, 277, 277, 278, 280, 287, 287, 287, 287, 287, 288, 288, 289, 289, 292, 292, 292, 293, 293, 294, 294, 297, 298, 298, 0, 298, 298, 299, 299, 301, 302, 303, 305, 306, 306, 306, 306, 307, 307, 309, 309, 310, 310, 311, 311, 312, 317, 317, 318, 318, 318, 318, 318, 319, 319, 319, 319, 319, 320, 324, 325, 325, 325, 326, 327, 327, 327, 327, 328, 328, 328, 328, 329, 329, 329, 329, 329, 330, 330, 331, 0, 331, 331, 332, 335, 335, 335, 335, 335, 336, 336, 337, 0, 337, 337, 338, 343, 343, 343, 344, 345, 345, 345, 345, 345, 345, 352, 352, 356, 356, 357, 362, 362, 363, 364, 364, 365, 366, 366, 367, 368, 368, 369, 370, 370, 371, 373, 373, 373, 375, 377, 381, 383, 383, 383, 384, 384, 385, 385, 385, 386, 386, 387, 388, 388, 389, 389, 389, 390, 390, 390, 396, 396, 397, 398, 398, 399, 0, 399, 399, 400, 403, 404, 404, 405, 406, 408, 408, 408, 411, 413, 0, 413, 413, 414, 414, 414, 415, 416, 417, 420, 0, 420, 420, 421, 421, 421, 422, 423, 424, 425, 425, 430, 431, 431, 432, 434, 434, 435, 435, 436, 439, 442, 442, 442, 445, 445, 445, 447, 447, 448, 448, 449, 449, 449, 450, 450, 450, 451, 451, 451, 452, 452, 452, 453, 453, 453, 454, 454, 457, 458, 460, 460, 460, 461, 462, 464, 465, 466, 466, 466, 467, 468, 472, 472, 472, 473, 473, 474, 474, 474, 476, 476, 476, 479, 483, 483, 484, 485, 487, 0, 487, 487, 488, 488, 489, 489, 490, 490, 490, 491, 491, 492, 492, 494, 494, 494, 495, 495, 495, 499, 500, 502, 502, 0, 0, 0, 503, 503, 504, 504, 504, 504, 504, 504, 504, 504, 506, 506, 507, 507, 509, 509, 509, 510, 510, 510, 515, 515, 515, 517, 517, 518, 518, 518, 520, 520, 521, 521, 521, 523, 523, 524, 524, 524, 528, 528, 529, 530, 530, 530, 530, 530, 531, 533, 533, 537, 537, 537, 538, 539, 539, 540, 541, 543, 543, 543, 544, 545, 545, 546, 547, 549, 549, 553, 553, 553, 553, 554, 554, 554, 556, 556, 557, 557, 557, 557, 558, 560, 560, 560, 560, 560, 562, 562, 563, 563, 564, 568, 568, 568, 570, 572, 572, 573, 573, 573, 573, 574, 578, 579, 579, 580, 580, 581, 587, 587, 588, 589, 596, 596, 597, 599, 604, 605, 606, 607, 608, 609, 609, 0, 0, 0, 612, 612, 612, 612, 614, 616, 616, 616, 616, 617, 617, 617, 620, 624, 624, 626, 626, 628, 628, 629, 629, 633, 633, 635, 635, 637, 637, 638, 638, 641, 641, 644, 644, 645, 647, 647, 648, 648, 652, 652, 654, 654, 656, 656, 657, 657, 661, 661, 663, 663, 665, 665, 666, 666, 670, 670, 672, 672, 674, 674, 675, 675, 679, 679, 681, 681, 683, 683, 684, 684, 688, 688, 690, 690, 692, 692, 693, 693, 697, 697, 699, 699, 701, 701, 702, 702, 706, 706, 708, 708, 710, 710, 711, 711, 714, 714, 716, 716, 718, 718, 719, 719, 723, 723, 724, 724, 726, 726, 0, 0, 0, 728, 728, 729, 729, 731, 731, 731, 732, 734, 735, 736, 736, 737, 738, 738, 738, 739, 740, 741, 742, 748, 749, 750, 751, 751, 752, 752, 753, 754, 754, 755, 755, 756, 756, 757, 759, 759, 760, 761, 768, 769, 771, 772, 772, 773, 774, 776, 777, 777, 778, 778, 779, 779, 780, 780, 781, 781, 782, 782, 784, 786, 786, 787, 789, 791, 791, 0, 791, 791, 0, 0, 792, 793, 793, 793, 793, 793, 0, 793, 793, 793, 0, 0, 0, 0, 0, 794, 795, 795, 0, 795, 795, 795, 795, 795, 795, 0, 0, 0, 795, 795, 795, 0, 0, 0, 795, 795, 795, 0, 0, 0, 0, 0, 801, 801, 801, 801, 802, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 237, 242, 243, 244, 246, 249, 250, 252, 255, 259, 262, 266, 269, 270, 272, 273, 279, 280, 281, 282, 289, 290, 291, 292, 293, 305, 306, 307, 308, 309, 310, 311, 312, 315, 320, 321, 322, 328, 336, 337, 339, 340, 341, 342, 346, 347, 348, 349, 350, 353, 357, 360, 364, 366, 372, 373, 374, 377, 529, 530, 531, 532, 537, 538, 539, 539, 542, 544, 545, 546, 551, 552, 553, 554, 562, 563, 564, 565, 567, 569, 570, 571, 572, 573, 575, 576, 577, 580, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 647, 648, 650, 651, 652, 657, 658, 660, 661, 662, 667, 668, 670, 671, 672, 677, 678, 680, 681, 682, 687, 688, 690, 691, 692, 697, 698, 700, 701, 702, 707, 708, 710, 711, 712, 717, 718, 720, 721, 722, 727, 728, 730, 731, 732, 737, 738, 740, 741, 742, 747, 748, 751, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 771, 772, 773, 778, 779, 782, 786, 789, 789, 792, 794, 795, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 823, 824, 824, 827, 829, 830, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 860, 861, 864, 866, 867, 868, 869, 870, 871, 876, 877, 878, 880, 881, 882, 883, 888, 889, 890, 892, 893, 894, 894, 897, 899, 900, 901, 907, 908, 909, 910, 911, 912, 913, 918, 919, 920, 922, 927, 928, 929, 930, 931, 932, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 999, 1000, 1001, 1004, 1006, 1007, 1008, 1009, 1010, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1026, 1027, 1027, 1030, 1032, 1033, 1040, 1041, 1042, 1043, 1044, 1045, 1050, 1051, 1051, 1054, 1056, 1057, 1070, 1071, 1074, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1092, 1093, 1109, 1114, 1115, 1117, 1122, 1123, 1124, 1125, 1127, 1130, 1131, 1133, 1136, 1137, 1139, 1142, 1143, 1145, 1148, 1149, 1150, 1155, 1157, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1316, 1317, 1318, 1319, 1324, 1325, 1325, 1328, 1330, 1331, 1338, 1339, 1344, 1345, 1346, 1348, 1349, 1350, 1353, 1354, 1354, 1357, 1359, 1360, 1361, 1366, 1367, 1368, 1369, 1376, 1376, 1379, 1381, 1382, 1383, 1388, 1389, 1390, 1391, 1392, 1393, 1401, 1402, 1405, 1407, 1408, 1409, 1411, 1412, 1413, 1420, 1422, 1423, 1424, 1425, 1426, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1455, 1456, 1457, 1458, 1461, 1463, 1464, 1470, 1471, 1472, 1473, 1476, 1478, 1479, 1486, 1487, 1488, 1489, 1494, 1495, 1496, 1497, 1499, 1500, 1501, 1503, 1506, 1511, 1512, 1513, 1515, 1515, 1518, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1531, 1532, 1534, 1535, 1536, 1538, 1539, 1540, 1548, 1549, 1552, 1554, 1556, 1559, 1563, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1579, 1580, 1582, 1583, 1584, 1586, 1587, 1588, 1597, 1598, 1599, 1600, 1605, 1606, 1607, 1608, 1610, 1615, 1616, 1617, 1618, 1620, 1625, 1626, 1627, 1628, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1641, 1642, 1655, 1656, 1659, 1661, 1662, 1663, 1664, 1665, 1671, 1672, 1675, 1677, 1678, 1679, 1680, 1681, 1687, 1688, 1716, 1717, 1718, 1723, 1724, 1725, 1726, 1728, 1729, 1730, 1731, 1732, 1737, 1738, 1741, 1742, 1743, 1744, 1745, 1746, 1751, 1752, 1753, 1754, 1757, 1758, 1759, 1761, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1777, 1778, 1779, 1780, 1785, 1786, 1788, 1789, 1790, 1791, 1795, 1800, 1801, 1803, 1882, 1883, 1884, 1885, 1886, 1887, 1888, 1891, 1895, 1898, 1902, 1903, 1904, 1905, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1917, 1918, 1920, 1921, 1923, 1924, 1925, 1926, 1929, 1930, 1932, 1933, 1935, 1936, 1937, 1938, 1941, 1942, 1944, 1945, 1946, 1948, 1949, 1950, 1951, 1954, 1955, 1957, 1958, 1960, 1961, 1962, 1963, 1966, 1967, 1969, 1970, 1972, 1973, 1974, 1975, 1978, 1979, 1981, 1982, 1984, 1985, 1986, 1987, 1990, 1991, 1993, 1994, 1996, 1997, 1998, 1999, 2002, 2003, 2005, 2006, 2008, 2009, 2010, 2011, 2014, 2015, 2017, 2018, 2020, 2021, 2022, 2023, 2026, 2027, 2029, 2030, 2032, 2033, 2034, 2035, 2038, 2039, 2041, 2042, 2044, 2045, 2046, 2047, 2050, 2051, 2052, 2053, 2055, 2056, 2058, 2062, 2065, 2069, 2070, 2071, 2072, 2074, 2075, 2078, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2115, 2116, 2117, 2118, 2119, 2120, 2123, 2125, 2126, 2127, 2128, 2129, 2130, 2131, 2133, 2135, 2136, 2138, 2139, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2222, 2225, 2226, 2228, 2231, 2235, 2236, 2241, 2242, 2243, 2244, 2246, 2249, 2250, 2251, 2253, 2256, 2260, 2263, 2267, 2270, 2271, 2276, 2277, 2280, 2281, 2282, 2284, 2285, 2286, 2288, 2291, 2295, 2298, 2299, 2300, 2302, 2305, 2309, 2312, 2313, 2314, 2316, 2319, 2323, 2326, 2329, 2333, 2334, 2335, 2336, 2337, 2344, 2347, 2351, 2354, 2358, 2361, 2365, 2368, 2372, 2375, 2379, 2382, 2386, 2389, 2393, 2396, 2400, 2403, 2407, 2410, 2414, 2417, 2421, 2424, 2428, 2431, 2435, 2438, 2442, 2445, 2449, 2452, 2456, 2459, 2463, 2466, 2470, 2473, 2477, 2480, 2484, 2487, 2491, 2494, 2498, 2501, 2505, 2508, 2512, 2515, 2519, 2522, 2526, 2529, 2533, 2536, 2540, 2543, 2547, 2550, 2554, 2557, 2561, 2564, 2568, 2571, 2575, 2578, 2582, 2585, 2589, 2592, 2596, 2599, 2603, 2606, 2610, 2613, 2617, 2620, 2624, 2627, 2631, 2634, 2638, 2641, 2645, 2648, 2652, 2655, 2659, 2662, 2666, 2669, 2673, 2676, 2680, 2683, 2687, 2690, 2694, 2697, 2701, 2704, 2708, 2711, 2715, 2718, 2722, 2725, 2729, 2732, 2736, 2739, 2743, 2746, 2750, 2753, 2757, 2760, 2764, 2767, 2771, 2774, 2778, 2781, 2785, 2788, 2792, 2795, 2799, 2802, 2806, 2809, 2813, 2816, 2820, 2823, 2827, 2830, 2834, 2837, 2841, 2844, 2848, 2851, 2855, 2858, 2862, 2865, 2869};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 56 197
new 0 56 197
assign 1 58 198
new 0 58 198
assign 1 59 199
new 0 59 199
assign 1 60 200
new 0 60 200
assign 1 61 201
new 0 61 201
assign 1 63 202
new 0 63 202
assign 1 64 203
new 0 64 203
assign 1 65 204
new 0 65 204
assign 1 66 205
new 0 66 205
assign 1 67 206
new 0 67 206
assign 1 68 207
new 0 68 207
assign 1 69 208
new 0 69 208
assign 1 73 209
new 0 73 209
assign 1 75 210
new 1 75 210
assign 1 76 211
ntypesGet 0 76 211
assign 1 77 212
twtokGet 0 77 212
assign 1 78 213
new 0 78 213
assign 1 78 214
new 1 78 214
assign 1 81 215
new 0 81 215
assign 1 84 216
new 0 84 216
assign 1 85 217
new 0 85 217
assign 1 86 218
new 0 86 218
assign 1 93 219
new 0 93 219
assign 1 94 220
new 0 94 220
assign 1 95 221
new 0 95 221
assign 1 96 222
new 0 96 222
assign 1 97 223
new 0 97 223
assign 1 98 224
new 0 98 224
assign 1 98 225
new 1 98 225
assign 1 106 237
def 1 106 242
assign 1 106 243
new 0 106 243
assign 1 106 244
equals 1 106 244
assign 1 0 246
assign 1 106 249
new 0 106 249
assign 1 106 250
ends 1 106 250
assign 1 0 252
assign 1 0 255
assign 1 0 259
assign 1 0 262
assign 1 0 266
assign 1 107 269
new 0 107 269
return 1 107 270
assign 1 109 272
new 0 109 272
return 1 109 273
assign 1 113 279
new 0 113 279
assign 1 113 280
new 0 113 280
assign 1 113 281
swap 2 113 281
return 1 113 282
assign 1 117 289
new 0 117 289
assign 1 117 290
argsGet 0 117 290
assign 1 118 291
new 0 118 291
assign 1 118 292
main 1 118 292
exit 1 118 293
assign 1 122 305
assign 1 123 306
new 1 123 306
assign 1 124 307
new 0 124 307
assign 1 124 308
new 0 124 308
assign 1 124 309
get 2 124 309
assign 1 124 310
firstGet 0 124 310
assign 1 124 311
new 1 124 311
assign 1 125 312
new 0 125 312
assign 1 125 315
lesser 1 125 320
assign 1 126 321
go 0 126 321
incrementValue 0 125 322
return 1 128 328
assign 1 132 336
new 0 132 336
assign 1 133 337
new 0 133 337
config 0 135 339
assign 1 136 340
new 0 136 340
assign 1 137 341
doWhat 0 137 341
assign 1 138 342
new 0 138 342
assign 1 140 346
toString 0 140 346
assign 1 141 347
new 0 141 347
assign 1 142 348
new 0 142 348
assign 1 142 349
add 1 142 349
assign 1 143 350
new 0 143 350
assign 1 0 353
assign 1 0 357
assign 1 0 360
print 0 146 364
return 1 148 366
assign 1 152 372
nameGet 0 152 372
assign 1 152 373
new 0 152 373
assign 1 152 374
equals 1 152 374
return 1 154 377
assign 1 159 529
new 0 159 529
assign 1 161 530
new 0 161 530
assign 1 162 531
get 1 162 531
assign 1 162 532
def 1 162 537
assign 1 163 538
get 1 163 538
assign 1 163 539
iteratorGet 0 0 539
assign 1 163 542
hasNextGet 0 163 542
assign 1 163 544
nextGet 0 163 544
assign 1 164 545
has 1 164 545
assign 1 164 546
not 0 164 551
put 1 165 552
assign 1 166 553
new 1 166 553
addFile 1 166 554
assign 1 171 562
new 0 171 562
assign 1 171 563
nameGet 0 171 563
assign 1 171 564
new 0 171 564
assign 1 171 565
equals 1 171 565
preProcessorSet 1 172 567
assign 1 174 569
new 0 174 569
assign 1 174 570
get 1 174 570
assign 1 174 571
firstGet 0 174 571
assign 1 175 572
new 0 175 572
assign 1 175 573
has 1 175 573
assign 1 176 575
new 0 176 575
assign 1 176 576
get 1 176 576
assign 1 176 577
firstGet 0 176 577
assign 1 178 580
assign 1 180 582
new 0 180 582
assign 1 180 583
new 0 180 583
assign 1 180 584
get 2 180 584
assign 1 180 585
firstGet 0 180 585
assign 1 180 586
new 1 180 586
assign 1 180 587
pathGet 0 180 587
addStep 1 181 588
assign 1 182 589
new 0 182 589
addStep 1 182 590
assign 1 183 591
new 0 183 591
assign 1 183 592
new 0 183 592
assign 1 183 593
get 2 183 593
assign 1 183 594
firstGet 0 183 594
assign 1 183 595
new 1 183 595
assign 1 183 596
pathGet 0 183 596
assign 1 184 597
new 0 184 597
assign 1 184 598
new 0 184 598
assign 1 184 599
nameGet 0 184 599
assign 1 184 600
get 2 184 600
assign 1 184 601
firstGet 0 184 601
assign 1 184 602
new 1 184 602
assign 1 185 603
new 0 185 603
assign 1 185 604
nameGet 0 185 604
assign 1 185 605
get 2 185 605
assign 1 185 606
firstGet 0 185 606
assign 1 185 607
new 1 185 607
assign 1 186 608
new 0 186 608
assign 1 186 609
new 0 186 609
assign 1 186 610
get 2 186 610
assign 1 186 611
firstGet 0 186 611
assign 1 186 612
new 1 186 612
assign 1 187 613
new 0 187 613
assign 1 187 614
new 0 187 614
assign 1 187 615
get 2 187 615
assign 1 187 616
firstGet 0 187 616
assign 1 187 617
new 1 187 617
assign 1 188 618
new 0 188 618
assign 1 188 619
new 0 188 619
assign 1 188 620
get 2 188 620
assign 1 188 621
firstGet 0 188 621
assign 1 188 622
new 1 188 622
assign 1 189 623
new 0 189 623
assign 1 189 624
new 0 189 624
assign 1 189 625
get 2 189 625
assign 1 189 626
firstGet 0 189 626
assign 1 189 627
new 1 189 627
assign 1 190 628
new 0 190 628
assign 1 190 629
get 1 190 629
assign 1 191 630
new 0 191 630
assign 1 191 631
get 1 191 631
assign 1 192 632
new 0 192 632
assign 1 192 633
get 1 192 633
assign 1 194 634
new 0 194 634
assign 1 194 635
get 1 194 635
assign 1 194 636
firstGet 0 194 636
assign 1 195 637
new 0 195 637
assign 1 195 638
get 1 195 638
assign 1 195 639
firstGet 0 195 639
assign 1 196 640
new 0 196 640
assign 1 196 641
get 1 196 641
assign 1 197 642
undef 1 197 647
assign 1 198 648
new 0 198 648
assign 1 200 650
new 0 200 650
assign 1 200 651
get 1 200 651
assign 1 201 652
undef 1 201 657
assign 1 202 658
new 0 202 658
assign 1 204 660
new 0 204 660
assign 1 204 661
get 1 204 661
assign 1 205 662
undef 1 205 667
assign 1 206 668
new 0 206 668
assign 1 208 670
new 0 208 670
assign 1 208 671
get 1 208 671
assign 1 209 672
undef 1 209 677
assign 1 210 678
new 0 210 678
assign 1 212 680
new 0 212 680
assign 1 212 681
get 1 212 681
assign 1 213 682
undef 1 213 687
assign 1 214 688
new 0 214 688
assign 1 216 690
new 0 216 690
assign 1 216 691
get 1 216 691
assign 1 217 692
undef 1 217 697
assign 1 218 698
new 0 218 698
assign 1 220 700
new 0 220 700
assign 1 220 701
get 1 220 701
assign 1 221 702
undef 1 221 707
assign 1 222 708
new 0 222 708
assign 1 224 710
new 0 224 710
assign 1 224 711
get 1 224 711
assign 1 225 712
undef 1 225 717
assign 1 226 718
new 0 226 718
assign 1 228 720
new 0 228 720
assign 1 228 721
get 1 228 721
assign 1 229 722
undef 1 229 727
assign 1 230 728
new 0 230 728
assign 1 232 730
new 0 232 730
assign 1 232 731
get 1 232 731
assign 1 233 732
def 1 233 737
assign 1 234 738
firstGet 0 234 738
assign 1 236 740
new 0 236 740
assign 1 236 741
get 1 236 741
assign 1 237 742
def 1 237 747
assign 1 238 748
firstGet 0 238 748
assign 1 240 751
new 0 240 751
assign 1 242 753
new 0 242 753
assign 1 242 754
new 0 242 754
assign 1 242 755
isTrue 2 242 755
assign 1 243 756
new 0 243 756
assign 1 243 757
new 0 243 757
assign 1 243 758
isTrue 2 243 758
assign 1 244 759
new 0 244 759
assign 1 244 760
isTrue 1 244 760
assign 1 245 761
new 0 245 761
assign 1 245 762
isTrue 1 245 762
assign 1 246 763
new 0 246 763
assign 1 247 764
new 0 247 764
assign 1 247 765
get 1 247 765
assign 1 248 766
def 1 248 771
assign 1 248 772
isEmptyGet 0 248 772
assign 1 248 773
not 0 248 778
assign 1 0 779
assign 1 0 782
assign 1 0 786
assign 1 249 789
linkedListIteratorGet 0 0 789
assign 1 249 792
hasNextGet 0 249 792
assign 1 249 794
nextGet 0 249 794
put 1 250 795
assign 1 253 802
new 0 253 802
assign 1 253 803
isTrue 1 253 803
assign 1 254 804
new 0 254 804
assign 1 254 805
isTrue 1 254 805
assign 1 255 806
new 0 255 806
assign 1 255 807
isTrue 1 255 807
assign 1 256 808
new 0 256 808
assign 1 256 809
isTrue 1 256 809
assign 1 257 810
new 0 257 810
assign 1 257 811
new 0 257 811
assign 1 257 812
isTrue 2 257 812
assign 1 258 813
new 0 258 813
assign 1 258 814
get 1 258 814
assign 1 259 815
new 0 259 815
assign 1 259 816
get 1 259 816
assign 1 260 817
new 0 260 817
assign 1 261 818
def 1 261 823
assign 1 262 824
linkedListIteratorGet 0 0 824
assign 1 262 827
hasNextGet 0 262 827
assign 1 262 829
nextGet 0 262 829
addValue 1 264 830
assign 1 267 837
new 0 267 837
assign 1 267 838
new 0 267 838
assign 1 267 839
get 2 267 839
assign 1 267 840
firstGet 0 267 840
assign 1 268 841
new 0 268 841
assign 1 268 842
new 0 268 842
assign 1 268 843
get 2 268 843
assign 1 268 844
firstGet 0 268 844
assign 1 269 845
new 0 269 845
assign 1 269 846
add 1 269 846
assign 1 269 847
new 0 269 847
assign 1 269 848
get 2 269 848
assign 1 269 849
firstGet 0 269 849
assign 1 270 850
new 0 270 850
assign 1 271 851
new 0 271 851
assign 1 272 852
new 0 272 852
assign 1 273 853
new 0 273 853
assign 1 274 854
new 0 274 854
assign 1 277 855
def 1 277 860
assign 1 278 861
firstGet 0 278 861
assign 1 280 864
new 0 280 864
assign 1 287 866
new 0 287 866
assign 1 287 867
add 1 287 867
assign 1 287 868
nameGet 0 287 868
assign 1 287 869
add 1 287 869
assign 1 287 870
get 1 287 870
assign 1 288 871
def 1 288 876
assign 1 289 877
orderedGet 0 289 877
addAll 1 289 878
assign 1 292 880
new 0 292 880
assign 1 292 881
add 1 292 881
assign 1 292 882
get 1 292 882
assign 1 293 883
def 1 293 888
assign 1 294 889
orderedGet 0 294 889
addAll 1 294 890
assign 1 297 892
new 0 297 892
assign 1 298 893
orderedGet 0 298 893
assign 1 298 894
iteratorGet 0 0 894
assign 1 298 897
hasNextGet 0 298 897
assign 1 298 899
nextGet 0 298 899
assign 1 299 900
new 1 299 900
addValue 1 299 901
assign 1 301 907
newlineGet 0 301 907
assign 1 302 908
assign 1 303 909
new 1 303 909
assign 1 305 910
copy 0 305 910
assign 1 306 911
fileGet 0 306 911
assign 1 306 912
existsGet 0 306 912
assign 1 306 913
not 0 306 918
assign 1 307 919
fileGet 0 307 919
makeDirs 0 307 920
assign 1 309 922
def 1 309 927
assign 1 310 928
new 1 310 928
assign 1 310 929
readerGet 0 310 929
assign 1 311 930
open 0 311 930
assign 1 311 931
readString 0 311 931
close 0 312 932
assign 1 317 947
new 0 317 947
assign 1 317 948
className 1 317 948
assign 1 318 949
add 1 318 949
assign 1 318 950
new 0 318 950
assign 1 318 951
add 1 318 951
assign 1 318 952
toString 0 318 952
assign 1 318 953
add 1 318 953
assign 1 319 954
add 1 319 954
assign 1 319 955
new 0 319 955
assign 1 319 956
add 1 319 956
assign 1 319 957
toString 0 319 957
assign 1 319 958
add 1 319 958
return 1 320 959
assign 1 324 999
new 0 324 999
assign 1 325 1000
classesGet 0 325 1000
assign 1 325 1001
valueIteratorGet 0 325 1001
assign 1 325 1004
hasNextGet 0 325 1004
assign 1 326 1006
nextGet 0 326 1006
assign 1 327 1007
shouldEmitGet 0 327 1007
assign 1 327 1008
heldGet 0 327 1008
assign 1 327 1009
fromFileGet 0 327 1009
assign 1 327 1010
has 1 327 1010
assign 1 328 1012
heldGet 0 328 1012
assign 1 328 1013
namepathGet 0 328 1013
assign 1 328 1014
toString 0 328 1014
put 1 328 1015
assign 1 329 1016
usedByGet 0 329 1016
assign 1 329 1017
heldGet 0 329 1017
assign 1 329 1018
namepathGet 0 329 1018
assign 1 329 1019
toString 0 329 1019
assign 1 329 1020
get 1 329 1020
assign 1 330 1021
def 1 330 1026
assign 1 331 1027
setIteratorGet 0 0 1027
assign 1 331 1030
hasNextGet 0 331 1030
assign 1 331 1032
nextGet 0 331 1032
put 1 332 1033
assign 1 335 1040
subClassesGet 0 335 1040
assign 1 335 1041
heldGet 0 335 1041
assign 1 335 1042
namepathGet 0 335 1042
assign 1 335 1043
toString 0 335 1043
assign 1 335 1044
get 1 335 1044
assign 1 336 1045
def 1 336 1050
assign 1 337 1051
setIteratorGet 0 0 1051
assign 1 337 1054
hasNextGet 0 337 1054
assign 1 337 1056
nextGet 0 337 1056
put 1 338 1057
assign 1 343 1070
classesGet 0 343 1070
assign 1 343 1071
valueIteratorGet 0 343 1071
assign 1 343 1074
hasNextGet 0 343 1074
assign 1 344 1076
nextGet 0 344 1076
assign 1 345 1077
heldGet 0 345 1077
assign 1 345 1078
heldGet 0 345 1078
assign 1 345 1079
namepathGet 0 345 1079
assign 1 345 1080
toString 0 345 1080
assign 1 345 1081
has 1 345 1081
shouldWriteSet 1 345 1082
assign 1 352 1092
new 0 352 1092
return 1 352 1093
assign 1 356 1109
def 1 356 1114
return 1 357 1115
assign 1 362 1117
def 1 362 1122
assign 1 363 1123
firstGet 0 363 1123
assign 1 364 1124
new 0 364 1124
assign 1 364 1125
equals 1 364 1125
assign 1 365 1127
new 1 365 1127
assign 1 366 1130
new 0 366 1130
assign 1 366 1131
equals 1 366 1131
assign 1 367 1133
new 1 367 1133
assign 1 368 1136
new 0 368 1136
assign 1 368 1137
equals 1 368 1137
assign 1 369 1139
new 1 369 1139
assign 1 370 1142
new 0 370 1142
assign 1 370 1143
equals 1 370 1143
assign 1 371 1145
new 1 371 1145
assign 1 373 1148
new 0 373 1148
assign 1 373 1149
new 1 373 1149
throw 1 373 1150
return 1 375 1155
return 1 377 1157
assign 1 381 1176
apNew 1 381 1176
assign 1 383 1177
new 0 383 1177
assign 1 383 1178
add 1 383 1178
print 0 383 1179
assign 1 384 1180
new 0 384 1180
assign 1 384 1181
now 0 384 1181
assign 1 385 1182
fileGet 0 385 1182
assign 1 385 1183
readerGet 0 385 1183
assign 1 385 1184
open 0 385 1184
assign 1 386 1185
new 0 386 1185
assign 1 386 1186
deserialize 1 386 1186
close 0 387 1187
assign 1 388 1188
synClassesGet 0 388 1188
addValue 1 388 1189
assign 1 389 1190
new 0 389 1190
assign 1 389 1191
now 0 389 1191
assign 1 389 1192
subtract 1 389 1192
assign 1 390 1193
new 0 390 1193
assign 1 390 1194
add 1 390 1194
print 0 390 1195
assign 1 396 1316
new 0 396 1316
assign 1 396 1317
now 0 396 1317
assign 1 397 1318
new 0 397 1318
assign 1 398 1319
def 1 398 1324
assign 1 399 1325
linkedListIteratorGet 0 0 1325
assign 1 399 1328
hasNextGet 0 399 1328
assign 1 399 1330
nextGet 0 399 1330
loadSyns 1 400 1331
assign 1 403 1338
emitterGet 0 403 1338
assign 1 404 1339
def 1 404 1344
assign 1 405 1345
new 4 405 1345
put 1 406 1346
assign 1 408 1348
new 0 408 1348
assign 1 408 1349
add 1 408 1349
print 0 408 1350
assign 1 411 1353
new 0 411 1353
assign 1 413 1354
iteratorGet 0 0 1354
assign 1 413 1357
hasNextGet 0 413 1357
assign 1 413 1359
nextGet 0 413 1359
assign 1 414 1360
has 1 414 1360
assign 1 414 1361
not 0 414 1366
put 1 415 1367
assign 1 416 1368
new 2 416 1368
addValue 1 417 1369
assign 1 420 1376
iteratorGet 0 0 1376
assign 1 420 1379
hasNextGet 0 420 1379
assign 1 420 1381
nextGet 0 420 1381
assign 1 421 1382
has 1 421 1382
assign 1 421 1383
not 0 421 1388
put 1 422 1389
assign 1 423 1390
new 2 423 1390
addValue 1 424 1391
assign 1 425 1392
libNameGet 0 425 1392
put 1 425 1393
assign 1 430 1401
new 0 430 1401
assign 1 431 1402
iteratorGet 0 431 1402
assign 1 431 1405
hasNextGet 0 431 1405
assign 1 432 1407
nextGet 0 432 1407
assign 1 434 1408
toString 0 434 1408
assign 1 434 1409
has 1 434 1409
assign 1 435 1411
toString 0 435 1411
put 1 435 1412
doParse 1 436 1413
buildSyns 1 439 1420
assign 1 442 1422
new 0 442 1422
assign 1 442 1423
now 0 442 1423
assign 1 442 1424
subtract 1 442 1424
assign 1 445 1425
emitCommonGet 0 445 1425
assign 1 445 1426
def 1 445 1431
assign 1 447 1432
new 0 447 1432
assign 1 447 1433
now 0 447 1433
assign 1 448 1434
emitCommonGet 0 448 1434
doEmit 0 448 1435
assign 1 449 1436
new 0 449 1436
assign 1 449 1437
now 0 449 1437
assign 1 449 1438
subtract 1 449 1438
assign 1 450 1439
new 0 450 1439
assign 1 450 1440
now 0 450 1440
assign 1 450 1441
subtract 1 450 1441
assign 1 451 1442
new 0 451 1442
assign 1 451 1443
add 1 451 1443
print 0 451 1444
assign 1 452 1445
new 0 452 1445
assign 1 452 1446
add 1 452 1446
print 0 452 1447
assign 1 453 1448
new 0 453 1448
assign 1 453 1449
add 1 453 1449
print 0 453 1450
assign 1 454 1451
new 0 454 1451
return 1 454 1452
setClassesToWrite 0 457 1455
libnameInfoGet 0 458 1456
assign 1 460 1457
classesGet 0 460 1457
assign 1 460 1458
valueIteratorGet 0 460 1458
assign 1 460 1461
hasNextGet 0 460 1461
assign 1 461 1463
nextGet 0 461 1463
doEmit 1 462 1464
emitMain 0 464 1470
emitCUInit 0 465 1471
assign 1 466 1472
classesGet 0 466 1472
assign 1 466 1473
valueIteratorGet 0 466 1473
assign 1 466 1476
hasNextGet 0 466 1476
assign 1 467 1478
nextGet 0 467 1478
emitSyn 1 468 1479
assign 1 472 1486
new 0 472 1486
assign 1 472 1487
now 0 472 1487
assign 1 472 1488
subtract 1 472 1488
assign 1 473 1489
def 1 473 1494
assign 1 474 1495
new 0 474 1495
assign 1 474 1496
add 1 474 1496
print 0 474 1497
assign 1 476 1499
new 0 476 1499
assign 1 476 1500
add 1 476 1500
print 0 476 1501
prepMake 1 479 1503
assign 1 483 1506
not 0 483 1511
make 1 484 1512
deployLibrary 1 485 1513
assign 1 487 1515
linkedListIteratorGet 0 0 1515
assign 1 487 1518
hasNextGet 0 487 1518
assign 1 487 1520
nextGet 0 487 1520
assign 1 488 1521
libnameInfoGet 0 488 1521
assign 1 488 1522
unitShlibGet 0 488 1522
assign 1 489 1523
emitPathGet 0 489 1523
assign 1 489 1524
copy 0 489 1524
assign 1 490 1525
stepsGet 0 490 1525
assign 1 490 1526
lastGet 0 490 1526
addStep 1 490 1527
assign 1 491 1528
fileGet 0 491 1528
assign 1 491 1529
existsGet 0 491 1529
assign 1 492 1531
fileGet 0 492 1531
delete 0 492 1532
assign 1 494 1534
fileGet 0 494 1534
assign 1 494 1535
existsGet 0 494 1535
assign 1 494 1536
not 0 494 1536
assign 1 495 1538
fileGet 0 495 1538
assign 1 495 1539
fileGet 0 495 1539
deployFile 2 495 1540
assign 1 499 1548
iteratorGet 0 499 1548
assign 1 500 1549
iteratorGet 0 500 1549
assign 1 502 1552
hasNextGet 0 502 1552
assign 1 502 1554
hasNextGet 0 502 1554
assign 1 0 1556
assign 1 0 1559
assign 1 0 1563
assign 1 503 1566
nextGet 0 503 1566
assign 1 503 1567
apNew 1 503 1567
assign 1 504 1568
emitPathGet 0 504 1568
assign 1 504 1569
copy 0 504 1569
assign 1 504 1570
toString 0 504 1570
assign 1 504 1571
new 0 504 1571
assign 1 504 1572
add 1 504 1572
assign 1 504 1573
nextGet 0 504 1573
assign 1 504 1574
add 1 504 1574
assign 1 504 1575
apNew 1 504 1575
assign 1 506 1576
fileGet 0 506 1576
assign 1 506 1577
existsGet 0 506 1577
assign 1 507 1579
fileGet 0 507 1579
delete 0 507 1580
assign 1 509 1582
fileGet 0 509 1582
assign 1 509 1583
existsGet 0 509 1583
assign 1 509 1584
not 0 509 1584
assign 1 510 1586
fileGet 0 510 1586
assign 1 510 1587
fileGet 0 510 1587
deployFile 2 510 1588
assign 1 515 1597
new 0 515 1597
assign 1 515 1598
now 0 515 1598
assign 1 515 1599
subtract 1 515 1599
assign 1 517 1600
def 1 517 1605
assign 1 518 1606
new 0 518 1606
assign 1 518 1607
add 1 518 1607
print 0 518 1608
assign 1 520 1610
def 1 520 1615
assign 1 521 1616
new 0 521 1616
assign 1 521 1617
add 1 521 1617
print 0 521 1618
assign 1 523 1620
def 1 523 1625
assign 1 524 1626
new 0 524 1626
assign 1 524 1627
add 1 524 1627
print 0 524 1628
assign 1 528 1631
new 0 528 1631
print 0 528 1632
assign 1 529 1633
run 2 529 1633
assign 1 530 1634
new 0 530 1634
assign 1 530 1635
add 1 530 1635
assign 1 530 1636
new 0 530 1636
assign 1 530 1637
add 1 530 1637
print 0 530 1638
return 1 531 1639
assign 1 533 1641
new 0 533 1641
return 1 533 1642
assign 1 537 1655
justParsedGet 0 537 1655
assign 1 537 1656
valueIteratorGet 0 537 1656
assign 1 537 1659
hasNextGet 0 537 1659
assign 1 538 1661
nextGet 0 538 1661
assign 1 539 1662
heldGet 0 539 1662
libNameSet 1 539 1663
assign 1 540 1664
getSyn 2 540 1664
libNameSet 1 541 1665
assign 1 543 1671
justParsedGet 0 543 1671
assign 1 543 1672
valueIteratorGet 0 543 1672
assign 1 543 1675
hasNextGet 0 543 1675
assign 1 544 1677
nextGet 0 544 1677
assign 1 545 1678
heldGet 0 545 1678
assign 1 545 1679
synGet 0 545 1679
checkInheritance 2 546 1680
integrate 1 547 1681
assign 1 549 1687
new 0 549 1687
justParsedSet 1 549 1688
assign 1 553 1716
heldGet 0 553 1716
assign 1 553 1717
synGet 0 553 1717
assign 1 553 1718
def 1 553 1723
assign 1 554 1724
heldGet 0 554 1724
assign 1 554 1725
synGet 0 554 1725
return 1 554 1726
assign 1 556 1728
heldGet 0 556 1728
libNameSet 1 556 1729
assign 1 557 1730
heldGet 0 557 1730
assign 1 557 1731
extendsGet 0 557 1731
assign 1 557 1732
undef 1 557 1737
assign 1 558 1738
new 1 558 1738
assign 1 560 1741
classesGet 0 560 1741
assign 1 560 1742
heldGet 0 560 1742
assign 1 560 1743
extendsGet 0 560 1743
assign 1 560 1744
toString 0 560 1744
assign 1 560 1745
get 1 560 1745
assign 1 562 1746
def 1 562 1751
assign 1 563 1752
heldGet 0 563 1752
libNameSet 1 563 1753
assign 1 564 1754
getSyn 2 564 1754
assign 1 568 1757
heldGet 0 568 1757
assign 1 568 1758
extendsGet 0 568 1758
assign 1 568 1759
getSynNp 1 568 1759
assign 1 570 1761
new 2 570 1761
assign 1 572 1763
heldGet 0 572 1763
synSet 1 572 1764
assign 1 573 1765
heldGet 0 573 1765
assign 1 573 1766
namepathGet 0 573 1766
assign 1 573 1767
toString 0 573 1767
addSynClass 2 573 1768
return 1 574 1769
assign 1 578 1777
toString 0 578 1777
assign 1 579 1778
synClassesGet 0 579 1778
assign 1 579 1779
get 1 579 1779
assign 1 580 1780
def 1 580 1785
return 1 581 1786
assign 1 587 1788
emitterGet 0 587 1788
assign 1 587 1789
loadSyn 1 587 1789
addSynClass 2 588 1790
return 1 589 1791
assign 1 596 1795
undef 1 596 1800
assign 1 597 1801
new 1 597 1801
return 1 599 1803
assign 1 604 1882
new 1 604 1882
assign 1 605 1883
new 0 605 1883
assign 1 606 1884
emitterGet 0 606 1884
assign 1 607 1885
assign 1 608 1886
new 0 608 1886
assign 1 609 1887
shouldEmitGet 0 609 1887
put 1 609 1888
assign 1 0 1891
assign 1 0 1895
assign 1 0 1898
assign 1 612 1902
new 0 612 1902
assign 1 612 1903
toString 0 612 1903
assign 1 612 1904
add 1 612 1904
print 0 612 1905
assign 1 614 1907
assign 1 616 1908
fileGet 0 616 1908
assign 1 616 1909
readerGet 0 616 1909
assign 1 616 1910
open 0 616 1910
assign 1 616 1911
readBuffer 1 616 1911
assign 1 617 1912
fileGet 0 617 1912
assign 1 617 1913
readerGet 0 617 1913
close 0 617 1914
assign 1 620 1915
tokenize 1 620 1915
assign 1 624 1917
new 0 624 1917
output 0 624 1918
assign 1 626 1920
outermostGet 0 626 1920
nodify 2 626 1921
assign 1 628 1923
new 0 628 1923
print 0 628 1924
assign 1 629 1925
new 2 629 1925
traverse 1 629 1926
assign 1 633 1929
new 0 633 1929
output 0 633 1930
assign 1 635 1932
new 0 635 1932
traverse 1 635 1933
assign 1 637 1935
new 0 637 1935
print 0 637 1936
assign 1 638 1937
new 2 638 1937
traverse 1 638 1938
assign 1 641 1941
new 0 641 1941
output 0 641 1942
assign 1 644 1944
new 0 644 1944
traverse 1 644 1945
contain 0 645 1946
assign 1 647 1948
new 0 647 1948
print 0 647 1949
assign 1 648 1950
new 2 648 1950
traverse 1 648 1951
assign 1 652 1954
new 0 652 1954
output 0 652 1955
assign 1 654 1957
new 0 654 1957
traverse 1 654 1958
assign 1 656 1960
new 0 656 1960
print 0 656 1961
assign 1 657 1962
new 2 657 1962
traverse 1 657 1963
assign 1 661 1966
new 0 661 1966
output 0 661 1967
assign 1 663 1969
new 0 663 1969
traverse 1 663 1970
assign 1 665 1972
new 0 665 1972
print 0 665 1973
assign 1 666 1974
new 2 666 1974
traverse 1 666 1975
assign 1 670 1978
new 0 670 1978
output 0 670 1979
assign 1 672 1981
new 0 672 1981
traverse 1 672 1982
assign 1 674 1984
new 0 674 1984
print 0 674 1985
assign 1 675 1986
new 2 675 1986
traverse 1 675 1987
assign 1 679 1990
new 0 679 1990
output 0 679 1991
assign 1 681 1993
new 0 681 1993
traverse 1 681 1994
assign 1 683 1996
new 0 683 1996
print 0 683 1997
assign 1 684 1998
new 2 684 1998
traverse 1 684 1999
assign 1 688 2002
new 0 688 2002
output 0 688 2003
assign 1 690 2005
new 0 690 2005
traverse 1 690 2006
assign 1 692 2008
new 0 692 2008
print 0 692 2009
assign 1 693 2010
new 2 693 2010
traverse 1 693 2011
assign 1 697 2014
new 0 697 2014
output 0 697 2015
assign 1 699 2017
new 0 699 2017
traverse 1 699 2018
assign 1 701 2020
new 0 701 2020
print 0 701 2021
assign 1 702 2022
new 2 702 2022
traverse 1 702 2023
assign 1 706 2026
new 0 706 2026
output 0 706 2027
assign 1 708 2029
new 0 708 2029
traverse 1 708 2030
assign 1 710 2032
new 0 710 2032
print 0 710 2033
assign 1 711 2034
new 2 711 2034
traverse 1 711 2035
assign 1 714 2038
new 0 714 2038
output 0 714 2039
assign 1 716 2041
new 0 716 2041
traverse 1 716 2042
assign 1 718 2044
new 0 718 2044
print 0 718 2045
assign 1 719 2046
new 2 719 2046
traverse 1 719 2047
assign 1 723 2050
new 0 723 2050
output 0 723 2051
assign 1 724 2052
new 0 724 2052
print 0 724 2053
assign 1 726 2055
new 0 726 2055
traverse 1 726 2056
assign 1 0 2058
assign 1 0 2062
assign 1 0 2065
assign 1 728 2069
new 0 728 2069
print 0 728 2070
assign 1 729 2071
new 2 729 2071
traverse 1 729 2072
assign 1 731 2074
classesGet 0 731 2074
assign 1 731 2075
valueIteratorGet 0 731 2075
assign 1 731 2078
hasNextGet 0 731 2078
assign 1 732 2080
nextGet 0 732 2080
assign 1 734 2081
transUnitGet 0 734 2081
assign 1 735 2082
new 1 735 2082
assign 1 736 2083
TRANSUNITGet 0 736 2083
typenameSet 1 736 2084
assign 1 737 2085
new 0 737 2085
assign 1 738 2086
heldGet 0 738 2086
assign 1 738 2087
emitsGet 0 738 2087
emitsSet 1 738 2088
heldSet 1 739 2089
remove 0 740 2090
addValue 1 741 2091
copyLoc 1 742 2092
reInitContained 0 748 2115
assign 1 749 2116
containedGet 0 749 2116
assign 1 750 2117
new 0 750 2117
assign 1 751 2118
new 0 751 2118
assign 1 751 2119
crGet 0 751 2119
assign 1 752 2120
linkedListIteratorGet 0 752 2120
assign 1 752 2123
hasNextGet 0 752 2123
assign 1 753 2125
new 1 753 2125
assign 1 754 2126
nextGet 0 754 2126
heldSet 1 754 2127
assign 1 755 2128
copy 0 755 2128
nlcSet 1 755 2129
assign 1 756 2130
heldGet 0 756 2130
assign 1 756 2131
equals 1 756 2131
incrementValue 0 757 2133
assign 1 759 2135
heldGet 0 759 2135
assign 1 759 2136
notEquals 1 759 2136
addValue 1 760 2138
containerSet 1 761 2139
assign 1 768 2194
new 0 768 2194
fromString 1 769 2195
assign 1 771 2196
new 1 771 2196
assign 1 772 2197
NAMEPATHGet 0 772 2197
typenameSet 1 772 2198
heldSet 1 773 2199
copyLoc 1 774 2200
assign 1 776 2201
new 0 776 2201
assign 1 777 2202
new 0 777 2202
nameSet 1 777 2203
assign 1 778 2204
new 0 778 2204
wasBoundSet 1 778 2205
assign 1 779 2206
new 0 779 2206
boundSet 1 779 2207
assign 1 780 2208
new 0 780 2208
isConstructSet 1 780 2209
assign 1 781 2210
new 0 781 2210
isLiteralSet 1 781 2211
assign 1 782 2212
heldGet 0 782 2212
literalValueSet 1 782 2213
addValue 1 784 2214
assign 1 786 2215
CALLGet 0 786 2215
typenameSet 1 786 2216
heldSet 1 787 2217
resolveNp 0 789 2218
assign 1 791 2219
new 0 791 2219
assign 1 791 2220
equals 1 791 2220
assign 1 0 2222
assign 1 791 2225
new 0 791 2225
assign 1 791 2226
equals 1 791 2226
assign 1 0 2228
assign 1 0 2231
assign 1 792 2235
priorPeerGet 0 792 2235
assign 1 793 2236
def 1 793 2241
assign 1 793 2242
typenameGet 0 793 2242
assign 1 793 2243
SUBTRACTGet 0 793 2243
assign 1 793 2244
equals 1 793 2244
assign 1 0 2246
assign 1 793 2249
typenameGet 0 793 2249
assign 1 793 2250
ADDGet 0 793 2250
assign 1 793 2251
equals 1 793 2251
assign 1 0 2253
assign 1 0 2256
assign 1 0 2260
assign 1 0 2263
assign 1 0 2267
assign 1 794 2270
priorPeerGet 0 794 2270
assign 1 795 2271
undef 1 795 2276
assign 1 0 2277
assign 1 795 2280
typenameGet 0 795 2280
assign 1 795 2281
CALLGet 0 795 2281
assign 1 795 2282
notEquals 1 795 2282
assign 1 795 2284
typenameGet 0 795 2284
assign 1 795 2285
IDGet 0 795 2285
assign 1 795 2286
notEquals 1 795 2286
assign 1 0 2288
assign 1 0 2291
assign 1 0 2295
assign 1 795 2298
typenameGet 0 795 2298
assign 1 795 2299
VARGet 0 795 2299
assign 1 795 2300
notEquals 1 795 2300
assign 1 0 2302
assign 1 0 2305
assign 1 0 2309
assign 1 795 2312
typenameGet 0 795 2312
assign 1 795 2313
ACCESSORGet 0 795 2313
assign 1 795 2314
notEquals 1 795 2314
assign 1 0 2316
assign 1 0 2319
assign 1 0 2323
assign 1 0 2326
assign 1 0 2329
assign 1 801 2333
heldGet 0 801 2333
assign 1 801 2334
literalValueGet 0 801 2334
assign 1 801 2335
add 1 801 2335
literalValueSet 1 801 2336
remove 0 802 2337
return 1 0 2344
assign 1 0 2347
return 1 0 2351
assign 1 0 2354
return 1 0 2358
assign 1 0 2361
return 1 0 2365
assign 1 0 2368
return 1 0 2372
assign 1 0 2375
return 1 0 2379
assign 1 0 2382
return 1 0 2386
assign 1 0 2389
return 1 0 2393
assign 1 0 2396
return 1 0 2400
assign 1 0 2403
return 1 0 2407
assign 1 0 2410
return 1 0 2414
assign 1 0 2417
return 1 0 2421
assign 1 0 2424
return 1 0 2428
assign 1 0 2431
return 1 0 2435
assign 1 0 2438
return 1 0 2442
assign 1 0 2445
return 1 0 2449
assign 1 0 2452
return 1 0 2456
assign 1 0 2459
return 1 0 2463
assign 1 0 2466
return 1 0 2470
assign 1 0 2473
return 1 0 2477
assign 1 0 2480
return 1 0 2484
assign 1 0 2487
return 1 0 2491
assign 1 0 2494
return 1 0 2498
assign 1 0 2501
return 1 0 2505
assign 1 0 2508
return 1 0 2512
assign 1 0 2515
return 1 0 2519
assign 1 0 2522
return 1 0 2526
assign 1 0 2529
return 1 0 2533
assign 1 0 2536
return 1 0 2540
assign 1 0 2543
return 1 0 2547
assign 1 0 2550
return 1 0 2554
assign 1 0 2557
return 1 0 2561
assign 1 0 2564
return 1 0 2568
assign 1 0 2571
return 1 0 2575
assign 1 0 2578
return 1 0 2582
assign 1 0 2585
return 1 0 2589
assign 1 0 2592
return 1 0 2596
assign 1 0 2599
return 1 0 2603
assign 1 0 2606
return 1 0 2610
assign 1 0 2613
return 1 0 2617
assign 1 0 2620
return 1 0 2624
assign 1 0 2627
return 1 0 2631
assign 1 0 2634
return 1 0 2638
assign 1 0 2641
return 1 0 2645
assign 1 0 2648
return 1 0 2652
assign 1 0 2655
return 1 0 2659
assign 1 0 2662
return 1 0 2666
assign 1 0 2669
return 1 0 2673
assign 1 0 2676
return 1 0 2680
assign 1 0 2683
return 1 0 2687
assign 1 0 2690
return 1 0 2694
assign 1 0 2697
return 1 0 2701
assign 1 0 2704
return 1 0 2708
assign 1 0 2711
return 1 0 2715
assign 1 0 2718
return 1 0 2722
assign 1 0 2725
return 1 0 2729
assign 1 0 2732
return 1 0 2736
assign 1 0 2739
return 1 0 2743
assign 1 0 2746
return 1 0 2750
assign 1 0 2753
return 1 0 2757
assign 1 0 2760
return 1 0 2764
assign 1 0 2767
return 1 0 2771
assign 1 0 2774
return 1 0 2778
assign 1 0 2781
return 1 0 2785
assign 1 0 2788
return 1 0 2792
assign 1 0 2795
return 1 0 2799
assign 1 0 2802
return 1 0 2806
assign 1 0 2809
return 1 0 2813
assign 1 0 2816
return 1 0 2820
assign 1 0 2823
return 1 0 2827
assign 1 0 2830
return 1 0 2834
assign 1 0 2837
return 1 0 2841
assign 1 0 2844
return 1 0 2848
assign 1 0 2851
return 1 0 2855
assign 1 0 2858
return 1 0 2862
assign 1 0 2865
assign 1 0 2869
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 294998794: return bem_prepMakeGet_0();
case 1199080894: return bem_ccObjArgsGet_0();
case -994803761: return bem_saveIdsGet_0();
case 1193364852: return bem_extLibsGet_0();
case -1547286709: return bem_linkLibArgsGet_0();
case -701784111: return bem_setClassesToWrite_0();
case 1182809286: return bem_deployFilesToGet_0();
case -397126222: return bem_deployFilesFromGet_0();
case -1747128614: return bem_doWhat_0();
case -544871722: return bem_parseEmitCompileTimeGet_0();
case 489075955: return bem_printAllAstGet_0();
case -1357303720: return bem_ntypesGet_0();
case -2116632580: return bem_printAstElementsGet_0();
case 1369343874: return bem_buildSucceededGet_0();
case 613682439: return bem_emitCs_0();
case -1669535373: return bem_buildMessageGet_0();
case 173214516: return bem_parseGet_0();
case 921287858: return bem_emitterGet_0();
case 349254994: return bem_printAstGet_0();
case 1508698283: return bem_doMainGet_0();
case -461664717: return bem_includePathGet_0();
case -590941330: return bem_exeNameGet_0();
case 2120694747: return bem_hashGet_0();
case 1335780319: return bem_runArgsGet_0();
case -1045555582: return bem_emitDebugGet_0();
case 1230602389: return bem_mainNameGet_0();
case 63408817: return bem_fromFileGet_0();
case 929647084: return bem_putLineNumbersInTraceGet_0();
case -2090601279: return bem_closeLibrariesStrGet_0();
case -913260434: return bem_printStepsGet_0();
case 125877895: return bem_makeArgsGet_0();
case 2113435143: return bem_initLibsGet_0();
case -1476742411: return bem_paramsGet_0();
case -1235033729: return bem_nlGet_0();
case 876662261: return bem_lctokGet_0();
case -1253632064: return bem_buildPathGet_0();
case 832004588: return bem_usedLibrarysStrGet_0();
case -510757051: return bem_emitLibraryGet_0();
case 1743175401: return bem_printPlacesGet_0();
case 1790631209: return bem_codeGet_0();
case 1555181898: return bem_emitPathGet_0();
case -1770735329: return bem_toBuildGet_0();
case -475647431: return bem_libNameGet_0();
case 1586640167: return bem_closeLibrariesGet_0();
case -450434204: return bem_parseEmitTimeGet_0();
case 100580913: return bem_go_0();
case 359021518: return bem_emitFileHeaderGet_0();
case 1149409098: return bem_constantsGet_0();
case 743700876: return bem_new_0();
case 313733409: return bem_genOnlyGet_0();
case -1809979161: return bem_parseTimeGet_0();
case -635566627: return bem_readBufferGet_0();
case -1361462135: return bem_loadSynsGet_0();
case -132460313: return bem_extIncludesGet_0();
case 1765703420: return bem_iteratorGet_0();
case 471369770: return bem_loadIdsGet_0();
case 1770984833: return bem_deployPathGet_0();
case -171041682: return bem_startTimeGet_0();
case -1836982263: return bem_emitDataGet_0();
case 422278468: return bem_outputPlatformGet_0();
case 361218099: return bem_emitCommonGet_0();
case 1773569651: return bem_singleCCGet_0();
case -2086831185: return bem_copy_0();
case 400753420: return bem_create_0();
case -1542832839: return bem_builtGet_0();
case 1853353010: return bem_saveSynsGet_0();
case -1802974463: return bem_main_0();
case -12878092: return bem_makeNameGet_0();
case 1411319058: return bem_deployLibraryGet_0();
case -1035066763: return bem_ownProcessGet_0();
case -327887850: return bem_runGet_0();
case -379031052: return bem_usedLibrarysGet_0();
case 1878331383: return bem_twtokGet_0();
case -1589924343: return bem_newlineGet_0();
case -454700355: return bem_emitChecksGet_0();
case -1985247189: return bem_doEmitGet_0();
case -870375334: return bem_sharedEmitterGet_0();
case 1389177244: return bem_deployUsedLibrariesGet_0();
case 694023299: return bem_argsGet_0();
case -1899206139: return bem_platformGet_0();
case 471531380: return bem_extLinkObjectsGet_0();
case -2064749383: return bem_emitLangsGet_0();
case 1189178834: return bem_config_0();
case 1215577796: return bem_toString_0();
case 1491045033: return bem_print_0();
case 1528955987: return bem_emitFlagsGet_0();
case 2060104025: return bem_compilerGet_0();
case -315679292: return bem_makeGet_0();
case 968022044: return bem_estrGet_0();
case 721294049: return bem_compilerProfileGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -412534785: return bem_copyTo_1(bevd_0);
case -1025516586: return bem_initLibsSet_1(bevd_0);
case -2011956077: return bem_emitLangsSet_1(bevd_0);
case -113007509: return bem_loadSynsSet_1(bevd_0);
case -340087866: return bem_constantsSet_1(bevd_0);
case -913423442: return bem_closeLibrariesStrSet_1(bevd_0);
case 142135945: return bem_twtokSet_1(bevd_0);
case -274598415: return bem_buildPathSet_1(bevd_0);
case 1017698704: return bem_def_1(bevd_0);
case -529616757: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -1431798982: return bem_buildSyns_1(bevd_0);
case -1162383332: return bem_nlSet_1(bevd_0);
case 368511490: return bem_outputPlatformSet_1(bevd_0);
case -2015664708: return bem_doEmitSet_1(bevd_0);
case -706676440: return bem_lctokSet_1(bevd_0);
case -437404985: return bem_builtSet_1(bevd_0);
case -1628038266: return bem_prepMakeSet_1(bevd_0);
case 495469197: return bem_ccObjArgsSet_1(bevd_0);
case -1481337253: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -1843707941: return bem_compilerSet_1(bevd_0);
case 283393712: return bem_parseSet_1(bevd_0);
case -1688269266: return bem_doMainSet_1(bevd_0);
case 931023977: return bem_parseTimeSet_1(bevd_0);
case 1288388452: return bem_startTimeSet_1(bevd_0);
case 564716292: return bem_emitPathSet_1(bevd_0);
case -879871233: return bem_undef_1(bevd_0);
case 538580037: return bem_buildMessageSet_1(bevd_0);
case -1212105802: return bem_mainNameSet_1(bevd_0);
case -2116754692: return bem_saveSynsSet_1(bevd_0);
case -272819979: return bem_paramsSet_1(bevd_0);
case -997101916: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -454243868: return bem_emitDebugSet_1(bevd_0);
case 933230006: return bem_argsSet_1(bevd_0);
case -1575963735: return bem_emitChecksSet_1(bevd_0);
case 15378756: return bem_doParse_1(bevd_0);
case 765482528: return bem_ntypesSet_1(bevd_0);
case 1559535390: return bem_deployFilesFromSet_1(bevd_0);
case -916515576: return bem_extLibsSet_1(bevd_0);
case -2130285407: return bem_deployUsedLibrariesSet_1(bevd_0);
case -421686305: return bem_ownProcessSet_1(bevd_0);
case -1920019282: return bem_readBufferSet_1(bevd_0);
case 509746359: return bem_printPlacesSet_1(bevd_0);
case 1544476916: return bem_libNameSet_1(bevd_0);
case -1338082599: return bem_equals_1(bevd_0);
case -2048525554: return bem_emitFlagsSet_1(bevd_0);
case 1646615257: return bem_singleCCSet_1(bevd_0);
case -1312007687: return bem_deployPathSet_1(bevd_0);
case -1188364990: return bem_newlineSet_1(bevd_0);
case 841260675: return bem_compilerProfileSet_1(bevd_0);
case 67221931: return bem_runArgsSet_1(bevd_0);
case 1016220297: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 802661428: return bem_printStepsSet_1(bevd_0);
case 1341464366: return bem_loadIdsSet_1(bevd_0);
case -1539068113: return bem_emitLibrarySet_1(bevd_0);
case -31730574: return bem_fromFileSet_1(bevd_0);
case -1902125282: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 124177105: return bem_toBuildSet_1(bevd_0);
case 864257708: return bem_buildSucceededSet_1(bevd_0);
case -490915090: return bem_printAstSet_1(bevd_0);
case 2042718694: return bem_makeNameSet_1(bevd_0);
case -10254616: return bem_deployFilesToSet_1(bevd_0);
case -1090189851: return bem_platformSet_1(bevd_0);
case -611982227: return bem_closeLibrariesSet_1(bevd_0);
case 779486598: return bem_deployLibrarySet_1(bevd_0);
case -949091010: return bem_notEquals_1(bevd_0);
case 655550144: return bem_emitFileHeaderSet_1(bevd_0);
case 537411438: return bem_includePathSet_1(bevd_0);
case 211101259: return bem_runSet_1(bevd_0);
case 1219173964: return bem_linkLibArgsSet_1(bevd_0);
case 1206116559: return bem_codeSet_1(bevd_0);
case -555233456: return bem_makeSet_1(bevd_0);
case 2038567737: return bem_emitCommonSet_1(bevd_0);
case -539481583: return bem_printAllAstSet_1(bevd_0);
case 1866788891: return bem_makeArgsSet_1(bevd_0);
case -903397012: return bem_exeNameSet_1(bevd_0);
case -1959783047: return bem_extIncludesSet_1(bevd_0);
case 990678553: return bem_emitDataSet_1(bevd_0);
case 1149335576: return bem_genOnlySet_1(bevd_0);
case -1403159661: return bem_printAstElementsSet_1(bevd_0);
case 1703284469: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1801497288: return bem_parseEmitTimeSet_1(bevd_0);
case -1139591629: return bem_usedLibrarysStrSet_1(bevd_0);
case 1569261195: return bem_usedLibrarysSet_1(bevd_0);
case -1106955019: return bem_getSynNp_1(bevd_0);
case -88783998: return bem_saveIdsSet_1(bevd_0);
case 379308290: return bem_extLinkObjectsSet_1(bevd_0);
case 1616561366: return bem_sharedEmitterSet_1(bevd_0);
case 1291055024: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -1800687413: return bem_print_1(bevd_0);
case -936207089: return bem_estrSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2086342051: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 514975136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1360269993: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -859372521: return bem_buildLiteral_2(bevd_0, bevd_1);
case 1877984138: return bem_getSyn_2(bevd_0, bevd_1);
case -293313249: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2029324670: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
