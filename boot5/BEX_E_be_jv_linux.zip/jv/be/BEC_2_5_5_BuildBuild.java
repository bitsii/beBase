package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_singleCC = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevp_saveIds = be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 98 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 116 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 116 */
 else  /* Line: 116 */ {
break;
} /* Line: 116 */
} /* Line: 116 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try  /* Line: 126 */ {
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 129 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(-1762356041);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 134 */
if (bevp_printSteps.bevi_bool) /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 136 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 136 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 137 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(412923694);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-408502512, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 143 */ {
} /* Line: 143 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 154 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 154 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1336532277);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 157 */
} /* Line: 155 */
 else  /* Line: 154 */ {
break;
} /* Line: 154 */
} /* Line: 154 */
} /* Line: 154 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 162 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 163 */
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 167 */
 else  /* Line: 168 */ {
bevp_exeName = bevp_libName;
} /* Line: 169 */
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(412923694);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 187 */
bevt_61_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 191 */
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 195 */
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 199 */
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 203 */
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 207 */
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 210 */ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 211 */
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 215 */
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 219 */
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-194416916);
} /* Line: 223 */
bevt_79_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 226 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-194416916);
} /* Line: 227 */
 else  /* Line: 228 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 229 */
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 237 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 238 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_91_tmpany_phold).bevi_bool) /* Line: 238 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 239 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
} /* Line: 238 */
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitLangs = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevp_emitFlags = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_100_tmpany_phold = bevp_params.bem_get_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_100_tmpany_phold.bem_firstGet_0();
bevt_104_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_59));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bem_add_1(bevp_makeName);
bevt_109_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_109_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 260 */
 else  /* Line: 261 */ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_62));
} /* Line: 262 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_platform.bemd_0(412923694);
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_114_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_111_tmpany_phold);
if (bevl_platformSources == null) {
bevt_115_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_115_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_116_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 271 */
bevt_118_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_117_tmpany_phold = bevl_outLang.bem_add_1(bevt_118_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_117_tmpany_phold);
if (bevl_langSources == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_120_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 276 */
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_121_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_121_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 280 */ {
bevt_122_tmpany_phold = bevt_2_tmpany_loop.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 280 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(1336532277);
bevt_123_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_123_tmpany_phold);
} /* Line: 281 */
 else  /* Line: 280 */ {
break;
} /* Line: 280 */
} /* Line: 280 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(1934552751);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_125_tmpany_phold = bevt_126_tmpany_phold.bem_existsGet_0();
if (bevt_125_tmpany_phold.bevi_bool) {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_124_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_127_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_127_tmpany_phold.bem_makeDirs_0();
} /* Line: 289 */
if (bevp_emitFileHeader == null) {
bevt_128_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_128_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_129_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_129_tmpany_phold.bem_readerGet_0();
bevt_130_tmpany_phold = bevl_emr.bemd_0(949900379);
bevp_emitFileHeader = bevt_130_tmpany_phold.bemd_0(-1582226508);
bevl_emr.bemd_0(-1299871508);
} /* Line: 294 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(1314740064, bevp_nl);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1314740064, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(1314740064, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(1314740064, bevp_nl);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1314740064, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(1314740064, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 308 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 308 */ {
bevl_clnode = bevl_ci.bemd_0(1336532277);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(574895325);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-354975821);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 310 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(574895325);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(626525515);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1762356041);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(574895325);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(626525515);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-1762356041);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 313 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 314 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 315 */
 else  /* Line: 314 */ {
break;
} /* Line: 314 */
} /* Line: 314 */
} /* Line: 314 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(574895325);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(626525515);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1762356041);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 320 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 321 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
} /* Line: 320 */
} /* Line: 319 */
} /* Line: 310 */
 else  /* Line: 308 */ {
break;
} /* Line: 308 */
} /* Line: 308 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 326 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 326 */ {
bevl_clnode = bevl_ci.bemd_0(1336532277);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(574895325);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(574895325);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(626525515);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-1762356041);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(-849306397, bevt_26_tmpany_phold);
} /* Line: 328 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 339 */ {
return bevp_emitCommon;
} /* Line: 340 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 347 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 348 */
 else  /* Line: 347 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 350 */
 else  /* Line: 347 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 352 */
 else  /* Line: 353 */ {
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_8_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 354 */
} /* Line: 347 */
} /* Line: 347 */
return bevp_emitCommon;
} /* Line: 356 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(949900379);
bevt_5_tmpany_phold = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 379 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 380 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 380 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 381 */
 else  /* Line: 380 */ {
break;
} /* Line: 380 */
} /* Line: 380 */
} /* Line: 380 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 385 */ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 388 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 389 */
} /* Line: 388 */
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(718789172);
while (true)
 /* Line: 394 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 394 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(1336532277);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 395 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 398 */
} /* Line: 395 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(718789172);
while (true)
 /* Line: 401 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 401 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(1336532277);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 402 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(1605051782);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 406 */
} /* Line: 402 */
 else  /* Line: 401 */ {
break;
} /* Line: 401 */
} /* Line: 401 */
if (bevp_parse.bevi_bool) /* Line: 409 */ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 412 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 412 */ {
bevl_tb = bevl_i.bemd_0(1336532277);
bevt_20_tmpany_phold = bevl_tb.bemd_0(-1762356041);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 415 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(-1762356041);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 417 */
} /* Line: 415 */
 else  /* Line: 412 */ {
break;
} /* Line: 412 */
} /* Line: 412 */
bem_buildSyns_1(bevl_em);
} /* Line: 420 */
bevt_23_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_26_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 435 */
if (bevp_doEmit.bevi_bool) /* Line: 437 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(1814369347);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 441 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 441 */ {
bevl_clnode = bevl_ci.bemd_0(1336532277);
bevl_em.bemd_1(-901542351, bevl_clnode);
} /* Line: 443 */
 else  /* Line: 441 */ {
break;
} /* Line: 441 */
} /* Line: 441 */
bevl_em.bemd_0(-530452839);
bevl_em.bemd_0(1983442865);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 447 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 447 */ {
bevl_clnode = bevl_ci.bemd_0(1336532277);
bevl_em.bemd_1(-1947832222, bevl_clnode);
} /* Line: 449 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
} /* Line: 447 */
bevt_44_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 454 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 455 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 458 */ {
bevl_em.bemd_1(-2083174375, bevp_deployLibrary);
} /* Line: 460 */
if (bevp_make.bevi_bool) /* Line: 463 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 464 */ {
bevl_em.bemd_1(140242695, bevp_deployLibrary);
bevl_em.bemd_1(118717735, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 467 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 468 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 468 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(1814369347);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(1629420452);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(402127104);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(769251386);
bevl_cpTo.bemd_1(897546281, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-1735967967);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(683398361);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 472 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-1735967967);
bevt_58_tmpany_phold.bemd_0(-1954815320);
} /* Line: 473 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-1735967967);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(683398361);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(111297745);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 475 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-1735967967);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-1735967967);
bevl_em.bemd_2(1556247788, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 476 */
} /* Line: 475 */
 else  /* Line: 468 */ {
break;
} /* Line: 468 */
} /* Line: 468 */
} /* Line: 468 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 483 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 483 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 483 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 483 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 483 */
 else  /* Line: 483 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 483 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(1336532277);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(1336532277);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-1735967967);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(683398361);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 487 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-1735967967);
bevt_76_tmpany_phold.bemd_0(-1954815320);
} /* Line: 488 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-1735967967);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(683398361);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(111297745);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 490 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-1735967967);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-1735967967);
bevl_em.bemd_2(1556247788, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 491 */
} /* Line: 490 */
 else  /* Line: 483 */ {
break;
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 464 */
bevt_83_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 499 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 502 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 504 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 505 */
if (bevp_run.bevi_bool) /* Line: 508 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(632408401, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 512 */
bevt_98_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 518 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 518 */ {
bevl_kls = bevl_ci.bemd_0(1336532277);
bevt_2_tmpany_phold = bevl_kls.bemd_0(574895325);
bevt_2_tmpany_phold.bemd_1(120464146, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(120464146, bevp_libName);
} /* Line: 522 */
 else  /* Line: 518 */ {
break;
} /* Line: 518 */
} /* Line: 518 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 524 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 524 */ {
bevl_kls = bevl_ci.bemd_0(1336532277);
bevt_5_tmpany_phold = bevl_kls.bemd_0(574895325);
bevl_syn = bevt_5_tmpany_phold.bemd_0(207713108);
bevl_syn.bemd_2(-556114637, this, bevl_kls);
bevl_syn.bemd_1(1774322343, this);
} /* Line: 528 */
 else  /* Line: 524 */ {
break;
} /* Line: 524 */
} /* Line: 524 */
bevt_6_tmpany_phold = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(574895325);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(207713108);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 534 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(574895325);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(207713108);
return bevt_3_tmpany_phold;
} /* Line: 535 */
bevt_5_tmpany_phold = beva_klass.bemd_0(574895325);
bevt_5_tmpany_phold.bemd_1(120464146, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(574895325);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1255441702);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 538 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 539 */
 else  /* Line: 540 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(574895325);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1255441702);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1762356041);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(574895325);
bevt_14_tmpany_phold.bemd_1(120464146, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 545 */
 else  /* Line: 546 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(574895325);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1255441702);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 549 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 551 */
bevt_17_tmpany_phold = beva_klass.bemd_0(574895325);
bevt_17_tmpany_phold.bemd_1(-2098080630, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(574895325);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(626525515);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1762356041);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(-1762356041);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 561 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 562 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(438356635, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 577 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 578 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 591 */ {
if (bevp_printSteps.bevi_bool) /* Line: 592 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 592 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 592 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 592 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 592 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 592 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_5_tmpany_phold = beva_toParse.bemd_0(-1762356041);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 593 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-1735967967);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(318406812);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(949900379);
bevl_src = bevt_6_tmpany_phold.bemd_1(-1200536912, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-1735967967);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(318406812);
bevt_9_tmpany_phold.bemd_0(-1299871508);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 602 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 603 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(1665377585);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 606 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_14_tmpany_phold);
} /* Line: 608 */
if (bevp_printSteps.bevi_bool) /* Line: 611 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 612 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(806222010, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 615 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_18_tmpany_phold);
} /* Line: 617 */
if (bevp_printSteps.bevi_bool) /* Line: 619 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 620 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(806222010, bevt_20_tmpany_phold);
bevl_trans.bemd_0(61635535);
if (bevp_printAllAst.bevi_bool) /* Line: 625 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_22_tmpany_phold);
} /* Line: 627 */
if (bevp_printSteps.bevi_bool) /* Line: 630 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 631 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(806222010, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 634 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_26_tmpany_phold);
} /* Line: 636 */
if (bevp_printSteps.bevi_bool) /* Line: 639 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 640 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(806222010, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 643 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_30_tmpany_phold);
} /* Line: 645 */
if (bevp_printSteps.bevi_bool) /* Line: 648 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 649 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(806222010, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 652 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_34_tmpany_phold);
} /* Line: 654 */
if (bevp_printSteps.bevi_bool) /* Line: 657 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 658 */
bevt_36_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(806222010, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 661 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_38_tmpany_phold);
} /* Line: 663 */
if (bevp_printSteps.bevi_bool) /* Line: 666 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 667 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(806222010, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 670 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_42_tmpany_phold);
} /* Line: 672 */
if (bevp_printSteps.bevi_bool) /* Line: 675 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 676 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(806222010, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 679 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_46_tmpany_phold);
} /* Line: 681 */
if (bevp_printSteps.bevi_bool) /* Line: 684 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 685 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(806222010, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 688 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_50_tmpany_phold);
} /* Line: 690 */
if (bevp_printSteps.bevi_bool) /* Line: 692 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 693 */
bevt_52_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(806222010, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 696 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_54_tmpany_phold);
} /* Line: 698 */
if (bevp_printSteps.bevi_bool) /* Line: 701 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 703 */
bevt_57_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(806222010, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 706 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 706 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 706 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 706 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 706 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 706 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(806222010, bevt_59_tmpany_phold);
} /* Line: 708 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 710 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(149193879);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 710 */ {
bevl_clnode = bevl_ci.bemd_0(1336532277);
bevl_tunode = bevl_clnode.bemd_0(-752060279);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-456580791, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(574895325);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1565297893);
bevl_ntt.bemd_1(-108743089, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(-1306371358, bevl_ntt);
bevl_clnode.bemd_0(-1954815320);
bevl_ntunode.bemd_1(-756695074, bevl_clnode);
bevl_ntunode.bemd_1(607068998, bevl_clnode);
} /* Line: 721 */
 else  /* Line: 710 */ {
break;
} /* Line: 710 */
} /* Line: 710 */
} /* Line: 710 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(-1292469498);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(255756067);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 731 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 731 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(-1306371358, bevt_2_tmpany_phold);
bevl_node.bemd_1(1139443960, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(574895325);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-408502512, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 735 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 736 */
bevt_6_tmpany_phold = bevl_node.bemd_0(574895325);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(1273353241, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 738 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-337514540, beva_parnode);
} /* Line: 740 */
} /* Line: 738 */
 else  /* Line: 731 */ {
break;
} /* Line: 731 */
} /* Line: 731 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(1773482649, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(-456580791, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(-1306371358, bevl_nlnp);
bevl_nlnpn.bemd_1(607068998, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_112));
bevl_nlc.bemd_1(-1342602458, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(222507495, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-454087205, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-1596841962, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1253804653, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(574895325);
bevl_nlc.bemd_1(343405763, bevt_11_tmpany_phold);
beva_node.bemd_1(-756695074, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(-456580791, bevt_12_tmpany_phold);
beva_node.bemd_1(-1306371358, bevl_nlc);
bevl_nlnpn.bemd_0(1877571217);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_113));
bevt_13_tmpany_phold = beva_tName.bemd_1(-408502512, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 770 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 770 */ {
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_114));
bevt_15_tmpany_phold = beva_tName.bemd_1(-408502512, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 770 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 770 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 770 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 770 */ {
bevl_pn = beva_node.bemd_0(1767324286);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 772 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-2118174948);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-408502512, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 772 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-2118174948);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(-408502512, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 772 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 772 */
 else  /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 772 */ {
bevl_pn2 = bevl_pn.bemd_0(1767324286);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-2118174948);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(1273353241, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-2118174948);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(1273353241, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
 else  /* Line: 774 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-2118174948);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(1273353241, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
 else  /* Line: 774 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-2118174948);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1273353241, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
 else  /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(574895325);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(690899140);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(1314740064, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(343405763, bevt_37_tmpany_phold);
bevl_pn.bemd_0(-1954815320);
} /* Line: 781 */
} /* Line: 774 */
} /* Line: 772 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public final BEC_2_4_6_TextString bem_mainNameGetDirect_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public final BEC_2_4_6_TextString bem_exeNameGetDirect_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_platformGetDirect_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public final BEC_2_4_6_TextString bem_nlGetDirect_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public final BEC_2_4_6_TextString bem_buildMessageGetDirect_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_includePathGetDirect_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_builtGetDirect_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printAstGetDirect_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_parseGetDirect_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_makeGetDirect_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_codeGetDirect_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public final BEC_2_4_6_TextString bem_estrGetDirect_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public final BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public final BEC_2_4_6_TextString bem_deployPathGetDirect_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_runGetDirect_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public final BEC_2_4_6_TextString bem_compilerGetDirect_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public final BEC_2_4_6_TextString bem_makeNameGetDirect_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public final BEC_2_4_6_TextString bem_makeArgsGetDirect_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public final BEC_2_4_6_TextString bem_readBufferGetDirect_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() throws Throwable {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 52, 53, 54, 55, 57, 58, 59, 60, 61, 62, 63, 67, 69, 70, 71, 72, 72, 75, 78, 79, 80, 86, 87, 88, 89, 90, 90, 97, 97, 97, 97, 0, 97, 97, 0, 0, 0, 0, 0, 98, 98, 100, 100, 104, 104, 104, 104, 108, 108, 109, 109, 109, 113, 114, 115, 115, 115, 115, 115, 116, 116, 116, 117, 116, 119, 123, 124, 125, 127, 128, 129, 131, 132, 133, 133, 134, 0, 0, 0, 137, 139, 143, 143, 143, 145, 150, 152, 153, 153, 153, 154, 154, 0, 154, 154, 155, 155, 155, 156, 157, 157, 162, 162, 162, 162, 163, 165, 165, 165, 166, 166, 167, 167, 167, 169, 171, 171, 171, 171, 171, 171, 172, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 181, 181, 183, 183, 183, 184, 184, 184, 185, 185, 186, 186, 187, 189, 189, 190, 190, 191, 193, 193, 194, 194, 195, 197, 197, 198, 198, 199, 201, 201, 202, 202, 203, 205, 205, 206, 206, 207, 209, 209, 210, 210, 211, 213, 213, 214, 214, 215, 217, 217, 218, 218, 219, 221, 221, 222, 222, 223, 225, 225, 226, 226, 227, 229, 231, 231, 231, 232, 232, 232, 233, 233, 234, 234, 235, 236, 236, 237, 237, 237, 237, 237, 0, 0, 0, 238, 0, 238, 238, 239, 242, 242, 243, 243, 244, 244, 245, 245, 246, 246, 246, 247, 247, 248, 248, 249, 249, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 251, 252, 253, 254, 255, 256, 259, 259, 260, 262, 269, 269, 269, 269, 269, 270, 270, 271, 271, 274, 274, 274, 275, 275, 276, 276, 279, 280, 280, 0, 280, 280, 281, 281, 283, 284, 285, 287, 288, 288, 288, 288, 289, 289, 291, 291, 292, 292, 293, 293, 294, 300, 301, 301, 301, 301, 301, 302, 302, 302, 302, 302, 303, 307, 308, 308, 308, 309, 310, 310, 310, 310, 311, 311, 311, 311, 312, 312, 312, 312, 312, 313, 313, 314, 0, 314, 314, 315, 318, 318, 318, 318, 318, 319, 319, 320, 0, 320, 320, 321, 326, 326, 326, 327, 328, 328, 328, 328, 328, 328, 335, 335, 339, 339, 340, 345, 345, 346, 347, 347, 348, 349, 349, 350, 351, 351, 352, 354, 354, 354, 356, 358, 362, 364, 364, 364, 365, 365, 366, 366, 366, 367, 367, 368, 369, 369, 370, 370, 370, 371, 371, 371, 377, 377, 378, 379, 379, 380, 0, 380, 380, 381, 384, 385, 385, 386, 387, 389, 389, 389, 392, 394, 0, 394, 394, 395, 395, 395, 396, 397, 398, 401, 0, 401, 401, 402, 402, 402, 403, 404, 405, 406, 406, 411, 412, 412, 413, 415, 415, 416, 416, 417, 420, 423, 423, 423, 426, 426, 426, 428, 428, 429, 429, 430, 430, 430, 431, 431, 431, 432, 432, 432, 433, 433, 433, 434, 434, 434, 435, 435, 438, 439, 441, 441, 441, 442, 443, 445, 446, 447, 447, 447, 448, 449, 453, 453, 453, 454, 454, 455, 455, 455, 457, 457, 457, 460, 464, 464, 465, 466, 468, 0, 468, 468, 469, 469, 470, 470, 471, 471, 471, 472, 472, 473, 473, 475, 475, 475, 476, 476, 476, 480, 481, 483, 483, 0, 0, 0, 484, 484, 485, 485, 485, 485, 485, 485, 485, 485, 487, 487, 488, 488, 490, 490, 490, 491, 491, 491, 496, 496, 496, 498, 498, 499, 499, 499, 501, 501, 502, 502, 502, 504, 504, 505, 505, 505, 509, 509, 510, 511, 511, 511, 511, 511, 512, 514, 514, 518, 518, 518, 519, 520, 520, 521, 522, 524, 524, 524, 525, 526, 526, 527, 528, 530, 530, 534, 534, 534, 534, 535, 535, 535, 537, 537, 538, 538, 538, 538, 539, 541, 541, 541, 541, 541, 543, 543, 544, 544, 545, 549, 549, 549, 551, 553, 553, 554, 554, 554, 554, 555, 559, 560, 560, 561, 561, 562, 568, 568, 569, 570, 577, 577, 578, 580, 585, 586, 587, 588, 589, 590, 590, 0, 0, 0, 593, 593, 593, 593, 595, 597, 597, 597, 597, 598, 598, 598, 599, 603, 603, 605, 605, 607, 607, 608, 608, 612, 612, 614, 614, 616, 616, 617, 617, 620, 620, 623, 623, 624, 626, 626, 627, 627, 631, 631, 633, 633, 635, 635, 636, 636, 640, 640, 642, 642, 644, 644, 645, 645, 649, 649, 651, 651, 653, 653, 654, 654, 658, 658, 660, 660, 662, 662, 663, 663, 667, 667, 669, 669, 671, 671, 672, 672, 676, 676, 678, 678, 680, 680, 681, 681, 685, 685, 687, 687, 689, 689, 690, 690, 693, 693, 695, 695, 697, 697, 698, 698, 702, 702, 703, 703, 705, 705, 0, 0, 0, 707, 707, 708, 708, 710, 710, 710, 711, 713, 714, 715, 715, 716, 717, 717, 717, 718, 719, 720, 721, 727, 728, 729, 730, 730, 731, 731, 732, 733, 733, 734, 735, 735, 736, 738, 738, 739, 740, 747, 748, 750, 751, 751, 752, 753, 755, 756, 756, 757, 757, 758, 758, 759, 759, 760, 760, 761, 761, 763, 765, 765, 766, 768, 770, 770, 0, 770, 770, 0, 0, 771, 772, 772, 772, 772, 772, 0, 772, 772, 772, 0, 0, 0, 0, 0, 773, 774, 774, 0, 774, 774, 774, 774, 774, 774, 0, 0, 0, 774, 774, 774, 0, 0, 0, 774, 774, 774, 0, 0, 0, 0, 0, 780, 780, 780, 780, 781, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 292, 297, 298, 299, 301, 304, 305, 307, 310, 314, 317, 321, 324, 325, 327, 328, 334, 335, 336, 337, 344, 345, 346, 347, 348, 360, 361, 362, 363, 364, 365, 366, 367, 370, 375, 376, 377, 383, 391, 392, 393, 395, 396, 397, 401, 402, 403, 404, 405, 408, 412, 415, 419, 421, 427, 428, 429, 432, 575, 576, 577, 578, 583, 584, 585, 585, 588, 590, 591, 592, 597, 598, 599, 600, 608, 609, 610, 611, 613, 615, 616, 617, 618, 619, 621, 622, 623, 626, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 686, 687, 689, 690, 691, 696, 697, 699, 700, 701, 706, 707, 709, 710, 711, 716, 717, 719, 720, 721, 726, 727, 729, 730, 731, 736, 737, 739, 740, 741, 746, 747, 749, 750, 751, 756, 757, 759, 760, 761, 766, 767, 769, 770, 771, 776, 777, 779, 780, 781, 786, 787, 790, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 810, 811, 812, 817, 818, 821, 825, 828, 828, 831, 833, 834, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 879, 880, 883, 885, 886, 887, 888, 889, 890, 895, 896, 897, 899, 900, 901, 902, 907, 908, 909, 911, 912, 913, 913, 916, 918, 919, 920, 926, 927, 928, 929, 930, 931, 932, 937, 938, 939, 941, 946, 947, 948, 949, 950, 951, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 1016, 1017, 1018, 1021, 1023, 1024, 1025, 1026, 1027, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1043, 1044, 1044, 1047, 1049, 1050, 1057, 1058, 1059, 1060, 1061, 1062, 1067, 1068, 1068, 1071, 1073, 1074, 1087, 1088, 1091, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1109, 1110, 1124, 1129, 1130, 1132, 1137, 1138, 1139, 1140, 1142, 1145, 1146, 1148, 1151, 1152, 1154, 1157, 1158, 1159, 1163, 1165, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1324, 1325, 1326, 1327, 1332, 1333, 1333, 1336, 1338, 1339, 1346, 1347, 1352, 1353, 1354, 1356, 1357, 1358, 1361, 1362, 1362, 1365, 1367, 1368, 1369, 1374, 1375, 1376, 1377, 1384, 1384, 1387, 1389, 1390, 1391, 1396, 1397, 1398, 1399, 1400, 1401, 1409, 1410, 1413, 1415, 1416, 1417, 1419, 1420, 1421, 1428, 1430, 1431, 1432, 1433, 1434, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1463, 1464, 1465, 1466, 1469, 1471, 1472, 1478, 1479, 1480, 1481, 1484, 1486, 1487, 1494, 1495, 1496, 1497, 1502, 1503, 1504, 1505, 1507, 1508, 1509, 1511, 1514, 1519, 1520, 1521, 1523, 1523, 1526, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1539, 1540, 1542, 1543, 1544, 1546, 1547, 1548, 1556, 1557, 1560, 1562, 1564, 1567, 1571, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1587, 1588, 1590, 1591, 1592, 1594, 1595, 1596, 1605, 1606, 1607, 1608, 1613, 1614, 1615, 1616, 1618, 1623, 1624, 1625, 1626, 1628, 1633, 1634, 1635, 1636, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1649, 1650, 1663, 1664, 1667, 1669, 1670, 1671, 1672, 1673, 1679, 1680, 1683, 1685, 1686, 1687, 1688, 1689, 1695, 1696, 1724, 1725, 1726, 1731, 1732, 1733, 1734, 1736, 1737, 1738, 1739, 1740, 1745, 1746, 1749, 1750, 1751, 1752, 1753, 1754, 1759, 1760, 1761, 1762, 1765, 1766, 1767, 1769, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1785, 1786, 1787, 1788, 1793, 1794, 1796, 1797, 1798, 1799, 1803, 1808, 1809, 1811, 1890, 1891, 1892, 1893, 1894, 1895, 1896, 1899, 1903, 1906, 1910, 1911, 1912, 1913, 1915, 1916, 1917, 1918, 1919, 1920, 1921, 1922, 1923, 1925, 1926, 1928, 1929, 1931, 1932, 1933, 1934, 1937, 1938, 1940, 1941, 1943, 1944, 1945, 1946, 1949, 1950, 1952, 1953, 1954, 1956, 1957, 1958, 1959, 1962, 1963, 1965, 1966, 1968, 1969, 1970, 1971, 1974, 1975, 1977, 1978, 1980, 1981, 1982, 1983, 1986, 1987, 1989, 1990, 1992, 1993, 1994, 1995, 1998, 1999, 2001, 2002, 2004, 2005, 2006, 2007, 2010, 2011, 2013, 2014, 2016, 2017, 2018, 2019, 2022, 2023, 2025, 2026, 2028, 2029, 2030, 2031, 2034, 2035, 2037, 2038, 2040, 2041, 2042, 2043, 2046, 2047, 2049, 2050, 2052, 2053, 2054, 2055, 2058, 2059, 2060, 2061, 2063, 2064, 2066, 2070, 2073, 2077, 2078, 2079, 2080, 2082, 2083, 2086, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2122, 2123, 2124, 2125, 2126, 2127, 2130, 2132, 2133, 2134, 2135, 2136, 2137, 2139, 2141, 2142, 2144, 2145, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2228, 2231, 2232, 2234, 2237, 2241, 2242, 2247, 2248, 2249, 2250, 2252, 2255, 2256, 2257, 2259, 2262, 2266, 2269, 2273, 2276, 2277, 2282, 2283, 2286, 2287, 2288, 2290, 2291, 2292, 2294, 2297, 2301, 2304, 2305, 2306, 2308, 2311, 2315, 2318, 2319, 2320, 2322, 2325, 2329, 2332, 2335, 2339, 2340, 2341, 2342, 2343, 2350, 2353, 2356, 2360, 2364, 2367, 2370, 2374, 2378, 2381, 2384, 2388, 2392, 2395, 2398, 2402, 2406, 2409, 2412, 2416, 2420, 2423, 2426, 2430, 2434, 2437, 2440, 2444, 2448, 2451, 2454, 2458, 2462, 2465, 2468, 2472, 2476, 2479, 2482, 2486, 2490, 2493, 2496, 2500, 2504, 2507, 2510, 2514, 2518, 2521, 2524, 2528, 2532, 2535, 2538, 2542, 2546, 2549, 2552, 2556, 2560, 2563, 2566, 2570, 2574, 2577, 2580, 2584, 2588, 2591, 2594, 2598, 2602, 2605, 2608, 2612, 2616, 2619, 2622, 2626, 2630, 2633, 2636, 2640, 2644, 2647, 2650, 2654, 2658, 2661, 2664, 2668, 2672, 2675, 2678, 2682, 2686, 2689, 2692, 2696, 2700, 2703, 2706, 2710, 2714, 2717, 2720, 2724, 2728, 2731, 2734, 2738, 2742, 2745, 2748, 2752, 2756, 2759, 2762, 2766, 2770, 2773, 2776, 2780, 2784, 2787, 2790, 2794, 2798, 2801, 2804, 2808, 2812, 2815, 2818, 2822, 2826, 2829, 2832, 2836, 2840, 2843, 2846, 2850, 2854, 2857, 2860, 2864, 2868, 2871, 2874, 2878, 2882, 2885, 2888, 2892, 2896, 2899, 2902, 2906, 2910, 2913, 2916, 2920, 2924, 2927, 2930, 2934, 2938, 2941, 2944, 2948, 2952, 2955, 2958, 2962, 2966, 2969, 2972, 2976, 2980, 2983, 2986, 2990, 2994, 2997, 3000, 3004, 3008, 3011, 3014, 3018, 3022, 3025, 3028, 3032, 3036, 3039, 3042, 3046, 3050, 3053, 3056, 3060, 3064, 3067, 3070, 3074, 3078, 3081, 3084, 3088, 3092, 3095, 3098, 3102, 3106, 3109, 3112, 3116, 3120, 3123, 3126, 3130, 3134, 3137, 3140, 3144, 3148, 3151, 3154, 3158, 3162, 3165, 3168, 3172, 3176, 3179, 3182, 3186, 3190, 3193, 3196, 3200, 3204, 3207, 3210, 3214, 3218, 3221, 3224, 3228, 3232, 3235, 3238, 3242, 3246, 3249, 3252, 3256, 3260, 3263, 3266, 3270, 3274, 3277, 3280, 3284, 3288, 3291, 3294, 3298, 3302, 3305, 3308, 3312, 3316, 3319, 3322, 3326, 3330, 3333, 3336, 3340, 3344, 3347, 3350, 3354, 3358, 3361, 3365};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 253
new 0 50 253
assign 1 52 254
new 0 52 254
assign 1 53 255
new 0 53 255
assign 1 54 256
new 0 54 256
assign 1 55 257
new 0 55 257
assign 1 57 258
new 0 57 258
assign 1 58 259
new 0 58 259
assign 1 59 260
new 0 59 260
assign 1 60 261
new 0 60 261
assign 1 61 262
new 0 61 262
assign 1 62 263
new 0 62 263
assign 1 63 264
new 0 63 264
assign 1 67 265
new 0 67 265
assign 1 69 266
new 1 69 266
assign 1 70 267
ntypesGet 0 70 267
assign 1 71 268
twtokGet 0 71 268
assign 1 72 269
new 0 72 269
assign 1 72 270
new 1 72 270
assign 1 75 271
new 0 75 271
assign 1 78 272
new 0 78 272
assign 1 79 273
new 0 79 273
assign 1 80 274
new 0 80 274
assign 1 86 275
new 0 86 275
assign 1 87 276
new 0 87 276
assign 1 88 277
new 0 88 277
assign 1 89 278
new 0 89 278
assign 1 90 279
new 0 90 279
assign 1 90 280
new 1 90 280
assign 1 97 292
def 1 97 297
assign 1 97 298
new 0 97 298
assign 1 97 299
equals 1 97 299
assign 1 0 301
assign 1 97 304
new 0 97 304
assign 1 97 305
ends 1 97 305
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 0 317
assign 1 0 321
assign 1 98 324
new 0 98 324
return 1 98 325
assign 1 100 327
new 0 100 327
return 1 100 328
assign 1 104 334
new 0 104 334
assign 1 104 335
new 0 104 335
assign 1 104 336
swap 2 104 336
return 1 104 337
assign 1 108 344
new 0 108 344
assign 1 108 345
argsGet 0 108 345
assign 1 109 346
new 0 109 346
assign 1 109 347
main 1 109 347
exit 1 109 348
assign 1 113 360
assign 1 114 361
new 1 114 361
assign 1 115 362
new 0 115 362
assign 1 115 363
new 0 115 363
assign 1 115 364
get 2 115 364
assign 1 115 365
firstGet 0 115 365
assign 1 115 366
new 1 115 366
assign 1 116 367
new 0 116 367
assign 1 116 370
lesser 1 116 375
assign 1 117 376
go 0 117 376
incrementValue 0 116 377
return 1 119 383
assign 1 123 391
new 0 123 391
config 0 124 392
assign 1 125 393
new 0 125 393
assign 1 127 395
new 0 127 395
assign 1 128 396
doWhat 0 128 396
assign 1 129 397
new 0 129 397
assign 1 131 401
toString 0 131 401
assign 1 132 402
new 0 132 402
assign 1 133 403
new 0 133 403
assign 1 133 404
add 1 133 404
assign 1 134 405
new 0 134 405
assign 1 0 408
assign 1 0 412
assign 1 0 415
print 0 137 419
return 1 139 421
assign 1 143 427
nameGet 0 143 427
assign 1 143 428
new 0 143 428
assign 1 143 429
equals 1 143 429
return 1 145 432
assign 1 150 575
new 0 150 575
assign 1 152 576
new 0 152 576
assign 1 153 577
get 1 153 577
assign 1 153 578
def 1 153 583
assign 1 154 584
get 1 154 584
assign 1 154 585
iteratorGet 0 0 585
assign 1 154 588
hasNextGet 0 154 588
assign 1 154 590
nextGet 0 154 590
assign 1 155 591
has 1 155 591
assign 1 155 592
not 0 155 597
put 1 156 598
assign 1 157 599
new 1 157 599
addFile 1 157 600
assign 1 162 608
new 0 162 608
assign 1 162 609
nameGet 0 162 609
assign 1 162 610
new 0 162 610
assign 1 162 611
equals 1 162 611
preProcessorSet 1 163 613
assign 1 165 615
new 0 165 615
assign 1 165 616
get 1 165 616
assign 1 165 617
firstGet 0 165 617
assign 1 166 618
new 0 166 618
assign 1 166 619
has 1 166 619
assign 1 167 621
new 0 167 621
assign 1 167 622
get 1 167 622
assign 1 167 623
firstGet 0 167 623
assign 1 169 626
assign 1 171 628
new 0 171 628
assign 1 171 629
new 0 171 629
assign 1 171 630
get 2 171 630
assign 1 171 631
firstGet 0 171 631
assign 1 171 632
new 1 171 632
assign 1 171 633
pathGet 0 171 633
addStep 1 172 634
assign 1 173 635
new 0 173 635
addStep 1 173 636
assign 1 174 637
new 0 174 637
assign 1 174 638
new 0 174 638
assign 1 174 639
get 2 174 639
assign 1 174 640
firstGet 0 174 640
assign 1 174 641
new 1 174 641
assign 1 174 642
pathGet 0 174 642
assign 1 175 643
new 0 175 643
assign 1 175 644
new 0 175 644
assign 1 175 645
nameGet 0 175 645
assign 1 175 646
get 2 175 646
assign 1 175 647
firstGet 0 175 647
assign 1 175 648
new 1 175 648
assign 1 176 649
new 0 176 649
assign 1 176 650
nameGet 0 176 650
assign 1 176 651
get 2 176 651
assign 1 176 652
firstGet 0 176 652
assign 1 176 653
new 1 176 653
assign 1 177 654
new 0 177 654
assign 1 177 655
new 0 177 655
assign 1 177 656
get 2 177 656
assign 1 177 657
firstGet 0 177 657
assign 1 177 658
new 1 177 658
assign 1 178 659
new 0 178 659
assign 1 178 660
new 0 178 660
assign 1 178 661
get 2 178 661
assign 1 178 662
firstGet 0 178 662
assign 1 178 663
new 1 178 663
assign 1 179 664
new 0 179 664
assign 1 179 665
new 0 179 665
assign 1 179 666
get 2 179 666
assign 1 179 667
firstGet 0 179 667
assign 1 179 668
new 1 179 668
assign 1 180 669
new 0 180 669
assign 1 180 670
get 1 180 670
assign 1 181 671
new 0 181 671
assign 1 181 672
get 1 181 672
assign 1 183 673
new 0 183 673
assign 1 183 674
get 1 183 674
assign 1 183 675
firstGet 0 183 675
assign 1 184 676
new 0 184 676
assign 1 184 677
get 1 184 677
assign 1 184 678
firstGet 0 184 678
assign 1 185 679
new 0 185 679
assign 1 185 680
get 1 185 680
assign 1 186 681
undef 1 186 686
assign 1 187 687
new 0 187 687
assign 1 189 689
new 0 189 689
assign 1 189 690
get 1 189 690
assign 1 190 691
undef 1 190 696
assign 1 191 697
new 0 191 697
assign 1 193 699
new 0 193 699
assign 1 193 700
get 1 193 700
assign 1 194 701
undef 1 194 706
assign 1 195 707
new 0 195 707
assign 1 197 709
new 0 197 709
assign 1 197 710
get 1 197 710
assign 1 198 711
undef 1 198 716
assign 1 199 717
new 0 199 717
assign 1 201 719
new 0 201 719
assign 1 201 720
get 1 201 720
assign 1 202 721
undef 1 202 726
assign 1 203 727
new 0 203 727
assign 1 205 729
new 0 205 729
assign 1 205 730
get 1 205 730
assign 1 206 731
undef 1 206 736
assign 1 207 737
new 0 207 737
assign 1 209 739
new 0 209 739
assign 1 209 740
get 1 209 740
assign 1 210 741
undef 1 210 746
assign 1 211 747
new 0 211 747
assign 1 213 749
new 0 213 749
assign 1 213 750
get 1 213 750
assign 1 214 751
undef 1 214 756
assign 1 215 757
new 0 215 757
assign 1 217 759
new 0 217 759
assign 1 217 760
get 1 217 760
assign 1 218 761
undef 1 218 766
assign 1 219 767
new 0 219 767
assign 1 221 769
new 0 221 769
assign 1 221 770
get 1 221 770
assign 1 222 771
def 1 222 776
assign 1 223 777
firstGet 0 223 777
assign 1 225 779
new 0 225 779
assign 1 225 780
get 1 225 780
assign 1 226 781
def 1 226 786
assign 1 227 787
firstGet 0 227 787
assign 1 229 790
new 0 229 790
assign 1 231 792
new 0 231 792
assign 1 231 793
new 0 231 793
assign 1 231 794
isTrue 2 231 794
assign 1 232 795
new 0 232 795
assign 1 232 796
new 0 232 796
assign 1 232 797
isTrue 2 232 797
assign 1 233 798
new 0 233 798
assign 1 233 799
isTrue 1 233 799
assign 1 234 800
new 0 234 800
assign 1 234 801
isTrue 1 234 801
assign 1 235 802
new 0 235 802
assign 1 236 803
new 0 236 803
assign 1 236 804
get 1 236 804
assign 1 237 805
def 1 237 810
assign 1 237 811
isEmptyGet 0 237 811
assign 1 237 812
not 0 237 817
assign 1 0 818
assign 1 0 821
assign 1 0 825
assign 1 238 828
linkedListIteratorGet 0 0 828
assign 1 238 831
hasNextGet 0 238 831
assign 1 238 833
nextGet 0 238 833
put 1 239 834
assign 1 242 841
new 0 242 841
assign 1 242 842
isTrue 1 242 842
assign 1 243 843
new 0 243 843
assign 1 243 844
isTrue 1 243 844
assign 1 244 845
new 0 244 845
assign 1 244 846
isTrue 1 244 846
assign 1 245 847
new 0 245 847
assign 1 245 848
isTrue 1 245 848
assign 1 246 849
new 0 246 849
assign 1 246 850
new 0 246 850
assign 1 246 851
isTrue 2 246 851
assign 1 247 852
new 0 247 852
assign 1 247 853
get 1 247 853
assign 1 248 854
new 0 248 854
assign 1 248 855
get 1 248 855
assign 1 249 856
new 0 249 856
assign 1 249 857
new 0 249 857
assign 1 249 858
get 2 249 858
assign 1 249 859
firstGet 0 249 859
assign 1 250 860
new 0 250 860
assign 1 250 861
new 0 250 861
assign 1 250 862
get 2 250 862
assign 1 250 863
firstGet 0 250 863
assign 1 251 864
new 0 251 864
assign 1 251 865
add 1 251 865
assign 1 251 866
new 0 251 866
assign 1 251 867
get 2 251 867
assign 1 251 868
firstGet 0 251 868
assign 1 252 869
new 0 252 869
assign 1 253 870
new 0 253 870
assign 1 254 871
new 0 254 871
assign 1 255 872
new 0 255 872
assign 1 256 873
new 0 256 873
assign 1 259 874
def 1 259 879
assign 1 260 880
firstGet 0 260 880
assign 1 262 883
new 0 262 883
assign 1 269 885
new 0 269 885
assign 1 269 886
add 1 269 886
assign 1 269 887
nameGet 0 269 887
assign 1 269 888
add 1 269 888
assign 1 269 889
get 1 269 889
assign 1 270 890
def 1 270 895
assign 1 271 896
orderedGet 0 271 896
addAll 1 271 897
assign 1 274 899
new 0 274 899
assign 1 274 900
add 1 274 900
assign 1 274 901
get 1 274 901
assign 1 275 902
def 1 275 907
assign 1 276 908
orderedGet 0 276 908
addAll 1 276 909
assign 1 279 911
new 0 279 911
assign 1 280 912
orderedGet 0 280 912
assign 1 280 913
iteratorGet 0 0 913
assign 1 280 916
hasNextGet 0 280 916
assign 1 280 918
nextGet 0 280 918
assign 1 281 919
new 1 281 919
addValue 1 281 920
assign 1 283 926
newlineGet 0 283 926
assign 1 284 927
assign 1 285 928
new 1 285 928
assign 1 287 929
copy 0 287 929
assign 1 288 930
fileGet 0 288 930
assign 1 288 931
existsGet 0 288 931
assign 1 288 932
not 0 288 937
assign 1 289 938
fileGet 0 289 938
makeDirs 0 289 939
assign 1 291 941
def 1 291 946
assign 1 292 947
new 1 292 947
assign 1 292 948
readerGet 0 292 948
assign 1 293 949
open 0 293 949
assign 1 293 950
readString 0 293 950
close 0 294 951
assign 1 300 965
classNameGet 0 300 965
assign 1 301 966
add 1 301 966
assign 1 301 967
new 0 301 967
assign 1 301 968
add 1 301 968
assign 1 301 969
toString 0 301 969
assign 1 301 970
add 1 301 970
assign 1 302 971
add 1 302 971
assign 1 302 972
new 0 302 972
assign 1 302 973
add 1 302 973
assign 1 302 974
toString 0 302 974
assign 1 302 975
add 1 302 975
return 1 303 976
assign 1 307 1016
new 0 307 1016
assign 1 308 1017
classesGet 0 308 1017
assign 1 308 1018
valueIteratorGet 0 308 1018
assign 1 308 1021
hasNextGet 0 308 1021
assign 1 309 1023
nextGet 0 309 1023
assign 1 310 1024
shouldEmitGet 0 310 1024
assign 1 310 1025
heldGet 0 310 1025
assign 1 310 1026
fromFileGet 0 310 1026
assign 1 310 1027
has 1 310 1027
assign 1 311 1029
heldGet 0 311 1029
assign 1 311 1030
namepathGet 0 311 1030
assign 1 311 1031
toString 0 311 1031
put 1 311 1032
assign 1 312 1033
usedByGet 0 312 1033
assign 1 312 1034
heldGet 0 312 1034
assign 1 312 1035
namepathGet 0 312 1035
assign 1 312 1036
toString 0 312 1036
assign 1 312 1037
get 1 312 1037
assign 1 313 1038
def 1 313 1043
assign 1 314 1044
setIteratorGet 0 0 1044
assign 1 314 1047
hasNextGet 0 314 1047
assign 1 314 1049
nextGet 0 314 1049
put 1 315 1050
assign 1 318 1057
subClassesGet 0 318 1057
assign 1 318 1058
heldGet 0 318 1058
assign 1 318 1059
namepathGet 0 318 1059
assign 1 318 1060
toString 0 318 1060
assign 1 318 1061
get 1 318 1061
assign 1 319 1062
def 1 319 1067
assign 1 320 1068
setIteratorGet 0 0 1068
assign 1 320 1071
hasNextGet 0 320 1071
assign 1 320 1073
nextGet 0 320 1073
put 1 321 1074
assign 1 326 1087
classesGet 0 326 1087
assign 1 326 1088
valueIteratorGet 0 326 1088
assign 1 326 1091
hasNextGet 0 326 1091
assign 1 327 1093
nextGet 0 327 1093
assign 1 328 1094
heldGet 0 328 1094
assign 1 328 1095
heldGet 0 328 1095
assign 1 328 1096
namepathGet 0 328 1096
assign 1 328 1097
toString 0 328 1097
assign 1 328 1098
has 1 328 1098
shouldWriteSet 1 328 1099
assign 1 335 1109
new 0 335 1109
return 1 335 1110
assign 1 339 1124
def 1 339 1129
return 1 340 1130
assign 1 345 1132
def 1 345 1137
assign 1 346 1138
firstGet 0 346 1138
assign 1 347 1139
new 0 347 1139
assign 1 347 1140
equals 1 347 1140
assign 1 348 1142
new 1 348 1142
assign 1 349 1145
new 0 349 1145
assign 1 349 1146
equals 1 349 1146
assign 1 350 1148
new 1 350 1148
assign 1 351 1151
new 0 351 1151
assign 1 351 1152
equals 1 351 1152
assign 1 352 1154
new 1 352 1154
assign 1 354 1157
new 0 354 1157
assign 1 354 1158
new 1 354 1158
throw 1 354 1159
return 1 356 1163
return 1 358 1165
assign 1 362 1184
apNew 1 362 1184
assign 1 364 1185
new 0 364 1185
assign 1 364 1186
add 1 364 1186
print 0 364 1187
assign 1 365 1188
new 0 365 1188
assign 1 365 1189
now 0 365 1189
assign 1 366 1190
fileGet 0 366 1190
assign 1 366 1191
readerGet 0 366 1191
assign 1 366 1192
open 0 366 1192
assign 1 367 1193
new 0 367 1193
assign 1 367 1194
deserialize 1 367 1194
close 0 368 1195
assign 1 369 1196
synClassesGet 0 369 1196
addValue 1 369 1197
assign 1 370 1198
new 0 370 1198
assign 1 370 1199
now 0 370 1199
assign 1 370 1200
subtract 1 370 1200
assign 1 371 1201
new 0 371 1201
assign 1 371 1202
add 1 371 1202
print 0 371 1203
assign 1 377 1324
new 0 377 1324
assign 1 377 1325
now 0 377 1325
assign 1 378 1326
new 0 378 1326
assign 1 379 1327
def 1 379 1332
assign 1 380 1333
linkedListIteratorGet 0 0 1333
assign 1 380 1336
hasNextGet 0 380 1336
assign 1 380 1338
nextGet 0 380 1338
loadSyns 1 381 1339
assign 1 384 1346
emitterGet 0 384 1346
assign 1 385 1347
def 1 385 1352
assign 1 386 1353
new 4 386 1353
put 1 387 1354
assign 1 389 1356
new 0 389 1356
assign 1 389 1357
add 1 389 1357
print 0 389 1358
assign 1 392 1361
new 0 392 1361
assign 1 394 1362
iteratorGet 0 0 1362
assign 1 394 1365
hasNextGet 0 394 1365
assign 1 394 1367
nextGet 0 394 1367
assign 1 395 1368
has 1 395 1368
assign 1 395 1369
not 0 395 1374
put 1 396 1375
assign 1 397 1376
new 2 397 1376
addValue 1 398 1377
assign 1 401 1384
iteratorGet 0 0 1384
assign 1 401 1387
hasNextGet 0 401 1387
assign 1 401 1389
nextGet 0 401 1389
assign 1 402 1390
has 1 402 1390
assign 1 402 1391
not 0 402 1396
put 1 403 1397
assign 1 404 1398
new 2 404 1398
addValue 1 405 1399
assign 1 406 1400
libNameGet 0 406 1400
put 1 406 1401
assign 1 411 1409
new 0 411 1409
assign 1 412 1410
iteratorGet 0 412 1410
assign 1 412 1413
hasNextGet 0 412 1413
assign 1 413 1415
nextGet 0 413 1415
assign 1 415 1416
toString 0 415 1416
assign 1 415 1417
has 1 415 1417
assign 1 416 1419
toString 0 416 1419
put 1 416 1420
doParse 1 417 1421
buildSyns 1 420 1428
assign 1 423 1430
new 0 423 1430
assign 1 423 1431
now 0 423 1431
assign 1 423 1432
subtract 1 423 1432
assign 1 426 1433
emitCommonGet 0 426 1433
assign 1 426 1434
def 1 426 1439
assign 1 428 1440
new 0 428 1440
assign 1 428 1441
now 0 428 1441
assign 1 429 1442
emitCommonGet 0 429 1442
doEmit 0 429 1443
assign 1 430 1444
new 0 430 1444
assign 1 430 1445
now 0 430 1445
assign 1 430 1446
subtract 1 430 1446
assign 1 431 1447
new 0 431 1447
assign 1 431 1448
now 0 431 1448
assign 1 431 1449
subtract 1 431 1449
assign 1 432 1450
new 0 432 1450
assign 1 432 1451
add 1 432 1451
print 0 432 1452
assign 1 433 1453
new 0 433 1453
assign 1 433 1454
add 1 433 1454
print 0 433 1455
assign 1 434 1456
new 0 434 1456
assign 1 434 1457
add 1 434 1457
print 0 434 1458
assign 1 435 1459
new 0 435 1459
return 1 435 1460
setClassesToWrite 0 438 1463
libnameInfoGet 0 439 1464
assign 1 441 1465
classesGet 0 441 1465
assign 1 441 1466
valueIteratorGet 0 441 1466
assign 1 441 1469
hasNextGet 0 441 1469
assign 1 442 1471
nextGet 0 442 1471
doEmit 1 443 1472
emitMain 0 445 1478
emitCUInit 0 446 1479
assign 1 447 1480
classesGet 0 447 1480
assign 1 447 1481
valueIteratorGet 0 447 1481
assign 1 447 1484
hasNextGet 0 447 1484
assign 1 448 1486
nextGet 0 448 1486
emitSyn 1 449 1487
assign 1 453 1494
new 0 453 1494
assign 1 453 1495
now 0 453 1495
assign 1 453 1496
subtract 1 453 1496
assign 1 454 1497
def 1 454 1502
assign 1 455 1503
new 0 455 1503
assign 1 455 1504
add 1 455 1504
print 0 455 1505
assign 1 457 1507
new 0 457 1507
assign 1 457 1508
add 1 457 1508
print 0 457 1509
prepMake 1 460 1511
assign 1 464 1514
not 0 464 1519
make 1 465 1520
deployLibrary 1 466 1521
assign 1 468 1523
linkedListIteratorGet 0 0 1523
assign 1 468 1526
hasNextGet 0 468 1526
assign 1 468 1528
nextGet 0 468 1528
assign 1 469 1529
libnameInfoGet 0 469 1529
assign 1 469 1530
unitShlibGet 0 469 1530
assign 1 470 1531
emitPathGet 0 470 1531
assign 1 470 1532
copy 0 470 1532
assign 1 471 1533
stepsGet 0 471 1533
assign 1 471 1534
lastGet 0 471 1534
addStep 1 471 1535
assign 1 472 1536
fileGet 0 472 1536
assign 1 472 1537
existsGet 0 472 1537
assign 1 473 1539
fileGet 0 473 1539
delete 0 473 1540
assign 1 475 1542
fileGet 0 475 1542
assign 1 475 1543
existsGet 0 475 1543
assign 1 475 1544
not 0 475 1544
assign 1 476 1546
fileGet 0 476 1546
assign 1 476 1547
fileGet 0 476 1547
deployFile 2 476 1548
assign 1 480 1556
iteratorGet 0 480 1556
assign 1 481 1557
iteratorGet 0 481 1557
assign 1 483 1560
hasNextGet 0 483 1560
assign 1 483 1562
hasNextGet 0 483 1562
assign 1 0 1564
assign 1 0 1567
assign 1 0 1571
assign 1 484 1574
nextGet 0 484 1574
assign 1 484 1575
apNew 1 484 1575
assign 1 485 1576
emitPathGet 0 485 1576
assign 1 485 1577
copy 0 485 1577
assign 1 485 1578
toString 0 485 1578
assign 1 485 1579
new 0 485 1579
assign 1 485 1580
add 1 485 1580
assign 1 485 1581
nextGet 0 485 1581
assign 1 485 1582
add 1 485 1582
assign 1 485 1583
apNew 1 485 1583
assign 1 487 1584
fileGet 0 487 1584
assign 1 487 1585
existsGet 0 487 1585
assign 1 488 1587
fileGet 0 488 1587
delete 0 488 1588
assign 1 490 1590
fileGet 0 490 1590
assign 1 490 1591
existsGet 0 490 1591
assign 1 490 1592
not 0 490 1592
assign 1 491 1594
fileGet 0 491 1594
assign 1 491 1595
fileGet 0 491 1595
deployFile 2 491 1596
assign 1 496 1605
new 0 496 1605
assign 1 496 1606
now 0 496 1606
assign 1 496 1607
subtract 1 496 1607
assign 1 498 1608
def 1 498 1613
assign 1 499 1614
new 0 499 1614
assign 1 499 1615
add 1 499 1615
print 0 499 1616
assign 1 501 1618
def 1 501 1623
assign 1 502 1624
new 0 502 1624
assign 1 502 1625
add 1 502 1625
print 0 502 1626
assign 1 504 1628
def 1 504 1633
assign 1 505 1634
new 0 505 1634
assign 1 505 1635
add 1 505 1635
print 0 505 1636
assign 1 509 1639
new 0 509 1639
print 0 509 1640
assign 1 510 1641
run 2 510 1641
assign 1 511 1642
new 0 511 1642
assign 1 511 1643
add 1 511 1643
assign 1 511 1644
new 0 511 1644
assign 1 511 1645
add 1 511 1645
print 0 511 1646
return 1 512 1647
assign 1 514 1649
new 0 514 1649
return 1 514 1650
assign 1 518 1663
justParsedGet 0 518 1663
assign 1 518 1664
valueIteratorGet 0 518 1664
assign 1 518 1667
hasNextGet 0 518 1667
assign 1 519 1669
nextGet 0 519 1669
assign 1 520 1670
heldGet 0 520 1670
libNameSet 1 520 1671
assign 1 521 1672
getSyn 2 521 1672
libNameSet 1 522 1673
assign 1 524 1679
justParsedGet 0 524 1679
assign 1 524 1680
valueIteratorGet 0 524 1680
assign 1 524 1683
hasNextGet 0 524 1683
assign 1 525 1685
nextGet 0 525 1685
assign 1 526 1686
heldGet 0 526 1686
assign 1 526 1687
synGet 0 526 1687
checkInheritance 2 527 1688
integrate 1 528 1689
assign 1 530 1695
new 0 530 1695
justParsedSet 1 530 1696
assign 1 534 1724
heldGet 0 534 1724
assign 1 534 1725
synGet 0 534 1725
assign 1 534 1726
def 1 534 1731
assign 1 535 1732
heldGet 0 535 1732
assign 1 535 1733
synGet 0 535 1733
return 1 535 1734
assign 1 537 1736
heldGet 0 537 1736
libNameSet 1 537 1737
assign 1 538 1738
heldGet 0 538 1738
assign 1 538 1739
extendsGet 0 538 1739
assign 1 538 1740
undef 1 538 1745
assign 1 539 1746
new 1 539 1746
assign 1 541 1749
classesGet 0 541 1749
assign 1 541 1750
heldGet 0 541 1750
assign 1 541 1751
extendsGet 0 541 1751
assign 1 541 1752
toString 0 541 1752
assign 1 541 1753
get 1 541 1753
assign 1 543 1754
def 1 543 1759
assign 1 544 1760
heldGet 0 544 1760
libNameSet 1 544 1761
assign 1 545 1762
getSyn 2 545 1762
assign 1 549 1765
heldGet 0 549 1765
assign 1 549 1766
extendsGet 0 549 1766
assign 1 549 1767
getSynNp 1 549 1767
assign 1 551 1769
new 2 551 1769
assign 1 553 1771
heldGet 0 553 1771
synSet 1 553 1772
assign 1 554 1773
heldGet 0 554 1773
assign 1 554 1774
namepathGet 0 554 1774
assign 1 554 1775
toString 0 554 1775
addSynClass 2 554 1776
return 1 555 1777
assign 1 559 1785
toString 0 559 1785
assign 1 560 1786
synClassesGet 0 560 1786
assign 1 560 1787
get 1 560 1787
assign 1 561 1788
def 1 561 1793
return 1 562 1794
assign 1 568 1796
emitterGet 0 568 1796
assign 1 568 1797
loadSyn 1 568 1797
addSynClass 2 569 1798
return 1 570 1799
assign 1 577 1803
undef 1 577 1808
assign 1 578 1809
new 1 578 1809
return 1 580 1811
assign 1 585 1890
new 1 585 1890
assign 1 586 1891
new 0 586 1891
assign 1 587 1892
emitterGet 0 587 1892
assign 1 588 1893
assign 1 589 1894
new 0 589 1894
assign 1 590 1895
shouldEmitGet 0 590 1895
put 1 590 1896
assign 1 0 1899
assign 1 0 1903
assign 1 0 1906
assign 1 593 1910
new 0 593 1910
assign 1 593 1911
toString 0 593 1911
assign 1 593 1912
add 1 593 1912
print 0 593 1913
assign 1 595 1915
assign 1 597 1916
fileGet 0 597 1916
assign 1 597 1917
readerGet 0 597 1917
assign 1 597 1918
open 0 597 1918
assign 1 597 1919
readBuffer 1 597 1919
assign 1 598 1920
fileGet 0 598 1920
assign 1 598 1921
readerGet 0 598 1921
close 0 598 1922
assign 1 599 1923
tokenize 1 599 1923
assign 1 603 1925
new 0 603 1925
echo 0 603 1926
assign 1 605 1928
outermostGet 0 605 1928
nodify 2 605 1929
assign 1 607 1931
new 0 607 1931
print 0 607 1932
assign 1 608 1933
new 2 608 1933
traverse 1 608 1934
assign 1 612 1937
new 0 612 1937
echo 0 612 1938
assign 1 614 1940
new 0 614 1940
traverse 1 614 1941
assign 1 616 1943
new 0 616 1943
print 0 616 1944
assign 1 617 1945
new 2 617 1945
traverse 1 617 1946
assign 1 620 1949
new 0 620 1949
echo 0 620 1950
assign 1 623 1952
new 0 623 1952
traverse 1 623 1953
contain 0 624 1954
assign 1 626 1956
new 0 626 1956
print 0 626 1957
assign 1 627 1958
new 2 627 1958
traverse 1 627 1959
assign 1 631 1962
new 0 631 1962
echo 0 631 1963
assign 1 633 1965
new 0 633 1965
traverse 1 633 1966
assign 1 635 1968
new 0 635 1968
print 0 635 1969
assign 1 636 1970
new 2 636 1970
traverse 1 636 1971
assign 1 640 1974
new 0 640 1974
echo 0 640 1975
assign 1 642 1977
new 0 642 1977
traverse 1 642 1978
assign 1 644 1980
new 0 644 1980
print 0 644 1981
assign 1 645 1982
new 2 645 1982
traverse 1 645 1983
assign 1 649 1986
new 0 649 1986
echo 0 649 1987
assign 1 651 1989
new 0 651 1989
traverse 1 651 1990
assign 1 653 1992
new 0 653 1992
print 0 653 1993
assign 1 654 1994
new 2 654 1994
traverse 1 654 1995
assign 1 658 1998
new 0 658 1998
echo 0 658 1999
assign 1 660 2001
new 0 660 2001
traverse 1 660 2002
assign 1 662 2004
new 0 662 2004
print 0 662 2005
assign 1 663 2006
new 2 663 2006
traverse 1 663 2007
assign 1 667 2010
new 0 667 2010
echo 0 667 2011
assign 1 669 2013
new 0 669 2013
traverse 1 669 2014
assign 1 671 2016
new 0 671 2016
print 0 671 2017
assign 1 672 2018
new 2 672 2018
traverse 1 672 2019
assign 1 676 2022
new 0 676 2022
echo 0 676 2023
assign 1 678 2025
new 0 678 2025
traverse 1 678 2026
assign 1 680 2028
new 0 680 2028
print 0 680 2029
assign 1 681 2030
new 2 681 2030
traverse 1 681 2031
assign 1 685 2034
new 0 685 2034
echo 0 685 2035
assign 1 687 2037
new 0 687 2037
traverse 1 687 2038
assign 1 689 2040
new 0 689 2040
print 0 689 2041
assign 1 690 2042
new 2 690 2042
traverse 1 690 2043
assign 1 693 2046
new 0 693 2046
echo 0 693 2047
assign 1 695 2049
new 0 695 2049
traverse 1 695 2050
assign 1 697 2052
new 0 697 2052
print 0 697 2053
assign 1 698 2054
new 2 698 2054
traverse 1 698 2055
assign 1 702 2058
new 0 702 2058
echo 0 702 2059
assign 1 703 2060
new 0 703 2060
print 0 703 2061
assign 1 705 2063
new 0 705 2063
traverse 1 705 2064
assign 1 0 2066
assign 1 0 2070
assign 1 0 2073
assign 1 707 2077
new 0 707 2077
print 0 707 2078
assign 1 708 2079
new 2 708 2079
traverse 1 708 2080
assign 1 710 2082
classesGet 0 710 2082
assign 1 710 2083
valueIteratorGet 0 710 2083
assign 1 710 2086
hasNextGet 0 710 2086
assign 1 711 2088
nextGet 0 711 2088
assign 1 713 2089
transUnitGet 0 713 2089
assign 1 714 2090
new 1 714 2090
assign 1 715 2091
TRANSUNITGet 0 715 2091
typenameSet 1 715 2092
assign 1 716 2093
new 0 716 2093
assign 1 717 2094
heldGet 0 717 2094
assign 1 717 2095
emitsGet 0 717 2095
emitsSet 1 717 2096
heldSet 1 718 2097
delete 0 719 2098
addValue 1 720 2099
copyLoc 1 721 2100
reInitContained 0 727 2122
assign 1 728 2123
containedGet 0 728 2123
assign 1 729 2124
new 0 729 2124
assign 1 730 2125
new 0 730 2125
assign 1 730 2126
crGet 0 730 2126
assign 1 731 2127
linkedListIteratorGet 0 731 2127
assign 1 731 2130
hasNextGet 0 731 2130
assign 1 732 2132
new 1 732 2132
assign 1 733 2133
nextGet 0 733 2133
heldSet 1 733 2134
nlcSet 1 734 2135
assign 1 735 2136
heldGet 0 735 2136
assign 1 735 2137
equals 1 735 2137
assign 1 736 2139
increment 0 736 2139
assign 1 738 2141
heldGet 0 738 2141
assign 1 738 2142
notEquals 1 738 2142
addValue 1 739 2144
containerSet 1 740 2145
assign 1 747 2200
new 0 747 2200
fromString 1 748 2201
assign 1 750 2202
new 1 750 2202
assign 1 751 2203
NAMEPATHGet 0 751 2203
typenameSet 1 751 2204
heldSet 1 752 2205
copyLoc 1 753 2206
assign 1 755 2207
new 0 755 2207
assign 1 756 2208
new 0 756 2208
nameSet 1 756 2209
assign 1 757 2210
new 0 757 2210
wasBoundSet 1 757 2211
assign 1 758 2212
new 0 758 2212
boundSet 1 758 2213
assign 1 759 2214
new 0 759 2214
isConstructSet 1 759 2215
assign 1 760 2216
new 0 760 2216
isLiteralSet 1 760 2217
assign 1 761 2218
heldGet 0 761 2218
literalValueSet 1 761 2219
addValue 1 763 2220
assign 1 765 2221
CALLGet 0 765 2221
typenameSet 1 765 2222
heldSet 1 766 2223
resolveNp 0 768 2224
assign 1 770 2225
new 0 770 2225
assign 1 770 2226
equals 1 770 2226
assign 1 0 2228
assign 1 770 2231
new 0 770 2231
assign 1 770 2232
equals 1 770 2232
assign 1 0 2234
assign 1 0 2237
assign 1 771 2241
priorPeerGet 0 771 2241
assign 1 772 2242
def 1 772 2247
assign 1 772 2248
typenameGet 0 772 2248
assign 1 772 2249
SUBTRACTGet 0 772 2249
assign 1 772 2250
equals 1 772 2250
assign 1 0 2252
assign 1 772 2255
typenameGet 0 772 2255
assign 1 772 2256
ADDGet 0 772 2256
assign 1 772 2257
equals 1 772 2257
assign 1 0 2259
assign 1 0 2262
assign 1 0 2266
assign 1 0 2269
assign 1 0 2273
assign 1 773 2276
priorPeerGet 0 773 2276
assign 1 774 2277
undef 1 774 2282
assign 1 0 2283
assign 1 774 2286
typenameGet 0 774 2286
assign 1 774 2287
CALLGet 0 774 2287
assign 1 774 2288
notEquals 1 774 2288
assign 1 774 2290
typenameGet 0 774 2290
assign 1 774 2291
IDGet 0 774 2291
assign 1 774 2292
notEquals 1 774 2292
assign 1 0 2294
assign 1 0 2297
assign 1 0 2301
assign 1 774 2304
typenameGet 0 774 2304
assign 1 774 2305
VARGet 0 774 2305
assign 1 774 2306
notEquals 1 774 2306
assign 1 0 2308
assign 1 0 2311
assign 1 0 2315
assign 1 774 2318
typenameGet 0 774 2318
assign 1 774 2319
ACCESSORGet 0 774 2319
assign 1 774 2320
notEquals 1 774 2320
assign 1 0 2322
assign 1 0 2325
assign 1 0 2329
assign 1 0 2332
assign 1 0 2335
assign 1 780 2339
heldGet 0 780 2339
assign 1 780 2340
literalValueGet 0 780 2340
assign 1 780 2341
add 1 780 2341
literalValueSet 1 780 2342
delete 0 781 2343
return 1 0 2350
return 1 0 2353
assign 1 0 2356
assign 1 0 2360
return 1 0 2364
return 1 0 2367
assign 1 0 2370
assign 1 0 2374
return 1 0 2378
return 1 0 2381
assign 1 0 2384
assign 1 0 2388
return 1 0 2392
return 1 0 2395
assign 1 0 2398
assign 1 0 2402
return 1 0 2406
return 1 0 2409
assign 1 0 2412
assign 1 0 2416
return 1 0 2420
return 1 0 2423
assign 1 0 2426
assign 1 0 2430
return 1 0 2434
return 1 0 2437
assign 1 0 2440
assign 1 0 2444
return 1 0 2448
return 1 0 2451
assign 1 0 2454
assign 1 0 2458
return 1 0 2462
return 1 0 2465
assign 1 0 2468
assign 1 0 2472
return 1 0 2476
return 1 0 2479
assign 1 0 2482
assign 1 0 2486
return 1 0 2490
return 1 0 2493
assign 1 0 2496
assign 1 0 2500
return 1 0 2504
return 1 0 2507
assign 1 0 2510
assign 1 0 2514
return 1 0 2518
return 1 0 2521
assign 1 0 2524
assign 1 0 2528
return 1 0 2532
return 1 0 2535
assign 1 0 2538
assign 1 0 2542
return 1 0 2546
return 1 0 2549
assign 1 0 2552
assign 1 0 2556
return 1 0 2560
return 1 0 2563
assign 1 0 2566
assign 1 0 2570
return 1 0 2574
return 1 0 2577
assign 1 0 2580
assign 1 0 2584
return 1 0 2588
return 1 0 2591
assign 1 0 2594
assign 1 0 2598
return 1 0 2602
return 1 0 2605
assign 1 0 2608
assign 1 0 2612
return 1 0 2616
return 1 0 2619
assign 1 0 2622
assign 1 0 2626
return 1 0 2630
return 1 0 2633
assign 1 0 2636
assign 1 0 2640
return 1 0 2644
return 1 0 2647
assign 1 0 2650
assign 1 0 2654
return 1 0 2658
return 1 0 2661
assign 1 0 2664
assign 1 0 2668
return 1 0 2672
return 1 0 2675
assign 1 0 2678
assign 1 0 2682
return 1 0 2686
return 1 0 2689
assign 1 0 2692
assign 1 0 2696
return 1 0 2700
return 1 0 2703
assign 1 0 2706
assign 1 0 2710
return 1 0 2714
return 1 0 2717
assign 1 0 2720
assign 1 0 2724
return 1 0 2728
return 1 0 2731
assign 1 0 2734
assign 1 0 2738
return 1 0 2742
return 1 0 2745
assign 1 0 2748
assign 1 0 2752
return 1 0 2756
return 1 0 2759
assign 1 0 2762
assign 1 0 2766
return 1 0 2770
return 1 0 2773
assign 1 0 2776
assign 1 0 2780
return 1 0 2784
return 1 0 2787
assign 1 0 2790
assign 1 0 2794
return 1 0 2798
return 1 0 2801
assign 1 0 2804
assign 1 0 2808
return 1 0 2812
return 1 0 2815
assign 1 0 2818
assign 1 0 2822
return 1 0 2826
return 1 0 2829
assign 1 0 2832
assign 1 0 2836
return 1 0 2840
return 1 0 2843
assign 1 0 2846
assign 1 0 2850
return 1 0 2854
return 1 0 2857
assign 1 0 2860
assign 1 0 2864
return 1 0 2868
return 1 0 2871
assign 1 0 2874
assign 1 0 2878
return 1 0 2882
return 1 0 2885
assign 1 0 2888
assign 1 0 2892
return 1 0 2896
return 1 0 2899
assign 1 0 2902
assign 1 0 2906
return 1 0 2910
return 1 0 2913
assign 1 0 2916
assign 1 0 2920
return 1 0 2924
return 1 0 2927
assign 1 0 2930
assign 1 0 2934
return 1 0 2938
return 1 0 2941
assign 1 0 2944
assign 1 0 2948
return 1 0 2952
return 1 0 2955
assign 1 0 2958
assign 1 0 2962
return 1 0 2966
return 1 0 2969
assign 1 0 2972
assign 1 0 2976
return 1 0 2980
return 1 0 2983
assign 1 0 2986
assign 1 0 2990
return 1 0 2994
return 1 0 2997
assign 1 0 3000
assign 1 0 3004
return 1 0 3008
return 1 0 3011
assign 1 0 3014
assign 1 0 3018
return 1 0 3022
return 1 0 3025
assign 1 0 3028
assign 1 0 3032
return 1 0 3036
return 1 0 3039
assign 1 0 3042
assign 1 0 3046
return 1 0 3050
return 1 0 3053
assign 1 0 3056
assign 1 0 3060
return 1 0 3064
return 1 0 3067
assign 1 0 3070
assign 1 0 3074
return 1 0 3078
return 1 0 3081
assign 1 0 3084
assign 1 0 3088
return 1 0 3092
return 1 0 3095
assign 1 0 3098
assign 1 0 3102
return 1 0 3106
return 1 0 3109
assign 1 0 3112
assign 1 0 3116
return 1 0 3120
return 1 0 3123
assign 1 0 3126
assign 1 0 3130
return 1 0 3134
return 1 0 3137
assign 1 0 3140
assign 1 0 3144
return 1 0 3148
return 1 0 3151
assign 1 0 3154
assign 1 0 3158
return 1 0 3162
return 1 0 3165
assign 1 0 3168
assign 1 0 3172
return 1 0 3176
return 1 0 3179
assign 1 0 3182
assign 1 0 3186
return 1 0 3190
return 1 0 3193
assign 1 0 3196
assign 1 0 3200
return 1 0 3204
return 1 0 3207
assign 1 0 3210
assign 1 0 3214
return 1 0 3218
return 1 0 3221
assign 1 0 3224
assign 1 0 3228
return 1 0 3232
return 1 0 3235
assign 1 0 3238
assign 1 0 3242
return 1 0 3246
return 1 0 3249
assign 1 0 3252
assign 1 0 3256
return 1 0 3260
return 1 0 3263
assign 1 0 3266
assign 1 0 3270
return 1 0 3274
return 1 0 3277
assign 1 0 3280
assign 1 0 3284
return 1 0 3288
return 1 0 3291
assign 1 0 3294
assign 1 0 3298
return 1 0 3302
return 1 0 3305
assign 1 0 3308
assign 1 0 3312
return 1 0 3316
return 1 0 3319
assign 1 0 3322
assign 1 0 3326
return 1 0 3330
return 1 0 3333
assign 1 0 3336
assign 1 0 3340
return 1 0 3344
return 1 0 3347
assign 1 0 3350
assign 1 0 3354
return 1 0 3358
assign 1 0 3361
assign 1 0 3365
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -88296803: return bem_codeGetDirect_0();
case 2141967023: return bem_usedLibrarysStrGet_0();
case 345819347: return bem_go_0();
case 200064426: return bem_sharedEmitterGet_0();
case 1844782840: return bem_prepMakeGet_0();
case -1913188372: return bem_compilerGet_0();
case 165019862: return bem_config_0();
case -1278273894: return bem_toAny_0();
case -1265747243: return bem_toBuildGetDirect_0();
case -207569400: return bem_serializeToString_0();
case 2112476178: return bem_usedLibrarysGetDirect_0();
case 431042492: return bem_compilerProfileGetDirect_0();
case -1910476924: return bem_prepMakeGetDirect_0();
case 1194649776: return bem_builtGetDirect_0();
case -1568661365: return bem_codeGet_0();
case 2103480139: return bem_compilerGetDirect_0();
case 1677945789: return bem_printAstElementsGet_0();
case -1019165667: return bem_linkLibArgsGetDirect_0();
case -560094221: return bem_singleCCGet_0();
case 2090199768: return bem_makeGetDirect_0();
case -1043047601: return bem_initLibsGet_0();
case 1216162807: return bem_argsGetDirect_0();
case 1388710286: return bem_saveSynsGet_0();
case -1494610981: return bem_mainNameGet_0();
case 1028311984: return bem_lctokGet_0();
case -566946637: return bem_nlGet_0();
case -496015575: return bem_closeLibrariesGetDirect_0();
case 1609586134: return bem_compilerProfileGet_0();
case -2059348269: return bem_fromFileGetDirect_0();
case 2041574825: return bem_deployUsedLibrariesGetDirect_0();
case -354975821: return bem_fromFileGet_0();
case 492047946: return bem_deployLibraryGet_0();
case -420950445: return bem_saveIdsGet_0();
case 53882535: return bem_initLibsGetDirect_0();
case -1985715612: return bem_parseTimeGet_0();
case 583953660: return bem_printAstGet_0();
case 981126040: return bem_makeNameGet_0();
case -675728835: return bem_buildMessageGetDirect_0();
case -1259828688: return bem_emitFileHeaderGetDirect_0();
case 1892553777: return bem_saveSynsGetDirect_0();
case -111765016: return bem_emitDebugGetDirect_0();
case -24607044: return bem_parseEmitTimeGet_0();
case 303211781: return bem_parseEmitCompileTimeGet_0();
case -2072769323: return bem_includePathGetDirect_0();
case -638442685: return bem_echo_0();
case -1529290633: return bem_runArgsGet_0();
case -1559280870: return bem_loadSynsGetDirect_0();
case 233896038: return bem_deployFilesToGet_0();
case -1308933810: return bem_deserializeClassNameGet_0();
case -1480185847: return bem_argsGet_0();
case 54059089: return bem_usedLibrarysStrGetDirect_0();
case 599887212: return bem_putLineNumbersInTraceGet_0();
case -341669734: return bem_readBufferGetDirect_0();
case -139125553: return bem_estrGet_0();
case 1702337498: return bem_printAllAstGetDirect_0();
case 1611055106: return bem_fieldNamesGet_0();
case -755653151: return bem_printStepsGetDirect_0();
case -751633144: return bem_deployLibraryGetDirect_0();
case 1975679076: return bem_doEmitGetDirect_0();
case -1152665740: return bem_mainNameGetDirect_0();
case 1828302548: return bem_paramsGet_0();
case -953805503: return bem_makeArgsGetDirect_0();
case -970583860: return bem_emitterGet_0();
case -217835874: return bem_tagGet_0();
case -811845461: return bem_linkLibArgsGet_0();
case 357537975: return bem_classNameGet_0();
case 1569758791: return bem_deployPathGetDirect_0();
case -1221361765: return bem_deployFilesToGetDirect_0();
case 2085038713: return bem_printStepsGet_0();
case 1585988974: return bem_outputPlatformGetDirect_0();
case 1287519130: return bem_runGet_0();
case -2110904559: return bem_deployUsedLibrariesGet_0();
case 595149727: return bem_ownProcessGet_0();
case 1792915466: return bem_twtokGetDirect_0();
case -1293771106: return bem_extIncludesGet_0();
case -744660417: return bem_builtGet_0();
case -434303464: return bem_emitCommonGet_0();
case -1968882644: return bem_lctokGetDirect_0();
case -1893083178: return bem_ccObjArgsGet_0();
case 349113250: return bem_emitFlagsGetDirect_0();
case -915808255: return bem_serializationIteratorGet_0();
case 1305769386: return bem_parseTimeGetDirect_0();
case 1934552751: return bem_newlineGet_0();
case 1533719312: return bem_ntypesGet_0();
case -1116479513: return bem_constantsGet_0();
case -1935322841: return bem_constantsGetDirect_0();
case 1605051782: return bem_libNameGet_0();
case 1606301561: return bem_makeArgsGet_0();
case 1502061771: return bem_emitDataGetDirect_0();
case -1621954218: return bem_emitPathGetDirect_0();
case 847337627: return bem_copy_0();
case -1036503536: return bem_singleCCGetDirect_0();
case 2080865844: return bem_platformGetDirect_0();
case -879406408: return bem_printPlacesGetDirect_0();
case 1230302912: return bem_hashGet_0();
case -1705408796: return bem_putLineNumbersInTraceGetDirect_0();
case -1376384216: return bem_usedLibrarysGet_0();
case -397559289: return bem_fieldIteratorGet_0();
case 298093315: return bem_doEmitGet_0();
case -380767960: return bem_includePathGet_0();
case 1045943593: return bem_toBuildGet_0();
case -1999072435: return bem_emitLangsGetDirect_0();
case 1397848375: return bem_closeLibrariesStrGetDirect_0();
case -507124439: return bem_new_0();
case 167808347: return bem_closeLibrariesGet_0();
case 290285068: return bem_genOnlyGet_0();
case -480687649: return bem_print_0();
case 1314743108: return bem_emitLibraryGet_0();
case -2060798695: return bem_emitFlagsGet_0();
case 641582958: return bem_emitCs_0();
case -1450886: return bem_buildMessageGet_0();
case -1273515126: return bem_emitPathGet_0();
case -1301893502: return bem_ownProcessGetDirect_0();
case 346235852: return bem_sourceFileNameGet_0();
case -1523405557: return bem_saveIdsGetDirect_0();
case -1412718074: return bem_emitLibraryGetDirect_0();
case 1317709356: return bem_parseGet_0();
case -1957156212: return bem_closeLibrariesStrGet_0();
case 1674590206: return bem_sharedEmitterGetDirect_0();
case -1290571007: return bem_makeGet_0();
case -1794766539: return bem_emitDataGet_0();
case 730167154: return bem_parseEmitTimeGetDirect_0();
case -1629544591: return bem_many_0();
case -1577153866: return bem_genOnlyGetDirect_0();
case -364583912: return bem_buildSucceededGet_0();
case -999782352: return bem_main_0();
case 2114100124: return bem_paramsGetDirect_0();
case 1981654959: return bem_once_0();
case 1577636851: return bem_printAstElementsGetDirect_0();
case -1574253133: return bem_loadSynsGet_0();
case 718789172: return bem_iteratorGet_0();
case -1898768337: return bem_printAllAstGet_0();
case -1672746855: return bem_makeNameGetDirect_0();
case -1433582010: return bem_deployFilesFromGetDirect_0();
case 1033769892: return bem_readBufferGet_0();
case 120253898: return bem_buildSucceededGetDirect_0();
case -126564541: return bem_ccObjArgsGetDirect_0();
case 1772823118: return bem_deployPathGet_0();
case -23163398: return bem_platformGet_0();
case -79309885: return bem_extIncludesGetDirect_0();
case 262018309: return bem_emitLangsGet_0();
case 381000357: return bem_twtokGet_0();
case -1050319970: return bem_emitDebugGet_0();
case -1502036655: return bem_doWhat_0();
case -598962250: return bem_buildPathGet_0();
case 1069855588: return bem_ntypesGetDirect_0();
case -1381547145: return bem_startTimeGet_0();
case -354322123: return bem_buildPathGetDirect_0();
case 2117670197: return bem_emitFileHeaderGet_0();
case -1949713802: return bem_printPlacesGet_0();
case -1884228687: return bem_extLinkObjectsGetDirect_0();
case -335837319: return bem_exeNameGet_0();
case 372696200: return bem_extLinkObjectsGet_0();
case -969968805: return bem_setClassesToWrite_0();
case 1716902142: return bem_emitCommonGetDirect_0();
case -360613383: return bem_serializeContents_0();
case -365494854: return bem_extLibsGet_0();
case 1592934325: return bem_parseEmitCompileTimeGetDirect_0();
case -1793824183: return bem_extLibsGetDirect_0();
case -1572641742: return bem_outputPlatformGet_0();
case -2001709932: return bem_runArgsGetDirect_0();
case 1061120821: return bem_deployFilesFromGet_0();
case 1175475926: return bem_printAstGetDirect_0();
case -22393727: return bem_create_0();
case -1548136645: return bem_startTimeGetDirect_0();
case 1636544398: return bem_runGetDirect_0();
case -30202202: return bem_nlGetDirect_0();
case 1744070117: return bem_exeNameGetDirect_0();
case 2098562443: return bem_estrGetDirect_0();
case 2034689224: return bem_parseGetDirect_0();
case -327314699: return bem_newlineGetDirect_0();
case -375391764: return bem_libNameGetDirect_0();
case -1762356041: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -323863221: return bem_startTimeSet_1(bevd_0);
case 321693734: return bem_undef_1(bevd_0);
case -2106988822: return bem_extLibsSetDirect_1(bevd_0);
case -2119527744: return bem_closeLibrariesStrSet_1(bevd_0);
case -1366937444: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -665968375: return bem_sameType_1(bevd_0);
case -1813894210: return bem_paramsSet_1(bevd_0);
case 473811906: return bem_buildSucceededSet_1(bevd_0);
case 1621613436: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 2098755689: return bem_emitFileHeaderSetDirect_1(bevd_0);
case 653662412: return bem_printAstSetDirect_1(bevd_0);
case -1499178296: return bem_ntypesSet_1(bevd_0);
case -2093893203: return bem_newlineSet_1(bevd_0);
case 1570809976: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1401458512: return bem_buildMessageSet_1(bevd_0);
case -1537381646: return bem_emitLangsSet_1(bevd_0);
case 545588986: return bem_makeArgsSetDirect_1(bevd_0);
case 580318355: return bem_otherType_1(bevd_0);
case -453626503: return bem_nlSet_1(bevd_0);
case 798457948: return bem_fromFileSet_1(bevd_0);
case 2141086228: return bem_initLibsSet_1(bevd_0);
case -675723368: return bem_twtokSetDirect_1(bevd_0);
case -95347415: return bem_runArgsSet_1(bevd_0);
case -916244239: return bem_emitPathSetDirect_1(bevd_0);
case -2009109882: return bem_platformSetDirect_1(bevd_0);
case 1612520667: return bem_lctokSet_1(bevd_0);
case -35162086: return bem_emitDataSetDirect_1(bevd_0);
case 838816805: return bem_includePathSetDirect_1(bevd_0);
case 1804820744: return bem_saveSynsSetDirect_1(bevd_0);
case -492673876: return bem_doEmitSetDirect_1(bevd_0);
case 1761986035: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case -1005981282: return bem_sharedEmitterSetDirect_1(bevd_0);
case -1115471313: return bem_genOnlySet_1(bevd_0);
case 1849763669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -436547338: return bem_undefined_1(bevd_0);
case 1222063470: return bem_constantsSet_1(bevd_0);
case 73041524: return bem_loadSynsSet_1(bevd_0);
case -1352794904: return bem_printPlacesSetDirect_1(bevd_0);
case 405892629: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 718034678: return bem_exeNameSet_1(bevd_0);
case -1256041694: return bem_copyTo_1(bevd_0);
case -13927831: return bem_makeNameSetDirect_1(bevd_0);
case -394115464: return bem_exeNameSetDirect_1(bevd_0);
case 618623452: return bem_saveIdsSet_1(bevd_0);
case -1352614639: return bem_saveIdsSetDirect_1(bevd_0);
case -864271267: return bem_singleCCSet_1(bevd_0);
case 1231189820: return bem_printAstSet_1(bevd_0);
case -627108851: return bem_emitFlagsSet_1(bevd_0);
case 1215339792: return bem_usedLibrarysSet_1(bevd_0);
case -523144998: return bem_compilerProfileSetDirect_1(bevd_0);
case -600236277: return bem_emitPathSet_1(bevd_0);
case 82842053: return bem_deployFilesFromSet_1(bevd_0);
case 541530523: return bem_emitDataSet_1(bevd_0);
case -230528415: return bem_emitFileHeaderSet_1(bevd_0);
case -2056947488: return bem_sameClass_1(bevd_0);
case 304494161: return bem_includePathSet_1(bevd_0);
case 1918242033: return bem_estrSetDirect_1(bevd_0);
case 165484033: return bem_printAllAstSet_1(bevd_0);
case -162039820: return bem_parseSet_1(bevd_0);
case -1187472711: return bem_twtokSet_1(bevd_0);
case 2058220505: return bem_codeSetDirect_1(bevd_0);
case -148539655: return bem_parseEmitTimeSet_1(bevd_0);
case -2135908906: return bem_emitCommonSet_1(bevd_0);
case 338656255: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 2035515336: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 120464146: return bem_libNameSet_1(bevd_0);
case 8732840: return bem_buildMessageSetDirect_1(bevd_0);
case 1061915597: return bem_doEmitSet_1(bevd_0);
case 604620942: return bem_doParse_1(bevd_0);
case 1279810075: return bem_ownProcessSet_1(bevd_0);
case 1364663547: return bem_prepMakeSet_1(bevd_0);
case -2024277530: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case 714062015: return bem_deployPathSet_1(bevd_0);
case -2088222308: return bem_sharedEmitterSet_1(bevd_0);
case -1147023045: return bem_buildSucceededSetDirect_1(bevd_0);
case -1661543902: return bem_linkLibArgsSet_1(bevd_0);
case -711833031: return bem_ownProcessSetDirect_1(bevd_0);
case 991411710: return bem_deployLibrarySetDirect_1(bevd_0);
case -1263961885: return bem_otherClass_1(bevd_0);
case -794657115: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 82591981: return bem_fromFileSetDirect_1(bevd_0);
case 1865819141: return bem_linkLibArgsSetDirect_1(bevd_0);
case 1153881816: return bem_compilerSet_1(bevd_0);
case -1808225266: return bem_startTimeSetDirect_1(bevd_0);
case -1115072658: return bem_saveSynsSet_1(bevd_0);
case 1756402674: return bem_builtSet_1(bevd_0);
case 962469508: return bem_codeSet_1(bevd_0);
case 592700335: return bem_argsSetDirect_1(bevd_0);
case -333093581: return bem_closeLibrariesSetDirect_1(bevd_0);
case 1387628079: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1896136018: return bem_ntypesSetDirect_1(bevd_0);
case 79035797: return bem_printStepsSetDirect_1(bevd_0);
case 697925000: return bem_readBufferSet_1(bevd_0);
case -2017818326: return bem_deployLibrarySet_1(bevd_0);
case -415812673: return bem_platformSet_1(bevd_0);
case 1022952671: return bem_usedLibrarysStrSet_1(bevd_0);
case 362414197: return bem_printStepsSet_1(bevd_0);
case 2114988362: return bem_toBuildSetDirect_1(bevd_0);
case -1729293842: return bem_extLibsSet_1(bevd_0);
case -1363121221: return bem_emitLibrarySet_1(bevd_0);
case -1924243205: return bem_getSynNp_1(bevd_0);
case 1418552655: return bem_def_1(bevd_0);
case 22005837: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 899395183: return bem_deployFilesToSetDirect_1(bevd_0);
case 143590068: return bem_singleCCSetDirect_1(bevd_0);
case 216083253: return bem_compilerSetDirect_1(bevd_0);
case -789742377: return bem_outputPlatformSet_1(bevd_0);
case -1283582169: return bem_paramsSetDirect_1(bevd_0);
case 1921003966: return bem_outputPlatformSetDirect_1(bevd_0);
case -2118243615: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case -547248171: return bem_usedLibrarysSetDirect_1(bevd_0);
case 1075981883: return bem_initLibsSetDirect_1(bevd_0);
case 2042926160: return bem_buildSyns_1(bevd_0);
case -764857255: return bem_parseTimeSetDirect_1(bevd_0);
case 1395451908: return bem_deployFilesFromSetDirect_1(bevd_0);
case -408502512: return bem_equals_1(bevd_0);
case -2110054273: return bem_buildPathSetDirect_1(bevd_0);
case -817968622: return bem_printAllAstSetDirect_1(bevd_0);
case -1269877213: return bem_mainNameSetDirect_1(bevd_0);
case -1759815774: return bem_deployUsedLibrariesSet_1(bevd_0);
case -115414910: return bem_lctokSetDirect_1(bevd_0);
case 427131447: return bem_printPlacesSet_1(bevd_0);
case -124120909: return bem_deployFilesToSet_1(bevd_0);
case 1887421687: return bem_emitCommonSetDirect_1(bevd_0);
case -423137440: return bem_compilerProfileSet_1(bevd_0);
case -1006768520: return bem_extIncludesSetDirect_1(bevd_0);
case 961949934: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -1106181565: return bem_emitLangsSetDirect_1(bevd_0);
case 1530291279: return bem_sameObject_1(bevd_0);
case -719984511: return bem_toBuildSet_1(bevd_0);
case 160154802: return bem_parseTimeSet_1(bevd_0);
case -664533880: return bem_deployPathSetDirect_1(bevd_0);
case 1597997258: return bem_nlSetDirect_1(bevd_0);
case -2033399171: return bem_genOnlySetDirect_1(bevd_0);
case 558724485: return bem_prepMakeSetDirect_1(bevd_0);
case -2075551011: return bem_emitDebugSet_1(bevd_0);
case -450481188: return bem_ccObjArgsSet_1(bevd_0);
case 2071814394: return bem_loadSynsSetDirect_1(bevd_0);
case 1787128072: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2038932384: return bem_estrSet_1(bevd_0);
case 2014052444: return bem_makeSet_1(bevd_0);
case -526050897: return bem_printAstElementsSet_1(bevd_0);
case -891607167: return bem_extLinkObjectsSet_1(bevd_0);
case 460570504: return bem_mainNameSet_1(bevd_0);
case -1746765803: return bem_parseEmitTimeSetDirect_1(bevd_0);
case 1379835000: return bem_defined_1(bevd_0);
case 2126955183: return bem_parseSetDirect_1(bevd_0);
case 18614636: return bem_emitFlagsSetDirect_1(bevd_0);
case -1811038058: return bem_ccObjArgsSetDirect_1(bevd_0);
case 1273353241: return bem_notEquals_1(bevd_0);
case -1389906830: return bem_newlineSetDirect_1(bevd_0);
case -43589199: return bem_makeSetDirect_1(bevd_0);
case 446639633: return bem_emitDebugSetDirect_1(bevd_0);
case 191452406: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case -938099827: return bem_argsSet_1(bevd_0);
case -605322282: return bem_runArgsSetDirect_1(bevd_0);
case -68684603: return bem_buildPathSet_1(bevd_0);
case -245915600: return bem_builtSetDirect_1(bevd_0);
case 433494986: return bem_readBufferSetDirect_1(bevd_0);
case -2072763681: return bem_runSetDirect_1(bevd_0);
case 2076237668: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case -953125256: return bem_makeArgsSet_1(bevd_0);
case 1063805988: return bem_constantsSetDirect_1(bevd_0);
case 2044870284: return bem_runSet_1(bevd_0);
case 834092314: return bem_printAstElementsSetDirect_1(bevd_0);
case 2124174833: return bem_extIncludesSet_1(bevd_0);
case -1860813946: return bem_makeNameSet_1(bevd_0);
case 1749558909: return bem_libNameSetDirect_1(bevd_0);
case 2016747511: return bem_emitLibrarySetDirect_1(bevd_0);
case 1372293718: return bem_closeLibrariesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1376937021: return bem_buildLiteral_2(bevd_0, bevd_1);
case -318431301: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 554632540: return bem_getSyn_2(bevd_0, bevd_1);
case 1138830036: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -799307739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1103544796: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -554397969: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1922702423: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 975610887: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2122183893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
