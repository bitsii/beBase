package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_8_DbDirStore extends BEC_2_6_6_SystemObject {
public BEC_2_2_8_DbDirStore() { }
private static byte[] becc_BEC_2_2_8_DbDirStore_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_BEC_2_2_8_DbDirStore_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_0 = {};
public static BEC_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_inst;

public static BET_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_type;

public BEC_2_6_10_SystemSerializer bevp_ser;
public BEC_3_2_4_4_IOFilePath bevp_storageDir;
public BEC_2_6_6_SystemObject bevp_keyEncoder;
public BEC_2_2_8_DbDirStore bem_new_2(BEC_2_4_6_TextString beva_storageDir, BEC_2_6_6_SystemObject beva__keyEncoder) throws Throwable {
bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_new_1(BEC_2_4_6_TextString beva_storageDir) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
bem_pathNew_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__storageDir) throws Throwable {
bevp_ser = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getStoreId_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_keyEncoder == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 372*/ {
bevl_storeId = (BEC_2_4_6_TextString) bevp_keyEncoder.bemd_1(88670244, beva_id);
} /* Line: 373*/
 else /* Line: 374*/ {
bevl_storeId = beva_id;
} /* Line: 375*/
return bevl_storeId;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_getPath_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_8_DbDirStore_bels_0));
bevt_2_ta_ph = beva_id.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 382*/
 else /* Line: 382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 382*/ {
bevt_6_ta_ph = bevp_storageDir.bem_fileGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_existsGet_0();
if (bevt_5_ta_ph.bevi_bool) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_7_ta_ph = bevp_storageDir.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 384*/
bevl_storeId = (BEC_2_4_6_TextString) bem_getStoreId_1(beva_id);
bevt_8_ta_ph = bevp_storageDir.bem_copy_0();
bevl_p = (BEC_3_2_4_4_IOFilePath) bevt_8_ta_ph.bem_addStep_1(bevl_storeId);
} /* Line: 387*/
return bevl_p;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 393*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_8_DbDirStore_bels_0));
bevt_2_ta_ph = beva_id.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 393*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 393*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 393*/
 else /* Line: 393*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 393*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 395*/ {
bevt_7_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_writerGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(909332085);
bevp_ser.bem_serialize_2(beva_object, bevt_5_ta_ph);
bevt_9_ta_ph = bevl_p.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevt_8_ta_ph.bemd_0(1344525652);
} /* Line: 397*/
} /* Line: 395*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_6_6_SystemObject bevl_object = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_2_4_IOFile bevt_12_ta_ph = null;
if (beva_id == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 403*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_8_DbDirStore_bels_0));
bevt_3_ta_ph = beva_id.bem_notEquals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 403*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 403*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 403*/
 else /* Line: 403*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 403*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 405*/ {
bevt_7_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_existsGet_0();
if (bevt_6_ta_ph.bevi_bool)/* Line: 405*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 405*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 405*/
 else /* Line: 405*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 405*/ {
bevt_10_ta_ph = bevl_p.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_readerGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(909332085);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_ta_ph);
bevt_12_ta_ph = bevl_p.bem_fileGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_readerGet_0();
bevt_11_ta_ph.bemd_0(1344525652);
return bevl_object;
} /* Line: 408*/
} /* Line: 405*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 415*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_8_DbDirStore_bels_0));
bevt_2_ta_ph = beva_id.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 415*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 415*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 415*/
bevl_p = bem_getPath_1(beva_id);
bevt_6_ta_ph = bevl_p.bem_fileGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_existsGet_0();
if (bevt_5_ta_ph.bevi_bool)/* Line: 417*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 418*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_delete_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_2_4_IOFile bevt_0_ta_ph = null;
bevl_p = bem_getPath_1(beva_id);
bevt_0_ta_ph = bevl_p.bem_fileGet_0();
bevt_0_ta_ph.bem_delete_0();
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serGet_0() throws Throwable {
return bevp_ser;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_serGetDirect_0() throws Throwable {
return bevp_ser;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_serSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_serSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_storageDirGet_0() throws Throwable {
return bevp_storageDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_storageDirGetDirect_0() throws Throwable {
return bevp_storageDir;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_storageDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_storageDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyEncoderGet_0() throws Throwable {
return bevp_keyEncoder;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_keyEncoderGetDirect_0() throws Throwable {
return bevp_keyEncoder;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_keyEncoderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_keyEncoder = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_keyEncoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_keyEncoder = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {354, 355, 359, 359, 364, 365, 366, 372, 372, 373, 375, 377, 382, 382, 382, 382, 0, 0, 0, 383, 383, 383, 383, 384, 384, 386, 387, 387, 389, 393, 393, 393, 393, 0, 0, 0, 394, 395, 395, 396, 396, 396, 396, 397, 397, 397, 403, 403, 403, 403, 0, 0, 0, 404, 405, 405, 405, 405, 0, 0, 0, 406, 406, 406, 406, 407, 407, 407, 408, 411, 415, 415, 0, 415, 415, 0, 0, 415, 415, 416, 417, 417, 418, 418, 420, 420, 424, 425, 425, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 22, 23, 27, 28, 29, 35, 40, 41, 44, 46, 60, 65, 66, 67, 69, 72, 76, 79, 80, 81, 86, 87, 88, 90, 91, 92, 94, 108, 113, 114, 115, 117, 120, 124, 127, 128, 133, 134, 135, 136, 137, 138, 139, 140, 161, 166, 167, 168, 170, 173, 177, 180, 181, 186, 187, 188, 190, 193, 197, 200, 201, 202, 203, 204, 205, 206, 207, 210, 223, 228, 229, 232, 233, 235, 238, 242, 243, 245, 246, 247, 249, 250, 252, 253, 258, 259, 260, 264, 267, 270, 274, 278, 281, 284, 288, 292, 295, 298, 302};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 354 16
assign 1 355 17
assign 1 359 22
apNew 1 359 22
pathNew 1 359 23
assign 1 364 27
new 0 364 27
assign 1 365 28
assign 1 366 29
assign 1 372 35
def 1 372 40
assign 1 373 41
encode 1 373 41
assign 1 375 44
return 1 377 46
assign 1 382 60
def 1 382 65
assign 1 382 66
new 0 382 66
assign 1 382 67
notEquals 1 382 67
assign 1 0 69
assign 1 0 72
assign 1 0 76
assign 1 383 79
fileGet 0 383 79
assign 1 383 80
existsGet 0 383 80
assign 1 383 81
not 0 383 86
assign 1 384 87
fileGet 0 384 87
makeDirs 0 384 88
assign 1 386 90
getStoreId 1 386 90
assign 1 387 91
copy 0 387 91
assign 1 387 92
addStep 1 387 92
return 1 389 94
assign 1 393 108
def 1 393 113
assign 1 393 114
new 0 393 114
assign 1 393 115
notEquals 1 393 115
assign 1 0 117
assign 1 0 120
assign 1 0 124
assign 1 394 127
getPath 1 394 127
assign 1 395 128
def 1 395 133
assign 1 396 134
fileGet 0 396 134
assign 1 396 135
writerGet 0 396 135
assign 1 396 136
open 0 396 136
serialize 2 396 137
assign 1 397 138
fileGet 0 397 138
assign 1 397 139
writerGet 0 397 139
close 0 397 140
assign 1 403 161
def 1 403 166
assign 1 403 167
new 0 403 167
assign 1 403 168
notEquals 1 403 168
assign 1 0 170
assign 1 0 173
assign 1 0 177
assign 1 404 180
getPath 1 404 180
assign 1 405 181
def 1 405 186
assign 1 405 187
fileGet 0 405 187
assign 1 405 188
existsGet 0 405 188
assign 1 0 190
assign 1 0 193
assign 1 0 197
assign 1 406 200
fileGet 0 406 200
assign 1 406 201
readerGet 0 406 201
assign 1 406 202
open 0 406 202
assign 1 406 203
deserialize 1 406 203
assign 1 407 204
fileGet 0 407 204
assign 1 407 205
readerGet 0 407 205
close 0 407 206
return 1 408 207
return 1 411 210
assign 1 415 223
undef 1 415 228
assign 1 0 229
assign 1 415 232
new 0 415 232
assign 1 415 233
equals 1 415 233
assign 1 0 235
assign 1 0 238
assign 1 415 242
new 0 415 242
return 1 415 243
assign 1 416 245
getPath 1 416 245
assign 1 417 246
fileGet 0 417 246
assign 1 417 247
existsGet 0 417 247
assign 1 418 249
new 0 418 249
return 1 418 250
assign 1 420 252
new 0 420 252
return 1 420 253
assign 1 424 258
getPath 1 424 258
assign 1 425 259
fileGet 0 425 259
delete 0 425 260
return 1 0 264
return 1 0 267
assign 1 0 270
assign 1 0 274
return 1 0 278
return 1 0 281
assign 1 0 284
assign 1 0 288
return 1 0 292
return 1 0 295
assign 1 0 298
assign 1 0 302
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1718188704: return bem_hashGet_0();
case 807655445: return bem_print_0();
case 807652135: return bem_serGetDirect_0();
case -677150073: return bem_toString_0();
case 1342623754: return bem_copy_0();
case 247576523: return bem_classNameGet_0();
case -2124354635: return bem_serializeToString_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case -636148769: return bem_keyEncoderGet_0();
case 308625140: return bem_storageDirGetDirect_0();
case -543330026: return bem_fieldNamesGet_0();
case -225222698: return bem_create_0();
case 2066839134: return bem_iteratorGet_0();
case 498101216: return bem_echo_0();
case 556565361: return bem_serializationIteratorGet_0();
case -1749437314: return bem_tagGet_0();
case 524094754: return bem_storageDirGet_0();
case 172684789: return bem_keyEncoderGetDirect_0();
case 126387064: return bem_new_0();
case 1765675337: return bem_serGet_0();
case 409380620: return bem_fieldIteratorGet_0();
case -1794485421: return bem_serializeContents_0();
case 398187407: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1502842604: return bem_def_1(bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case 1954378938: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 483583497: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case 181157527: return bem_keyEncoderSet_1(bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case 1997957511: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case -404194174: return bem_copyTo_1(bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case -1031842373: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case 1770175602: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 733540198: return bem_serSet_1(bevd_0);
case 2030640584: return bem_keyEncoderSetDirect_1(bevd_0);
case -739474824: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case -1313981726: return bem_storageDirSet_1(bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case -1180006819: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
case 1998377134: return bem_storageDirSetDirect_1(bevd_0);
case -99772608: return bem_serSetDirect_1(bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -627787012: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1576081835: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_2_8_DbDirStore_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_8_DbDirStore_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_8_DbDirStore();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst = (BEC_2_2_8_DbDirStore) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_type;
}
}
