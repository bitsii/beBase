package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_8_DbDirStore extends BEC_2_6_6_SystemObject {
public BEC_2_2_8_DbDirStore() { }
private static byte[] becc_BEC_2_2_8_DbDirStore_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_BEC_2_2_8_DbDirStore_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_0 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
public static BEC_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_inst;

public static BET_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_type;

public BEC_2_6_10_SystemSerializer bevp_ser;
public BEC_3_2_4_4_IOFilePath bevp_storageDir;
public BEC_2_6_6_SystemObject bevp_keyEncoder;
public BEC_2_2_8_DbDirStore bem_new_2(BEC_2_4_6_TextString beva_storageDir, BEC_2_6_6_SystemObject beva__keyEncoder) throws Throwable {
bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_new_1(BEC_2_4_6_TextString beva_storageDir) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
bem_pathNew_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__storageDir) throws Throwable {
bevp_ser = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getStoreId_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_keyEncoder == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 372*/ {
bevl_storeId = (BEC_2_4_6_TextString) bevp_keyEncoder.bemd_1(-1415567029, beva_id);
} /* Line: 373*/
 else /* Line: 374*/ {
bevl_storeId = beva_id;
} /* Line: 375*/
return bevl_storeId;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_getPath_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_3_ta_ph = bece_BEC_2_2_8_DbDirStore_bevo_0;
bevt_2_ta_ph = beva_id.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 382*/
 else /* Line: 382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 382*/ {
bevt_6_ta_ph = bevp_storageDir.bem_fileGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_existsGet_0();
if (bevt_5_ta_ph.bevi_bool) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_7_ta_ph = bevp_storageDir.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 384*/
bevl_storeId = (BEC_2_4_6_TextString) bem_getStoreId_1(beva_id);
bevt_8_ta_ph = bevp_storageDir.bem_copy_0();
bevl_p = (BEC_3_2_4_4_IOFilePath) bevt_8_ta_ph.bem_addStep_1(bevl_storeId);
} /* Line: 387*/
return bevl_p;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 393*/ {
bevt_3_ta_ph = bece_BEC_2_2_8_DbDirStore_bevo_1;
bevt_2_ta_ph = beva_id.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 393*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 393*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 393*/
 else /* Line: 393*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 393*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 395*/ {
bevt_7_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_writerGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(1587354648);
bevp_ser.bem_serialize_2(beva_object, bevt_5_ta_ph);
bevt_9_ta_ph = bevl_p.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevt_8_ta_ph.bemd_0(-68577615);
} /* Line: 397*/
} /* Line: 395*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_6_6_SystemObject bevl_object = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_2_4_IOFile bevt_12_ta_ph = null;
if (beva_id == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 403*/ {
bevt_4_ta_ph = bece_BEC_2_2_8_DbDirStore_bevo_2;
bevt_3_ta_ph = beva_id.bem_notEquals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 403*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 403*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 403*/
 else /* Line: 403*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 403*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 405*/ {
bevt_7_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_existsGet_0();
if (bevt_6_ta_ph.bevi_bool)/* Line: 405*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 405*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 405*/
 else /* Line: 405*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 405*/ {
bevt_10_ta_ph = bevl_p.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_readerGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1587354648);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_ta_ph);
bevt_12_ta_ph = bevl_p.bem_fileGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_readerGet_0();
bevt_11_ta_ph.bemd_0(-68577615);
return bevl_object;
} /* Line: 408*/
} /* Line: 405*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 415*/ {
bevt_3_ta_ph = bece_BEC_2_2_8_DbDirStore_bevo_3;
bevt_2_ta_ph = beva_id.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 415*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 415*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 415*/
bevl_p = bem_getPath_1(beva_id);
bevt_6_ta_ph = bevl_p.bem_fileGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_existsGet_0();
if (bevt_5_ta_ph.bevi_bool)/* Line: 417*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 418*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_delete_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_2_4_IOFile bevt_0_ta_ph = null;
bevl_p = bem_getPath_1(beva_id);
bevt_0_ta_ph = bevl_p.bem_fileGet_0();
bevt_0_ta_ph.bem_delete_0();
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serGet_0() throws Throwable {
return bevp_ser;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_serGetDirect_0() throws Throwable {
return bevp_ser;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_serSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_serSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_storageDirGet_0() throws Throwable {
return bevp_storageDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_storageDirGetDirect_0() throws Throwable {
return bevp_storageDir;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_storageDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_storageDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyEncoderGet_0() throws Throwable {
return bevp_keyEncoder;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_keyEncoderGetDirect_0() throws Throwable {
return bevp_keyEncoder;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_keyEncoderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_keyEncoder = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_keyEncoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_keyEncoder = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {354, 355, 359, 359, 364, 365, 366, 372, 372, 373, 375, 377, 382, 382, 382, 382, 0, 0, 0, 383, 383, 383, 383, 384, 384, 386, 387, 387, 389, 393, 393, 393, 393, 0, 0, 0, 394, 395, 395, 396, 396, 396, 396, 397, 397, 397, 403, 403, 403, 403, 0, 0, 0, 404, 405, 405, 405, 405, 0, 0, 0, 406, 406, 406, 406, 407, 407, 407, 408, 411, 415, 415, 0, 415, 415, 0, 0, 415, 415, 416, 417, 417, 418, 418, 420, 420, 424, 425, 425, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 26, 27, 31, 32, 33, 39, 44, 45, 48, 50, 64, 69, 70, 71, 73, 76, 80, 83, 84, 85, 90, 91, 92, 94, 95, 96, 98, 112, 117, 118, 119, 121, 124, 128, 131, 132, 137, 138, 139, 140, 141, 142, 143, 144, 165, 170, 171, 172, 174, 177, 181, 184, 185, 190, 191, 192, 194, 197, 201, 204, 205, 206, 207, 208, 209, 210, 211, 214, 227, 232, 233, 236, 237, 239, 242, 246, 247, 249, 250, 251, 253, 254, 256, 257, 262, 263, 264, 268, 271, 274, 278, 282, 285, 288, 292, 296, 299, 302, 306};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 354 20
assign 1 355 21
assign 1 359 26
apNew 1 359 26
pathNew 1 359 27
assign 1 364 31
new 0 364 31
assign 1 365 32
assign 1 366 33
assign 1 372 39
def 1 372 44
assign 1 373 45
encode 1 373 45
assign 1 375 48
return 1 377 50
assign 1 382 64
def 1 382 69
assign 1 382 70
new 0 382 70
assign 1 382 71
notEquals 1 382 71
assign 1 0 73
assign 1 0 76
assign 1 0 80
assign 1 383 83
fileGet 0 383 83
assign 1 383 84
existsGet 0 383 84
assign 1 383 85
not 0 383 90
assign 1 384 91
fileGet 0 384 91
makeDirs 0 384 92
assign 1 386 94
getStoreId 1 386 94
assign 1 387 95
copy 0 387 95
assign 1 387 96
addStep 1 387 96
return 1 389 98
assign 1 393 112
def 1 393 117
assign 1 393 118
new 0 393 118
assign 1 393 119
notEquals 1 393 119
assign 1 0 121
assign 1 0 124
assign 1 0 128
assign 1 394 131
getPath 1 394 131
assign 1 395 132
def 1 395 137
assign 1 396 138
fileGet 0 396 138
assign 1 396 139
writerGet 0 396 139
assign 1 396 140
open 0 396 140
serialize 2 396 141
assign 1 397 142
fileGet 0 397 142
assign 1 397 143
writerGet 0 397 143
close 0 397 144
assign 1 403 165
def 1 403 170
assign 1 403 171
new 0 403 171
assign 1 403 172
notEquals 1 403 172
assign 1 0 174
assign 1 0 177
assign 1 0 181
assign 1 404 184
getPath 1 404 184
assign 1 405 185
def 1 405 190
assign 1 405 191
fileGet 0 405 191
assign 1 405 192
existsGet 0 405 192
assign 1 0 194
assign 1 0 197
assign 1 0 201
assign 1 406 204
fileGet 0 406 204
assign 1 406 205
readerGet 0 406 205
assign 1 406 206
open 0 406 206
assign 1 406 207
deserialize 1 406 207
assign 1 407 208
fileGet 0 407 208
assign 1 407 209
readerGet 0 407 209
close 0 407 210
return 1 408 211
return 1 411 214
assign 1 415 227
undef 1 415 232
assign 1 0 233
assign 1 415 236
new 0 415 236
assign 1 415 237
equals 1 415 237
assign 1 0 239
assign 1 0 242
assign 1 415 246
new 0 415 246
return 1 415 247
assign 1 416 249
getPath 1 416 249
assign 1 417 250
fileGet 0 417 250
assign 1 417 251
existsGet 0 417 251
assign 1 418 253
new 0 418 253
return 1 418 254
assign 1 420 256
new 0 420 256
return 1 420 257
assign 1 424 262
getPath 1 424 262
assign 1 425 263
fileGet 0 425 263
delete 0 425 264
return 1 0 268
return 1 0 271
assign 1 0 274
assign 1 0 278
return 1 0 282
return 1 0 285
assign 1 0 288
assign 1 0 292
return 1 0 296
return 1 0 299
assign 1 0 302
assign 1 0 306
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1613180546: return bem_keyEncoderGet_0();
case -777537417: return bem_serializeContents_0();
case 221458969: return bem_serializeToString_0();
case -1238524057: return bem_print_0();
case -1332467552: return bem_keyEncoderGetDirect_0();
case 2071247075: return bem_sourceFileNameGet_0();
case 1327611495: return bem_serGetDirect_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 310047227: return bem_fieldNamesGet_0();
case 814015164: return bem_copy_0();
case -1079456517: return bem_many_0();
case -992634121: return bem_tagGet_0();
case 205150354: return bem_new_0();
case 993286746: return bem_echo_0();
case -1426056679: return bem_hashGet_0();
case 440040110: return bem_storageDirGetDirect_0();
case 137910263: return bem_create_0();
case 78412540: return bem_toAny_0();
case -1292542595: return bem_serGet_0();
case -1392846471: return bem_toString_0();
case -257587556: return bem_storageDirGet_0();
case 217381802: return bem_serializationIteratorGet_0();
case -438289515: return bem_fieldIteratorGet_0();
case -1714583788: return bem_classNameGet_0();
case -1331626162: return bem_iteratorGet_0();
case -1851472893: return bem_once_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 945769885: return bem_sameClass_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -202882393: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 203452863: return bem_keyEncoderSet_1(bevd_0);
case -1492085360: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1742042817: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1497198914: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case -1436106280: return bem_storageDirSetDirect_1(bevd_0);
case 1784380521: return bem_serSetDirect_1(bevd_0);
case -128747274: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 359828056: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 1902738199: return bem_serSet_1(bevd_0);
case 2064429440: return bem_keyEncoderSetDirect_1(bevd_0);
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 1774491315: return bem_storageDirSet_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case -271728426: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -523562161: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -436671793: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_2_8_DbDirStore_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_8_DbDirStore_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_8_DbDirStore();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst = (BEC_2_2_8_DbDirStore) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_type;
}
}
