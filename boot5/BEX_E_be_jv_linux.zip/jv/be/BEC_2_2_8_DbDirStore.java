package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_8_DbDirStore extends BEC_2_6_6_SystemObject {
public BEC_2_2_8_DbDirStore() { }
private static byte[] becc_BEC_2_2_8_DbDirStore_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_BEC_2_2_8_DbDirStore_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_0 = {};
public static BEC_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_inst;

public static BET_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_type;

public BEC_2_6_10_SystemSerializer bevp_ser;
public BEC_3_2_4_4_IOFilePath bevp_storageDir;
public BEC_2_6_6_SystemObject bevp_keyEncoder;
public BEC_2_2_8_DbDirStore bem_new_2(BEC_2_4_6_TextString beva_storageDir, BEC_2_6_6_SystemObject beva__keyEncoder) throws Throwable {
bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_new_1(BEC_2_4_6_TextString beva_storageDir) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
bem_pathNew_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__storageDir) throws Throwable {
bevp_ser = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getStoreId_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_keyEncoder == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 405*/ {
bevl_storeId = (BEC_2_4_6_TextString) bevp_keyEncoder.bemd_1(-1008095659, beva_id);
} /* Line: 406*/
 else /* Line: 407*/ {
bevl_storeId = beva_id;
} /* Line: 408*/
return bevl_storeId;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_getPath_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 415*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_8_DbDirStore_bels_0));
bevt_2_ta_ph = beva_id.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 415*/
 else /* Line: 415*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 415*/ {
bevt_6_ta_ph = bevp_storageDir.bem_fileGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_existsGet_0();
if (bevt_5_ta_ph.bevi_bool) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_7_ta_ph = bevp_storageDir.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 417*/
bevl_storeId = (BEC_2_4_6_TextString) bem_getStoreId_1(beva_id);
bevt_8_ta_ph = bevp_storageDir.bem_copy_0();
bevl_p = (BEC_3_2_4_4_IOFilePath) bevt_8_ta_ph.bem_addStep_1(bevl_storeId);
} /* Line: 420*/
return bevl_p;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 426*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_8_DbDirStore_bels_0));
bevt_2_ta_ph = beva_id.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 426*/
 else /* Line: 426*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 426*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 428*/ {
bevt_7_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_writerGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(-979793239);
bevp_ser.bem_serialize_2(beva_object, bevt_5_ta_ph);
bevt_9_ta_ph = bevl_p.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevt_8_ta_ph.bemd_0(1914804496);
} /* Line: 430*/
} /* Line: 428*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_6_6_SystemObject bevl_object = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_2_4_IOFile bevt_12_ta_ph = null;
if (beva_id == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 436*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_8_DbDirStore_bels_0));
bevt_3_ta_ph = beva_id.bem_notEquals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 436*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 436*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 436*/
 else /* Line: 436*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 436*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_7_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_existsGet_0();
if (bevt_6_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 438*/
 else /* Line: 438*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 438*/ {
bevt_10_ta_ph = bevl_p.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_readerGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-979793239);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_ta_ph);
bevt_12_ta_ph = bevl_p.bem_fileGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_readerGet_0();
bevt_11_ta_ph.bemd_0(1914804496);
return bevl_object;
} /* Line: 441*/
} /* Line: 438*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 448*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 448*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_8_DbDirStore_bels_0));
bevt_2_ta_ph = beva_id.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 448*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 448*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 448*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 448*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 448*/
bevl_p = bem_getPath_1(beva_id);
bevt_6_ta_ph = bevl_p.bem_fileGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_existsGet_0();
if (bevt_5_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 451*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_remove_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_2_4_IOFile bevt_0_ta_ph = null;
bevl_p = bem_getPath_1(beva_id);
bevt_0_ta_ph = bevl_p.bem_fileGet_0();
bevt_0_ta_ph.bem_delete_0();
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serGet_0() throws Throwable {
return bevp_ser;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_serSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_storageDirGet_0() throws Throwable {
return bevp_storageDir;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_storageDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyEncoderGet_0() throws Throwable {
return bevp_keyEncoder;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_keyEncoderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_keyEncoder = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {387, 388, 392, 392, 397, 398, 399, 405, 405, 406, 408, 410, 415, 415, 415, 415, 0, 0, 0, 416, 416, 416, 416, 417, 417, 419, 420, 420, 422, 426, 426, 426, 426, 0, 0, 0, 427, 428, 428, 429, 429, 429, 429, 430, 430, 430, 436, 436, 436, 436, 0, 0, 0, 437, 438, 438, 438, 438, 0, 0, 0, 439, 439, 439, 439, 440, 440, 440, 441, 444, 448, 448, 0, 448, 448, 0, 0, 448, 448, 449, 450, 450, 451, 451, 453, 453, 457, 458, 458, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 22, 23, 27, 28, 29, 35, 40, 41, 44, 46, 60, 65, 66, 67, 69, 72, 76, 79, 80, 81, 86, 87, 88, 90, 91, 92, 94, 108, 113, 114, 115, 117, 120, 124, 127, 128, 133, 134, 135, 136, 137, 138, 139, 140, 161, 166, 167, 168, 170, 173, 177, 180, 181, 186, 187, 188, 190, 193, 197, 200, 201, 202, 203, 204, 205, 206, 207, 210, 223, 228, 229, 232, 233, 235, 238, 242, 243, 245, 246, 247, 249, 250, 252, 253, 258, 259, 260, 264, 267, 271, 274, 278, 281};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 387 16
assign 1 388 17
assign 1 392 22
apNew 1 392 22
pathNew 1 392 23
assign 1 397 27
new 0 397 27
assign 1 398 28
assign 1 399 29
assign 1 405 35
def 1 405 40
assign 1 406 41
encode 1 406 41
assign 1 408 44
return 1 410 46
assign 1 415 60
def 1 415 65
assign 1 415 66
new 0 415 66
assign 1 415 67
notEquals 1 415 67
assign 1 0 69
assign 1 0 72
assign 1 0 76
assign 1 416 79
fileGet 0 416 79
assign 1 416 80
existsGet 0 416 80
assign 1 416 81
not 0 416 86
assign 1 417 87
fileGet 0 417 87
makeDirs 0 417 88
assign 1 419 90
getStoreId 1 419 90
assign 1 420 91
copy 0 420 91
assign 1 420 92
addStep 1 420 92
return 1 422 94
assign 1 426 108
def 1 426 113
assign 1 426 114
new 0 426 114
assign 1 426 115
notEquals 1 426 115
assign 1 0 117
assign 1 0 120
assign 1 0 124
assign 1 427 127
getPath 1 427 127
assign 1 428 128
def 1 428 133
assign 1 429 134
fileGet 0 429 134
assign 1 429 135
writerGet 0 429 135
assign 1 429 136
open 0 429 136
serialize 2 429 137
assign 1 430 138
fileGet 0 430 138
assign 1 430 139
writerGet 0 430 139
close 0 430 140
assign 1 436 161
def 1 436 166
assign 1 436 167
new 0 436 167
assign 1 436 168
notEquals 1 436 168
assign 1 0 170
assign 1 0 173
assign 1 0 177
assign 1 437 180
getPath 1 437 180
assign 1 438 181
def 1 438 186
assign 1 438 187
fileGet 0 438 187
assign 1 438 188
existsGet 0 438 188
assign 1 0 190
assign 1 0 193
assign 1 0 197
assign 1 439 200
fileGet 0 439 200
assign 1 439 201
readerGet 0 439 201
assign 1 439 202
open 0 439 202
assign 1 439 203
deserialize 1 439 203
assign 1 440 204
fileGet 0 440 204
assign 1 440 205
readerGet 0 440 205
close 0 440 206
return 1 441 207
return 1 444 210
assign 1 448 223
undef 1 448 228
assign 1 0 229
assign 1 448 232
new 0 448 232
assign 1 448 233
equals 1 448 233
assign 1 0 235
assign 1 0 238
assign 1 448 242
new 0 448 242
return 1 448 243
assign 1 449 245
getPath 1 449 245
assign 1 450 246
fileGet 0 450 246
assign 1 450 247
existsGet 0 450 247
assign 1 451 249
new 0 451 249
return 1 451 250
assign 1 453 252
new 0 453 252
return 1 453 253
assign 1 457 258
getPath 1 457 258
assign 1 458 259
fileGet 0 458 259
delete 0 458 260
return 1 0 264
assign 1 0 267
return 1 0 271
assign 1 0 274
return 1 0 278
assign 1 0 281
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1978701672: return bem_iteratorGet_0();
case 992700193: return bem_copy_0();
case 1836285625: return bem_new_0();
case -745370670: return bem_keyEncoderGet_0();
case 308156191: return bem_storageDirGet_0();
case -10560512: return bem_toString_0();
case 1230276296: return bem_hashGet_0();
case 275969005: return bem_serGet_0();
case -1250586953: return bem_create_0();
case 1293883485: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1759643859: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case 1409349899: return bem_undef_1(bevd_0);
case 907966167: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 52329100: return bem_copyTo_1(bevd_0);
case 2071260442: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case 715512076: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 452869449: return bem_serSet_1(bevd_0);
case -305715842: return bem_notEquals_1(bevd_0);
case 1483312357: return bem_remove_1((BEC_2_4_6_TextString) bevd_0);
case -1926574247: return bem_def_1(bevd_0);
case -277954027: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 854308449: return bem_storageDirSet_1(bevd_0);
case -1978152287: return bem_print_1(bevd_0);
case 850514472: return bem_equals_1(bevd_0);
case -237010923: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -1506813782: return bem_keyEncoderSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1974138487: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1686468839: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1007047738: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -127109256: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 530385415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1507992233: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_2_8_DbDirStore_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_8_DbDirStore_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_8_DbDirStore();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst = (BEC_2_2_8_DbDirStore) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_type;
}
}
