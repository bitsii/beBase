package be;
/* IO:File: source/build/Pass1.be */
public final class BEC_3_5_5_5_BuildVisitPass1 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass1() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_0 = {};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_1 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_1, 1));
public static BEC_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;

public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_allAstElements;
public BEC_2_6_6_SystemObject bevp_f;
public BEC_2_4_6_TextString bevp_inClass;
public BEC_2_4_6_TextString bevp_inClassMethod;
public BEC_3_5_5_5_BuildVisitPass1 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_new_2(BEC_2_9_3_ContainerSet beva__printAstElements, BEC_2_4_6_TextString beva__fname) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
bevp_printAstElements = beva__printAstElements;
bevp_allAstElements = bevp_printAstElements.bem_isEmptyGet_0();
if (beva__fname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevt_3_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva__fname);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_writerGet_0();
bevp_f = bevt_1_tmpany_phold.bemd_0(-2145436361);
} /* Line: 26 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_inLine = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_46_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_5_tmpany_phold.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_sameType_1(bevt_9_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 36 */ {
bevp_inClass = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 37 */
 else  /* Line: 38 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1548759582);
bevp_inClass = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bemd_0(2036147796);
} /* Line: 39 */
bevp_inClassMethod = null;
bevl_inLine = null;
} /* Line: 42 */
bevt_13_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_14_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_13_tmpany_phold.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 44 */ {
if (bevp_inClass == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 44 */
 else  /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 44 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_18_tmpany_phold = beva_node.bem_heldGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_sameType_1(bevt_18_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevp_inClassMethod = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 46 */
 else  /* Line: 45 */ {
bevt_21_tmpany_phold = beva_node.bem_heldGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(963489153);
if (bevt_20_tmpany_phold == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_23_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_0;
bevt_22_tmpany_phold = bevp_inClass.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(963489153);
bevp_inClassMethod = bevt_22_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
} /* Line: 48 */
 else  /* Line: 45 */ {
bevt_28_tmpany_phold = beva_node.bem_heldGet_0();
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-1284507729);
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_30_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_1;
bevt_29_tmpany_phold = bevp_inClass.bem_add_1(bevt_30_tmpany_phold);
bevt_32_tmpany_phold = beva_node.bem_heldGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_0(-1284507729);
bevp_inClassMethod = bevt_29_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
} /* Line: 50 */
} /* Line: 45 */
} /* Line: 45 */
} /* Line: 45 */
if (bevp_inClassMethod == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 54 */ {
bevt_35_tmpany_phold = beva_node.bem_nlcGet_0();
if (bevt_35_tmpany_phold == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 54 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 54 */
 else  /* Line: 54 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 54 */ {
bevt_37_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_2;
bevt_36_tmpany_phold = bevp_inClassMethod.bem_add_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = beva_node.bem_nlcGet_0();
bevl_inLine = bevt_36_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
} /* Line: 55 */
if (bevp_allAstElements.bevi_bool) /* Line: 57 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
if (bevp_inClassMethod == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_40_tmpany_phold = bevp_printAstElements.bem_has_1(bevp_inClassMethod);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
if (bevl_inLine == null) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_42_tmpany_phold = bevp_printAstElements.bem_has_1(bevl_inLine);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 57 */ {
if (bevp_f == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_44_tmpany_phold = beva_node.bem_toString_0();
bevp_f.bemd_1(770248313, bevt_44_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_newlineGet_0();
bevp_f.bemd_1(770248313, bevt_45_tmpany_phold);
} /* Line: 60 */
 else  /* Line: 61 */ {
beva_node.bem_print_0();
} /* Line: 62 */
} /* Line: 58 */
bevt_47_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_47_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAstElementsGet_0() throws Throwable {
return bevp_allAstElements;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_allAstElementsGetDirect_0() throws Throwable {
return bevp_allAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fGet_0() throws Throwable {
return bevp_f;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fGetDirect_0() throws Throwable {
return bevp_f;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_fSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_f = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_fSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_f = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public final BEC_2_4_6_TextString bem_inClassGetDirect_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassMethodGet_0() throws Throwable {
return bevp_inClassMethod;
} /*method end*/
public final BEC_2_4_6_TextString bem_inClassMethodGetDirect_0() throws Throwable {
return bevp_inClassMethod;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 25, 26, 26, 26, 26, 35, 35, 35, 35, 36, 36, 36, 37, 39, 39, 39, 41, 42, 44, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 45, 46, 47, 47, 47, 47, 48, 48, 48, 48, 48, 49, 49, 49, 49, 50, 50, 50, 50, 50, 54, 54, 54, 54, 54, 0, 0, 0, 55, 55, 55, 55, 0, 57, 57, 57, 0, 0, 0, 0, 0, 0, 57, 57, 57, 0, 0, 0, 0, 0, 58, 58, 59, 59, 60, 60, 60, 62, 65, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 30, 31, 36, 37, 38, 39, 40, 94, 95, 96, 101, 102, 103, 104, 106, 109, 110, 111, 113, 114, 116, 117, 118, 123, 124, 129, 130, 133, 137, 140, 141, 142, 144, 147, 148, 149, 154, 155, 156, 157, 158, 159, 162, 163, 164, 169, 170, 171, 172, 173, 174, 179, 184, 185, 186, 191, 192, 195, 199, 202, 203, 204, 205, 208, 211, 216, 217, 219, 222, 226, 229, 232, 236, 239, 244, 245, 247, 250, 254, 257, 260, 264, 269, 270, 271, 272, 273, 274, 277, 280, 281, 284, 287, 290, 294, 298, 301, 304, 308, 312, 315, 318, 322, 326, 329, 332, 336, 340, 343, 346, 350};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 29
assign 1 24 30
isEmptyGet 0 24 30
assign 1 25 31
def 1 25 36
assign 1 26 37
new 1 26 37
assign 1 26 38
fileGet 0 26 38
assign 1 26 39
writerGet 0 26 39
assign 1 26 40
open 0 26 40
assign 1 35 94
typenameGet 0 35 94
assign 1 35 95
CLASSGet 0 35 95
assign 1 35 96
equals 1 35 101
assign 1 36 102
new 0 36 102
assign 1 36 103
heldGet 0 36 103
assign 1 36 104
sameType 1 36 104
assign 1 37 106
heldGet 0 37 106
assign 1 39 109
heldGet 0 39 109
assign 1 39 110
namepathGet 0 39 110
assign 1 39 111
toString 0 39 111
assign 1 41 113
assign 1 42 114
assign 1 44 116
typenameGet 0 44 116
assign 1 44 117
METHODGet 0 44 117
assign 1 44 118
equals 1 44 123
assign 1 44 124
def 1 44 129
assign 1 0 130
assign 1 0 133
assign 1 0 137
assign 1 45 140
new 0 45 140
assign 1 45 141
heldGet 0 45 141
assign 1 45 142
sameType 1 45 142
assign 1 46 144
heldGet 0 46 144
assign 1 47 147
heldGet 0 47 147
assign 1 47 148
orgNameGet 0 47 148
assign 1 47 149
def 1 47 154
assign 1 48 155
new 0 48 155
assign 1 48 156
add 1 48 156
assign 1 48 157
heldGet 0 48 157
assign 1 48 158
orgNameGet 0 48 158
assign 1 48 159
add 1 48 159
assign 1 49 162
heldGet 0 49 162
assign 1 49 163
nameGet 0 49 163
assign 1 49 164
def 1 49 169
assign 1 50 170
new 0 50 170
assign 1 50 171
add 1 50 171
assign 1 50 172
heldGet 0 50 172
assign 1 50 173
nameGet 0 50 173
assign 1 50 174
add 1 50 174
assign 1 54 179
def 1 54 184
assign 1 54 185
nlcGet 0 54 185
assign 1 54 186
def 1 54 191
assign 1 0 192
assign 1 0 195
assign 1 0 199
assign 1 55 202
new 0 55 202
assign 1 55 203
add 1 55 203
assign 1 55 204
nlcGet 0 55 204
assign 1 55 205
add 1 55 205
assign 1 0 208
assign 1 57 211
def 1 57 216
assign 1 57 217
has 1 57 217
assign 1 0 219
assign 1 0 222
assign 1 0 226
assign 1 0 229
assign 1 0 232
assign 1 0 236
assign 1 57 239
def 1 57 244
assign 1 57 245
has 1 57 245
assign 1 0 247
assign 1 0 250
assign 1 0 254
assign 1 0 257
assign 1 0 260
assign 1 58 264
def 1 58 269
assign 1 59 270
toString 0 59 270
write 1 59 271
assign 1 60 272
new 0 60 272
assign 1 60 273
newlineGet 0 60 273
write 1 60 274
print 0 62 277
assign 1 65 280
nextDescendGet 0 65 280
return 1 65 281
return 1 0 284
return 1 0 287
assign 1 0 290
assign 1 0 294
return 1 0 298
return 1 0 301
assign 1 0 304
assign 1 0 308
return 1 0 312
return 1 0 315
assign 1 0 318
assign 1 0 322
return 1 0 326
return 1 0 329
assign 1 0 332
assign 1 0 336
return 1 0 340
return 1 0 343
assign 1 0 346
assign 1 0 350
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1737009900: return bem_many_0();
case 2102651338: return bem_fieldIteratorGet_0();
case -1551806822: return bem_toAny_0();
case -1439875774: return bem_new_0();
case 1201799861: return bem_serializeToString_0();
case -1759630984: return bem_classNameGet_0();
case 653341959: return bem_print_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case -904680778: return bem_buildGetDirect_0();
case 718229932: return bem_allAstElementsGetDirect_0();
case 997252144: return bem_printAstElementsGet_0();
case -831283656: return bem_inClassGetDirect_0();
case -923573178: return bem_fGet_0();
case -1514848875: return bem_inClassMethodGetDirect_0();
case -90594128: return bem_transGet_0();
case -878179779: return bem_buildGet_0();
case -1301091886: return bem_constGet_0();
case 1604237807: return bem_inClassMethodGet_0();
case 532047870: return bem_constGetDirect_0();
case -114079936: return bem_serializeContents_0();
case 298218513: return bem_ntypesGetDirect_0();
case -1195111829: return bem_create_0();
case 2036147796: return bem_toString_0();
case 1941684587: return bem_fGetDirect_0();
case -1748925107: return bem_echo_0();
case 980643754: return bem_inClassGet_0();
case 791125970: return bem_allAstElementsGet_0();
case 967277716: return bem_printAstElementsGetDirect_0();
case 573647971: return bem_iteratorGet_0();
case 191896611: return bem_copy_0();
case -1066226610: return bem_fieldNamesGet_0();
case 1525639803: return bem_sourceFileNameGet_0();
case 1188285097: return bem_transGetDirect_0();
case -1500978633: return bem_tagGet_0();
case 76102507: return bem_ntypesGet_0();
case 1430998361: return bem_serializationIteratorGet_0();
case -1976480232: return bem_once_0();
case -2072472298: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -807148816: return bem_inClassMethodSetDirect_1(bevd_0);
case 110728819: return bem_fSetDirect_1(bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case -192271885: return bem_equals_1(bevd_0);
case 1664039386: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1060492374: return bem_allAstElementsSet_1(bevd_0);
case 1883050496: return bem_inClassMethodSet_1(bevd_0);
case -1751215994: return bem_inClassSetDirect_1(bevd_0);
case -1556728538: return bem_allAstElementsSetDirect_1(bevd_0);
case -1508758513: return bem_buildSet_1(bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1508932546: return bem_inClassSet_1(bevd_0);
case -1011557663: return bem_constSetDirect_1(bevd_0);
case -1510220279: return bem_fSet_1(bevd_0);
case 618012114: return bem_buildSetDirect_1(bevd_0);
case -98987572: return bem_end_1(bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
case -102295312: return bem_sameObject_1(bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1725945273: return bem_ntypesSet_1(bevd_0);
case 1138947652: return bem_transSetDirect_1(bevd_0);
case 91382750: return bem_ntypesSetDirect_1(bevd_0);
case 884462515: return bem_def_1(bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case -1109701375: return bem_transSet_1(bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case -1247329303: return bem_printAstElementsSet_1(bevd_0);
case -343635918: return bem_constSet_1(bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
case -704193884: return bem_printAstElementsSetDirect_1(bevd_0);
case 1746804248: return bem_begin_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2112530015: return bem_new_2((BEC_2_9_3_ContainerSet) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass1_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass1_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass1();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst = (BEC_3_5_5_5_BuildVisitPass1) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;
}
}
