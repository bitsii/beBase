package be;
/* IO:File: source/build/Pass1.be */
public final class BEC_3_5_5_5_BuildVisitPass1 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass1() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_0 = {};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_1 = {0x2E};
public static BEC_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;

public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_allAstElements;
public BEC_2_6_6_SystemObject bevp_f;
public BEC_2_4_6_TextString bevp_inClass;
public BEC_2_4_6_TextString bevp_inClassMethod;
public BEC_3_5_5_5_BuildVisitPass1 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_new_2(BEC_2_9_3_ContainerSet beva__printAstElements, BEC_2_4_6_TextString beva__fname) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_2_4_IOFile bevt_2_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_3_ta_ph = null;
bevp_printAstElements = beva__printAstElements;
bevp_allAstElements = bevp_printAstElements.bem_isEmptyGet_0();
if (beva__fname == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_3_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva__fname);
bevt_2_ta_ph = bevt_3_ta_ph.bem_fileGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_writerGet_0();
bevp_f = bevt_1_ta_ph.bemd_0(278268582);
} /* Line: 26*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_inLine = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_7_TextStrings bevt_48_ta_ph = null;
BEC_2_5_4_BuildNode bevt_49_ta_ph = null;
bevt_5_ta_ph = beva_node.bem_typenameGet_0();
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_5_ta_ph.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 35*/ {
bevt_8_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_9_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_10_ta_ph = beva_node.bem_heldGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_sameType_2(bevt_9_ta_ph, bevt_10_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 36*/ {
bevp_inClass = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 37*/
 else /* Line: 38*/ {
bevt_12_ta_ph = beva_node.bem_heldGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(1293397616);
bevp_inClass = (BEC_2_4_6_TextString) bevt_11_ta_ph.bemd_0(186551951);
} /* Line: 39*/
bevp_inClassMethod = null;
bevl_inLine = null;
} /* Line: 42*/
bevt_14_ta_ph = beva_node.bem_typenameGet_0();
bevt_15_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_14_ta_ph.bevi_int == bevt_15_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevp_inClass == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_18_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_19_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_20_ta_ph = beva_node.bem_heldGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_sameType_2(bevt_19_ta_ph, bevt_20_ta_ph);
if (bevt_17_ta_ph.bevi_bool)/* Line: 45*/ {
bevp_inClassMethod = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 46*/
 else /* Line: 45*/ {
bevt_23_ta_ph = beva_node.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(1443240795);
if (bevt_22_ta_ph == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_24_ta_ph = bevp_inClass.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = beva_node.bem_heldGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bemd_0(1443240795);
bevp_inClassMethod = bevt_24_ta_ph.bem_add_1(bevt_26_ta_ph);
} /* Line: 48*/
 else /* Line: 45*/ {
bevt_30_ta_ph = beva_node.bem_heldGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(-1934031533);
if (bevt_29_ta_ph == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_31_ta_ph = bevp_inClass.bem_add_1(bevt_32_ta_ph);
bevt_34_ta_ph = beva_node.bem_heldGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bemd_0(-1934031533);
bevp_inClassMethod = bevt_31_ta_ph.bem_add_1(bevt_33_ta_ph);
} /* Line: 50*/
} /* Line: 45*/
} /* Line: 45*/
} /* Line: 45*/
if (bevp_inClassMethod == null) {
bevt_35_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_35_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_37_ta_ph = beva_node.bem_nlcGet_0();
if (bevt_37_ta_ph == null) {
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 54*/
 else /* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 54*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_38_ta_ph = bevp_inClassMethod.bem_add_1(bevt_39_ta_ph);
bevt_40_ta_ph = beva_node.bem_nlcGet_0();
bevl_inLine = bevt_38_ta_ph.bem_add_1(bevt_40_ta_ph);
} /* Line: 55*/
if (bevp_allAstElements.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
if (bevp_inClassMethod == null) {
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_42_ta_ph = bevp_printAstElements.bem_has_1(bevp_inClassMethod);
if (bevt_42_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
if (bevl_inLine == null) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_44_ta_ph = bevp_printAstElements.bem_has_1(bevl_inLine);
if (bevt_44_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 57*/ {
if (bevp_f == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 58*/ {
bevt_46_ta_ph = beva_node.bem_toString_0();
bevp_f.bemd_1(1789305204, bevt_46_ta_ph);
bevt_48_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_47_ta_ph = bevt_48_ta_ph.bem_newlineGet_0();
bevp_f.bemd_1(1789305204, bevt_47_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
beva_node.bem_print_0();
} /* Line: 62*/
} /* Line: 58*/
bevt_49_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_49_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAstElementsGet_0() throws Throwable {
return bevp_allAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fGet_0() throws Throwable {
return bevp_f;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_fSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_f = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassMethodGet_0() throws Throwable {
return bevp_inClassMethod;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 25, 26, 26, 26, 26, 35, 35, 35, 35, 36, 36, 36, 36, 37, 39, 39, 39, 41, 42, 44, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 45, 45, 46, 47, 47, 47, 47, 48, 48, 48, 48, 48, 49, 49, 49, 49, 50, 50, 50, 50, 50, 54, 54, 54, 54, 54, 0, 0, 0, 55, 55, 55, 55, 0, 57, 57, 57, 0, 0, 0, 0, 0, 0, 57, 57, 57, 0, 0, 0, 0, 0, 58, 58, 59, 59, 60, 60, 60, 62, 65, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 33, 34, 35, 36, 37, 93, 94, 95, 100, 101, 102, 103, 104, 106, 109, 110, 111, 113, 114, 116, 117, 118, 123, 124, 129, 130, 133, 137, 140, 141, 142, 143, 145, 148, 149, 150, 155, 156, 157, 158, 159, 160, 163, 164, 165, 170, 171, 172, 173, 174, 175, 180, 185, 186, 187, 192, 193, 196, 200, 203, 204, 205, 206, 209, 212, 217, 218, 220, 223, 227, 230, 233, 237, 240, 245, 246, 248, 251, 255, 258, 261, 265, 270, 271, 272, 273, 274, 275, 278, 281, 282, 285, 288, 292, 295, 299, 302, 306, 309, 313, 316};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 26
assign 1 24 27
isEmptyGet 0 24 27
assign 1 25 28
def 1 25 33
assign 1 26 34
new 1 26 34
assign 1 26 35
fileGet 0 26 35
assign 1 26 36
writerGet 0 26 36
assign 1 26 37
open 0 26 37
assign 1 35 93
typenameGet 0 35 93
assign 1 35 94
CLASSGet 0 35 94
assign 1 35 95
equals 1 35 100
assign 1 36 101
new 0 36 101
assign 1 36 102
new 0 36 102
assign 1 36 103
heldGet 0 36 103
assign 1 36 104
sameType 2 36 104
assign 1 37 106
heldGet 0 37 106
assign 1 39 109
heldGet 0 39 109
assign 1 39 110
namepathGet 0 39 110
assign 1 39 111
toString 0 39 111
assign 1 41 113
assign 1 42 114
assign 1 44 116
typenameGet 0 44 116
assign 1 44 117
METHODGet 0 44 117
assign 1 44 118
equals 1 44 123
assign 1 44 124
def 1 44 129
assign 1 0 130
assign 1 0 133
assign 1 0 137
assign 1 45 140
new 0 45 140
assign 1 45 141
new 0 45 141
assign 1 45 142
heldGet 0 45 142
assign 1 45 143
sameType 2 45 143
assign 1 46 145
heldGet 0 46 145
assign 1 47 148
heldGet 0 47 148
assign 1 47 149
orgNameGet 0 47 149
assign 1 47 150
def 1 47 155
assign 1 48 156
new 0 48 156
assign 1 48 157
add 1 48 157
assign 1 48 158
heldGet 0 48 158
assign 1 48 159
orgNameGet 0 48 159
assign 1 48 160
add 1 48 160
assign 1 49 163
heldGet 0 49 163
assign 1 49 164
nameGet 0 49 164
assign 1 49 165
def 1 49 170
assign 1 50 171
new 0 50 171
assign 1 50 172
add 1 50 172
assign 1 50 173
heldGet 0 50 173
assign 1 50 174
nameGet 0 50 174
assign 1 50 175
add 1 50 175
assign 1 54 180
def 1 54 185
assign 1 54 186
nlcGet 0 54 186
assign 1 54 187
def 1 54 192
assign 1 0 193
assign 1 0 196
assign 1 0 200
assign 1 55 203
new 0 55 203
assign 1 55 204
add 1 55 204
assign 1 55 205
nlcGet 0 55 205
assign 1 55 206
add 1 55 206
assign 1 0 209
assign 1 57 212
def 1 57 217
assign 1 57 218
has 1 57 218
assign 1 0 220
assign 1 0 223
assign 1 0 227
assign 1 0 230
assign 1 0 233
assign 1 0 237
assign 1 57 240
def 1 57 245
assign 1 57 246
has 1 57 246
assign 1 0 248
assign 1 0 251
assign 1 0 255
assign 1 0 258
assign 1 0 261
assign 1 58 265
def 1 58 270
assign 1 59 271
toString 0 59 271
write 1 59 272
assign 1 60 273
new 0 60 273
assign 1 60 274
newlineGet 0 60 274
write 1 60 275
print 0 62 278
assign 1 65 281
nextDescendGet 0 65 281
return 1 65 282
return 1 0 285
assign 1 0 288
return 1 0 292
assign 1 0 295
return 1 0 299
assign 1 0 302
return 1 0 306
assign 1 0 309
return 1 0 313
assign 1 0 316
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2139846672: return bem_print_0();
case -44508337: return bem_allAstElementsGet_0();
case 1890623763: return bem_copy_0();
case -1655584324: return bem_inClassGet_0();
case 1515047198: return bem_create_0();
case 1179078689: return bem_constGet_0();
case -382723170: return bem_transGet_0();
case 1252372914: return bem_inClassMethodGet_0();
case -712351806: return bem_buildGet_0();
case -1967481250: return bem_hashGet_0();
case 641179090: return bem_fGet_0();
case -643744552: return bem_iteratorGet_0();
case 670650041: return bem_new_0();
case -1545451149: return bem_ntypesGet_0();
case -711987358: return bem_printAstElementsGet_0();
case 186551951: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 7869303: return bem_equals_1(bevd_0);
case 951741113: return bem_notEquals_1(bevd_0);
case -1876852691: return bem_def_1(bevd_0);
case 715546820: return bem_allAstElementsSet_1(bevd_0);
case -924354049: return bem_transSet_1(bevd_0);
case 266044734: return bem_printAstElementsSet_1(bevd_0);
case 1380966042: return bem_end_1(bevd_0);
case -1583823897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1644238154: return bem_inClassSet_1(bevd_0);
case 1041331381: return bem_undef_1(bevd_0);
case 582683348: return bem_inClassMethodSet_1(bevd_0);
case -233548354: return bem_begin_1(bevd_0);
case -645974690: return bem_fSet_1(bevd_0);
case 1846677851: return bem_constSet_1(bevd_0);
case -44126037: return bem_ntypesSet_1(bevd_0);
case 1882156513: return bem_copyTo_1(bevd_0);
case 754787161: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -874794247: return bem_buildSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1779285405: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 582832509: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -881314990: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1602342275: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1356996215: return bem_new_2((BEC_2_9_3_ContainerSet) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1686414234: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass1_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass1_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass1();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst = (BEC_3_5_5_5_BuildVisitPass1) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;
}
}
