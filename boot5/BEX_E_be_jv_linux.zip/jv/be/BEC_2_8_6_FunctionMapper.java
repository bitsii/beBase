package be;
/* IO:File: source/base/Functions.be */
public final class BEC_2_8_6_FunctionMapper extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_FunctionMapper() { }
private static byte[] becc_BEC_2_8_6_FunctionMapper_clname = {0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x3A,0x4D,0x61,0x70,0x70,0x65,0x72};
private static byte[] becc_BEC_2_8_6_FunctionMapper_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_8_6_FunctionMapper bece_BEC_2_8_6_FunctionMapper_bevs_inst;

public static BET_2_8_6_FunctionMapper bece_BEC_2_8_6_FunctionMapper_bevs_type;

public BEC_2_8_6_FunctionMapper bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapCopy_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemMethod beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = beva_input.bemd_0(814015164);
bevt_0_ta_ph = bem_map_2(bevt_1_ta_ph, beva_action);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_map_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemObject beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_input.bemd_0(-1331626162);
bem_mapIterator_2(bevt_0_ta_ph, (BEC_2_6_6_SystemMethod) beva_action );
return beva_input;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_mapIterator_2(BEC_2_6_6_SystemObject beva_iter, BEC_2_6_6_SystemMethod beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[2];
while (true)
/* Line: 23*/ {
bevt_0_ta_ph = beva_iter.bemd_0(1590161492);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 23*/ {
bevt_2_ta_ph = beva_iter.bemd_0(-920607504);
bevd_x[0] = bevt_2_ta_ph;
bevt_1_ta_ph = beva_action.bem_forwardCall_2(new BEC_2_4_6_TextString("apply".getBytes("UTF-8")), (new BEC_2_9_4_ContainerList(bevd_x, 1)).bem_copy_0());
beva_iter.bemd_1(-2097197724, bevt_1_ta_ph);
} /* Line: 24*/
 else /* Line: 23*/ {
break;
} /* Line: 23*/
} /* Line: 23*/
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 14, 14, 18, 18, 19, 23, 24, 24, 24};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 22, 26, 27, 28, 37, 39, 40, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 20
copy 0 14 20
assign 1 14 21
map 2 14 21
return 1 14 22
assign 1 18 26
iteratorGet 0 18 26
mapIterator 2 18 27
return 1 19 28
assign 1 23 37
hasNextGet 0 23 37
assign 1 24 39
nextGet 0 24 39
assign 1 24 40
apply 1 24 40
currentSet 1 24 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 310047227: return bem_fieldNamesGet_0();
case 221458969: return bem_serializeToString_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 78412540: return bem_toAny_0();
case -1079456517: return bem_many_0();
case -992634121: return bem_tagGet_0();
case -1238524057: return bem_print_0();
case -1851472893: return bem_once_0();
case -777537417: return bem_serializeContents_0();
case -1714583788: return bem_classNameGet_0();
case 205150354: return bem_new_0();
case -1331626162: return bem_iteratorGet_0();
case 217381802: return bem_serializationIteratorGet_0();
case 814015164: return bem_copy_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -1392846471: return bem_toString_0();
case -438289515: return bem_fieldIteratorGet_0();
case -1426056679: return bem_hashGet_0();
case 993286746: return bem_echo_0();
case 137910263: return bem_create_0();
case -1201862288: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 945769885: return bem_sameClass_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1690162757: return bem_mapIterator_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1407734889: return bem_mapCopy_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case -1846192379: return bem_map_2(bevd_0, bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_FunctionMapper_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_8_6_FunctionMapper_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_FunctionMapper();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst = (BEC_2_8_6_FunctionMapper) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_type;
}
}
