package be;
public class BET_2_5_9_BuildConstants extends BETS_Object {
public BET_2_5_9_BuildConstants() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "prepare_0", "twtokGet_0", "twtokSet_1", "matchMapGet_0", "matchMapSet_1", "rwordsGet_0", "rwordsSet_1", "maxargsGet_0", "maxargsSet_1", "extraSlotsGet_0", "extraSlotsSet_1", "mtdxPadGet_0", "mtdxPadSet_1", "ntypesGet_0", "ntypesSet_1", "unwindToGet_0", "unwindToSet_1", "unwindOkGet_0", "unwindOkSet_1", "operGet_0", "operSet_1", "operNamesGet_0", "operNamesSet_1", "conTypesGet_0", "conTypesSet_1", "parensReqGet_0", "parensReqSet_1", "anchorTypesGet_0", "anchorTypesSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "twtok", "matchMap", "rwords", "maxargs", "extraSlots", "mtdxPad", "ntypes", "unwindTo", "unwindOk", "oper", "operNames", "conTypes", "parensReq", "anchorTypes" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_9_BuildConstants();
}
}
