package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerSets extends BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerSets() { }
private static byte[] becc_BEC_2_9_4_ContainerSets_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x73};
private static byte[] becc_BEC_2_9_4_ContainerSets_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerSets_bevo_0 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_inst;

public static BET_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_type;

public BEC_2_9_4_ContainerSets bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_9_3_ContainerSet bevl_set = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = beva_list.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_9_4_ContainerSets_bevo_0;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_multiply_1(bevt_3_tmpany_phold);
bevl_set = (new BEC_2_9_3_ContainerSet()).bem_new_1(bevt_1_tmpany_phold);
bevt_0_tmpany_loop = beva_list.bem_iteratorGet_0();
while (true)
 /* Line: 708 */ {
bevt_4_tmpany_phold = bevt_0_tmpany_loop.bemd_0(930592389);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 708 */ {
bevl_v = bevt_0_tmpany_loop.bemd_0(-1219636284);
bevl_set.bem_put_1(bevl_v);
} /* Line: 709 */
 else  /* Line: 708 */ {
break;
} /* Line: 708 */
} /* Line: 708 */
return bevl_set;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {707, 707, 707, 707, 708, 0, 708, 708, 709, 711};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 27, 30, 32, 33, 39};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 707 23
sizeGet 0 707 23
assign 1 707 24
new 0 707 24
assign 1 707 25
multiply 1 707 25
assign 1 707 26
new 1 707 26
assign 1 708 27
iteratorGet 0 0 27
assign 1 708 30
hasNextGet 0 708 30
assign 1 708 32
nextGet 0 708 32
put 1 709 33
return 1 711 39
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -162465408: return bem_classNameGet_0();
case 35710370: return bem_default_0();
case -1118611827: return bem_copy_0();
case 216387563: return bem_many_0();
case 1901482140: return bem_tagGet_0();
case -702348589: return bem_toString_0();
case -275244597: return bem_hashGet_0();
case 1899370103: return bem_echo_0();
case -2036889336: return bem_toAny_0();
case -1528945516: return bem_fieldNamesGet_0();
case -1653065356: return bem_serializeToString_0();
case -1009286812: return bem_iteratorGet_0();
case 1555639231: return bem_print_0();
case -1774143633: return bem_once_0();
case -2101622436: return bem_sourceFileNameGet_0();
case -138934452: return bem_serializationIteratorGet_0();
case -826924838: return bem_fieldIteratorGet_0();
case 357618761: return bem_new_0();
case -716934857: return bem_serializeContents_0();
case 1881523822: return bem_deserializeClassNameGet_0();
case 71860751: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -959745115: return bem_otherType_1(bevd_0);
case -1082439894: return bem_sameObject_1(bevd_0);
case -68723535: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1193778385: return bem_undefined_1(bevd_0);
case 1137403549: return bem_copyTo_1(bevd_0);
case 1353620660: return bem_sameClass_1(bevd_0);
case -2109980302: return bem_undef_1(bevd_0);
case 2082558825: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1339829082: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 66254795: return bem_sameType_1(bevd_0);
case -1903832317: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case 1459678776: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2027670755: return bem_defined_1(bevd_0);
case -2130714868: return bem_equals_1(bevd_0);
case 1325575386: return bem_def_1(bevd_0);
case 814727407: return bem_notEquals_1(bevd_0);
case -1493100314: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 70790709: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020619337: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 163657925: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1186365239: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 686267336: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271558857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1157880701: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerSets_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerSets_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerSets();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst = (BEC_2_9_4_ContainerSets) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_type;
}
}
