package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerSets extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerSets() { }
private static byte[] becc_BEC_2_9_4_ContainerSets_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x73};
private static byte[] becc_BEC_2_9_4_ContainerSets_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerSets_bels_0 = {0x48,0x61,0x6E,0x64,0x6C,0x65,0x72};
public static BEC_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_inst;

public static BET_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_type;

public BEC_2_9_4_ContainerSets bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_9_4_ContainerList bevl_varargs = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_9_4_ContainerSets_bels_0));
beva_name = beva_name.bem_add_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bem_can_2(beva_name, bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 664*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_varargs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_varargs.bem_put_2(bevt_4_ta_ph, beva_args);
bevl_result = bem_invoke_2(beva_name, bevl_varargs);
} /* Line: 667*/
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromList_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_fromHandler_1(beva_list);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromHandler_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_9_3_ContainerSet bevl_set = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = beva_list.bem_sizeGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_ssz = bevt_1_ta_ph.bem_multiply_1(bevt_2_ta_ph);
bevl_ssz.bevi_int++;
bevl_set = (new BEC_2_9_3_ContainerSet()).bem_new_1(bevl_ssz);
bevt_0_ta_loop = beva_list.bem_iteratorGet_0();
while (true)
/* Line: 680*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(1648650429);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 680*/ {
bevl_v = bevt_0_ta_loop.bemd_0(2003722353);
bevl_set.bem_put_1(bevl_v);
} /* Line: 681*/
 else /* Line: 680*/ {
break;
} /* Line: 680*/
} /* Line: 680*/
return bevl_set;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {663, 663, 664, 664, 665, 665, 666, 666, 667, 669, 673, 673, 677, 677, 677, 678, 679, 680, 0, 680, 680, 681, 683};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 34, 38, 39, 49, 50, 51, 52, 53, 54, 54, 57, 59, 60, 66};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 663 23
new 0 663 23
assign 1 663 24
add 1 663 24
assign 1 664 25
new 0 664 25
assign 1 664 26
can 2 664 26
assign 1 665 28
new 0 665 28
assign 1 665 29
new 1 665 29
assign 1 666 30
new 0 666 30
put 2 666 31
assign 1 667 32
invoke 2 667 32
return 1 669 34
assign 1 673 38
fromHandler 1 673 38
return 1 673 39
assign 1 677 49
sizeGet 0 677 49
assign 1 677 50
new 0 677 50
assign 1 677 51
multiply 1 677 51
incrementValue 0 678 52
assign 1 679 53
new 1 679 53
assign 1 680 54
iteratorGet 0 0 54
assign 1 680 57
hasNextGet 0 680 57
assign 1 680 59
nextGet 0 680 59
put 1 681 60
return 1 683 66
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 623573770: return bem_print_0();
case 1010176607: return bem_default_0();
case 1177285854: return bem_copy_0();
case -1282299119: return bem_create_0();
case 546120276: return bem_toString_0();
case -228772832: return bem_iteratorGet_0();
case -1559547014: return bem_hashGet_0();
case -348415913: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 534289483: return bem_equals_1(bevd_0);
case 931409834: return bem_def_1(bevd_0);
case -351786284: return bem_fromHandler_1((BEC_2_9_4_ContainerList) bevd_0);
case -682431481: return bem_copyTo_1(bevd_0);
case 1494013582: return bem_fromList_1((BEC_2_9_4_ContainerList) bevd_0);
case 1566580881: return bem_notEquals_1(bevd_0);
case -1960594051: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -329232359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 192102659: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1722564428: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2033261913: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerSets_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerSets_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerSets();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst = (BEC_2_9_4_ContainerSets) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_type;
}
}
