package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerSets extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerSets() { }
private static byte[] becc_BEC_2_9_4_ContainerSets_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x73};
private static byte[] becc_BEC_2_9_4_ContainerSets_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerSets_bels_0 = {0x48,0x61,0x6E,0x64,0x6C,0x65,0x72};
public static BEC_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_inst;

public static BET_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_type;

public BEC_2_9_4_ContainerSets bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_9_4_ContainerList bevl_varargs = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_9_4_ContainerSets_bels_0));
beva_name = beva_name.bem_add_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bem_can_2(beva_name, bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 674*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_varargs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_varargs.bem_put_2(bevt_4_ta_ph, beva_args);
bevl_result = bem_invoke_2(beva_name, bevl_varargs);
} /* Line: 677*/
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromList_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_fromHandler_1(beva_list);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromHandler_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_9_3_ContainerSet bevl_set = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = beva_list.bem_lengthGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_ssz = bevt_1_ta_ph.bem_multiply_1(bevt_2_ta_ph);
bevl_ssz.bevi_int++;
bevl_set = (new BEC_2_9_3_ContainerSet()).bem_new_1(bevl_ssz);
bevt_0_ta_loop = beva_list.bem_iteratorGet_0();
while (true)
/* Line: 690*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(-972761279);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 690*/ {
bevl_v = bevt_0_ta_loop.bemd_0(857822229);
bevl_set.bem_put_1(bevl_v);
} /* Line: 691*/
 else /* Line: 690*/ {
break;
} /* Line: 690*/
} /* Line: 690*/
return bevl_set;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {673, 673, 674, 674, 675, 675, 676, 676, 677, 679, 683, 683, 687, 687, 687, 688, 689, 690, 0, 690, 690, 691, 693};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 34, 38, 39, 49, 50, 51, 52, 53, 54, 54, 57, 59, 60, 66};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 673 23
new 0 673 23
assign 1 673 24
add 1 673 24
assign 1 674 25
new 0 674 25
assign 1 674 26
can 2 674 26
assign 1 675 28
new 0 675 28
assign 1 675 29
new 1 675 29
assign 1 676 30
new 0 676 30
put 2 676 31
assign 1 677 32
invoke 2 677 32
return 1 679 34
assign 1 683 38
fromHandler 1 683 38
return 1 683 39
assign 1 687 49
lengthGet 0 687 49
assign 1 687 50
new 0 687 50
assign 1 687 51
multiply 1 687 51
incrementValue 0 688 52
assign 1 689 53
new 1 689 53
assign 1 690 54
iteratorGet 0 0 54
assign 1 690 57
hasNextGet 0 690 57
assign 1 690 59
nextGet 0 690 59
put 1 691 60
return 1 693 66
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1250586953: return bem_create_0();
case 992700193: return bem_copy_0();
case 1978701672: return bem_iteratorGet_0();
case 704976374: return bem_default_0();
case 1293883485: return bem_print_0();
case -10560512: return bem_toString_0();
case 1230276296: return bem_hashGet_0();
case 1836285625: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 850514472: return bem_equals_1(bevd_0);
case -305715842: return bem_notEquals_1(bevd_0);
case -1978152287: return bem_print_1(bevd_0);
case 52329100: return bem_copyTo_1(bevd_0);
case -1821073884: return bem_fromList_1((BEC_2_9_4_ContainerList) bevd_0);
case 1409349899: return bem_undef_1(bevd_0);
case -1926574247: return bem_def_1(bevd_0);
case 1830663005: return bem_fromHandler_1((BEC_2_9_4_ContainerList) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1507992233: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1974138487: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1007047738: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 530385415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerSets_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerSets_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerSets();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst = (BEC_2_9_4_ContainerSets) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_type;
}
}
