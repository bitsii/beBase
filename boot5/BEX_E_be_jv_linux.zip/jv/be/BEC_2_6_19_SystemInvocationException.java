package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_19_SystemInvocationException extends BEC_2_6_9_SystemException {
public BEC_2_6_19_SystemInvocationException() { }
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_inst;

public static BET_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -826924838: return bem_fieldIteratorGet_0();
case 216387563: return bem_many_0();
case -138934452: return bem_serializationIteratorGet_0();
case -1233810219: return bem_framesGet_0();
case -474520014: return bem_getFrameText_0();
case -1886343374: return bem_framesTextGetDirect_0();
case 53035583: return bem_framesGetDirect_0();
case -2101622436: return bem_sourceFileNameGet_0();
case 1381691457: return bem_translateEmittedExceptionInner_0();
case -716934857: return bem_serializeContents_0();
case -1774143633: return bem_once_0();
case -702348589: return bem_toString_0();
case -1564571498: return bem_methodNameGet_0();
case 511305286: return bem_translatedGetDirect_0();
case -1009286812: return bem_iteratorGet_0();
case -1782482657: return bem_langGet_0();
case -637983976: return bem_descriptionGetDirect_0();
case 1881523822: return bem_deserializeClassNameGet_0();
case 358660046: return bem_klassNameGetDirect_0();
case 71860751: return bem_create_0();
case 656429508: return bem_fileNameGetDirect_0();
case -1530598490: return bem_translatedGet_0();
case -162465408: return bem_classNameGet_0();
case 1588615001: return bem_emitLangGet_0();
case 354552235: return bem_vvGet_0();
case 754020763: return bem_langGetDirect_0();
case -27142183: return bem_lineNumberGetDirect_0();
case -1105860797: return bem_fileNameGet_0();
case -1051842018: return bem_framesTextGet_0();
case 117025407: return bem_emitLangGetDirect_0();
case 1899370103: return bem_echo_0();
case 1901482140: return bem_tagGet_0();
case -1118611827: return bem_copy_0();
case 357618761: return bem_new_0();
case -910781759: return bem_descriptionGet_0();
case -275244597: return bem_hashGet_0();
case -1653065356: return bem_serializeToString_0();
case -1528945516: return bem_fieldNamesGet_0();
case 1007789702: return bem_vvGetDirect_0();
case -2036889336: return bem_toAny_0();
case 723992303: return bem_methodNameGetDirect_0();
case -782508791: return bem_translateEmittedException_0();
case 1555639231: return bem_print_0();
case 346077569: return bem_lineNumberGet_0();
case -857975774: return bem_klassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1840024447: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -2065733752: return bem_framesSet_1(bevd_0);
case 1490953525: return bem_klassNameSetDirect_1(bevd_0);
case -384373161: return bem_framesTextSet_1(bevd_0);
case 814727407: return bem_notEquals_1(bevd_0);
case -2130714868: return bem_equals_1(bevd_0);
case -424019758: return bem_fileNameSet_1(bevd_0);
case 66254795: return bem_sameType_1(bevd_0);
case -1493100314: return bem_otherClass_1(bevd_0);
case 1193778385: return bem_undefined_1(bevd_0);
case 96858445: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 726591591: return bem_emitLangSet_1(bevd_0);
case -702790272: return bem_langSet_1(bevd_0);
case 1962796944: return bem_vvSet_1(bevd_0);
case 1459678776: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1854365279: return bem_klassNameSet_1(bevd_0);
case 1513838151: return bem_framesTextSetDirect_1(bevd_0);
case -1519880733: return bem_descriptionSetDirect_1(bevd_0);
case 408464213: return bem_langSetDirect_1(bevd_0);
case 1325575386: return bem_def_1(bevd_0);
case -605413669: return bem_methodNameSet_1(bevd_0);
case 570298004: return bem_lineNumberSet_1(bevd_0);
case -959745115: return bem_otherType_1(bevd_0);
case 780721901: return bem_descriptionSet_1(bevd_0);
case 2082558825: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2131453379: return bem_fileNameSetDirect_1(bevd_0);
case 2109734458: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1082439894: return bem_sameObject_1(bevd_0);
case 1353620660: return bem_sameClass_1(bevd_0);
case -1339829082: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1167969386: return bem_lineNumberSetDirect_1(bevd_0);
case 1597743279: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1664321543: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1793174709: return bem_translatedSet_1(bevd_0);
case 1608731500: return bem_framesSetDirect_1(bevd_0);
case -68723535: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759126894: return bem_new_1(bevd_0);
case -2109980302: return bem_undef_1(bevd_0);
case 2027670755: return bem_defined_1(bevd_0);
case 58703166: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -182660524: return bem_vvSetDirect_1(bevd_0);
case 408705417: return bem_methodNameSetDirect_1(bevd_0);
case -684600363: return bem_emitLangSetDirect_1(bevd_0);
case -1058400031: return bem_translatedSetDirect_1(bevd_0);
case 1137403549: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 70790709: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020619337: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 163657925: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1186365239: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 686267336: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271558857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1157880701: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1019318168: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemInvocationException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_19_SystemInvocationException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemInvocationException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst = (BEC_2_6_19_SystemInvocationException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_type;
}
}
