package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_9_ContainerLinkedListAwareNode extends BEC_3_9_10_4_ContainerLinkedListNode {
public BEC_3_9_10_9_ContainerLinkedListAwareNode() { }
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x41,0x77,0x61,0x72,0x65,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;

public static BET_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;

public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) throws Throwable {
bevp_held = beva__held;
bevp_held.bemd_1(500187624, this);
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldSet_1(BEC_2_6_6_SystemObject beva__held) throws Throwable {
bevp_held = beva__held;
bevp_held.bemd_1(500187624, this);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {97, 98, 99, 103, 104};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 13, 14, 18, 19};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 97 12
heldBySet 1 98 13
assign 1 99 14
assign 1 103 18
heldBySet 1 104 19
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 912871340: return bem_toString_0();
case 1448984271: return bem_create_0();
case 633682209: return bem_print_0();
case -87056108: return bem_new_0();
case -1166859559: return bem_iteratorGet_0();
case -1814897120: return bem_nextGet_0();
case -1922193929: return bem_mylistGet_0();
case -1958204547: return bem_priorGet_0();
case -1476546286: return bem_delete_0();
case 1074060647: return bem_heldGet_0();
case 476934751: return bem_copy_0();
case -1450568577: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2106618550: return bem_def_1(bevd_0);
case -1089041118: return bem_undef_1(bevd_0);
case -957342767: return bem_heldSet_1(bevd_0);
case 490857456: return bem_priorSet_1(bevd_0);
case -1076047891: return bem_notEquals_1(bevd_0);
case 381130981: return bem_copyTo_1(bevd_0);
case 1119792214: return bem_insertBefore_1(bevd_0);
case -1486086431: return bem_equals_1(bevd_0);
case 806654795: return bem_nextSet_1(bevd_0);
case -1922236771: return bem_mylistSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1900258780: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 551846529: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1341903525: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -658194391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -64978042: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_9_ContainerLinkedListAwareNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst = (BEC_3_9_10_9_ContainerLinkedListAwareNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;
}
}
