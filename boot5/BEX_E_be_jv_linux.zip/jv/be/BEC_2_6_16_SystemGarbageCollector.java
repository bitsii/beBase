package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_16_SystemGarbageCollector extends BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemGarbageCollector() { }
private static byte[] becc_BEC_2_6_16_SystemGarbageCollector_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x47,0x61,0x72,0x62,0x61,0x67,0x65,0x43,0x6F,0x6C,0x6C,0x65,0x63,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_16_SystemGarbageCollector_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_16_SystemGarbageCollector bece_BEC_2_6_16_SystemGarbageCollector_bevs_inst;

public static BET_2_6_16_SystemGarbageCollector bece_BEC_2_6_16_SystemGarbageCollector_bevs_type;

public BEC_2_6_16_SystemGarbageCollector bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemGarbageCollector bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemGarbageCollector bem_doFullCollection_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1714302458: return bem_tagGet_0();
case 2087395772: return bem_print_0();
case 1780712404: return bem_toAny_0();
case 1309277187: return bem_serializationIteratorGet_0();
case 216516509: return bem_copy_0();
case 643429711: return bem_many_0();
case -2055449397: return bem_default_0();
case -743672203: return bem_toString_0();
case 1466941499: return bem_fieldIteratorGet_0();
case -730850057: return bem_new_0();
case 535585918: return bem_echo_0();
case 1016157954: return bem_deserializeClassNameGet_0();
case -333666649: return bem_iteratorGet_0();
case -452381319: return bem_hashGet_0();
case 764172461: return bem_sourceFileNameGet_0();
case -1903112833: return bem_serializeContents_0();
case -184894195: return bem_create_0();
case -1002865577: return bem_classNameGet_0();
case -749676617: return bem_serializeToString_0();
case 1951393559: return bem_once_0();
case 1810328254: return bem_fieldNamesGet_0();
case -1555654251: return bem_doFullCollection_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1426897534: return bem_notEquals_1(bevd_0);
case 217750778: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 732303652: return bem_undefined_1(bevd_0);
case 674985673: return bem_equals_1(bevd_0);
case 1190344604: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 221919936: return bem_otherType_1(bevd_0);
case 1522004802: return bem_otherClass_1(bevd_0);
case -536421745: return bem_def_1(bevd_0);
case -557613368: return bem_sameClass_1(bevd_0);
case 275261050: return bem_sameObject_1(bevd_0);
case -1763815494: return bem_undef_1(bevd_0);
case -1327170073: return bem_copyTo_1(bevd_0);
case 254544143: return bem_defined_1(bevd_0);
case 842198181: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1938939824: return bem_sameType_1(bevd_0);
case -1645106897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1213162260: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1183971462: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1639843562: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 758918507: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -36988574: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1804891568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1644786359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemGarbageCollector_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_16_SystemGarbageCollector_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemGarbageCollector();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemGarbageCollector.bece_BEC_2_6_16_SystemGarbageCollector_bevs_inst = (BEC_2_6_16_SystemGarbageCollector) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemGarbageCollector.bece_BEC_2_6_16_SystemGarbageCollector_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemGarbageCollector.bece_BEC_2_6_16_SystemGarbageCollector_bevs_type;
}
}
