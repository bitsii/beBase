package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_7_IOFileReaderCommand extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0, 8));
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1, 30));
public static BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_1(BEC_2_6_6_SystemObject beva__command) throws Throwable {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) throws Throwable {
super.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool) /* Line: 832 */ {
bevt_3_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_command);
bevt_4_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 833 */
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_close_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public final BEC_2_4_6_TextString bem_commandGetDirect_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {795, 799, 803, 805, 816, 831, 833, 833, 833, 833, 833, 833, 846, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 21, 25, 26, 37, 38, 40, 41, 42, 43, 44, 45, 50, 54, 57, 60, 64};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 795 17
commandNew 1 799 21
new 0 803 25
assign 1 805 26
assign 1 816 37
assign 1 831 38
assign 1 833 40
new 0 833 40
assign 1 833 41
add 1 833 41
assign 1 833 42
new 0 833 42
assign 1 833 43
add 1 833 43
assign 1 833 44
new 1 833 44
throw 1 833 45
assign 1 846 50
new 0 846 50
return 1 0 54
return 1 0 57
assign 1 0 60
assign 1 0 64
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1500978633: return bem_tagGet_0();
case 2102651338: return bem_fieldIteratorGet_0();
case -2035750871: return bem_vfileGetDirect_0();
case -1551806822: return bem_toAny_0();
case 118059308: return bem_commandGetDirect_0();
case 1201799861: return bem_serializeToString_0();
case 1325694207: return bem_isClosedGet_0();
case -114079936: return bem_serializeContents_0();
case 2080368646: return bem_commandGet_0();
case 1617635208: return bem_readDiscard_0();
case 42225481: return bem_vfileGet_0();
case 756031562: return bem_readDiscardClose_0();
case -1852716747: return bem_byteReaderGet_0();
case -1513389200: return bem_readStringClose_0();
case 2036147796: return bem_toString_0();
case 1430998361: return bem_serializationIteratorGet_0();
case 2040706850: return bem_readString_0();
case 191896611: return bem_copy_0();
case -2072472298: return bem_hashGet_0();
case -1737009900: return bem_many_0();
case 1016497072: return bem_pathGetDirect_0();
case -1066226610: return bem_fieldNamesGet_0();
case 1525639803: return bem_sourceFileNameGet_0();
case 653341959: return bem_print_0();
case -1759630984: return bem_classNameGet_0();
case -2145436361: return bem_open_0();
case -20092371: return bem_pathGet_0();
case -1195111829: return bem_create_0();
case -887888022: return bem_blockSizeGetDirect_0();
case 653626519: return bem_readBufferLine_0();
case -508877915: return bem_isClosedGetDirect_0();
case 573647971: return bem_iteratorGet_0();
case -1976480232: return bem_once_0();
case -812552811: return bem_extOpen_0();
case 836237170: return bem_close_0();
case -1748925107: return bem_echo_0();
case 1359821363: return bem_blockSizeGet_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case -1439875774: return bem_new_0();
case 131590846: return bem_readBuffer_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1906745373: return bem_blockSizeSetDirect_1(bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case -192271885: return bem_equals_1(bevd_0);
case -397635677: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -40515151: return bem_vfileSetDirect_1(bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case 1393967332: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -712903169: return bem_new_1(bevd_0);
case -1661158960: return bem_isClosedSet_1(bevd_0);
case -1675092603: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -276798229: return bem_pathSet_1(bevd_0);
case -411577193: return bem_isClosedSetDirect_1(bevd_0);
case -857759314: return bem_commandSetDirect_1(bevd_0);
case 1661874097: return bem_blockSizeSet_1(bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
case -102295312: return bem_sameObject_1(bevd_0);
case 279371417: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 1455634795: return bem_pathSetDirect_1(bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -759722687: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -695976251: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 884462515: return bem_def_1(bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case 1553034526: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case 655356113: return bem_vfileSet_1(bevd_0);
case -1423554297: return bem_commandSet_1(bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618785517: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -668613244: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 780283980: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
