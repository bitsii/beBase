package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_7_IOFileReaderCommand extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0, 8));
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1, 30));
public static BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
public BEC_2_4_6_TextString bevp_command;
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_1(BEC_2_6_6_SystemObject beva__command) throws Throwable {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) throws Throwable {
super.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool) /* Line: 758 */ {
bevt_3_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_command);
bevt_4_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 759 */
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_close_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {721, 725, 729, 731, 742, 757, 759, 759, 759, 759, 759, 759, 772, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 18, 22, 23, 34, 35, 37, 38, 39, 40, 41, 42, 47, 51, 54};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 721 14
commandNew 1 725 18
new 0 729 22
assign 1 731 23
assign 1 742 34
assign 1 757 35
assign 1 759 37
new 0 759 37
assign 1 759 38
add 1 759 38
assign 1 759 39
new 0 759 39
assign 1 759 40
add 1 759 40
assign 1 759 41
new 1 759 41
throw 1 759 42
assign 1 772 47
new 0 772 47
return 1 0 51
assign 1 0 54
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -748130189: return bem_echo_0();
case 1063828377: return bem_vfileGet_0();
case -1256903143: return bem_print_0();
case 332690122: return bem_open_0();
case -1693411633: return bem_fieldIteratorGet_0();
case -165345418: return bem_readBuffer_0();
case -2128130409: return bem_close_0();
case -2089883321: return bem_new_0();
case 1029417943: return bem_readString_0();
case 721298840: return bem_serializationIteratorGet_0();
case 1330053746: return bem_classNameGet_0();
case -1666892068: return bem_once_0();
case 755335905: return bem_isClosedGet_0();
case 532724685: return bem_pathGet_0();
case 394710523: return bem_toAny_0();
case 978873391: return bem_deserializeClassNameGet_0();
case -1755437106: return bem_serializeContents_0();
case -266150550: return bem_many_0();
case -67323485: return bem_create_0();
case 1087310574: return bem_extOpen_0();
case 895906767: return bem_toString_0();
case -721291680: return bem_readBufferLine_0();
case -582877759: return bem_readStringClose_0();
case -907223016: return bem_iteratorGet_0();
case 648643859: return bem_sourceFileNameGet_0();
case 19655765: return bem_tagGet_0();
case 271563984: return bem_byteReaderGet_0();
case 1973388656: return bem_blockSizeGet_0();
case -269387599: return bem_commandGet_0();
case 1781926555: return bem_copy_0();
case 1740583826: return bem_serializeToString_0();
case 1782125853: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2119054446: return bem_otherType_1(bevd_0);
case -2142325185: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case -1804976263: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 803845413: return bem_def_1(bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case -1842584050: return bem_new_1(bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -780023472: return bem_vfileSet_1(bevd_0);
case -254385268: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -832551193: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case -934181394: return bem_isClosedSet_1(bevd_0);
case -1294060004: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -874263406: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case -2097315666: return bem_sameClass_1(bevd_0);
case 842590965: return bem_commandSet_1(bevd_0);
case 1019423408: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case 2052733066: return bem_pathSet_1(bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1011228115: return bem_blockSizeSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -180252519: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1196404771: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -2079206653: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
}
