package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_7_IOFileReaderCommand extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0, 8));
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1, 30));
public static BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_1(BEC_2_6_6_SystemObject beva__command) throws Throwable {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) throws Throwable {
super.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool) /* Line: 808 */ {
bevt_3_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_command);
bevt_4_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 809 */
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_close_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public final BEC_2_4_6_TextString bem_commandGetDirect_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {771, 775, 779, 781, 792, 807, 809, 809, 809, 809, 809, 809, 822, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 21, 25, 26, 37, 38, 40, 41, 42, 43, 44, 45, 50, 54, 57, 60, 64};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 771 17
commandNew 1 775 21
new 0 779 25
assign 1 781 26
assign 1 792 37
assign 1 807 38
assign 1 809 40
new 0 809 40
assign 1 809 41
add 1 809 41
assign 1 809 42
new 0 809 42
assign 1 809 43
add 1 809 43
assign 1 809 44
new 1 809 44
throw 1 809 45
assign 1 822 50
new 0 822 50
return 1 0 54
return 1 0 57
assign 1 0 60
assign 1 0 64
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 486198208: return bem_fieldNamesGet_0();
case 486036595: return bem_once_0();
case 1102858101: return bem_commandGet_0();
case -1553872012: return bem_blockSizeGet_0();
case -2028995013: return bem_new_0();
case -2111591272: return bem_sourceFileNameGet_0();
case 223156538: return bem_readString_0();
case 1615388739: return bem_create_0();
case -1474366991: return bem_many_0();
case -1789612391: return bem_fieldIteratorGet_0();
case 2089347046: return bem_classNameGet_0();
case -835557872: return bem_tagGet_0();
case 1852774851: return bem_close_0();
case 1600753962: return bem_toAny_0();
case -1833113172: return bem_serializationIteratorGet_0();
case -638960936: return bem_byteReaderGet_0();
case 610604781: return bem_echo_0();
case 1266624801: return bem_hashGet_0();
case 1999559263: return bem_isClosedGetDirect_0();
case 526998957: return bem_extOpen_0();
case 595012101: return bem_pathGet_0();
case 1281408236: return bem_readBuffer_0();
case 15292588: return bem_serializeToString_0();
case -1177132334: return bem_readStringClose_0();
case 1760278610: return bem_open_0();
case 28192138: return bem_serializeContents_0();
case 1770116736: return bem_isClosedGet_0();
case -1005390218: return bem_deserializeClassNameGet_0();
case -1873931192: return bem_print_0();
case 1505588986: return bem_commandGetDirect_0();
case -520114288: return bem_pathGetDirect_0();
case 1766865098: return bem_blockSizeGetDirect_0();
case -1264037424: return bem_copy_0();
case 355474872: return bem_vfileGetDirect_0();
case 1801976276: return bem_vfileGet_0();
case -1180336274: return bem_iteratorGet_0();
case -495947451: return bem_readBufferLine_0();
case 83573654: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1507780801: return bem_new_1(bevd_0);
case 1702750854: return bem_sameObject_1(bevd_0);
case -317025047: return bem_copyTo_1(bevd_0);
case -1612312921: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 981626333: return bem_sameType_1(bevd_0);
case -1929193380: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 402640360: return bem_pathSetDirect_1(bevd_0);
case 799774900: return bem_isClosedSetDirect_1(bevd_0);
case 118112309: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1941881344: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1093777793: return bem_commandSet_1(bevd_0);
case -838432587: return bem_vfileSetDirect_1(bevd_0);
case -1208980303: return bem_otherClass_1(bevd_0);
case 63361049: return bem_defined_1(bevd_0);
case -99128923: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -782460965: return bem_undef_1(bevd_0);
case 1439554668: return bem_blockSizeSetDirect_1(bevd_0);
case 1805450030: return bem_isClosedSet_1(bevd_0);
case 577328175: return bem_pathSet_1(bevd_0);
case -1374791728: return bem_otherType_1(bevd_0);
case -257313333: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2011440128: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -366926915: return bem_blockSizeSet_1(bevd_0);
case -1967806979: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 952474121: return bem_def_1(bevd_0);
case 2141890129: return bem_equals_1(bevd_0);
case -1893810963: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1482822102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1599766807: return bem_undefined_1(bevd_0);
case -348415642: return bem_notEquals_1(bevd_0);
case 720952303: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 727631606: return bem_vfileSet_1(bevd_0);
case 1180747580: return bem_commandSetDirect_1(bevd_0);
case 2034381311: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -454079439: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 861143274: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -260132007: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 749345524: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1277474521: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2028665645: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 455421503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 941034455: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1325101316: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1620906616: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
