package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static BEC_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;

public static BET_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;

public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public BEC_2_4_12_JsonUnmarshaller bem_new_0() throws Throwable {
bevp_parser = (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) throws Throwable {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_9_ta_ph = null;
BEC_2_6_9_SystemException bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (bevp_first == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 491*/ {
bevp_first = beva_o;
} /* Line: 492*/
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 495*/ {
bevt_3_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameClass_2(bevl_top, bevp_pair);
if (bevt_2_ta_ph.bevi_bool)/* Line: 496*/ {
bevt_5_ta_ph = bevl_top.bemd_0(-2096536834);
if (bevt_5_ta_ph == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 497*/ {
bevt_6_ta_ph = bevl_top.bemd_0(-1616255067);
bevt_7_ta_ph = bevl_top.bemd_0(-2096536834);
bevt_6_ta_ph.bemd_2(317235156, bevt_7_ta_ph, beva_o);
bevl_top.bemd_1(1337124194, null);
} /* Line: 499*/
 else /* Line: 500*/ {
bevl_top.bemd_1(1337124194, beva_o);
} /* Line: 501*/
} /* Line: 497*/
 else /* Line: 496*/ {
bevt_9_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_8_ta_ph = bevt_9_ta_ph.bem_sameClass_2(bevl_top, bevp_list);
if (bevt_8_ta_ph.bevi_bool)/* Line: 503*/ {
bevl_top.bemd_1(-1328631978, beva_o);
} /* Line: 504*/
 else /* Line: 505*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_4_12_JsonUnmarshaller_bels_0));
bevt_10_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_ta_ph);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 506*/
} /* Line: 496*/
} /* Line: 496*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_ta_ph = null;
bevl_m = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bem_addIn_1(bevl_m);
bevt_0_ta_ph = (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endMap_0() throws Throwable {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 520*/ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 521*/
 else /* Line: 522*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_12_JsonUnmarshaller_bels_1));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 523*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_4_ta_ph = bevp_stack.bem_peek_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameClass_2(bevt_4_ta_ph, bevp_pair);
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 529*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 529*/ {
bevt_7_ta_ph = bevp_stack.bem_peek_0();
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-2096536834);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 529*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 529*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 529*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 529*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_4_12_JsonUnmarshaller_bels_2));
bevt_8_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 530*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (new BEC_2_9_4_ContainerList()).bem_new_0();
bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 543*/ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 544*/
 else /* Line: 545*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_4_12_JsonUnmarshaller_bels_3));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 546*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_addIn_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
bem_addIn_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
bem_addIn_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() throws Throwable {
bem_addIn_1(null);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
bem_addIn_1(beva_int);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parserGet_0() throws Throwable {
return bevp_parser;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_pairGet_0() throws Throwable {
return bevp_pair;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_first = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_stackGet_0() throws Throwable {
return bevp_stack;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {474, 475, 476, 477, 479, 480, 485, 486, 487, 491, 491, 492, 494, 495, 495, 496, 496, 497, 497, 497, 498, 498, 498, 499, 501, 503, 503, 504, 506, 506, 506, 513, 514, 515, 515, 520, 521, 523, 523, 523, 529, 529, 529, 529, 529, 0, 529, 529, 529, 529, 0, 0, 530, 530, 530, 536, 537, 538, 543, 544, 546, 546, 546, 553, 558, 558, 563, 563, 568, 573, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 25, 26, 27, 31, 32, 33, 49, 54, 55, 57, 58, 63, 64, 65, 67, 68, 73, 74, 75, 76, 77, 80, 84, 85, 87, 90, 91, 92, 101, 102, 103, 104, 112, 114, 117, 118, 119, 134, 135, 136, 137, 142, 143, 146, 147, 148, 153, 154, 157, 161, 162, 163, 169, 170, 171, 179, 181, 184, 185, 186, 191, 196, 197, 202, 203, 207, 211, 215, 218, 222, 225, 229, 232, 236, 239, 243, 246, 250, 253};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 474 22
new 0 474 22
assign 1 475 23
new 0 475 23
assign 1 476 24
new 0 476 24
assign 1 477 25
new 0 477 25
assign 1 479 26
assign 1 480 27
new 0 480 27
new 0 485 31
parse 2 486 32
return 1 487 33
assign 1 491 49
undef 1 491 54
assign 1 492 55
assign 1 494 57
peek 0 494 57
assign 1 495 58
def 1 495 63
assign 1 496 64
new 0 496 64
assign 1 496 65
sameClass 2 496 65
assign 1 497 67
secondGet 0 497 67
assign 1 497 68
def 1 497 73
assign 1 498 74
firstGet 0 498 74
assign 1 498 75
secondGet 0 498 75
put 2 498 76
secondSet 1 499 77
secondSet 1 501 80
assign 1 503 84
new 0 503 84
assign 1 503 85
sameClass 2 503 85
addValueWhole 1 504 87
assign 1 506 90
new 0 506 90
assign 1 506 91
new 1 506 91
throw 1 506 92
assign 1 513 101
new 0 513 101
addIn 1 514 102
assign 1 515 103
new 2 515 103
push 1 515 104
assign 1 520 112
isEmptyGet 0 520 112
assign 1 521 114
pop 0 521 114
assign 1 523 117
new 0 523 117
assign 1 523 118
new 1 523 118
throw 1 523 119
assign 1 529 134
new 0 529 134
assign 1 529 135
peek 0 529 135
assign 1 529 136
sameClass 2 529 136
assign 1 529 137
not 0 529 142
assign 1 0 143
assign 1 529 146
peek 0 529 146
assign 1 529 147
secondGet 0 529 147
assign 1 529 148
undef 1 529 153
assign 1 0 154
assign 1 0 157
assign 1 530 161
new 0 530 161
assign 1 530 162
new 1 530 162
throw 1 530 163
assign 1 536 169
new 0 536 169
addIn 1 537 170
push 1 538 171
assign 1 543 179
isEmptyGet 0 543 179
assign 1 544 181
pop 0 544 181
assign 1 546 184
new 0 546 184
assign 1 546 185
new 1 546 185
throw 1 546 186
addIn 1 553 191
assign 1 558 196
new 0 558 196
addIn 1 558 197
assign 1 563 202
new 0 563 202
addIn 1 563 203
addIn 1 568 207
addIn 1 573 211
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
return 1 0 250
assign 1 0 253
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1054203184: return bem_handleFalse_0();
case 1661695301: return bem_beginMap_0();
case -618327675: return bem_hashGet_0();
case 1921755447: return bem_handleTrue_0();
case -2064126859: return bem_endMap_0();
case -675794816: return bem_print_0();
case 1469284867: return bem_toString_0();
case -1221115541: return bem_new_0();
case 1171022339: return bem_copy_0();
case -1372629316: return bem_listGet_0();
case -1059671707: return bem_mapGet_0();
case -2134112673: return bem_handleNull_0();
case 634096355: return bem_endList_0();
case 1004533269: return bem_parserGet_0();
case 422595331: return bem_iteratorGet_0();
case -222930549: return bem_kvMid_0();
case -1616255067: return bem_firstGet_0();
case 95990182: return bem_beginList_0();
case -1324751158: return bem_stackGet_0();
case 92270569: return bem_create_0();
case 1329411298: return bem_pairGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1636250903: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case 701760907: return bem_def_1(bevd_0);
case -39729582: return bem_notEquals_1(bevd_0);
case 1159219480: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case -280253635: return bem_stackSet_1(bevd_0);
case -1472623145: return bem_firstSet_1(bevd_0);
case 1218740568: return bem_mapSet_1(bevd_0);
case -778065893: return bem_listSet_1(bevd_0);
case -857586605: return bem_pairSet_1(bevd_0);
case -1089103671: return bem_undef_1(bevd_0);
case -173368796: return bem_parserSet_1(bevd_0);
case 192400507: return bem_copyTo_1(bevd_0);
case -1515236141: return bem_print_1(bevd_0);
case -1041644544: return bem_addIn_1(bevd_0);
case 935360108: return bem_equals_1(bevd_0);
case -97086347: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 218804328: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1274504073: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1010736438: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1082406137: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_JsonUnmarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_12_JsonUnmarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_JsonUnmarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst = (BEC_2_4_12_JsonUnmarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;
}
}
