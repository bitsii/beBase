package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static BEC_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;

public static BET_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;

public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public BEC_2_4_12_JsonUnmarshaller bem_new_0() throws Throwable {
bevp_parser = (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) throws Throwable {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_9_ta_ph = null;
BEC_2_6_9_SystemException bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (bevp_first == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 485*/ {
bevp_first = beva_o;
} /* Line: 486*/
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 489*/ {
bevt_3_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameClass_2(bevl_top, bevp_pair);
if (bevt_2_ta_ph.bevi_bool)/* Line: 490*/ {
bevt_5_ta_ph = bevl_top.bemd_0(-1190573327);
if (bevt_5_ta_ph == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 491*/ {
bevt_6_ta_ph = bevl_top.bemd_0(2068887570);
bevt_7_ta_ph = bevl_top.bemd_0(-1190573327);
bevt_6_ta_ph.bemd_2(68260516, bevt_7_ta_ph, beva_o);
bevl_top.bemd_1(631143226, null);
} /* Line: 493*/
 else /* Line: 494*/ {
bevl_top.bemd_1(631143226, beva_o);
} /* Line: 495*/
} /* Line: 491*/
 else /* Line: 490*/ {
bevt_9_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_8_ta_ph = bevt_9_ta_ph.bem_sameClass_2(bevl_top, bevp_list);
if (bevt_8_ta_ph.bevi_bool)/* Line: 497*/ {
bevl_top.bemd_1(-1014039137, beva_o);
} /* Line: 498*/
 else /* Line: 499*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_4_12_JsonUnmarshaller_bels_0));
bevt_10_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_ta_ph);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 500*/
} /* Line: 490*/
} /* Line: 490*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_ta_ph = null;
bevl_m = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bem_addIn_1(bevl_m);
bevt_0_ta_ph = (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endMap_0() throws Throwable {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 514*/ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 515*/
 else /* Line: 516*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_12_JsonUnmarshaller_bels_1));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 517*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_4_ta_ph = bevp_stack.bem_peek_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameClass_2(bevt_4_ta_ph, bevp_pair);
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 523*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 523*/ {
bevt_7_ta_ph = bevp_stack.bem_peek_0();
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-1190573327);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 523*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 523*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 523*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 523*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_4_12_JsonUnmarshaller_bels_2));
bevt_8_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 524*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (new BEC_2_9_4_ContainerList()).bem_new_0();
bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 537*/ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 538*/
 else /* Line: 539*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_4_12_JsonUnmarshaller_bels_3));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 540*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_addIn_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
bem_addIn_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
bem_addIn_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() throws Throwable {
bem_addIn_1(null);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
bem_addIn_1(beva_int);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parserGet_0() throws Throwable {
return bevp_parser;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_pairGet_0() throws Throwable {
return bevp_pair;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_first = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_stackGet_0() throws Throwable {
return bevp_stack;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {468, 469, 470, 471, 473, 474, 479, 480, 481, 485, 485, 486, 488, 489, 489, 490, 490, 491, 491, 491, 492, 492, 492, 493, 495, 497, 497, 498, 500, 500, 500, 507, 508, 509, 509, 514, 515, 517, 517, 517, 523, 523, 523, 523, 523, 0, 523, 523, 523, 523, 0, 0, 524, 524, 524, 530, 531, 532, 537, 538, 540, 540, 540, 547, 552, 552, 557, 557, 562, 567, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 25, 26, 27, 31, 32, 33, 49, 54, 55, 57, 58, 63, 64, 65, 67, 68, 73, 74, 75, 76, 77, 80, 84, 85, 87, 90, 91, 92, 101, 102, 103, 104, 112, 114, 117, 118, 119, 134, 135, 136, 137, 142, 143, 146, 147, 148, 153, 154, 157, 161, 162, 163, 169, 170, 171, 179, 181, 184, 185, 186, 191, 196, 197, 202, 203, 207, 211, 215, 218, 222, 225, 229, 232, 236, 239, 243, 246, 250, 253};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 468 22
new 0 468 22
assign 1 469 23
new 0 469 23
assign 1 470 24
new 0 470 24
assign 1 471 25
new 0 471 25
assign 1 473 26
assign 1 474 27
new 0 474 27
new 0 479 31
parse 2 480 32
return 1 481 33
assign 1 485 49
undef 1 485 54
assign 1 486 55
assign 1 488 57
peek 0 488 57
assign 1 489 58
def 1 489 63
assign 1 490 64
new 0 490 64
assign 1 490 65
sameClass 2 490 65
assign 1 491 67
secondGet 0 491 67
assign 1 491 68
def 1 491 73
assign 1 492 74
firstGet 0 492 74
assign 1 492 75
secondGet 0 492 75
put 2 492 76
secondSet 1 493 77
secondSet 1 495 80
assign 1 497 84
new 0 497 84
assign 1 497 85
sameClass 2 497 85
addValueWhole 1 498 87
assign 1 500 90
new 0 500 90
assign 1 500 91
new 1 500 91
throw 1 500 92
assign 1 507 101
new 0 507 101
addIn 1 508 102
assign 1 509 103
new 2 509 103
push 1 509 104
assign 1 514 112
isEmptyGet 0 514 112
assign 1 515 114
pop 0 515 114
assign 1 517 117
new 0 517 117
assign 1 517 118
new 1 517 118
throw 1 517 119
assign 1 523 134
new 0 523 134
assign 1 523 135
peek 0 523 135
assign 1 523 136
sameClass 2 523 136
assign 1 523 137
not 0 523 142
assign 1 0 143
assign 1 523 146
peek 0 523 146
assign 1 523 147
secondGet 0 523 147
assign 1 523 148
undef 1 523 153
assign 1 0 154
assign 1 0 157
assign 1 524 161
new 0 524 161
assign 1 524 162
new 1 524 162
throw 1 524 163
assign 1 530 169
new 0 530 169
addIn 1 531 170
push 1 532 171
assign 1 537 179
isEmptyGet 0 537 179
assign 1 538 181
pop 0 538 181
assign 1 540 184
new 0 540 184
assign 1 540 185
new 1 540 185
throw 1 540 186
addIn 1 547 191
assign 1 552 196
new 0 552 196
addIn 1 552 197
assign 1 557 202
new 0 557 202
addIn 1 557 203
addIn 1 562 207
addIn 1 567 211
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
return 1 0 250
assign 1 0 253
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2101684619: return bem_new_0();
case 429375366: return bem_pairGet_0();
case 324723616: return bem_listGet_0();
case -1624890023: return bem_handleTrue_0();
case 1357299616: return bem_handleFalse_0();
case 952243325: return bem_beginMap_0();
case 1319233284: return bem_iteratorGet_0();
case 488617187: return bem_kvMid_0();
case -428175563: return bem_toString_0();
case -2060672203: return bem_parserGet_0();
case 449669889: return bem_endList_0();
case 2068887570: return bem_firstGet_0();
case -1677484548: return bem_print_0();
case -1715211966: return bem_hashGet_0();
case 1171718113: return bem_mapGet_0();
case 322268881: return bem_endMap_0();
case -414672201: return bem_create_0();
case 1749455096: return bem_copy_0();
case -324707487: return bem_beginList_0();
case -365746149: return bem_stackGet_0();
case -43601476: return bem_handleNull_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -760176780: return bem_copyTo_1(bevd_0);
case 968534925: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case 1228234604: return bem_def_1(bevd_0);
case 64410224: return bem_addIn_1(bevd_0);
case -312834412: return bem_parserSet_1(bevd_0);
case 1445843213: return bem_firstSet_1(bevd_0);
case 1789302952: return bem_notEquals_1(bevd_0);
case -1837782797: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 1076760443: return bem_listSet_1(bevd_0);
case 183362921: return bem_equals_1(bevd_0);
case 705198518: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case -852736831: return bem_pairSet_1(bevd_0);
case -1841821234: return bem_mapSet_1(bevd_0);
case -329682344: return bem_undef_1(bevd_0);
case -1934041586: return bem_stackSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -355340329: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 365672883: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -519546757: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -242597694: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_JsonUnmarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_12_JsonUnmarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_JsonUnmarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst = (BEC_2_4_12_JsonUnmarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;
}
}
