package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static BEC_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;

public static BET_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;

public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public BEC_2_4_12_JsonUnmarshaller bem_new_0() throws Throwable {
bevp_parser = (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) throws Throwable {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_first == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevp_first = beva_o;
} /* Line: 485 */
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 488 */ {
bevt_2_tmpany_phold = bevl_top.bemd_1(-2056947488, bevp_pair);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_4_tmpany_phold = bevl_top.bemd_0(1764393658);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 490 */ {
bevt_5_tmpany_phold = bevl_top.bemd_0(-194416916);
bevt_6_tmpany_phold = bevl_top.bemd_0(1764393658);
bevt_5_tmpany_phold.bemd_2(334521225, bevt_6_tmpany_phold, beva_o);
bevl_top.bemd_1(-2079780959, null);
} /* Line: 492 */
 else  /* Line: 493 */ {
bevl_top.bemd_1(-2079780959, beva_o);
} /* Line: 494 */
} /* Line: 490 */
 else  /* Line: 489 */ {
bevt_7_tmpany_phold = bevl_top.bemd_1(-2056947488, bevp_list);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevl_top.bemd_1(-820929226, beva_o);
} /* Line: 497 */
 else  /* Line: 498 */ {
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_4_12_JsonUnmarshaller_bels_0));
bevt_8_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 499 */
} /* Line: 489 */
} /* Line: 489 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_tmpany_phold = null;
bevl_m = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bem_addIn_1(bevl_m);
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endMap_0() throws Throwable {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 513 */ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 514 */
 else  /* Line: 515 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_12_JsonUnmarshaller_bels_1));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 516 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_stack.bem_peek_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-2056947488, bevp_pair);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(111297745);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_6_tmpany_phold = bevp_stack.bem_peek_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(1764393658);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 522 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 522 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_4_12_JsonUnmarshaller_bels_2));
bevt_7_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 523 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (new BEC_2_9_4_ContainerList()).bem_new_0();
bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 536 */ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 537 */
 else  /* Line: 538 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_4_12_JsonUnmarshaller_bels_3));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 539 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_addIn_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() throws Throwable {
bem_addIn_1(null);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
bem_addIn_1(beva_int);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parserGet_0() throws Throwable {
return bevp_parser;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_parserGetDirect_0() throws Throwable {
return bevp_parser;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_JsonUnmarshaller bem_parserSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_listGetDirect_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_JsonUnmarshaller bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_pairGet_0() throws Throwable {
return bevp_pair;
} /*method end*/
public final BEC_2_9_4_ContainerPair bem_pairGetDirect_0() throws Throwable {
return bevp_pair;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_JsonUnmarshaller bem_pairSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_mapGetDirect_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_JsonUnmarshaller bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_firstGetDirect_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_JsonUnmarshaller bem_firstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_stackGet_0() throws Throwable {
return bevp_stack;
} /*method end*/
public final BEC_2_9_5_ContainerStack bem_stackGetDirect_0() throws Throwable {
return bevp_stack;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_JsonUnmarshaller bem_stackSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {467, 468, 469, 470, 472, 473, 478, 479, 480, 484, 484, 485, 487, 488, 488, 489, 490, 490, 490, 491, 491, 491, 492, 494, 496, 497, 499, 499, 499, 506, 507, 508, 508, 513, 514, 516, 516, 516, 522, 522, 522, 0, 522, 522, 522, 522, 0, 0, 523, 523, 523, 529, 530, 531, 536, 537, 539, 539, 539, 546, 551, 551, 556, 556, 561, 566, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 25, 26, 27, 31, 32, 33, 47, 52, 53, 55, 56, 61, 62, 64, 65, 70, 71, 72, 73, 74, 77, 81, 83, 86, 87, 88, 97, 98, 99, 100, 108, 110, 113, 114, 115, 129, 130, 131, 133, 136, 137, 138, 143, 144, 147, 151, 152, 153, 159, 160, 161, 169, 171, 174, 175, 176, 181, 186, 187, 192, 193, 197, 201, 205, 208, 211, 215, 219, 222, 225, 229, 233, 236, 239, 243, 247, 250, 253, 257, 261, 264, 267, 271, 275, 278, 281, 285};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 467 22
new 0 467 22
assign 1 468 23
new 0 468 23
assign 1 469 24
new 0 469 24
assign 1 470 25
new 0 470 25
assign 1 472 26
assign 1 473 27
new 0 473 27
new 0 478 31
parse 2 479 32
return 1 480 33
assign 1 484 47
undef 1 484 52
assign 1 485 53
assign 1 487 55
peek 0 487 55
assign 1 488 56
def 1 488 61
assign 1 489 62
sameClass 1 489 62
assign 1 490 64
secondGet 0 490 64
assign 1 490 65
def 1 490 70
assign 1 491 71
firstGet 0 491 71
assign 1 491 72
secondGet 0 491 72
put 2 491 73
secondSet 1 492 74
secondSet 1 494 77
assign 1 496 81
sameClass 1 496 81
addValueWhole 1 497 83
assign 1 499 86
new 0 499 86
assign 1 499 87
new 1 499 87
throw 1 499 88
assign 1 506 97
new 0 506 97
addIn 1 507 98
assign 1 508 99
new 2 508 99
push 1 508 100
assign 1 513 108
isEmptyGet 0 513 108
assign 1 514 110
pop 0 514 110
assign 1 516 113
new 0 516 113
assign 1 516 114
new 1 516 114
throw 1 516 115
assign 1 522 129
peek 0 522 129
assign 1 522 130
sameClass 1 522 130
assign 1 522 131
not 0 522 131
assign 1 0 133
assign 1 522 136
peek 0 522 136
assign 1 522 137
secondGet 0 522 137
assign 1 522 138
undef 1 522 143
assign 1 0 144
assign 1 0 147
assign 1 523 151
new 0 523 151
assign 1 523 152
new 1 523 152
throw 1 523 153
assign 1 529 159
new 0 529 159
addIn 1 530 160
push 1 531 161
assign 1 536 169
isEmptyGet 0 536 169
assign 1 537 171
pop 0 537 171
assign 1 539 174
new 0 539 174
assign 1 539 175
new 1 539 175
throw 1 539 176
addIn 1 546 181
assign 1 551 186
new 0 551 186
addIn 1 551 187
assign 1 556 192
new 0 556 192
addIn 1 556 193
addIn 1 561 197
addIn 1 566 201
return 1 0 205
return 1 0 208
assign 1 0 211
assign 1 0 215
return 1 0 219
return 1 0 222
assign 1 0 225
assign 1 0 229
return 1 0 233
return 1 0 236
assign 1 0 239
assign 1 0 243
return 1 0 247
return 1 0 250
assign 1 0 253
assign 1 0 257
return 1 0 261
return 1 0 264
assign 1 0 267
assign 1 0 271
return 1 0 275
return 1 0 278
assign 1 0 281
assign 1 0 285
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2093192891: return bem_endMap_0();
case 1611055106: return bem_fieldNamesGet_0();
case 1981654959: return bem_once_0();
case -217835874: return bem_tagGet_0();
case -397559289: return bem_fieldIteratorGet_0();
case 1895234234: return bem_mapGet_0();
case -1629544591: return bem_many_0();
case -934118971: return bem_pairGet_0();
case 156156592: return bem_mapGetDirect_0();
case -2021277153: return bem_listGetDirect_0();
case 346235852: return bem_sourceFileNameGet_0();
case 718789172: return bem_iteratorGet_0();
case -207569400: return bem_serializeToString_0();
case 2010907720: return bem_firstGetDirect_0();
case -1610792694: return bem_beginMap_0();
case -480687649: return bem_print_0();
case 1230302912: return bem_hashGet_0();
case -1309956681: return bem_pairGetDirect_0();
case -360613383: return bem_serializeContents_0();
case -362401407: return bem_parserGetDirect_0();
case 55397208: return bem_beginList_0();
case -1219520198: return bem_handleNull_0();
case -2005255255: return bem_endList_0();
case -915808255: return bem_serializationIteratorGet_0();
case -1278273894: return bem_toAny_0();
case 689795977: return bem_stackGetDirect_0();
case -1590198424: return bem_stackGet_0();
case -194416916: return bem_firstGet_0();
case -1308933810: return bem_deserializeClassNameGet_0();
case 357537975: return bem_classNameGet_0();
case 947585898: return bem_kvMid_0();
case -1762356041: return bem_toString_0();
case -638442685: return bem_echo_0();
case -22393727: return bem_create_0();
case 989659495: return bem_parserGet_0();
case 1099530000: return bem_handleFalse_0();
case -507124439: return bem_new_0();
case 1054341191: return bem_handleTrue_0();
case 847337627: return bem_copy_0();
case -1706240983: return bem_listGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1375943041: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case -1731244517: return bem_addIn_1(bevd_0);
case 1387628079: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 580318355: return bem_otherType_1(bevd_0);
case 1379835000: return bem_defined_1(bevd_0);
case 1273353241: return bem_notEquals_1(bevd_0);
case -723822275: return bem_firstSetDirect_1(bevd_0);
case 1391707526: return bem_pairSet_1(bevd_0);
case -1823217260: return bem_stackSetDirect_1(bevd_0);
case 887888794: return bem_parserSetDirect_1(bevd_0);
case 1418552655: return bem_def_1(bevd_0);
case -665968375: return bem_sameType_1(bevd_0);
case -1256041694: return bem_copyTo_1(bevd_0);
case -1263961885: return bem_otherClass_1(bevd_0);
case 1514810988: return bem_mapSet_1(bevd_0);
case -166307772: return bem_parserSet_1(bevd_0);
case -624570608: return bem_listSet_1(bevd_0);
case -1585817548: return bem_mapSetDirect_1(bevd_0);
case 1787128072: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -768330148: return bem_firstSet_1(bevd_0);
case -794657115: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2056947488: return bem_sameClass_1(bevd_0);
case -199410701: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case -408502512: return bem_equals_1(bevd_0);
case -436547338: return bem_undefined_1(bevd_0);
case 1340526893: return bem_listSetDirect_1(bevd_0);
case -660877284: return bem_stackSet_1(bevd_0);
case 1530291279: return bem_sameObject_1(bevd_0);
case -938042823: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case -495480812: return bem_pairSetDirect_1(bevd_0);
case 321693734: return bem_undef_1(bevd_0);
case 1849763669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -318431301: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1103544796: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138830036: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -554397969: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2122183893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 975610887: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -799307739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_JsonUnmarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_12_JsonUnmarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_JsonUnmarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst = (BEC_2_4_12_JsonUnmarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;
}
}
