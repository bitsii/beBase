package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static BEC_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;

public static BET_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;

public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public BEC_2_4_12_JsonUnmarshaller bem_new_0() throws Throwable {
bevp_parser = (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) throws Throwable {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_9_ta_ph = null;
BEC_2_6_9_SystemException bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (bevp_first == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 483*/ {
bevp_first = beva_o;
} /* Line: 484*/
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 487*/ {
bevt_3_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameClass_2(bevl_top, bevp_pair);
if (bevt_2_ta_ph.bevi_bool)/* Line: 488*/ {
bevt_5_ta_ph = bevl_top.bemd_0(-1132773022);
if (bevt_5_ta_ph == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 489*/ {
bevt_6_ta_ph = bevl_top.bemd_0(-1273197378);
bevt_7_ta_ph = bevl_top.bemd_0(-1132773022);
bevt_6_ta_ph.bemd_2(1183773003, bevt_7_ta_ph, beva_o);
bevl_top.bemd_1(-498958778, null);
} /* Line: 491*/
 else /* Line: 492*/ {
bevl_top.bemd_1(-498958778, beva_o);
} /* Line: 493*/
} /* Line: 489*/
 else /* Line: 488*/ {
bevt_9_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_8_ta_ph = bevt_9_ta_ph.bem_sameClass_2(bevl_top, bevp_list);
if (bevt_8_ta_ph.bevi_bool)/* Line: 495*/ {
bevl_top.bemd_1(249444225, beva_o);
} /* Line: 496*/
 else /* Line: 497*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_4_12_JsonUnmarshaller_bels_0));
bevt_10_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_ta_ph);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 498*/
} /* Line: 488*/
} /* Line: 488*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_ta_ph = null;
bevl_m = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bem_addIn_1(bevl_m);
bevt_0_ta_ph = (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endMap_0() throws Throwable {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 512*/ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 513*/
 else /* Line: 514*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_12_JsonUnmarshaller_bels_1));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 515*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_4_ta_ph = bevp_stack.bem_peek_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameClass_2(bevt_4_ta_ph, bevp_pair);
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 521*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 521*/ {
bevt_7_ta_ph = bevp_stack.bem_peek_0();
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-1132773022);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 521*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 521*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 521*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 521*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_4_12_JsonUnmarshaller_bels_2));
bevt_8_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 522*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (new BEC_2_9_4_ContainerList()).bem_new_0();
bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 535*/ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 536*/
 else /* Line: 537*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_4_12_JsonUnmarshaller_bels_3));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 538*/
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_addIn_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
bem_addIn_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
bem_addIn_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() throws Throwable {
bem_addIn_1(null);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
bem_addIn_1(beva_int);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parserGet_0() throws Throwable {
return bevp_parser;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_pairGet_0() throws Throwable {
return bevp_pair;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_first = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_stackGet_0() throws Throwable {
return bevp_stack;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {466, 467, 468, 469, 471, 472, 477, 478, 479, 483, 483, 484, 486, 487, 487, 488, 488, 489, 489, 489, 490, 490, 490, 491, 493, 495, 495, 496, 498, 498, 498, 505, 506, 507, 507, 512, 513, 515, 515, 515, 521, 521, 521, 521, 521, 0, 521, 521, 521, 521, 0, 0, 522, 522, 522, 528, 529, 530, 535, 536, 538, 538, 538, 545, 550, 550, 555, 555, 560, 565, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 25, 26, 27, 31, 32, 33, 49, 54, 55, 57, 58, 63, 64, 65, 67, 68, 73, 74, 75, 76, 77, 80, 84, 85, 87, 90, 91, 92, 101, 102, 103, 104, 112, 114, 117, 118, 119, 134, 135, 136, 137, 142, 143, 146, 147, 148, 153, 154, 157, 161, 162, 163, 169, 170, 171, 179, 181, 184, 185, 186, 191, 196, 197, 202, 203, 207, 211, 215, 218, 222, 225, 229, 232, 236, 239, 243, 246, 250, 253};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 466 22
new 0 466 22
assign 1 467 23
new 0 467 23
assign 1 468 24
new 0 468 24
assign 1 469 25
new 0 469 25
assign 1 471 26
assign 1 472 27
new 0 472 27
new 0 477 31
parse 2 478 32
return 1 479 33
assign 1 483 49
undef 1 483 54
assign 1 484 55
assign 1 486 57
peek 0 486 57
assign 1 487 58
def 1 487 63
assign 1 488 64
new 0 488 64
assign 1 488 65
sameClass 2 488 65
assign 1 489 67
secondGet 0 489 67
assign 1 489 68
def 1 489 73
assign 1 490 74
firstGet 0 490 74
assign 1 490 75
secondGet 0 490 75
put 2 490 76
secondSet 1 491 77
secondSet 1 493 80
assign 1 495 84
new 0 495 84
assign 1 495 85
sameClass 2 495 85
addValueWhole 1 496 87
assign 1 498 90
new 0 498 90
assign 1 498 91
new 1 498 91
throw 1 498 92
assign 1 505 101
new 0 505 101
addIn 1 506 102
assign 1 507 103
new 2 507 103
push 1 507 104
assign 1 512 112
isEmptyGet 0 512 112
assign 1 513 114
pop 0 513 114
assign 1 515 117
new 0 515 117
assign 1 515 118
new 1 515 118
throw 1 515 119
assign 1 521 134
new 0 521 134
assign 1 521 135
peek 0 521 135
assign 1 521 136
sameClass 2 521 136
assign 1 521 137
not 0 521 142
assign 1 0 143
assign 1 521 146
peek 0 521 146
assign 1 521 147
secondGet 0 521 147
assign 1 521 148
undef 1 521 153
assign 1 0 154
assign 1 0 157
assign 1 522 161
new 0 522 161
assign 1 522 162
new 1 522 162
throw 1 522 163
assign 1 528 169
new 0 528 169
addIn 1 529 170
push 1 530 171
assign 1 535 179
isEmptyGet 0 535 179
assign 1 536 181
pop 0 536 181
assign 1 538 184
new 0 538 184
assign 1 538 185
new 1 538 185
throw 1 538 186
addIn 1 545 191
assign 1 550 196
new 0 550 196
addIn 1 550 197
assign 1 555 202
new 0 555 202
addIn 1 555 203
addIn 1 560 207
addIn 1 565 211
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
return 1 0 250
assign 1 0 253
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1826754149: return bem_tagGet_0();
case 1336616742: return bem_fieldNamesGet_0();
case 457178368: return bem_classNameGet_0();
case -249785676: return bem_listGet_0();
case 1875789891: return bem_pairGet_0();
case 1787710498: return bem_iteratorGet_0();
case -1273197378: return bem_firstGet_0();
case -1401305769: return bem_copy_0();
case 562138791: return bem_print_0();
case -1693451255: return bem_beginList_0();
case -286773653: return bem_handleFalse_0();
case 1038438487: return bem_handleTrue_0();
case 703659479: return bem_kvMid_0();
case -621918355: return bem_handleNull_0();
case 1466025550: return bem_beginMap_0();
case 513871126: return bem_parserGet_0();
case 1745333375: return bem_hashGet_0();
case 606880756: return bem_endList_0();
case 1653499699: return bem_create_0();
case 72748419: return bem_stackGet_0();
case -1054253204: return bem_new_0();
case 1497956054: return bem_toString_0();
case -410809157: return bem_mapGet_0();
case 437794949: return bem_endMap_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1282419489: return bem_copyTo_1(bevd_0);
case 1039831294: return bem_pairSet_1(bevd_0);
case 897088300: return bem_sameObject_1(bevd_0);
case 943183973: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case -1869622408: return bem_listSet_1(bevd_0);
case -1894503367: return bem_sameType_1(bevd_0);
case 887358230: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case -2045148476: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 586710983: return bem_notEquals_1(bevd_0);
case -1621420215: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 2119044610: return bem_parserSet_1(bevd_0);
case -93958152: return bem_equals_1(bevd_0);
case -1094345634: return bem_otherType_1(bevd_0);
case -1066425284: return bem_firstSet_1(bevd_0);
case 1134633143: return bem_stackSet_1(bevd_0);
case 400377948: return bem_addIn_1(bevd_0);
case 519586024: return bem_def_1(bevd_0);
case 112425026: return bem_undef_1(bevd_0);
case -170043597: return bem_mapSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1052889707: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651612463: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 209233844: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1399119392: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 402325359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_JsonUnmarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_12_JsonUnmarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_JsonUnmarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst = (BEC_2_4_12_JsonUnmarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;
}
}
