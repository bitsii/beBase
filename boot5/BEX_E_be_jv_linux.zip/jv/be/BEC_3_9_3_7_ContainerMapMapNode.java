package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_7_ContainerMapMapNode extends BEC_3_9_3_7_ContainerSetSetNode {
public BEC_3_9_3_7_ContainerMapMapNode() { }
private static byte[] becc_BEC_3_9_3_7_ContainerMapMapNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4D,0x61,0x70,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_3_7_ContainerMapMapNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_7_ContainerMapMapNode bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst;

public static BET_3_9_3_7_ContainerMapMapNode bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_type;

public BEC_2_6_6_SystemObject bevp_value;
public BEC_3_9_3_7_ContainerMapMapNode bem_new_3(BEC_2_6_6_SystemObject beva__hval, BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) throws Throwable {
super.bem_new_3(beva__hval, beva__key, beva__value);
bevp_value = beva__value;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerMapMapNode bem_putTo_2(BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) throws Throwable {
bevp_key = beva__key;
bevp_value = beva__value;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFrom_0() throws Throwable {
return bevp_value;
} /*method end*/
public BEC_2_6_6_SystemObject bem_valueGet_0() throws Throwable {
return bevp_value;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_valueGetDirect_0() throws Throwable {
return bevp_value;
} /*method end*/
public BEC_3_9_3_7_ContainerMapMapNode bem_valueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_value = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_3_7_ContainerMapMapNode bem_valueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_value = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {41, 44, 50, 51, 55, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 23, 26, 29, 32, 36};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 3 41 13
assign 1 44 14
assign 1 50 18
assign 1 51 19
return 1 55 23
return 1 0 26
return 1 0 29
assign 1 0 32
assign 1 0 36
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1400770094: return bem_many_0();
case -518710385: return bem_fieldNamesGet_0();
case 1049460306: return bem_valueGet_0();
case -512236724: return bem_deserializeClassNameGet_0();
case 613333849: return bem_getFrom_0();
case 1995046109: return bem_hvalGet_0();
case -2091241279: return bem_create_0();
case 1349866592: return bem_toString_0();
case 247934050: return bem_valueGetDirect_0();
case 1957608515: return bem_fieldIteratorGet_0();
case -1423578661: return bem_print_0();
case -923057320: return bem_serializationIteratorGet_0();
case 993759307: return bem_iteratorGet_0();
case -35248652: return bem_toAny_0();
case 1299948053: return bem_serializeContents_0();
case 518862870: return bem_tagGet_0();
case 1719501656: return bem_keyGet_0();
case -914347833: return bem_new_0();
case 646589914: return bem_sourceFileNameGet_0();
case -2035208893: return bem_echo_0();
case 1052263558: return bem_serializeToString_0();
case 675566088: return bem_classNameGet_0();
case 244323433: return bem_hvalGetDirect_0();
case 13807179: return bem_hashGet_0();
case 758802515: return bem_once_0();
case -245363326: return bem_copy_0();
case -1786228318: return bem_keyGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -537932837: return bem_equals_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case 2022183158: return bem_keySetDirect_1(bevd_0);
case -578915425: return bem_hvalSetDirect_1(bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case -1859438662: return bem_valueSet_1(bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case 1406609314: return bem_keySet_1(bevd_0);
case -391318188: return bem_hvalSet_1(bevd_0);
case 1707524675: return bem_valueSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1245475845: return bem_putTo_2(bevd_0, bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 777577179: return bem_new_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_9_3_7_ContainerMapMapNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_7_ContainerMapMapNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_7_ContainerMapMapNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst = (BEC_3_9_3_7_ContainerMapMapNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_type;
}
}
