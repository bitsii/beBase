package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_7_ContainerMapMapNode extends BEC_3_9_3_7_ContainerSetSetNode {
public BEC_3_9_3_7_ContainerMapMapNode() { }
private static byte[] becc_BEC_3_9_3_7_ContainerMapMapNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4D,0x61,0x70,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_3_7_ContainerMapMapNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_7_ContainerMapMapNode bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst;

public static BET_3_9_3_7_ContainerMapMapNode bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_type;

public BEC_2_6_6_SystemObject bevp_value;
public BEC_3_9_3_7_ContainerMapMapNode bem_new_3(BEC_2_6_6_SystemObject beva__hval, BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) throws Throwable {
super.bem_new_3(beva__hval, beva__key, beva__value);
bevp_value = beva__value;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerMapMapNode bem_putTo_2(BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) throws Throwable {
bevp_key = beva__key;
bevp_value = beva__value;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFrom_0() throws Throwable {
return bevp_value;
} /*method end*/
public BEC_2_6_6_SystemObject bem_valueGet_0() throws Throwable {
return bevp_value;
} /*method end*/
public BEC_3_9_3_7_ContainerMapMapNode bem_valueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_value = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {41, 44, 50, 51, 55, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 23, 26, 29};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 3 41 13
assign 1 44 14
assign 1 50 18
assign 1 51 19
return 1 55 23
return 1 0 26
assign 1 0 29
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1548224760: return bem_keyGet_0();
case 48817245: return bem_getFrom_0();
case -41023079: return bem_iteratorGet_0();
case 1043984390: return bem_once_0();
case 761778979: return bem_create_0();
case 169398438: return bem_hashGet_0();
case 1173515901: return bem_valueGet_0();
case 512670579: return bem_deserializeClassNameGet_0();
case 2090767709: return bem_many_0();
case -853332380: return bem_hvalGet_0();
case -1662177650: return bem_classNameGet_0();
case -1120421430: return bem_print_0();
case 605404858: return bem_tagGet_0();
case 751706402: return bem_copy_0();
case 2079084965: return bem_toString_0();
case 1387818040: return bem_new_0();
case 1315558702: return bem_sourceFileNameGet_0();
case -1165063866: return bem_serializeContents_0();
case -1032373300: return bem_echo_0();
case 2033350872: return bem_serializeToString_0();
case -364109840: return bem_serializationIteratorGet_0();
case 763461621: return bem_toAny_0();
case -268528295: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 936525227: return bem_keySet_1(bevd_0);
case -550476304: return bem_sameType_1(bevd_0);
case 1646725461: return bem_copyTo_1(bevd_0);
case -132994488: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 327020484: return bem_sameObject_1(bevd_0);
case -1628072592: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 915725619: return bem_valueSet_1(bevd_0);
case -95156212: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -173923543: return bem_def_1(bevd_0);
case 932249623: return bem_sameClass_1(bevd_0);
case 611966660: return bem_equals_1(bevd_0);
case -1179778534: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -728515558: return bem_hvalSet_1(bevd_0);
case 1953673516: return bem_undef_1(bevd_0);
case -46023056: return bem_notEquals_1(bevd_0);
case -400783475: return bem_undefined_1(bevd_0);
case 1296533558: return bem_otherClass_1(bevd_0);
case -1578179895: return bem_defined_1(bevd_0);
case 1479785081: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -501684028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1260862073: return bem_putTo_2(bevd_0, bevd_1);
case 1815708233: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1424200790: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1920722583: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806507047: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1733811664: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1465498474: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -228775077: return bem_new_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_9_3_7_ContainerMapMapNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_7_ContainerMapMapNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_7_ContainerMapMapNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst = (BEC_3_9_3_7_ContainerMapMapNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_type;
}
}
