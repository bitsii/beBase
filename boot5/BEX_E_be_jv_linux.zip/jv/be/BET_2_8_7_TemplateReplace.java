package be;
public class BET_2_8_7_TemplateReplace extends BETS_Object {
public BET_2_8_7_TemplateReplace() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "load_1", "load_2", "accept_2", "stepsGet_0", "stepsGetDirect_0", "stepsSet_1", "stepsSetDirect_1", "sizeGet_0", "sizeGetDirect_0", "sizeSet_1", "sizeSetDirect_1", "appendGet_0", "appendGetDirect_0", "appendSet_1", "appendSetDirect_1", "runnerGet_0", "runnerGetDirect_0", "runnerSet_1", "runnerSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "steps", "size", "append", "runner" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_8_7_TemplateReplace();
}
}
