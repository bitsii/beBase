package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_one = (new BEC_2_4_3_MathInt(1));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(1978701672);
bevt_1_ta_ph = bevl_i.bemd_0(-972761279);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(629438899);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1221*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1222*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(857822229);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1226*/ {
bevt_4_ta_ph = bevl_i.bemd_0(-972761279);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1226*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(857822229);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1228*/
 else /* Line: 1226*/ {
break;
} /* Line: 1226*/
} /* Line: 1226*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1238*/ {
bevt_3_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 1238*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_4_ta_ph = bevl_step.bem_equals_1(bevp_space);
if (bevt_4_ta_ph.bevi_bool)/* Line: 1240*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1240*/ {
bevt_5_ta_ph = bevl_step.bem_equals_1(bevp_tab);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1240*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1240*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1240*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1240*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1240*/ {
bevt_6_ta_ph = bevl_step.bem_equals_1(bevp_cr);
if (bevt_6_ta_ph.bevi_bool)/* Line: 1240*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1240*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1240*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1240*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1240*/ {
bevt_7_ta_ph = bevl_step.bem_equals_1(bevp_unixNewline);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1240*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1240*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1240*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1240*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1241*/ {
bevl_end.bevi_int++;
} /* Line: 1242*/
 else /* Line: 1243*/ {
bevl_beg.bevi_int++;
} /* Line: 1244*/
} /* Line: 1241*/
 else /* Line: 1246*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_8_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1248*/
} /* Line: 1240*/
 else /* Line: 1238*/ {
break;
} /* Line: 1238*/
} /* Line: 1238*/
if (bevl_foundChar.bevi_bool)/* Line: 1251*/ {
bevt_10_ta_ph = beva_str.bem_lengthGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_9_ta_ph);
} /* Line: 1252*/
 else /* Line: 1253*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1254*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1260*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1260*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1260*/ {
return null;
} /* Line: 1260*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_lengthGet_0();
bevt_5_ta_ph = beva_b.bem_lengthGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1266*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1266*/ {
bevl_ai.bemd_1(982689105, bevl_av);
bevl_bi.bemd_1(982689105, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1269*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1270*/
bevl_i.bevi_int++;
} /* Line: 1266*/
 else /* Line: 1266*/ {
break;
} /* Line: 1266*/
} /* Line: 1266*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1277*/ {
bevt_3_ta_ph = beva_value.bem_lengthGet_0();
if (bevt_3_ta_ph.bevi_int < bevp_one.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1277*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1277*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1278*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1284*/ {
bevt_3_ta_ph = beva_value.bem_lengthGet_0();
if (bevt_3_ta_ph.bevi_int > bevp_zero.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1284*/
 else /* Line: 1284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1284*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1285*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNumSpace_1(BEC_2_4_6_TextString beva_toCheck) throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_length = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_length = beva_toCheck.bem_lengthGet_0();
bevt_4_ta_ph = beva_toCheck.bem_lengthGet_0();
bevl_ret = (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_ta_ph);
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1294*/ {
if (bevl_j.bevi_int < bevl_length.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 1294*/ {
beva_toCheck.bem_getInt_2(bevl_j, bevl_ic);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1296*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ic.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 1296*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1296*/
 else /* Line: 1296*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 1296*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1296*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_ic.bevi_int < bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 1296*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1296*/
 else /* Line: 1296*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1296*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1296*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1296*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 1296*/ {
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ic.bevi_int < bevt_17_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 1296*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1296*/
 else /* Line: 1296*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1296*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1296*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(32));
if (bevl_ic.bevi_int == bevt_19_ta_ph.bevi_int) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 1296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1296*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1296*/ {
bevt_21_ta_ph = bevl_ret.bem_lengthGet_0();
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_22_ta_ph);
bevl_ret.bem_lengthSet_1(bevt_20_ta_ph);
bevl_ret.bem_setInt_2(bevl_j, bevl_ic);
} /* Line: 1298*/
bevl_j.bevi_int++;
} /* Line: 1294*/
 else /* Line: 1294*/ {
break;
} /* Line: 1294*/
} /* Line: 1294*/
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() throws Throwable {
return bevp_one;
} /*method end*/
public BEC_2_4_7_TextStrings bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1200, 1201, 1202, 1203, 1204, 1204, 1205, 1205, 1206, 1207, 1209, 1209, 1210, 1211, 1216, 1216, 1220, 1221, 1221, 1222, 1222, 1224, 1225, 1225, 1226, 1227, 1228, 1228, 1230, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 0, 1240, 0, 0, 0, 1240, 0, 0, 0, 1240, 0, 0, 1242, 1244, 1247, 1247, 1248, 1252, 1252, 1252, 1254, 1256, 1260, 1260, 0, 1260, 1260, 0, 0, 1260, 1261, 1261, 1261, 1261, 1262, 1263, 1264, 1265, 1266, 1266, 1266, 1267, 1268, 1269, 1270, 1270, 1270, 1266, 1273, 1273, 1273, 1277, 1277, 0, 1277, 1277, 1277, 0, 0, 1278, 1278, 1280, 1280, 1284, 1284, 1284, 1284, 1284, 0, 0, 0, 1285, 1285, 1287, 1287, 1291, 1292, 1293, 1293, 1294, 1294, 1294, 1295, 1296, 1296, 1296, 1296, 1296, 1296, 0, 0, 0, 0, 1296, 1296, 1296, 1296, 1296, 1296, 0, 0, 0, 0, 0, 0, 1296, 1296, 1296, 1296, 1296, 1296, 0, 0, 0, 0, 0, 0, 1296, 1296, 1296, 0, 0, 1297, 1297, 1297, 1297, 1298, 1294, 1301, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 53, 54, 65, 66, 67, 69, 70, 72, 73, 74, 77, 79, 80, 81, 87, 107, 108, 109, 110, 113, 115, 116, 118, 121, 123, 126, 130, 133, 135, 138, 142, 145, 147, 150, 155, 158, 162, 163, 164, 172, 173, 174, 177, 179, 200, 205, 206, 209, 214, 215, 218, 222, 224, 225, 226, 227, 228, 229, 230, 231, 232, 235, 240, 241, 242, 243, 245, 246, 247, 249, 255, 256, 257, 266, 271, 272, 275, 276, 281, 282, 285, 289, 290, 292, 293, 302, 307, 308, 309, 314, 315, 318, 322, 325, 326, 328, 329, 359, 360, 361, 362, 363, 366, 371, 372, 373, 374, 379, 380, 381, 386, 387, 390, 394, 397, 400, 401, 406, 407, 408, 413, 414, 417, 421, 424, 427, 431, 434, 435, 440, 441, 442, 447, 448, 451, 455, 458, 461, 465, 468, 469, 474, 475, 478, 482, 483, 484, 485, 486, 488, 494, 497, 500, 504, 507, 511, 514, 518, 521, 525, 528, 532, 535, 539, 542, 546, 549, 553, 556, 560, 563, 567, 570, 574, 577};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1200 35
new 0 1200 35
assign 1 1201 36
new 0 1201 36
assign 1 1202 37
new 0 1202 37
assign 1 1203 38
new 0 1203 38
assign 1 1204 39
new 0 1204 39
assign 1 1204 40
codeNew 1 1204 40
assign 1 1205 41
new 0 1205 41
assign 1 1205 42
codeNew 1 1205 42
assign 1 1206 43
new 0 1206 43
assign 1 1207 44
new 0 1207 44
assign 1 1209 45
new 0 1209 45
assign 1 1209 46
codeNew 1 1209 46
assign 1 1210 47
new 0 1210 47
assign 1 1211 48
new 0 1211 48
assign 1 1216 53
joinBuffer 2 1216 53
return 1 1216 54
assign 1 1220 65
iteratorGet 0 1220 65
assign 1 1221 66
hasNextGet 0 1221 66
assign 1 1221 67
not 0 1221 67
assign 1 1222 69
new 0 1222 69
return 1 1222 70
assign 1 1224 72
new 0 1224 72
assign 1 1225 73
nextGet 0 1225 73
addValue 1 1225 74
assign 1 1226 77
hasNextGet 0 1226 77
addValue 1 1227 79
assign 1 1228 80
nextGet 0 1228 80
addValue 1 1228 81
return 1 1230 87
assign 1 1234 107
new 0 1234 107
assign 1 1235 108
new 0 1235 108
assign 1 1236 109
new 0 1236 109
assign 1 1237 110
mbiterGet 0 1237 110
assign 1 1238 113
hasNextGet 0 1238 113
assign 1 1239 115
nextGet 0 1239 115
assign 1 1240 116
equals 1 1240 116
assign 1 0 118
assign 1 1240 121
equals 1 1240 121
assign 1 0 123
assign 1 0 126
assign 1 0 130
assign 1 1240 133
equals 1 1240 133
assign 1 0 135
assign 1 0 138
assign 1 0 142
assign 1 1240 145
equals 1 1240 145
assign 1 0 147
assign 1 0 150
incrementValue 0 1242 155
incrementValue 0 1244 158
assign 1 1247 162
new 0 1247 162
setValue 1 1247 163
assign 1 1248 164
new 0 1248 164
assign 1 1252 172
lengthGet 0 1252 172
assign 1 1252 173
subtract 1 1252 173
assign 1 1252 174
substring 2 1252 174
assign 1 1254 177
new 0 1254 177
return 1 1256 179
assign 1 1260 200
undef 1 1260 205
assign 1 0 206
assign 1 1260 209
undef 1 1260 214
assign 1 0 215
assign 1 0 218
return 1 1260 222
assign 1 1261 224
new 0 1261 224
assign 1 1261 225
lengthGet 0 1261 225
assign 1 1261 226
lengthGet 0 1261 226
assign 1 1261 227
min 2 1261 227
assign 1 1262 228
biterGet 0 1262 228
assign 1 1263 229
biterGet 0 1263 229
assign 1 1264 230
new 0 1264 230
assign 1 1265 231
new 0 1265 231
assign 1 1266 232
new 0 1266 232
assign 1 1266 235
lesser 1 1266 240
next 1 1267 241
next 1 1268 242
assign 1 1269 243
notEquals 1 1269 243
assign 1 1270 245
new 0 1270 245
assign 1 1270 246
substring 2 1270 246
return 1 1270 247
incrementValue 0 1266 249
assign 1 1273 255
new 0 1273 255
assign 1 1273 256
substring 2 1273 256
return 1 1273 257
assign 1 1277 266
undef 1 1277 271
assign 1 0 272
assign 1 1277 275
lengthGet 0 1277 275
assign 1 1277 276
lesser 1 1277 281
assign 1 0 282
assign 1 0 285
assign 1 1278 289
new 0 1278 289
return 1 1278 290
assign 1 1280 292
new 0 1280 292
return 1 1280 293
assign 1 1284 302
def 1 1284 307
assign 1 1284 308
lengthGet 0 1284 308
assign 1 1284 309
greater 1 1284 314
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 1285 325
new 0 1285 325
return 1 1285 326
assign 1 1287 328
new 0 1287 328
return 1 1287 329
assign 1 1291 359
new 0 1291 359
assign 1 1292 360
lengthGet 0 1292 360
assign 1 1293 361
lengthGet 0 1293 361
assign 1 1293 362
new 1 1293 362
assign 1 1294 363
new 0 1294 363
assign 1 1294 366
lesser 1 1294 371
getInt 2 1295 372
assign 1 1296 373
new 0 1296 373
assign 1 1296 374
greater 1 1296 379
assign 1 1296 380
new 0 1296 380
assign 1 1296 381
lesser 1 1296 386
assign 1 0 387
assign 1 0 390
assign 1 0 394
assign 1 0 397
assign 1 1296 400
new 0 1296 400
assign 1 1296 401
greater 1 1296 406
assign 1 1296 407
new 0 1296 407
assign 1 1296 408
lesser 1 1296 413
assign 1 0 414
assign 1 0 417
assign 1 0 421
assign 1 0 424
assign 1 0 427
assign 1 0 431
assign 1 1296 434
new 0 1296 434
assign 1 1296 435
greater 1 1296 440
assign 1 1296 441
new 0 1296 441
assign 1 1296 442
lesser 1 1296 447
assign 1 0 448
assign 1 0 451
assign 1 0 455
assign 1 0 458
assign 1 0 461
assign 1 0 465
assign 1 1296 468
new 0 1296 468
assign 1 1296 469
equals 1 1296 474
assign 1 0 475
assign 1 0 478
assign 1 1297 482
lengthGet 0 1297 482
assign 1 1297 483
new 0 1297 483
assign 1 1297 484
add 1 1297 484
lengthSet 1 1297 485
setInt 2 1298 486
incrementValue 0 1294 488
return 1 1301 494
return 1 0 497
assign 1 0 500
return 1 0 504
assign 1 0 507
return 1 0 511
assign 1 0 514
return 1 0 518
assign 1 0 521
return 1 0 525
assign 1 0 528
return 1 0 532
assign 1 0 535
return 1 0 539
assign 1 0 542
return 1 0 546
assign 1 0 549
return 1 0 553
assign 1 0 556
return 1 0 560
assign 1 0 563
return 1 0 567
assign 1 0 570
return 1 0 574
assign 1 0 577
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -173036160: return bem_unixNewlineGet_0();
case 1293883485: return bem_print_0();
case -1539513090: return bem_zeroGet_0();
case 912680335: return bem_colonGet_0();
case 1230276296: return bem_hashGet_0();
case -673363876: return bem_lfGet_0();
case -978770863: return bem_tabGet_0();
case 2015340465: return bem_spaceGet_0();
case -1250586953: return bem_create_0();
case -451368765: return bem_emptyGet_0();
case 704976374: return bem_default_0();
case -1202396826: return bem_oneGet_0();
case 1978701672: return bem_iteratorGet_0();
case 1836285625: return bem_new_0();
case 992700193: return bem_copy_0();
case -732201404: return bem_dosNewlineGet_0();
case 1603596732: return bem_newlineGet_0();
case -10560512: return bem_toString_0();
case 1700916014: return bem_crGet_0();
case -1093513100: return bem_quoteGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1535652192: return bem_colonSet_1(bevd_0);
case -305715842: return bem_notEquals_1(bevd_0);
case 624034613: return bem_oneSet_1(bevd_0);
case -1383998791: return bem_newlineSet_1(bevd_0);
case 2061322665: return bem_toAlphaNumSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1409349899: return bem_undef_1(bevd_0);
case 1522871629: return bem_crSet_1(bevd_0);
case 206051823: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1774508896: return bem_unixNewlineSet_1(bevd_0);
case -1926574247: return bem_def_1(bevd_0);
case 850514472: return bem_equals_1(bevd_0);
case 1022339161: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 660002617: return bem_emptySet_1(bevd_0);
case 52329100: return bem_copyTo_1(bevd_0);
case -496749868: return bem_spaceSet_1(bevd_0);
case -965300099: return bem_zeroSet_1(bevd_0);
case -2083598147: return bem_dosNewlineSet_1(bevd_0);
case 1473572728: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -820440712: return bem_quoteSet_1(bevd_0);
case -1172163498: return bem_lfSet_1(bevd_0);
case 4340875: return bem_tabSet_1(bevd_0);
case -1978152287: return bem_print_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 690472765: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1974138487: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1390292434: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1007047738: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 530385415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1507992233: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1172945119: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
