package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_one = (new BEC_2_4_3_MathInt(1));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(275008169);
bevt_1_ta_ph = bevl_i.bemd_0(562945321);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(997074806);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1317*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1318*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(-1386394571);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1322*/ {
bevt_4_ta_ph = bevl_i.bemd_0(562945321);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1322*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(-1386394571);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1324*/
 else /* Line: 1322*/ {
break;
} /* Line: 1322*/
} /* Line: 1322*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1334*/ {
bevt_3_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 1334*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_4_ta_ph = bevl_step.bem_equals_1(bevp_space);
if (bevt_4_ta_ph.bevi_bool)/* Line: 1336*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1336*/ {
bevt_5_ta_ph = bevl_step.bem_equals_1(bevp_tab);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1336*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1336*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1336*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1336*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1336*/ {
bevt_6_ta_ph = bevl_step.bem_equals_1(bevp_cr);
if (bevt_6_ta_ph.bevi_bool)/* Line: 1336*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1336*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1336*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1336*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1336*/ {
bevt_7_ta_ph = bevl_step.bem_equals_1(bevp_unixNewline);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1336*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1336*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1336*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1336*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1337*/ {
bevl_end.bevi_int++;
} /* Line: 1338*/
 else /* Line: 1339*/ {
bevl_beg.bevi_int++;
} /* Line: 1340*/
} /* Line: 1337*/
 else /* Line: 1342*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_8_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1344*/
} /* Line: 1336*/
 else /* Line: 1334*/ {
break;
} /* Line: 1334*/
} /* Line: 1334*/
if (bevl_foundChar.bevi_bool)/* Line: 1347*/ {
bevt_10_ta_ph = beva_str.bem_sizeGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_9_ta_ph);
} /* Line: 1348*/
 else /* Line: 1349*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1350*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1356*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1356*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1356*/ {
return null;
} /* Line: 1356*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1362*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1362*/ {
bevl_ai.bemd_1(1035052004, bevl_av);
bevl_bi.bemd_1(1035052004, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1365*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1366*/
bevl_i.bevi_int++;
} /* Line: 1362*/
 else /* Line: 1362*/ {
break;
} /* Line: 1362*/
} /* Line: 1362*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(275008169);
while (true)
/* Line: 1373*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(562945321);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1373*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-1386394571);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1374*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1375*/
} /* Line: 1374*/
 else /* Line: 1373*/ {
break;
} /* Line: 1373*/
} /* Line: 1373*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1382*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
if (bevt_3_ta_ph.bevi_int < bevp_one.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1382*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1382*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1382*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1383*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1389*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
if (bevt_3_ta_ph.bevi_int > bevp_zero.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1389*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1389*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1389*/
 else /* Line: 1389*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1389*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1390*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() throws Throwable {
return bevp_one;
} /*method end*/
public BEC_2_4_7_TextStrings bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1296, 1297, 1298, 1299, 1300, 1300, 1301, 1301, 1302, 1303, 1305, 1305, 1306, 1307, 1312, 1312, 1316, 1317, 1317, 1318, 1318, 1320, 1321, 1321, 1322, 1323, 1324, 1324, 1326, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 0, 1336, 0, 0, 0, 1336, 0, 0, 0, 1336, 0, 0, 1338, 1340, 1343, 1343, 1344, 1348, 1348, 1348, 1350, 1352, 1356, 1356, 0, 1356, 1356, 0, 0, 1356, 1357, 1357, 1357, 1357, 1358, 1359, 1360, 1361, 1362, 1362, 1362, 1363, 1364, 1365, 1366, 1366, 1366, 1362, 1369, 1369, 1369, 1373, 0, 1373, 1373, 1374, 1375, 1375, 1378, 1378, 1382, 1382, 0, 1382, 1382, 1382, 0, 0, 1383, 1383, 1385, 1385, 1389, 1389, 1389, 1389, 1389, 0, 0, 0, 1390, 1390, 1392, 1392, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 53, 54, 65, 66, 67, 69, 70, 72, 73, 74, 77, 79, 80, 81, 87, 107, 108, 109, 110, 113, 115, 116, 118, 121, 123, 126, 130, 133, 135, 138, 142, 145, 147, 150, 155, 158, 162, 163, 164, 172, 173, 174, 177, 179, 200, 205, 206, 209, 214, 215, 218, 222, 224, 225, 226, 227, 228, 229, 230, 231, 232, 235, 240, 241, 242, 243, 245, 246, 247, 249, 255, 256, 257, 266, 266, 269, 271, 272, 274, 275, 282, 283, 292, 297, 298, 301, 302, 307, 308, 311, 315, 316, 318, 319, 328, 333, 334, 335, 340, 341, 344, 348, 351, 352, 354, 355, 358, 361, 365, 368, 372, 375, 379, 382, 386, 389, 393, 396, 400, 403, 407, 410, 414, 417, 421, 424, 428, 431, 435, 438};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1296 35
new 0 1296 35
assign 1 1297 36
new 0 1297 36
assign 1 1298 37
new 0 1298 37
assign 1 1299 38
new 0 1299 38
assign 1 1300 39
new 0 1300 39
assign 1 1300 40
codeNew 1 1300 40
assign 1 1301 41
new 0 1301 41
assign 1 1301 42
codeNew 1 1301 42
assign 1 1302 43
new 0 1302 43
assign 1 1303 44
new 0 1303 44
assign 1 1305 45
new 0 1305 45
assign 1 1305 46
codeNew 1 1305 46
assign 1 1306 47
new 0 1306 47
assign 1 1307 48
new 0 1307 48
assign 1 1312 53
joinBuffer 2 1312 53
return 1 1312 54
assign 1 1316 65
iteratorGet 0 1316 65
assign 1 1317 66
hasNextGet 0 1317 66
assign 1 1317 67
not 0 1317 67
assign 1 1318 69
new 0 1318 69
return 1 1318 70
assign 1 1320 72
new 0 1320 72
assign 1 1321 73
nextGet 0 1321 73
addValue 1 1321 74
assign 1 1322 77
hasNextGet 0 1322 77
addValue 1 1323 79
assign 1 1324 80
nextGet 0 1324 80
addValue 1 1324 81
return 1 1326 87
assign 1 1330 107
new 0 1330 107
assign 1 1331 108
new 0 1331 108
assign 1 1332 109
new 0 1332 109
assign 1 1333 110
mbiterGet 0 1333 110
assign 1 1334 113
hasNextGet 0 1334 113
assign 1 1335 115
nextGet 0 1335 115
assign 1 1336 116
equals 1 1336 116
assign 1 0 118
assign 1 1336 121
equals 1 1336 121
assign 1 0 123
assign 1 0 126
assign 1 0 130
assign 1 1336 133
equals 1 1336 133
assign 1 0 135
assign 1 0 138
assign 1 0 142
assign 1 1336 145
equals 1 1336 145
assign 1 0 147
assign 1 0 150
incrementValue 0 1338 155
incrementValue 0 1340 158
assign 1 1343 162
new 0 1343 162
setValue 1 1343 163
assign 1 1344 164
new 0 1344 164
assign 1 1348 172
sizeGet 0 1348 172
assign 1 1348 173
subtract 1 1348 173
assign 1 1348 174
substring 2 1348 174
assign 1 1350 177
new 0 1350 177
return 1 1352 179
assign 1 1356 200
undef 1 1356 205
assign 1 0 206
assign 1 1356 209
undef 1 1356 214
assign 1 0 215
assign 1 0 218
return 1 1356 222
assign 1 1357 224
new 0 1357 224
assign 1 1357 225
sizeGet 0 1357 225
assign 1 1357 226
sizeGet 0 1357 226
assign 1 1357 227
min 2 1357 227
assign 1 1358 228
biterGet 0 1358 228
assign 1 1359 229
biterGet 0 1359 229
assign 1 1360 230
new 0 1360 230
assign 1 1361 231
new 0 1361 231
assign 1 1362 232
new 0 1362 232
assign 1 1362 235
lesser 1 1362 240
next 1 1363 241
next 1 1364 242
assign 1 1365 243
notEquals 1 1365 243
assign 1 1366 245
new 0 1366 245
assign 1 1366 246
substring 2 1366 246
return 1 1366 247
incrementValue 0 1362 249
assign 1 1369 255
new 0 1369 255
assign 1 1369 256
substring 2 1369 256
return 1 1369 257
assign 1 1373 266
iteratorGet 0 0 266
assign 1 1373 269
hasNextGet 0 1373 269
assign 1 1373 271
nextGet 0 1373 271
assign 1 1374 272
isEmpty 1 1374 272
assign 1 1375 274
new 0 1375 274
return 1 1375 275
assign 1 1378 282
new 0 1378 282
return 1 1378 283
assign 1 1382 292
undef 1 1382 297
assign 1 0 298
assign 1 1382 301
sizeGet 0 1382 301
assign 1 1382 302
lesser 1 1382 307
assign 1 0 308
assign 1 0 311
assign 1 1383 315
new 0 1383 315
return 1 1383 316
assign 1 1385 318
new 0 1385 318
return 1 1385 319
assign 1 1389 328
def 1 1389 333
assign 1 1389 334
sizeGet 0 1389 334
assign 1 1389 335
greater 1 1389 340
assign 1 0 341
assign 1 0 344
assign 1 0 348
assign 1 1390 351
new 0 1390 351
return 1 1390 352
assign 1 1392 354
new 0 1392 354
return 1 1392 355
return 1 0 358
assign 1 0 361
return 1 0 365
assign 1 0 368
return 1 0 372
assign 1 0 375
return 1 0 379
assign 1 0 382
return 1 0 386
assign 1 0 389
return 1 0 393
assign 1 0 396
return 1 0 400
assign 1 0 403
return 1 0 407
assign 1 0 410
return 1 0 414
assign 1 0 417
return 1 0 421
assign 1 0 424
return 1 0 428
assign 1 0 431
return 1 0 435
assign 1 0 438
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1668207848: return bem_create_0();
case -1501238610: return bem_quoteGet_0();
case 2018340932: return bem_tabGet_0();
case -752204173: return bem_hashGet_0();
case 1487497558: return bem_spaceGet_0();
case 925274822: return bem_oneGet_0();
case -1558425735: return bem_print_0();
case -456739017: return bem_crGet_0();
case 184194385: return bem_copy_0();
case -787880669: return bem_dosNewlineGet_0();
case -1459622248: return bem_new_0();
case -747505461: return bem_colonGet_0();
case -836132799: return bem_zeroGet_0();
case -1043856584: return bem_lfGet_0();
case -1899540842: return bem_newlineGet_0();
case 275008169: return bem_iteratorGet_0();
case -1365344062: return bem_unixNewlineGet_0();
case 2101401855: return bem_toString_0();
case 393607224: return bem_default_0();
case 1166644572: return bem_emptyGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1780267908: return bem_oneSet_1(bevd_0);
case 800860135: return bem_spaceSet_1(bevd_0);
case 182975146: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -112665378: return bem_crSet_1(bevd_0);
case -707452627: return bem_lfSet_1(bevd_0);
case 1297294292: return bem_tabSet_1(bevd_0);
case -100575596: return bem_zeroSet_1(bevd_0);
case 319966406: return bem_anyEmpty_1(bevd_0);
case 1368343175: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1974854016: return bem_unixNewlineSet_1(bevd_0);
case -2100921521: return bem_emptySet_1(bevd_0);
case 1786728161: return bem_quoteSet_1(bevd_0);
case -2098715878: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1790102834: return bem_notEquals_1(bevd_0);
case -652922507: return bem_dosNewlineSet_1(bevd_0);
case 1179391512: return bem_newlineSet_1(bevd_0);
case -1486272003: return bem_undef_1(bevd_0);
case -1703868814: return bem_def_1(bevd_0);
case 1225550205: return bem_colonSet_1(bevd_0);
case -652861342: return bem_equals_1(bevd_0);
case 154368609: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2119857882: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 648898220: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 647390111: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 384443656: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2076042115: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 145687102: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1494362942: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
