package be;
public class BET_2_5_4_BuildNode extends BETS_Object {
public BET_2_5_4_BuildNode() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameType_1", "otherType_1", "new_1", "copyLoc_1", "nextDescendGet_0", "nextAscendGet_0", "nextPeerGet_0", "priorPeerGet_0", "firstGet_0", "secondGet_0", "thirdGet_0", "isFirstGet_0", "isSecondGet_0", "isThirdGet_0", "delayDelete_0", "delete_0", "beforeInsert_1", "prepend_1", "addValue_1", "reInitContained_0", "initContained_0", "toStringBig_0", "toStringCompact_0", "depthGet_0", "prefixGet_0", "transUnitGet_0", "tmpVar_2", "inPropertiesGet_0", "addVariable_0", "syncAddVariable_0", "syncVariable_1", "anchorGet_0", "classGet_0", "scopeGet_0", "replaceWith_1", "deleteAndAppend_1", "takeContents_1", "resolveNp_0", "containedGet_0", "containedSet_1", "containerGet_0", "containerSet_1", "heldGet_0", "heldSet_1", "heldByGet_0", "heldBySet_1", "condanyGet_0", "condanySet_1", "inClassNpGet_0", "inClassNpSet_1", "inFileGet_0", "inFileSet_1", "typeDetailGet_0", "typeDetailSet_1", "delayDeleteGet_0", "delayDeleteSet_1", "nlcGet_0", "nlcSet_1", "nlecGet_0", "nlecSet_1", "wideStringGet_0", "wideStringSet_1", "buildGet_0", "buildSet_1", "constantsGet_0", "constantsSet_1", "ntypesGet_0", "ntypesSet_1", "typenameGet_0", "typenameSet_1", "inlinedGet_0", "inlinedSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "contained", "container", "held", "heldBy", "condany", "inClassNp", "inFile", "typeDetail", "delayDelete", "nlc", "nlec", "wideString", "build", "constants", "ntypes", "typename", "inlined" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_4_BuildNode();
}
}
