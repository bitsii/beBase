package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_21_XmlProcessingInstruction extends BEC_2_3_3_XmlTag {
public BEC_2_3_21_XmlProcessingInstruction() { }
private static byte[] becc_BEC_2_3_21_XmlProcessingInstruction_clname = {0x58,0x6D,0x6C,0x3A,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x69,0x6E,0x67,0x49,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_21_XmlProcessingInstruction_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_21_XmlProcessingInstruction bece_BEC_2_3_21_XmlProcessingInstruction_bevs_inst;

public static BET_2_3_21_XmlProcessingInstruction bece_BEC_2_3_21_XmlProcessingInstruction_bevs_type;

public BEC_2_4_6_TextString bevp_contents;
public BEC_2_3_21_XmlProcessingInstruction bem_new_1(BEC_2_4_6_TextString beva__contents) throws Throwable {
bevp_contents = beva__contents;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_2_3_21_XmlProcessingInstruction bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contents = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {110, 115, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 17, 20, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 110 13
return 1 115 17
return 1 0 20
assign 1 0 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 623573770: return bem_print_0();
case -228772832: return bem_iteratorGet_0();
case 1177285854: return bem_copy_0();
case 546120276: return bem_toString_0();
case -1559547014: return bem_hashGet_0();
case -1181657290: return bem_contentsGet_0();
case -348415913: return bem_new_0();
case -1282299119: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1856411169: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1566580881: return bem_notEquals_1(bevd_0);
case 534289483: return bem_equals_1(bevd_0);
case -1960594051: return bem_undef_1(bevd_0);
case 931409834: return bem_def_1(bevd_0);
case 1079308253: return bem_contentsSet_1(bevd_0);
case -682431481: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -329232359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 192102659: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1722564428: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2033261913: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_3_21_XmlProcessingInstruction_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_21_XmlProcessingInstruction_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_21_XmlProcessingInstruction();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_21_XmlProcessingInstruction.bece_BEC_2_3_21_XmlProcessingInstruction_bevs_inst = (BEC_2_3_21_XmlProcessingInstruction) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_21_XmlProcessingInstruction.bece_BEC_2_3_21_XmlProcessingInstruction_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_21_XmlProcessingInstruction.bece_BEC_2_3_21_XmlProcessingInstruction_bevs_type;
}
}
