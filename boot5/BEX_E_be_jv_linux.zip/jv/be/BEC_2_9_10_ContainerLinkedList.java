package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList extends BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_2_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 137 */ {
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /* Line: 138 */
while (true)
 /* Line: 142 */ {
if (bevl_f == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 144 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 145 */
if (bevl_fnode == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_fnode = bevl_f;
} /* Line: 149 */
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 152 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(-1227495136, null);
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_node.bemd_1(15909119, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 164 */
 else  /* Line: 165 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 167 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(-1227495136, null);
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 173 */ {
beva_node.bemd_1(-1227495136, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 176 */
 else  /* Line: 177 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 179 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(-1291625328);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(2046216883, beva_toIns);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_0;
if (beva_pos.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_2_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 193 */
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 196 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 196 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 198 */
 else  /* Line: 199 */ {
break;
} /* Line: 200 */
bevl_i.bevi_int++;
} /* Line: 202 */
 else  /* Line: 196 */ {
break;
} /* Line: 196 */
} /* Line: 196 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 204 */ {
return null;
} /* Line: 205 */
bevt_6_tmpany_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 213 */ {
bevt_1_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 213 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 215 */
 else  /* Line: 216 */ {
break;
} /* Line: 217 */
bevl_i.bevi_int++;
} /* Line: 219 */
 else  /* Line: 213 */ {
break;
} /* Line: 213 */
} /* Line: 213 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 222 */
bevt_5_tmpany_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 228 */ {
return null;
} /* Line: 228 */
bevt_1_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_3_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 233 */
 else  /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 233 */ {
bevt_5_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_heldGet_0();
return bevt_4_tmpany_phold;
} /* Line: 234 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_4_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 240 */ {
bevt_7_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_nextGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 240 */ {
bevt_10_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_nextGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_heldGet_0();
return bevt_8_tmpany_phold;
} /* Line: 241 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 247 */ {
return null;
} /* Line: 247 */
bevt_1_tmpany_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_pos.bemd_1(-2130714868, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 252 */ {
return bevp_firstNode;
} /* Line: 253 */
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 256 */ {
bevt_2_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 256 */ {
bevt_3_tmpany_phold = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 258 */
 else  /* Line: 259 */ {
break;
} /* Line: 260 */
bevl_i.bevi_int++;
} /* Line: 262 */
 else  /* Line: 256 */ {
break;
} /* Line: 256 */
} /* Line: 256 */
bevt_4_tmpany_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 264 */ {
return null;
} /* Line: 265 */
bevt_5_tmpany_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_held == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_2_tmpany_phold = beva_held.bemd_1(66254795, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
 else  /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 276 */ {
bem_addAll_1(beva_held);
} /* Line: 277 */
 else  /* Line: 278 */ {
bem_addValueWhole_1(beva_held);
} /* Line: 279 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 284 */ {
while (true)
 /* Line: 285 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(930592389);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(-1219636284);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
} /* Line: 285 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-1009286812);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 293 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 304 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 304 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 306 */
 else  /* Line: 304 */ {
break;
} /* Line: 304 */
} /* Line: 304 */
return bevl_cnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_lengthGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 317 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toNodeList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 326 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 326 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_2_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 328 */
bevl_cnt.bevi_int++;
} /* Line: 330 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
return bevl_toret;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 339 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 339 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 340 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-1756182650);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 341 */
bevl_cnt.bevi_int++;
} /* Line: 343 */
 else  /* Line: 339 */ {
break;
} /* Line: 339 */
} /* Line: 339 */
return bevl_toret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_maxGet_0();
bevt_0_tmpany_phold = bem_subList_2(beva_start, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 366 */ {
return bevl_res;
} /* Line: 367 */
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 370 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-829027431);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 371 */ {
return bevl_res;
} /* Line: 372 */
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 375 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 376 */
bevl_i.bevi_int++;
} /* Line: 370 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
return bevl_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 419 */ {
if (bevl_current == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpany_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpany_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 424 */
 else  /* Line: 419 */ {
break;
} /* Line: 419 */
} /* Line: 419 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGetDirect_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_firstNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGetDirect_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_lastNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {129, 129, 134, 135, 136, 137, 137, 138, 142, 142, 143, 144, 144, 145, 148, 148, 149, 151, 152, 154, 155, 156, 160, 161, 161, 162, 163, 164, 166, 167, 172, 173, 173, 174, 175, 176, 178, 179, 184, 188, 192, 192, 192, 193, 193, 195, 196, 196, 197, 197, 198, 202, 204, 204, 205, 207, 207, 211, 211, 212, 213, 213, 214, 214, 215, 219, 221, 221, 222, 222, 224, 224, 228, 228, 228, 229, 229, 233, 233, 233, 233, 233, 0, 0, 0, 234, 234, 234, 236, 240, 240, 240, 240, 240, 0, 0, 0, 240, 240, 240, 240, 0, 0, 0, 241, 241, 241, 241, 243, 247, 247, 247, 248, 248, 252, 252, 253, 255, 256, 256, 257, 258, 262, 264, 265, 267, 267, 271, 272, 276, 276, 276, 0, 0, 0, 277, 279, 284, 284, 285, 286, 286, 292, 292, 293, 293, 298, 299, 303, 304, 304, 305, 306, 308, 312, 312, 316, 316, 317, 317, 319, 319, 323, 324, 325, 326, 326, 327, 327, 328, 328, 330, 332, 336, 337, 338, 339, 339, 340, 340, 341, 341, 341, 343, 345, 349, 349, 353, 353, 357, 357, 361, 361, 361, 361, 365, 366, 366, 367, 369, 370, 370, 370, 371, 371, 372, 374, 375, 375, 376, 370, 379, 417, 418, 419, 419, 420, 421, 421, 422, 423, 424, 426, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 33, 34, 35, 36, 41, 42, 46, 51, 52, 53, 58, 59, 61, 66, 67, 69, 70, 76, 77, 78, 82, 83, 88, 89, 90, 91, 94, 95, 101, 102, 107, 108, 109, 110, 113, 114, 119, 123, 136, 137, 142, 143, 144, 146, 147, 150, 152, 157, 158, 163, 169, 174, 175, 177, 178, 189, 190, 191, 192, 195, 197, 202, 203, 208, 214, 219, 220, 221, 223, 224, 229, 234, 235, 237, 238, 247, 252, 253, 254, 259, 260, 263, 267, 270, 271, 272, 274, 288, 293, 294, 295, 300, 301, 304, 308, 311, 312, 313, 318, 319, 322, 326, 329, 330, 331, 332, 334, 339, 344, 345, 347, 348, 359, 360, 362, 364, 365, 368, 370, 372, 377, 383, 385, 387, 388, 392, 393, 400, 405, 406, 408, 411, 415, 418, 421, 429, 434, 437, 439, 440, 452, 457, 458, 459, 465, 466, 473, 474, 477, 479, 480, 486, 490, 491, 497, 502, 503, 504, 506, 507, 517, 518, 519, 520, 523, 525, 530, 531, 532, 534, 540, 551, 552, 553, 554, 557, 559, 564, 565, 566, 567, 569, 575, 579, 580, 584, 585, 589, 590, 596, 597, 598, 599, 611, 612, 617, 618, 620, 621, 624, 629, 630, 631, 633, 635, 636, 641, 642, 644, 650, 658, 659, 662, 667, 668, 669, 670, 671, 672, 673, 679, 683, 686, 689, 693, 697, 700, 703, 707};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 129 20
new 2 129 20
return 1 129 21
assign 1 134 33
create 0 134 33
assign 1 135 34
linkedListIteratorGet 0 135 34
assign 1 136 35
nextNodeGet 0 136 35
assign 1 137 36
undef 1 137 41
return 1 138 42
assign 1 142 46
def 1 142 51
assign 1 143 52
copy 0 143 52
assign 1 144 53
def 1 144 58
nextSet 1 145 59
assign 1 148 61
undef 1 148 66
assign 1 149 67
assign 1 151 69
assign 1 152 70
nextNodeGet 0 152 70
firstNodeSet 1 154 76
lastNodeSet 1 155 77
return 1 156 78
nextSet 1 160 82
assign 1 161 83
def 1 161 88
priorSet 1 162 89
nextSet 1 163 90
assign 1 164 91
assign 1 166 94
assign 1 167 95
nextSet 1 172 101
assign 1 173 102
def 1 173 107
nextSet 1 174 108
priorSet 1 175 109
assign 1 176 110
assign 1 178 113
assign 1 179 114
delete 0 184 119
insertBefore 1 188 123
assign 1 192 136
new 0 192 136
assign 1 192 137
equals 1 192 142
assign 1 193 143
heldGet 0 193 143
return 1 193 144
assign 1 195 146
new 0 195 146
assign 1 196 147
linkedListIteratorGet 0 196 147
assign 1 196 150
hasNextGet 0 196 150
assign 1 197 152
lesser 1 197 157
nextGet 0 198 158
incrementValue 0 202 163
assign 1 204 169
notEquals 1 204 174
return 1 205 175
assign 1 207 177
nextGet 0 207 177
return 1 207 178
assign 1 211 189
new 0 211 189
assign 1 211 190
add 1 211 190
assign 1 212 191
new 0 212 191
assign 1 213 192
linkedListIteratorGet 0 213 192
assign 1 213 195
hasNextGet 0 213 195
assign 1 214 197
lesser 1 214 202
nextGet 0 215 203
incrementValue 0 219 208
assign 1 221 214
notEquals 1 221 219
assign 1 222 220
new 0 222 220
return 1 222 221
assign 1 224 223
currentSet 1 224 223
return 1 224 224
assign 1 228 229
undef 1 228 234
return 1 228 235
assign 1 229 237
heldGet 0 229 237
return 1 229 238
assign 1 233 247
def 1 233 252
assign 1 233 253
nextGet 0 233 253
assign 1 233 254
def 1 233 259
assign 1 0 260
assign 1 0 263
assign 1 0 267
assign 1 234 270
nextGet 0 234 270
assign 1 234 271
heldGet 0 234 271
return 1 234 272
return 1 236 274
assign 1 240 288
def 1 240 293
assign 1 240 294
nextGet 0 240 294
assign 1 240 295
def 1 240 300
assign 1 0 301
assign 1 0 304
assign 1 0 308
assign 1 240 311
nextGet 0 240 311
assign 1 240 312
nextGet 0 240 312
assign 1 240 313
def 1 240 318
assign 1 0 319
assign 1 0 322
assign 1 0 326
assign 1 241 329
nextGet 0 241 329
assign 1 241 330
nextGet 0 241 330
assign 1 241 331
heldGet 0 241 331
return 1 241 332
return 1 243 334
assign 1 247 339
undef 1 247 344
return 1 247 345
assign 1 248 347
heldGet 0 248 347
return 1 248 348
assign 1 252 359
new 0 252 359
assign 1 252 360
equals 1 252 360
return 1 253 362
assign 1 255 364
new 0 255 364
assign 1 256 365
linkedListIteratorGet 0 256 365
assign 1 256 368
hasNextGet 0 256 368
assign 1 257 370
lesser 1 257 370
nextGet 0 258 372
incrementValue 0 262 377
assign 1 264 383
notEquals 1 264 383
return 1 265 385
assign 1 267 387
nextNodeGet 0 267 387
return 1 267 388
assign 1 271 392
newNode 1 271 392
appendNode 1 272 393
assign 1 276 400
def 1 276 405
assign 1 276 406
sameType 1 276 406
assign 1 0 408
assign 1 0 411
assign 1 0 415
addAll 1 277 418
addValueWhole 1 279 421
assign 1 284 429
def 1 284 434
assign 1 285 437
hasNextGet 0 285 437
assign 1 286 439
nextGet 0 286 439
addValueWhole 1 286 440
assign 1 292 452
def 1 292 457
assign 1 293 458
iteratorGet 0 293 458
iterateAdd 1 293 459
assign 1 298 465
newNode 1 298 465
prependNode 1 299 466
assign 1 303 473
new 0 303 473
assign 1 304 474
linkedListIteratorGet 0 304 474
assign 1 304 477
hasNextGet 0 304 477
nextGet 0 305 479
incrementValue 0 306 480
return 1 308 486
assign 1 312 490
lengthGet 0 312 490
return 1 312 491
assign 1 316 497
undef 1 316 502
assign 1 317 503
new 0 317 503
return 1 317 504
assign 1 319 506
new 0 319 506
return 1 319 507
assign 1 323 517
lengthGet 0 323 517
assign 1 324 518
new 1 324 518
assign 1 325 519
new 0 325 519
assign 1 326 520
linkedListIteratorGet 0 326 520
assign 1 326 523
hasNextGet 0 326 523
assign 1 327 525
lesser 1 327 530
assign 1 328 531
nextNodeGet 0 328 531
put 2 328 532
incrementValue 0 330 534
return 1 332 540
assign 1 336 551
lengthGet 0 336 551
assign 1 337 552
new 1 337 552
assign 1 338 553
new 0 338 553
assign 1 339 554
linkedListIteratorGet 0 339 554
assign 1 339 557
hasNextGet 0 339 557
assign 1 340 559
lesser 1 340 564
assign 1 341 565
nextNodeGet 0 341 565
assign 1 341 566
heldGet 0 341 566
put 2 341 567
incrementValue 0 343 569
return 1 345 575
assign 1 349 579
new 1 349 579
return 1 349 580
assign 1 353 584
new 1 353 584
return 1 353 585
assign 1 357 589
iteratorGet 0 357 589
return 1 357 590
assign 1 361 596
new 0 361 596
assign 1 361 597
maxGet 0 361 597
assign 1 361 598
subList 2 361 598
return 1 361 599
assign 1 365 611
create 0 365 611
assign 1 366 612
lesserEquals 1 366 617
return 1 367 618
assign 1 369 620
linkedListIteratorGet 0 369 620
assign 1 370 621
new 0 370 621
assign 1 370 624
lesser 1 370 629
assign 1 371 630
hasNextGet 0 371 630
assign 1 371 631
not 0 371 631
return 1 372 633
assign 1 374 635
nextGet 0 374 635
assign 1 375 636
greaterEquals 1 375 641
addValue 1 376 642
incrementValue 0 370 644
return 1 379 650
assign 1 417 658
assign 1 418 659
assign 1 419 662
def 1 419 667
assign 1 420 668
nextGet 0 420 668
assign 1 421 669
priorGet 0 421 669
nextSet 1 421 670
priorSet 1 422 671
assign 1 423 672
assign 1 424 673
assign 1 426 679
return 1 0 683
return 1 0 686
assign 1 0 689
assign 1 0 693
return 1 0 697
return 1 0 700
assign 1 0 703
assign 1 0 707
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1084284828: return bem_firstNodeGet_0();
case 1319749995: return bem_thirdGet_0();
case -341939074: return bem_isEmptyGet_0();
case -1528945516: return bem_fieldNamesGet_0();
case -826924838: return bem_fieldIteratorGet_0();
case 71860751: return bem_create_0();
case -702348589: return bem_toString_0();
case -716934857: return bem_serializeContents_0();
case -614302944: return bem_linkedListIteratorGet_0();
case -1009286812: return bem_iteratorGet_0();
case 676606025: return bem_toList_0();
case -138934452: return bem_serializationIteratorGet_0();
case 1901482140: return bem_tagGet_0();
case 1763534158: return bem_firstGet_0();
case 288240717: return bem_lengthGet_0();
case -275244597: return bem_hashGet_0();
case -713895580: return bem_lastNodeGetDirect_0();
case 2077629293: return bem_sizeGet_0();
case 1899370103: return bem_echo_0();
case 357618761: return bem_new_0();
case -162465408: return bem_classNameGet_0();
case -1774143633: return bem_once_0();
case 739152506: return bem_toNodeList_0();
case 216387563: return bem_many_0();
case -359168932: return bem_lastGet_0();
case 1881523822: return bem_deserializeClassNameGet_0();
case 354719892: return bem_lastNodeGet_0();
case -1118611827: return bem_copy_0();
case -2101622436: return bem_sourceFileNameGet_0();
case 1555639231: return bem_print_0();
case -1684591097: return bem_reverse_0();
case 478712098: return bem_firstNodeGetDirect_0();
case -2036889336: return bem_toAny_0();
case -7303412: return bem_secondGet_0();
case -1653065356: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2109980302: return bem_undef_1(bevd_0);
case 814727407: return bem_notEquals_1(bevd_0);
case -1048887207: return bem_prepend_1(bevd_0);
case -1307408610: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1493100314: return bem_otherClass_1(bevd_0);
case -959745115: return bem_otherType_1(bevd_0);
case 107285016: return bem_addValue_1(bevd_0);
case 2082558825: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 425080133: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -68723535: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -843911140: return bem_prependNode_1(bevd_0);
case 1137403549: return bem_copyTo_1(bevd_0);
case 1549020854: return bem_deleteNode_1(bevd_0);
case 2027670755: return bem_defined_1(bevd_0);
case 1353620660: return bem_sameClass_1(bevd_0);
case 252131966: return bem_firstNodeSetDirect_1(bevd_0);
case -1811486767: return bem_iterateAdd_1(bevd_0);
case -2130714868: return bem_equals_1(bevd_0);
case -1830531570: return bem_appendNode_1(bevd_0);
case 1429136271: return bem_addAll_1(bevd_0);
case -972709671: return bem_lastNodeSet_1(bevd_0);
case -76776573: return bem_addValueWhole_1(bevd_0);
case 1459678776: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1882461176: return bem_firstNodeSet_1(bevd_0);
case -1000146780: return bem_newNode_1(bevd_0);
case -1339829082: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1193778385: return bem_undefined_1(bevd_0);
case 1325575386: return bem_def_1(bevd_0);
case -1245250488: return bem_lastNodeSetDirect_1(bevd_0);
case -1082439894: return bem_sameObject_1(bevd_0);
case 66254795: return bem_sameType_1(bevd_0);
case 1671396295: return bem_getNode_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1271558857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1996246635: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 163657925: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1157880701: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 686267336: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020619337: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 894643748: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 70790709: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1168201006: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1186365239: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
