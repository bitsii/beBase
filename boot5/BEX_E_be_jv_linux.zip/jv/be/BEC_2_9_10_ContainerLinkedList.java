package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList extends BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_2_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 142*/ {
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /* Line: 143*/
while (true)
/* Line: 147*/ {
if (bevl_f == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 147*/ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 149*/ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 150*/
if (bevl_fnode == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 153*/ {
bevl_fnode = bevl_f;
} /* Line: 154*/
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 157*/
 else /* Line: 147*/ {
break;
} /* Line: 147*/
} /* Line: 147*/
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_node.bemd_1(1572665331, null);
if (bevp_lastNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 166*/ {
beva_node.bemd_1(693185831, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 169*/
 else /* Line: 170*/ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 172*/
beva_node.bemd_1(457844181, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_node.bemd_1(1572665331, null);
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 179*/ {
beva_node.bemd_1(1572665331, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 182*/
 else /* Line: 183*/ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 185*/
beva_node.bemd_1(457844181, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(1586347312);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(906883379, beva_toIns);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 200*/ {
bevt_0_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 200*/ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 201*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 202*/
 else /* Line: 203*/ {
break;
} /* Line: 204*/
bevl_i.bevi_int++;
} /* Line: 206*/
 else /* Line: 200*/ {
break;
} /* Line: 200*/
} /* Line: 200*/
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 208*/ {
return null;
} /* Line: 209*/
bevt_3_ta_ph = bevl_iter.bem_nextGet_0();
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_pos = beva_pos.bem_add_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 217*/ {
bevt_1_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 217*/ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 218*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 219*/
 else /* Line: 220*/ {
break;
} /* Line: 221*/
bevl_i.bevi_int++;
} /* Line: 223*/
 else /* Line: 217*/ {
break;
} /* Line: 217*/
} /* Line: 217*/
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 225*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 226*/
bevt_5_ta_ph = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 232*/ {
return null;
} /* Line: 232*/
bevt_1_ta_ph = bevp_firstNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_ta_ph = null;
if (bevp_firstNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 237*/ {
bevt_3_ta_ph = bevp_firstNode.bem_nextGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 237*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 237*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 237*/
 else /* Line: 237*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 237*/ {
bevt_5_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_heldGet_0();
return bevt_4_ta_ph;
} /* Line: 238*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_ta_ph = null;
if (bevp_firstNode == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_4_ta_ph = bevp_firstNode.bem_nextGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 244*/
 else /* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 244*/ {
bevt_7_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_nextGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 244*/
 else /* Line: 244*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 244*/ {
bevt_10_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_nextGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_heldGet_0();
return bevt_8_ta_ph;
} /* Line: 245*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_lastNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 251*/ {
return null;
} /* Line: 251*/
bevt_1_ta_ph = bevp_lastNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 257*/ {
bevt_0_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 257*/ {
bevt_1_ta_ph = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_1_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 259*/
 else /* Line: 260*/ {
break;
} /* Line: 261*/
bevl_i.bevi_int++;
} /* Line: 263*/
 else /* Line: 257*/ {
break;
} /* Line: 257*/
} /* Line: 257*/
bevt_2_ta_ph = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_2_ta_ph.bevi_bool)/* Line: 265*/ {
return null;
} /* Line: 266*/
bevt_3_ta_ph = bevl_iter.bem_nextNodeGet_0();
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_held == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_held, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 277*/
 else /* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 277*/ {
bem_addAll_1(beva_held);
} /* Line: 278*/
 else /* Line: 279*/ {
bem_addValueWhole_1(beva_held);
} /* Line: 280*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 285*/ {
while (true)
/* Line: 286*/ {
bevt_1_ta_ph = beva_val.bemd_0(1852223219);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 286*/ {
bevt_2_ta_ph = beva_val.bemd_0(1576658686);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 287*/
 else /* Line: 286*/ {
break;
} /* Line: 286*/
} /* Line: 286*/
} /* Line: 286*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_1_ta_ph = beva_val.bemd_0(-879452611);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 294*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 305*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 305*/ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 307*/
 else /* Line: 305*/ {
break;
} /* Line: 305*/
} /* Line: 305*/
return bevl_cnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_lengthGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 317*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 318*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toNodeList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 327*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 327*/ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 328*/ {
bevt_2_ta_ph = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_ta_ph);
} /* Line: 329*/
bevl_cnt.bevi_int++;
} /* Line: 331*/
 else /* Line: 327*/ {
break;
} /* Line: 327*/
} /* Line: 327*/
return bevl_toret;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 340*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 340*/ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 341*/ {
bevt_3_ta_ph = bevl_i.bem_nextNodeGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(959999744);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_ta_ph);
} /* Line: 342*/
bevl_cnt.bevi_int++;
} /* Line: 344*/
 else /* Line: 340*/ {
break;
} /* Line: 340*/
} /* Line: 340*/
return bevl_toret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_4_MathInts bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_maxGet_0();
bevt_0_ta_ph = bem_subList_2(beva_start, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 367*/ {
return bevl_res;
} /* Line: 368*/
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 371*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_3_ta_ph = bevl_iter.bem_hasNextGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1225080155);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 372*/ {
return bevl_res;
} /* Line: 373*/
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 376*/ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 377*/
bevl_i.bevi_int++;
} /* Line: 371*/
 else /* Line: 371*/ {
break;
} /* Line: 371*/
} /* Line: 371*/
return bevl_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_ta_ph = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
/* Line: 420*/ {
if (bevl_current == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 420*/ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_ta_ph = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_ta_ph);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 425*/
 else /* Line: 420*/ {
break;
} /* Line: 420*/
} /* Line: 420*/
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {134, 134, 139, 140, 141, 142, 142, 143, 147, 147, 148, 149, 149, 150, 153, 153, 154, 156, 157, 159, 160, 161, 165, 166, 166, 167, 168, 169, 171, 172, 174, 178, 179, 179, 180, 181, 182, 184, 185, 187, 191, 195, 199, 200, 200, 201, 201, 202, 206, 208, 208, 209, 211, 211, 215, 215, 216, 217, 217, 218, 218, 219, 223, 225, 225, 226, 226, 228, 228, 232, 232, 232, 233, 233, 237, 237, 237, 237, 237, 0, 0, 0, 238, 238, 238, 240, 244, 244, 244, 244, 244, 0, 0, 0, 244, 244, 244, 244, 0, 0, 0, 245, 245, 245, 245, 247, 251, 251, 251, 252, 252, 256, 257, 257, 258, 259, 263, 265, 266, 268, 268, 272, 273, 277, 277, 277, 277, 0, 0, 0, 278, 280, 285, 285, 286, 287, 287, 293, 293, 294, 294, 299, 300, 304, 305, 305, 306, 307, 309, 313, 313, 317, 317, 318, 318, 320, 320, 324, 325, 326, 327, 327, 328, 328, 329, 329, 331, 333, 337, 338, 339, 340, 340, 341, 341, 342, 342, 342, 344, 346, 350, 350, 354, 354, 358, 358, 362, 362, 362, 362, 366, 367, 367, 368, 370, 371, 371, 371, 372, 372, 373, 375, 376, 376, 377, 371, 380, 418, 419, 420, 420, 421, 422, 422, 423, 424, 425, 427, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 31, 32, 33, 34, 39, 40, 44, 49, 50, 51, 56, 57, 59, 64, 65, 67, 68, 74, 75, 76, 80, 81, 86, 87, 88, 89, 92, 93, 95, 100, 101, 106, 107, 108, 109, 112, 113, 115, 119, 123, 133, 134, 137, 139, 144, 145, 150, 156, 161, 162, 164, 165, 176, 177, 178, 179, 182, 184, 189, 190, 195, 201, 206, 207, 208, 210, 211, 216, 221, 222, 224, 225, 234, 239, 240, 241, 246, 247, 250, 254, 257, 258, 259, 261, 275, 280, 281, 282, 287, 288, 291, 295, 298, 299, 300, 305, 306, 309, 313, 316, 317, 318, 319, 321, 326, 331, 332, 334, 335, 344, 345, 348, 350, 352, 357, 363, 365, 367, 368, 372, 373, 381, 386, 387, 388, 390, 393, 397, 400, 403, 411, 416, 419, 421, 422, 434, 439, 440, 441, 447, 448, 455, 456, 459, 461, 462, 468, 472, 473, 479, 484, 485, 486, 488, 489, 499, 500, 501, 502, 505, 507, 512, 513, 514, 516, 522, 533, 534, 535, 536, 539, 541, 546, 547, 548, 549, 551, 557, 561, 562, 566, 567, 571, 572, 578, 579, 580, 581, 593, 594, 599, 600, 602, 603, 606, 611, 612, 613, 615, 617, 618, 623, 624, 626, 632, 640, 641, 644, 649, 650, 651, 652, 653, 654, 655, 661, 665, 668, 672, 675};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 134 18
new 2 134 18
return 1 134 19
assign 1 139 31
create 0 139 31
assign 1 140 32
linkedListIteratorGet 0 140 32
assign 1 141 33
nextNodeGet 0 141 33
assign 1 142 34
undef 1 142 39
return 1 143 40
assign 1 147 44
def 1 147 49
assign 1 148 50
copy 0 148 50
assign 1 149 51
def 1 149 56
nextSet 1 150 57
assign 1 153 59
undef 1 153 64
assign 1 154 65
assign 1 156 67
assign 1 157 68
nextNodeGet 0 157 68
firstNodeSet 1 159 74
lastNodeSet 1 160 75
return 1 161 76
nextSet 1 165 80
assign 1 166 81
def 1 166 86
priorSet 1 167 87
nextSet 1 168 88
assign 1 169 89
assign 1 171 92
assign 1 172 93
mylistSet 1 174 95
nextSet 1 178 100
assign 1 179 101
def 1 179 106
nextSet 1 180 107
priorSet 1 181 108
assign 1 182 109
assign 1 184 112
assign 1 185 113
mylistSet 1 187 115
delete 0 191 119
insertBefore 1 195 123
assign 1 199 133
new 0 199 133
assign 1 200 134
linkedListIteratorGet 0 200 134
assign 1 200 137
hasNextGet 0 200 137
assign 1 201 139
lesser 1 201 144
nextGet 0 202 145
incrementValue 0 206 150
assign 1 208 156
notEquals 1 208 161
return 1 209 162
assign 1 211 164
nextGet 0 211 164
return 1 211 165
assign 1 215 176
new 0 215 176
assign 1 215 177
add 1 215 177
assign 1 216 178
new 0 216 178
assign 1 217 179
linkedListIteratorGet 0 217 179
assign 1 217 182
hasNextGet 0 217 182
assign 1 218 184
lesser 1 218 189
nextGet 0 219 190
incrementValue 0 223 195
assign 1 225 201
notEquals 1 225 206
assign 1 226 207
new 0 226 207
return 1 226 208
assign 1 228 210
currentSet 1 228 210
return 1 228 211
assign 1 232 216
undef 1 232 221
return 1 232 222
assign 1 233 224
heldGet 0 233 224
return 1 233 225
assign 1 237 234
def 1 237 239
assign 1 237 240
nextGet 0 237 240
assign 1 237 241
def 1 237 246
assign 1 0 247
assign 1 0 250
assign 1 0 254
assign 1 238 257
nextGet 0 238 257
assign 1 238 258
heldGet 0 238 258
return 1 238 259
return 1 240 261
assign 1 244 275
def 1 244 280
assign 1 244 281
nextGet 0 244 281
assign 1 244 282
def 1 244 287
assign 1 0 288
assign 1 0 291
assign 1 0 295
assign 1 244 298
nextGet 0 244 298
assign 1 244 299
nextGet 0 244 299
assign 1 244 300
def 1 244 305
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 245 316
nextGet 0 245 316
assign 1 245 317
nextGet 0 245 317
assign 1 245 318
heldGet 0 245 318
return 1 245 319
return 1 247 321
assign 1 251 326
undef 1 251 331
return 1 251 332
assign 1 252 334
heldGet 0 252 334
return 1 252 335
assign 1 256 344
new 0 256 344
assign 1 257 345
linkedListIteratorGet 0 257 345
assign 1 257 348
hasNextGet 0 257 348
assign 1 258 350
lesser 1 258 350
nextGet 0 259 352
incrementValue 0 263 357
assign 1 265 363
notEquals 1 265 363
return 1 266 365
assign 1 268 367
nextNodeGet 0 268 367
return 1 268 368
assign 1 272 372
newNode 1 272 372
appendNode 1 273 373
assign 1 277 381
def 1 277 386
assign 1 277 387
new 0 277 387
assign 1 277 388
sameType 2 277 388
assign 1 0 390
assign 1 0 393
assign 1 0 397
addAll 1 278 400
addValueWhole 1 280 403
assign 1 285 411
def 1 285 416
assign 1 286 419
hasNextGet 0 286 419
assign 1 287 421
nextGet 0 287 421
addValueWhole 1 287 422
assign 1 293 434
def 1 293 439
assign 1 294 440
iteratorGet 0 294 440
iterateAdd 1 294 441
assign 1 299 447
newNode 1 299 447
prependNode 1 300 448
assign 1 304 455
new 0 304 455
assign 1 305 456
linkedListIteratorGet 0 305 456
assign 1 305 459
hasNextGet 0 305 459
nextGet 0 306 461
incrementValue 0 307 462
return 1 309 468
assign 1 313 472
lengthGet 0 313 472
return 1 313 473
assign 1 317 479
undef 1 317 484
assign 1 318 485
new 0 318 485
return 1 318 486
assign 1 320 488
new 0 320 488
return 1 320 489
assign 1 324 499
lengthGet 0 324 499
assign 1 325 500
new 1 325 500
assign 1 326 501
new 0 326 501
assign 1 327 502
linkedListIteratorGet 0 327 502
assign 1 327 505
hasNextGet 0 327 505
assign 1 328 507
lesser 1 328 512
assign 1 329 513
nextNodeGet 0 329 513
put 2 329 514
incrementValue 0 331 516
return 1 333 522
assign 1 337 533
lengthGet 0 337 533
assign 1 338 534
new 1 338 534
assign 1 339 535
new 0 339 535
assign 1 340 536
linkedListIteratorGet 0 340 536
assign 1 340 539
hasNextGet 0 340 539
assign 1 341 541
lesser 1 341 546
assign 1 342 547
nextNodeGet 0 342 547
assign 1 342 548
heldGet 0 342 548
put 2 342 549
incrementValue 0 344 551
return 1 346 557
assign 1 350 561
new 1 350 561
return 1 350 562
assign 1 354 566
new 1 354 566
return 1 354 567
assign 1 358 571
iteratorGet 0 358 571
return 1 358 572
assign 1 362 578
new 0 362 578
assign 1 362 579
maxGet 0 362 579
assign 1 362 580
subList 2 362 580
return 1 362 581
assign 1 366 593
create 0 366 593
assign 1 367 594
lesserEquals 1 367 599
return 1 368 600
assign 1 370 602
linkedListIteratorGet 0 370 602
assign 1 371 603
new 0 371 603
assign 1 371 606
lesser 1 371 611
assign 1 372 612
hasNextGet 0 372 612
assign 1 372 613
not 0 372 613
return 1 373 615
assign 1 375 617
nextGet 0 375 617
assign 1 376 618
greaterEquals 1 376 623
addValue 1 377 624
incrementValue 0 371 626
return 1 380 632
assign 1 418 640
assign 1 419 641
assign 1 420 644
def 1 420 649
assign 1 421 650
nextGet 0 421 650
assign 1 422 651
priorGet 0 422 651
nextSet 1 422 652
priorSet 1 423 653
assign 1 424 654
assign 1 425 655
assign 1 427 661
return 1 0 665
assign 1 0 668
return 1 0 672
assign 1 0 675
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 387568365: return bem_secondGet_0();
case -623084206: return bem_hashGet_0();
case 2073184633: return bem_thirdGet_0();
case -1706872053: return bem_isEmptyGet_0();
case 861361414: return bem_toList_0();
case -1641542932: return bem_firstGet_0();
case -1553579298: return bem_create_0();
case 292374882: return bem_toNodeList_0();
case 1716134471: return bem_linkedListIteratorGet_0();
case 424988055: return bem_lengthGet_0();
case -668031687: return bem_new_0();
case 632943252: return bem_sizeGet_0();
case -1334228416: return bem_copy_0();
case -2031824344: return bem_lastGet_0();
case -1480697901: return bem_lastNodeGet_0();
case -1425765767: return bem_reverse_0();
case -441674362: return bem_serializationIteratorGet_0();
case -1548606764: return bem_firstNodeGet_0();
case -302306326: return bem_print_0();
case -1613872813: return bem_toString_0();
case -879452611: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1275288170: return bem_prepend_1(bevd_0);
case -2083179763: return bem_def_1(bevd_0);
case -106068549: return bem_undef_1(bevd_0);
case 1553693181: return bem_copyTo_1(bevd_0);
case -1640509418: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 363705161: return bem_newNode_1(bevd_0);
case 200601382: return bem_appendNode_1(bevd_0);
case -401726745: return bem_addValueWhole_1(bevd_0);
case 1781756311: return bem_firstNodeSet_1(bevd_0);
case 183226086: return bem_equals_1(bevd_0);
case -456617752: return bem_getNode_1(bevd_0);
case 371312694: return bem_deleteNode_1(bevd_0);
case -580200024: return bem_iterateAdd_1(bevd_0);
case 1878801863: return bem_addAll_1(bevd_0);
case -202521454: return bem_prependNode_1(bevd_0);
case -1857979685: return bem_addValue_1(bevd_0);
case 1017114831: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -623349145: return bem_lastNodeSet_1(bevd_0);
case -1595922574: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 571658570: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1780160067: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1663342083: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -529409169: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -395032929: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -1187541565: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -123507493: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
