package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileWriter extends BEC_2_2_6_IOWriter {
public BEC_3_2_4_6_IOFileWriter() { }
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_0 = {0x77,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_1 = {0x61,0x62};
public static BEC_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;

public static BET_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_3_2_4_6_IOFileWriter bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevp_isClosed = be.BECS_Runtime.boolTrue;
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_openTruncate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_openAppend_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_open_1(BEC_2_4_6_TextString beva_mode) throws Throwable {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevl_append = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_fhpatha = bevp_path.bem_toString_0();
/* Line: 428*/ {
if (beva_mode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 429*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bevt_2_ta_ph = beva_mode.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 429*/
 else /* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 429*/ {
bevl_append = be.BECS_Runtime.boolTrue;
} /* Line: 430*/
 else /* Line: 431*/ {
bevl_append = be.BECS_Runtime.boolFalse;
} /* Line: 432*/
} /* Line: 429*/

      if (this.bevi_os == null) {
        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        this.bevi_os = new java.io.FileOutputStream(bevls_f, bevl_append.bevi_bool);
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {388, 389, 389, 393, 393, 397, 397, 401, 401, 412, 429, 429, 429, 429, 0, 0, 0, 430, 432, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 23, 24, 29, 30, 35, 36, 52, 54, 59, 60, 61, 63, 66, 70, 73, 76, 88, 91, 94, 98};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 388 16
new 0 388 16
assign 1 389 17
new 1 389 17
pathSet 1 389 18
assign 1 393 23
new 0 393 23
open 1 393 24
assign 1 397 29
new 0 397 29
open 1 397 30
assign 1 401 35
new 0 401 35
open 1 401 36
assign 1 412 52
toString 0 412 52
assign 1 429 54
def 1 429 59
assign 1 429 60
new 0 429 60
assign 1 429 61
equals 1 429 61
assign 1 0 63
assign 1 0 66
assign 1 0 70
assign 1 430 73
new 0 430 73
assign 1 432 76
new 0 432 76
return 1 0 88
return 1 0 91
assign 1 0 94
assign 1 0 98
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1915513690: return bem_classNameGet_0();
case 1604055525: return bem_hashGet_0();
case 291628629: return bem_isClosedGet_0();
case 428447159: return bem_close_0();
case -1081907606: return bem_vfileGet_0();
case -1902821230: return bem_sourceFileNameGet_0();
case 1845392880: return bem_pathGet_0();
case 1476572399: return bem_new_0();
case 807844599: return bem_copy_0();
case 708488762: return bem_create_0();
case -436514878: return bem_echo_0();
case 1534778339: return bem_serializeContents_0();
case 886843570: return bem_open_0();
case 290193605: return bem_toString_0();
case -129556018: return bem_fieldNamesGet_0();
case -656810579: return bem_pathGetDirect_0();
case -523484640: return bem_vfileGetDirect_0();
case 210349252: return bem_deserializeClassNameGet_0();
case -490903157: return bem_openAppend_0();
case 1528097206: return bem_serializeToString_0();
case -129423987: return bem_openTruncate_0();
case 1599267410: return bem_extOpen_0();
case 198473032: return bem_tagGet_0();
case -1781364078: return bem_print_0();
case 1057028028: return bem_fieldIteratorGet_0();
case 1524789695: return bem_isClosedGetDirect_0();
case 715553388: return bem_serializationIteratorGet_0();
case -450907329: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -658117728: return bem_vfileSet_1(bevd_0);
case 1825333525: return bem_pathSetDirect_1(bevd_0);
case -472492109: return bem_pathSet_1(bevd_0);
case 1859153072: return bem_undef_1(bevd_0);
case 1114174001: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 938863663: return bem_def_1(bevd_0);
case -746609219: return bem_sameObject_1(bevd_0);
case -2140357933: return bem_vfileSetDirect_1(bevd_0);
case -1606202955: return bem_copyTo_1(bevd_0);
case 1342151407: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 530665401: return bem_isClosedSetDirect_1(bevd_0);
case -835119407: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 909428606: return bem_otherClass_1(bevd_0);
case 1141872328: return bem_new_1(bevd_0);
case -999927226: return bem_notEquals_1(bevd_0);
case 1528010380: return bem_sameClass_1(bevd_0);
case -1865008630: return bem_equals_1(bevd_0);
case -73400120: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 1880525273: return bem_otherType_1(bevd_0);
case -596782293: return bem_isClosedSet_1(bevd_0);
case 84273825: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -575460023: return bem_sameType_1(bevd_0);
case -1768944168: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 506082618: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1582482490: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1978405023: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953140974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1983033893: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileWriter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileWriter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_6_IOFileWriter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst = (BEC_3_2_4_6_IOFileWriter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_type;
}
}
