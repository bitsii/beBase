package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_8_BuildNamePath extends BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_0, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_1, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_2, 1));
public static BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;

public static BET_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_type;

public BEC_2_4_6_TextString bevp_label;
public BEC_2_5_8_BuildNamePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_tmpany_phold.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
if (bevp_label == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 20 */ {
bevt_2_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lastGet_0();
return bevt_1_tmpany_phold;
} /* Line: 21 */
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_0;
bevt_1_tmpany_phold = bevl_oldpath.bem_equals_1(bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 29 */ {
return this;
} /* Line: 29 */
bevt_4_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_1;
bevt_3_tmpany_phold = bevl_oldpath.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 30 */ {
return this;
} /* Line: 30 */
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(-752060279);
bevt_6_tmpany_phold = bevl_tunode.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1674690068);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_tmpany_phold.bemd_1(2070262258, bevl_fstep);
if (bevl_par == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_10_tmpany_phold = beva_node.bemd_0(1052159844);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-1794766539);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1674690068);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_tmpany_phold.bemd_1(2070262258, bevl_fstep);
} /* Line: 35 */
if (bevl_par == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_14_tmpany_phold = bem_pathGet_0();
bevt_15_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_2;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_has_1(bevt_15_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 37 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 37 */ {
bevl_np2 = bem_deleteFirstStep_0();
bevl_np = bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 40 */
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(90329278);
if (bevl_clnode == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_17_tmpany_phold = bevl_clnode.bem_heldGet_0();
bevt_17_tmpany_phold.bemd_1(-1259171679, this);
} /* Line: 44 */
return this;
} /*method end*/
public final BEC_2_4_6_TextString bem_labelGetDirect_0() throws Throwable {
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_labelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15, 15, 16, 20, 20, 21, 21, 21, 24, 28, 29, 29, 29, 30, 30, 30, 31, 32, 33, 33, 33, 34, 34, 35, 35, 35, 35, 37, 37, 37, 37, 37, 37, 37, 0, 0, 0, 38, 39, 40, 42, 43, 43, 44, 44, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 22, 29, 34, 35, 36, 37, 39, 67, 68, 69, 71, 73, 74, 76, 78, 79, 80, 81, 82, 83, 88, 89, 90, 91, 92, 94, 99, 100, 101, 102, 103, 108, 109, 112, 116, 119, 120, 121, 123, 124, 129, 130, 131, 136, 139, 143};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 15 20
new 0 15 20
assign 1 15 21
colonGet 0 15 21
fromString 1 16 22
assign 1 20 29
undef 1 20 34
assign 1 21 35
split 1 21 35
assign 1 21 36
lastGet 0 21 36
return 1 21 37
return 1 24 39
assign 1 28 67
pathGet 0 28 67
assign 1 29 68
new 0 29 68
assign 1 29 69
equals 1 29 69
return 1 29 71
assign 1 30 73
new 0 30 73
assign 1 30 74
equals 1 30 74
return 1 30 76
assign 1 31 78
firstStepGet 0 31 78
assign 1 32 79
transUnitGet 0 32 79
assign 1 33 80
heldGet 0 33 80
assign 1 33 81
aliasedGet 0 33 81
assign 1 33 82
get 1 33 82
assign 1 34 83
undef 1 34 88
assign 1 35 89
buildGet 0 35 89
assign 1 35 90
emitDataGet 0 35 90
assign 1 35 91
aliasedGet 0 35 91
assign 1 35 92
get 1 35 92
assign 1 37 94
def 1 37 99
assign 1 37 100
pathGet 0 37 100
assign 1 37 101
new 0 37 101
assign 1 37 102
has 1 37 102
assign 1 37 103
not 0 37 108
assign 1 0 109
assign 1 0 112
assign 1 0 116
assign 1 38 119
deleteFirstStep 0 38 119
assign 1 39 120
add 1 39 120
assign 1 40 121
pathGet 0 40 121
assign 1 42 123
classGet 0 42 123
assign 1 43 124
def 1 43 129
assign 1 44 130
heldGet 0 44 130
addUsed 1 44 131
return 1 0 136
assign 1 0 139
assign 1 0 143
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1629544591: return bem_many_0();
case -217835874: return bem_tagGet_0();
case 135177629: return bem_stepListGet_0();
case -600310534: return bem_labelGetDirect_0();
case 954180722: return bem_deleteFirstStep_0();
case -139666523: return bem_separatorGetDirect_0();
case 2080509787: return bem_makeAbsolute_0();
case 847337627: return bem_copy_0();
case -350098250: return bem_firstStepGet_0();
case -915808255: return bem_serializationIteratorGet_0();
case 346235852: return bem_sourceFileNameGet_0();
case 1611055106: return bem_fieldNamesGet_0();
case -1278273894: return bem_toAny_0();
case -709828994: return bem_isAbsoluteGet_0();
case 1132290948: return bem_separatorGet_0();
case 1981654959: return bem_once_0();
case -638442685: return bem_echo_0();
case -397559289: return bem_fieldIteratorGet_0();
case 1230302912: return bem_hashGet_0();
case 402127104: return bem_stepsGet_0();
case 718789172: return bem_iteratorGet_0();
case -207569400: return bem_serializeToString_0();
case -360613383: return bem_serializeContents_0();
case 357537975: return bem_classNameGet_0();
case -22393727: return bem_create_0();
case 963715601: return bem_lastStepGet_0();
case -1762356041: return bem_toString_0();
case -507124439: return bem_new_0();
case -980589980: return bem_pathGet_0();
case -480687649: return bem_print_0();
case -1830405602: return bem_makeNonAbsolute_0();
case -2019640494: return bem_labelGet_0();
case -592396688: return bem_parentGet_0();
case -1308933810: return bem_deserializeClassNameGet_0();
case -1525888183: return bem_pathGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1314740064: return bem_add_1(bevd_0);
case 1387628079: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -787624360: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1999267396: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 580318355: return bem_otherType_1(bevd_0);
case 604091769: return bem_pathSetDirect_1(bevd_0);
case 1379835000: return bem_defined_1(bevd_0);
case 1273353241: return bem_notEquals_1(bevd_0);
case 1775222585: return bem_separatorSet_1(bevd_0);
case -279917156: return bem_labelSet_1(bevd_0);
case -960101702: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1170652492: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 1418552655: return bem_def_1(bevd_0);
case -665968375: return bem_sameType_1(bevd_0);
case -1256041694: return bem_copyTo_1(bevd_0);
case 593171335: return bem_pathSet_1(bevd_0);
case -1263961885: return bem_otherClass_1(bevd_0);
case 1773482649: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -223628928: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1281008818: return bem_resolve_1(bevd_0);
case 1787128072: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -794657115: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2056947488: return bem_sameClass_1(bevd_0);
case -408502512: return bem_equals_1(bevd_0);
case -1010536484: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -436547338: return bem_undefined_1(bevd_0);
case 1530291279: return bem_sameObject_1(bevd_0);
case 897546281: return bem_addStep_1(bevd_0);
case 2105249017: return bem_addSteps_1(bevd_0);
case 321693734: return bem_undef_1(bevd_0);
case -1427494634: return bem_labelSetDirect_1(bevd_0);
case 1849763669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1850585622: return bem_separatorSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -318431301: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1138830036: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -799307739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2124098680: return bem_addSteps_2(bevd_0, bevd_1);
case -1103544796: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -554397969: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 975610887: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 468697030: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2122183893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildNamePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_type;
}
}
