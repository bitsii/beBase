package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_8_BuildNamePath extends BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
public static BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;

public static BET_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_type;

public BEC_2_4_6_TextString bevp_label;
public BEC_2_5_8_BuildNamePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_ta_ph.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
if (bevp_label == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 19*/ {
bevt_2_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_1_ta_ph = bevt_2_ta_ph.bem_lastGet_0();
return bevt_1_ta_ph;
} /* Line: 20*/
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_8_BuildNamePath_bels_0));
bevt_1_ta_ph = bevl_oldpath.bem_equals_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 28*/ {
return this;
} /* Line: 28*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_8_BuildNamePath_bels_1));
bevt_3_ta_ph = bevl_oldpath.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 29*/ {
return this;
} /* Line: 29*/
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(622637620);
bevt_6_ta_ph = bevl_tunode.bem_heldGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(670377659);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_ta_ph.bemd_1(-1666673182, bevl_fstep);
if (bevl_par == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 33*/ {
bevt_10_ta_ph = beva_node.bemd_0(1585567932);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1467557023);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(670377659);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_ta_ph.bemd_1(-1666673182, bevl_fstep);
} /* Line: 34*/
if (bevl_par == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_14_ta_ph = bem_pathGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_8_BuildNamePath_bels_2));
bevt_13_ta_ph = bevt_14_ta_ph.bem_has_1(bevt_15_ta_ph);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 36*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 36*/ {
bevl_np2 = bem_deleteFirstStep_0();
bevl_np = bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 39*/
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(-1922067655);
if (bevl_clnode == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_17_ta_ph = bevl_clnode.bem_heldGet_0();
bevt_17_ta_ph.bemd_1(1958569326, this);
} /* Line: 43*/
return this;
} /*method end*/
public final BEC_2_4_6_TextString bem_labelGetDirect_0() throws Throwable {
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_labelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 14, 15, 19, 19, 20, 20, 20, 23, 27, 28, 28, 28, 29, 29, 29, 30, 31, 32, 32, 32, 33, 33, 34, 34, 34, 34, 36, 36, 36, 36, 36, 36, 36, 0, 0, 0, 37, 38, 39, 41, 42, 42, 43, 43, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 26, 31, 32, 33, 34, 36, 64, 65, 66, 68, 70, 71, 73, 75, 76, 77, 78, 79, 80, 85, 86, 87, 88, 89, 91, 96, 97, 98, 99, 100, 105, 106, 109, 113, 116, 117, 118, 120, 121, 126, 127, 128, 133, 136, 140};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 17
new 0 14 17
assign 1 14 18
colonGet 0 14 18
fromString 1 15 19
assign 1 19 26
undef 1 19 31
assign 1 20 32
split 1 20 32
assign 1 20 33
lastGet 0 20 33
return 1 20 34
return 1 23 36
assign 1 27 64
pathGet 0 27 64
assign 1 28 65
new 0 28 65
assign 1 28 66
equals 1 28 66
return 1 28 68
assign 1 29 70
new 0 29 70
assign 1 29 71
equals 1 29 71
return 1 29 73
assign 1 30 75
firstStepGet 0 30 75
assign 1 31 76
transUnitGet 0 31 76
assign 1 32 77
heldGet 0 32 77
assign 1 32 78
aliasedGet 0 32 78
assign 1 32 79
get 1 32 79
assign 1 33 80
undef 1 33 85
assign 1 34 86
buildGet 0 34 86
assign 1 34 87
emitDataGet 0 34 87
assign 1 34 88
aliasedGet 0 34 88
assign 1 34 89
get 1 34 89
assign 1 36 91
def 1 36 96
assign 1 36 97
pathGet 0 36 97
assign 1 36 98
new 0 36 98
assign 1 36 99
has 1 36 99
assign 1 36 100
not 0 36 105
assign 1 0 106
assign 1 0 109
assign 1 0 113
assign 1 37 116
deleteFirstStep 0 37 116
assign 1 38 117
add 1 38 117
assign 1 39 118
pathGet 0 39 118
assign 1 41 120
classGet 0 41 120
assign 1 42 121
def 1 42 126
assign 1 43 127
heldGet 0 43 127
addUsed 1 43 128
return 1 0 133
assign 1 0 136
assign 1 0 140
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1259946050: return bem_parentGet_0();
case -63568776: return bem_makeNonAbsolute_0();
case -231109830: return bem_pathGetDirect_0();
case -777055641: return bem_copy_0();
case -1223695676: return bem_firstStepGet_0();
case 1182219629: return bem_lastStepGet_0();
case -569920311: return bem_pathGet_0();
case -1558163991: return bem_labelGetDirect_0();
case -1786334802: return bem_classNameGet_0();
case 266241134: return bem_separatorGetDirect_0();
case -1699409236: return bem_stepListGet_0();
case 889719110: return bem_print_0();
case -843133681: return bem_separatorGet_0();
case -1136648067: return bem_sourceFileNameGet_0();
case 2123289296: return bem_labelGet_0();
case 1773293529: return bem_hashGet_0();
case -517387544: return bem_isAbsoluteGet_0();
case 1073013382: return bem_iteratorGet_0();
case 989732871: return bem_new_0();
case -1993034141: return bem_makeAbsolute_0();
case 1171811488: return bem_deleteFirstStep_0();
case -362215698: return bem_toString_0();
case 1812616799: return bem_create_0();
case 319726380: return bem_stepsGet_0();
case 1648346602: return bem_tagGet_0();
case 2140998184: return bem_fieldNamesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 723074903: return bem_addStep_1(bevd_0);
case 319814146: return bem_sameClass_1(bevd_0);
case 1074356718: return bem_labelSetDirect_1(bevd_0);
case -700370392: return bem_pathSet_1(bevd_0);
case -583708652: return bem_otherType_1(bevd_0);
case -42885212: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1978132891: return bem_copyTo_1(bevd_0);
case 1295257783: return bem_otherClass_1(bevd_0);
case 980301665: return bem_sameType_1(bevd_0);
case 1361415688: return bem_labelSet_1(bevd_0);
case 1276821859: return bem_pathSetDirect_1(bevd_0);
case 64942054: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 1550384130: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 308709758: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1292466096: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1679425113: return bem_resolve_1(bevd_0);
case -862963517: return bem_addSteps_1(bevd_0);
case 1099902675: return bem_separatorSet_1(bevd_0);
case -1402519729: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 137331971: return bem_undef_1(bevd_0);
case 173786785: return bem_add_1(bevd_0);
case 754161535: return bem_equals_1(bevd_0);
case -1578954177: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1197299386: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1764717463: return bem_notEquals_1(bevd_0);
case -501085090: return bem_separatorSetDirect_1(bevd_0);
case -1875172918: return bem_sameObject_1(bevd_0);
case -930132980: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 831817632: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1681451114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -121478277: return bem_addSteps_2(bevd_0, bevd_1);
case -1450498968: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1679839886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1690490315: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1805853509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildNamePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_type;
}
}
