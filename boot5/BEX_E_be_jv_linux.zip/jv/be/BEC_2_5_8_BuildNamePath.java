package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_8_BuildNamePath extends BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_0, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_1, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_2, 1));
public static BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;

public static BET_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_type;

public BEC_2_4_6_TextString bevp_label;
public BEC_2_5_8_BuildNamePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_ta_ph.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
if (bevp_label == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 19*/ {
bevt_2_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_1_ta_ph = bevt_2_ta_ph.bem_lastGet_0();
return bevt_1_ta_ph;
} /* Line: 20*/
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_ta_ph = bece_BEC_2_5_8_BuildNamePath_bevo_0;
bevt_1_ta_ph = bevl_oldpath.bem_equals_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 28*/ {
return this;
} /* Line: 28*/
bevt_4_ta_ph = bece_BEC_2_5_8_BuildNamePath_bevo_1;
bevt_3_ta_ph = bevl_oldpath.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 29*/ {
return this;
} /* Line: 29*/
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(116707039);
bevt_6_ta_ph = bevl_tunode.bem_heldGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(768370903);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_ta_ph.bemd_1(-271728426, bevl_fstep);
if (bevl_par == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 33*/ {
bevt_10_ta_ph = beva_node.bemd_0(1970107535);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1779132875);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(768370903);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_ta_ph.bemd_1(-271728426, bevl_fstep);
} /* Line: 34*/
if (bevl_par == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_14_ta_ph = bem_pathGet_0();
bevt_15_ta_ph = bece_BEC_2_5_8_BuildNamePath_bevo_2;
bevt_13_ta_ph = bevt_14_ta_ph.bem_has_1(bevt_15_ta_ph);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 36*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 36*/ {
bevl_np2 = bem_deleteFirstStep_0();
bevl_np = bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 39*/
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(829739757);
if (bevl_clnode == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_17_ta_ph = bevl_clnode.bem_heldGet_0();
bevt_17_ta_ph.bemd_1(-102473403, this);
} /* Line: 43*/
return this;
} /*method end*/
public final BEC_2_4_6_TextString bem_labelGetDirect_0() throws Throwable {
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_labelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 14, 15, 19, 19, 20, 20, 20, 23, 27, 28, 28, 28, 29, 29, 29, 30, 31, 32, 32, 32, 33, 33, 34, 34, 34, 34, 36, 36, 36, 36, 36, 36, 36, 0, 0, 0, 37, 38, 39, 41, 42, 42, 43, 43, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 22, 29, 34, 35, 36, 37, 39, 67, 68, 69, 71, 73, 74, 76, 78, 79, 80, 81, 82, 83, 88, 89, 90, 91, 92, 94, 99, 100, 101, 102, 103, 108, 109, 112, 116, 119, 120, 121, 123, 124, 129, 130, 131, 136, 139, 143};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 20
new 0 14 20
assign 1 14 21
colonGet 0 14 21
fromString 1 15 22
assign 1 19 29
undef 1 19 34
assign 1 20 35
split 1 20 35
assign 1 20 36
lastGet 0 20 36
return 1 20 37
return 1 23 39
assign 1 27 67
pathGet 0 27 67
assign 1 28 68
new 0 28 68
assign 1 28 69
equals 1 28 69
return 1 28 71
assign 1 29 73
new 0 29 73
assign 1 29 74
equals 1 29 74
return 1 29 76
assign 1 30 78
firstStepGet 0 30 78
assign 1 31 79
transUnitGet 0 31 79
assign 1 32 80
heldGet 0 32 80
assign 1 32 81
aliasedGet 0 32 81
assign 1 32 82
get 1 32 82
assign 1 33 83
undef 1 33 88
assign 1 34 89
buildGet 0 34 89
assign 1 34 90
emitDataGet 0 34 90
assign 1 34 91
aliasedGet 0 34 91
assign 1 34 92
get 1 34 92
assign 1 36 94
def 1 36 99
assign 1 36 100
pathGet 0 36 100
assign 1 36 101
new 0 36 101
assign 1 36 102
has 1 36 102
assign 1 36 103
not 0 36 108
assign 1 0 109
assign 1 0 112
assign 1 0 116
assign 1 37 119
deleteFirstStep 0 37 119
assign 1 38 120
add 1 38 120
assign 1 39 121
pathGet 0 39 121
assign 1 41 123
classGet 0 41 123
assign 1 42 124
def 1 42 129
assign 1 43 130
heldGet 0 43 130
addUsed 1 43 131
return 1 0 136
assign 1 0 139
assign 1 0 143
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1238524057: return bem_print_0();
case -1851472893: return bem_once_0();
case -1089393200: return bem_parentGet_0();
case 205150354: return bem_new_0();
case 2103973139: return bem_labelGetDirect_0();
case -912342775: return bem_deserializeClassNameGet_0();
case -298341639: return bem_separatorGet_0();
case -468107138: return bem_makeAbsolute_0();
case 350294433: return bem_deleteFirstStep_0();
case 217381802: return bem_serializationIteratorGet_0();
case 1904821745: return bem_lastStepGet_0();
case 993286746: return bem_echo_0();
case 130791480: return bem_labelGet_0();
case -364134377: return bem_stepListGet_0();
case -992634121: return bem_tagGet_0();
case 814015164: return bem_copy_0();
case -777537417: return bem_serializeContents_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -1109836353: return bem_pathGet_0();
case -438289515: return bem_fieldIteratorGet_0();
case -1426056679: return bem_hashGet_0();
case 609400335: return bem_pathGetDirect_0();
case 1813327301: return bem_separatorGetDirect_0();
case 310047227: return bem_fieldNamesGet_0();
case 485978629: return bem_stepsGet_0();
case -1714583788: return bem_classNameGet_0();
case -1392846471: return bem_toString_0();
case -2136344072: return bem_isAbsoluteGet_0();
case -664640601: return bem_firstStepGet_0();
case 137910263: return bem_create_0();
case 78412540: return bem_toAny_0();
case -1331626162: return bem_iteratorGet_0();
case -1079456517: return bem_many_0();
case -1634199288: return bem_makeNonAbsolute_0();
case 221458969: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1038712011: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case -154887457: return bem_resolve_1(bevd_0);
case 966381947: return bem_separatorSetDirect_1(bevd_0);
case -390527872: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 1912040601: return bem_labelSetDirect_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case -1747997039: return bem_labelSet_1(bevd_0);
case -202882393: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case -1774284588: return bem_addStep_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -350348142: return bem_pathSet_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 2018787760: return bem_addSteps_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 78930112: return bem_add_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case -712220047: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 827207962: return bem_separatorSet_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 566797671: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 236257392: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1915581692: return bem_pathSetDirect_1(bevd_0);
case 1619843567: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 290892918: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -84696831: return bem_addSteps_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildNamePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_type;
}
}
