package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_8_BuildNamePath extends BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_0, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_1, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_2, 1));
public static BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;
public BEC_2_4_6_TextString bevp_label;
public BEC_2_5_8_BuildNamePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_tmpany_phold.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
if (bevp_label == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 20 */ {
bevt_2_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lastGet_0();
return bevt_1_tmpany_phold;
} /* Line: 21 */
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_0;
bevt_1_tmpany_phold = bevl_oldpath.bem_equals_1(bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 29 */ {
return this;
} /* Line: 29 */
bevt_4_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_1;
bevt_3_tmpany_phold = bevl_oldpath.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 30 */ {
return this;
} /* Line: 30 */
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(1965709327);
bevt_6_tmpany_phold = bevl_tunode.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(384416760);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_tmpany_phold.bemd_1(-308618888, bevl_fstep);
if (bevl_par == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_10_tmpany_phold = beva_node.bemd_0(1642913038);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(277188030);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(384416760);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_tmpany_phold.bemd_1(-308618888, bevl_fstep);
} /* Line: 35 */
if (bevl_par == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_14_tmpany_phold = bem_pathGet_0();
bevt_15_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_2;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_has_1(bevt_15_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 37 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 37 */ {
bevl_np2 = bem_deleteFirstStep_0();
bevl_np = bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 40 */
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(1514066959);
if (bevl_clnode == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_17_tmpany_phold = bevl_clnode.bem_heldGet_0();
bevt_17_tmpany_phold.bemd_1(1408640377, this);
} /* Line: 44 */
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15, 15, 16, 20, 20, 21, 21, 21, 24, 28, 29, 29, 29, 30, 30, 30, 31, 32, 33, 33, 33, 34, 34, 35, 35, 35, 35, 37, 37, 37, 37, 37, 37, 37, 0, 0, 0, 38, 39, 40, 42, 43, 43, 44, 44, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 26, 31, 32, 33, 34, 36, 64, 65, 66, 68, 70, 71, 73, 75, 76, 77, 78, 79, 80, 85, 86, 87, 88, 89, 91, 96, 97, 98, 99, 100, 105, 106, 109, 113, 116, 117, 118, 120, 121, 126, 127, 128, 133};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 15 17
new 0 15 17
assign 1 15 18
colonGet 0 15 18
fromString 1 16 19
assign 1 20 26
undef 1 20 31
assign 1 21 32
split 1 21 32
assign 1 21 33
lastGet 0 21 33
return 1 21 34
return 1 24 36
assign 1 28 64
pathGet 0 28 64
assign 1 29 65
new 0 29 65
assign 1 29 66
equals 1 29 66
return 1 29 68
assign 1 30 70
new 0 30 70
assign 1 30 71
equals 1 30 71
return 1 30 73
assign 1 31 75
firstStepGet 0 31 75
assign 1 32 76
transUnitGet 0 32 76
assign 1 33 77
heldGet 0 33 77
assign 1 33 78
aliasedGet 0 33 78
assign 1 33 79
get 1 33 79
assign 1 34 80
undef 1 34 85
assign 1 35 86
buildGet 0 35 86
assign 1 35 87
emitDataGet 0 35 87
assign 1 35 88
aliasedGet 0 35 88
assign 1 35 89
get 1 35 89
assign 1 37 91
def 1 37 96
assign 1 37 97
pathGet 0 37 97
assign 1 37 98
new 0 37 98
assign 1 37 99
has 1 37 99
assign 1 37 100
not 0 37 105
assign 1 0 106
assign 1 0 109
assign 1 0 113
assign 1 38 116
deleteFirstStep 0 38 116
assign 1 39 117
add 1 39 117
assign 1 40 118
pathGet 0 40 118
assign 1 42 120
classGet 0 42 120
assign 1 43 121
def 1 43 126
assign 1 44 127
heldGet 0 44 127
addUsed 1 44 128
assign 1 0 133
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -39484966: return bem_parentGet_0();
case 2057616018: return bem_isAbsoluteGet_0();
case -981705277: return bem_stepListGet_0();
case -748130189: return bem_echo_0();
case -899981572: return bem_stepsGet_0();
case -1256903143: return bem_print_0();
case -1693411633: return bem_fieldIteratorGet_0();
case -2089883321: return bem_new_0();
case -1685830259: return bem_separatorGet_0();
case 721298840: return bem_serializationIteratorGet_0();
case -676718137: return bem_lastStepGet_0();
case 1330053746: return bem_classNameGet_0();
case -1666892068: return bem_once_0();
case 532724685: return bem_pathGet_0();
case -900855445: return bem_makeNonAbsolute_0();
case 394710523: return bem_toAny_0();
case 978873391: return bem_deserializeClassNameGet_0();
case -1755437106: return bem_serializeContents_0();
case -705846490: return bem_labelGet_0();
case -266150550: return bem_many_0();
case -67323485: return bem_create_0();
case 895906767: return bem_toString_0();
case 1842062757: return bem_deleteFirstStep_0();
case -907223016: return bem_iteratorGet_0();
case 648643859: return bem_sourceFileNameGet_0();
case 19655765: return bem_tagGet_0();
case 1781926555: return bem_copy_0();
case 1740583826: return bem_serializeToString_0();
case 355607643: return bem_makeAbsolute_0();
case 1782125853: return bem_hashGet_0();
case 36736040: return bem_firstStepGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2119054446: return bem_otherType_1(bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case -1236882160: return bem_labelSet_1(bevd_0);
case 803845413: return bem_def_1(bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case -1842584050: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1323859439: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1052050845: return bem_resolve_1(bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 57397863: return bem_separatorSet_1(bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case -1551041169: return bem_addStep_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case -1257269071: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2097315666: return bem_sameClass_1(bevd_0);
case -914119195: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case 975789468: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1564151986: return bem_add_1(bevd_0);
case -1664799114: return bem_addSteps_1(bevd_0);
case 1685576958: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 2052733066: return bem_pathSet_1(bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case -583985694: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1389924806: return bem_addSteps_2(bevd_0, bevd_1);
case -1690918005: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildNamePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
}
