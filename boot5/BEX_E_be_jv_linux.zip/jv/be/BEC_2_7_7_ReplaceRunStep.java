package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_7_7_ReplaceRunStep extends BEC_2_6_6_SystemObject {
public BEC_2_7_7_ReplaceRunStep() { }
private static byte[] becc_BEC_2_7_7_ReplaceRunStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x52,0x75,0x6E,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_7_ReplaceRunStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_7_7_ReplaceRunStep bece_BEC_2_7_7_ReplaceRunStep_bevs_inst;

public static BET_2_7_7_ReplaceRunStep bece_BEC_2_7_7_ReplaceRunStep_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_4_6_TextString bevp_str;
public BEC_2_7_7_ReplaceRunStep bem_new_2(BEC_2_8_7_TemplateReplace beva__replace, BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_replace = beva__replace;
bevp_str = beva__str;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) throws Throwable {
BEC_2_4_6_TextString bevl_toSwap = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_r.bemd_0(-1351944399);
bevl_toSwap = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(715512076, bevp_str);
if (bevl_toSwap == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 162*/ {
return bevl_toSwap;
} /* Line: 163*/
return bevp_str;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {154, 155, 161, 161, 162, 162, 163, 165, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 22, 23, 24, 29, 30, 32, 35, 38, 42, 45};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 154 14
assign 1 155 15
assign 1 161 22
swapGet 0 161 22
assign 1 161 23
get 1 161 23
assign 1 162 24
def 1 162 29
return 1 163 30
return 1 165 32
return 1 0 35
assign 1 0 38
return 1 0 42
assign 1 0 45
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1293883485: return bem_print_0();
case 1230276296: return bem_hashGet_0();
case 227386682: return bem_strGet_0();
case 992700193: return bem_copy_0();
case -10560512: return bem_toString_0();
case -1250586953: return bem_create_0();
case 1978701672: return bem_iteratorGet_0();
case 1836285625: return bem_new_0();
case -1259158287: return bem_replaceGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 850514472: return bem_equals_1(bevd_0);
case -305715842: return bem_notEquals_1(bevd_0);
case -1978152287: return bem_print_1(bevd_0);
case 52329100: return bem_copyTo_1(bevd_0);
case 1340329587: return bem_handle_1(bevd_0);
case 889043921: return bem_strSet_1(bevd_0);
case 1409349899: return bem_undef_1(bevd_0);
case 1533925031: return bem_replaceSet_1(bevd_0);
case -1926574247: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1974138487: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1007047738: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -127109256: return bem_new_2((BEC_2_8_7_TemplateReplace) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 530385415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1507992233: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_7_7_ReplaceRunStep_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_7_ReplaceRunStep_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_7_7_ReplaceRunStep();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_inst = (BEC_2_7_7_ReplaceRunStep) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_type;
}
}
