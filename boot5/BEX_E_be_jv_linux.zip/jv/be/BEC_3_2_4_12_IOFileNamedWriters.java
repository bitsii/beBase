package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_3_2_4_12_IOFileNamedWriters extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedWriters() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x57,0x72,0x69,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_3_2_4_12_IOFileNamedWriters bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;

public static BET_3_2_4_12_IOFileNamedWriters bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_type;

public BEC_3_2_4_6_IOFileWriter bevp_output;
public BEC_3_2_4_6_IOFileWriter bevp_error;
public BEC_3_2_4_6_IOFileWriter bevp_exceptionConsole;
public BEC_3_2_4_12_IOFileNamedWriters bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_default_0() throws Throwable {
BEC_4_2_4_6_6_IOFileWriterStdout bevt_0_ta_ph = null;
BEC_4_2_4_6_6_IOFileWriterStderr bevt_1_ta_ph = null;
BEC_4_2_4_6_8_IOFileWriterNoOutput bevt_2_ta_ph = null;
bevt_0_ta_ph = BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst.bem_new_0();
bem_outputSet_1(bevt_0_ta_ph);
bevt_1_ta_ph = BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst.bem_new_0();
bem_errorSet_1(bevt_1_ta_ph);
bevt_2_ta_ph = (BEC_4_2_4_6_8_IOFileWriterNoOutput) BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst.bem_new_0();
bem_exceptionConsoleSet_1(bevt_2_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_outputSet_1(BEC_3_2_4_6_IOFileWriter beva__output) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevp_output = beva__output;
bevt_0_ta_ph = bevp_output.bem_isClosedGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 650*/ {
bevp_output.bem_open_0();
} /* Line: 651*/
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_errorSet_1(BEC_3_2_4_6_IOFileWriter beva__error) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevp_error = beva__error;
bevt_0_ta_ph = bevp_error.bem_isClosedGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 657*/ {
bevp_error.bem_open_0();
} /* Line: 658*/
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_exceptionConsoleSet_1(BEC_3_2_4_6_IOFileWriter beva__exceptionConsole) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevp_exceptionConsole = beva__exceptionConsole;
bevt_0_ta_ph = bevp_exceptionConsole.bem_isClosedGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 664*/ {
bevp_exceptionConsole.bem_open_0();
} /* Line: 665*/
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_errorGet_0() throws Throwable {
return bevp_error;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_exceptionConsoleGet_0() throws Throwable {
return bevp_exceptionConsole;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {643, 643, 644, 644, 645, 645, 649, 650, 651, 656, 657, 658, 663, 664, 665, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 24, 25, 26, 31, 32, 34, 40, 41, 43, 49, 50, 52, 57, 60, 63};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 643 21
new 0 643 21
outputSet 1 643 22
assign 1 644 23
new 0 644 23
errorSet 1 644 24
assign 1 645 25
new 0 645 25
exceptionConsoleSet 1 645 26
assign 1 649 31
assign 1 650 32
isClosedGet 0 650 32
open 0 651 34
assign 1 656 40
assign 1 657 41
isClosedGet 0 657 41
open 0 658 43
assign 1 663 49
assign 1 664 50
isClosedGet 0 664 50
open 0 665 52
return 1 0 57
return 1 0 60
return 1 0 63
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1689571156: return bem_default_0();
case -1486199957: return bem_outputGet_0();
case 1327010431: return bem_hashGet_0();
case 1318937193: return bem_create_0();
case 1405379722: return bem_errorGet_0();
case 2120153411: return bem_copy_0();
case 730216499: return bem_exceptionConsoleGet_0();
case 1769965429: return bem_toString_0();
case -469226465: return bem_print_0();
case 532380883: return bem_new_0();
case 966722567: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -16136112: return bem_notEquals_1(bevd_0);
case 1194286113: return bem_def_1(bevd_0);
case 820560864: return bem_exceptionConsoleSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -276885715: return bem_errorSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -266175653: return bem_outputSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -533094380: return bem_undef_1(bevd_0);
case 2147027771: return bem_copyTo_1(bevd_0);
case -268811991: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1665151698: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 792362948: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -672637344: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1688602503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedWriters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedWriters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_12_IOFileNamedWriters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst = (BEC_3_2_4_12_IOFileNamedWriters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_type;
}
}
