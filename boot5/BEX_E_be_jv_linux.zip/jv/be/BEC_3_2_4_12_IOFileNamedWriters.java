package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_3_2_4_12_IOFileNamedWriters extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedWriters() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x57,0x72,0x69,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_3_2_4_12_IOFileNamedWriters bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;
public BEC_3_2_4_6_IOFileWriter bevp_output;
public BEC_3_2_4_6_IOFileWriter bevp_error;
public BEC_3_2_4_6_IOFileWriter bevp_exceptionConsole;
public BEC_3_2_4_12_IOFileNamedWriters bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_default_0() throws Throwable {
BEC_4_2_4_6_6_IOFileWriterStdout bevt_0_tmpany_phold = null;
BEC_4_2_4_6_6_IOFileWriterStderr bevt_1_tmpany_phold = null;
BEC_4_2_4_6_8_IOFileWriterNoOutput bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst.bem_new_0();
bem_outputSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst.bem_new_0();
bem_errorSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_4_2_4_6_8_IOFileWriterNoOutput) BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst.bem_new_0();
bem_exceptionConsoleSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_outputSet_1(BEC_3_2_4_6_IOFileWriter beva__output) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_output = beva__output;
bevt_0_tmpany_phold = bevp_output.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 576 */ {
bevp_output.bem_open_0();
} /* Line: 577 */
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_errorSet_1(BEC_3_2_4_6_IOFileWriter beva__error) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_error = beva__error;
bevt_0_tmpany_phold = bevp_error.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 583 */ {
bevp_error.bem_open_0();
} /* Line: 584 */
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_exceptionConsoleSet_1(BEC_3_2_4_6_IOFileWriter beva__exceptionConsole) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_exceptionConsole = beva__exceptionConsole;
bevt_0_tmpany_phold = bevp_exceptionConsole.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 590 */ {
bevp_exceptionConsole.bem_open_0();
} /* Line: 591 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_errorGet_0() throws Throwable {
return bevp_error;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_exceptionConsoleGet_0() throws Throwable {
return bevp_exceptionConsole;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {569, 569, 570, 570, 571, 571, 575, 576, 577, 582, 583, 584, 589, 590, 591, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 21, 22, 23, 28, 29, 31, 37, 38, 40, 46, 47, 49, 54, 57, 60};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 569 18
new 0 569 18
outputSet 1 569 19
assign 1 570 20
new 0 570 20
errorSet 1 570 21
assign 1 571 22
new 0 571 22
exceptionConsoleSet 1 571 23
assign 1 575 28
assign 1 576 29
isClosedGet 0 576 29
open 0 577 31
assign 1 582 37
assign 1 583 38
isClosedGet 0 583 38
open 0 584 40
assign 1 589 46
assign 1 590 47
isClosedGet 0 590 47
open 0 591 49
return 1 0 54
return 1 0 57
return 1 0 60
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 648643859: return bem_sourceFileNameGet_0();
case -266150550: return bem_many_0();
case 1740583826: return bem_serializeToString_0();
case 895906767: return bem_toString_0();
case 978873391: return bem_deserializeClassNameGet_0();
case 1330053746: return bem_classNameGet_0();
case -1666892068: return bem_once_0();
case 1967871042: return bem_outputGet_0();
case -1256903143: return bem_print_0();
case -748130189: return bem_echo_0();
case 1782125853: return bem_hashGet_0();
case 721298840: return bem_serializationIteratorGet_0();
case -105262122: return bem_exceptionConsoleGet_0();
case -67323485: return bem_create_0();
case -907223016: return bem_iteratorGet_0();
case 394710523: return bem_toAny_0();
case 19655765: return bem_tagGet_0();
case -1755437106: return bem_serializeContents_0();
case -1873009448: return bem_errorGet_0();
case 1781926555: return bem_copy_0();
case -805848244: return bem_default_0();
case -2089883321: return bem_new_0();
case -1693411633: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2097315666: return bem_sameClass_1(bevd_0);
case -1342538671: return bem_errorSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2119054446: return bem_otherType_1(bevd_0);
case -817915908: return bem_outputSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1979882190: return bem_exceptionConsoleSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 803845413: return bem_def_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedWriters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedWriters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_12_IOFileNamedWriters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst = (BEC_3_2_4_12_IOFileNamedWriters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;
}
}
