package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_3_2_4_12_IOFileNamedWriters extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedWriters() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x57,0x72,0x69,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_3_2_4_12_IOFileNamedWriters bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;

public static BET_3_2_4_12_IOFileNamedWriters bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_type;

public BEC_3_2_4_6_IOFileWriter bevp_output;
public BEC_3_2_4_6_IOFileWriter bevp_error;
public BEC_3_2_4_6_IOFileWriter bevp_exceptionConsole;
public BEC_3_2_4_12_IOFileNamedWriters bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_default_0() throws Throwable {
BEC_4_2_4_6_6_IOFileWriterStdout bevt_0_tmpany_phold = null;
BEC_4_2_4_6_6_IOFileWriterStderr bevt_1_tmpany_phold = null;
BEC_4_2_4_6_8_IOFileWriterNoOutput bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst.bem_new_0();
bem_outputSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst.bem_new_0();
bem_errorSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_4_2_4_6_8_IOFileWriterNoOutput) BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst.bem_new_0();
bem_exceptionConsoleSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_outputSet_1(BEC_3_2_4_6_IOFileWriter beva__output) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_output = beva__output;
bevt_0_tmpany_phold = bevp_output.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevp_output.bem_open_0();
} /* Line: 632 */
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_errorSet_1(BEC_3_2_4_6_IOFileWriter beva__error) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_error = beva__error;
bevt_0_tmpany_phold = bevp_error.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 638 */ {
bevp_error.bem_open_0();
} /* Line: 639 */
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_exceptionConsoleSet_1(BEC_3_2_4_6_IOFileWriter beva__exceptionConsole) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_exceptionConsole = beva__exceptionConsole;
bevt_0_tmpany_phold = bevp_exceptionConsole.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 645 */ {
bevp_exceptionConsole.bem_open_0();
} /* Line: 646 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_outputGetDirect_0() throws Throwable {
return bevp_output;
} /*method end*/
public final BEC_3_2_4_12_IOFileNamedWriters bem_outputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_output = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_errorGet_0() throws Throwable {
return bevp_error;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_errorGetDirect_0() throws Throwable {
return bevp_error;
} /*method end*/
public final BEC_3_2_4_12_IOFileNamedWriters bem_errorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_error = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_exceptionConsoleGet_0() throws Throwable {
return bevp_exceptionConsole;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_exceptionConsoleGetDirect_0() throws Throwable {
return bevp_exceptionConsole;
} /*method end*/
public final BEC_3_2_4_12_IOFileNamedWriters bem_exceptionConsoleSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exceptionConsole = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {624, 624, 625, 625, 626, 626, 630, 631, 632, 637, 638, 639, 644, 645, 646, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 24, 25, 26, 31, 32, 34, 40, 41, 43, 49, 50, 52, 57, 60, 63, 67, 70, 73, 77, 80, 83};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 624 21
new 0 624 21
outputSet 1 624 22
assign 1 625 23
new 0 625 23
errorSet 1 625 24
assign 1 626 25
new 0 626 25
exceptionConsoleSet 1 626 26
assign 1 630 31
assign 1 631 32
isClosedGet 0 631 32
open 0 632 34
assign 1 637 40
assign 1 638 41
isClosedGet 0 638 41
open 0 639 43
assign 1 644 49
assign 1 645 50
isClosedGet 0 645 50
open 0 646 52
return 1 0 57
return 1 0 60
assign 1 0 63
return 1 0 67
return 1 0 70
assign 1 0 73
return 1 0 77
return 1 0 80
assign 1 0 83
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1400770094: return bem_many_0();
case -518710385: return bem_fieldNamesGet_0();
case -512236724: return bem_deserializeClassNameGet_0();
case -2091241279: return bem_create_0();
case 1349866592: return bem_toString_0();
case 1957608515: return bem_fieldIteratorGet_0();
case -1423578661: return bem_print_0();
case -923057320: return bem_serializationIteratorGet_0();
case 993759307: return bem_iteratorGet_0();
case -35248652: return bem_toAny_0();
case 1462917165: return bem_default_0();
case 1299948053: return bem_serializeContents_0();
case 518862870: return bem_tagGet_0();
case -914347833: return bem_new_0();
case 646589914: return bem_sourceFileNameGet_0();
case -2035208893: return bem_echo_0();
case 1148491745: return bem_exceptionConsoleGet_0();
case 1052263558: return bem_serializeToString_0();
case -1817548966: return bem_exceptionConsoleGetDirect_0();
case 675566088: return bem_classNameGet_0();
case 13807179: return bem_hashGet_0();
case 182872303: return bem_errorGet_0();
case -458140592: return bem_outputGetDirect_0();
case -389026737: return bem_outputGet_0();
case 758802515: return bem_once_0();
case -245363326: return bem_copy_0();
case -341931742: return bem_errorGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -537932837: return bem_equals_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1173338416: return bem_outputSetDirect_1(bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -118391667: return bem_exceptionConsoleSetDirect_1(bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case -586956892: return bem_outputSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case 13780858: return bem_errorSetDirect_1(bevd_0);
case 20321995: return bem_exceptionConsoleSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case 313116204: return bem_errorSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedWriters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedWriters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_12_IOFileNamedWriters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst = (BEC_3_2_4_12_IOFileNamedWriters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_type;
}
}
