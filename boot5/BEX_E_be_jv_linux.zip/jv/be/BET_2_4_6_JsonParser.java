package be;
public class BET_2_4_6_JsonParser extends BETS_Object {
public BET_2_4_6_JsonParser() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "parse_2", "jsonUcIsPairStart_1", "jsonUcIsPairEnd_1", "jsonUcGetAfterPart_1", "jsonUcUnescape_1", "jsonUcAppendValue_3", "parseTokens_2", "quoteGet_0", "quoteSet_1", "lbraceGet_0", "lbraceSet_1", "rbraceGet_0", "rbraceSet_1", "lbracketGet_0", "lbracketSet_1", "rbracketGet_0", "rbracketSet_1", "spaceGet_0", "spaceSet_1", "colonGet_0", "colonSet_1", "escapeGet_0", "escapeSet_1", "crGet_0", "crSet_1", "lfGet_0", "lfSet_1", "commaGet_0", "commaSet_1", "tokensGet_0", "tokensSet_1", "tokerGet_0", "tokerSet_1", "hsubGet_0", "hsubSet_1", "vsubGet_0", "vsubSet_1", "hmAddGet_0", "hmAddSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "quote", "lbrace", "rbrace", "lbracket", "rbracket", "space", "colon", "escape", "cr", "lf", "comma", "tokens", "toker", "hsub", "vsub", "hmAdd" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_6_JsonParser();
}
}
