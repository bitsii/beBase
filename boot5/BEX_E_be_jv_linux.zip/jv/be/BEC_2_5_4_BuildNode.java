package be;
/* IO:File: source/build/Nodes.be */
public final class BEC_2_5_4_BuildNode extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
private static byte[] becc_BEC_2_5_4_BuildNode_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_2_5_4_BuildNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_0 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_1 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_5 = {0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_6 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_7 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_8, 7));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_9, 8));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_10 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_10, 1));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_11 = {0x20,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_11, 2));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_13 = {0x5F,0x74,0x6D,0x70,0x61,0x6E,0x79,0x5F};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_17, 18));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_5;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_6;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_7;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_8;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_9;
private static BEC_2_4_3_MathInt bece_BEC_2_5_4_BuildNode_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_inst;

public static BET_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_type;

public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_3_9_10_9_ContainerLinkedListAwareNode bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_2_4_3_MathInt(0));
bevp_nlec = (new BEC_2_4_3_MathInt(0));
bevp_wideString = be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = bevt_0_tmpany_phold.bem_copy_0();
bevt_1_tmpany_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = bevt_1_tmpany_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (bevp_contained == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_4_tmpany_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 45 */ {
bevt_5_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_tmpany_phold;
} /* Line: 46 */
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
 /* Line: 50 */ {
if (bevl_ret == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 50 */ {
if (bevl_con == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 52 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
 /* Line: 60 */ {
if (bevl_ret == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 60 */ {
if (bevl_con == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 60 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 62 */
 else  /* Line: 60 */ {
break;
} /* Line: 60 */
} /* Line: 60 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 68 */ {
return null;
} /* Line: 69 */
bevl_hh = bevp_heldBy.bem_nextGet_0();
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 72 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 73 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(2032771297);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 79 */ {
return null;
} /* Line: 80 */
bevl_hh = bevp_heldBy.bem_priorGet_0();
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 83 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 84 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(2032771297);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 102 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 103 */
bevt_3_tmpany_phold = bevp_heldBy.bem_priorGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 109 */ {
bevt_3_tmpany_phold = bevp_heldBy.bem_priorGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 109 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 109 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 109 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 110 */
bevt_7_tmpany_phold = bevp_heldBy.bem_priorGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_priorGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_11_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_12_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_4_tmpany_phold = bevp_heldBy.bem_priorGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_7_tmpany_phold = bevp_heldBy.bem_priorGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_priorGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 116 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 117 */
bevt_12_tmpany_phold = bevp_heldBy.bem_priorGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_priorGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_priorGet_0();
if (bevt_10_tmpany_phold == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 127 */ {
return null;
} /* Line: 128 */
bevp_heldBy.bem_delete_0();
bem_containerSet_1(null);
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_3_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 136 */ {
return null;
} /* Line: 137 */
bevt_2_tmpany_phold = bevp_heldBy.bem_mylistGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_newNode_1(beva_x);
bevp_heldBy.bem_insertBefore_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bem_containerGet_0();
beva_x.bem_containerSet_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 144 */ {
bem_initContained_0();
} /* Line: 145 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 152 */ {
bem_initContained_0();
} /* Line: 153 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 164 */ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 165 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try  /* Line: 171 */ {
bevl_res = bem_toStringCompact_0();
} /* Line: 172 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(-1423578661);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 175 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
bevl_prefix = bem_prefixGet_0();
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_2_tmpany_phold = bevl_prefix.bemd_1(495742460, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_typename.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(495742460, bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = bevt_1_tmpany_phold.bemd_1(495742460, bevt_5_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_newlineGet_0();
bevt_8_tmpany_phold = bevl_ret.bemd_1(495742460, bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(495742460, bevl_prefix);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_2));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(495742460, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bemd_1(495742460, bevt_12_tmpany_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 184 */ {
if (bevp_inFile == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 184 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 184 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 184 */
 else  /* Line: 184 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 184 */ {
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_newlineGet_0();
bevt_20_tmpany_phold = bevl_ret.bemd_1(495742460, bevt_21_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(495742460, bevl_prefix);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_3));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(495742460, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(495742460, bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_4));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_1(495742460, bevt_25_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(495742460, bevp_inFile);
bevt_27_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpany_phold.bemd_1(495742460, bevt_26_tmpany_phold);
} /* Line: 185 */
if (bevp_held == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_32_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_newlineGet_0();
bevt_30_tmpany_phold = bevl_ret.bemd_1(495742460, bevt_31_tmpany_phold);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_1(495742460, bevl_prefix);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevl_ret = bevt_29_tmpany_phold.bemd_1(495742460, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_held.bemd_0(1349866592);
bevl_ret = bevl_ret.bemd_1(495742460, bevt_34_tmpany_phold);
} /* Line: 189 */
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
bevl_prefix = bem_prefixGet_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_6));
bevt_1_tmpany_phold = bevl_prefix.bemd_1(495742460, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_typename.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(495742460, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_7));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(495742460, bevt_4_tmpany_phold);
if (bevp_nlc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_0;
bevt_6_tmpany_phold = bevl_ret.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 198 */
if (bevp_inClassNp == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_1;
bevt_10_tmpany_phold = bevl_ret.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
} /* Line: 201 */
if (bevp_held == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_2;
bevt_14_tmpany_phold = bevl_ret.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_held.bemd_0(1349866592);
bevl_ret = bevt_14_tmpany_phold.bem_add_1(bevt_16_tmpany_phold);
} /* Line: 204 */
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = (new BEC_2_4_3_MathInt(0));
bevl_c = bem_containerGet_0();
while (true)
 /* Line: 212 */ {
if (bevl_c == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 214 */
 else  /* Line: 212 */ {
break;
} /* Line: 212 */
} /* Line: 212 */
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = bem_depthGet_0();
bevl_p = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = bece_BEC_2_5_4_BuildNode_bevo_3;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 223 */ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 223 */
 else  /* Line: 223 */ {
break;
} /* Line: 223 */
} /* Line: 223 */
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 231 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(897666401);
bevt_4_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-2005653387, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 231 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 231 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 231 */
 else  /* Line: 231 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 231 */ {
bevl_targ = bevl_targ.bemd_0(961903680);
} /* Line: 232 */
 else  /* Line: 231 */ {
break;
} /* Line: 231 */
} /* Line: 231 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_clnode = bem_scopeGet_0();
bevt_1_tmpany_phold = bevl_clnode.bemd_0(897666401);
bevt_2_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-2005653387, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 239 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildNode_bels_12));
bevt_3_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 240 */
bevt_6_tmpany_phold = bevl_clnode.bemd_0(2032771297);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(1969684306);
bevl_tmpanyn = bevt_5_tmpany_phold.bemd_0(1349866592);
bevt_8_tmpany_phold = bevl_clnode.bemd_0(2032771297);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1969684306);
bevt_7_tmpany_phold.bemd_0(1225134390);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(-1510628175, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(2087682439, bevt_10_tmpany_phold);
bevl_tmpany.bemd_1(250595574, beva_suffix);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_13));
bevt_12_tmpany_phold = bevl_tmpanyn.bemd_1(495742460, bevt_13_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(495742460, beva_suffix);
bevl_tmpany.bemd_1(-577672246, bevt_11_tmpany_phold);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_con = bem_containerGet_0();
while (true)
 /* Line: 254 */ {
if (bevl_con == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevt_2_tmpany_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 256 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 258 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevl_v = bevp_held;
bevt_2_tmpany_phold = bevl_v.bemd_0(-877072648);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1188119310);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 265 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1450899448, bevt_3_tmpany_phold);
bevl_sco = bem_scopeGet_0();
bevt_5_tmpany_phold = bevl_sco.bemd_0(897666401);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(-537932837, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 268 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_4_BuildNode_bels_14));
bevt_7_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 269 */
bevt_9_tmpany_phold = bem_inPropertiesGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevt_11_tmpany_phold = bevl_v.bemd_0(1267071383);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1188119310);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 271 */ {
bevl_sco = bem_classGet_0();
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(377649219, bevt_12_tmpany_phold);
} /* Line: 273 */
bevl_sc = bevl_sco.bemd_0(2032771297);
bevt_14_tmpany_phold = bevl_sc.bemd_0(1819197586);
bevt_15_tmpany_phold = bevl_v.bemd_0(-223555590);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_1(1645909378, bevt_15_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 276 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_4_BuildNode_bels_15));
bevt_16_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 277 */
bevt_18_tmpany_phold = bevl_sc.bemd_0(1819197586);
bevt_19_tmpany_phold = bevl_v.bemd_0(-223555590);
bevt_18_tmpany_phold.bemd_2(-2078297324, bevt_19_tmpany_phold, this);
bevt_20_tmpany_phold = bevl_sc.bemd_0(-576632275);
bevt_20_tmpany_phold.bemd_1(-992295107, this);
} /* Line: 280 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevl_v = bevp_held;
bevt_1_tmpany_phold = bevl_v.bemd_0(-877072648);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1188119310);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 286 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1450899448, bevt_2_tmpany_phold);
bevl_sco = bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(2032771297);
bevt_4_tmpany_phold = bevl_sc.bemd_0(1819197586);
bevt_5_tmpany_phold = bevl_v.bemd_0(-223555590);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1645909378, bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 290 */ {
bevt_6_tmpany_phold = bevl_sc.bemd_0(1819197586);
bevt_7_tmpany_phold = bevl_v.bemd_0(-223555590);
bevp_held = bevt_6_tmpany_phold.bemd_1(590912902, bevt_7_tmpany_phold);
} /* Line: 291 */
 else  /* Line: 292 */ {
bevt_8_tmpany_phold = bem_classGet_0();
bevl_cl = bevt_8_tmpany_phold.bemd_0(2032771297);
bevt_10_tmpany_phold = bevl_cl.bemd_0(1819197586);
bevt_11_tmpany_phold = bevl_v.bemd_0(-223555590);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(1645909378, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 294 */ {
bevt_12_tmpany_phold = bevl_cl.bemd_0(1819197586);
bevt_13_tmpany_phold = bevl_v.bemd_0(-223555590);
bevp_held = bevt_12_tmpany_phold.bemd_1(590912902, bevt_13_tmpany_phold);
} /* Line: 295 */
 else  /* Line: 296 */ {
bevt_14_tmpany_phold = bevl_sc.bemd_0(1819197586);
bevt_15_tmpany_phold = bevl_v.bemd_0(-223555590);
bevt_14_tmpany_phold.bemd_2(-2078297324, bevt_15_tmpany_phold, this);
bevt_16_tmpany_phold = bevl_sc.bemd_0(-576632275);
bevt_16_tmpany_phold.bemd_1(-992295107, this);
bevt_18_tmpany_phold = bevl_sco.bemd_0(897666401);
bevt_19_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(-537932837, bevt_19_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 299 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_4_BuildNode_bels_16));
bevt_20_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 300 */
} /* Line: 299 */
} /* Line: 294 */
} /* Line: 290 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_13_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpany_phold = bem_scopeGet_0();
bevl_sc = bevt_0_tmpany_phold.bemd_0(2032771297);
bevt_2_tmpany_phold = bevl_sc.bemd_0(1819197586);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(1645909378, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 311 */ {
bevt_4_tmpany_phold = bevl_sc.bemd_0(1819197586);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(590912902, bevl_vname);
bevp_held = bevt_3_tmpany_phold.bemd_0(2032771297);
} /* Line: 312 */
 else  /* Line: 313 */ {
bevt_5_tmpany_phold = bem_classGet_0();
bevl_cl = bevt_5_tmpany_phold.bemd_0(2032771297);
bevt_7_tmpany_phold = bevl_cl.bemd_0(1819197586);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(1645909378, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 315 */ {
bevt_9_tmpany_phold = bevl_cl.bemd_0(1819197586);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_1(590912902, bevl_vname);
bevp_held = bevt_8_tmpany_phold.bemd_0(2032771297);
} /* Line: 316 */
 else  /* Line: 317 */ {
bevl_tunode = bem_transUnitGet_0();
bevt_11_tmpany_phold = bevl_tunode.bemd_0(2032771297);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1866003922);
bevl_np = bevt_10_tmpany_phold.bemd_1(590912902, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_14_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_aliasedGet_0();
bevl_np = bevt_13_tmpany_phold.bem_get_1(bevl_vname);
} /* Line: 321 */
if (bevl_np == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_18_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_4;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevl_np);
bevt_16_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 324 */
 else  /* Line: 325 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(-577672246, bevl_vname);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_18));
bevt_19_tmpany_phold = bevl_vname.bemd_1(-537932837, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_19_tmpany_phold).bevi_bool) /* Line: 329 */ {
bevp_held = bevl_v;
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(415038240, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevl_cl.bemd_0(1914782123);
bevl_v.bemd_1(-2006748524, bevt_22_tmpany_phold);
bevt_23_tmpany_phold = bevl_sc.bemd_0(1819197586);
bevt_23_tmpany_phold.bemd_2(-2078297324, bevl_vname, this);
bevt_24_tmpany_phold = bevl_sc.bemd_0(-576632275);
bevt_24_tmpany_phold.bemd_1(-992295107, this);
} /* Line: 334 */
 else  /* Line: 335 */ {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(355550262, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(377649219, bevt_26_tmpany_phold);
bevp_held = bevl_v;
bevt_27_tmpany_phold = bevl_cl.bemd_0(1819197586);
bevt_27_tmpany_phold.bemd_2(-2078297324, bevl_vname, this);
bevt_28_tmpany_phold = bevl_cl.bemd_0(-576632275);
bevt_28_tmpany_phold.bemd_1(-992295107, this);
} /* Line: 340 */
} /* Line: 329 */
} /* Line: 323 */
} /* Line: 315 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_node = this;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 349 */ {
while (true)
 /* Line: 350 */ {
bevt_2_tmpany_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpany_phold = bevl_node.bemd_0(897666401);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_has_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 351 */ {
return bevl_node;
} /* Line: 352 */
 else  /* Line: 353 */ {
bevl_node = bevl_node.bemd_0(961903680);
if (bevl_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_19));
bevt_5_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 356 */
} /* Line: 355 */
} /* Line: 351 */
} /* Line: 350 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 365 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 365 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(897666401);
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-2005653387, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 365 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 365 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 365 */
 else  /* Line: 365 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 365 */ {
bevl_targ = bevl_targ.bemd_0(961903680);
} /* Line: 366 */
 else  /* Line: 365 */ {
break;
} /* Line: 365 */
} /* Line: 365 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 373 */ {
if (bevl_targ == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevt_5_tmpany_phold = bevl_targ.bemd_0(897666401);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(-2005653387, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 373 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 373 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 373 */
 else  /* Line: 373 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 373 */ {
bevt_8_tmpany_phold = bevl_targ.bemd_0(897666401);
bevt_9_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(-2005653387, bevt_9_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 373 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 373 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 373 */
 else  /* Line: 373 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 373 */ {
bevt_11_tmpany_phold = bevl_targ.bemd_0(897666401);
bevt_12_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(-2005653387, bevt_12_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 373 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 373 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 373 */
 else  /* Line: 373 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 373 */ {
bevl_targ = bevl_targ.bemd_0(961903680);
} /* Line: 374 */
 else  /* Line: 373 */ {
break;
} /* Line: 373 */
} /* Line: 373 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_1_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 380 */ {
return null;
} /* Line: 381 */
bevt_1_tmpany_phold = bem_containerGet_0();
beva_other.bem_containerSet_1(bevt_1_tmpany_phold);
bevp_heldBy.bem_heldSet_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 394 */ {
bevt_0_tmpany_phold = bevl_it.bemd_0(-568133260);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 394 */ {
bevl_i = bevl_it.bemd_0(-1008451889);
bevl_i.bemd_1(1765490842, this);
} /* Line: 396 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 402 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 405 */
} /* Line: 404 */
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 408 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(657081007);
if (bevl_np == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 411 */
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(1914782123);
if (bevl_np == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 414 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 415 */
bevt_8_tmpany_phold = bevp_held.bemd_0(657081007);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1349866592);
bevp_held.bemd_1(-577672246, bevt_7_tmpany_phold);
} /* Line: 417 */
bevt_10_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(657081007);
if (bevl_np == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 422 */
} /* Line: 421 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_callIsSafe_1(BEC_2_5_4_BuildNode beva_call) throws Throwable {
BEC_2_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses = null;
BEC_2_9_3_ContainerSet bevl_okCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses2 = null;
BEC_2_9_3_ContainerSet bevl_okCalls2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
bevt_2_tmpany_phold = beva_call.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1871450477);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 432 */ {
bevt_6_tmpany_phold = beva_call.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1385410759);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1349866592);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_20));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-537932837, bevt_7_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 432 */
 else  /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 432 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 433 */
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_5 == null) {
bece_BEC_2_5_4_BuildNode_bevo_5 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bece_BEC_2_5_4_BuildNode_bevo_5;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_6 == null) {
bece_BEC_2_5_4_BuildNode_bevo_6 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bece_BEC_2_5_4_BuildNode_bevo_6;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_7 == null) {
bece_BEC_2_5_4_BuildNode_bevo_7 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bece_BEC_2_5_4_BuildNode_bevo_7;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_8 == null) {
bece_BEC_2_5_4_BuildNode_bevo_8 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bece_BEC_2_5_4_BuildNode_bevo_8;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_9 == null) {
bece_BEC_2_5_4_BuildNode_bevo_9 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bece_BEC_2_5_4_BuildNode_bevo_9;
bevt_10_tmpany_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_10;
if (bevt_10_tmpany_phold.bevi_int == bevt_11_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 441 */ {
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_4_BuildNode_bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpany_phold);
} /* Line: 491 */
bevt_48_tmpany_phold = beva_call.bem_heldGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(-223555590);
bevt_46_tmpany_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpany_phold);
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 495 */ {
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_49_tmpany_phold;
} /* Line: 497 */
bevt_54_tmpany_phold = beva_call.bem_containedGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_firstGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(2032771297);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(1044811213);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_0(1188119310);
if (((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 501 */ {
bevt_55_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_55_tmpany_phold;
} /* Line: 503 */
bevt_61_tmpany_phold = beva_call.bem_containedGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(2032771297);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(657081007);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(1349866592);
bevt_56_tmpany_phold = bevl_okClasses.bem_has_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_64_tmpany_phold = beva_call.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-223555590);
bevt_62_tmpany_phold = bevl_okCalls.bem_has_1(bevt_63_tmpany_phold);
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 512 */ {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_65_tmpany_phold;
} /* Line: 514 */
 else  /* Line: 515 */ {
} /* Line: 515 */
} /* Line: 512 */
bevt_71_tmpany_phold = beva_call.bem_containedGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_firstGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_0(2032771297);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(657081007);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(1349866592);
bevt_66_tmpany_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 519 */ {
bevt_74_tmpany_phold = beva_call.bem_heldGet_0();
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(-223555590);
bevt_72_tmpany_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpany_phold);
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 520 */ {
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_75_tmpany_phold;
} /* Line: 522 */
 else  /* Line: 523 */ {
} /* Line: 523 */
} /* Line: 520 */
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_76_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralOnceGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_BuildNode bevl_c0 = null;
BEC_2_5_4_BuildNode bevl_c1 = null;
BEC_2_5_4_BuildNode bevl_call = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevt_4_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevp_typename.bevi_int != bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 544 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 544 */
bevt_7_tmpany_phold = bevp_held.bemd_0(1174656102);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_55));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(-537932837, bevt_8_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 545 */ {
bevl_c0 = (BEC_2_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_2_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 548 */ {
bevt_11_tmpany_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_11_tmpany_phold.bevi_int == bevt_12_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 548 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 548 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 548 */
 else  /* Line: 548 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 548 */ {
bevt_14_tmpany_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(510397758);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 549 */ {
bevt_17_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(238998395);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1188119310);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 549 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 549 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 549 */
 else  /* Line: 549 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 549 */ {
bevl_result = be.BECS_Runtime.boolTrue;
bevt_19_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-661710028);
bevt_0_tmpany_loop = bevt_18_tmpany_phold.bemd_0(993759307);
while (true)
 /* Line: 551 */ {
bevt_20_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-568133260);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 551 */ {
bevl_call = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(-1008451889);
bevt_21_tmpany_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 552 */ {
bevt_23_tmpany_phold = bem_callIsSafe_1(bevl_call);
if (bevt_23_tmpany_phold.bevi_bool) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 553 */ {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_24_tmpany_phold;
} /* Line: 554 */
} /* Line: 553 */
} /* Line: 552 */
 else  /* Line: 551 */ {
break;
} /* Line: 551 */
} /* Line: 551 */
} /* Line: 551 */
} /* Line: 549 */
} /* Line: 548 */
return bevl_result;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public final BEC_2_9_8_ContainerNodeList bem_containedGetDirect_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_heldGetDirect_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public final BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGetDirect_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_heldBySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() throws Throwable {
return bevp_condany;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_condanyGetDirect_0() throws Throwable {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_condany = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_condanySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_condany = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public final BEC_2_4_6_TextString bem_inFileGetDirect_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_typeDetailGetDirect_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeDetail = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_typeDetailSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeDetail = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_delayDeleteGetDirect_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_delayDeleteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nlcGetDirect_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_nlcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nlecGetDirect_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_nlecSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wideStringGetDirect_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_wideStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildGetDirect_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public final BEC_2_4_3_MathInt bem_typenameGetDirect_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_typenameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_inlinedGetDirect_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inlinedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 25, 26, 27, 29, 30, 31, 32, 33, 38, 38, 39, 39, 40, 41, 45, 45, 45, 45, 45, 0, 0, 0, 46, 46, 48, 49, 50, 50, 50, 50, 0, 0, 0, 51, 52, 54, 58, 59, 60, 60, 60, 60, 0, 0, 0, 61, 62, 64, 68, 68, 69, 71, 72, 72, 73, 75, 75, 79, 79, 80, 82, 83, 83, 84, 86, 86, 90, 90, 94, 94, 98, 98, 102, 102, 103, 103, 105, 105, 105, 109, 109, 0, 109, 109, 109, 0, 0, 110, 110, 112, 112, 112, 112, 116, 116, 0, 116, 116, 116, 0, 0, 0, 116, 116, 116, 116, 0, 0, 117, 117, 119, 119, 119, 119, 119, 123, 127, 127, 128, 130, 131, 132, 136, 136, 137, 139, 139, 139, 140, 140, 144, 144, 145, 147, 148, 152, 152, 153, 155, 156, 160, 164, 164, 165, 172, 174, 175, 177, 181, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 183, 183, 183, 184, 184, 184, 184, 0, 0, 0, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 187, 187, 188, 188, 188, 188, 188, 188, 189, 189, 191, 195, 196, 196, 196, 196, 196, 196, 197, 197, 198, 198, 198, 198, 200, 200, 201, 201, 201, 201, 203, 203, 204, 204, 204, 204, 206, 210, 211, 212, 212, 213, 214, 216, 220, 221, 222, 223, 223, 223, 224, 223, 226, 230, 231, 231, 231, 231, 231, 0, 0, 0, 232, 234, 238, 239, 239, 239, 240, 240, 240, 242, 242, 242, 243, 243, 243, 244, 245, 245, 246, 246, 247, 248, 248, 248, 248, 249, 253, 254, 254, 255, 255, 255, 255, 256, 256, 258, 260, 260, 264, 265, 265, 266, 266, 267, 268, 268, 268, 269, 269, 269, 271, 271, 271, 0, 0, 0, 272, 273, 273, 275, 276, 276, 276, 277, 277, 277, 279, 279, 279, 280, 280, 285, 286, 286, 287, 287, 288, 289, 290, 290, 290, 291, 291, 291, 293, 293, 294, 294, 294, 295, 295, 295, 297, 297, 297, 298, 298, 299, 299, 299, 300, 300, 300, 309, 310, 310, 311, 311, 312, 312, 312, 314, 314, 315, 315, 316, 316, 316, 318, 319, 319, 319, 320, 320, 321, 321, 321, 323, 323, 324, 324, 324, 324, 327, 328, 329, 329, 330, 331, 331, 332, 332, 333, 333, 334, 334, 336, 336, 337, 337, 338, 339, 339, 340, 340, 348, 349, 351, 351, 351, 352, 354, 355, 355, 356, 356, 356, 364, 365, 365, 365, 365, 365, 0, 0, 0, 366, 368, 372, 373, 373, 373, 373, 373, 0, 0, 0, 373, 373, 373, 0, 0, 0, 373, 373, 373, 0, 0, 0, 374, 376, 380, 380, 381, 383, 383, 384, 388, 389, 393, 394, 394, 395, 396, 402, 402, 402, 403, 404, 404, 405, 408, 408, 408, 409, 410, 410, 411, 413, 414, 414, 415, 417, 417, 417, 419, 419, 419, 420, 421, 421, 422, 432, 432, 432, 432, 432, 432, 432, 0, 0, 0, 433, 433, 436, 437, 438, 439, 440, 441, 441, 441, 441, 448, 448, 451, 451, 452, 452, 454, 454, 455, 455, 456, 456, 457, 457, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 473, 473, 474, 474, 475, 475, 476, 476, 477, 477, 478, 478, 482, 482, 483, 483, 484, 484, 485, 485, 490, 490, 491, 491, 495, 495, 495, 497, 497, 501, 501, 501, 501, 501, 503, 503, 511, 511, 511, 511, 511, 511, 512, 512, 512, 514, 514, 519, 519, 519, 519, 519, 519, 520, 520, 520, 522, 522, 528, 528, 539, 544, 544, 544, 544, 544, 545, 545, 545, 546, 547, 548, 548, 548, 548, 548, 548, 0, 0, 0, 549, 549, 549, 549, 549, 0, 0, 0, 550, 551, 551, 551, 0, 551, 551, 552, 553, 553, 553, 554, 554, 565, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {96, 97, 98, 99, 100, 101, 102, 103, 104, 110, 111, 112, 113, 114, 115, 129, 134, 135, 136, 141, 142, 145, 149, 152, 153, 155, 156, 159, 164, 165, 170, 171, 174, 178, 181, 182, 188, 196, 197, 200, 205, 206, 211, 212, 215, 219, 222, 223, 229, 236, 241, 242, 244, 245, 250, 251, 253, 254, 261, 266, 267, 269, 270, 275, 276, 278, 279, 283, 284, 288, 289, 293, 294, 301, 306, 307, 308, 310, 311, 316, 327, 332, 333, 336, 337, 342, 343, 346, 350, 351, 353, 354, 355, 360, 376, 381, 382, 385, 386, 391, 392, 395, 399, 402, 403, 404, 409, 410, 413, 417, 418, 420, 421, 422, 423, 428, 431, 436, 441, 442, 444, 445, 446, 454, 459, 460, 462, 463, 464, 465, 466, 471, 476, 477, 479, 480, 485, 490, 491, 493, 494, 498, 503, 508, 509, 517, 521, 522, 524, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 584, 585, 590, 591, 594, 598, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 616, 621, 622, 623, 624, 625, 626, 627, 628, 629, 631, 653, 654, 655, 656, 657, 658, 659, 660, 665, 666, 667, 668, 669, 671, 676, 677, 678, 679, 680, 682, 687, 688, 689, 690, 691, 693, 699, 700, 703, 708, 709, 710, 716, 724, 725, 726, 727, 730, 735, 736, 737, 743, 752, 755, 760, 761, 762, 763, 765, 768, 772, 775, 781, 801, 802, 803, 804, 806, 807, 808, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 836, 839, 844, 845, 846, 847, 852, 853, 854, 856, 862, 863, 890, 891, 892, 894, 895, 896, 897, 898, 899, 901, 902, 903, 905, 907, 908, 910, 913, 917, 920, 921, 922, 924, 925, 926, 927, 929, 930, 931, 933, 934, 935, 936, 937, 968, 969, 970, 972, 973, 974, 975, 976, 977, 978, 980, 981, 982, 985, 986, 987, 988, 989, 991, 992, 993, 996, 997, 998, 999, 1000, 1001, 1002, 1003, 1005, 1006, 1007, 1050, 1051, 1052, 1053, 1054, 1056, 1057, 1058, 1061, 1062, 1063, 1064, 1066, 1067, 1068, 1071, 1072, 1073, 1074, 1075, 1080, 1081, 1082, 1083, 1085, 1090, 1091, 1092, 1093, 1094, 1097, 1098, 1099, 1100, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1113, 1114, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1137, 1138, 1142, 1143, 1144, 1146, 1149, 1150, 1155, 1156, 1157, 1158, 1172, 1175, 1180, 1181, 1182, 1183, 1185, 1188, 1192, 1195, 1201, 1218, 1221, 1226, 1227, 1228, 1229, 1231, 1234, 1238, 1241, 1242, 1243, 1245, 1248, 1252, 1255, 1256, 1257, 1259, 1262, 1266, 1269, 1275, 1280, 1285, 1286, 1288, 1289, 1290, 1294, 1295, 1302, 1303, 1306, 1308, 1309, 1331, 1332, 1337, 1338, 1339, 1344, 1345, 1348, 1349, 1354, 1355, 1356, 1361, 1362, 1364, 1365, 1370, 1371, 1373, 1374, 1375, 1377, 1378, 1383, 1384, 1385, 1390, 1391, 1479, 1480, 1482, 1483, 1484, 1485, 1486, 1488, 1491, 1495, 1498, 1499, 1501, 1507, 1513, 1519, 1525, 1531, 1532, 1533, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1608, 1609, 1610, 1612, 1613, 1615, 1616, 1617, 1618, 1619, 1621, 1622, 1624, 1625, 1626, 1627, 1628, 1629, 1631, 1632, 1633, 1635, 1636, 1641, 1642, 1643, 1644, 1645, 1646, 1648, 1649, 1650, 1652, 1653, 1658, 1659, 1691, 1692, 1693, 1698, 1699, 1700, 1702, 1703, 1704, 1706, 1707, 1708, 1713, 1714, 1715, 1716, 1721, 1722, 1725, 1729, 1732, 1733, 1735, 1736, 1737, 1739, 1742, 1746, 1749, 1750, 1751, 1752, 1752, 1755, 1757, 1758, 1760, 1761, 1766, 1767, 1768, 1779, 1782, 1785, 1788, 1792, 1796, 1799, 1802, 1806, 1810, 1813, 1816, 1820, 1824, 1827, 1830, 1834, 1838, 1841, 1844, 1848, 1852, 1855, 1858, 1862, 1866, 1869, 1872, 1876, 1880, 1883, 1886, 1890, 1894, 1897, 1900, 1904, 1908, 1911, 1914, 1918, 1922, 1925, 1928, 1932, 1936, 1939, 1942, 1946, 1950, 1953, 1956, 1960, 1964, 1967, 1970, 1974, 1978, 1981, 1984, 1988, 1992, 1995, 1998, 2002, 2006, 2009, 2012, 2016};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 96
new 0 24 96
assign 1 25 97
new 0 25 97
assign 1 26 98
new 0 26 98
assign 1 27 99
new 0 27 99
assign 1 29 100
assign 1 30 101
constantsGet 0 30 101
assign 1 31 102
ntypesGet 0 31 102
assign 1 32 103
TOKENGet 0 32 103
assign 1 33 104
new 0 33 104
assign 1 38 110
nlcGet 0 38 110
assign 1 38 111
copy 0 38 111
assign 1 39 112
nlecGet 0 39 112
assign 1 39 113
copy 0 39 113
assign 1 40 114
inClassNpGet 0 40 114
assign 1 41 115
inFileGet 0 41 115
assign 1 45 129
def 1 45 134
assign 1 45 135
firstGet 0 45 135
assign 1 45 136
def 1 45 141
assign 1 0 142
assign 1 0 145
assign 1 0 149
assign 1 46 152
firstGet 0 46 152
return 1 46 153
assign 1 48 155
nextPeerGet 0 48 155
assign 1 49 156
containerGet 0 49 156
assign 1 50 159
undef 1 50 164
assign 1 50 165
def 1 50 170
assign 1 0 171
assign 1 0 174
assign 1 0 178
assign 1 51 181
nextPeerGet 0 51 181
assign 1 52 182
containerGet 0 52 182
return 1 54 188
assign 1 58 196
nextPeerGet 0 58 196
assign 1 59 197
containerGet 0 59 197
assign 1 60 200
undef 1 60 205
assign 1 60 206
def 1 60 211
assign 1 0 212
assign 1 0 215
assign 1 0 219
assign 1 61 222
nextPeerGet 0 61 222
assign 1 62 223
containerGet 0 62 223
return 1 64 229
assign 1 68 236
undef 1 68 241
return 1 69 242
assign 1 71 244
nextGet 0 71 244
assign 1 72 245
undef 1 72 250
return 1 73 251
assign 1 75 253
heldGet 0 75 253
return 1 75 254
assign 1 79 261
undef 1 79 266
return 1 80 267
assign 1 82 269
priorGet 0 82 269
assign 1 83 270
undef 1 83 275
return 1 84 276
assign 1 86 278
heldGet 0 86 278
return 1 86 279
assign 1 90 283
firstGet 0 90 283
return 1 90 284
assign 1 94 288
secondGet 0 94 288
return 1 94 289
assign 1 98 293
thirdGet 0 98 293
return 1 98 294
assign 1 102 301
undef 1 102 306
assign 1 103 307
new 0 103 307
return 1 103 308
assign 1 105 310
priorGet 0 105 310
assign 1 105 311
undef 1 105 316
return 1 105 316
assign 1 109 327
undef 1 109 332
assign 1 0 333
assign 1 109 336
priorGet 0 109 336
assign 1 109 337
undef 1 109 342
assign 1 0 343
assign 1 0 346
assign 1 110 350
new 0 110 350
return 1 110 351
assign 1 112 353
priorGet 0 112 353
assign 1 112 354
priorGet 0 112 354
assign 1 112 355
undef 1 112 360
return 1 112 360
assign 1 116 376
undef 1 116 381
assign 1 0 382
assign 1 116 385
priorGet 0 116 385
assign 1 116 386
undef 1 116 391
assign 1 0 392
assign 1 0 395
assign 1 0 399
assign 1 116 402
priorGet 0 116 402
assign 1 116 403
priorGet 0 116 403
assign 1 116 404
undef 1 116 409
assign 1 0 410
assign 1 0 413
assign 1 117 417
new 0 117 417
return 1 117 418
assign 1 119 420
priorGet 0 119 420
assign 1 119 421
priorGet 0 119 421
assign 1 119 422
priorGet 0 119 422
assign 1 119 423
undef 1 119 428
return 1 119 428
assign 1 123 431
new 0 123 431
assign 1 127 436
undef 1 127 441
return 1 128 442
delete 0 130 444
containerSet 1 131 445
assign 1 132 446
assign 1 136 454
undef 1 136 459
return 1 137 460
assign 1 139 462
mylistGet 0 139 462
assign 1 139 463
newNode 1 139 463
insertBefore 1 139 464
assign 1 140 465
containerGet 0 140 465
containerSet 1 140 466
assign 1 144 471
undef 1 144 476
initContained 0 145 477
prepend 1 147 479
containerSet 1 148 480
assign 1 152 485
undef 1 152 490
initContained 0 153 491
addValue 1 155 493
containerSet 1 156 494
assign 1 160 498
new 0 160 498
assign 1 164 503
undef 1 164 508
assign 1 165 509
new 0 165 509
assign 1 172 517
toStringCompact 0 172 517
print 0 174 521
throw 1 175 522
return 1 177 524
assign 1 181 564
prefixGet 0 181 564
assign 1 182 565
new 0 182 565
assign 1 182 566
add 1 182 566
assign 1 182 567
toString 0 182 567
assign 1 182 568
add 1 182 568
assign 1 182 569
new 0 182 569
assign 1 182 570
add 1 182 570
assign 1 183 571
new 0 183 571
assign 1 183 572
newlineGet 0 183 572
assign 1 183 573
add 1 183 573
assign 1 183 574
add 1 183 574
assign 1 183 575
new 0 183 575
assign 1 183 576
add 1 183 576
assign 1 183 577
toString 0 183 577
assign 1 183 578
add 1 183 578
assign 1 184 579
def 1 184 584
assign 1 184 585
def 1 184 590
assign 1 0 591
assign 1 0 594
assign 1 0 598
assign 1 185 601
new 0 185 601
assign 1 185 602
newlineGet 0 185 602
assign 1 185 603
add 1 185 603
assign 1 185 604
add 1 185 604
assign 1 185 605
new 0 185 605
assign 1 185 606
add 1 185 606
assign 1 185 607
toString 0 185 607
assign 1 185 608
add 1 185 608
assign 1 185 609
new 0 185 609
assign 1 185 610
add 1 185 610
assign 1 185 611
add 1 185 611
assign 1 185 612
new 0 185 612
assign 1 185 613
newlineGet 0 185 613
assign 1 185 614
add 1 185 614
assign 1 187 616
def 1 187 621
assign 1 188 622
new 0 188 622
assign 1 188 623
newlineGet 0 188 623
assign 1 188 624
add 1 188 624
assign 1 188 625
add 1 188 625
assign 1 188 626
new 0 188 626
assign 1 188 627
add 1 188 627
assign 1 189 628
toString 0 189 628
assign 1 189 629
add 1 189 629
return 1 191 631
assign 1 195 653
prefixGet 0 195 653
assign 1 196 654
new 0 196 654
assign 1 196 655
add 1 196 655
assign 1 196 656
toString 0 196 656
assign 1 196 657
add 1 196 657
assign 1 196 658
new 0 196 658
assign 1 196 659
add 1 196 659
assign 1 197 660
def 1 197 665
assign 1 198 666
new 0 198 666
assign 1 198 667
add 1 198 667
assign 1 198 668
toString 0 198 668
assign 1 198 669
add 1 198 669
assign 1 200 671
def 1 200 676
assign 1 201 677
new 0 201 677
assign 1 201 678
add 1 201 678
assign 1 201 679
toString 0 201 679
assign 1 201 680
add 1 201 680
assign 1 203 682
def 1 203 687
assign 1 204 688
new 0 204 688
assign 1 204 689
add 1 204 689
assign 1 204 690
toString 0 204 690
assign 1 204 691
add 1 204 691
return 1 206 693
assign 1 210 699
new 0 210 699
assign 1 211 700
containerGet 0 211 700
assign 1 212 703
def 1 212 708
incrementValue 0 213 709
assign 1 214 710
containerGet 0 214 710
return 1 216 716
assign 1 220 724
depthGet 0 220 724
assign 1 221 725
new 0 221 725
assign 1 222 726
new 0 222 726
assign 1 223 727
new 0 223 727
assign 1 223 730
lesser 1 223 735
assign 1 224 736
add 1 224 736
incrementValue 0 223 737
return 1 226 743
assign 1 230 752
assign 1 231 755
def 1 231 760
assign 1 231 761
typenameGet 0 231 761
assign 1 231 762
TRANSUNITGet 0 231 762
assign 1 231 763
notEquals 1 231 763
assign 1 0 765
assign 1 0 768
assign 1 0 772
assign 1 232 775
containerGet 0 232 775
return 1 234 781
assign 1 238 801
scopeGet 0 238 801
assign 1 239 802
typenameGet 0 239 802
assign 1 239 803
METHODGet 0 239 803
assign 1 239 804
notEquals 1 239 804
assign 1 240 806
new 0 240 806
assign 1 240 807
new 2 240 807
throw 1 240 808
assign 1 242 810
heldGet 0 242 810
assign 1 242 811
tmpCntGet 0 242 811
assign 1 242 812
toString 0 242 812
assign 1 243 813
heldGet 0 243 813
assign 1 243 814
tmpCntGet 0 243 814
incrementValue 0 243 815
assign 1 244 816
new 0 244 816
assign 1 245 817
new 0 245 817
isTmpVarSet 1 245 818
assign 1 246 819
new 0 246 819
autoTypeSet 1 246 820
suffixSet 1 247 821
assign 1 248 822
new 0 248 822
assign 1 248 823
add 1 248 823
assign 1 248 824
add 1 248 824
nameSet 1 248 825
return 1 249 826
assign 1 253 836
containerGet 0 253 836
assign 1 254 839
def 1 254 844
assign 1 255 845
typenameGet 0 255 845
assign 1 255 846
PROPERTIESGet 0 255 846
assign 1 255 847
equals 1 255 852
assign 1 256 853
new 0 256 853
return 1 256 854
assign 1 258 856
containerGet 0 258 856
assign 1 260 862
new 0 260 862
return 1 260 863
assign 1 264 890
assign 1 265 891
isAddedGet 0 265 891
assign 1 265 892
not 0 265 892
assign 1 266 894
new 0 266 894
isAddedSet 1 266 895
assign 1 267 896
scopeGet 0 267 896
assign 1 268 897
typenameGet 0 268 897
assign 1 268 898
CLASSGet 0 268 898
assign 1 268 899
equals 1 268 899
assign 1 269 901
new 0 269 901
assign 1 269 902
new 2 269 902
throw 1 269 903
assign 1 271 905
inPropertiesGet 0 271 905
assign 1 271 907
isTmpVarGet 0 271 907
assign 1 271 908
not 0 271 908
assign 1 0 910
assign 1 0 913
assign 1 0 917
assign 1 272 920
classGet 0 272 920
assign 1 273 921
new 0 273 921
isPropertySet 1 273 922
assign 1 275 924
heldGet 0 275 924
assign 1 276 925
anyMapGet 0 276 925
assign 1 276 926
nameGet 0 276 926
assign 1 276 927
has 1 276 927
assign 1 277 929
new 0 277 929
assign 1 277 930
new 2 277 930
throw 1 277 931
assign 1 279 933
anyMapGet 0 279 933
assign 1 279 934
nameGet 0 279 934
put 2 279 935
assign 1 280 936
orderedVarsGet 0 280 936
addValue 1 280 937
assign 1 285 968
assign 1 286 969
isAddedGet 0 286 969
assign 1 286 970
not 0 286 970
assign 1 287 972
new 0 287 972
isAddedSet 1 287 973
assign 1 288 974
scopeGet 0 288 974
assign 1 289 975
heldGet 0 289 975
assign 1 290 976
anyMapGet 0 290 976
assign 1 290 977
nameGet 0 290 977
assign 1 290 978
has 1 290 978
assign 1 291 980
anyMapGet 0 291 980
assign 1 291 981
nameGet 0 291 981
assign 1 291 982
get 1 291 982
assign 1 293 985
classGet 0 293 985
assign 1 293 986
heldGet 0 293 986
assign 1 294 987
anyMapGet 0 294 987
assign 1 294 988
nameGet 0 294 988
assign 1 294 989
has 1 294 989
assign 1 295 991
anyMapGet 0 295 991
assign 1 295 992
nameGet 0 295 992
assign 1 295 993
get 1 295 993
assign 1 297 996
anyMapGet 0 297 996
assign 1 297 997
nameGet 0 297 997
put 2 297 998
assign 1 298 999
orderedVarsGet 0 298 999
addValue 1 298 1000
assign 1 299 1001
typenameGet 0 299 1001
assign 1 299 1002
CLASSGet 0 299 1002
assign 1 299 1003
equals 1 299 1003
assign 1 300 1005
new 0 300 1005
assign 1 300 1006
new 2 300 1006
throw 1 300 1007
assign 1 309 1050
assign 1 310 1051
scopeGet 0 310 1051
assign 1 310 1052
heldGet 0 310 1052
assign 1 311 1053
anyMapGet 0 311 1053
assign 1 311 1054
has 1 311 1054
assign 1 312 1056
anyMapGet 0 312 1056
assign 1 312 1057
get 1 312 1057
assign 1 312 1058
heldGet 0 312 1058
assign 1 314 1061
classGet 0 314 1061
assign 1 314 1062
heldGet 0 314 1062
assign 1 315 1063
anyMapGet 0 315 1063
assign 1 315 1064
has 1 315 1064
assign 1 316 1066
anyMapGet 0 316 1066
assign 1 316 1067
get 1 316 1067
assign 1 316 1068
heldGet 0 316 1068
assign 1 318 1071
transUnitGet 0 318 1071
assign 1 319 1072
heldGet 0 319 1072
assign 1 319 1073
aliasedGet 0 319 1073
assign 1 319 1074
get 1 319 1074
assign 1 320 1075
undef 1 320 1080
assign 1 321 1081
emitDataGet 0 321 1081
assign 1 321 1082
aliasedGet 0 321 1082
assign 1 321 1083
get 1 321 1083
assign 1 323 1085
def 1 323 1090
assign 1 324 1091
new 0 324 1091
assign 1 324 1092
add 1 324 1092
assign 1 324 1093
new 2 324 1093
throw 1 324 1094
assign 1 327 1097
new 0 327 1097
nameSet 1 328 1098
assign 1 329 1099
new 0 329 1099
assign 1 329 1100
equals 1 329 1100
assign 1 330 1102
assign 1 331 1103
new 0 331 1103
isTypedSet 1 331 1104
assign 1 332 1105
extendsGet 0 332 1105
namepathSet 1 332 1106
assign 1 333 1107
anyMapGet 0 333 1107
put 2 333 1108
assign 1 334 1109
orderedVarsGet 0 334 1109
addValue 1 334 1110
assign 1 336 1113
new 0 336 1113
isDeclaredSet 1 336 1114
assign 1 337 1115
new 0 337 1115
isPropertySet 1 337 1116
assign 1 338 1117
assign 1 339 1118
anyMapGet 0 339 1118
put 2 339 1119
assign 1 340 1120
orderedVarsGet 0 340 1120
addValue 1 340 1121
assign 1 348 1137
assign 1 349 1138
new 0 349 1138
assign 1 351 1142
anchorTypesGet 0 351 1142
assign 1 351 1143
typenameGet 0 351 1143
assign 1 351 1144
has 1 351 1144
return 1 352 1146
assign 1 354 1149
containerGet 0 354 1149
assign 1 355 1150
undef 1 355 1155
assign 1 356 1156
new 0 356 1156
assign 1 356 1157
new 2 356 1157
throw 1 356 1158
assign 1 364 1172
assign 1 365 1175
def 1 365 1180
assign 1 365 1181
typenameGet 0 365 1181
assign 1 365 1182
CLASSGet 0 365 1182
assign 1 365 1183
notEquals 1 365 1183
assign 1 0 1185
assign 1 0 1188
assign 1 0 1192
assign 1 366 1195
containerGet 0 366 1195
return 1 368 1201
assign 1 372 1218
assign 1 373 1221
def 1 373 1226
assign 1 373 1227
typenameGet 0 373 1227
assign 1 373 1228
CLASSGet 0 373 1228
assign 1 373 1229
notEquals 1 373 1229
assign 1 0 1231
assign 1 0 1234
assign 1 0 1238
assign 1 373 1241
typenameGet 0 373 1241
assign 1 373 1242
METHODGet 0 373 1242
assign 1 373 1243
notEquals 1 373 1243
assign 1 0 1245
assign 1 0 1248
assign 1 0 1252
assign 1 373 1255
typenameGet 0 373 1255
assign 1 373 1256
TRANSUNITGet 0 373 1256
assign 1 373 1257
notEquals 1 373 1257
assign 1 0 1259
assign 1 0 1262
assign 1 0 1266
assign 1 374 1269
containerGet 0 374 1269
return 1 376 1275
assign 1 380 1280
undef 1 380 1285
return 1 381 1286
assign 1 383 1288
containerGet 0 383 1288
containerSet 1 383 1289
heldSet 1 384 1290
delete 0 388 1294
addValue 1 389 1295
assign 1 393 1302
containedGet 0 393 1302
assign 1 394 1303
iteratorGet 0 394 1303
assign 1 394 1306
hasNextGet 0 394 1306
assign 1 395 1308
nextGet 0 395 1308
containerSet 1 396 1309
assign 1 402 1331
NAMEPATHGet 0 402 1331
assign 1 402 1332
equals 1 402 1337
assign 1 403 1338
assign 1 404 1339
def 1 404 1344
resolve 1 405 1345
assign 1 408 1348
CLASSGet 0 408 1348
assign 1 408 1349
equals 1 408 1354
assign 1 409 1355
namepathGet 0 409 1355
assign 1 410 1356
def 1 410 1361
resolve 1 411 1362
assign 1 413 1364
extendsGet 0 413 1364
assign 1 414 1365
def 1 414 1370
resolve 1 415 1371
assign 1 417 1373
namepathGet 0 417 1373
assign 1 417 1374
toString 0 417 1374
nameSet 1 417 1375
assign 1 419 1377
VARGet 0 419 1377
assign 1 419 1378
equals 1 419 1383
assign 1 420 1384
namepathGet 0 420 1384
assign 1 421 1385
def 1 421 1390
resolve 1 422 1391
assign 1 432 1479
heldGet 0 432 1479
assign 1 432 1480
isConstructGet 0 432 1480
assign 1 432 1482
heldGet 0 432 1482
assign 1 432 1483
newNpGet 0 432 1483
assign 1 432 1484
toString 0 432 1484
assign 1 432 1485
new 0 432 1485
assign 1 432 1486
equals 1 432 1486
assign 1 0 1488
assign 1 0 1491
assign 1 0 1495
assign 1 433 1498
new 0 433 1498
return 1 433 1499
assign 1 436 1501
new 0 436 1501
assign 1 437 1507
new 0 437 1507
assign 1 438 1513
new 0 438 1513
assign 1 439 1519
new 0 439 1519
assign 1 440 1525
new 0 440 1525
assign 1 441 1531
sizeGet 0 441 1531
assign 1 441 1532
new 0 441 1532
assign 1 441 1533
equals 1 441 1538
assign 1 448 1539
new 0 448 1539
put 1 448 1540
assign 1 451 1541
new 0 451 1541
put 1 451 1542
assign 1 452 1543
new 0 452 1543
put 1 452 1544
assign 1 454 1545
new 0 454 1545
put 1 454 1546
assign 1 455 1547
new 0 455 1547
put 1 455 1548
assign 1 456 1549
new 0 456 1549
put 1 456 1550
assign 1 457 1551
new 0 457 1551
put 1 457 1552
assign 1 458 1553
new 0 458 1553
put 1 458 1554
assign 1 459 1555
new 0 459 1555
put 1 459 1556
assign 1 460 1557
new 0 460 1557
put 1 460 1558
assign 1 461 1559
new 0 461 1559
put 1 461 1560
assign 1 462 1561
new 0 462 1561
put 1 462 1562
assign 1 463 1563
new 0 463 1563
put 1 463 1564
assign 1 464 1565
new 0 464 1565
put 1 464 1566
assign 1 465 1567
new 0 465 1567
put 1 465 1568
assign 1 466 1569
new 0 466 1569
put 1 466 1570
assign 1 467 1571
new 0 467 1571
put 1 467 1572
assign 1 468 1573
new 0 468 1573
put 1 468 1574
assign 1 469 1575
new 0 469 1575
put 1 469 1576
assign 1 470 1577
new 0 470 1577
put 1 470 1578
assign 1 471 1579
new 0 471 1579
put 1 471 1580
assign 1 472 1581
new 0 472 1581
put 1 472 1582
assign 1 473 1583
new 0 473 1583
put 1 473 1584
assign 1 474 1585
new 0 474 1585
put 1 474 1586
assign 1 475 1587
new 0 475 1587
put 1 475 1588
assign 1 476 1589
new 0 476 1589
put 1 476 1590
assign 1 477 1591
new 0 477 1591
put 1 477 1592
assign 1 478 1593
new 0 478 1593
put 1 478 1594
assign 1 482 1595
new 0 482 1595
put 1 482 1596
assign 1 483 1597
new 0 483 1597
put 1 483 1598
assign 1 484 1599
new 0 484 1599
put 1 484 1600
assign 1 485 1601
new 0 485 1601
put 1 485 1602
assign 1 490 1603
new 0 490 1603
put 1 490 1604
assign 1 491 1605
new 0 491 1605
put 1 491 1606
assign 1 495 1608
heldGet 0 495 1608
assign 1 495 1609
nameGet 0 495 1609
assign 1 495 1610
has 1 495 1610
assign 1 497 1612
new 0 497 1612
return 1 497 1613
assign 1 501 1615
containedGet 0 501 1615
assign 1 501 1616
firstGet 0 501 1616
assign 1 501 1617
heldGet 0 501 1617
assign 1 501 1618
isTypedGet 0 501 1618
assign 1 501 1619
not 0 501 1619
assign 1 503 1621
new 0 503 1621
return 1 503 1622
assign 1 511 1624
containedGet 0 511 1624
assign 1 511 1625
firstGet 0 511 1625
assign 1 511 1626
heldGet 0 511 1626
assign 1 511 1627
namepathGet 0 511 1627
assign 1 511 1628
toString 0 511 1628
assign 1 511 1629
has 1 511 1629
assign 1 512 1631
heldGet 0 512 1631
assign 1 512 1632
nameGet 0 512 1632
assign 1 512 1633
has 1 512 1633
assign 1 514 1635
new 0 514 1635
return 1 514 1636
assign 1 519 1641
containedGet 0 519 1641
assign 1 519 1642
firstGet 0 519 1642
assign 1 519 1643
heldGet 0 519 1643
assign 1 519 1644
namepathGet 0 519 1644
assign 1 519 1645
toString 0 519 1645
assign 1 519 1646
has 1 519 1646
assign 1 520 1648
heldGet 0 520 1648
assign 1 520 1649
nameGet 0 520 1649
assign 1 520 1650
has 1 520 1650
assign 1 522 1652
new 0 522 1652
return 1 522 1653
assign 1 528 1658
new 0 528 1658
return 1 528 1659
assign 1 539 1691
new 0 539 1691
assign 1 544 1692
CALLGet 0 544 1692
assign 1 544 1693
notEquals 1 544 1698
assign 1 544 1699
new 0 544 1699
return 1 544 1700
assign 1 545 1702
orgNameGet 0 545 1702
assign 1 545 1703
new 0 545 1703
assign 1 545 1704
equals 1 545 1704
assign 1 546 1706
firstGet 0 546 1706
assign 1 547 1707
secondGet 0 547 1707
assign 1 548 1708
def 1 548 1713
assign 1 548 1714
typenameGet 0 548 1714
assign 1 548 1715
CALLGet 0 548 1715
assign 1 548 1716
equals 1 548 1721
assign 1 0 1722
assign 1 0 1725
assign 1 0 1729
assign 1 549 1732
heldGet 0 549 1732
assign 1 549 1733
isLiteralGet 0 549 1733
assign 1 549 1735
heldGet 0 549 1735
assign 1 549 1736
isPropertyGet 0 549 1736
assign 1 549 1737
not 0 549 1737
assign 1 0 1739
assign 1 0 1742
assign 1 0 1746
assign 1 550 1749
new 0 550 1749
assign 1 551 1750
heldGet 0 551 1750
assign 1 551 1751
allCallsGet 0 551 1751
assign 1 551 1752
iteratorGet 0 0 1752
assign 1 551 1755
hasNextGet 0 551 1755
assign 1 551 1757
nextGet 0 551 1757
assign 1 552 1758
notEquals 1 552 1758
assign 1 553 1760
callIsSafe 1 553 1760
assign 1 553 1761
not 0 553 1766
assign 1 554 1767
new 0 554 1767
return 1 554 1768
return 1 565 1779
return 1 0 1782
return 1 0 1785
assign 1 0 1788
assign 1 0 1792
return 1 0 1796
return 1 0 1799
assign 1 0 1802
assign 1 0 1806
return 1 0 1810
return 1 0 1813
assign 1 0 1816
assign 1 0 1820
return 1 0 1824
return 1 0 1827
assign 1 0 1830
assign 1 0 1834
return 1 0 1838
return 1 0 1841
assign 1 0 1844
assign 1 0 1848
return 1 0 1852
return 1 0 1855
assign 1 0 1858
assign 1 0 1862
return 1 0 1866
return 1 0 1869
assign 1 0 1872
assign 1 0 1876
return 1 0 1880
return 1 0 1883
assign 1 0 1886
assign 1 0 1890
return 1 0 1894
return 1 0 1897
assign 1 0 1900
assign 1 0 1904
return 1 0 1908
return 1 0 1911
assign 1 0 1914
assign 1 0 1918
return 1 0 1922
return 1 0 1925
assign 1 0 1928
assign 1 0 1932
return 1 0 1936
return 1 0 1939
assign 1 0 1942
assign 1 0 1946
return 1 0 1950
return 1 0 1953
assign 1 0 1956
assign 1 0 1960
return 1 0 1964
return 1 0 1967
assign 1 0 1970
assign 1 0 1974
return 1 0 1978
return 1 0 1981
assign 1 0 1984
assign 1 0 1988
return 1 0 1992
return 1 0 1995
assign 1 0 1998
assign 1 0 2002
return 1 0 2006
return 1 0 2009
assign 1 0 2012
assign 1 0 2016
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 758802515: return bem_once_0();
case 961903680: return bem_containerGet_0();
case -751657044: return bem_secondGet_0();
case 373929796: return bem_addVariable_0();
case 993759307: return bem_iteratorGet_0();
case 2037449490: return bem_priorPeerGet_0();
case 1692290065: return bem_reInitContained_0();
case 1520924398: return bem_toStringCompact_0();
case -1922356588: return bem_delayDelete_0();
case -82673213: return bem_inPropertiesGet_0();
case 46463676: return bem_nlcGetDirect_0();
case -35248652: return bem_toAny_0();
case -1283459023: return bem_delete_0();
case -354749400: return bem_depthGet_0();
case -1463870512: return bem_scopeGet_0();
case 675566088: return bem_classNameGet_0();
case 1250265045: return bem_constantsGet_0();
case 897666401: return bem_typenameGet_0();
case -1689868304: return bem_wideStringGet_0();
case 20642314: return bem_ntypesGetDirect_0();
case 2010994217: return bem_isLiteralOnceGet_0();
case -359133654: return bem_inClassNpGet_0();
case 1375376430: return bem_thirdGet_0();
case 105648211: return bem_nextPeerGet_0();
case -1400770094: return bem_many_0();
case 1870761871: return bem_constantsGetDirect_0();
case 1594065187: return bem_inFileGetDirect_0();
case 1299948053: return bem_serializeContents_0();
case 1349866592: return bem_toString_0();
case 2081826200: return bem_nlcGet_0();
case -1767503258: return bem_delayDeleteGetDirect_0();
case 152774500: return bem_containedGet_0();
case -1534505736: return bem_heldByGetDirect_0();
case 1052263558: return bem_serializeToString_0();
case -746395870: return bem_inlinedGetDirect_0();
case 1237752071: return bem_condanyGetDirect_0();
case 1578957460: return bem_condanyGet_0();
case 1957608515: return bem_fieldIteratorGet_0();
case 518862870: return bem_tagGet_0();
case 1115963173: return bem_nextDescendGet_0();
case 1577119962: return bem_nlecGetDirect_0();
case 2081319470: return bem_initContained_0();
case 648222810: return bem_resolveNp_0();
case -359055592: return bem_heldByGet_0();
case -804644943: return bem_typenameGetDirect_0();
case 646589914: return bem_sourceFileNameGet_0();
case 968129667: return bem_ntypesGet_0();
case 37178757: return bem_inlinedGet_0();
case -1189786665: return bem_firstGet_0();
case -1090727716: return bem_wideStringGetDirect_0();
case 1720794971: return bem_classGet_0();
case -512236724: return bem_deserializeClassNameGet_0();
case -1497340781: return bem_isThirdGet_0();
case -296507733: return bem_buildGet_0();
case 45823921: return bem_isSecondGet_0();
case -332406532: return bem_inClassNpGetDirect_0();
case -914347833: return bem_new_0();
case 248765454: return bem_prefixGet_0();
case 985319258: return bem_nlecGet_0();
case -1423578661: return bem_print_0();
case -923057320: return bem_serializationIteratorGet_0();
case 2032771297: return bem_heldGet_0();
case 1183213199: return bem_containedGetDirect_0();
case 1446424900: return bem_inFileGet_0();
case 13807179: return bem_hashGet_0();
case -518710385: return bem_fieldNamesGet_0();
case -1980051957: return bem_syncAddVariable_0();
case -1766117881: return bem_transUnitGet_0();
case 1725741943: return bem_typeDetailGetDirect_0();
case -1570387002: return bem_nextAscendGet_0();
case -1189855036: return bem_heldGetDirect_0();
case 683261566: return bem_typeDetailGet_0();
case -245363326: return bem_copy_0();
case -2091241279: return bem_create_0();
case -1965415408: return bem_anchorGet_0();
case -663638612: return bem_buildGetDirect_0();
case 1498757707: return bem_isFirstGet_0();
case -83114822: return bem_toStringBig_0();
case 1867000550: return bem_delayDeleteGet_0();
case -2035208893: return bem_echo_0();
case -1209028673: return bem_containerGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1117079734: return bem_inFileSetDirect_1(bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case -537932837: return bem_equals_1(bevd_0);
case 1249176153: return bem_inFileSet_1(bevd_0);
case -1887889142: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 1374613219: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 209995776: return bem_condanySet_1(bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case -1481383110: return bem_wideStringSetDirect_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -913655817: return bem_nlcSet_1(bevd_0);
case 1765490842: return bem_containerSet_1(bevd_0);
case 2074781221: return bem_heldSet_1(bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case 1800015562: return bem_heldBySetDirect_1(bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case 1060735344: return bem_typeDetailSet_1(bevd_0);
case -1152464394: return bem_typenameSet_1(bevd_0);
case 481789825: return bem_ntypesSet_1(bevd_0);
case -1034489448: return bem_typeDetailSetDirect_1(bevd_0);
case -1495841299: return bem_buildSet_1(bevd_0);
case 1700884134: return bem_nlcSetDirect_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case 930956120: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1229247573: return bem_constantsSet_1(bevd_0);
case -1783432725: return bem_delayDeleteSetDirect_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case 139205972: return bem_nlecSetDirect_1(bevd_0);
case 491319560: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case -766291592: return bem_containedSet_1(bevd_0);
case 2072639832: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case 1626353481: return bem_heldBySet_1(bevd_0);
case -2064439446: return bem_inClassNpSet_1(bevd_0);
case -992295107: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case 1478681953: return bem_callIsSafe_1((BEC_2_5_4_BuildNode) bevd_0);
case -195704480: return bem_heldSetDirect_1(bevd_0);
case -2092935060: return bem_condanySetDirect_1(bevd_0);
case -929957576: return bem_containedSetDirect_1(bevd_0);
case -340377293: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1392428020: return bem_constantsSetDirect_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case -1756533749: return bem_nlecSet_1(bevd_0);
case -1943697232: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case -798718302: return bem_buildSetDirect_1(bevd_0);
case 640349330: return bem_wideStringSet_1(bevd_0);
case -541456681: return bem_inClassNpSetDirect_1(bevd_0);
case -2018385139: return bem_ntypesSetDirect_1(bevd_0);
case -1093631943: return bem_typenameSetDirect_1(bevd_0);
case -1276524485: return bem_inlinedSetDirect_1(bevd_0);
case -1176283810: return bem_inlinedSet_1(bevd_0);
case 736059795: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case 137358348: return bem_containerSetDirect_1(bevd_0);
case -1525387727: return bem_delayDeleteSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1371172718: return bem_tmpVar_2(bevd_0, bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_4_BuildNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst = (BEC_2_5_4_BuildNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_type;
}
}
