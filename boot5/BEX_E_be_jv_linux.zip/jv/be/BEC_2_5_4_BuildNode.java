package be;
/* IO:File: source/build/Nodes.be */
public final class BEC_2_5_4_BuildNode extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
private static byte[] becc_BEC_2_5_4_BuildNode_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_2_5_4_BuildNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_0 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_1 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_5 = {0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_6 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_8 = {0x20,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_9 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_10 = {0x5F,0x74,0x61,0x5F};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_11 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_12 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_13 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_15 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_16 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
public static BEC_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_inst;

public static BET_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_type;

public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_3_9_10_9_ContainerLinkedListAwareNode bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_2_4_3_MathInt(0));
bevp_nlec = (new BEC_2_4_3_MathInt(0));
bevp_wideString = be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_fromNode.bem_nlcGet_0();
bevp_nlc = bevt_0_ta_ph.bem_copy_0();
bevt_1_ta_ph = beva_fromNode.bem_nlecGet_0();
bevp_nlec = bevt_1_ta_ph.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (bevp_contained == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_4_ta_ph = bevp_contained.bem_firstGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_5_ta_ph = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_ta_ph;
} /* Line: 45*/
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
/* Line: 49*/ {
if (bevl_ret == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 49*/ {
if (bevl_con == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 49*/
 else /* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 49*/ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 51*/
 else /* Line: 49*/ {
break;
} /* Line: 49*/
} /* Line: 49*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
/* Line: 59*/ {
if (bevl_ret == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 59*/ {
if (bevl_con == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 59*/
 else /* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 59*/ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 61*/
 else /* Line: 59*/ {
break;
} /* Line: 59*/
} /* Line: 59*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 67*/ {
return null;
} /* Line: 68*/
bevl_hh = bevp_heldBy.bem_nextGet_0();
if (bevl_hh == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 71*/ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 72*/
bevt_2_ta_ph = bevl_hh.bemd_0(196928297);
return (BEC_2_5_4_BuildNode) bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 78*/ {
return null;
} /* Line: 79*/
bevl_hh = bevp_heldBy.bem_priorGet_0();
if (bevl_hh == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 82*/ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 83*/
bevt_2_ta_ph = bevl_hh.bemd_0(196928297);
return (BEC_2_5_4_BuildNode) bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 102*/
bevt_3_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
if (bevp_heldBy == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 108*/ {
bevt_3_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 108*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 108*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 109*/
bevt_7_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_priorGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_11_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_12_ta_ph = null;
if (bevp_heldBy == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_4_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 115*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_7_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_priorGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 115*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 115*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 116*/
bevt_12_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_priorGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_priorGet_0();
if (bevt_10_ta_ph == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 126*/ {
return null;
} /* Line: 127*/
bevp_heldBy.bem_delete_0();
bem_containerSet_1(null);
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
BEC_2_5_4_BuildNode bevt_3_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 135*/ {
return null;
} /* Line: 136*/
bevt_2_ta_ph = bevp_heldBy.bem_mylistGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_newNode_1(beva_x);
bevp_heldBy.bem_insertBefore_1(bevt_1_ta_ph);
bevt_3_ta_ph = bem_containerGet_0();
beva_x.bem_containerSet_1(bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 143*/ {
bem_initContained_0();
} /* Line: 144*/
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 151*/ {
bem_initContained_0();
} /* Line: 152*/
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 163*/ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 164*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try /* Line: 170*/ {
bevl_res = bem_toStringCompact_0();
} /* Line: 171*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(807655445);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 174*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_7_TextStrings bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_7_TextStrings bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_7_TextStrings bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
bevl_prefix = bem_prefixGet_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_2_ta_ph = bevl_prefix.bemd_1(1584364126, bevt_3_ta_ph);
bevt_4_ta_ph = bevp_typename.bem_toString_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(1584364126, bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = bevt_1_ta_ph.bemd_1(1584364126, bevt_5_ta_ph);
bevt_10_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_9_ta_ph = bevt_10_ta_ph.bem_newlineGet_0();
bevt_8_ta_ph = bevl_ret.bemd_1(1584364126, bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(1584364126, bevl_prefix);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_2));
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(1584364126, bevt_11_ta_ph);
bevt_12_ta_ph = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bemd_1(1584364126, bevt_12_ta_ph);
if (bevp_inClassNp == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 183*/ {
if (bevp_inFile == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 183*/
 else /* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 183*/ {
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_21_ta_ph = bevt_22_ta_ph.bem_newlineGet_0();
bevt_20_ta_ph = bevl_ret.bemd_1(1584364126, bevt_21_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_1(1584364126, bevl_prefix);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_3));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(1584364126, bevt_23_ta_ph);
bevt_24_ta_ph = bevp_inClassNp.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(1584364126, bevt_24_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_4));
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(1584364126, bevt_25_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(1584364126, bevp_inFile);
bevt_27_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_26_ta_ph = bevt_27_ta_ph.bem_newlineGet_0();
bevl_ret = bevt_15_ta_ph.bemd_1(1584364126, bevt_26_ta_ph);
} /* Line: 184*/
if (bevp_held == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 186*/ {
bevt_32_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_31_ta_ph = bevt_32_ta_ph.bem_newlineGet_0();
bevt_30_ta_ph = bevl_ret.bemd_1(1584364126, bevt_31_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(1584364126, bevl_prefix);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevl_ret = bevt_29_ta_ph.bemd_1(1584364126, bevt_33_ta_ph);
bevt_34_ta_ph = bevp_held.bemd_0(-677150073);
bevl_ret = bevl_ret.bemd_1(1584364126, bevt_34_ta_ph);
} /* Line: 188*/
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
bevl_prefix = bem_prefixGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_1_ta_ph = bevl_prefix.bemd_1(1584364126, bevt_2_ta_ph);
bevt_3_ta_ph = bevp_typename.bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1584364126, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(1584364126, bevt_4_ta_ph);
if (bevp_nlc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 196*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_6));
bevt_6_ta_ph = bevl_ret.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
} /* Line: 197*/
if (bevp_inClassNp == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 199*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_7));
bevt_10_ta_ph = bevl_ret.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_ta_ph.bem_add_1(bevt_12_ta_ph);
} /* Line: 200*/
if (bevp_held == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 202*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevt_14_ta_ph = bevl_ret.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = bevp_held.bemd_0(-677150073);
bevl_ret = bevt_14_ta_ph.bem_add_1(bevt_16_ta_ph);
} /* Line: 203*/
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_d = (new BEC_2_4_3_MathInt(0));
bevl_c = bem_containerGet_0();
while (true)
/* Line: 211*/ {
if (bevl_c == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 211*/ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 213*/
 else /* Line: 211*/ {
break;
} /* Line: 211*/
} /* Line: 211*/
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_d = bem_depthGet_0();
bevl_p = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_4_BuildNode_bels_8));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 222*/ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 222*/ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 222*/
 else /* Line: 222*/ {
break;
} /* Line: 222*/
} /* Line: 222*/
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 230*/ {
if (bevl_targ == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 230*/ {
bevt_3_ta_ph = bevl_targ.bemd_0(-1738458884);
bevt_4_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(1748833599, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 230*/
 else /* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 230*/ {
bevl_targ = bevl_targ.bemd_0(1752193128);
} /* Line: 231*/
 else /* Line: 230*/ {
break;
} /* Line: 230*/
} /* Line: 230*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_clnode = bem_scopeGet_0();
bevt_1_ta_ph = bevl_clnode.bemd_0(-1738458884);
bevt_2_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1748833599, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 238*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildNode_bels_9));
bevt_3_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 239*/
bevt_6_ta_ph = bevl_clnode.bemd_0(196928297);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(1483992330);
bevl_tmpanyn = bevt_5_ta_ph.bemd_0(-677150073);
bevt_8_ta_ph = bevl_clnode.bemd_0(196928297);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(1483992330);
bevt_7_ta_ph.bemd_0(-1799284910);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(-1175406588, bevt_9_ta_ph);
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(1908122252, bevt_10_ta_ph);
bevl_tmpany.bemd_1(721725179, beva_suffix);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_BuildNode_bels_10));
bevt_12_ta_ph = bevl_tmpanyn.bemd_1(1584364126, bevt_13_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(1584364126, beva_suffix);
bevl_tmpany.bemd_1(-1585081495, bevt_11_ta_ph);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_con = bem_containerGet_0();
while (true)
/* Line: 253*/ {
if (bevl_con == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 253*/ {
bevt_2_ta_ph = bevl_con.bem_typenameGet_0();
bevt_3_ta_ph = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 255*/
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 257*/
 else /* Line: 253*/ {
break;
} /* Line: 253*/
} /* Line: 253*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
bevl_v = bevp_held;
bevt_2_ta_ph = bevl_v.bemd_0(-2065502961);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1764485786);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 264*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(630202781, bevt_3_ta_ph);
bevl_sco = bem_scopeGet_0();
bevt_5_ta_ph = bevl_sco.bemd_0(-1738458884);
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(1812729488, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 267*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_4_BuildNode_bels_11));
bevt_7_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_7_ta_ph);
} /* Line: 268*/
bevt_9_ta_ph = bem_inPropertiesGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 270*/ {
bevt_11_ta_ph = bevl_v.bemd_0(1350430346);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(1764485786);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 270*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 270*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 270*/
 else /* Line: 270*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 270*/ {
bevl_sco = bem_classGet_0();
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1474155031, bevt_12_ta_ph);
} /* Line: 272*/
bevl_sc = bevl_sco.bemd_0(196928297);
bevt_14_ta_ph = bevl_sc.bemd_0(672323507);
bevt_15_ta_ph = bevl_v.bemd_0(749770559);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_1(1954378938, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 275*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_4_BuildNode_bels_12));
bevt_16_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_16_ta_ph);
} /* Line: 276*/
bevt_18_ta_ph = bevl_sc.bemd_0(672323507);
bevt_19_ta_ph = bevl_v.bemd_0(749770559);
bevt_18_ta_ph.bemd_2(-627787012, bevt_19_ta_ph, this);
bevt_20_ta_ph = bevl_sc.bemd_0(408949676);
bevt_20_ta_ph.bemd_1(-1149238266, this);
} /* Line: 279*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevl_v = bevp_held;
bevt_1_ta_ph = bevl_v.bemd_0(-2065502961);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1764485786);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 285*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(630202781, bevt_2_ta_ph);
bevl_sco = bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(196928297);
bevt_4_ta_ph = bevl_sc.bemd_0(672323507);
bevt_5_ta_ph = bevl_v.bemd_0(749770559);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(1954378938, bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 289*/ {
bevt_6_ta_ph = bevl_sc.bemd_0(672323507);
bevt_7_ta_ph = bevl_v.bemd_0(749770559);
bevp_held = bevt_6_ta_ph.bemd_1(1770175602, bevt_7_ta_ph);
} /* Line: 290*/
 else /* Line: 291*/ {
bevt_8_ta_ph = bem_classGet_0();
bevl_cl = bevt_8_ta_ph.bemd_0(196928297);
bevt_10_ta_ph = bevl_cl.bemd_0(672323507);
bevt_11_ta_ph = bevl_v.bemd_0(749770559);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(1954378938, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 293*/ {
bevt_12_ta_ph = bevl_cl.bemd_0(672323507);
bevt_13_ta_ph = bevl_v.bemd_0(749770559);
bevp_held = bevt_12_ta_ph.bemd_1(1770175602, bevt_13_ta_ph);
} /* Line: 294*/
 else /* Line: 295*/ {
bevt_14_ta_ph = bevl_sc.bemd_0(672323507);
bevt_15_ta_ph = bevl_v.bemd_0(749770559);
bevt_14_ta_ph.bemd_2(-627787012, bevt_15_ta_ph, this);
bevt_16_ta_ph = bevl_sc.bemd_0(408949676);
bevt_16_ta_ph.bemd_1(-1149238266, this);
bevt_18_ta_ph = bevl_sco.bemd_0(-1738458884);
bevt_19_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(1812729488, bevt_19_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 298*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_4_BuildNode_bels_13));
bevt_20_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_20_ta_ph);
} /* Line: 299*/
} /* Line: 298*/
} /* Line: 293*/
} /* Line: 289*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_13_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
bevl_vname = bevp_held;
bevt_0_ta_ph = bem_scopeGet_0();
bevl_sc = bevt_0_ta_ph.bemd_0(196928297);
bevt_2_ta_ph = bevl_sc.bemd_0(672323507);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(1954378938, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 310*/ {
bevt_4_ta_ph = bevl_sc.bemd_0(672323507);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(1770175602, bevl_vname);
bevp_held = bevt_3_ta_ph.bemd_0(196928297);
} /* Line: 311*/
 else /* Line: 312*/ {
bevt_5_ta_ph = bem_classGet_0();
bevl_cl = bevt_5_ta_ph.bemd_0(196928297);
bevt_7_ta_ph = bevl_cl.bemd_0(672323507);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(1954378938, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 314*/ {
bevt_9_ta_ph = bevl_cl.bemd_0(672323507);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_1(1770175602, bevl_vname);
bevp_held = bevt_8_ta_ph.bemd_0(196928297);
} /* Line: 315*/
 else /* Line: 316*/ {
bevl_tunode = bem_transUnitGet_0();
bevt_11_ta_ph = bevl_tunode.bemd_0(196928297);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1168948824);
bevl_np = bevt_10_ta_ph.bemd_1(1770175602, bevl_vname);
if (bevl_np == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 319*/ {
bevt_14_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_aliasedGet_0();
bevl_np = bevt_13_ta_ph.bem_get_1(bevl_vname);
} /* Line: 320*/
if (bevl_np == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 322*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_14));
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(bevl_np);
bevt_16_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_16_ta_ph);
} /* Line: 323*/
 else /* Line: 324*/ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(-1585081495, bevl_vname);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_15));
bevt_19_ta_ph = bevl_vname.bemd_1(1812729488, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_19_ta_ph).bevi_bool)/* Line: 328*/ {
bevp_held = bevl_v;
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-510378045, bevt_21_ta_ph);
bevt_22_ta_ph = bevl_cl.bemd_0(415725416);
bevl_v.bemd_1(-1869933828, bevt_22_ta_ph);
bevt_23_ta_ph = bevl_sc.bemd_0(672323507);
bevt_23_ta_ph.bemd_2(-627787012, bevl_vname, this);
bevt_24_ta_ph = bevl_sc.bemd_0(408949676);
bevt_24_ta_ph.bemd_1(-1149238266, this);
} /* Line: 333*/
 else /* Line: 334*/ {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(-1386790412, bevt_25_ta_ph);
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1474155031, bevt_26_ta_ph);
bevp_held = bevl_v;
bevt_27_ta_ph = bevl_cl.bemd_0(672323507);
bevt_27_ta_ph.bemd_2(-627787012, bevl_vname, this);
bevt_28_ta_ph = bevl_cl.bemd_0(408949676);
bevt_28_ta_ph.bemd_1(-1149238266, this);
} /* Line: 339*/
} /* Line: 328*/
} /* Line: 322*/
} /* Line: 314*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_node = this;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 348*/ {
while (true)
/* Line: 349*/ {
bevt_2_ta_ph = bevp_constants.bem_anchorTypesGet_0();
bevt_3_ta_ph = bevl_node.bemd_0(-1738458884);
bevt_1_ta_ph = bevt_2_ta_ph.bem_has_1(bevt_3_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 350*/ {
return bevl_node;
} /* Line: 351*/
 else /* Line: 352*/ {
bevl_node = bevl_node.bemd_0(1752193128);
if (bevl_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 354*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_16));
bevt_5_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 355*/
} /* Line: 354*/
} /* Line: 350*/
} /* Line: 349*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 364*/ {
if (bevl_targ == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 364*/ {
bevt_3_ta_ph = bevl_targ.bemd_0(-1738458884);
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(1748833599, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 364*/
 else /* Line: 364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 364*/ {
bevl_targ = bevl_targ.bemd_0(1752193128);
} /* Line: 365*/
 else /* Line: 364*/ {
break;
} /* Line: 364*/
} /* Line: 364*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 372*/ {
if (bevl_targ == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 372*/ {
bevt_5_ta_ph = bevl_targ.bemd_0(-1738458884);
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(1748833599, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 372*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 372*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 372*/
 else /* Line: 372*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 372*/ {
bevt_8_ta_ph = bevl_targ.bemd_0(-1738458884);
bevt_9_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(1748833599, bevt_9_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 372*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 372*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 372*/
 else /* Line: 372*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 372*/ {
bevt_11_ta_ph = bevl_targ.bemd_0(-1738458884);
bevt_12_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(1748833599, bevt_12_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 372*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 372*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 372*/
 else /* Line: 372*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 372*/ {
bevl_targ = bevl_targ.bemd_0(1752193128);
} /* Line: 373*/
 else /* Line: 372*/ {
break;
} /* Line: 372*/
} /* Line: 372*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_BuildNode bevt_1_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 379*/ {
return null;
} /* Line: 380*/
bevt_1_ta_ph = bem_containerGet_0();
beva_other.bem_containerSet_1(bevt_1_ta_ph);
bevp_heldBy.bem_heldSet_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
/* Line: 393*/ {
bevt_0_ta_ph = bevl_it.bemd_0(1681879581);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 393*/ {
bevl_i = bevl_it.bemd_0(1696433337);
bevl_i.bemd_1(-930117097, this);
} /* Line: 395*/
 else /* Line: 393*/ {
break;
} /* Line: 393*/
} /* Line: 393*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
bevt_1_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 401*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 403*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 404*/
} /* Line: 403*/
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 407*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-1652677786);
if (bevl_np == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 409*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 410*/
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(415725416);
if (bevl_np == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 413*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 414*/
bevt_8_ta_ph = bevp_held.bemd_0(-1652677786);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-677150073);
bevp_held.bemd_1(-1585081495, bevt_7_ta_ph);
} /* Line: 416*/
bevt_10_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 418*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-1652677786);
if (bevl_np == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 420*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 421*/
} /* Line: 420*/
return this;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public final BEC_2_9_8_ContainerNodeList bem_containedGetDirect_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_heldGetDirect_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public final BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGetDirect_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_heldBySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() throws Throwable {
return bevp_condany;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_condanyGetDirect_0() throws Throwable {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_condany = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_condanySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_condany = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public final BEC_2_4_6_TextString bem_inFileGetDirect_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_typeDetailGetDirect_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeDetail = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_typeDetailSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeDetail = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_delayDeleteGetDirect_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_delayDeleteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nlcGetDirect_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_nlcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nlecGetDirect_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_nlecSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wideStringGetDirect_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_wideStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildGetDirect_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public final BEC_2_4_3_MathInt bem_typenameGetDirect_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_typenameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_inlinedGetDirect_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inlinedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 37, 37, 38, 38, 39, 40, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 47, 48, 49, 49, 49, 49, 0, 0, 0, 50, 51, 53, 57, 58, 59, 59, 59, 59, 0, 0, 0, 60, 61, 63, 67, 67, 68, 70, 71, 71, 72, 74, 74, 78, 78, 79, 81, 82, 82, 83, 85, 85, 89, 89, 93, 93, 97, 97, 101, 101, 102, 102, 104, 104, 104, 108, 108, 0, 108, 108, 108, 0, 0, 109, 109, 111, 111, 111, 111, 115, 115, 0, 115, 115, 115, 0, 0, 0, 115, 115, 115, 115, 0, 0, 116, 116, 118, 118, 118, 118, 118, 122, 126, 126, 127, 129, 130, 131, 135, 135, 136, 138, 138, 138, 139, 139, 143, 143, 144, 146, 147, 151, 151, 152, 154, 155, 159, 163, 163, 164, 171, 173, 174, 176, 180, 181, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 0, 0, 0, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 187, 187, 188, 188, 190, 194, 195, 195, 195, 195, 195, 195, 196, 196, 197, 197, 197, 197, 199, 199, 200, 200, 200, 200, 202, 202, 203, 203, 203, 203, 205, 209, 210, 211, 211, 212, 213, 215, 219, 220, 221, 222, 222, 222, 223, 222, 225, 229, 230, 230, 230, 230, 230, 0, 0, 0, 231, 233, 237, 238, 238, 238, 239, 239, 239, 241, 241, 241, 242, 242, 242, 243, 244, 244, 245, 245, 246, 247, 247, 247, 247, 248, 252, 253, 253, 254, 254, 254, 254, 255, 255, 257, 259, 259, 263, 264, 264, 265, 265, 266, 267, 267, 267, 268, 268, 268, 270, 270, 270, 0, 0, 0, 271, 272, 272, 274, 275, 275, 275, 276, 276, 276, 278, 278, 278, 279, 279, 284, 285, 285, 286, 286, 287, 288, 289, 289, 289, 290, 290, 290, 292, 292, 293, 293, 293, 294, 294, 294, 296, 296, 296, 297, 297, 298, 298, 298, 299, 299, 299, 308, 309, 309, 310, 310, 311, 311, 311, 313, 313, 314, 314, 315, 315, 315, 317, 318, 318, 318, 319, 319, 320, 320, 320, 322, 322, 323, 323, 323, 323, 326, 327, 328, 328, 329, 330, 330, 331, 331, 332, 332, 333, 333, 335, 335, 336, 336, 337, 338, 338, 339, 339, 347, 348, 350, 350, 350, 351, 353, 354, 354, 355, 355, 355, 363, 364, 364, 364, 364, 364, 0, 0, 0, 365, 367, 371, 372, 372, 372, 372, 372, 0, 0, 0, 372, 372, 372, 0, 0, 0, 372, 372, 372, 0, 0, 0, 373, 375, 379, 379, 380, 382, 382, 383, 387, 388, 392, 393, 393, 394, 395, 401, 401, 401, 402, 403, 403, 404, 407, 407, 407, 408, 409, 409, 410, 412, 413, 413, 414, 416, 416, 416, 418, 418, 418, 419, 420, 420, 421, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 60, 61, 62, 63, 64, 65, 79, 84, 85, 86, 91, 92, 95, 99, 102, 103, 105, 106, 109, 114, 115, 120, 121, 124, 128, 131, 132, 138, 146, 147, 150, 155, 156, 161, 162, 165, 169, 172, 173, 179, 186, 191, 192, 194, 195, 200, 201, 203, 204, 211, 216, 217, 219, 220, 225, 226, 228, 229, 233, 234, 238, 239, 243, 244, 251, 256, 257, 258, 260, 261, 266, 277, 282, 283, 286, 287, 292, 293, 296, 300, 301, 303, 304, 305, 310, 326, 331, 332, 335, 336, 341, 342, 345, 349, 352, 353, 354, 359, 360, 363, 367, 368, 370, 371, 372, 373, 378, 381, 386, 391, 392, 394, 395, 396, 404, 409, 410, 412, 413, 414, 415, 416, 421, 426, 427, 429, 430, 435, 440, 441, 443, 444, 448, 453, 458, 459, 467, 471, 472, 474, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 534, 535, 540, 541, 544, 548, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 566, 571, 572, 573, 574, 575, 576, 577, 578, 579, 581, 603, 604, 605, 606, 607, 608, 609, 610, 615, 616, 617, 618, 619, 621, 626, 627, 628, 629, 630, 632, 637, 638, 639, 640, 641, 643, 649, 650, 653, 658, 659, 660, 666, 674, 675, 676, 677, 680, 685, 686, 687, 693, 702, 705, 710, 711, 712, 713, 715, 718, 722, 725, 731, 751, 752, 753, 754, 756, 757, 758, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 786, 789, 794, 795, 796, 797, 802, 803, 804, 806, 812, 813, 840, 841, 842, 844, 845, 846, 847, 848, 849, 851, 852, 853, 855, 857, 858, 860, 863, 867, 870, 871, 872, 874, 875, 876, 877, 879, 880, 881, 883, 884, 885, 886, 887, 918, 919, 920, 922, 923, 924, 925, 926, 927, 928, 930, 931, 932, 935, 936, 937, 938, 939, 941, 942, 943, 946, 947, 948, 949, 950, 951, 952, 953, 955, 956, 957, 1000, 1001, 1002, 1003, 1004, 1006, 1007, 1008, 1011, 1012, 1013, 1014, 1016, 1017, 1018, 1021, 1022, 1023, 1024, 1025, 1030, 1031, 1032, 1033, 1035, 1040, 1041, 1042, 1043, 1044, 1047, 1048, 1049, 1050, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1087, 1088, 1092, 1093, 1094, 1096, 1099, 1100, 1105, 1106, 1107, 1108, 1122, 1125, 1130, 1131, 1132, 1133, 1135, 1138, 1142, 1145, 1151, 1168, 1171, 1176, 1177, 1178, 1179, 1181, 1184, 1188, 1191, 1192, 1193, 1195, 1198, 1202, 1205, 1206, 1207, 1209, 1212, 1216, 1219, 1225, 1230, 1235, 1236, 1238, 1239, 1240, 1244, 1245, 1252, 1253, 1256, 1258, 1259, 1281, 1282, 1287, 1288, 1289, 1294, 1295, 1298, 1299, 1304, 1305, 1306, 1311, 1312, 1314, 1315, 1320, 1321, 1323, 1324, 1325, 1327, 1328, 1333, 1334, 1335, 1340, 1341, 1347, 1350, 1353, 1357, 1361, 1364, 1367, 1371, 1375, 1378, 1381, 1385, 1389, 1392, 1395, 1399, 1403, 1406, 1409, 1413, 1417, 1420, 1423, 1427, 1431, 1434, 1437, 1441, 1445, 1448, 1451, 1455, 1459, 1462, 1465, 1469, 1473, 1476, 1479, 1483, 1487, 1490, 1493, 1497, 1501, 1504, 1507, 1511, 1515, 1518, 1521, 1525, 1529, 1532, 1535, 1539, 1543, 1546, 1549, 1553, 1557, 1560, 1563, 1567, 1571, 1574, 1577, 1581};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 46
new 0 23 46
assign 1 24 47
new 0 24 47
assign 1 25 48
new 0 25 48
assign 1 26 49
new 0 26 49
assign 1 28 50
assign 1 29 51
constantsGet 0 29 51
assign 1 30 52
ntypesGet 0 30 52
assign 1 31 53
TOKENGet 0 31 53
assign 1 32 54
new 0 32 54
assign 1 37 60
nlcGet 0 37 60
assign 1 37 61
copy 0 37 61
assign 1 38 62
nlecGet 0 38 62
assign 1 38 63
copy 0 38 63
assign 1 39 64
inClassNpGet 0 39 64
assign 1 40 65
inFileGet 0 40 65
assign 1 44 79
def 1 44 84
assign 1 44 85
firstGet 0 44 85
assign 1 44 86
def 1 44 91
assign 1 0 92
assign 1 0 95
assign 1 0 99
assign 1 45 102
firstGet 0 45 102
return 1 45 103
assign 1 47 105
nextPeerGet 0 47 105
assign 1 48 106
containerGet 0 48 106
assign 1 49 109
undef 1 49 114
assign 1 49 115
def 1 49 120
assign 1 0 121
assign 1 0 124
assign 1 0 128
assign 1 50 131
nextPeerGet 0 50 131
assign 1 51 132
containerGet 0 51 132
return 1 53 138
assign 1 57 146
nextPeerGet 0 57 146
assign 1 58 147
containerGet 0 58 147
assign 1 59 150
undef 1 59 155
assign 1 59 156
def 1 59 161
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 60 172
nextPeerGet 0 60 172
assign 1 61 173
containerGet 0 61 173
return 1 63 179
assign 1 67 186
undef 1 67 191
return 1 68 192
assign 1 70 194
nextGet 0 70 194
assign 1 71 195
undef 1 71 200
return 1 72 201
assign 1 74 203
heldGet 0 74 203
return 1 74 204
assign 1 78 211
undef 1 78 216
return 1 79 217
assign 1 81 219
priorGet 0 81 219
assign 1 82 220
undef 1 82 225
return 1 83 226
assign 1 85 228
heldGet 0 85 228
return 1 85 229
assign 1 89 233
firstGet 0 89 233
return 1 89 234
assign 1 93 238
secondGet 0 93 238
return 1 93 239
assign 1 97 243
thirdGet 0 97 243
return 1 97 244
assign 1 101 251
undef 1 101 256
assign 1 102 257
new 0 102 257
return 1 102 258
assign 1 104 260
priorGet 0 104 260
assign 1 104 261
undef 1 104 266
return 1 104 266
assign 1 108 277
undef 1 108 282
assign 1 0 283
assign 1 108 286
priorGet 0 108 286
assign 1 108 287
undef 1 108 292
assign 1 0 293
assign 1 0 296
assign 1 109 300
new 0 109 300
return 1 109 301
assign 1 111 303
priorGet 0 111 303
assign 1 111 304
priorGet 0 111 304
assign 1 111 305
undef 1 111 310
return 1 111 310
assign 1 115 326
undef 1 115 331
assign 1 0 332
assign 1 115 335
priorGet 0 115 335
assign 1 115 336
undef 1 115 341
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 115 352
priorGet 0 115 352
assign 1 115 353
priorGet 0 115 353
assign 1 115 354
undef 1 115 359
assign 1 0 360
assign 1 0 363
assign 1 116 367
new 0 116 367
return 1 116 368
assign 1 118 370
priorGet 0 118 370
assign 1 118 371
priorGet 0 118 371
assign 1 118 372
priorGet 0 118 372
assign 1 118 373
undef 1 118 378
return 1 118 378
assign 1 122 381
new 0 122 381
assign 1 126 386
undef 1 126 391
return 1 127 392
delete 0 129 394
containerSet 1 130 395
assign 1 131 396
assign 1 135 404
undef 1 135 409
return 1 136 410
assign 1 138 412
mylistGet 0 138 412
assign 1 138 413
newNode 1 138 413
insertBefore 1 138 414
assign 1 139 415
containerGet 0 139 415
containerSet 1 139 416
assign 1 143 421
undef 1 143 426
initContained 0 144 427
prepend 1 146 429
containerSet 1 147 430
assign 1 151 435
undef 1 151 440
initContained 0 152 441
addValue 1 154 443
containerSet 1 155 444
assign 1 159 448
new 0 159 448
assign 1 163 453
undef 1 163 458
assign 1 164 459
new 0 164 459
assign 1 171 467
toStringCompact 0 171 467
print 0 173 471
throw 1 174 472
return 1 176 474
assign 1 180 514
prefixGet 0 180 514
assign 1 181 515
new 0 181 515
assign 1 181 516
add 1 181 516
assign 1 181 517
toString 0 181 517
assign 1 181 518
add 1 181 518
assign 1 181 519
new 0 181 519
assign 1 181 520
add 1 181 520
assign 1 182 521
new 0 182 521
assign 1 182 522
newlineGet 0 182 522
assign 1 182 523
add 1 182 523
assign 1 182 524
add 1 182 524
assign 1 182 525
new 0 182 525
assign 1 182 526
add 1 182 526
assign 1 182 527
toString 0 182 527
assign 1 182 528
add 1 182 528
assign 1 183 529
def 1 183 534
assign 1 183 535
def 1 183 540
assign 1 0 541
assign 1 0 544
assign 1 0 548
assign 1 184 551
new 0 184 551
assign 1 184 552
newlineGet 0 184 552
assign 1 184 553
add 1 184 553
assign 1 184 554
add 1 184 554
assign 1 184 555
new 0 184 555
assign 1 184 556
add 1 184 556
assign 1 184 557
toString 0 184 557
assign 1 184 558
add 1 184 558
assign 1 184 559
new 0 184 559
assign 1 184 560
add 1 184 560
assign 1 184 561
add 1 184 561
assign 1 184 562
new 0 184 562
assign 1 184 563
newlineGet 0 184 563
assign 1 184 564
add 1 184 564
assign 1 186 566
def 1 186 571
assign 1 187 572
new 0 187 572
assign 1 187 573
newlineGet 0 187 573
assign 1 187 574
add 1 187 574
assign 1 187 575
add 1 187 575
assign 1 187 576
new 0 187 576
assign 1 187 577
add 1 187 577
assign 1 188 578
toString 0 188 578
assign 1 188 579
add 1 188 579
return 1 190 581
assign 1 194 603
prefixGet 0 194 603
assign 1 195 604
new 0 195 604
assign 1 195 605
add 1 195 605
assign 1 195 606
toString 0 195 606
assign 1 195 607
add 1 195 607
assign 1 195 608
new 0 195 608
assign 1 195 609
add 1 195 609
assign 1 196 610
def 1 196 615
assign 1 197 616
new 0 197 616
assign 1 197 617
add 1 197 617
assign 1 197 618
toString 0 197 618
assign 1 197 619
add 1 197 619
assign 1 199 621
def 1 199 626
assign 1 200 627
new 0 200 627
assign 1 200 628
add 1 200 628
assign 1 200 629
toString 0 200 629
assign 1 200 630
add 1 200 630
assign 1 202 632
def 1 202 637
assign 1 203 638
new 0 203 638
assign 1 203 639
add 1 203 639
assign 1 203 640
toString 0 203 640
assign 1 203 641
add 1 203 641
return 1 205 643
assign 1 209 649
new 0 209 649
assign 1 210 650
containerGet 0 210 650
assign 1 211 653
def 1 211 658
incrementValue 0 212 659
assign 1 213 660
containerGet 0 213 660
return 1 215 666
assign 1 219 674
depthGet 0 219 674
assign 1 220 675
new 0 220 675
assign 1 221 676
new 0 221 676
assign 1 222 677
new 0 222 677
assign 1 222 680
lesser 1 222 685
assign 1 223 686
add 1 223 686
incrementValue 0 222 687
return 1 225 693
assign 1 229 702
assign 1 230 705
def 1 230 710
assign 1 230 711
typenameGet 0 230 711
assign 1 230 712
TRANSUNITGet 0 230 712
assign 1 230 713
notEquals 1 230 713
assign 1 0 715
assign 1 0 718
assign 1 0 722
assign 1 231 725
containerGet 0 231 725
return 1 233 731
assign 1 237 751
scopeGet 0 237 751
assign 1 238 752
typenameGet 0 238 752
assign 1 238 753
METHODGet 0 238 753
assign 1 238 754
notEquals 1 238 754
assign 1 239 756
new 0 239 756
assign 1 239 757
new 2 239 757
throw 1 239 758
assign 1 241 760
heldGet 0 241 760
assign 1 241 761
tmpCntGet 0 241 761
assign 1 241 762
toString 0 241 762
assign 1 242 763
heldGet 0 242 763
assign 1 242 764
tmpCntGet 0 242 764
incrementValue 0 242 765
assign 1 243 766
new 0 243 766
assign 1 244 767
new 0 244 767
isTmpVarSet 1 244 768
assign 1 245 769
new 0 245 769
autoTypeSet 1 245 770
suffixSet 1 246 771
assign 1 247 772
new 0 247 772
assign 1 247 773
add 1 247 773
assign 1 247 774
add 1 247 774
nameSet 1 247 775
return 1 248 776
assign 1 252 786
containerGet 0 252 786
assign 1 253 789
def 1 253 794
assign 1 254 795
typenameGet 0 254 795
assign 1 254 796
PROPERTIESGet 0 254 796
assign 1 254 797
equals 1 254 802
assign 1 255 803
new 0 255 803
return 1 255 804
assign 1 257 806
containerGet 0 257 806
assign 1 259 812
new 0 259 812
return 1 259 813
assign 1 263 840
assign 1 264 841
isAddedGet 0 264 841
assign 1 264 842
not 0 264 842
assign 1 265 844
new 0 265 844
isAddedSet 1 265 845
assign 1 266 846
scopeGet 0 266 846
assign 1 267 847
typenameGet 0 267 847
assign 1 267 848
CLASSGet 0 267 848
assign 1 267 849
equals 1 267 849
assign 1 268 851
new 0 268 851
assign 1 268 852
new 2 268 852
throw 1 268 853
assign 1 270 855
inPropertiesGet 0 270 855
assign 1 270 857
isTmpVarGet 0 270 857
assign 1 270 858
not 0 270 858
assign 1 0 860
assign 1 0 863
assign 1 0 867
assign 1 271 870
classGet 0 271 870
assign 1 272 871
new 0 272 871
isPropertySet 1 272 872
assign 1 274 874
heldGet 0 274 874
assign 1 275 875
anyMapGet 0 275 875
assign 1 275 876
nameGet 0 275 876
assign 1 275 877
has 1 275 877
assign 1 276 879
new 0 276 879
assign 1 276 880
new 2 276 880
throw 1 276 881
assign 1 278 883
anyMapGet 0 278 883
assign 1 278 884
nameGet 0 278 884
put 2 278 885
assign 1 279 886
orderedVarsGet 0 279 886
addValue 1 279 887
assign 1 284 918
assign 1 285 919
isAddedGet 0 285 919
assign 1 285 920
not 0 285 920
assign 1 286 922
new 0 286 922
isAddedSet 1 286 923
assign 1 287 924
scopeGet 0 287 924
assign 1 288 925
heldGet 0 288 925
assign 1 289 926
anyMapGet 0 289 926
assign 1 289 927
nameGet 0 289 927
assign 1 289 928
has 1 289 928
assign 1 290 930
anyMapGet 0 290 930
assign 1 290 931
nameGet 0 290 931
assign 1 290 932
get 1 290 932
assign 1 292 935
classGet 0 292 935
assign 1 292 936
heldGet 0 292 936
assign 1 293 937
anyMapGet 0 293 937
assign 1 293 938
nameGet 0 293 938
assign 1 293 939
has 1 293 939
assign 1 294 941
anyMapGet 0 294 941
assign 1 294 942
nameGet 0 294 942
assign 1 294 943
get 1 294 943
assign 1 296 946
anyMapGet 0 296 946
assign 1 296 947
nameGet 0 296 947
put 2 296 948
assign 1 297 949
orderedVarsGet 0 297 949
addValue 1 297 950
assign 1 298 951
typenameGet 0 298 951
assign 1 298 952
CLASSGet 0 298 952
assign 1 298 953
equals 1 298 953
assign 1 299 955
new 0 299 955
assign 1 299 956
new 2 299 956
throw 1 299 957
assign 1 308 1000
assign 1 309 1001
scopeGet 0 309 1001
assign 1 309 1002
heldGet 0 309 1002
assign 1 310 1003
anyMapGet 0 310 1003
assign 1 310 1004
has 1 310 1004
assign 1 311 1006
anyMapGet 0 311 1006
assign 1 311 1007
get 1 311 1007
assign 1 311 1008
heldGet 0 311 1008
assign 1 313 1011
classGet 0 313 1011
assign 1 313 1012
heldGet 0 313 1012
assign 1 314 1013
anyMapGet 0 314 1013
assign 1 314 1014
has 1 314 1014
assign 1 315 1016
anyMapGet 0 315 1016
assign 1 315 1017
get 1 315 1017
assign 1 315 1018
heldGet 0 315 1018
assign 1 317 1021
transUnitGet 0 317 1021
assign 1 318 1022
heldGet 0 318 1022
assign 1 318 1023
aliasedGet 0 318 1023
assign 1 318 1024
get 1 318 1024
assign 1 319 1025
undef 1 319 1030
assign 1 320 1031
emitDataGet 0 320 1031
assign 1 320 1032
aliasedGet 0 320 1032
assign 1 320 1033
get 1 320 1033
assign 1 322 1035
def 1 322 1040
assign 1 323 1041
new 0 323 1041
assign 1 323 1042
add 1 323 1042
assign 1 323 1043
new 2 323 1043
throw 1 323 1044
assign 1 326 1047
new 0 326 1047
nameSet 1 327 1048
assign 1 328 1049
new 0 328 1049
assign 1 328 1050
equals 1 328 1050
assign 1 329 1052
assign 1 330 1053
new 0 330 1053
isTypedSet 1 330 1054
assign 1 331 1055
extendsGet 0 331 1055
namepathSet 1 331 1056
assign 1 332 1057
anyMapGet 0 332 1057
put 2 332 1058
assign 1 333 1059
orderedVarsGet 0 333 1059
addValue 1 333 1060
assign 1 335 1063
new 0 335 1063
isDeclaredSet 1 335 1064
assign 1 336 1065
new 0 336 1065
isPropertySet 1 336 1066
assign 1 337 1067
assign 1 338 1068
anyMapGet 0 338 1068
put 2 338 1069
assign 1 339 1070
orderedVarsGet 0 339 1070
addValue 1 339 1071
assign 1 347 1087
assign 1 348 1088
new 0 348 1088
assign 1 350 1092
anchorTypesGet 0 350 1092
assign 1 350 1093
typenameGet 0 350 1093
assign 1 350 1094
has 1 350 1094
return 1 351 1096
assign 1 353 1099
containerGet 0 353 1099
assign 1 354 1100
undef 1 354 1105
assign 1 355 1106
new 0 355 1106
assign 1 355 1107
new 2 355 1107
throw 1 355 1108
assign 1 363 1122
assign 1 364 1125
def 1 364 1130
assign 1 364 1131
typenameGet 0 364 1131
assign 1 364 1132
CLASSGet 0 364 1132
assign 1 364 1133
notEquals 1 364 1133
assign 1 0 1135
assign 1 0 1138
assign 1 0 1142
assign 1 365 1145
containerGet 0 365 1145
return 1 367 1151
assign 1 371 1168
assign 1 372 1171
def 1 372 1176
assign 1 372 1177
typenameGet 0 372 1177
assign 1 372 1178
CLASSGet 0 372 1178
assign 1 372 1179
notEquals 1 372 1179
assign 1 0 1181
assign 1 0 1184
assign 1 0 1188
assign 1 372 1191
typenameGet 0 372 1191
assign 1 372 1192
METHODGet 0 372 1192
assign 1 372 1193
notEquals 1 372 1193
assign 1 0 1195
assign 1 0 1198
assign 1 0 1202
assign 1 372 1205
typenameGet 0 372 1205
assign 1 372 1206
TRANSUNITGet 0 372 1206
assign 1 372 1207
notEquals 1 372 1207
assign 1 0 1209
assign 1 0 1212
assign 1 0 1216
assign 1 373 1219
containerGet 0 373 1219
return 1 375 1225
assign 1 379 1230
undef 1 379 1235
return 1 380 1236
assign 1 382 1238
containerGet 0 382 1238
containerSet 1 382 1239
heldSet 1 383 1240
delete 0 387 1244
addValue 1 388 1245
assign 1 392 1252
containedGet 0 392 1252
assign 1 393 1253
iteratorGet 0 393 1253
assign 1 393 1256
hasNextGet 0 393 1256
assign 1 394 1258
nextGet 0 394 1258
containerSet 1 395 1259
assign 1 401 1281
NAMEPATHGet 0 401 1281
assign 1 401 1282
equals 1 401 1287
assign 1 402 1288
assign 1 403 1289
def 1 403 1294
resolve 1 404 1295
assign 1 407 1298
CLASSGet 0 407 1298
assign 1 407 1299
equals 1 407 1304
assign 1 408 1305
namepathGet 0 408 1305
assign 1 409 1306
def 1 409 1311
resolve 1 410 1312
assign 1 412 1314
extendsGet 0 412 1314
assign 1 413 1315
def 1 413 1320
resolve 1 414 1321
assign 1 416 1323
namepathGet 0 416 1323
assign 1 416 1324
toString 0 416 1324
nameSet 1 416 1325
assign 1 418 1327
VARGet 0 418 1327
assign 1 418 1328
equals 1 418 1333
assign 1 419 1334
namepathGet 0 419 1334
assign 1 420 1335
def 1 420 1340
resolve 1 421 1341
return 1 0 1347
return 1 0 1350
assign 1 0 1353
assign 1 0 1357
return 1 0 1361
return 1 0 1364
assign 1 0 1367
assign 1 0 1371
return 1 0 1375
return 1 0 1378
assign 1 0 1381
assign 1 0 1385
return 1 0 1389
return 1 0 1392
assign 1 0 1395
assign 1 0 1399
return 1 0 1403
return 1 0 1406
assign 1 0 1409
assign 1 0 1413
return 1 0 1417
return 1 0 1420
assign 1 0 1423
assign 1 0 1427
return 1 0 1431
return 1 0 1434
assign 1 0 1437
assign 1 0 1441
return 1 0 1445
return 1 0 1448
assign 1 0 1451
assign 1 0 1455
return 1 0 1459
return 1 0 1462
assign 1 0 1465
assign 1 0 1469
return 1 0 1473
return 1 0 1476
assign 1 0 1479
assign 1 0 1483
return 1 0 1487
return 1 0 1490
assign 1 0 1493
assign 1 0 1497
return 1 0 1501
return 1 0 1504
assign 1 0 1507
assign 1 0 1511
return 1 0 1515
return 1 0 1518
assign 1 0 1521
assign 1 0 1525
return 1 0 1529
return 1 0 1532
assign 1 0 1535
assign 1 0 1539
return 1 0 1543
return 1 0 1546
assign 1 0 1549
assign 1 0 1553
return 1 0 1557
return 1 0 1560
assign 1 0 1563
assign 1 0 1567
return 1 0 1571
return 1 0 1574
assign 1 0 1577
assign 1 0 1581
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2034540153: return bem_syncAddVariable_0();
case -1738458884: return bem_typenameGet_0();
case -287326573: return bem_containerGetDirect_0();
case -831383947: return bem_inFileGet_0();
case 409380620: return bem_fieldIteratorGet_0();
case -2115439750: return bem_typeDetailGetDirect_0();
case 1958875772: return bem_initContained_0();
case -543330026: return bem_fieldNamesGet_0();
case -1818065006: return bem_nlcGetDirect_0();
case 1410587895: return bem_constantsGet_0();
case -1319137433: return bem_resolveNp_0();
case -366523977: return bem_inlinedGet_0();
case 1605323166: return bem_priorPeerGet_0();
case -1718188704: return bem_hashGet_0();
case -1970639679: return bem_nlcGet_0();
case -857834610: return bem_buildGet_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case -331491067: return bem_inClassNpGetDirect_0();
case -1069524953: return bem_ntypesGetDirect_0();
case 1358964037: return bem_delayDeleteGetDirect_0();
case -442537710: return bem_classGet_0();
case 2066839134: return bem_iteratorGet_0();
case -1915219814: return bem_typenameGetDirect_0();
case 1995661347: return bem_constantsGetDirect_0();
case -1728194038: return bem_prefixGet_0();
case 99680894: return bem_scopeGet_0();
case -1042859987: return bem_delayDeleteGet_0();
case 1651758374: return bem_thirdGet_0();
case -639757512: return bem_transUnitGet_0();
case 807655445: return bem_print_0();
case 1342623754: return bem_copy_0();
case 556565361: return bem_serializationIteratorGet_0();
case 719956322: return bem_condanyGetDirect_0();
case -314603489: return bem_nlecGetDirect_0();
case 1532823091: return bem_toStringCompact_0();
case 1510679071: return bem_nextPeerGet_0();
case -1297616941: return bem_containedGet_0();
case 1855845835: return bem_buildGetDirect_0();
case 1567159219: return bem_wideStringGetDirect_0();
case 149732689: return bem_inClassNpGet_0();
case -1280822406: return bem_isFirstGet_0();
case -2139381908: return bem_secondGet_0();
case 1698888040: return bem_toStringBig_0();
case 1660850695: return bem_heldByGet_0();
case 1752193128: return bem_containerGet_0();
case -1930280234: return bem_isSecondGet_0();
case 1590540462: return bem_nextAscendGet_0();
case -437711556: return bem_delayDelete_0();
case 498101216: return bem_echo_0();
case -2124354635: return bem_serializeToString_0();
case 868579263: return bem_heldGetDirect_0();
case 911997409: return bem_wideStringGet_0();
case 224950949: return bem_inFileGetDirect_0();
case 247576523: return bem_classNameGet_0();
case -1794485421: return bem_serializeContents_0();
case 1428766497: return bem_inPropertiesGet_0();
case 1835802788: return bem_addVariable_0();
case 536902098: return bem_nextDescendGet_0();
case 762553302: return bem_firstGet_0();
case -225222698: return bem_create_0();
case 1077307579: return bem_isThirdGet_0();
case 398187407: return bem_sourceFileNameGet_0();
case 1414485404: return bem_nlecGet_0();
case 809123860: return bem_heldByGetDirect_0();
case -1505765230: return bem_depthGet_0();
case -70310920: return bem_typeDetailGet_0();
case 196928297: return bem_heldGet_0();
case 126387064: return bem_new_0();
case -1787916208: return bem_condanyGet_0();
case -958997185: return bem_ntypesGet_0();
case -677150073: return bem_toString_0();
case -11094273: return bem_inlinedGetDirect_0();
case -312657332: return bem_containedGetDirect_0();
case 1070627980: return bem_reInitContained_0();
case 18460769: return bem_anchorGet_0();
case 34110590: return bem_delete_0();
case -1749437314: return bem_tagGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1238937232: return bem_heldBySet_1(bevd_0);
case 785145234: return bem_buildSet_1(bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case -1516976669: return bem_typenameSetDirect_1(bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case -1497928736: return bem_constantsSet_1(bevd_0);
case 284683814: return bem_wideStringSet_1(bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1470975410: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1995636535: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case 1678308931: return bem_typeDetailSet_1(bevd_0);
case -1382428872: return bem_containedSetDirect_1(bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
case -57881169: return bem_typeDetailSetDirect_1(bevd_0);
case 254058734: return bem_inlinedSetDirect_1(bevd_0);
case 1558062450: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case -1180006819: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1042013363: return bem_wideStringSetDirect_1(bevd_0);
case -530845621: return bem_condanySet_1(bevd_0);
case 643548482: return bem_buildSetDirect_1(bevd_0);
case 14144092: return bem_nlecSet_1(bevd_0);
case -730190438: return bem_containerSetDirect_1(bevd_0);
case 1019256041: return bem_nlcSetDirect_1(bevd_0);
case 965096298: return bem_heldSet_1(bevd_0);
case 1502842604: return bem_def_1(bevd_0);
case 123535344: return bem_nlcSet_1(bevd_0);
case -1399638769: return bem_delayDeleteSetDirect_1(bevd_0);
case 801847540: return bem_condanySetDirect_1(bevd_0);
case 1758948342: return bem_constantsSetDirect_1(bevd_0);
case 842728187: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case 1736982781: return bem_heldSetDirect_1(bevd_0);
case 1622474369: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case 2069334810: return bem_inClassNpSetDirect_1(bevd_0);
case 1045213349: return bem_inFileSet_1(bevd_0);
case 1428690346: return bem_ntypesSetDirect_1(bevd_0);
case 749720753: return bem_inFileSetDirect_1(bevd_0);
case -1506232635: return bem_containedSet_1(bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case -1676326985: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case 1695072721: return bem_nlecSetDirect_1(bevd_0);
case -347806802: return bem_ntypesSet_1(bevd_0);
case -1207184996: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case -930117097: return bem_containerSet_1(bevd_0);
case 353454315: return bem_inlinedSet_1(bevd_0);
case 1279135853: return bem_heldBySetDirect_1(bevd_0);
case -1411360879: return bem_typenameSet_1(bevd_0);
case 399454066: return bem_inClassNpSet_1(bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1149238266: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case -220486268: return bem_delayDeleteSet_1(bevd_0);
case -404194174: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1125116446: return bem_tmpVar_2(bevd_0, bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_4_BuildNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst = (BEC_2_5_4_BuildNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_type;
}
}
