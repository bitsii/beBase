package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_6_JsonParser extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_JsonParser() { }
private static byte[] becc_BEC_2_4_6_JsonParser_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x72};
private static byte[] becc_BEC_2_4_6_JsonParser_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_0 = {0x7B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_1 = {0x7D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_2 = {0x5B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_3 = {0x5D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_4 = {0x5C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_5 = {0x2C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_6 = {0x62,0x66,0x6E,0x72,0x74,0x2F};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_8 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_9 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_10 = {0x74,0x6F,0x6B,0x20,0x74,0x6F,0x6F,0x20,0x73,0x6D,0x61,0x6C,0x6C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_11 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_12 = {0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_13 = {0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_14 = {0x37,0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_15 = {0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_16 = {0x45,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_17 = {0x46,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_18 = {0x30,0x46,0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_19 = {0x30,0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_20 = {0x31,0x30,0x46,0x46,0x46,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_21 = {0x46,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_22 = {0x31,0x43,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_23 = {0x30,0x33,0x46,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_24 = {0x30,0x30,0x30,0x46,0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_25 = {0x30,0x30,0x30,0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_26 = {0x66,0x61,0x69,0x6C,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x74,0x6F,0x20,0x62,0x75,0x66,0x66,0x65,0x72,0x20,0x63,0x6F,0x6E,0x76,0x65,0x72,0x74};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_27 = {0x75};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_28 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x69,0x73,0x20,0x69,0x6E,0x76,0x61,0x6C,0x69,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_29 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x65,0x64,0x20,0x62,0x79,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_30 = {0x74};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_31 = {0x72};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_32 = {0x66};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_33 = {0x6E};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_34 = {0x75,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_35 = {0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_36 = {0x75,0x6C,0x6C};
public static BEC_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_inst;

public static BET_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_type;

public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_lbrace;
public BEC_2_4_6_TextString bevp_rbrace;
public BEC_2_4_6_TextString bevp_lbracket;
public BEC_2_4_6_TextString bevp_rbracket;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_6_TextString bevp_escape;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_comma;
public BEC_2_4_6_TextString bevp_tokens;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_4_3_MathInt bevp_hsub;
public BEC_2_4_3_MathInt bevp_vsub;
public BEC_2_4_3_MathInt bevp_hmAdd;
public BEC_2_4_6_JsonParser bem_new_0() throws Throwable {
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_7_TextStrings bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_quote = bevt_0_ta_ph.bem_quoteGet_0();
bevp_lbrace = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_0));
bevp_rbrace = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_1));
bevp_lbracket = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_2));
bevp_rbracket = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_3));
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_space = bevt_1_ta_ph.bem_spaceGet_0();
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_colon = bevt_2_ta_ph.bem_colonGet_0();
bevp_escape = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_4));
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_cr = bevt_3_ta_ph.bem_crGet_0();
bevt_4_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_lf = bevt_4_ta_ph.bem_lfGet_0();
bevp_comma = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_5));
bevt_14_ta_ph = bevp_quote.bem_add_1(bevp_lbrace);
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevp_rbrace);
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevp_lbracket);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevp_rbracket);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevp_space);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_colon);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_escape);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevp_cr);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevp_lf);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_comma);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_6));
bevp_tokens = bevt_5_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
bevp_toker = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevp_tokens, bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_7));
bevp_hsub = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_8));
bevp_vsub = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevp_hmAdd = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_19_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parse_2(BEC_2_4_6_TextString beva_str, BEC_2_6_6_SystemObject beva_handler) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_toker.bem_tokenize_1(beva_str);
bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevt_0_ta_ph , beva_handler);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_jsonUcIsPairStart_1(BEC_2_4_3_MathInt beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(55296));
if (bevt_2_ta_ph.bevi_int <= beva_value.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 68*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(56319));
if (beva_value.bevi_int <= bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 68*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 68*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 68*/
 else /* Line: 68*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 68*/ {
bevl_result = be.BECS_Runtime.boolTrue;
} /* Line: 69*/
 else /* Line: 70*/ {
bevl_result = be.BECS_Runtime.boolFalse;
} /* Line: 71*/
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_jsonUcIsPairEnd_1(BEC_2_4_3_MathInt beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(56320));
if (bevt_2_ta_ph.bevi_int <= beva_value.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 79*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(57343));
if (beva_value.bevi_int <= bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 79*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 79*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 79*/
 else /* Line: 79*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 79*/ {
bevl_result = be.BECS_Runtime.boolTrue;
} /* Line: 80*/
 else /* Line: 81*/ {
bevl_result = be.BECS_Runtime.boolFalse;
} /* Line: 82*/
return bevl_result;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonUcGetAfterPart_1(BEC_2_4_6_TextString beva_tok) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = beva_tok.bem_sizeGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(6));
if (bevt_1_ta_ph.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 89*/ {
return null;
} /* Line: 90*/
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(5));
bevt_3_ta_ph = beva_tok.bem_substring_1(bevt_4_ta_ph);
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_jsonUcUnescape_1(BEC_2_4_6_TextString beva_tok) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_9_SystemException bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
bevt_1_ta_ph = beva_tok.bem_sizeGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(5));
if (bevt_1_ta_ph.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 96*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_6_JsonParser_bels_10));
bevt_3_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_ta_ph);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 97*/
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_6_ta_ph = beva_tok.bem_substring_1(bevt_7_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_6_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_JsonParser bem_jsonUcAppendValue_3(BEC_2_4_3_MathInt beva_heldValue, BEC_2_4_3_MathInt beva_value, BEC_2_4_6_TextString beva_accum) throws Throwable {
BEC_2_4_3_MathInt bevl_sizeNow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_heldm = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_3_MathInt bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_4_3_MathInt bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_4_3_MathInt bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_4_3_MathInt bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_3_MathInt bevt_93_ta_ph = null;
BEC_2_4_3_MathInt bevt_94_ta_ph = null;
BEC_2_4_3_MathInt bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_4_3_MathInt bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_5_4_LogicBool bevt_102_ta_ph = null;
BEC_2_4_3_MathInt bevt_103_ta_ph = null;
BEC_2_6_9_SystemException bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_4_3_MathInt bevt_107_ta_ph = null;
bevt_2_ta_ph = beva_accum.bem_capacityGet_0();
bevt_3_ta_ph = beva_accum.bem_sizeGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_subtract_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(4));
if (bevt_1_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 104*/ {
bevt_6_ta_ph = beva_accum.bem_sizeGet_0();
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_7_ta_ph);
beva_accum.bem_capacitySet_1(bevt_5_ta_ph);
} /* Line: 105*/
bevl_sizeNow = beva_accum.bem_sizeGet_0();
if (beva_heldValue == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 110*/ {
bevl_heldm = beva_heldValue;
bevl_heldm.bem_subtractValue_1(bevp_hsub);
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(10));
bevl_heldm.bem_shiftLeftValue_1(bevt_9_ta_ph);
bevl_heldm.bem_subtractValue_1(bevp_vsub);
bevl_heldm.bevi_int += beva_value.bevi_int;
bevl_heldm.bevi_int += bevp_hmAdd.bevi_int;
beva_value = bevl_heldm;
} /* Line: 118*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_value.bevi_int < bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 124*/ {
bevl_size = (new BEC_2_4_3_MathInt(-1));
} /* Line: 125*/
 else /* Line: 124*/ {
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_13_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_14_ta_ph);
if (beva_value.bevi_int < bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 126*/ {
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, beva_value);
bevl_size = (new BEC_2_4_3_MathInt(1));
} /* Line: 128*/
 else /* Line: 124*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_12));
bevt_16_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_ta_ph);
if (beva_value.bevi_int < bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 129*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_13));
bevt_19_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_20_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_14));
bevt_23_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_24_ta_ph);
bevt_22_ta_ph = beva_value.bem_and_1(bevt_23_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_21_ta_ph = bevt_22_ta_ph.bem_shiftRight_1(bevt_25_ta_ph);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_21_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_18_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_26_ta_ph = bevl_sizeNow.bem_add_1(bevt_27_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_29_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_30_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_15));
bevt_32_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_33_ta_ph);
bevt_31_ta_ph = beva_value.bem_and_1(bevt_32_ta_ph);
bevt_28_ta_ph = bevt_29_ta_ph.bem_add_1(bevt_31_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_26_ta_ph, bevt_28_ta_ph);
bevl_size = (new BEC_2_4_3_MathInt(2));
} /* Line: 132*/
 else /* Line: 124*/ {
bevt_36_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevt_35_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_36_ta_ph);
if (beva_value.bevi_int < bevt_35_ta_ph.bevi_int) {
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 133*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_16));
bevt_38_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_39_ta_ph);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_17));
bevt_42_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_43_ta_ph);
bevt_41_ta_ph = beva_value.bem_and_1(bevt_42_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_3_MathInt(12));
bevt_40_ta_ph = bevt_41_ta_ph.bem_shiftRight_1(bevt_44_ta_ph);
bevt_37_ta_ph = bevt_38_ta_ph.bem_add_1(bevt_40_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_37_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_45_ta_ph = bevl_sizeNow.bem_add_1(bevt_46_ta_ph);
bevt_49_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_48_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_49_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_18));
bevt_52_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_53_ta_ph);
bevt_51_ta_ph = beva_value.bem_and_1(bevt_52_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_50_ta_ph = bevt_51_ta_ph.bem_shiftRight_1(bevt_54_ta_ph);
bevt_47_ta_ph = bevt_48_ta_ph.bem_add_1(bevt_50_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_45_ta_ph, bevt_47_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_55_ta_ph = bevl_sizeNow.bem_add_1(bevt_56_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_58_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_59_ta_ph);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_19));
bevt_61_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_ta_ph);
bevt_60_ta_ph = beva_value.bem_and_1(bevt_61_ta_ph);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevt_60_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_55_ta_ph, bevt_57_ta_ph);
bevl_size = (new BEC_2_4_3_MathInt(3));
} /* Line: 137*/
 else /* Line: 124*/ {
bevt_65_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_20));
bevt_64_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_ta_ph);
if (beva_value.bevi_int <= bevt_64_ta_ph.bevi_int) {
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 138*/ {
bevt_68_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_21));
bevt_67_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_ta_ph);
bevt_72_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_22));
bevt_71_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_72_ta_ph);
bevt_70_ta_ph = beva_value.bem_and_1(bevt_71_ta_ph);
bevt_73_ta_ph = (new BEC_2_4_3_MathInt(18));
bevt_69_ta_ph = bevt_70_ta_ph.bem_shiftRight_1(bevt_73_ta_ph);
bevt_66_ta_ph = bevt_67_ta_ph.bem_add_1(bevt_69_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_66_ta_ph);
bevt_75_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_74_ta_ph = bevl_sizeNow.bem_add_1(bevt_75_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_77_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_78_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_23));
bevt_81_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_82_ta_ph);
bevt_80_ta_ph = beva_value.bem_and_1(bevt_81_ta_ph);
bevt_83_ta_ph = (new BEC_2_4_3_MathInt(12));
bevt_79_ta_ph = bevt_80_ta_ph.bem_shiftRight_1(bevt_83_ta_ph);
bevt_76_ta_ph = bevt_77_ta_ph.bem_add_1(bevt_79_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_74_ta_ph, bevt_76_ta_ph);
bevt_85_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_84_ta_ph = bevl_sizeNow.bem_add_1(bevt_85_ta_ph);
bevt_88_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_87_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_88_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_24));
bevt_91_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_92_ta_ph);
bevt_90_ta_ph = beva_value.bem_and_1(bevt_91_ta_ph);
bevt_93_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_89_ta_ph = bevt_90_ta_ph.bem_shiftRight_1(bevt_93_ta_ph);
bevt_86_ta_ph = bevt_87_ta_ph.bem_add_1(bevt_89_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_84_ta_ph, bevt_86_ta_ph);
bevt_95_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_94_ta_ph = bevl_sizeNow.bem_add_1(bevt_95_ta_ph);
bevt_98_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_97_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_98_ta_ph);
bevt_101_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_25));
bevt_100_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_101_ta_ph);
bevt_99_ta_ph = beva_value.bem_and_1(bevt_100_ta_ph);
bevt_96_ta_ph = bevt_97_ta_ph.bem_add_1(bevt_99_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_94_ta_ph, bevt_96_ta_ph);
bevl_size = (new BEC_2_4_3_MathInt(4));
} /* Line: 143*/
 else /* Line: 144*/ {
bevl_size = (new BEC_2_4_3_MathInt(-1));
} /* Line: 145*/
} /* Line: 124*/
} /* Line: 124*/
} /* Line: 124*/
} /* Line: 124*/
bevt_103_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_size.bevi_int < bevt_103_ta_ph.bevi_int) {
bevt_102_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_102_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_102_ta_ph.bevi_bool)/* Line: 148*/ {
bevt_105_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_4_6_JsonParser_bels_26));
bevt_104_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_105_ta_ph);
throw new be.BECS_ThrowBack(bevt_104_ta_ph);
} /* Line: 149*/
bevt_107_ta_ph = beva_accum.bem_sizeGet_0();
bevt_106_ta_ph = bevt_107_ta_ph.bem_add_1(bevl_size);
beva_accum.bem_sizeSet_1(bevt_106_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parseTokens_2(BEC_2_9_10_ContainerLinkedList beva_toks, BEC_2_6_6_SystemObject beva_handler) throws Throwable {
BEC_2_5_4_LogicBool bevl_inString = null;
BEC_2_5_4_LogicBool bevl_inEscape = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_9_3_ContainerMap bevl_fromEscapes = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_tokIter = null;
BEC_2_4_3_MathInt bevl_heldValue = null;
BEC_2_4_6_TextString bevl_tok = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_6_TextString bevl_remainder = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_4_7_JsonEscapes bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_9_SystemException bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_6_9_SystemException bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
bevl_inString = be.BECS_Runtime.boolFalse;
bevl_inEscape = be.BECS_Runtime.boolFalse;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevl_fromEscapes = bevt_9_ta_ph.bem_fromEscapesGet_0();
bevl_tokIter = beva_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 182*/ {
bevt_10_ta_ph = bevl_tokIter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 182*/ {
bevl_tok = (BEC_2_4_6_TextString) bevl_tokIter.bem_nextGet_0();
if (bevl_inString.bevi_bool)/* Line: 185*/ {
if (bevl_inEscape.bevi_bool) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 186*/ {
bevt_12_ta_ph = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_12_ta_ph.bevi_bool)/* Line: 186*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 186*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 186*/
 else /* Line: 186*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 186*/ {
bevl_inString = be.BECS_Runtime.boolFalse;
bevt_13_ta_ph = bevl_accum.bem_extractString_0();
beva_handler.bemd_1(-52533118, bevt_13_ta_ph);
} /* Line: 188*/
 else /* Line: 189*/ {
if (bevl_inEscape.bevi_bool)/* Line: 190*/ {
bevl_escval = (BEC_2_4_6_TextString) bevl_fromEscapes.bem_get_1(bevl_tok);
if (bevl_escval == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 192*/ {
bevl_accum.bem_addValue_1(bevl_escval);
} /* Line: 193*/
 else /* Line: 192*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_27));
bevt_15_ta_ph = bevl_tok.bem_begins_1(bevt_16_ta_ph);
if (bevt_15_ta_ph.bevi_bool)/* Line: 194*/ {
bevl_value = bem_jsonUcUnescape_1(bevl_tok);
bevl_remainder = bem_jsonUcGetAfterPart_1(bevl_tok);
bevl_isStart = be.BECS_Runtime.boolFalse;
if (bevl_heldValue == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 198*/ {
bevt_19_ta_ph = bem_jsonUcIsPairEnd_1(bevl_value);
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 198*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 198*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 198*/
 else /* Line: 198*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 198*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(62, bece_BEC_2_4_6_JsonParser_bels_28));
bevt_20_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_21_ta_ph);
throw new be.BECS_ThrowBack(bevt_20_ta_ph);
} /* Line: 199*/
 else /* Line: 198*/ {
if (bevl_heldValue == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 200*/ {
bevl_isStart = bem_jsonUcIsPairStart_1(bevl_value);
} /* Line: 201*/
} /* Line: 198*/
if (bevl_isStart.bevi_bool)/* Line: 203*/ {
if (bevl_remainder == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 203*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 203*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 203*/
 else /* Line: 203*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 203*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(73, bece_BEC_2_4_6_JsonParser_bels_29));
bevt_24_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 204*/
if (bevl_isStart.bevi_bool)/* Line: 206*/ {
bevl_heldValue = bevl_value;
} /* Line: 207*/
 else /* Line: 208*/ {
bem_jsonUcAppendValue_3(bevl_heldValue, bevl_value, bevl_accum);
bevl_heldValue = null;
if (bevl_remainder == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 211*/ {
bevl_accum.bem_addValue_1(bevl_remainder);
} /* Line: 212*/
} /* Line: 211*/
} /* Line: 206*/
 else /* Line: 215*/ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 216*/
} /* Line: 192*/
bevl_inEscape = be.BECS_Runtime.boolFalse;
} /* Line: 218*/
 else /* Line: 190*/ {
bevt_27_ta_ph = bevl_tok.bem_equals_1(bevp_escape);
if (bevt_27_ta_ph.bevi_bool)/* Line: 219*/ {
bevl_inEscape = be.BECS_Runtime.boolTrue;
} /* Line: 220*/
 else /* Line: 221*/ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 222*/
} /* Line: 190*/
} /* Line: 190*/
} /* Line: 186*/
 else /* Line: 225*/ {
bevt_28_ta_ph = bevl_tok.bem_equals_1(bevp_space);
if (bevt_28_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_29_ta_ph = bevl_tok.bem_equals_1(bevp_cr);
if (bevt_29_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 227*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 227*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_30_ta_ph = bevl_tok.bem_equals_1(bevp_lf);
if (bevt_30_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 227*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_31_ta_ph = bevl_tok.bem_equals_1(bevp_comma);
if (bevt_31_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 227*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 227*/ {
} /* Line: 227*/
 else /* Line: 227*/ {
bevt_32_ta_ph = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_32_ta_ph.bevi_bool)/* Line: 228*/ {
bevl_inString = be.BECS_Runtime.boolTrue;
} /* Line: 229*/
 else /* Line: 227*/ {
bevt_33_ta_ph = bevl_tok.bem_equals_1(bevp_lbrace);
if (bevt_33_ta_ph.bevi_bool)/* Line: 230*/ {
beva_handler.bemd_0(1457491037);
} /* Line: 231*/
 else /* Line: 227*/ {
bevt_34_ta_ph = bevl_tok.bem_equals_1(bevp_rbrace);
if (bevt_34_ta_ph.bevi_bool)/* Line: 232*/ {
beva_handler.bemd_0(432188061);
} /* Line: 233*/
 else /* Line: 227*/ {
bevt_35_ta_ph = bevl_tok.bem_equals_1(bevp_colon);
if (bevt_35_ta_ph.bevi_bool)/* Line: 234*/ {
beva_handler.bemd_0(-36352152);
} /* Line: 235*/
 else /* Line: 227*/ {
bevt_36_ta_ph = bevl_tok.bem_equals_1(bevp_lbracket);
if (bevt_36_ta_ph.bevi_bool)/* Line: 236*/ {
beva_handler.bemd_0(-1598536093);
} /* Line: 237*/
 else /* Line: 227*/ {
bevt_37_ta_ph = bevl_tok.bem_equals_1(bevp_rbracket);
if (bevt_37_ta_ph.bevi_bool)/* Line: 238*/ {
beva_handler.bemd_0(-246249201);
} /* Line: 239*/
 else /* Line: 240*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_30));
bevt_38_ta_ph = bevl_tok.bem_equals_1(bevt_39_ta_ph);
if (bevt_38_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_31));
bevt_40_ta_ph = bevl_tok.bem_equals_1(bevt_41_ta_ph);
if (bevt_40_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 243*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 243*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_43_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_32));
bevt_42_ta_ph = bevl_tok.bem_equals_1(bevt_43_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 243*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 243*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_33));
bevt_44_ta_ph = bevl_tok.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 243*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 243*/ {
} /* Line: 243*/
 else /* Line: 243*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_34));
bevt_46_ta_ph = bevl_tok.bem_equals_1(bevt_47_ta_ph);
if (bevt_46_ta_ph.bevi_bool)/* Line: 246*/ {
beva_handler.bemd_0(-912002028);
} /* Line: 247*/
 else /* Line: 243*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_35));
bevt_48_ta_ph = bevl_tok.bem_equals_1(bevt_49_ta_ph);
if (bevt_48_ta_ph.bevi_bool)/* Line: 248*/ {
beva_handler.bemd_0(1407948392);
} /* Line: 249*/
 else /* Line: 243*/ {
bevt_51_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_36));
bevt_50_ta_ph = bevl_tok.bem_equals_1(bevt_51_ta_ph);
if (bevt_50_ta_ph.bevi_bool)/* Line: 250*/ {
beva_handler.bemd_0(-238469334);
} /* Line: 251*/
 else /* Line: 252*/ {
bevt_52_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_tok);
beva_handler.bemd_1(-1709734383, bevt_52_ta_ph);
} /* Line: 254*/
} /* Line: 243*/
} /* Line: 243*/
} /* Line: 243*/
} /* Line: 243*/
} /* Line: 227*/
} /* Line: 227*/
} /* Line: 227*/
} /* Line: 227*/
} /* Line: 227*/
} /* Line: 227*/
} /* Line: 227*/
} /* Line: 185*/
 else /* Line: 182*/ {
break;
} /* Line: 182*/
} /* Line: 182*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_JsonParser bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbraceGet_0() throws Throwable {
return bevp_lbrace;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_rbraceGet_0() throws Throwable {
return bevp_rbrace;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbracketGet_0() throws Throwable {
return bevp_lbracket;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbracketSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_rbracketGet_0() throws Throwable {
return bevp_rbracket;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbracketSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_6_JsonParser bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_JsonParser bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_escapeGet_0() throws Throwable {
return bevp_escape;
} /*method end*/
public BEC_2_4_6_JsonParser bem_escapeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_JsonParser bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commaGet_0() throws Throwable {
return bevp_comma;
} /*method end*/
public BEC_2_4_6_JsonParser bem_commaSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tokensGet_0() throws Throwable {
return bevp_tokens;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokensSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() throws Throwable {
return bevp_toker;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hsubGet_0() throws Throwable {
return bevp_hsub;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hsubSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vsubGet_0() throws Throwable {
return bevp_vsub;
} /*method end*/
public BEC_2_4_6_JsonParser bem_vsubSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmAddGet_0() throws Throwable {
return bevp_hmAdd;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hmAddSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {42, 42, 43, 44, 45, 46, 47, 47, 48, 48, 49, 50, 50, 51, 51, 52, 53, 53, 53, 53, 53, 53, 53, 53, 53, 53, 53, 53, 54, 54, 55, 55, 56, 56, 57, 57, 63, 63, 68, 68, 68, 68, 68, 68, 0, 0, 0, 69, 71, 73, 79, 79, 79, 79, 79, 79, 0, 0, 0, 80, 82, 84, 89, 89, 89, 89, 90, 92, 92, 92, 96, 96, 96, 96, 97, 97, 97, 99, 99, 99, 99, 104, 104, 104, 104, 104, 104, 105, 105, 105, 105, 107, 110, 110, 112, 113, 114, 114, 115, 116, 117, 118, 124, 124, 124, 125, 126, 126, 126, 126, 127, 128, 129, 129, 129, 129, 130, 130, 130, 130, 130, 130, 130, 130, 130, 131, 131, 131, 131, 131, 131, 131, 131, 131, 132, 133, 133, 133, 133, 134, 134, 134, 134, 134, 134, 134, 134, 134, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 136, 136, 136, 136, 136, 136, 136, 136, 136, 137, 138, 138, 138, 138, 139, 139, 139, 139, 139, 139, 139, 139, 139, 140, 140, 140, 140, 140, 140, 140, 140, 140, 140, 140, 141, 141, 141, 141, 141, 141, 141, 141, 141, 141, 141, 142, 142, 142, 142, 142, 142, 142, 142, 142, 143, 145, 148, 148, 148, 149, 149, 149, 151, 151, 151, 172, 173, 174, 176, 176, 178, 182, 183, 186, 186, 186, 0, 0, 0, 187, 188, 188, 191, 192, 192, 193, 194, 194, 195, 196, 197, 198, 198, 198, 198, 198, 0, 0, 0, 199, 199, 199, 200, 200, 201, 203, 203, 0, 0, 0, 204, 204, 204, 207, 209, 210, 211, 211, 212, 216, 218, 219, 220, 222, 227, 0, 227, 0, 0, 0, 227, 0, 0, 0, 227, 0, 0, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 243, 243, 0, 243, 243, 0, 0, 0, 243, 243, 0, 0, 0, 243, 243, 0, 0, 246, 246, 247, 248, 248, 249, 250, 250, 251, 254, 254, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 125, 126, 136, 137, 142, 143, 144, 149, 150, 153, 157, 160, 163, 165, 174, 175, 180, 181, 182, 187, 188, 191, 195, 198, 201, 203, 211, 212, 213, 218, 219, 221, 222, 223, 234, 235, 236, 241, 242, 243, 244, 246, 247, 248, 249, 363, 364, 365, 366, 367, 372, 373, 374, 375, 376, 378, 379, 384, 385, 386, 387, 388, 389, 390, 391, 392, 394, 395, 400, 401, 404, 405, 406, 411, 412, 413, 416, 417, 418, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 445, 446, 447, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 485, 486, 487, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 536, 542, 543, 548, 549, 550, 551, 553, 554, 555, 623, 624, 625, 626, 627, 628, 631, 633, 635, 640, 641, 643, 646, 650, 653, 654, 655, 659, 660, 665, 666, 669, 670, 672, 673, 674, 675, 680, 681, 682, 687, 688, 691, 695, 698, 699, 700, 703, 708, 709, 713, 718, 719, 722, 726, 729, 730, 731, 734, 737, 738, 739, 744, 745, 750, 753, 756, 758, 761, 767, 769, 772, 774, 777, 781, 784, 786, 789, 793, 796, 798, 801, 807, 809, 812, 814, 817, 819, 822, 824, 827, 829, 832, 834, 837, 838, 840, 843, 844, 846, 849, 853, 856, 857, 859, 862, 866, 869, 870, 872, 875, 881, 882, 884, 887, 888, 890, 893, 894, 896, 899, 900, 921, 924, 928, 931, 935, 938, 942, 945, 949, 952, 956, 959, 963, 966, 970, 973, 977, 980, 984, 987, 991, 994, 998, 1001, 1005, 1008, 1012, 1015, 1019, 1022, 1026, 1029};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 42 85
new 0 42 85
assign 1 42 86
quoteGet 0 42 86
assign 1 43 87
new 0 43 87
assign 1 44 88
new 0 44 88
assign 1 45 89
new 0 45 89
assign 1 46 90
new 0 46 90
assign 1 47 91
new 0 47 91
assign 1 47 92
spaceGet 0 47 92
assign 1 48 93
new 0 48 93
assign 1 48 94
colonGet 0 48 94
assign 1 49 95
new 0 49 95
assign 1 50 96
new 0 50 96
assign 1 50 97
crGet 0 50 97
assign 1 51 98
new 0 51 98
assign 1 51 99
lfGet 0 51 99
assign 1 52 100
new 0 52 100
assign 1 53 101
add 1 53 101
assign 1 53 102
add 1 53 102
assign 1 53 103
add 1 53 103
assign 1 53 104
add 1 53 104
assign 1 53 105
add 1 53 105
assign 1 53 106
add 1 53 106
assign 1 53 107
add 1 53 107
assign 1 53 108
add 1 53 108
assign 1 53 109
add 1 53 109
assign 1 53 110
add 1 53 110
assign 1 53 111
new 0 53 111
assign 1 53 112
add 1 53 112
assign 1 54 113
new 0 54 113
assign 1 54 114
new 2 54 114
assign 1 55 115
new 0 55 115
assign 1 55 116
hexNew 1 55 116
assign 1 56 117
new 0 56 117
assign 1 56 118
hexNew 1 56 118
assign 1 57 119
new 0 57 119
assign 1 57 120
hexNew 1 57 120
assign 1 63 125
tokenize 1 63 125
parseTokens 2 63 126
assign 1 68 136
new 0 68 136
assign 1 68 137
lesserEquals 1 68 142
assign 1 68 143
new 0 68 143
assign 1 68 144
lesserEquals 1 68 149
assign 1 0 150
assign 1 0 153
assign 1 0 157
assign 1 69 160
new 0 69 160
assign 1 71 163
new 0 71 163
return 1 73 165
assign 1 79 174
new 0 79 174
assign 1 79 175
lesserEquals 1 79 180
assign 1 79 181
new 0 79 181
assign 1 79 182
lesserEquals 1 79 187
assign 1 0 188
assign 1 0 191
assign 1 0 195
assign 1 80 198
new 0 80 198
assign 1 82 201
new 0 82 201
return 1 84 203
assign 1 89 211
sizeGet 0 89 211
assign 1 89 212
new 0 89 212
assign 1 89 213
lesser 1 89 218
return 1 90 219
assign 1 92 221
new 0 92 221
assign 1 92 222
substring 1 92 222
return 1 92 223
assign 1 96 234
sizeGet 0 96 234
assign 1 96 235
new 0 96 235
assign 1 96 236
lesser 1 96 241
assign 1 97 242
new 0 97 242
assign 1 97 243
new 1 97 243
throw 1 97 244
assign 1 99 246
new 0 99 246
assign 1 99 247
substring 1 99 247
assign 1 99 248
hexNew 1 99 248
return 1 99 249
assign 1 104 363
capacityGet 0 104 363
assign 1 104 364
sizeGet 0 104 364
assign 1 104 365
subtract 1 104 365
assign 1 104 366
new 0 104 366
assign 1 104 367
lesser 1 104 372
assign 1 105 373
sizeGet 0 105 373
assign 1 105 374
new 0 105 374
assign 1 105 375
add 1 105 375
capacitySet 1 105 376
assign 1 107 378
sizeGet 0 107 378
assign 1 110 379
def 1 110 384
assign 1 112 385
subtractValue 1 113 386
assign 1 114 387
new 0 114 387
shiftLeftValue 1 114 388
subtractValue 1 115 389
addValue 1 116 390
addValue 1 117 391
assign 1 118 392
assign 1 124 394
new 0 124 394
assign 1 124 395
lesser 1 124 400
assign 1 125 401
new 0 125 401
assign 1 126 404
new 0 126 404
assign 1 126 405
hexNew 1 126 405
assign 1 126 406
lesser 1 126 411
setIntUnchecked 2 127 412
assign 1 128 413
new 0 128 413
assign 1 129 416
new 0 129 416
assign 1 129 417
hexNew 1 129 417
assign 1 129 418
lesser 1 129 423
assign 1 130 424
new 0 130 424
assign 1 130 425
hexNew 1 130 425
assign 1 130 426
new 0 130 426
assign 1 130 427
hexNew 1 130 427
assign 1 130 428
and 1 130 428
assign 1 130 429
new 0 130 429
assign 1 130 430
shiftRight 1 130 430
assign 1 130 431
add 1 130 431
setIntUnchecked 2 130 432
assign 1 131 433
new 0 131 433
assign 1 131 434
add 1 131 434
assign 1 131 435
new 0 131 435
assign 1 131 436
hexNew 1 131 436
assign 1 131 437
new 0 131 437
assign 1 131 438
hexNew 1 131 438
assign 1 131 439
and 1 131 439
assign 1 131 440
add 1 131 440
setIntUnchecked 2 131 441
assign 1 132 442
new 0 132 442
assign 1 133 445
new 0 133 445
assign 1 133 446
hexNew 1 133 446
assign 1 133 447
lesser 1 133 452
assign 1 134 453
new 0 134 453
assign 1 134 454
hexNew 1 134 454
assign 1 134 455
new 0 134 455
assign 1 134 456
hexNew 1 134 456
assign 1 134 457
and 1 134 457
assign 1 134 458
new 0 134 458
assign 1 134 459
shiftRight 1 134 459
assign 1 134 460
add 1 134 460
setIntUnchecked 2 134 461
assign 1 135 462
new 0 135 462
assign 1 135 463
add 1 135 463
assign 1 135 464
new 0 135 464
assign 1 135 465
hexNew 1 135 465
assign 1 135 466
new 0 135 466
assign 1 135 467
hexNew 1 135 467
assign 1 135 468
and 1 135 468
assign 1 135 469
new 0 135 469
assign 1 135 470
shiftRight 1 135 470
assign 1 135 471
add 1 135 471
setIntUnchecked 2 135 472
assign 1 136 473
new 0 136 473
assign 1 136 474
add 1 136 474
assign 1 136 475
new 0 136 475
assign 1 136 476
hexNew 1 136 476
assign 1 136 477
new 0 136 477
assign 1 136 478
hexNew 1 136 478
assign 1 136 479
and 1 136 479
assign 1 136 480
add 1 136 480
setIntUnchecked 2 136 481
assign 1 137 482
new 0 137 482
assign 1 138 485
new 0 138 485
assign 1 138 486
hexNew 1 138 486
assign 1 138 487
lesserEquals 1 138 492
assign 1 139 493
new 0 139 493
assign 1 139 494
hexNew 1 139 494
assign 1 139 495
new 0 139 495
assign 1 139 496
hexNew 1 139 496
assign 1 139 497
and 1 139 497
assign 1 139 498
new 0 139 498
assign 1 139 499
shiftRight 1 139 499
assign 1 139 500
add 1 139 500
setIntUnchecked 2 139 501
assign 1 140 502
new 0 140 502
assign 1 140 503
add 1 140 503
assign 1 140 504
new 0 140 504
assign 1 140 505
hexNew 1 140 505
assign 1 140 506
new 0 140 506
assign 1 140 507
hexNew 1 140 507
assign 1 140 508
and 1 140 508
assign 1 140 509
new 0 140 509
assign 1 140 510
shiftRight 1 140 510
assign 1 140 511
add 1 140 511
setIntUnchecked 2 140 512
assign 1 141 513
new 0 141 513
assign 1 141 514
add 1 141 514
assign 1 141 515
new 0 141 515
assign 1 141 516
hexNew 1 141 516
assign 1 141 517
new 0 141 517
assign 1 141 518
hexNew 1 141 518
assign 1 141 519
and 1 141 519
assign 1 141 520
new 0 141 520
assign 1 141 521
shiftRight 1 141 521
assign 1 141 522
add 1 141 522
setIntUnchecked 2 141 523
assign 1 142 524
new 0 142 524
assign 1 142 525
add 1 142 525
assign 1 142 526
new 0 142 526
assign 1 142 527
hexNew 1 142 527
assign 1 142 528
new 0 142 528
assign 1 142 529
hexNew 1 142 529
assign 1 142 530
and 1 142 530
assign 1 142 531
add 1 142 531
setIntUnchecked 2 142 532
assign 1 143 533
new 0 143 533
assign 1 145 536
new 0 145 536
assign 1 148 542
new 0 148 542
assign 1 148 543
lesser 1 148 548
assign 1 149 549
new 0 149 549
assign 1 149 550
new 1 149 550
throw 1 149 551
assign 1 151 553
sizeGet 0 151 553
assign 1 151 554
add 1 151 554
sizeSet 1 151 555
assign 1 172 623
new 0 172 623
assign 1 173 624
new 0 173 624
assign 1 174 625
new 0 174 625
assign 1 176 626
new 0 176 626
assign 1 176 627
fromEscapesGet 0 176 627
assign 1 178 628
linkedListIteratorGet 0 178 628
assign 1 182 631
hasNextGet 0 182 631
assign 1 183 633
nextGet 0 183 633
assign 1 186 635
not 0 186 640
assign 1 186 641
equals 1 186 641
assign 1 0 643
assign 1 0 646
assign 1 0 650
assign 1 187 653
new 0 187 653
assign 1 188 654
extractString 0 188 654
handleString 1 188 655
assign 1 191 659
get 1 191 659
assign 1 192 660
def 1 192 665
addValue 1 193 666
assign 1 194 669
new 0 194 669
assign 1 194 670
begins 1 194 670
assign 1 195 672
jsonUcUnescape 1 195 672
assign 1 196 673
jsonUcGetAfterPart 1 196 673
assign 1 197 674
new 0 197 674
assign 1 198 675
def 1 198 680
assign 1 198 681
jsonUcIsPairEnd 1 198 681
assign 1 198 682
not 0 198 687
assign 1 0 688
assign 1 0 691
assign 1 0 695
assign 1 199 698
new 0 199 698
assign 1 199 699
new 1 199 699
throw 1 199 700
assign 1 200 703
undef 1 200 708
assign 1 201 709
jsonUcIsPairStart 1 201 709
assign 1 203 713
def 1 203 718
assign 1 0 719
assign 1 0 722
assign 1 0 726
assign 1 204 729
new 0 204 729
assign 1 204 730
new 1 204 730
throw 1 204 731
assign 1 207 734
jsonUcAppendValue 3 209 737
assign 1 210 738
assign 1 211 739
def 1 211 744
addValue 1 212 745
addValue 1 216 750
assign 1 218 753
new 0 218 753
assign 1 219 756
equals 1 219 756
assign 1 220 758
new 0 220 758
addValue 1 222 761
assign 1 227 767
equals 1 227 767
assign 1 0 769
assign 1 227 772
equals 1 227 772
assign 1 0 774
assign 1 0 777
assign 1 0 781
assign 1 227 784
equals 1 227 784
assign 1 0 786
assign 1 0 789
assign 1 0 793
assign 1 227 796
equals 1 227 796
assign 1 0 798
assign 1 0 801
assign 1 228 807
equals 1 228 807
assign 1 229 809
new 0 229 809
assign 1 230 812
equals 1 230 812
beginMap 0 231 814
assign 1 232 817
equals 1 232 817
endMap 0 233 819
assign 1 234 822
equals 1 234 822
kvMid 0 235 824
assign 1 236 827
equals 1 236 827
beginList 0 237 829
assign 1 238 832
equals 1 238 832
endList 0 239 834
assign 1 243 837
new 0 243 837
assign 1 243 838
equals 1 243 838
assign 1 0 840
assign 1 243 843
new 0 243 843
assign 1 243 844
equals 1 243 844
assign 1 0 846
assign 1 0 849
assign 1 0 853
assign 1 243 856
new 0 243 856
assign 1 243 857
equals 1 243 857
assign 1 0 859
assign 1 0 862
assign 1 0 866
assign 1 243 869
new 0 243 869
assign 1 243 870
equals 1 243 870
assign 1 0 872
assign 1 0 875
assign 1 246 881
new 0 246 881
assign 1 246 882
equals 1 246 882
handleTrue 0 247 884
assign 1 248 887
new 0 248 887
assign 1 248 888
equals 1 248 888
handleFalse 0 249 890
assign 1 250 893
new 0 250 893
assign 1 250 894
equals 1 250 894
handleNull 0 251 896
assign 1 254 899
new 1 254 899
handleInteger 1 254 900
return 1 0 921
assign 1 0 924
return 1 0 928
assign 1 0 931
return 1 0 935
assign 1 0 938
return 1 0 942
assign 1 0 945
return 1 0 949
assign 1 0 952
return 1 0 956
assign 1 0 959
return 1 0 963
assign 1 0 966
return 1 0 970
assign 1 0 973
return 1 0 977
assign 1 0 980
return 1 0 984
assign 1 0 987
return 1 0 991
assign 1 0 994
return 1 0 998
assign 1 0 1001
return 1 0 1005
assign 1 0 1008
return 1 0 1012
assign 1 0 1015
return 1 0 1019
assign 1 0 1022
return 1 0 1026
assign 1 0 1029
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1843092295: return bem_rbracketGet_0();
case -1182108874: return bem_create_0();
case 1818335248: return bem_toString_0();
case 84237329: return bem_hashGet_0();
case -301511251: return bem_quoteGet_0();
case 37644021: return bem_rbraceGet_0();
case 890769141: return bem_lfGet_0();
case -1854351103: return bem_print_0();
case 2076437605: return bem_lbraceGet_0();
case 1860692295: return bem_hmAddGet_0();
case -1800509135: return bem_escapeGet_0();
case -906665424: return bem_tokensGet_0();
case -76983889: return bem_colonGet_0();
case 1207968914: return bem_crGet_0();
case 2063858269: return bem_spaceGet_0();
case 1704927424: return bem_new_0();
case -1574625186: return bem_lbracketGet_0();
case -534337315: return bem_commaGet_0();
case 1243487119: return bem_tokerGet_0();
case 1145598418: return bem_copy_0();
case 764459509: return bem_iteratorGet_0();
case -1488184981: return bem_vsubGet_0();
case 511985084: return bem_hsubGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 9189358: return bem_rbraceSet_1(bevd_0);
case 854124491: return bem_print_1(bevd_0);
case -237508565: return bem_lbracketSet_1(bevd_0);
case 1782625331: return bem_notEquals_1(bevd_0);
case -388719027: return bem_lfSet_1(bevd_0);
case 1725112909: return bem_commaSet_1(bevd_0);
case -2038919763: return bem_rbracketSet_1(bevd_0);
case 775180462: return bem_def_1(bevd_0);
case 1697701048: return bem_equals_1(bevd_0);
case -646925145: return bem_jsonUcGetAfterPart_1((BEC_2_4_6_TextString) bevd_0);
case 1362044489: return bem_colonSet_1(bevd_0);
case -170273195: return bem_quoteSet_1(bevd_0);
case -2322993: return bem_spaceSet_1(bevd_0);
case -856346305: return bem_jsonUcIsPairStart_1((BEC_2_4_3_MathInt) bevd_0);
case -2015836126: return bem_escapeSet_1(bevd_0);
case 710391252: return bem_tokerSet_1(bevd_0);
case -881118035: return bem_vsubSet_1(bevd_0);
case -1162579478: return bem_jsonUcUnescape_1((BEC_2_4_6_TextString) bevd_0);
case 1780152727: return bem_undef_1(bevd_0);
case 1270438115: return bem_crSet_1(bevd_0);
case -326403545: return bem_lbraceSet_1(bevd_0);
case -1601489182: return bem_copyTo_1(bevd_0);
case -1420270508: return bem_hsubSet_1(bevd_0);
case 994787074: return bem_hmAddSet_1(bevd_0);
case 1162707558: return bem_jsonUcIsPairEnd_1((BEC_2_4_3_MathInt) bevd_0);
case 1330543399: return bem_tokensSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1638131121: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1986773680: return bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevd_0, bevd_1);
case 294957256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 91726751: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -500575377: return bem_parse_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -997677553: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1342578725: return bem_jsonUcAppendValue_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_JsonParser_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_6_JsonParser_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_JsonParser();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst = (BEC_2_4_6_JsonParser) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_type;
}
}
