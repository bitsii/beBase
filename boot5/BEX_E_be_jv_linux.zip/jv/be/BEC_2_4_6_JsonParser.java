package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_6_JsonParser extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_JsonParser() { }
private static byte[] becc_BEC_2_4_6_JsonParser_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x72};
private static byte[] becc_BEC_2_4_6_JsonParser_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_0 = {0x7B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_1 = {0x7D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_2 = {0x5B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_3 = {0x5D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_4 = {0x5C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_5 = {0x2C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_6 = {0x62,0x66,0x6E,0x72,0x74,0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_6, 6));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_8 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_9 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_1 = (new BEC_2_4_3_MathInt(55296));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_2 = (new BEC_2_4_3_MathInt(56319));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_3 = (new BEC_2_4_3_MathInt(56320));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_4 = (new BEC_2_4_3_MathInt(57343));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_5 = (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_6 = (new BEC_2_4_3_MathInt(5));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_10 = {0x74,0x6F,0x6B,0x20,0x74,0x6F,0x6F,0x20,0x73,0x6D,0x61,0x6C,0x6C};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_7 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_8 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_11 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_12 = {0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_13 = {0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_14 = {0x37,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_15 = {0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_16 = {0x45,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_17 = {0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_18 = {0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_12 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_19 = {0x30,0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_20 = {0x31,0x30,0x46,0x46,0x46,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_21 = {0x46,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_22 = {0x31,0x43,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_23 = {0x30,0x33,0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_24 = {0x30,0x30,0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_15 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_25 = {0x30,0x30,0x30,0x30,0x33,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_26 = {0x66,0x61,0x69,0x6C,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x74,0x6F,0x20,0x62,0x75,0x66,0x66,0x65,0x72,0x20,0x63,0x6F,0x6E,0x76,0x65,0x72,0x74};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_27 = {0x75};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_27, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_28 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x69,0x73,0x20,0x69,0x6E,0x76,0x61,0x6C,0x69,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_29 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x65,0x64,0x20,0x62,0x79,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_30 = {0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_30, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_31 = {0x72};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_31, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_32 = {0x66};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_32, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_33 = {0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_33, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_34 = {0x75,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_34, 2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_35 = {0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_35, 4));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_36 = {0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_36, 3));
public static BEC_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_inst;

public static BET_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_type;

public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_lbrace;
public BEC_2_4_6_TextString bevp_rbrace;
public BEC_2_4_6_TextString bevp_lbracket;
public BEC_2_4_6_TextString bevp_rbracket;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_6_TextString bevp_escape;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_comma;
public BEC_2_4_6_TextString bevp_tokens;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_4_3_MathInt bevp_hsub;
public BEC_2_4_3_MathInt bevp_vsub;
public BEC_2_4_3_MathInt bevp_hmAdd;
public BEC_2_4_6_JsonParser bem_new_0() throws Throwable {
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_quote = bevt_0_tmpany_phold.bem_quoteGet_0();
bevp_lbrace = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_0));
bevp_rbrace = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_1));
bevp_lbracket = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_2));
bevp_rbracket = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_3));
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_space = bevt_1_tmpany_phold.bem_spaceGet_0();
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_colon = bevt_2_tmpany_phold.bem_colonGet_0();
bevp_escape = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_4));
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_cr = bevt_3_tmpany_phold.bem_crGet_0();
bevt_4_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_lf = bevt_4_tmpany_phold.bem_lfGet_0();
bevp_comma = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_5));
bevt_14_tmpany_phold = bevp_quote.bem_add_1(bevp_lbrace);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevp_rbrace);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_lbracket);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevp_rbracket);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevp_space);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_colon);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevp_escape);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevp_cr);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_lf);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevp_comma);
bevt_15_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_0;
bevp_tokens = bevt_5_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_toker = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevp_tokens, bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_7));
bevp_hsub = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_8));
bevp_vsub = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevp_hmAdd = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_19_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parse_2(BEC_2_4_6_TextString beva_str, BEC_2_6_6_SystemObject beva_handler) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_toker.bem_tokenize_1(beva_str);
bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold , beva_handler);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_jsonUcIsPairStart_1(BEC_2_4_3_MathInt beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_1;
if (bevt_2_tmpany_phold.bevi_int <= beva_value.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 62 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_2;
if (beva_value.bevi_int <= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 62 */
 else  /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 62 */ {
bevl_result = be.BECS_Runtime.boolTrue;
} /* Line: 63 */
 else  /* Line: 64 */ {
bevl_result = be.BECS_Runtime.boolFalse;
} /* Line: 65 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_jsonUcIsPairEnd_1(BEC_2_4_3_MathInt beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_3;
if (bevt_2_tmpany_phold.bevi_int <= beva_value.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_4;
if (beva_value.bevi_int <= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 73 */ {
bevl_result = be.BECS_Runtime.boolTrue;
} /* Line: 74 */
 else  /* Line: 75 */ {
bevl_result = be.BECS_Runtime.boolFalse;
} /* Line: 76 */
return bevl_result;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonUcGetAfterPart_1(BEC_2_4_6_TextString beva_tok) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_5;
if (bevt_1_tmpany_phold.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {
return null;
} /* Line: 84 */
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevt_3_tmpany_phold = beva_tok.bem_substring_1(bevt_4_tmpany_phold);
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_jsonUcUnescape_1(BEC_2_4_6_TextString beva_tok) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_6;
if (bevt_1_tmpany_phold.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 90 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_6_JsonParser_bels_10));
bevt_3_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 91 */
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_6_tmpany_phold = beva_tok.bem_substring_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_6_tmpany_phold);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_JsonParser bem_jsonUcAppendValue_3(BEC_2_4_3_MathInt beva_heldValue, BEC_2_4_3_MathInt beva_value, BEC_2_4_6_TextString beva_accum) throws Throwable {
BEC_2_4_3_MathInt bevl_sizeNow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_heldm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
bevt_2_tmpany_phold = beva_accum.bem_capacityGet_0();
bevt_3_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_subtract_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_7;
if (bevt_1_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_6_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_7_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_8;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
beva_accum.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 99 */
bevl_sizeNow = beva_accum.bem_sizeGet_0();
if (beva_heldValue == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevl_heldm = beva_heldValue;
bevl_heldm.bem_subtractValue_1(bevp_hsub);
bevt_9_tmpany_phold = (new BEC_2_4_3_MathInt(10));
bevl_heldm.bem_shiftLeftValue_1(bevt_9_tmpany_phold);
bevl_heldm.bem_subtractValue_1(bevp_vsub);
bevl_heldm.bevi_int += beva_value.bevi_int;
bevl_heldm.bevi_int += bevp_hmAdd.bevi_int;
beva_value = bevl_heldm;
} /* Line: 112 */
bevt_11_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_9;
if (beva_value.bevi_int < bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevl_size = (new BEC_2_4_3_MathInt(-1));
} /* Line: 119 */
 else  /* Line: 118 */ {
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_13_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_14_tmpany_phold);
if (beva_value.bevi_int < bevt_13_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 120 */ {
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, beva_value);
bevl_size = (new BEC_2_4_3_MathInt(1));
} /* Line: 122 */
 else  /* Line: 118 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_12));
bevt_16_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpany_phold);
if (beva_value.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_13));
bevt_19_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_20_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_14));
bevt_23_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_24_tmpany_phold);
bevt_22_tmpany_phold = beva_value.bem_and_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_shiftRight_1(bevt_25_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_18_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_10;
bevt_26_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_29_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_30_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_15));
bevt_32_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_33_tmpany_phold);
bevt_31_tmpany_phold = beva_value.bem_and_1(bevt_32_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_28_tmpany_phold);
bevl_size = (new BEC_2_4_3_MathInt(2));
} /* Line: 126 */
 else  /* Line: 118 */ {
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevt_35_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_36_tmpany_phold);
if (beva_value.bevi_int < bevt_35_tmpany_phold.bevi_int) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_16));
bevt_38_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_39_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_17));
bevt_42_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_43_tmpany_phold);
bevt_41_tmpany_phold = beva_value.bem_and_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_3_MathInt(12));
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_shiftRight_1(bevt_44_tmpany_phold);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_37_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_11;
bevt_45_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_46_tmpany_phold);
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_48_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_18));
bevt_52_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_53_tmpany_phold);
bevt_51_tmpany_phold = beva_value.bem_and_1(bevt_52_tmpany_phold);
bevt_54_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_shiftRight_1(bevt_54_tmpany_phold);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_50_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_45_tmpany_phold, bevt_47_tmpany_phold);
bevt_56_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_12;
bevt_55_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_56_tmpany_phold);
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_58_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_59_tmpany_phold);
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_19));
bevt_61_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_tmpany_phold);
bevt_60_tmpany_phold = beva_value.bem_and_1(bevt_61_tmpany_phold);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevt_60_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_55_tmpany_phold, bevt_57_tmpany_phold);
bevl_size = (new BEC_2_4_3_MathInt(3));
} /* Line: 131 */
 else  /* Line: 118 */ {
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_20));
bevt_64_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_tmpany_phold);
if (beva_value.bevi_int <= bevt_64_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_68_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_21));
bevt_67_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_tmpany_phold);
bevt_72_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_22));
bevt_71_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_72_tmpany_phold);
bevt_70_tmpany_phold = beva_value.bem_and_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_4_3_MathInt(18));
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_shiftRight_1(bevt_73_tmpany_phold);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_add_1(bevt_69_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_66_tmpany_phold);
bevt_75_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_13;
bevt_74_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_75_tmpany_phold);
bevt_78_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_77_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_78_tmpany_phold);
bevt_82_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_23));
bevt_81_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_82_tmpany_phold);
bevt_80_tmpany_phold = beva_value.bem_and_1(bevt_81_tmpany_phold);
bevt_83_tmpany_phold = (new BEC_2_4_3_MathInt(12));
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_shiftRight_1(bevt_83_tmpany_phold);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bem_add_1(bevt_79_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_74_tmpany_phold, bevt_76_tmpany_phold);
bevt_85_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_14;
bevt_84_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_85_tmpany_phold);
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_87_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_88_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_24));
bevt_91_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_92_tmpany_phold);
bevt_90_tmpany_phold = beva_value.bem_and_1(bevt_91_tmpany_phold);
bevt_93_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bem_shiftRight_1(bevt_93_tmpany_phold);
bevt_86_tmpany_phold = bevt_87_tmpany_phold.bem_add_1(bevt_89_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_84_tmpany_phold, bevt_86_tmpany_phold);
bevt_95_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_15;
bevt_94_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_95_tmpany_phold);
bevt_98_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_97_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_98_tmpany_phold);
bevt_101_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_25));
bevt_100_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_101_tmpany_phold);
bevt_99_tmpany_phold = beva_value.bem_and_1(bevt_100_tmpany_phold);
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_add_1(bevt_99_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_94_tmpany_phold, bevt_96_tmpany_phold);
bevl_size = (new BEC_2_4_3_MathInt(4));
} /* Line: 137 */
 else  /* Line: 138 */ {
bevl_size = (new BEC_2_4_3_MathInt(-1));
} /* Line: 139 */
} /* Line: 118 */
} /* Line: 118 */
} /* Line: 118 */
} /* Line: 118 */
bevt_103_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_16;
if (bevl_size.bevi_int < bevt_103_tmpany_phold.bevi_int) {
bevt_102_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_102_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_102_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_4_6_JsonParser_bels_26));
bevt_104_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_105_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_104_tmpany_phold);
} /* Line: 143 */
bevt_107_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_106_tmpany_phold = bevt_107_tmpany_phold.bem_add_1(bevl_size);
beva_accum.bem_sizeSet_1(bevt_106_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parseTokens_2(BEC_2_9_10_ContainerLinkedList beva_toks, BEC_2_6_6_SystemObject beva_handler) throws Throwable {
BEC_2_5_4_LogicBool bevl_inString = null;
BEC_2_5_4_LogicBool bevl_inEscape = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_9_3_ContainerMap bevl_fromEscapes = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_tokIter = null;
BEC_2_4_3_MathInt bevl_heldValue = null;
BEC_2_4_6_TextString bevl_tok = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_6_TextString bevl_remainder = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_4_7_JsonEscapes bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
bevl_inString = be.BECS_Runtime.boolFalse;
bevl_inEscape = be.BECS_Runtime.boolFalse;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevl_fromEscapes = bevt_9_tmpany_phold.bem_fromEscapesGet_0();
bevl_tokIter = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 176 */ {
bevt_10_tmpany_phold = bevl_tokIter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 176 */ {
bevl_tok = (BEC_2_4_6_TextString) bevl_tokIter.bem_nextGet_0();
if (bevl_inString.bevi_bool) /* Line: 179 */ {
if (bevl_inEscape.bevi_bool) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 180 */ {
bevt_12_tmpany_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 180 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
 else  /* Line: 180 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 180 */ {
bevl_inString = be.BECS_Runtime.boolFalse;
bevt_13_tmpany_phold = bevl_accum.bem_extractString_0();
beva_handler.bemd_1(-229126306, bevt_13_tmpany_phold);
} /* Line: 182 */
 else  /* Line: 183 */ {
if (bevl_inEscape.bevi_bool) /* Line: 184 */ {
bevl_escval = (BEC_2_4_6_TextString) bevl_fromEscapes.bem_get_1(bevl_tok);
if (bevl_escval == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevl_accum.bem_addValue_1(bevl_escval);
} /* Line: 187 */
 else  /* Line: 186 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_17;
bevt_15_tmpany_phold = bevl_tok.bem_begins_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevl_value = bem_jsonUcUnescape_1(bevl_tok);
bevl_remainder = bem_jsonUcGetAfterPart_1(bevl_tok);
bevl_isStart = be.BECS_Runtime.boolFalse;
if (bevl_heldValue == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_19_tmpany_phold = bem_jsonUcIsPairEnd_1(bevl_value);
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 192 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(62, bece_BEC_2_4_6_JsonParser_bels_28));
bevt_20_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_21_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 193 */
 else  /* Line: 192 */ {
if (bevl_heldValue == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevl_isStart = bem_jsonUcIsPairStart_1(bevl_value);
} /* Line: 195 */
} /* Line: 192 */
if (bevl_isStart.bevi_bool) /* Line: 197 */ {
if (bevl_remainder == null) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 197 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 197 */
 else  /* Line: 197 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 197 */ {
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(73, bece_BEC_2_4_6_JsonParser_bels_29));
bevt_24_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 198 */
if (bevl_isStart.bevi_bool) /* Line: 200 */ {
bevl_heldValue = bevl_value;
} /* Line: 201 */
 else  /* Line: 202 */ {
bem_jsonUcAppendValue_3(bevl_heldValue, bevl_value, bevl_accum);
bevl_heldValue = null;
if (bevl_remainder == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevl_accum.bem_addValue_1(bevl_remainder);
} /* Line: 206 */
} /* Line: 205 */
} /* Line: 200 */
 else  /* Line: 209 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 210 */
} /* Line: 186 */
bevl_inEscape = be.BECS_Runtime.boolFalse;
} /* Line: 212 */
 else  /* Line: 184 */ {
bevt_27_tmpany_phold = bevl_tok.bem_equals_1(bevp_escape);
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevl_inEscape = be.BECS_Runtime.boolTrue;
} /* Line: 214 */
 else  /* Line: 215 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 216 */
} /* Line: 184 */
} /* Line: 184 */
} /* Line: 180 */
 else  /* Line: 219 */ {
bevt_28_tmpany_phold = bevl_tok.bem_equals_1(bevp_space);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_29_tmpany_phold = bevl_tok.bem_equals_1(bevp_cr);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 221 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_30_tmpany_phold = bevl_tok.bem_equals_1(bevp_lf);
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 221 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_31_tmpany_phold = bevl_tok.bem_equals_1(bevp_comma);
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 221 */ {
} /* Line: 221 */
 else  /* Line: 221 */ {
bevt_32_tmpany_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevl_inString = be.BECS_Runtime.boolTrue;
} /* Line: 223 */
 else  /* Line: 221 */ {
bevt_33_tmpany_phold = bevl_tok.bem_equals_1(bevp_lbrace);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 224 */ {
beva_handler.bemd_0(-1192092144);
} /* Line: 225 */
 else  /* Line: 221 */ {
bevt_34_tmpany_phold = bevl_tok.bem_equals_1(bevp_rbrace);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 226 */ {
beva_handler.bemd_0(76493958);
} /* Line: 227 */
 else  /* Line: 221 */ {
bevt_35_tmpany_phold = bevl_tok.bem_equals_1(bevp_colon);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 228 */ {
beva_handler.bemd_0(-819815423);
} /* Line: 229 */
 else  /* Line: 221 */ {
bevt_36_tmpany_phold = bevl_tok.bem_equals_1(bevp_lbracket);
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 230 */ {
beva_handler.bemd_0(1465433716);
} /* Line: 231 */
 else  /* Line: 221 */ {
bevt_37_tmpany_phold = bevl_tok.bem_equals_1(bevp_rbracket);
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 232 */ {
beva_handler.bemd_0(1168916617);
} /* Line: 233 */
 else  /* Line: 234 */ {
bevt_39_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_18;
bevt_38_tmpany_phold = bevl_tok.bem_equals_1(bevt_39_tmpany_phold);
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_41_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_19;
bevt_40_tmpany_phold = bevl_tok.bem_equals_1(bevt_41_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 237 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_43_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_20;
bevt_42_tmpany_phold = bevl_tok.bem_equals_1(bevt_43_tmpany_phold);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 237 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_45_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_21;
bevt_44_tmpany_phold = bevl_tok.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 237 */ {
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_47_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_22;
bevt_46_tmpany_phold = bevl_tok.bem_equals_1(bevt_47_tmpany_phold);
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 240 */ {
beva_handler.bemd_0(1753821040);
} /* Line: 241 */
 else  /* Line: 237 */ {
bevt_49_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_23;
bevt_48_tmpany_phold = bevl_tok.bem_equals_1(bevt_49_tmpany_phold);
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 242 */ {
beva_handler.bemd_0(746392288);
} /* Line: 243 */
 else  /* Line: 237 */ {
bevt_51_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_24;
bevt_50_tmpany_phold = bevl_tok.bem_equals_1(bevt_51_tmpany_phold);
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 244 */ {
beva_handler.bemd_0(1106852519);
} /* Line: 245 */
 else  /* Line: 246 */ {
bevt_52_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_tok);
beva_handler.bemd_1(-1300321877, bevt_52_tmpany_phold);
} /* Line: 248 */
} /* Line: 237 */
} /* Line: 237 */
} /* Line: 237 */
} /* Line: 237 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 179 */
 else  /* Line: 176 */ {
break;
} /* Line: 176 */
} /* Line: 176 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public final BEC_2_4_6_TextString bem_quoteGetDirect_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_JsonParser bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbraceGet_0() throws Throwable {
return bevp_lbrace;
} /*method end*/
public final BEC_2_4_6_TextString bem_lbraceGetDirect_0() throws Throwable {
return bevp_lbrace;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_lbraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_rbraceGet_0() throws Throwable {
return bevp_rbrace;
} /*method end*/
public final BEC_2_4_6_TextString bem_rbraceGetDirect_0() throws Throwable {
return bevp_rbrace;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_rbraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbracketGet_0() throws Throwable {
return bevp_lbracket;
} /*method end*/
public final BEC_2_4_6_TextString bem_lbracketGetDirect_0() throws Throwable {
return bevp_lbracket;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_lbracketSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_rbracketGet_0() throws Throwable {
return bevp_rbracket;
} /*method end*/
public final BEC_2_4_6_TextString bem_rbracketGetDirect_0() throws Throwable {
return bevp_rbracket;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_rbracketSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public final BEC_2_4_6_TextString bem_spaceGetDirect_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_6_JsonParser bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public final BEC_2_4_6_TextString bem_colonGetDirect_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_JsonParser bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_escapeGet_0() throws Throwable {
return bevp_escape;
} /*method end*/
public final BEC_2_4_6_TextString bem_escapeGetDirect_0() throws Throwable {
return bevp_escape;
} /*method end*/
public BEC_2_4_6_JsonParser bem_escapeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_escapeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public final BEC_2_4_6_TextString bem_crGetDirect_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_JsonParser bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public final BEC_2_4_6_TextString bem_lfGetDirect_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commaGet_0() throws Throwable {
return bevp_comma;
} /*method end*/
public final BEC_2_4_6_TextString bem_commaGetDirect_0() throws Throwable {
return bevp_comma;
} /*method end*/
public BEC_2_4_6_JsonParser bem_commaSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_commaSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tokensGet_0() throws Throwable {
return bevp_tokens;
} /*method end*/
public final BEC_2_4_6_TextString bem_tokensGetDirect_0() throws Throwable {
return bevp_tokens;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_tokensSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() throws Throwable {
return bevp_toker;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() throws Throwable {
return bevp_toker;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hsubGet_0() throws Throwable {
return bevp_hsub;
} /*method end*/
public final BEC_2_4_3_MathInt bem_hsubGetDirect_0() throws Throwable {
return bevp_hsub;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_hsubSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vsubGet_0() throws Throwable {
return bevp_vsub;
} /*method end*/
public final BEC_2_4_3_MathInt bem_vsubGetDirect_0() throws Throwable {
return bevp_vsub;
} /*method end*/
public BEC_2_4_6_JsonParser bem_vsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_vsubSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmAddGet_0() throws Throwable {
return bevp_hmAdd;
} /*method end*/
public final BEC_2_4_3_MathInt bem_hmAddGetDirect_0() throws Throwable {
return bevp_hmAdd;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hmAddSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_hmAddSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {36, 36, 37, 38, 39, 40, 41, 41, 42, 42, 43, 44, 44, 45, 45, 46, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 48, 48, 49, 49, 50, 50, 51, 51, 57, 57, 62, 62, 62, 62, 62, 62, 0, 0, 0, 63, 65, 67, 73, 73, 73, 73, 73, 73, 0, 0, 0, 74, 76, 78, 83, 83, 83, 83, 84, 86, 86, 86, 90, 90, 90, 90, 91, 91, 91, 93, 93, 93, 93, 98, 98, 98, 98, 98, 98, 99, 99, 99, 99, 101, 104, 104, 106, 107, 108, 108, 109, 110, 111, 112, 118, 118, 118, 119, 120, 120, 120, 120, 121, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 125, 126, 127, 127, 127, 127, 128, 128, 128, 128, 128, 128, 128, 128, 128, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 130, 130, 130, 130, 130, 130, 130, 130, 130, 131, 132, 132, 132, 132, 133, 133, 133, 133, 133, 133, 133, 133, 133, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 136, 136, 136, 136, 136, 136, 136, 136, 136, 137, 139, 142, 142, 142, 143, 143, 143, 145, 145, 145, 166, 167, 168, 170, 170, 172, 176, 177, 180, 180, 180, 0, 0, 0, 181, 182, 182, 185, 186, 186, 187, 188, 188, 189, 190, 191, 192, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 194, 194, 195, 197, 197, 0, 0, 0, 198, 198, 198, 201, 203, 204, 205, 205, 206, 210, 212, 213, 214, 216, 221, 0, 221, 0, 0, 0, 221, 0, 0, 0, 221, 0, 0, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 237, 237, 0, 237, 237, 0, 0, 0, 237, 237, 0, 0, 0, 237, 237, 0, 0, 240, 240, 241, 242, 242, 243, 244, 244, 245, 248, 248, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 150, 151, 161, 162, 167, 168, 169, 174, 175, 178, 182, 185, 188, 190, 199, 200, 205, 206, 207, 212, 213, 216, 220, 223, 226, 228, 236, 237, 238, 243, 244, 246, 247, 248, 259, 260, 261, 266, 267, 268, 269, 271, 272, 273, 274, 388, 389, 390, 391, 392, 397, 398, 399, 400, 401, 403, 404, 409, 410, 411, 412, 413, 414, 415, 416, 417, 419, 420, 425, 426, 429, 430, 431, 436, 437, 438, 441, 442, 443, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 470, 471, 472, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 510, 511, 512, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 561, 567, 568, 573, 574, 575, 576, 578, 579, 580, 648, 649, 650, 651, 652, 653, 656, 658, 660, 665, 666, 668, 671, 675, 678, 679, 680, 684, 685, 690, 691, 694, 695, 697, 698, 699, 700, 705, 706, 707, 712, 713, 716, 720, 723, 724, 725, 728, 733, 734, 738, 743, 744, 747, 751, 754, 755, 756, 759, 762, 763, 764, 769, 770, 775, 778, 781, 783, 786, 792, 794, 797, 799, 802, 806, 809, 811, 814, 818, 821, 823, 826, 832, 834, 837, 839, 842, 844, 847, 849, 852, 854, 857, 859, 862, 863, 865, 868, 869, 871, 874, 878, 881, 882, 884, 887, 891, 894, 895, 897, 900, 906, 907, 909, 912, 913, 915, 918, 919, 921, 924, 925, 946, 949, 952, 956, 960, 963, 966, 970, 974, 977, 980, 984, 988, 991, 994, 998, 1002, 1005, 1008, 1012, 1016, 1019, 1022, 1026, 1030, 1033, 1036, 1040, 1044, 1047, 1050, 1054, 1058, 1061, 1064, 1068, 1072, 1075, 1078, 1082, 1086, 1089, 1092, 1096, 1100, 1103, 1106, 1110, 1114, 1117, 1120, 1124, 1128, 1131, 1134, 1138, 1142, 1145, 1148, 1152, 1156, 1159, 1162, 1166};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 36 110
new 0 36 110
assign 1 36 111
quoteGet 0 36 111
assign 1 37 112
new 0 37 112
assign 1 38 113
new 0 38 113
assign 1 39 114
new 0 39 114
assign 1 40 115
new 0 40 115
assign 1 41 116
new 0 41 116
assign 1 41 117
spaceGet 0 41 117
assign 1 42 118
new 0 42 118
assign 1 42 119
colonGet 0 42 119
assign 1 43 120
new 0 43 120
assign 1 44 121
new 0 44 121
assign 1 44 122
crGet 0 44 122
assign 1 45 123
new 0 45 123
assign 1 45 124
lfGet 0 45 124
assign 1 46 125
new 0 46 125
assign 1 47 126
add 1 47 126
assign 1 47 127
add 1 47 127
assign 1 47 128
add 1 47 128
assign 1 47 129
add 1 47 129
assign 1 47 130
add 1 47 130
assign 1 47 131
add 1 47 131
assign 1 47 132
add 1 47 132
assign 1 47 133
add 1 47 133
assign 1 47 134
add 1 47 134
assign 1 47 135
add 1 47 135
assign 1 47 136
new 0 47 136
assign 1 47 137
add 1 47 137
assign 1 48 138
new 0 48 138
assign 1 48 139
new 2 48 139
assign 1 49 140
new 0 49 140
assign 1 49 141
hexNew 1 49 141
assign 1 50 142
new 0 50 142
assign 1 50 143
hexNew 1 50 143
assign 1 51 144
new 0 51 144
assign 1 51 145
hexNew 1 51 145
assign 1 57 150
tokenize 1 57 150
parseTokens 2 57 151
assign 1 62 161
new 0 62 161
assign 1 62 162
lesserEquals 1 62 167
assign 1 62 168
new 0 62 168
assign 1 62 169
lesserEquals 1 62 174
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 63 185
new 0 63 185
assign 1 65 188
new 0 65 188
return 1 67 190
assign 1 73 199
new 0 73 199
assign 1 73 200
lesserEquals 1 73 205
assign 1 73 206
new 0 73 206
assign 1 73 207
lesserEquals 1 73 212
assign 1 0 213
assign 1 0 216
assign 1 0 220
assign 1 74 223
new 0 74 223
assign 1 76 226
new 0 76 226
return 1 78 228
assign 1 83 236
sizeGet 0 83 236
assign 1 83 237
new 0 83 237
assign 1 83 238
lesser 1 83 243
return 1 84 244
assign 1 86 246
new 0 86 246
assign 1 86 247
substring 1 86 247
return 1 86 248
assign 1 90 259
sizeGet 0 90 259
assign 1 90 260
new 0 90 260
assign 1 90 261
lesser 1 90 266
assign 1 91 267
new 0 91 267
assign 1 91 268
new 1 91 268
throw 1 91 269
assign 1 93 271
new 0 93 271
assign 1 93 272
substring 1 93 272
assign 1 93 273
hexNew 1 93 273
return 1 93 274
assign 1 98 388
capacityGet 0 98 388
assign 1 98 389
sizeGet 0 98 389
assign 1 98 390
subtract 1 98 390
assign 1 98 391
new 0 98 391
assign 1 98 392
lesser 1 98 397
assign 1 99 398
sizeGet 0 99 398
assign 1 99 399
new 0 99 399
assign 1 99 400
add 1 99 400
capacitySet 1 99 401
assign 1 101 403
sizeGet 0 101 403
assign 1 104 404
def 1 104 409
assign 1 106 410
subtractValue 1 107 411
assign 1 108 412
new 0 108 412
shiftLeftValue 1 108 413
subtractValue 1 109 414
addValue 1 110 415
addValue 1 111 416
assign 1 112 417
assign 1 118 419
new 0 118 419
assign 1 118 420
lesser 1 118 425
assign 1 119 426
new 0 119 426
assign 1 120 429
new 0 120 429
assign 1 120 430
hexNew 1 120 430
assign 1 120 431
lesser 1 120 436
setIntUnchecked 2 121 437
assign 1 122 438
new 0 122 438
assign 1 123 441
new 0 123 441
assign 1 123 442
hexNew 1 123 442
assign 1 123 443
lesser 1 123 448
assign 1 124 449
new 0 124 449
assign 1 124 450
hexNew 1 124 450
assign 1 124 451
new 0 124 451
assign 1 124 452
hexNew 1 124 452
assign 1 124 453
and 1 124 453
assign 1 124 454
new 0 124 454
assign 1 124 455
shiftRight 1 124 455
assign 1 124 456
add 1 124 456
setIntUnchecked 2 124 457
assign 1 125 458
new 0 125 458
assign 1 125 459
add 1 125 459
assign 1 125 460
new 0 125 460
assign 1 125 461
hexNew 1 125 461
assign 1 125 462
new 0 125 462
assign 1 125 463
hexNew 1 125 463
assign 1 125 464
and 1 125 464
assign 1 125 465
add 1 125 465
setIntUnchecked 2 125 466
assign 1 126 467
new 0 126 467
assign 1 127 470
new 0 127 470
assign 1 127 471
hexNew 1 127 471
assign 1 127 472
lesser 1 127 477
assign 1 128 478
new 0 128 478
assign 1 128 479
hexNew 1 128 479
assign 1 128 480
new 0 128 480
assign 1 128 481
hexNew 1 128 481
assign 1 128 482
and 1 128 482
assign 1 128 483
new 0 128 483
assign 1 128 484
shiftRight 1 128 484
assign 1 128 485
add 1 128 485
setIntUnchecked 2 128 486
assign 1 129 487
new 0 129 487
assign 1 129 488
add 1 129 488
assign 1 129 489
new 0 129 489
assign 1 129 490
hexNew 1 129 490
assign 1 129 491
new 0 129 491
assign 1 129 492
hexNew 1 129 492
assign 1 129 493
and 1 129 493
assign 1 129 494
new 0 129 494
assign 1 129 495
shiftRight 1 129 495
assign 1 129 496
add 1 129 496
setIntUnchecked 2 129 497
assign 1 130 498
new 0 130 498
assign 1 130 499
add 1 130 499
assign 1 130 500
new 0 130 500
assign 1 130 501
hexNew 1 130 501
assign 1 130 502
new 0 130 502
assign 1 130 503
hexNew 1 130 503
assign 1 130 504
and 1 130 504
assign 1 130 505
add 1 130 505
setIntUnchecked 2 130 506
assign 1 131 507
new 0 131 507
assign 1 132 510
new 0 132 510
assign 1 132 511
hexNew 1 132 511
assign 1 132 512
lesserEquals 1 132 517
assign 1 133 518
new 0 133 518
assign 1 133 519
hexNew 1 133 519
assign 1 133 520
new 0 133 520
assign 1 133 521
hexNew 1 133 521
assign 1 133 522
and 1 133 522
assign 1 133 523
new 0 133 523
assign 1 133 524
shiftRight 1 133 524
assign 1 133 525
add 1 133 525
setIntUnchecked 2 133 526
assign 1 134 527
new 0 134 527
assign 1 134 528
add 1 134 528
assign 1 134 529
new 0 134 529
assign 1 134 530
hexNew 1 134 530
assign 1 134 531
new 0 134 531
assign 1 134 532
hexNew 1 134 532
assign 1 134 533
and 1 134 533
assign 1 134 534
new 0 134 534
assign 1 134 535
shiftRight 1 134 535
assign 1 134 536
add 1 134 536
setIntUnchecked 2 134 537
assign 1 135 538
new 0 135 538
assign 1 135 539
add 1 135 539
assign 1 135 540
new 0 135 540
assign 1 135 541
hexNew 1 135 541
assign 1 135 542
new 0 135 542
assign 1 135 543
hexNew 1 135 543
assign 1 135 544
and 1 135 544
assign 1 135 545
new 0 135 545
assign 1 135 546
shiftRight 1 135 546
assign 1 135 547
add 1 135 547
setIntUnchecked 2 135 548
assign 1 136 549
new 0 136 549
assign 1 136 550
add 1 136 550
assign 1 136 551
new 0 136 551
assign 1 136 552
hexNew 1 136 552
assign 1 136 553
new 0 136 553
assign 1 136 554
hexNew 1 136 554
assign 1 136 555
and 1 136 555
assign 1 136 556
add 1 136 556
setIntUnchecked 2 136 557
assign 1 137 558
new 0 137 558
assign 1 139 561
new 0 139 561
assign 1 142 567
new 0 142 567
assign 1 142 568
lesser 1 142 573
assign 1 143 574
new 0 143 574
assign 1 143 575
new 1 143 575
throw 1 143 576
assign 1 145 578
sizeGet 0 145 578
assign 1 145 579
add 1 145 579
sizeSet 1 145 580
assign 1 166 648
new 0 166 648
assign 1 167 649
new 0 167 649
assign 1 168 650
new 0 168 650
assign 1 170 651
new 0 170 651
assign 1 170 652
fromEscapesGet 0 170 652
assign 1 172 653
linkedListIteratorGet 0 172 653
assign 1 176 656
hasNextGet 0 176 656
assign 1 177 658
nextGet 0 177 658
assign 1 180 660
not 0 180 665
assign 1 180 666
equals 1 180 666
assign 1 0 668
assign 1 0 671
assign 1 0 675
assign 1 181 678
new 0 181 678
assign 1 182 679
extractString 0 182 679
handleString 1 182 680
assign 1 185 684
get 1 185 684
assign 1 186 685
def 1 186 690
addValue 1 187 691
assign 1 188 694
new 0 188 694
assign 1 188 695
begins 1 188 695
assign 1 189 697
jsonUcUnescape 1 189 697
assign 1 190 698
jsonUcGetAfterPart 1 190 698
assign 1 191 699
new 0 191 699
assign 1 192 700
def 1 192 705
assign 1 192 706
jsonUcIsPairEnd 1 192 706
assign 1 192 707
not 0 192 712
assign 1 0 713
assign 1 0 716
assign 1 0 720
assign 1 193 723
new 0 193 723
assign 1 193 724
new 1 193 724
throw 1 193 725
assign 1 194 728
undef 1 194 733
assign 1 195 734
jsonUcIsPairStart 1 195 734
assign 1 197 738
def 1 197 743
assign 1 0 744
assign 1 0 747
assign 1 0 751
assign 1 198 754
new 0 198 754
assign 1 198 755
new 1 198 755
throw 1 198 756
assign 1 201 759
jsonUcAppendValue 3 203 762
assign 1 204 763
assign 1 205 764
def 1 205 769
addValue 1 206 770
addValue 1 210 775
assign 1 212 778
new 0 212 778
assign 1 213 781
equals 1 213 781
assign 1 214 783
new 0 214 783
addValue 1 216 786
assign 1 221 792
equals 1 221 792
assign 1 0 794
assign 1 221 797
equals 1 221 797
assign 1 0 799
assign 1 0 802
assign 1 0 806
assign 1 221 809
equals 1 221 809
assign 1 0 811
assign 1 0 814
assign 1 0 818
assign 1 221 821
equals 1 221 821
assign 1 0 823
assign 1 0 826
assign 1 222 832
equals 1 222 832
assign 1 223 834
new 0 223 834
assign 1 224 837
equals 1 224 837
beginMap 0 225 839
assign 1 226 842
equals 1 226 842
endMap 0 227 844
assign 1 228 847
equals 1 228 847
kvMid 0 229 849
assign 1 230 852
equals 1 230 852
beginList 0 231 854
assign 1 232 857
equals 1 232 857
endList 0 233 859
assign 1 237 862
new 0 237 862
assign 1 237 863
equals 1 237 863
assign 1 0 865
assign 1 237 868
new 0 237 868
assign 1 237 869
equals 1 237 869
assign 1 0 871
assign 1 0 874
assign 1 0 878
assign 1 237 881
new 0 237 881
assign 1 237 882
equals 1 237 882
assign 1 0 884
assign 1 0 887
assign 1 0 891
assign 1 237 894
new 0 237 894
assign 1 237 895
equals 1 237 895
assign 1 0 897
assign 1 0 900
assign 1 240 906
new 0 240 906
assign 1 240 907
equals 1 240 907
handleTrue 0 241 909
assign 1 242 912
new 0 242 912
assign 1 242 913
equals 1 242 913
handleFalse 0 243 915
assign 1 244 918
new 0 244 918
assign 1 244 919
equals 1 244 919
handleNull 0 245 921
assign 1 248 924
new 1 248 924
handleInteger 1 248 925
return 1 0 946
return 1 0 949
assign 1 0 952
assign 1 0 956
return 1 0 960
return 1 0 963
assign 1 0 966
assign 1 0 970
return 1 0 974
return 1 0 977
assign 1 0 980
assign 1 0 984
return 1 0 988
return 1 0 991
assign 1 0 994
assign 1 0 998
return 1 0 1002
return 1 0 1005
assign 1 0 1008
assign 1 0 1012
return 1 0 1016
return 1 0 1019
assign 1 0 1022
assign 1 0 1026
return 1 0 1030
return 1 0 1033
assign 1 0 1036
assign 1 0 1040
return 1 0 1044
return 1 0 1047
assign 1 0 1050
assign 1 0 1054
return 1 0 1058
return 1 0 1061
assign 1 0 1064
assign 1 0 1068
return 1 0 1072
return 1 0 1075
assign 1 0 1078
assign 1 0 1082
return 1 0 1086
return 1 0 1089
assign 1 0 1092
assign 1 0 1096
return 1 0 1100
return 1 0 1103
assign 1 0 1106
assign 1 0 1110
return 1 0 1114
return 1 0 1117
assign 1 0 1120
assign 1 0 1124
return 1 0 1128
return 1 0 1131
assign 1 0 1134
assign 1 0 1138
return 1 0 1142
return 1 0 1145
assign 1 0 1148
assign 1 0 1152
return 1 0 1156
return 1 0 1159
assign 1 0 1162
assign 1 0 1166
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -911425158: return bem_lbraceGet_0();
case -1500978633: return bem_tagGet_0();
case 2102651338: return bem_fieldIteratorGet_0();
case -484995088: return bem_hmAddGet_0();
case -527884055: return bem_crGetDirect_0();
case 1859607775: return bem_commaGet_0();
case -1551806822: return bem_toAny_0();
case 756962342: return bem_lbraceGetDirect_0();
case -1028606640: return bem_quoteGetDirect_0();
case 1201799861: return bem_serializeToString_0();
case 1219791999: return bem_escapeGet_0();
case -114079936: return bem_serializeContents_0();
case 301177989: return bem_commaGetDirect_0();
case 201605835: return bem_spaceGetDirect_0();
case -2137659920: return bem_tokerGetDirect_0();
case 1447764754: return bem_hmAddGetDirect_0();
case 2036147796: return bem_toString_0();
case -1421110551: return bem_hsubGetDirect_0();
case 1430998361: return bem_serializationIteratorGet_0();
case 459828379: return bem_quoteGet_0();
case 191896611: return bem_copy_0();
case 436532071: return bem_lbracketGetDirect_0();
case 473522792: return bem_crGet_0();
case -1275250473: return bem_vsubGet_0();
case -2072472298: return bem_hashGet_0();
case -1737009900: return bem_many_0();
case -1066226610: return bem_fieldNamesGet_0();
case -1779190962: return bem_tokensGetDirect_0();
case 552049268: return bem_rbracketGet_0();
case 793962932: return bem_lfGet_0();
case 226252534: return bem_rbracketGetDirect_0();
case 1572075383: return bem_tokensGet_0();
case 1525639803: return bem_sourceFileNameGet_0();
case 2071612158: return bem_tokerGet_0();
case 653341959: return bem_print_0();
case -1759630984: return bem_classNameGet_0();
case -1222439756: return bem_escapeGetDirect_0();
case -1195111829: return bem_create_0();
case 1162560541: return bem_colonGet_0();
case -1933366242: return bem_vsubGetDirect_0();
case 573647971: return bem_iteratorGet_0();
case 1354879463: return bem_rbraceGet_0();
case -1976480232: return bem_once_0();
case -1748925107: return bem_echo_0();
case 1848630324: return bem_rbraceGetDirect_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case -878215285: return bem_lbracketGet_0();
case 1139174773: return bem_colonGetDirect_0();
case -1628301109: return bem_hsubGet_0();
case -1447962621: return bem_spaceGet_0();
case -1439875774: return bem_new_0();
case 483062399: return bem_lfGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -192271885: return bem_equals_1(bevd_0);
case -102295312: return bem_sameObject_1(bevd_0);
case 1747292944: return bem_escapeSetDirect_1(bevd_0);
case -629741970: return bem_commaSet_1(bevd_0);
case 276929689: return bem_vsubSet_1(bevd_0);
case -1236915103: return bem_rbraceSetDirect_1(bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case 33662653: return bem_jsonUcIsPairStart_1((BEC_2_4_3_MathInt) bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case 1856496069: return bem_crSetDirect_1(bevd_0);
case -201997895: return bem_rbraceSet_1(bevd_0);
case 1865423688: return bem_jsonUcIsPairEnd_1((BEC_2_4_3_MathInt) bevd_0);
case -2046265425: return bem_escapeSet_1(bevd_0);
case 755717461: return bem_tokerSet_1(bevd_0);
case 125005146: return bem_colonSet_1(bevd_0);
case 1968394080: return bem_jsonUcGetAfterPart_1((BEC_2_4_6_TextString) bevd_0);
case -1718417378: return bem_lfSetDirect_1(bevd_0);
case 1984498278: return bem_jsonUcUnescape_1((BEC_2_4_6_TextString) bevd_0);
case 1180476792: return bem_quoteSet_1(bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case -1329723395: return bem_rbracketSetDirect_1(bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1963469705: return bem_hsubSetDirect_1(bevd_0);
case 421033878: return bem_colonSetDirect_1(bevd_0);
case -1425507993: return bem_hsubSet_1(bevd_0);
case -1936110894: return bem_rbracketSet_1(bevd_0);
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 601847995: return bem_lfSet_1(bevd_0);
case 1275845183: return bem_spaceSetDirect_1(bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case -1094017744: return bem_commaSetDirect_1(bevd_0);
case -1143973844: return bem_vsubSetDirect_1(bevd_0);
case -1640400604: return bem_lbracketSet_1(bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -940364023: return bem_crSet_1(bevd_0);
case -362221307: return bem_lbracketSetDirect_1(bevd_0);
case 1686337035: return bem_hmAddSetDirect_1(bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case 884462515: return bem_def_1(bevd_0);
case 2016843967: return bem_tokerSetDirect_1(bevd_0);
case -853882311: return bem_lbraceSet_1(bevd_0);
case -2038111821: return bem_hmAddSet_1(bevd_0);
case -1836610511: return bem_tokensSet_1(bevd_0);
case 762007253: return bem_quoteSetDirect_1(bevd_0);
case -248927589: return bem_lbraceSetDirect_1(bevd_0);
case -279722875: return bem_tokensSetDirect_1(bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
case 1698740350: return bem_spaceSet_1(bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1316660016: return bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevd_0, bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -363133314: return bem_parse_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 352441175: return bem_jsonUcAppendValue_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_JsonParser_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_6_JsonParser_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_JsonParser();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst = (BEC_2_4_6_JsonParser) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_type;
}
}
