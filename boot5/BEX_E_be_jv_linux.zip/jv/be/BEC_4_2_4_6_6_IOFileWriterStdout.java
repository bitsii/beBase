package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_6_IOFileWriterStdout extends BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_6_IOFileWriterStdout() { }
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStdout_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x53,0x74,0x64,0x6F,0x75,0x74};
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStdout_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_6_IOFileWriterStdout bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst;

public static BET_4_2_4_6_6_IOFileWriterStdout bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_type;

public BEC_4_2_4_6_6_IOFileWriterStdout bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStdout bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStdout bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStdout bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStdout bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStdout bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {685, 690, 690};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 23, 24};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 685 15
new 0 685 15
assign 1 690 23
new 0 690 23
return 1 690 24
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1401305769: return bem_copy_0();
case -1826754149: return bem_tagGet_0();
case 179457097: return bem_openTruncate_0();
case -1054253204: return bem_new_0();
case 1787710498: return bem_iteratorGet_0();
case 1318427979: return bem_open_0();
case 1745333375: return bem_hashGet_0();
case 562138791: return bem_print_0();
case 1497956054: return bem_toString_0();
case 474305884: return bem_pathGet_0();
case -986592722: return bem_default_0();
case -801890495: return bem_close_0();
case -508656086: return bem_openAppend_0();
case -191405214: return bem_isClosedGet_0();
case -205176326: return bem_extOpen_0();
case 457178368: return bem_classNameGet_0();
case 1336616742: return bem_fieldNamesGet_0();
case 2068199302: return bem_vfileGet_0();
case 1653499699: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1282419489: return bem_copyTo_1(bevd_0);
case 897088300: return bem_sameObject_1(bevd_0);
case -1471136482: return bem_new_1(bevd_0);
case -1894503367: return bem_sameType_1(bevd_0);
case 407945070: return bem_pathSet_1(bevd_0);
case -2045148476: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 586710983: return bem_notEquals_1(bevd_0);
case 341315102: return bem_vfileSet_1(bevd_0);
case -93958152: return bem_equals_1(bevd_0);
case 591751180: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -1094345634: return bem_otherType_1(bevd_0);
case 519586024: return bem_def_1(bevd_0);
case -185166219: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 112425026: return bem_undef_1(bevd_0);
case 190930489: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -1259898071: return bem_isClosedSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1052889707: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651612463: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 209233844: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1399119392: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 402325359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_4_2_4_6_6_IOFileWriterStdout_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_6_IOFileWriterStdout_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_6_IOFileWriterStdout();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst = (BEC_4_2_4_6_6_IOFileWriterStdout) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_type;
}
}
