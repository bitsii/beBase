package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_4_IOLogs extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOLogs() { }
private static byte[] becc_BEC_2_2_4_IOLogs_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67,0x73};
private static byte[] becc_BEC_2_2_4_IOLogs_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
public static BEC_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_inst;

public static BET_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_type;

public BEC_2_4_3_MathInt bevp_debug;
public BEC_2_4_3_MathInt bevp_info;
public BEC_2_4_3_MathInt bevp_warn;
public BEC_2_4_3_MathInt bevp_error;
public BEC_2_4_3_MathInt bevp_fatal;
public BEC_2_9_3_ContainerSet bevp_overrides;
public BEC_2_9_3_ContainerMap bevp_loggers;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_4_3_MathInt bevp_defaultOutputLevel;
public BEC_2_4_3_MathInt bevp_defaultLevel;
public BEC_2_6_6_SystemObject bevp_sink;
public BEC_2_2_4_IOLogs bem_default_0() throws Throwable {
bevp_debug = (new BEC_2_4_3_MathInt(400));
bevp_info = (new BEC_2_4_3_MathInt(300));
bevp_warn = (new BEC_2_4_3_MathInt(200));
bevp_error = (new BEC_2_4_3_MathInt(100));
bevp_fatal = (new BEC_2_4_3_MathInt(0));
bevp_overrides = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_loggers = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_defaultOutputLevel = bevp_error;
bevp_defaultLevel = bevp_info;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_setDefaultLevels_2(BEC_2_4_3_MathInt beva__defaultOutputLevel, BEC_2_4_3_MathInt beva__defaultLevel) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
try /* Line: 43*/ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = beva__defaultOutputLevel;
bevp_defaultLevel = beva__defaultLevel;
bevt_0_ta_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
/* Line: 47*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 47*/ {
bevl_kv = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = bevl_kv.bemd_0(-923955479);
bevt_2_ta_ph = bevp_overrides.bem_contains_1(bevt_3_ta_ph);
if (!(bevt_2_ta_ph.bevi_bool))/* Line: 48*/ {
bevt_4_ta_ph = bevl_kv.bemd_0(-1614292331);
bevt_4_ta_ph.bemd_2(1070534790, bevp_defaultOutputLevel, bevp_defaultLevel);
} /* Line: 49*/
} /* Line: 48*/
 else /* Line: 47*/ {
break;
} /* Line: 47*/
} /* Line: 47*/
bevp_lock.bem_unlock_0();
} /* Line: 52*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 54*/
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_putKeyLevels_3(BEC_2_4_6_TextString beva_key, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
try /* Line: 59*/ {
bevp_lock.bem_lock_0();
bevp_overrides.bem_put_1(beva_key);
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 64*/ {
bevl_log = (new BEC_2_2_3_IOLog()).bem_new_3(bevp_sink, beva_level, beva_outputLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 66*/
 else /* Line: 67*/ {
bevl_log.bem_levelSet_1(beva_level);
bevl_log.bem_outputLevelSet_1(beva_outputLevel);
} /* Line: 69*/
bevp_lock.bem_unlock_0();
} /* Line: 71*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 73*/
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_putLevels_3(BEC_2_6_6_SystemObject beva_inst, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_className_1(beva_inst);
bem_putKeyLevels_3(bevt_0_ta_ph, beva_level, beva_outputLevel);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_getKey_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
try /* Line: 82*/ {
bevp_lock.bem_lock_0();
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 85*/ {
bevl_log = (new BEC_2_2_3_IOLog()).bem_new_3(bevp_sink, bevp_defaultOutputLevel, bevp_defaultLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 87*/
bevp_lock.bem_unlock_0();
} /* Line: 89*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 91*/
return bevl_log;
} /*method end*/
public BEC_2_2_3_IOLog bem_get_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_2_3_IOLog bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_className_1(beva_inst);
bevt_0_ta_ph = bem_getKey_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_2_4_IOLogs bem_turnOn_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
try /* Line: 101*/ {
bevp_lock.bem_lock_0();
bevl_log = bem_get_1(beva_inst);
bevt_0_ta_ph = bevl_log.bem_levelGet_0();
bevt_1_ta_ph = bevl_log.bem_levelGet_0();
bem_putLevels_3(beva_inst, bevt_0_ta_ph, bevt_1_ta_ph);
bevp_lock.bem_unlock_0();
} /* Line: 105*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 107*/
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_turnOnAll_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
try /* Line: 112*/ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = bevp_defaultLevel;
bevt_0_ta_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
/* Line: 115*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 115*/ {
bevl_kv = bevt_0_ta_loop.bem_nextGet_0();
bevt_2_ta_ph = bevl_kv.bemd_0(-1614292331);
bevt_2_ta_ph.bemd_1(-1999049612, bevp_defaultOutputLevel);
bevt_3_ta_ph = bevl_kv.bemd_0(-1614292331);
bevt_3_ta_ph.bemd_1(219429551, bevp_defaultLevel);
} /* Line: 117*/
 else /* Line: 115*/ {
break;
} /* Line: 115*/
} /* Line: 115*/
bevp_lock.bem_unlock_0();
} /* Line: 119*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 121*/
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_setAllSinks_1(BEC_2_6_6_SystemObject beva__sink) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
try /* Line: 126*/ {
bevp_lock.bem_lock_0();
bevp_sink = beva__sink;
bevt_0_ta_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
/* Line: 129*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 129*/ {
bevl_kv = bevt_0_ta_loop.bem_nextGet_0();
bevt_2_ta_ph = bevl_kv.bemd_0(-1614292331);
bevt_2_ta_ph.bemd_1(-773650897, beva__sink);
} /* Line: 130*/
 else /* Line: 129*/ {
break;
} /* Line: 129*/
} /* Line: 129*/
bevp_lock.bem_unlock_0();
} /* Line: 132*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 134*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_2_4_IOLogs bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_infoGet_0() throws Throwable {
return bevp_info;
} /*method end*/
public BEC_2_2_4_IOLogs bem_infoSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_warnGet_0() throws Throwable {
return bevp_warn;
} /*method end*/
public BEC_2_2_4_IOLogs bem_warnSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_errorGet_0() throws Throwable {
return bevp_error;
} /*method end*/
public BEC_2_2_4_IOLogs bem_errorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_fatalGet_0() throws Throwable {
return bevp_fatal;
} /*method end*/
public BEC_2_2_4_IOLogs bem_fatalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_overridesGet_0() throws Throwable {
return bevp_overrides;
} /*method end*/
public BEC_2_2_4_IOLogs bem_overridesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_loggersGet_0() throws Throwable {
return bevp_loggers;
} /*method end*/
public BEC_2_2_4_IOLogs bem_loggersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_2_2_4_IOLogs bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultOutputLevelGet_0() throws Throwable {
return bevp_defaultOutputLevel;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultOutputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultLevelGet_0() throws Throwable {
return bevp_defaultLevel;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultLevelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGet_0() throws Throwable {
return bevp_sink;
} /*method end*/
public BEC_2_2_4_IOLogs bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 25, 26, 27, 28, 29, 30, 31, 33, 34, 44, 45, 46, 47, 0, 47, 47, 48, 48, 49, 49, 52, 54, 60, 61, 63, 64, 64, 65, 66, 68, 69, 71, 73, 78, 78, 78, 83, 84, 85, 85, 86, 87, 89, 91, 93, 97, 97, 97, 97, 102, 103, 104, 104, 104, 105, 107, 113, 114, 115, 0, 115, 115, 116, 116, 117, 117, 119, 121, 127, 128, 129, 0, 129, 129, 130, 130, 132, 134, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 44, 45, 46, 47, 47, 50, 52, 53, 54, 56, 57, 64, 68, 77, 78, 79, 80, 85, 86, 87, 90, 91, 93, 97, 104, 105, 106, 114, 115, 116, 121, 122, 123, 125, 129, 131, 137, 138, 139, 140, 148, 149, 150, 151, 152, 153, 157, 169, 170, 171, 171, 174, 176, 177, 178, 179, 180, 186, 190, 201, 202, 203, 203, 206, 208, 209, 210, 216, 220, 225, 228, 232, 235, 239, 242, 246, 249, 253, 256, 260, 263, 267, 270, 274, 277, 281, 284, 288, 291, 295, 298};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 23
new 0 24 23
assign 1 25 24
new 0 25 24
assign 1 26 25
new 0 26 25
assign 1 27 26
new 0 27 26
assign 1 28 27
new 0 28 27
assign 1 29 28
new 0 29 28
assign 1 30 29
new 0 30 29
assign 1 31 30
new 0 31 30
assign 1 33 31
assign 1 34 32
lock 0 44 44
assign 1 45 45
assign 1 46 46
assign 1 47 47
mapIteratorGet 0 0 47
assign 1 47 50
hasNextGet 0 47 50
assign 1 47 52
nextGet 0 47 52
assign 1 48 53
keyGet 0 48 53
assign 1 48 54
contains 1 48 54
assign 1 49 56
valueGet 0 49 56
setLevels 2 49 57
unlock 0 52 64
unlock 0 54 68
lock 0 60 77
put 1 61 78
assign 1 63 79
get 1 63 79
assign 1 64 80
undef 1 64 85
assign 1 65 86
new 3 65 86
put 2 66 87
levelSet 1 68 90
outputLevelSet 1 69 91
unlock 0 71 93
unlock 0 73 97
assign 1 78 104
new 0 78 104
assign 1 78 105
className 1 78 105
putKeyLevels 3 78 106
lock 0 83 114
assign 1 84 115
get 1 84 115
assign 1 85 116
undef 1 85 121
assign 1 86 122
new 3 86 122
put 2 87 123
unlock 0 89 125
unlock 0 91 129
return 1 93 131
assign 1 97 137
new 0 97 137
assign 1 97 138
className 1 97 138
assign 1 97 139
getKey 1 97 139
return 1 97 140
lock 0 102 148
assign 1 103 149
get 1 103 149
assign 1 104 150
levelGet 0 104 150
assign 1 104 151
levelGet 0 104 151
putLevels 3 104 152
unlock 0 105 153
unlock 0 107 157
lock 0 113 169
assign 1 114 170
assign 1 115 171
mapIteratorGet 0 0 171
assign 1 115 174
hasNextGet 0 115 174
assign 1 115 176
nextGet 0 115 176
assign 1 116 177
valueGet 0 116 177
outputLevelSet 1 116 178
assign 1 117 179
valueGet 0 117 179
levelSet 1 117 180
unlock 0 119 186
unlock 0 121 190
lock 0 127 201
assign 1 128 202
assign 1 129 203
mapIteratorGet 0 0 203
assign 1 129 206
hasNextGet 0 129 206
assign 1 129 208
nextGet 0 129 208
assign 1 130 209
valueGet 0 130 209
sinkSet 1 130 210
unlock 0 132 216
unlock 0 134 220
return 1 0 225
assign 1 0 228
return 1 0 232
assign 1 0 235
return 1 0 239
assign 1 0 242
return 1 0 246
assign 1 0 249
return 1 0 253
assign 1 0 256
return 1 0 260
assign 1 0 263
return 1 0 267
assign 1 0 270
return 1 0 274
assign 1 0 277
return 1 0 281
assign 1 0 284
return 1 0 288
assign 1 0 291
return 1 0 295
assign 1 0 298
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1599162480: return bem_defaultOutputLevelGet_0();
case -1048682546: return bem_infoGet_0();
case 1862660644: return bem_new_0();
case 51088423: return bem_fatalGet_0();
case -393844090: return bem_copy_0();
case -748394026: return bem_hashGet_0();
case 1160279532: return bem_create_0();
case 1570402525: return bem_lockGet_0();
case 1449076862: return bem_defaultLevelGet_0();
case -849762499: return bem_warnGet_0();
case 1183506115: return bem_loggersGet_0();
case -1048184133: return bem_turnOnAll_0();
case -1079825495: return bem_iteratorGet_0();
case -201034921: return bem_overridesGet_0();
case 1928595339: return bem_errorGet_0();
case 1723207084: return bem_sinkGet_0();
case 2066241869: return bem_print_0();
case -1233241901: return bem_toString_0();
case -1212242384: return bem_debugGet_0();
case -1240571169: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1902022464: return bem_print_1(bevd_0);
case -465513410: return bem_copyTo_1(bevd_0);
case 756438565: return bem_setAllSinks_1(bevd_0);
case -1215278694: return bem_def_1(bevd_0);
case 1744561694: return bem_overridesSet_1(bevd_0);
case 1184984907: return bem_getKey_1((BEC_2_4_6_TextString) bevd_0);
case -1288111971: return bem_loggersSet_1(bevd_0);
case 718577757: return bem_lockSet_1(bevd_0);
case 1921787435: return bem_equals_1(bevd_0);
case -382364404: return bem_errorSet_1(bevd_0);
case -846183763: return bem_turnOn_1(bevd_0);
case 65944014: return bem_defaultOutputLevelSet_1(bevd_0);
case -338960915: return bem_get_1(bevd_0);
case 748082217: return bem_debugSet_1(bevd_0);
case -773650897: return bem_sinkSet_1(bevd_0);
case -1227929691: return bem_fatalSet_1(bevd_0);
case -1844020083: return bem_infoSet_1(bevd_0);
case 1599446009: return bem_warnSet_1(bevd_0);
case 310887766: return bem_undef_1(bevd_0);
case 1633476346: return bem_notEquals_1(bevd_0);
case 32172598: return bem_defaultLevelSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1745573040: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1324104974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1411462266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1589423995: return bem_setDefaultLevels_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1926749857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1593668271: return bem_putKeyLevels_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 905655342: return bem_putLevels_3(bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOLogs_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_4_IOLogs_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOLogs();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst = (BEC_2_2_4_IOLogs) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_type;
}
}
