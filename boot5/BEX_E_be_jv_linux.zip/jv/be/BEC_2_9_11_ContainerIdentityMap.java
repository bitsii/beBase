package be;
/* IO:File: source/extended/IdentityMap.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {37, 37, 41, 42, 43, 44, 45, 46};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 37 13
new 0 37 13
new 1 37 14
assign 1 41 18
new 1 41 18
assign 1 42 19
assign 1 43 20
new 0 43 20
assign 1 44 21
new 0 44 21
assign 1 45 22
new 0 45 22
assign 1 46 23
new 0 46 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1568895705: return bem_serializationIteratorGet_0();
case 1293883485: return bem_print_0();
case -1000401074: return bem_lengthGet_0();
case -604728977: return bem_isEmptyGet_0();
case 975064598: return bem_valuesGet_0();
case 1676584576: return bem_clear_0();
case -109067955: return bem_nodesGet_0();
case 992700193: return bem_copy_0();
case -688180452: return bem_keyValueIteratorGet_0();
case 44618831: return bem_bucketsGet_0();
case -531178233: return bem_keyIteratorGet_0();
case -1227286029: return bem_valueIteratorGet_0();
case 1978701672: return bem_iteratorGet_0();
case -1250586953: return bem_create_0();
case -828589364: return bem_mapIteratorGet_0();
case 1169576666: return bem_keysGet_0();
case -183558940: return bem_nodeIteratorGet_0();
case 1788009576: return bem_serializeToString_0();
case -549345222: return bem_notEmptyGet_0();
case -10560512: return bem_toString_0();
case 1230276296: return bem_hashGet_0();
case 1836285625: return bem_new_0();
case -1583398024: return bem_setIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -257578377: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 625537054: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1409349899: return bem_undef_1(bevd_0);
case 907966167: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 52329100: return bem_copyTo_1(bevd_0);
case 715512076: return bem_get_1(bevd_0);
case -1933815953: return bem_addValue_1(bevd_0);
case -743975562: return bem_lengthSet_1(bevd_0);
case -305715842: return bem_notEquals_1(bevd_0);
case 1483312357: return bem_remove_1(bevd_0);
case -1926574247: return bem_def_1(bevd_0);
case 306269598: return bem_put_1(bevd_0);
case -277954027: return bem_has_1(bevd_0);
case -1978152287: return bem_print_1(bevd_0);
case -1987138359: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 850514472: return bem_equals_1(bevd_0);
case -2142243911: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -204687759: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1375138300: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1720096360: return bem_bucketsSet_1(bevd_0);
case -194987770: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1974138487: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1686468839: return bem_put_2(bevd_0, bevd_1);
case -1007047738: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -306501207: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 530385415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1507992233: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -914988023: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
