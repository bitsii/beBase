package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {91, 91, 95, 96, 97, 98, 99, 100};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 11, 15, 16, 17, 18, 19, 20};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 91 10
new 0 91 10
new 1 91 11
assign 1 95 15
new 1 95 15
assign 1 96 16
assign 1 97 17
new 0 97 17
assign 1 98 18
new 0 98 18
assign 1 99 19
new 0 99 19
assign 1 100 20
new 0 100 20
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1823731495: return bem_fieldIteratorGet_0();
case 889621714: return bem_relGet_0();
case 380917179: return bem_deserializeClassNameGet_0();
case 2007419844: return bem_sourceFileNameGet_0();
case -1997732490: return bem_serializeToString_0();
case -916997475: return bem_clear_0();
case -288603233: return bem_serializationIteratorGet_0();
case -486730947: return bem_tagGet_0();
case -495176641: return bem_slotsGet_0();
case -1488266286: return bem_mapIteratorGet_0();
case 89921707: return bem_echo_0();
case -2002314890: return bem_serializeContents_0();
case -706394436: return bem_classNameGet_0();
case -1182437983: return bem_valuesGet_0();
case -766424693: return bem_baseNodeGet_0();
case -1181381104: return bem_keysGet_0();
case -145517521: return bem_iteratorGet_0();
case 991924244: return bem_setIteratorGet_0();
case -1740032816: return bem_valueIteratorGet_0();
case 2091274768: return bem_notEmptyGet_0();
case 1293767192: return bem_sizeGet_0();
case -887436520: return bem_innerPutAddedGet_0();
case -724682101: return bem_keyIteratorGet_0();
case -1278101514: return bem_multiGet_0();
case 991850509: return bem_hashGet_0();
case -438931987: return bem_many_0();
case 903380622: return bem_copy_0();
case 192353495: return bem_toString_0();
case -2005670353: return bem_nodesGet_0();
case 1939405925: return bem_moduGet_0();
case 1071338406: return bem_once_0();
case 150815360: return bem_new_0();
case -1664987563: return bem_isEmptyGet_0();
case -610207516: return bem_print_0();
case 168772280: return bem_keyValueIteratorGet_0();
case 15192691: return bem_nodeIteratorGet_0();
case 1733022581: return bem_create_0();
case 1222559837: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1794454226: return bem_undef_1(bevd_0);
case -904802330: return bem_multiSet_1(bevd_0);
case -241747324: return bem_baseNodeSet_1(bevd_0);
case 754254864: return bem_sameType_1(bevd_0);
case -174280441: return bem_otherClass_1(bevd_0);
case -1245865568: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1702402169: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1355712669: return bem_put_1(bevd_0);
case 1234343289: return bem_def_1(bevd_0);
case -543653941: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1286019779: return bem_moduSet_1(bevd_0);
case 1018353830: return bem_has_1(bevd_0);
case -1642665544: return bem_get_1(bevd_0);
case -1812425724: return bem_notEquals_1(bevd_0);
case -2128196335: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1886873191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1679724785: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1839028328: return bem_slotsSet_1(bevd_0);
case 264973749: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1587661946: return bem_sameObject_1(bevd_0);
case 112712165: return bem_addValue_1(bevd_0);
case -165881314: return bem_delete_1(bevd_0);
case -1951248711: return bem_defined_1(bevd_0);
case -2038181641: return bem_copyTo_1(bevd_0);
case 698316509: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -565780685: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -907803894: return bem_otherType_1(bevd_0);
case -226295549: return bem_sameClass_1(bevd_0);
case -1017305888: return bem_sizeSet_1(bevd_0);
case -302611919: return bem_innerPutAddedSet_1(bevd_0);
case 1450526552: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 568764092: return bem_equals_1(bevd_0);
case -177732522: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -28236009: return bem_relSet_1(bevd_0);
case -2087149042: return bem_undefined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -862992684: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1613964396: return bem_put_2(bevd_0, bevd_1);
case 608937217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -507686943: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1346377346: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1911273797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1789964230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2066895296: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1538374916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -2104297131: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
}
