package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_8_SystemPlatform extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemPlatform() { }
private static byte[] becc_BEC_2_6_8_SystemPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_8_SystemPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_0 = {0x6D,0x61,0x63,0x6F,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_1 = {0x6C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_2 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_3 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_4 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_5 = {0x2F,0x64,0x65,0x76,0x2F,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_6 = {0x2E,0x73,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_7 = {0x4D,0x61,0x63,0x4F,0x53};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_8 = {0x4C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_9 = {0x46,0x72,0x65,0x65,0x42,0x53,0x44};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_11 = {0x6E,0x75,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_12 = {0x2E,0x62,0x61,0x74};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_13 = {0x4D,0x53,0x57,0x69,0x6E};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_14 = {0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_14, 9));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_15 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x2C,0x20,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x69,0x6E,0x20,0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_15, 60));
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 5));
public static BEC_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_inst;

public static BET_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_properName;
public BEC_2_5_4_LogicBool bevp_isNix;
public BEC_2_5_4_LogicBool bevp_isWin;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_otherSeparator;
public BEC_2_4_6_TextString bevp_nullFile;
public BEC_2_4_6_TextString bevp_scriptExt;
public BEC_2_6_8_SystemPlatform bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_new_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_9_SystemException bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_0;
bevt_2_ta_ph = bevp_name.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 346*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 346*/ {
bevt_5_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_1;
bevt_4_ta_ph = bevp_name.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 346*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 346*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 346*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 346*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 346*/ {
bevt_7_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_2;
bevt_6_ta_ph = bevp_name.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 346*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 346*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 346*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 346*/ {
bevp_isNix = be.BECS_Runtime.boolTrue;
bevp_isWin = be.BECS_Runtime.boolFalse;
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_otherSeparator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_nullFile = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_8_SystemPlatform_bels_5));
bevp_scriptExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_6));
bevt_9_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_3;
bevt_8_ta_ph = bevp_name.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 353*/ {
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_7));
} /* Line: 354*/
 else /* Line: 353*/ {
bevt_11_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_4;
bevt_10_ta_ph = bevp_name.bem_equals_1(bevt_11_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 355*/ {
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_8));
} /* Line: 356*/
 else /* Line: 353*/ {
bevt_13_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_5;
bevt_12_ta_ph = bevp_name.bem_equals_1(bevt_13_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 357*/ {
bevp_properName = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_8_SystemPlatform_bels_9));
} /* Line: 358*/
} /* Line: 353*/
} /* Line: 353*/
} /* Line: 353*/
 else /* Line: 346*/ {
bevt_15_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_6;
bevt_14_ta_ph = bevp_name.bem_equals_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_bool)/* Line: 360*/ {
bevp_isNix = be.BECS_Runtime.boolFalse;
bevp_isWin = be.BECS_Runtime.boolTrue;
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_otherSeparator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_nullFile = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_11));
bevp_scriptExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_8_SystemPlatform_bels_12));
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_13));
} /* Line: 367*/
 else /* Line: 368*/ {
bevt_19_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_7;
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevp_name);
bevt_20_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_8;
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_16_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_17_ta_ph);
throw new be.BECS_ThrowBack(bevt_16_ta_ph);
} /* Line: 369*/
} /* Line: 346*/
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_22_ta_ph = bece_BEC_2_6_8_SystemPlatform_bevo_9;
bevt_21_ta_ph = bevp_name.bem_equals_1(bevt_22_ta_ph);
if (bevt_21_ta_ph.bevi_bool)/* Line: 372*/ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(57793551);
} /* Line: 374*/
 else /* Line: 375*/ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(57793551);
} /* Line: 376*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_properNameGet_0() throws Throwable {
return bevp_properName;
} /*method end*/
public final BEC_2_4_6_TextString bem_properNameGetDirect_0() throws Throwable {
return bevp_properName;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_properNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_properName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_properNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_properName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNixGet_0() throws Throwable {
return bevp_isNix;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isNixGetDirect_0() throws Throwable {
return bevp_isNix;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isNixSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_isNixSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isWinGet_0() throws Throwable {
return bevp_isWin;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isWinGetDirect_0() throws Throwable {
return bevp_isWin;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isWinSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_isWinSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public final BEC_2_4_6_TextString bem_separatorGetDirect_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_otherSeparatorGet_0() throws Throwable {
return bevp_otherSeparator;
} /*method end*/
public final BEC_2_4_6_TextString bem_otherSeparatorGetDirect_0() throws Throwable {
return bevp_otherSeparator;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_otherSeparatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_otherSeparatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullFileGet_0() throws Throwable {
return bevp_nullFile;
} /*method end*/
public final BEC_2_4_6_TextString bem_nullFileGetDirect_0() throws Throwable {
return bevp_nullFile;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nullFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_nullFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_scriptExtGet_0() throws Throwable {
return bevp_scriptExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_scriptExtGetDirect_0() throws Throwable {
return bevp_scriptExt;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_scriptExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_scriptExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_scriptExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_scriptExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {340, 341, 346, 346, 0, 346, 346, 0, 0, 0, 346, 346, 0, 0, 347, 348, 349, 350, 351, 352, 353, 353, 354, 355, 355, 356, 357, 357, 358, 360, 360, 361, 362, 363, 364, 365, 366, 367, 369, 369, 369, 369, 369, 369, 371, 372, 372, 374, 376, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {52, 53, 81, 82, 84, 87, 88, 90, 93, 97, 100, 101, 103, 106, 110, 111, 112, 113, 114, 115, 116, 117, 119, 122, 123, 125, 128, 129, 131, 137, 138, 140, 141, 142, 143, 144, 145, 146, 149, 150, 151, 152, 153, 154, 157, 158, 159, 161, 164, 169, 172, 175, 179, 183, 186, 189, 193, 197, 200, 203, 207, 211, 214, 217, 221, 225, 228, 231, 235, 239, 242, 245, 249, 253, 256, 259, 263, 267, 270, 273, 277, 281, 284, 287, 291};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 340 52
buildProfile 0 341 53
assign 1 346 81
new 0 346 81
assign 1 346 82
equals 1 346 82
assign 1 0 84
assign 1 346 87
new 0 346 87
assign 1 346 88
equals 1 346 88
assign 1 0 90
assign 1 0 93
assign 1 0 97
assign 1 346 100
new 0 346 100
assign 1 346 101
equals 1 346 101
assign 1 0 103
assign 1 0 106
assign 1 347 110
new 0 347 110
assign 1 348 111
new 0 348 111
assign 1 349 112
new 0 349 112
assign 1 350 113
new 0 350 113
assign 1 351 114
new 0 351 114
assign 1 352 115
new 0 352 115
assign 1 353 116
new 0 353 116
assign 1 353 117
equals 1 353 117
assign 1 354 119
new 0 354 119
assign 1 355 122
new 0 355 122
assign 1 355 123
equals 1 355 123
assign 1 356 125
new 0 356 125
assign 1 357 128
new 0 357 128
assign 1 357 129
equals 1 357 129
assign 1 358 131
new 0 358 131
assign 1 360 137
new 0 360 137
assign 1 360 138
equals 1 360 138
assign 1 361 140
new 0 361 140
assign 1 362 141
new 0 362 141
assign 1 363 142
new 0 363 142
assign 1 364 143
new 0 364 143
assign 1 365 144
new 0 365 144
assign 1 366 145
new 0 366 145
assign 1 367 146
new 0 367 146
assign 1 369 149
new 0 369 149
assign 1 369 150
add 1 369 150
assign 1 369 151
new 0 369 151
assign 1 369 152
add 1 369 152
assign 1 369 153
new 1 369 153
throw 1 369 154
assign 1 371 157
new 0 371 157
assign 1 372 158
new 0 372 158
assign 1 372 159
equals 1 372 159
assign 1 374 161
unixNewlineGet 0 374 161
assign 1 376 164
unixNewlineGet 0 376 164
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
return 1 0 225
return 1 0 228
assign 1 0 231
assign 1 0 235
return 1 0 239
return 1 0 242
assign 1 0 245
assign 1 0 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
return 1 0 267
return 1 0 270
assign 1 0 273
assign 1 0 277
return 1 0 281
return 1 0 284
assign 1 0 287
assign 1 0 291
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 221458969: return bem_serializeToString_0();
case -1592951854: return bem_nullFileGet_0();
case 1295452166: return bem_properNameGet_0();
case -298341639: return bem_separatorGet_0();
case -1238524057: return bem_print_0();
case -471444759: return bem_newlineGetDirect_0();
case -1989328826: return bem_properNameGetDirect_0();
case 993286746: return bem_echo_0();
case -1137361298: return bem_scriptExtGet_0();
case -854269887: return bem_nameGetDirect_0();
case 1813327301: return bem_separatorGetDirect_0();
case 137910263: return bem_create_0();
case -992634121: return bem_tagGet_0();
case -1426056679: return bem_hashGet_0();
case -1405670295: return bem_otherSeparatorGetDirect_0();
case -1851472893: return bem_once_0();
case -891522185: return bem_newlineGet_0();
case 2106580913: return bem_scriptExtGetDirect_0();
case -1714583788: return bem_classNameGet_0();
case 814015164: return bem_copy_0();
case -438289515: return bem_fieldIteratorGet_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -777537417: return bem_serializeContents_0();
case 1993884067: return bem_nullFileGetDirect_0();
case -712981534: return bem_isWinGetDirect_0();
case 217381802: return bem_serializationIteratorGet_0();
case 205150354: return bem_new_0();
case 1875670545: return bem_buildProfile_0();
case -3484928: return bem_otherSeparatorGet_0();
case -123169734: return bem_isNixGetDirect_0();
case -1331626162: return bem_iteratorGet_0();
case -912342775: return bem_deserializeClassNameGet_0();
case -1079456517: return bem_many_0();
case 1871262881: return bem_isWinGet_0();
case 78412540: return bem_toAny_0();
case 351470539: return bem_isNixGet_0();
case -1392846471: return bem_toString_0();
case 310047227: return bem_fieldNamesGet_0();
case -1466994215: return bem_nameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1833693265: return bem_isWinSet_1(bevd_0);
case 591241880: return bem_newlineSetDirect_1(bevd_0);
case 662356552: return bem_isNixSet_1(bevd_0);
case 2042665444: return bem_nameSetDirect_1(bevd_0);
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case -1171879501: return bem_properNameSet_1(bevd_0);
case -850618166: return bem_otherSeparatorSetDirect_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 1166132959: return bem_properNameSetDirect_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 1456673616: return bem_nullFileSet_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case -165735800: return bem_scriptExtSetDirect_1(bevd_0);
case -1519726331: return bem_isWinSetDirect_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -202882393: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case 1856047963: return bem_isNixSetDirect_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 1631497559: return bem_newlineSet_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case -1941659026: return bem_nullFileSetDirect_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case 739418870: return bem_scriptExtSet_1(bevd_0);
case -1254319075: return bem_otherSeparatorSet_1(bevd_0);
case 763343837: return bem_nameSet_1(bevd_0);
case 966381947: return bem_separatorSetDirect_1(bevd_0);
case 827207962: return bem_separatorSet_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_8_SystemPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst = (BEC_2_6_8_SystemPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_type;
}
}
