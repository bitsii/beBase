package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;

public static BET_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_0() throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bem_new_0();
bevp_lock.bem_lock_0();
try /* Line: 910*/ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 912*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 915*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_oGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 921*/ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 923*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 926*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 933*/ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 936*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 939*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
bevl_res = be.BECS_Runtime.boolFalse;
try /* Line: 947*/ {
if (bevp_obj == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 948*/ {
bevp_obj = beva__obj;
bevl_res = be.BECS_Runtime.boolTrue;
} /* Line: 950*/
bevp_lock.bem_unlock_0();
} /* Line: 952*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 955*/
return bevl_res;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 962*/ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 964*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 967*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_oGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_oSet_1(beva__obj);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objGet_0() throws Throwable {
return bevp_obj;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_obj = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {900, 905, 909, 911, 912, 914, 915, 920, 922, 923, 925, 926, 928, 932, 934, 935, 936, 938, 939, 941, 945, 946, 948, 948, 949, 950, 952, 954, 955, 957, 961, 963, 964, 966, 967, 972, 972, 976, 976, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 56, 60, 61, 63, 69, 70, 72, 77, 78, 79, 81, 85, 86, 88, 92, 94, 95, 99, 100, 106, 107, 111, 112, 115, 118, 122, 125};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 900 16
new 0 900 16
new 0 905 21
lock 0 909 22
assign 1 911 24
unlock 0 912 25
unlock 0 914 29
throw 1 915 30
lock 0 920 37
assign 1 922 39
unlock 0 923 40
unlock 0 925 44
throw 1 926 45
return 1 928 47
lock 0 932 52
assign 1 934 54
assign 1 935 55
unlock 0 936 56
unlock 0 938 60
throw 1 939 61
return 1 941 63
lock 0 945 69
assign 1 946 70
new 0 946 70
assign 1 948 72
undef 1 948 77
assign 1 949 78
assign 1 950 79
new 0 950 79
unlock 0 952 81
unlock 0 954 85
throw 1 955 86
return 1 957 88
lock 0 961 92
assign 1 963 94
unlock 0 964 95
unlock 0 966 99
throw 1 967 100
assign 1 972 106
oGet 0 972 106
return 1 972 107
assign 1 976 111
oSet 1 976 111
return 1 976 112
return 1 0 115
assign 1 0 118
return 1 0 122
assign 1 0 125
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1571487075: return bem_oGet_0();
case -846281908: return bem_copy_0();
case -2013154284: return bem_objGet_0();
case -1957915024: return bem_create_0();
case -2065042097: return bem_objectGet_0();
case 219302946: return bem_lockGet_0();
case 784391444: return bem_print_0();
case -16745781: return bem_getAndClear_0();
case 1215849051: return bem_iteratorGet_0();
case 1829488886: return bem_hashGet_0();
case -804900710: return bem_new_0();
case 351045163: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2004422791: return bem_oSet_1(bevd_0);
case -821812891: return bem_undef_1(bevd_0);
case 44182594: return bem_def_1(bevd_0);
case -1057469813: return bem_lockSet_1(bevd_0);
case -2032978866: return bem_notEquals_1(bevd_0);
case 1706358534: return bem_objectSet_1(bevd_0);
case -788369265: return bem_new_1(bevd_0);
case 930245137: return bem_objSet_1(bevd_0);
case 562333251: return bem_copyTo_1(bevd_0);
case 561835924: return bem_equals_1(bevd_0);
case 1546949454: return bem_setIfClear_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1930607363: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1463161769: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -439174742: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1813861893: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;
}
}
