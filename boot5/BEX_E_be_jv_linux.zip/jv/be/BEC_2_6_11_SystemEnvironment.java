package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public final class BEC_2_6_11_SystemEnvironment extends BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemEnvironment() { }
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x6E,0x76,0x69,0x72,0x6F,0x6E,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_inst;

public static BET_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_type;

public BEC_2_4_6_TextString bem_getVariable_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevl_value = null;

            String value = System.getenv().get(beva_name.bems_toJvString());
            if (value != null) {
                bevl_value = new BEC_2_4_6_TextString(value);
            }
        return bevl_value;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {425};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
return 1 425 20
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -162465408: return bem_classNameGet_0();
case -1118611827: return bem_copy_0();
case 216387563: return bem_many_0();
case 1901482140: return bem_tagGet_0();
case -702348589: return bem_toString_0();
case -275244597: return bem_hashGet_0();
case 1899370103: return bem_echo_0();
case -2036889336: return bem_toAny_0();
case -1528945516: return bem_fieldNamesGet_0();
case -1653065356: return bem_serializeToString_0();
case -1009286812: return bem_iteratorGet_0();
case 1555639231: return bem_print_0();
case -1774143633: return bem_once_0();
case -2101622436: return bem_sourceFileNameGet_0();
case -138934452: return bem_serializationIteratorGet_0();
case -826924838: return bem_fieldIteratorGet_0();
case 357618761: return bem_new_0();
case -716934857: return bem_serializeContents_0();
case 1881523822: return bem_deserializeClassNameGet_0();
case 71860751: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -959745115: return bem_otherType_1(bevd_0);
case -1082439894: return bem_sameObject_1(bevd_0);
case -68723535: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1319105880: return bem_getVariable_1((BEC_2_4_6_TextString) bevd_0);
case 1193778385: return bem_undefined_1(bevd_0);
case 1137403549: return bem_copyTo_1(bevd_0);
case 1353620660: return bem_sameClass_1(bevd_0);
case -2109980302: return bem_undef_1(bevd_0);
case 2082558825: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1339829082: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 66254795: return bem_sameType_1(bevd_0);
case 1459678776: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2027670755: return bem_defined_1(bevd_0);
case -2130714868: return bem_equals_1(bevd_0);
case 1325575386: return bem_def_1(bevd_0);
case 814727407: return bem_notEquals_1(bevd_0);
case -1493100314: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 70790709: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020619337: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 163657925: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1186365239: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 686267336: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271558857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1157880701: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemEnvironment_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_11_SystemEnvironment_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_11_SystemEnvironment();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst = (BEC_2_6_11_SystemEnvironment) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_type;
}
}
