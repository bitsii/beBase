package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public final class BEC_2_6_11_SystemEnvironment extends BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemEnvironment() { }
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x6E,0x76,0x69,0x72,0x6F,0x6E,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_inst;

public static BET_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_type;

public BEC_2_4_6_TextString bem_getVariable_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevl_value = null;

            String value = System.getenv().get(beva_name.bems_toJvString());
            if (value != null) {
                bevl_value = new BEC_2_4_6_TextString(value);
            }
        return bevl_value;
} /*method end*/
public BEC_2_4_6_TextString bem_getVar_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getVariable_1(beva_name);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {581, 585, 585};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 24, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
return 1 581 20
assign 1 585 24
getVariable 1 585 24
return 1 585 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1967481250: return bem_hashGet_0();
case 1890623763: return bem_copy_0();
case 1515047198: return bem_create_0();
case 186551951: return bem_toString_0();
case 670650041: return bem_new_0();
case -643744552: return bem_iteratorGet_0();
case 2139846672: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1675245807: return bem_getVariable_1((BEC_2_4_6_TextString) bevd_0);
case 951741113: return bem_notEquals_1(bevd_0);
case 1041331381: return bem_undef_1(bevd_0);
case -671810231: return bem_getVar_1((BEC_2_4_6_TextString) bevd_0);
case -1583823897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 7869303: return bem_equals_1(bevd_0);
case 1882156513: return bem_copyTo_1(bevd_0);
case -1876852691: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1779285405: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 582832509: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -881314990: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1602342275: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1686414234: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemEnvironment_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_11_SystemEnvironment_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_11_SystemEnvironment();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst = (BEC_2_6_11_SystemEnvironment) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_type;
}
}
