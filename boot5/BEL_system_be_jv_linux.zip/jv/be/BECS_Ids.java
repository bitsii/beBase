// Copyright 2015 The Abelii Authors. All rights reserved.
// Use of this source code is governed by the BSD-3-Clause
// license that can be found in the LICENSE file.

package be;

import be.BEC_2_6_6_SystemObject;

import java.util.*;

public class BECS_Ids {
    
    public static Map<String, Integer> callIds;
    public static Map<Integer, String> idCalls;
    
}

