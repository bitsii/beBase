namespace be {
/* IO:File: source/base/Logic.be */
public sealed class BEC_2_5_4_LogicBool : BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }
static BEC_2_5_4_LogicBool() { }

   
    public bool bevi_bool;
    public BEC_2_5_4_LogicBool(bool bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bels_2 = {0x31};
private static byte[] bels_3 = {0x30};
private static byte[] bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bels_5 = {0x74,0x72,0x75,0x65};
private static byte[] bels_6 = {0x66,0x61,0x6C,0x73,0x65};
public static new BEC_2_5_4_LogicBool bevs_inst;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 43 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 44 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 51 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (this.bevi_bool) /* Line: 61 */ {
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_2));
return bevt_0_tmpany_phold;
} /* Line: 62 */
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_4));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (this.bevi_bool) /* Line: 72 */ {
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 73 */
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (this.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 88 */
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (this.bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_5));
return bevt_0_tmpany_phold;
} /* Line: 95 */
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_6));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {43, 43, 44, 44, 46, 46, 50, 50, 50, 50, 0, 0, 0, 51, 51, 53, 53, 57, 57, 62, 62, 64, 64, 68, 68, 73, 73, 75, 75, 79, 79, 83, 83, 88, 88, 90, 90, 95, 95, 97, 97, 101};
public static new int[] bevs_smnlec
 = new int[] {29, 30, 32, 33, 35, 36, 45, 50, 51, 52, 54, 57, 61, 64, 65, 67, 68, 72, 73, 79, 80, 82, 83, 87, 88, 94, 95, 97, 98, 102, 103, 107, 108, 114, 115, 117, 118, 124, 125, 127, 128, 131};
/* BEGIN LINEINFO 
assign 1 43 29
new 0 43 29
assign 1 43 30
equals 1 43 30
assign 1 44 32
new 0 44 32
return 1 44 33
assign 1 46 35
new 0 46 35
return 1 46 36
assign 1 50 45
def 1 50 50
assign 1 50 51
new 0 50 51
assign 1 50 52
equals 1 50 52
assign 1 0 54
assign 1 0 57
assign 1 0 61
assign 1 51 64
new 0 51 64
return 1 51 65
assign 1 53 67
new 0 53 67
return 1 53 68
assign 1 57 72
new 0 57 72
return 1 57 73
assign 1 62 79
new 0 62 79
return 1 62 80
assign 1 64 82
new 0 64 82
return 1 64 83
assign 1 68 87
new 0 68 87
return 1 68 88
assign 1 73 94
new 0 73 94
return 1 73 95
assign 1 75 97
new 0 75 97
return 1 75 98
assign 1 79 102
new 0 79 102
return 1 79 103
assign 1 83 107
new 0 83 107
return 1 83 108
assign 1 88 114
new 0 88 114
return 1 88 115
assign 1 90 117
new 0 90 117
return 1 90 118
assign 1 95 124
new 0 95 124
return 1 95 125
assign 1 97 127
new 0 97 127
return 1 97 128
return 1 101 131
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 105008580: return bem_not_0();
case -1046151292: return bem_decrement_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1085372256: return bem_increment_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -1254042251: return bem_checkDefNew_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_LogicBool();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_LogicBool.bevs_inst = (BEC_2_5_4_LogicBool)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_LogicBool.bevs_inst;
}
}
}
