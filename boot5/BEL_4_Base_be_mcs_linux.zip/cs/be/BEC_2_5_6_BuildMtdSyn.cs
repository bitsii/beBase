namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_6_BuildMtdSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMtdSyn() { }
static BEC_2_5_6_BuildMtdSyn() { }
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x74,0x64,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_0, 6));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_1, 4));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_2 = {0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_2, 7));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_3 = {0x6E,0x75,0x6D,0x61,0x72,0x67,0x73};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMtdSyn_bels_3, 7));
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_4 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_5 = {0x6C,0x61,0x73,0x74,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_6 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_7 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_8 = {0x69,0x73,0x47,0x65,0x6E,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_9 = {0x72,0x73,0x79,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_10 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_11 = {0x61,0x72,0x67,0x54,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_12 = {0x61,0x6E,0x79};
public static new BEC_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;
public BEC_2_4_3_MathInt bevp_hpos;
public BEC_2_4_3_MathInt bevp_mtdx;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_9_4_ContainerList bevp_argSyns;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_5_4_LogicBool bevp_lastDef;
public BEC_2_5_4_LogicBool bevp_isOverride;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_6_TextString bevp_propertyName;
public BEC_2_5_6_BuildVarSyn bevp_rsyn;
public BEC_2_5_6_BuildMtdSyn bem_new_2(BEC_2_6_6_SystemObject beva_snode, BEC_2_6_6_SystemObject beva__origin) {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_args = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_6_BuildVarSyn bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevl_s = beva_snode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_numargs = (BEC_2_4_3_MathInt) bevl_s.bemd_0(-548714012, BEL_4_Base.bevn_numargsGet_0);
bevp_name = (BEC_2_4_6_TextString) bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_orgName = (BEC_2_4_6_TextString) bevl_s.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(1714571098, BEL_4_Base.bevn_isGenAccessorGet_0);
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = bevp_numargs.bem_add_1(bevt_1_tmpany_phold);
bevp_argSyns = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_lastDef = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_isOverride = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isFinal = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_3_tmpany_phold = bevl_s.bemd_0(-1041978190, BEL_4_Base.bevn_propertyGet_0);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 431 */ {
bevt_4_tmpany_phold = bevl_s.bemd_0(-1041978190, BEL_4_Base.bevn_propertyGet_0);
bevp_propertyName = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
} /* Line: 432 */
bevt_6_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 434 */ {
bevt_7_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_7_tmpany_phold);
} /* Line: 435 */
bevt_9_tmpany_phold = beva_snode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_args = bevt_8_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 440 */ {
bevt_11_tmpany_phold = bevp_argSyns.bem_lengthGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_11_tmpany_phold);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 440 */ {
bevt_14_tmpany_phold = bevl_args.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_12_tmpany_phold = (BEC_2_5_6_BuildVarSyn) (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_13_tmpany_phold);
bevp_argSyns.bem_put_2((BEC_2_4_3_MathInt) bevl_i, bevt_12_tmpany_phold);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 440 */
 else  /* Line: 440 */ {
break;
} /* Line: 440 */
} /* Line: 440 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_arg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_1_tmpany_phold.bem_newlineGet_0();
bevt_14_tmpany_phold = bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_nl);
bevt_15_tmpany_phold = bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevl_nl);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevp_name);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_nl);
bevt_16_tmpany_phold = bevo_3;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_16_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_nl);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_orgName);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevl_nl);
bevt_17_tmpany_phold = bevo_4;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevl_nl);
bevt_18_tmpany_phold = bevp_numargs.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevl_toRet = bevt_2_tmpany_phold.bem_add_1(bevl_nl);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_4));
bevt_21_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_22_tmpany_phold);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_23_tmpany_phold = bevp_origin.bem_toString_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpany_phold);
bevl_toRet = bevt_19_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_5));
bevt_26_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_27_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_28_tmpany_phold = bevp_lastDef.bem_toString_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_28_tmpany_phold);
bevl_toRet = bevt_24_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_6));
bevt_31_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_32_tmpany_phold);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_33_tmpany_phold = bevp_isFinal.bem_toString_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpany_phold);
bevl_toRet = bevt_29_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
if (bevp_propertyName == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 452 */ {
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_6_BuildMtdSyn_bels_7));
bevt_37_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_38_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_propertyName);
bevl_toRet = bevt_35_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 453 */
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_6_BuildMtdSyn_bels_8));
bevt_41_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_42_tmpany_phold);
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_43_tmpany_phold = bevp_isGenAccessor.bem_toString_0();
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_43_tmpany_phold);
bevl_toRet = bevt_39_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_9));
bevt_44_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_45_tmpany_phold);
bevl_toRet = bevt_44_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
if (bevp_rsyn == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_47_tmpany_phold = bevp_rsyn.bem_isTypedGet_0();
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 457 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 457 */ {
bevt_50_tmpany_phold = bevp_rsyn.bem_namepathGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_toString_0();
bevt_48_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_49_tmpany_phold);
bevl_toRet = bevt_48_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 458 */
 else  /* Line: 459 */ {
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_51_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_52_tmpany_phold);
bevl_toRet = bevt_51_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 460 */
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 462 */ {
bevt_54_tmpany_phold = bevp_argSyns.bem_lengthGet_0();
bevt_53_tmpany_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_54_tmpany_phold);
if (bevt_53_tmpany_phold != null && bevt_53_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_53_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevl_arg = bevp_argSyns.bem_get_1((BEC_2_4_3_MathInt) bevl_i);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_11));
bevt_55_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_56_tmpany_phold);
bevl_toRet = bevt_55_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_57_tmpany_phold = bevl_arg.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_57_tmpany_phold != null && bevt_57_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_57_tmpany_phold).bevi_bool) /* Line: 466 */ {
bevt_60_tmpany_phold = bevl_arg.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_58_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_59_tmpany_phold);
bevl_toRet = bevt_58_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 467 */
 else  /* Line: 468 */ {
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_12));
bevt_61_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_62_tmpany_phold);
bevl_toRet = bevt_61_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 469 */
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 462 */
 else  /* Line: 462 */ {
break;
} /* Line: 462 */
} /* Line: 462 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_getEmitReturnType_2(BEC_2_5_8_BuildClassSyn beva_csyn, BEC_2_5_5_BuildBuild beva_build) {
BEC_2_5_4_LogicBool bevl_coanyiantReturns = null;
BEC_2_5_10_BuildEmitCommon bevl_ec = null;
BEC_2_5_8_BuildClassSyn bevl_cs = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_3_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_7_tmpany_phold = null;
BEC_2_5_6_BuildVarSyn bevt_8_tmpany_phold = null;
bevl_coanyiantReturns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_ec = beva_build.bem_emitCommonGet_0();
if (bevl_ec == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 478 */ {
bevl_coanyiantReturns = (BEC_2_5_4_LogicBool) bevl_ec.bem_coanyiantReturnsGet_0();
} /* Line: 479 */
if (bevp_rsyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 481 */ {
if (bevl_coanyiantReturns.bevi_bool) /* Line: 482 */ {
bevt_2_tmpany_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 483 */ {
bevt_3_tmpany_phold = beva_csyn.bem_namepathGet_0();
return bevt_3_tmpany_phold;
} /* Line: 484 */
 else  /* Line: 485 */ {
bevt_4_tmpany_phold = bevp_rsyn.bem_namepathGet_0();
return bevt_4_tmpany_phold;
} /* Line: 486 */
} /* Line: 483 */
 else  /* Line: 488 */ {
bevt_5_tmpany_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 489 */ {
return bevp_declaration;
} /* Line: 490 */
 else  /* Line: 491 */ {
bevl_cs = beva_build.bem_getSynNp_1(bevp_declaration);
bevt_6_tmpany_phold = bevl_cs.bem_mtdMapGet_0();
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevt_6_tmpany_phold.bem_get_1(bevp_name);
bevt_8_tmpany_phold = bevl_ms.bem_rsynGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_namepathGet_0();
return bevt_7_tmpany_phold;
} /* Line: 494 */
} /* Line: 489 */
} /* Line: 482 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_hposGet_0() {
return bevp_hpos;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_hposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxGet_0() {
return bevp_mtdx;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_mtdxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argSynsGet_0() {
return bevp_argSyns;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_argSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() {
return bevp_declaration;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lastDefGet_0() {
return bevp_lastDef;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_lastDefSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOverrideGet_0() {
return bevp_isOverride;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isOverrideSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_propertyNameGet_0() {
return bevp_propertyName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_propertyNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_rsynGet_0() {
return bevp_rsyn;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_rsynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {414, 420, 421, 422, 423, 424, 424, 424, 426, 428, 429, 430, 431, 431, 431, 432, 432, 434, 434, 434, 435, 435, 439, 439, 439, 440, 440, 440, 441, 441, 441, 441, 440, 447, 447, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 448, 449, 449, 449, 449, 449, 449, 450, 450, 450, 450, 450, 450, 451, 451, 451, 451, 451, 451, 452, 452, 453, 453, 453, 453, 453, 455, 455, 455, 455, 455, 455, 456, 456, 456, 457, 457, 457, 0, 0, 0, 458, 458, 458, 458, 460, 460, 460, 462, 462, 462, 463, 465, 465, 465, 466, 467, 467, 467, 467, 469, 469, 469, 462, 472, 476, 477, 478, 478, 479, 481, 481, 483, 484, 484, 486, 486, 489, 490, 492, 493, 493, 494, 494, 494, 498, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 78, 79, 80, 82, 83, 88, 89, 90, 92, 93, 94, 95, 98, 99, 101, 102, 103, 104, 105, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 224, 225, 226, 227, 228, 229, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 245, 246, 248, 251, 255, 258, 259, 260, 261, 264, 265, 266, 268, 271, 272, 274, 275, 276, 277, 278, 280, 281, 282, 283, 286, 287, 288, 290, 296, 312, 313, 314, 319, 320, 322, 327, 329, 331, 332, 335, 336, 340, 342, 345, 346, 347, 348, 349, 350, 354, 357, 360, 364, 367, 371, 374, 378, 381, 385, 388, 392, 395, 399, 402, 406, 409, 413, 416, 420, 423, 427, 430, 434, 437, 441, 444, 448, 451};
/* BEGIN LINEINFO 
assign 1 414 60
heldGet 0 414 60
assign 1 420 61
numargsGet 0 420 61
assign 1 421 62
nameGet 0 421 62
assign 1 422 63
orgNameGet 0 422 63
assign 1 423 64
isGenAccessorGet 0 423 64
assign 1 424 65
new 0 424 65
assign 1 424 66
add 1 424 66
assign 1 424 67
new 1 424 67
assign 1 426 68
assign 1 428 69
new 0 428 69
assign 1 429 70
new 0 429 70
assign 1 430 71
isFinalGet 0 430 71
assign 1 431 72
propertyGet 0 431 72
assign 1 431 73
def 1 431 78
assign 1 432 79
propertyGet 0 432 79
assign 1 432 80
nameGet 0 432 80
assign 1 434 82
rtypeGet 0 434 82
assign 1 434 83
def 1 434 88
assign 1 435 89
rtypeGet 0 435 89
assign 1 435 90
anyNew 1 435 90
assign 1 439 92
containedGet 0 439 92
assign 1 439 93
firstGet 0 439 93
assign 1 439 94
containedGet 0 439 94
assign 1 440 95
new 0 440 95
assign 1 440 98
lengthGet 0 440 98
assign 1 440 99
lesser 1 440 99
assign 1 441 101
get 1 441 101
assign 1 441 102
heldGet 0 441 102
assign 1 441 103
anyNew 1 441 103
put 2 441 104
assign 1 440 105
increment 0 440 105
assign 1 447 181
new 0 447 181
assign 1 447 182
newlineGet 0 447 182
assign 1 448 183
new 0 448 183
assign 1 448 184
add 1 448 184
assign 1 448 185
new 0 448 185
assign 1 448 186
add 1 448 186
assign 1 448 187
add 1 448 187
assign 1 448 188
add 1 448 188
assign 1 448 189
add 1 448 189
assign 1 448 190
new 0 448 190
assign 1 448 191
add 1 448 191
assign 1 448 192
add 1 448 192
assign 1 448 193
add 1 448 193
assign 1 448 194
add 1 448 194
assign 1 448 195
new 0 448 195
assign 1 448 196
add 1 448 196
assign 1 448 197
add 1 448 197
assign 1 448 198
toString 0 448 198
assign 1 448 199
add 1 448 199
assign 1 448 200
add 1 448 200
assign 1 449 201
new 0 449 201
assign 1 449 202
add 1 449 202
assign 1 449 203
add 1 449 203
assign 1 449 204
toString 0 449 204
assign 1 449 205
add 1 449 205
assign 1 449 206
add 1 449 206
assign 1 450 207
new 0 450 207
assign 1 450 208
add 1 450 208
assign 1 450 209
add 1 450 209
assign 1 450 210
toString 0 450 210
assign 1 450 211
add 1 450 211
assign 1 450 212
add 1 450 212
assign 1 451 213
new 0 451 213
assign 1 451 214
add 1 451 214
assign 1 451 215
add 1 451 215
assign 1 451 216
toString 0 451 216
assign 1 451 217
add 1 451 217
assign 1 451 218
add 1 451 218
assign 1 452 219
def 1 452 224
assign 1 453 225
new 0 453 225
assign 1 453 226
add 1 453 226
assign 1 453 227
add 1 453 227
assign 1 453 228
add 1 453 228
assign 1 453 229
add 1 453 229
assign 1 455 231
new 0 455 231
assign 1 455 232
add 1 455 232
assign 1 455 233
add 1 455 233
assign 1 455 234
toString 0 455 234
assign 1 455 235
add 1 455 235
assign 1 455 236
add 1 455 236
assign 1 456 237
new 0 456 237
assign 1 456 238
add 1 456 238
assign 1 456 239
add 1 456 239
assign 1 457 240
def 1 457 245
assign 1 457 246
isTypedGet 0 457 246
assign 1 0 248
assign 1 0 251
assign 1 0 255
assign 1 458 258
namepathGet 0 458 258
assign 1 458 259
toString 0 458 259
assign 1 458 260
add 1 458 260
assign 1 458 261
add 1 458 261
assign 1 460 264
new 0 460 264
assign 1 460 265
add 1 460 265
assign 1 460 266
add 1 460 266
assign 1 462 268
new 0 462 268
assign 1 462 271
lengthGet 0 462 271
assign 1 462 272
lesser 1 462 272
assign 1 463 274
get 1 463 274
assign 1 465 275
new 0 465 275
assign 1 465 276
add 1 465 276
assign 1 465 277
add 1 465 277
assign 1 466 278
isTypedGet 0 466 278
assign 1 467 280
namepathGet 0 467 280
assign 1 467 281
toString 0 467 281
assign 1 467 282
add 1 467 282
assign 1 467 283
add 1 467 283
assign 1 469 286
new 0 469 286
assign 1 469 287
add 1 469 287
assign 1 469 288
add 1 469 288
assign 1 462 290
increment 0 462 290
return 1 472 296
assign 1 476 312
new 0 476 312
assign 1 477 313
emitCommonGet 0 477 313
assign 1 478 314
def 1 478 319
assign 1 479 320
coanyiantReturnsGet 0 479 320
assign 1 481 322
def 1 481 327
assign 1 483 329
isSelfGet 0 483 329
assign 1 484 331
namepathGet 0 484 331
return 1 484 332
assign 1 486 335
namepathGet 0 486 335
return 1 486 336
assign 1 489 340
isSelfGet 0 489 340
return 1 490 342
assign 1 492 345
getSynNp 1 492 345
assign 1 493 346
mtdMapGet 0 493 346
assign 1 493 347
get 1 493 347
assign 1 494 348
rsynGet 0 494 348
assign 1 494 349
namepathGet 0 494 349
return 1 494 350
return 1 498 354
return 1 0 357
assign 1 0 360
return 1 0 364
assign 1 0 367
return 1 0 371
assign 1 0 374
return 1 0 378
assign 1 0 381
return 1 0 385
assign 1 0 388
return 1 0 392
assign 1 0 395
return 1 0 399
assign 1 0 402
return 1 0 406
assign 1 0 409
return 1 0 413
assign 1 0 416
return 1 0 420
assign 1 0 423
return 1 0 427
assign 1 0 430
return 1 0 434
assign 1 0 437
return 1 0 441
assign 1 0 444
return 1 0 448
assign 1 0 451
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1707345409: return bem_originGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1719265275: return bem_hposGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -1391492296: return bem_orgNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -82450415: return bem_isOverrideGet_0();
case -1081412016: return bem_many_0();
case -896461779: return bem_declarationGet_0();
case -1187343513: return bem_propertyNameGet_0();
case 1714571098: return bem_isGenAccessorGet_0();
case 287367803: return bem_isFinalGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 815066086: return bem_argSynsGet_0();
case -1100651208: return bem_lastDefGet_0();
case 1820417453: return bem_create_0();
case 1900010001: return bem_rsynGet_0();
case -786424307: return bem_tagGet_0();
case -1376225844: return bem_mtdxGet_0();
case -1354714650: return bem_copy_0();
case -548714012: return bem_numargsGet_0();
case 1211273660: return bem_nameGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1911092254: return bem_rsynSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1718427662: return bem_originSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 826148339: return bem_argSynsSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -71368162: return bem_isOverrideSet_1(bevd_0);
case -1365143591: return bem_mtdxSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1730347528: return bem_hposSet_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case -1380410043: return bem_orgNameSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -537631759: return bem_numargsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1089568955: return bem_lastDefSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 1725653351: return bem_isGenAccessorSet_1(bevd_0);
case -1176261260: return bem_propertyNameSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -885379526: return bem_declarationSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -583049050: return bem_getEmitReturnType_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case 104713555: return bem_new_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMtdSyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildMtdSyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildMtdSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst = (BEC_2_5_6_BuildMtdSyn)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;
}
}
}
