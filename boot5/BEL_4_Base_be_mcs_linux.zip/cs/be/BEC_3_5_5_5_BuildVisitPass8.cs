namespace be {
/* IO:File: source/build/Pass8.be */
public sealed class BEC_3_5_5_5_BuildVisitPass8 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass8() { }
static BEC_3_5_5_5_BuildVisitPass8() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bels_24 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_25 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_26 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_27 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_28 = {0x3D,0x40};
private static byte[] bels_29 = {0x3D,0x23};
public static new BEC_3_5_5_5_BuildVisitPass8 bevs_inst;
public BEC_2_6_6_SystemObject bem_acceptClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_8_BuildEmitData bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_0_tmpany_phold.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepOps_0() {
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_ops = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 23 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_1_tmpany_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 23 */ {
bevt_3_tmpany_phold = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_3_tmpany_phold);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 23 */
 else  /* Line: 23 */ {
break;
} /* Line: 23 */
} /* Line: 23 */
return bevl_ops;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_prec = null;
BEC_2_6_6_SystemObject bevl_cont = null;
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_onode = null;
BEC_2_6_6_SystemObject bevl_mo = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_mt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_3_tmpany_phold.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 33 */ {
this.bem_acceptClass_1(beva_node);
bevt_5_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpany_phold;
} /* Line: 35 */
bevt_6_tmpany_phold = bevp_const.bem_operGet_0();
bevt_7_tmpany_phold = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_tmpany_phold.bem_get_1(bevt_7_tmpany_phold);
if (bevl_prec == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = this.bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
 /* Line: 48 */ {
if (bevl_onode == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 48 */ {
if (bevl_prec == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevt_12_tmpany_phold = bevl_onode.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_cont);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevt_13_tmpany_phold = bevl_ops.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_prec);
bevt_13_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_onode);
bevl_inode = bevl_onode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevl_inode = bevl_inode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_17_tmpany_phold = bevl_inode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_18_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_18_tmpany_phold);
if (bevt_16_tmpany_phold != null && bevt_16_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_16_tmpany_phold).bevi_bool) /* Line: 54 */ {
bevl_inode = bevl_inode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevl_inode = bevl_inode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 57 */
} /* Line: 56 */
} /* Line: 54 */
} /* Line: 53 */
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 63 */ {
bevt_21_tmpany_phold = bevp_const.bem_operGet_0();
bevt_22_tmpany_phold = bevl_onode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevl_prec = bevt_21_tmpany_phold.bem_get_1(bevt_22_tmpany_phold);
} /* Line: 64 */
 else  /* Line: 65 */ {
bevl_prec = null;
} /* Line: 66 */
} /* Line: 63 */
 else  /* Line: 48 */ {
break;
} /* Line: 48 */
} /* Line: 48 */
bevl_prec = (new BEC_2_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 70 */ {
bevt_23_tmpany_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpany_phold).bevi_bool) /* Line: 70 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpany_phold = bevl_i.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpany_phold);
if (bevt_24_tmpany_phold != null && bevt_24_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpany_phold).bevi_bool) /* Line: 72 */ {
bevl_mt = bevl_i.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 73 */ {
bevt_27_tmpany_phold = bevl_mt.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_27_tmpany_phold != null && bevt_27_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_27_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevl_mo = bevl_mt.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_28_tmpany_phold = bevl_mo.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
bevt_29_tmpany_phold = bevl_mo.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_mo = this.bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_tmpany_phold, bevt_29_tmpany_phold);
beva_node = (BEC_2_5_4_BuildNode) bevl_mo;
} /* Line: 76 */
 else  /* Line: 73 */ {
break;
} /* Line: 73 */
} /* Line: 73 */
} /* Line: 73 */
bevl_prec = bevl_prec.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 79 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
} /* Line: 70 */
bevt_30_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callFromOper_4(BEC_2_6_6_SystemObject beva_op, BEC_2_6_6_SystemObject beva_prec, BEC_2_6_6_SystemObject beva_pr, BEC_2_6_6_SystemObject beva_nx) {
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-1795527427, BEL_4_Base.bevn_wasOperSet_1, bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bevp_const.bem_operNamesGet_0();
bevt_6_tmpany_phold = beva_op.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_get_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(357005938, BEL_4_Base.bevn_lower_0);
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_3_tmpany_phold);
bevt_8_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_0));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_9_tmpany_phold);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_1));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_10_tmpany_phold);
} /* Line: 92 */
bevt_12_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_2));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_3));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_14_tmpany_phold);
} /* Line: 95 */
bevt_16_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_4));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpany_phold);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 97 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_5));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_18_tmpany_phold);
} /* Line: 98 */
bevt_20_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_6));
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpany_phold);
if (bevt_19_tmpany_phold != null && bevt_19_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_19_tmpany_phold).bevi_bool) /* Line: 100 */ {
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_7));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_22_tmpany_phold);
} /* Line: 101 */
bevt_24_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_25_tmpany_phold);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpany_phold).bevi_bool) /* Line: 103 */ {
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_9));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_26_tmpany_phold);
} /* Line: 104 */
bevt_28_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_10));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_29_tmpany_phold);
if (bevt_27_tmpany_phold != null && bevt_27_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_27_tmpany_phold).bevi_bool) /* Line: 106 */ {
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_11));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_30_tmpany_phold);
} /* Line: 107 */
bevt_32_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_12));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_33_tmpany_phold);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpany_phold).bevi_bool) /* Line: 109 */ {
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_13));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_34_tmpany_phold);
} /* Line: 110 */
bevt_36_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_14));
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_37_tmpany_phold);
if (bevt_35_tmpany_phold != null && bevt_35_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpany_phold).bevi_bool) /* Line: 112 */ {
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_15));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_38_tmpany_phold);
} /* Line: 113 */
bevt_40_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_16));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpany_phold);
if (bevt_39_tmpany_phold != null && bevt_39_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_39_tmpany_phold).bevi_bool) /* Line: 115 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_17));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_42_tmpany_phold);
} /* Line: 116 */
bevt_44_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_18));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_45_tmpany_phold);
if (bevt_43_tmpany_phold != null && bevt_43_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_43_tmpany_phold).bevi_bool) /* Line: 118 */ {
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_19));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_46_tmpany_phold);
} /* Line: 119 */
bevt_48_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_20));
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_49_tmpany_phold);
if (bevt_47_tmpany_phold != null && bevt_47_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpany_phold).bevi_bool) /* Line: 121 */ {
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_21));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpany_phold);
} /* Line: 122 */
bevt_52_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_22));
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_53_tmpany_phold);
if (bevt_51_tmpany_phold != null && bevt_51_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_51_tmpany_phold).bevi_bool) /* Line: 124 */ {
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_23));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_54_tmpany_phold);
} /* Line: 125 */
bevt_56_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_24));
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_57_tmpany_phold);
if (bevt_55_tmpany_phold != null && bevt_55_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_55_tmpany_phold).bevi_bool) /* Line: 127 */ {
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_25));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_58_tmpany_phold);
} /* Line: 128 */
bevt_60_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_26));
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpany_phold);
if (bevt_59_tmpany_phold != null && bevt_59_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpany_phold).bevi_bool) /* Line: 130 */ {
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_27));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_62_tmpany_phold);
} /* Line: 131 */
bevt_63_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_63_tmpany_phold);
bevt_65_tmpany_phold = beva_op.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_66_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_66_tmpany_phold);
if (bevt_64_tmpany_phold != null && bevt_64_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_64_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_68_tmpany_phold = beva_op.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_28));
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpany_phold);
if (bevt_67_tmpany_phold != null && bevt_67_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_70_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1489916809, BEL_4_Base.bevn_isOnceSet_1, bevt_70_tmpany_phold);
} /* Line: 137 */
bevt_72_tmpany_phold = beva_op.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_73_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_73_tmpany_phold);
if (bevt_71_tmpany_phold != null && bevt_71_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_71_tmpany_phold).bevi_bool) /* Line: 139 */ {
bevt_75_tmpany_phold = beva_op.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_29));
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpany_phold);
if (bevt_74_tmpany_phold != null && bevt_74_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpany_phold).bevi_bool) /* Line: 139 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 139 */
 else  /* Line: 139 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 139 */ {
bevt_77_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1373349483, BEL_4_Base.bevn_isManySet_1, bevt_77_tmpany_phold);
} /* Line: 141 */
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpany_phold);
beva_op.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_pr.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_op.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_pr);
bevt_80_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_79_tmpany_phold = beva_prec.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_80_tmpany_phold);
if (bevt_79_tmpany_phold != null && bevt_79_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpany_phold).bevi_bool) /* Line: 147 */ {
beva_nx.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_op.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_nx);
} /* Line: 149 */
return beva_op;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 18, 22, 22, 23, 23, 23, 24, 24, 23, 26, 33, 33, 33, 33, 34, 35, 35, 37, 37, 37, 38, 38, 43, 44, 45, 47, 48, 48, 48, 48, 0, 0, 0, 48, 48, 0, 0, 0, 49, 49, 50, 51, 51, 52, 53, 53, 54, 54, 54, 55, 56, 56, 57, 62, 63, 63, 64, 64, 64, 66, 69, 70, 70, 71, 72, 72, 72, 73, 73, 74, 75, 75, 75, 76, 79, 84, 84, 88, 89, 89, 90, 90, 90, 90, 90, 91, 91, 91, 92, 92, 94, 94, 94, 95, 95, 97, 97, 97, 98, 98, 100, 100, 100, 101, 101, 103, 103, 103, 104, 104, 106, 106, 106, 107, 107, 109, 109, 109, 110, 110, 112, 112, 112, 113, 113, 115, 115, 115, 116, 116, 118, 118, 118, 119, 119, 121, 121, 121, 122, 122, 124, 124, 124, 125, 125, 127, 127, 127, 128, 128, 130, 130, 130, 131, 131, 134, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 137, 137, 139, 139, 139, 139, 139, 139, 0, 0, 0, 141, 141, 143, 143, 144, 145, 146, 147, 147, 148, 149, 151};
public static new int[] bevs_smnlec
 = new int[] {41, 42, 52, 53, 54, 57, 58, 60, 61, 62, 68, 111, 112, 113, 118, 119, 120, 121, 123, 124, 125, 126, 131, 132, 133, 134, 135, 138, 143, 144, 149, 150, 153, 157, 160, 161, 163, 166, 170, 173, 174, 175, 176, 181, 182, 183, 188, 189, 190, 191, 193, 194, 199, 200, 205, 206, 211, 212, 213, 214, 217, 224, 225, 228, 230, 231, 232, 233, 235, 238, 240, 241, 242, 243, 244, 251, 258, 259, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 356, 357, 359, 360, 361, 363, 364, 366, 367, 368, 370, 371, 373, 374, 375, 377, 378, 380, 381, 382, 384, 385, 387, 388, 389, 391, 392, 394, 395, 396, 398, 399, 401, 402, 403, 405, 406, 408, 409, 410, 412, 413, 415, 416, 417, 419, 420, 422, 423, 424, 426, 427, 429, 430, 431, 433, 434, 436, 437, 438, 440, 441, 443, 444, 445, 447, 448, 450, 451, 452, 453, 454, 456, 457, 458, 460, 463, 467, 470, 471, 473, 474, 475, 477, 478, 479, 481, 484, 488, 491, 492, 494, 495, 496, 497, 498, 499, 500, 502, 503, 505};
/* BEGIN LINEINFO 
assign 1 18 41
emitDataGet 0 18 41
addParsedClass 1 18 42
assign 1 22 52
new 0 22 52
assign 1 22 53
new 1 22 53
assign 1 23 54
new 0 23 54
assign 1 23 57
new 0 23 57
assign 1 23 58
lesser 1 23 58
assign 1 24 60
new 0 24 60
put 2 24 61
assign 1 23 62
increment 0 23 62
return 1 26 68
assign 1 33 111
typenameGet 0 33 111
assign 1 33 112
CLASSGet 0 33 112
assign 1 33 113
equals 1 33 118
acceptClass 1 34 119
assign 1 35 120
nextDescendGet 0 35 120
return 1 35 121
assign 1 37 123
operGet 0 37 123
assign 1 37 124
typenameGet 0 37 124
assign 1 37 125
get 1 37 125
assign 1 38 126
def 1 38 131
assign 1 43 132
containerGet 0 43 132
assign 1 44 133
prepOps 0 44 133
assign 1 45 134
assign 1 47 135
assign 1 48 138
def 1 48 143
assign 1 48 144
def 1 48 149
assign 1 0 150
assign 1 0 153
assign 1 0 157
assign 1 48 160
containerGet 0 48 160
assign 1 48 161
equals 1 48 161
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 49 173
get 1 49 173
addValue 1 49 174
assign 1 50 175
nextPeerGet 0 50 175
assign 1 51 176
def 1 51 181
assign 1 52 182
nextPeerGet 0 52 182
assign 1 53 183
def 1 53 188
assign 1 54 189
typenameGet 0 54 189
assign 1 54 190
COMMAGet 0 54 190
assign 1 54 191
equals 1 54 191
assign 1 55 193
nextPeerGet 0 55 193
assign 1 56 194
def 1 56 199
assign 1 57 200
nextPeerGet 0 57 200
assign 1 62 205
assign 1 63 206
def 1 63 211
assign 1 64 212
operGet 0 64 212
assign 1 64 213
typenameGet 0 64 213
assign 1 64 214
get 1 64 214
assign 1 66 217
assign 1 69 224
new 0 69 224
assign 1 70 225
iteratorGet 0 70 225
assign 1 70 228
hasNextGet 0 70 228
assign 1 71 230
nextGet 0 71 230
assign 1 72 231
lengthGet 0 72 231
assign 1 72 232
new 0 72 232
assign 1 72 233
greater 1 72 233
assign 1 73 235
iteratorGet 0 73 235
assign 1 73 238
hasNextGet 0 73 238
assign 1 74 240
nextGet 0 74 240
assign 1 75 241
priorPeerGet 0 75 241
assign 1 75 242
nextPeerGet 0 75 242
assign 1 75 243
callFromOper 4 75 243
assign 1 76 244
assign 1 79 251
increment 0 79 251
assign 1 84 258
nextDescendGet 0 84 258
return 1 84 259
assign 1 88 344
new 0 88 344
assign 1 89 345
new 0 89 345
wasOperSet 1 89 346
assign 1 90 347
operNamesGet 0 90 347
assign 1 90 348
typenameGet 0 90 348
assign 1 90 349
get 1 90 349
assign 1 90 350
lower 0 90 350
nameSet 1 90 351
assign 1 91 352
nameGet 0 91 352
assign 1 91 353
new 0 91 353
assign 1 91 354
equals 1 91 354
assign 1 92 356
new 0 92 356
nameSet 1 92 357
assign 1 94 359
nameGet 0 94 359
assign 1 94 360
new 0 94 360
assign 1 94 361
equals 1 94 361
assign 1 95 363
new 0 95 363
nameSet 1 95 364
assign 1 97 366
nameGet 0 97 366
assign 1 97 367
new 0 97 367
assign 1 97 368
equals 1 97 368
assign 1 98 370
new 0 98 370
nameSet 1 98 371
assign 1 100 373
nameGet 0 100 373
assign 1 100 374
new 0 100 374
assign 1 100 375
equals 1 100 375
assign 1 101 377
new 0 101 377
nameSet 1 101 378
assign 1 103 380
nameGet 0 103 380
assign 1 103 381
new 0 103 381
assign 1 103 382
equals 1 103 382
assign 1 104 384
new 0 104 384
nameSet 1 104 385
assign 1 106 387
nameGet 0 106 387
assign 1 106 388
new 0 106 388
assign 1 106 389
equals 1 106 389
assign 1 107 391
new 0 107 391
nameSet 1 107 392
assign 1 109 394
nameGet 0 109 394
assign 1 109 395
new 0 109 395
assign 1 109 396
equals 1 109 396
assign 1 110 398
new 0 110 398
nameSet 1 110 399
assign 1 112 401
nameGet 0 112 401
assign 1 112 402
new 0 112 402
assign 1 112 403
equals 1 112 403
assign 1 113 405
new 0 113 405
nameSet 1 113 406
assign 1 115 408
nameGet 0 115 408
assign 1 115 409
new 0 115 409
assign 1 115 410
equals 1 115 410
assign 1 116 412
new 0 116 412
nameSet 1 116 413
assign 1 118 415
nameGet 0 118 415
assign 1 118 416
new 0 118 416
assign 1 118 417
equals 1 118 417
assign 1 119 419
new 0 119 419
nameSet 1 119 420
assign 1 121 422
nameGet 0 121 422
assign 1 121 423
new 0 121 423
assign 1 121 424
equals 1 121 424
assign 1 122 426
new 0 122 426
nameSet 1 122 427
assign 1 124 429
nameGet 0 124 429
assign 1 124 430
new 0 124 430
assign 1 124 431
equals 1 124 431
assign 1 125 433
new 0 125 433
nameSet 1 125 434
assign 1 127 436
nameGet 0 127 436
assign 1 127 437
new 0 127 437
assign 1 127 438
equals 1 127 438
assign 1 128 440
new 0 128 440
nameSet 1 128 441
assign 1 130 443
nameGet 0 130 443
assign 1 130 444
new 0 130 444
assign 1 130 445
equals 1 130 445
assign 1 131 447
new 0 131 447
nameSet 1 131 448
assign 1 134 450
new 0 134 450
wasBoundSet 1 134 451
assign 1 135 452
typenameGet 0 135 452
assign 1 135 453
ASSIGNGet 0 135 453
assign 1 135 454
equals 1 135 454
assign 1 135 456
heldGet 0 135 456
assign 1 135 457
new 0 135 457
assign 1 135 458
equals 1 135 458
assign 1 0 460
assign 1 0 463
assign 1 0 467
assign 1 137 470
new 0 137 470
isOnceSet 1 137 471
assign 1 139 473
typenameGet 0 139 473
assign 1 139 474
ASSIGNGet 0 139 474
assign 1 139 475
equals 1 139 475
assign 1 139 477
heldGet 0 139 477
assign 1 139 478
new 0 139 478
assign 1 139 479
equals 1 139 479
assign 1 0 481
assign 1 0 484
assign 1 0 488
assign 1 141 491
new 0 141 491
isManySet 1 141 492
assign 1 143 494
CALLGet 0 143 494
typenameSet 1 143 495
heldSet 1 144 496
delete 0 145 497
addValue 1 146 498
assign 1 147 499
new 0 147 499
assign 1 147 500
greater 1 147 500
delete 0 148 502
addValue 1 149 503
return 1 151 505
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -1028089930: return bem_prepOps_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -724180734: return bem_acceptClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case -1204261941: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass8();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass8.bevs_inst = (BEC_3_5_5_5_BuildVisitPass8)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass8.bevs_inst;
}
}
}
