namespace be {
/* IO:File: source/build/Pass7.be */
public sealed class BEC_3_5_5_5_BuildVisitPass7 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
static BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x65,0x77};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_4 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_5 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_6 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_7 = {0x74,0x72,0x75,0x65};
private static byte[] bels_8 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_9 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_10 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 41));
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_17 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_18 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_20 = {0x6E,0x65,0x77};
public static new BEC_3_5_5_5_BuildVisitPass7 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-630006451, BEL_4_Base.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevl_nlc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEL_4_Base.bevn_isLiteralSet_1, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_11_tmpany_phold);
beva_node.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_12_tmpany_phold);
beva_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_1));
bevt_13_tmpany_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 46 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_2));
bevt_15_tmpany_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 46 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 46 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpany_phold);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_23_tmpany_phold);
if (bevt_21_tmpany_phold != null && bevt_21_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_27_tmpany_phold);
if (bevt_25_tmpany_phold != null && bevt_25_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold != null && bevt_28_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_33_tmpany_phold);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_36_tmpany_phold);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_37_tmpany_phold);
bevl_pn.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 57 */
} /* Line: 50 */
} /* Line: 48 */
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 88 */
if (bevp_inClassNp == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 90 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 92 */
bevt_16_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpany_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_3));
this.bem_buildLiteral_2(beva_node, bevt_18_tmpany_phold);
} /* Line: 95 */
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_4));
this.bem_buildLiteral_2(beva_node, bevt_22_tmpany_phold);
} /* Line: 98 */
bevt_24_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpany_phold.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 100 */ {
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_5));
this.bem_buildLiteral_2(beva_node, bevt_26_tmpany_phold);
} /* Line: 101 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_6));
this.bem_buildLiteral_2(beva_node, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpany_phold);
} /* Line: 106 */
bevt_33_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpany_phold.bevi_int == bevt_34_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
beva_node.bem_heldSet_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_8));
this.bem_buildLiteral_2(beva_node, bevt_36_tmpany_phold);
} /* Line: 110 */
bevt_38_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpany_phold.bevi_int == bevt_39_tmpany_phold.bevi_int) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_9));
beva_node.bem_heldSet_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_10));
this.bem_buildLiteral_2(beva_node, bevt_41_tmpany_phold);
} /* Line: 118 */
 else  /* Line: 116 */ {
bevt_43_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpany_phold.bevi_int == bevt_44_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpany_phold).bevi_bool) /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_50_tmpany_phold = beva_node.bem_heldGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_49_tmpany_phold == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 121 */ {
if (bevl_nnode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_53_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_54_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_54_tmpany_phold);
if (bevt_52_tmpany_phold != null && bevt_52_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpany_phold).bevi_bool) /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 121 */ {
bevt_57_tmpany_phold = bevo_0;
bevt_59_tmpany_phold = beva_node.bem_heldGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_55_tmpany_phold);
} /* Line: 122 */
 else  /* Line: 123 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpany_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_62_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpany_phold;
} /* Line: 130 */
} /* Line: 121 */
 else  /* Line: 116 */ {
bevt_64_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 132 */ {
if (bevl_nnode == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 133 */ {
bevt_68_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpany_phold);
if (bevt_67_tmpany_phold != null && bevt_67_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 133 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 133 */
 else  /* Line: 133 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 133 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_71_tmpany_phold == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_72_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 136 */ {
bevt_73_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpany_phold != null && bevt_73_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_75_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpany_phold);
if (bevt_74_tmpany_phold != null && bevt_74_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpany_phold).bevi_bool) /* Line: 138 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 139 */
} /* Line: 138 */
 else  /* Line: 136 */ {
break;
} /* Line: 136 */
} /* Line: 136 */
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 142 */ {
bevt_77_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_77_tmpany_phold != null && bevt_77_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_77_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 144 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
} /* Line: 142 */
bevl_pc = bevl_nnode;
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpany_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_79_tmpany_phold);
bevl_pc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevt_82_tmpany_phold = bevl_dnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_83_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpany_phold);
if (bevt_81_tmpany_phold != null && bevt_81_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_81_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 155 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 155 */
 else  /* Line: 155 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 155 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_onode == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bels_12));
bevt_85_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpany_phold);
} /* Line: 158 */
 else  /* Line: 157 */ {
bevt_88_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpany_phold.bevi_int == bevt_89_tmpany_phold.bevi_int) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 159 */ {
bevt_91_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpany_phold);
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 160 */ {
bevt_92_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_94_tmpany_phold);
} /* Line: 163 */
 else  /* Line: 164 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 165 */
} /* Line: 160 */
 else  /* Line: 157 */ {
bevt_96_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpany_phold.bevi_int == bevt_97_tmpany_phold.bevi_int) {
bevt_95_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_101_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_99_tmpany_phold = bevt_100_tmpany_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_102_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_102_tmpany_phold);
if (bevt_98_tmpany_phold != null && bevt_98_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_98_tmpany_phold).bevi_bool) /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 167 */ {
bevt_105_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_aliasedGet_0();
bevt_106_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpany_phold = bevt_104_tmpany_phold.bem_has_1(bevt_106_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 167 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 167 */
 else  /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 167 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_109_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpany_phold);
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevt_111_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_113_tmpany_phold);
} /* Line: 176 */
 else  /* Line: 177 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 178 */
} /* Line: 173 */
 else  /* Line: 157 */ {
bevt_115_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_116_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_13));
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpany_phold);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpany_phold).bevi_bool) /* Line: 180 */ {
bevt_118_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(70, bels_14));
bevt_117_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 181 */
 else  /* Line: 157 */ {
bevt_120_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_121_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_15));
bevt_119_tmpany_phold = bevt_120_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpany_phold);
if (bevt_119_tmpany_phold != null && bevt_119_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_119_tmpany_phold).bevi_bool) /* Line: 182 */ {
bevt_123_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bels_16));
bevt_122_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_122_tmpany_phold);
} /* Line: 183 */
} /* Line: 157 */
} /* Line: 157 */
} /* Line: 157 */
} /* Line: 157 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_onode);
bevl_dnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 188 */
 else  /* Line: 189 */ {
bevt_124_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_124_tmpany_phold);
bevt_125_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_125_tmpany_phold);
} /* Line: 191 */
} /* Line: 155 */
} /* Line: 133 */
 else  /* Line: 116 */ {
bevt_127_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpany_phold.bevi_int == bevt_128_tmpany_phold.bevi_int) {
bevt_126_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_131_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_17));
bevt_130_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_130_tmpany_phold);
} /* Line: 200 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpany_phold.bevi_int == bevt_134_tmpany_phold.bevi_int) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 204 */ {
bevt_136_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(84, bels_18));
bevt_135_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_135_tmpany_phold);
} /* Line: 205 */
bevt_137_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpany_phold);
} /* Line: 207 */
 else  /* Line: 116 */ {
bevt_139_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpany_phold.bevi_int == bevt_140_tmpany_phold.bevi_int) {
bevt_138_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
if (bevl_onode == null) {
bevt_142_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 213 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 213 */ {
bevt_144_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_19));
bevt_143_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpany_phold);
} /* Line: 214 */
bevt_146_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_147_tmpany_phold);
if (bevt_145_tmpany_phold != null && bevt_145_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_145_tmpany_phold).bevi_bool) /* Line: 216 */ {
bevl_pnode = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_pnode == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_150_tmpany_phold = bevl_pnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_151_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_151_tmpany_phold);
if (bevt_149_tmpany_phold != null && bevt_149_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpany_phold).bevi_bool) /* Line: 218 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 218 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpany_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpany_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_ga.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_153_tmpany_phold);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpany_phold.bevi_int == bevt_156_tmpany_phold.bevi_int) {
bevt_154_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpany_phold.bevi_bool) /* Line: 227 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 228 */
 else  /* Line: 227 */ {
bevt_158_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpany_phold.bevi_int == bevt_159_tmpany_phold.bevi_int) {
bevt_157_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpany_phold.bevi_bool) /* Line: 229 */ {
bevt_163_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_164_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_164_tmpany_phold);
if (bevt_160_tmpany_phold != null && bevt_160_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_160_tmpany_phold).bevi_bool) /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_167_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bem_aliasedGet_0();
bevt_168_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bem_has_1(bevt_168_tmpany_phold);
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 229 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 229 */
 else  /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 229 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpany_phold);
bevl_onode.bem_resolveNp_0();
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 235 */
} /* Line: 227 */
} /* Line: 227 */
} /* Line: 218 */
} /* Line: 216 */
} /* Line: 116 */
} /* Line: 116 */
} /* Line: 116 */
} /* Line: 116 */
bevt_171_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpany_phold;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpany_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_20));
bevl_gnc.bem_nameSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpany_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {23, 24, 26, 27, 27, 28, 29, 31, 32, 32, 33, 33, 34, 34, 35, 35, 36, 36, 37, 37, 39, 41, 41, 42, 44, 46, 46, 0, 46, 46, 0, 0, 47, 48, 48, 48, 48, 48, 0, 48, 48, 48, 0, 0, 0, 0, 0, 49, 50, 50, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 50, 50, 50, 0, 0, 0, 50, 50, 50, 0, 0, 0, 0, 0, 56, 56, 56, 56, 57, 83, 86, 86, 86, 86, 87, 87, 88, 88, 88, 90, 90, 91, 92, 94, 94, 94, 94, 95, 95, 97, 97, 97, 97, 98, 98, 100, 100, 100, 100, 101, 101, 103, 103, 103, 103, 105, 105, 106, 106, 108, 108, 108, 108, 109, 109, 110, 110, 116, 116, 116, 116, 117, 117, 118, 118, 120, 120, 120, 120, 120, 120, 120, 0, 0, 0, 121, 121, 121, 121, 121, 121, 0, 121, 121, 121, 0, 0, 0, 0, 0, 122, 122, 122, 122, 122, 122, 124, 124, 124, 125, 126, 130, 130, 132, 132, 132, 132, 133, 133, 133, 133, 133, 0, 0, 0, 134, 134, 134, 135, 136, 136, 136, 137, 138, 138, 138, 139, 142, 142, 143, 144, 147, 148, 148, 149, 150, 150, 151, 152, 153, 154, 155, 155, 155, 155, 155, 0, 0, 0, 156, 157, 157, 158, 158, 158, 159, 159, 159, 159, 160, 160, 161, 161, 162, 162, 163, 163, 165, 167, 167, 167, 167, 167, 167, 167, 167, 167, 0, 167, 167, 167, 167, 0, 0, 0, 0, 0, 168, 169, 169, 170, 171, 171, 172, 173, 173, 174, 174, 175, 175, 176, 176, 178, 180, 180, 180, 181, 181, 181, 182, 182, 182, 183, 183, 183, 186, 187, 188, 190, 190, 191, 191, 195, 195, 195, 195, 198, 199, 199, 200, 200, 200, 202, 203, 204, 204, 204, 204, 205, 205, 205, 207, 207, 208, 208, 208, 208, 210, 213, 213, 0, 213, 213, 0, 0, 214, 214, 214, 216, 216, 216, 217, 218, 218, 0, 218, 218, 218, 0, 0, 219, 220, 220, 221, 222, 222, 223, 224, 225, 226, 227, 227, 227, 227, 228, 229, 229, 229, 229, 229, 229, 229, 229, 229, 0, 229, 229, 229, 229, 0, 0, 0, 0, 0, 230, 231, 231, 232, 233, 233, 234, 235, 240, 240, 244, 245, 246, 246, 247, 247, 248, 250, 251, 251, 252, 252, 253, 253, 254, 254, 255, 255, 256, 257, 257, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 110, 113, 114, 116, 119, 123, 124, 129, 130, 131, 132, 134, 137, 138, 139, 141, 144, 148, 151, 155, 158, 159, 164, 165, 168, 169, 170, 172, 173, 174, 176, 179, 183, 186, 187, 188, 190, 193, 197, 200, 201, 202, 204, 207, 211, 214, 217, 221, 222, 223, 224, 225, 418, 419, 420, 421, 426, 427, 428, 429, 430, 431, 433, 438, 439, 440, 442, 443, 444, 449, 450, 451, 453, 454, 455, 460, 461, 462, 464, 465, 466, 471, 472, 473, 475, 476, 477, 482, 483, 484, 485, 486, 488, 489, 490, 495, 496, 497, 498, 499, 501, 502, 503, 508, 509, 510, 511, 512, 515, 516, 517, 522, 523, 524, 525, 527, 530, 534, 537, 538, 539, 544, 545, 550, 551, 554, 555, 556, 558, 561, 565, 568, 572, 575, 576, 577, 578, 579, 580, 583, 584, 585, 586, 587, 588, 589, 593, 594, 595, 600, 601, 606, 607, 608, 609, 611, 614, 618, 621, 622, 627, 628, 629, 630, 633, 635, 636, 637, 638, 640, 647, 650, 652, 653, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 675, 676, 677, 678, 680, 683, 687, 690, 691, 696, 697, 698, 699, 702, 703, 704, 709, 710, 711, 713, 714, 715, 716, 717, 718, 721, 725, 726, 727, 732, 733, 734, 735, 736, 737, 739, 742, 743, 744, 745, 747, 750, 754, 757, 761, 764, 765, 766, 767, 768, 769, 770, 771, 772, 774, 775, 776, 777, 778, 779, 782, 786, 787, 788, 790, 791, 792, 795, 796, 797, 799, 800, 801, 807, 808, 809, 812, 813, 814, 815, 820, 821, 822, 827, 828, 829, 834, 835, 836, 837, 839, 840, 841, 842, 843, 848, 849, 850, 851, 853, 854, 857, 858, 859, 864, 865, 866, 871, 872, 875, 880, 881, 884, 888, 889, 890, 892, 893, 894, 896, 897, 902, 903, 906, 907, 908, 910, 913, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 934, 935, 938, 939, 940, 945, 946, 947, 948, 949, 950, 952, 955, 956, 957, 958, 960, 963, 967, 970, 974, 977, 978, 979, 980, 981, 982, 983, 984, 994, 995, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1032, 1035, 1039, 1042};
/* BEGIN LINEINFO 
assign 1 23 82
new 0 23 82
fromString 1 24 83
assign 1 26 84
new 1 26 84
assign 1 27 85
NAMEPATHGet 0 27 85
typenameSet 1 27 86
heldSet 1 28 87
copyLoc 1 29 88
assign 1 31 89
new 0 31 89
assign 1 32 90
new 0 32 90
nameSet 1 32 91
assign 1 33 92
new 0 33 92
wasBoundSet 1 33 93
assign 1 34 94
new 0 34 94
boundSet 1 34 95
assign 1 35 96
new 0 35 96
isConstructSet 1 35 97
assign 1 36 98
new 0 36 98
isLiteralSet 1 36 99
assign 1 37 100
heldGet 0 37 100
literalValueSet 1 37 101
addValue 1 39 102
assign 1 41 103
CALLGet 0 41 103
typenameSet 1 41 104
heldSet 1 42 105
resolveNp 0 44 106
assign 1 46 107
new 0 46 107
assign 1 46 108
equals 1 46 108
assign 1 0 110
assign 1 46 113
new 0 46 113
assign 1 46 114
equals 1 46 114
assign 1 0 116
assign 1 0 119
assign 1 47 123
priorPeerGet 0 47 123
assign 1 48 124
def 1 48 129
assign 1 48 130
typenameGet 0 48 130
assign 1 48 131
SUBTRACTGet 0 48 131
assign 1 48 132
equals 1 48 132
assign 1 0 134
assign 1 48 137
typenameGet 0 48 137
assign 1 48 138
ADDGet 0 48 138
assign 1 48 139
equals 1 48 139
assign 1 0 141
assign 1 0 144
assign 1 0 148
assign 1 0 151
assign 1 0 155
assign 1 49 158
priorPeerGet 0 49 158
assign 1 50 159
undef 1 50 164
assign 1 0 165
assign 1 50 168
typenameGet 0 50 168
assign 1 50 169
CALLGet 0 50 169
assign 1 50 170
notEquals 1 50 170
assign 1 50 172
typenameGet 0 50 172
assign 1 50 173
IDGet 0 50 173
assign 1 50 174
notEquals 1 50 174
assign 1 0 176
assign 1 0 179
assign 1 0 183
assign 1 50 186
typenameGet 0 50 186
assign 1 50 187
VARGet 0 50 187
assign 1 50 188
notEquals 1 50 188
assign 1 0 190
assign 1 0 193
assign 1 0 197
assign 1 50 200
typenameGet 0 50 200
assign 1 50 201
ACCESSORGet 0 50 201
assign 1 50 202
notEquals 1 50 202
assign 1 0 204
assign 1 0 207
assign 1 0 211
assign 1 0 214
assign 1 0 217
assign 1 56 221
heldGet 0 56 221
assign 1 56 222
literalValueGet 0 56 222
assign 1 56 223
add 1 56 223
literalValueSet 1 56 224
delete 0 57 225
assign 1 83 418
nextPeerGet 0 83 418
assign 1 86 419
typenameGet 0 86 419
assign 1 86 420
CLASSGet 0 86 420
assign 1 86 421
equals 1 86 426
assign 1 87 427
heldGet 0 87 427
assign 1 87 428
namepathGet 0 87 428
assign 1 88 429
heldGet 0 88 429
assign 1 88 430
fromFileGet 0 88 430
assign 1 88 431
toString 0 88 431
assign 1 90 433
def 1 90 438
inClassNpSet 1 91 439
inFileSet 1 92 440
assign 1 94 442
typenameGet 0 94 442
assign 1 94 443
INTLGet 0 94 443
assign 1 94 444
equals 1 94 449
assign 1 95 450
new 0 95 450
buildLiteral 2 95 451
assign 1 97 453
typenameGet 0 97 453
assign 1 97 454
FLOATLGet 0 97 454
assign 1 97 455
equals 1 97 460
assign 1 98 461
new 0 98 461
buildLiteral 2 98 462
assign 1 100 464
typenameGet 0 100 464
assign 1 100 465
STRINGLGet 0 100 465
assign 1 100 466
equals 1 100 471
assign 1 101 472
new 0 101 472
buildLiteral 2 101 473
assign 1 103 475
typenameGet 0 103 475
assign 1 103 476
WSTRINGLGet 0 103 476
assign 1 103 477
equals 1 103 482
assign 1 105 483
new 0 105 483
buildLiteral 2 105 484
assign 1 106 485
new 0 106 485
wideStringSet 1 106 486
assign 1 108 488
typenameGet 0 108 488
assign 1 108 489
TRUEGet 0 108 489
assign 1 108 490
equals 1 108 495
assign 1 109 496
new 0 109 496
heldSet 1 109 497
assign 1 110 498
new 0 110 498
buildLiteral 2 110 499
assign 1 116 501
typenameGet 0 116 501
assign 1 116 502
FALSEGet 0 116 502
assign 1 116 503
equals 1 116 508
assign 1 117 509
new 0 117 509
heldSet 1 117 510
assign 1 118 511
new 0 118 511
buildLiteral 2 118 512
assign 1 120 515
typenameGet 0 120 515
assign 1 120 516
VARGet 0 120 516
assign 1 120 517
equals 1 120 522
assign 1 120 523
heldGet 0 120 523
assign 1 120 524
isArgGet 0 120 524
assign 1 120 525
not 0 120 525
assign 1 0 527
assign 1 0 530
assign 1 0 534
assign 1 121 537
heldGet 0 121 537
assign 1 121 538
nameGet 0 121 538
assign 1 121 539
undef 1 121 544
assign 1 121 545
undef 1 121 550
assign 1 0 551
assign 1 121 554
typenameGet 0 121 554
assign 1 121 555
IDGet 0 121 555
assign 1 121 556
notEquals 1 121 556
assign 1 0 558
assign 1 0 561
assign 1 0 565
assign 1 0 568
assign 1 0 572
assign 1 122 575
new 0 122 575
assign 1 122 576
heldGet 0 122 576
assign 1 122 577
nameGet 0 122 577
assign 1 122 578
add 1 122 578
assign 1 122 579
new 2 122 579
throw 1 122 580
assign 1 124 583
heldGet 0 124 583
assign 1 124 584
heldGet 0 124 584
nameSet 1 124 585
addVariable 0 125 586
delete 0 126 587
assign 1 130 588
nextDescendGet 0 130 588
return 1 130 589
assign 1 132 593
typenameGet 0 132 593
assign 1 132 594
IDGet 0 132 594
assign 1 132 595
equals 1 132 600
assign 1 133 601
def 1 133 606
assign 1 133 607
typenameGet 0 133 607
assign 1 133 608
PARENSGet 0 133 608
assign 1 133 609
equals 1 133 609
assign 1 0 611
assign 1 0 614
assign 1 0 618
assign 1 134 621
containedGet 0 134 621
assign 1 134 622
def 1 134 627
assign 1 135 628
new 0 135 628
assign 1 136 629
containedGet 0 136 629
assign 1 136 630
iteratorGet 0 136 630
assign 1 136 633
hasNextGet 0 136 633
assign 1 137 635
nextGet 0 137 635
assign 1 138 636
typenameGet 0 138 636
assign 1 138 637
COMMAGet 0 138 637
assign 1 138 638
equals 1 138 638
addValue 1 139 640
assign 1 142 647
iteratorGet 0 142 647
assign 1 142 650
hasNextGet 0 142 650
assign 1 143 652
nextGet 0 143 652
delete 0 144 653
assign 1 147 660
assign 1 148 661
CALLGet 0 148 661
typenameSet 1 148 662
assign 1 149 663
new 0 149 663
assign 1 150 664
heldGet 0 150 664
nameSet 1 150 665
heldSet 1 151 666
delete 0 152 667
assign 1 153 668
assign 1 154 669
priorPeerGet 0 154 669
assign 1 155 670
def 1 155 675
assign 1 155 676
typenameGet 0 155 676
assign 1 155 677
DOTGet 0 155 677
assign 1 155 678
equals 1 155 678
assign 1 0 680
assign 1 0 683
assign 1 0 687
assign 1 156 690
priorPeerGet 0 156 690
assign 1 157 691
undef 1 157 696
assign 1 158 697
new 0 158 697
assign 1 158 698
new 2 158 698
throw 1 158 699
assign 1 159 702
typenameGet 0 159 702
assign 1 159 703
NAMEPATHGet 0 159 703
assign 1 159 704
equals 1 159 709
assign 1 160 710
nameGet 0 160 710
assign 1 160 711
isNewish 1 160 711
assign 1 161 713
new 0 161 713
wasBoundSet 1 161 714
assign 1 162 715
new 0 162 715
boundSet 1 162 716
assign 1 163 717
new 0 163 717
isConstructSet 1 163 718
createImpliedConstruct 2 165 721
assign 1 167 725
typenameGet 0 167 725
assign 1 167 726
IDGet 0 167 726
assign 1 167 727
equals 1 167 732
assign 1 167 733
transUnitGet 0 167 733
assign 1 167 734
heldGet 0 167 734
assign 1 167 735
aliasedGet 0 167 735
assign 1 167 736
heldGet 0 167 736
assign 1 167 737
has 1 167 737
assign 1 0 739
assign 1 167 742
emitDataGet 0 167 742
assign 1 167 743
aliasedGet 0 167 743
assign 1 167 744
heldGet 0 167 744
assign 1 167 745
has 1 167 745
assign 1 0 747
assign 1 0 750
assign 1 0 754
assign 1 0 757
assign 1 0 761
assign 1 168 764
new 0 168 764
assign 1 169 765
heldGet 0 169 765
addStep 1 169 766
heldSet 1 170 767
assign 1 171 768
NAMEPATHGet 0 171 768
typenameSet 1 171 769
resolveNp 0 172 770
assign 1 173 771
nameGet 0 173 771
assign 1 173 772
isNewish 1 173 772
assign 1 174 774
new 0 174 774
wasBoundSet 1 174 775
assign 1 175 776
new 0 175 776
boundSet 1 175 777
assign 1 176 778
new 0 176 778
isConstructSet 1 176 779
createImpliedConstruct 2 178 782
assign 1 180 786
nameGet 0 180 786
assign 1 180 787
new 0 180 787
assign 1 180 788
equals 1 180 788
assign 1 181 790
new 0 181 790
assign 1 181 791
new 2 181 791
throw 1 181 792
assign 1 182 795
nameGet 0 182 795
assign 1 182 796
new 0 182 796
assign 1 182 797
equals 1 182 797
assign 1 183 799
new 0 183 799
assign 1 183 800
new 2 183 800
throw 1 183 801
delete 0 186 807
prepend 1 187 808
delete 0 188 809
assign 1 190 812
new 0 190 812
boundSet 1 190 813
assign 1 191 814
new 0 191 814
wasBoundSet 1 191 815
assign 1 195 820
typenameGet 0 195 820
assign 1 195 821
IDXGet 0 195 821
assign 1 195 822
equals 1 195 827
assign 1 198 828
priorPeerGet 0 198 828
assign 1 199 829
undef 1 199 834
assign 1 200 835
new 0 200 835
assign 1 200 836
new 2 200 836
throw 1 200 837
delete 0 202 839
prepend 1 203 840
assign 1 204 841
typenameGet 0 204 841
assign 1 204 842
NAMEPATHGet 0 204 842
assign 1 204 843
equals 1 204 848
assign 1 205 849
new 0 205 849
assign 1 205 850
new 2 205 850
throw 1 205 851
assign 1 207 853
IDXACCGet 0 207 853
typenameSet 1 207 854
assign 1 208 857
typenameGet 0 208 857
assign 1 208 858
DOTGet 0 208 858
assign 1 208 859
equals 1 208 864
assign 1 210 865
priorPeerGet 0 210 865
assign 1 213 866
undef 1 213 871
assign 1 0 872
assign 1 213 875
undef 1 213 880
assign 1 0 881
assign 1 0 884
assign 1 214 888
new 0 214 888
assign 1 214 889
new 2 214 889
throw 1 214 890
assign 1 216 892
typenameGet 0 216 892
assign 1 216 893
IDGet 0 216 893
assign 1 216 894
equals 1 216 894
assign 1 217 896
nextPeerGet 0 217 896
assign 1 218 897
undef 1 218 902
assign 1 0 903
assign 1 218 906
typenameGet 0 218 906
assign 1 218 907
PARENSGet 0 218 907
assign 1 218 908
notEquals 1 218 908
assign 1 0 910
assign 1 0 913
assign 1 219 917
priorPeerGet 0 219 917
assign 1 220 918
ACCESSORGet 0 220 918
typenameSet 1 220 919
assign 1 221 920
new 0 221 920
assign 1 222 921
heldGet 0 222 921
nameSet 1 222 922
delete 0 223 923
delete 0 224 924
heldSet 1 225 925
addValue 1 226 926
assign 1 227 927
typenameGet 0 227 927
assign 1 227 928
NAMEPATHGet 0 227 928
assign 1 227 929
equals 1 227 934
createImpliedConstruct 2 228 935
assign 1 229 938
typenameGet 0 229 938
assign 1 229 939
IDGet 0 229 939
assign 1 229 940
equals 1 229 945
assign 1 229 946
transUnitGet 0 229 946
assign 1 229 947
heldGet 0 229 947
assign 1 229 948
aliasedGet 0 229 948
assign 1 229 949
heldGet 0 229 949
assign 1 229 950
has 1 229 950
assign 1 0 952
assign 1 229 955
emitDataGet 0 229 955
assign 1 229 956
aliasedGet 0 229 956
assign 1 229 957
heldGet 0 229 957
assign 1 229 958
has 1 229 958
assign 1 0 960
assign 1 0 963
assign 1 0 967
assign 1 0 970
assign 1 0 974
assign 1 230 977
new 0 230 977
assign 1 231 978
heldGet 0 231 978
addStep 1 231 979
heldSet 1 232 980
assign 1 233 981
NAMEPATHGet 0 233 981
typenameSet 1 233 982
resolveNp 0 234 983
createImpliedConstruct 2 235 984
assign 1 240 994
nextDescendGet 0 240 994
return 1 240 995
assign 1 244 1008
new 0 244 1008
heldSet 1 245 1009
assign 1 246 1010
NAMEPATHGet 0 246 1010
typenameSet 1 246 1011
assign 1 247 1012
heldGet 0 247 1012
heldSet 1 247 1013
prepend 1 248 1014
assign 1 250 1015
new 0 250 1015
assign 1 251 1016
new 0 251 1016
nameSet 1 251 1017
assign 1 252 1018
new 0 252 1018
wasBoundSet 1 252 1019
assign 1 253 1020
new 0 253 1020
boundSet 1 253 1021
assign 1 254 1022
new 0 254 1022
isConstructSet 1 254 1023
assign 1 255 1024
new 0 255 1024
wasImpliedConstructSet 1 255 1025
heldSet 1 256 1026
assign 1 257 1027
CALLGet 0 257 1027
typenameSet 1 257 1028
return 1 0 1032
assign 1 0 1035
return 1 0 1039
assign 1 0 1042
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 822104518: return bem_inFileGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 856627742: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass7.bevs_inst = (BEC_3_5_5_5_BuildVisitPass7)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass7.bevs_inst;
}
}
}
