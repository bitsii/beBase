namespace be.BEL_4_Base {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_4_7_TextStrings : BEC_6_6_SystemObject {
public BEC_4_7_TextStrings() { }
static BEC_4_7_TextStrings() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static byte[] bels_1 = {0x0D,0x0A};
private static byte[] bels_2 = {0x0A};
private static byte[] bels_3 = {0x0A};
private static byte[] bels_4 = {0x3A};
private static byte[] bels_5 = {};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_6 = {};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_6, 0));
public static new BEC_4_7_TextStrings bevs_inst;
public BEC_4_6_TextString bevp_space;
public BEC_4_6_TextString bevp_empty;
public BEC_4_6_TextString bevp_quote;
public BEC_4_6_TextString bevp_tab;
public BEC_4_6_TextString bevp_dosNewline;
public BEC_4_6_TextString bevp_unixNewline;
public BEC_4_6_TextString bevp_newline;
public BEC_4_6_TextString bevp_cr;
public BEC_4_6_TextString bevp_lf;
public BEC_4_6_TextString bevp_colon;
public BEC_4_9_TextTokenizer bevp_lineSplitter;
public BEC_9_3_ContainerSet bevp_ws;
public override BEC_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_4_7_TextStrings bem_default_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevp_space = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_0));
bevp_empty = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(34));
bevp_quote = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_codeNew_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(9));
bevp_tab = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_codeNew_1(bevt_1_tmpvar_phold);
bevp_dosNewline = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_1));
bevp_unixNewline = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_2));
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(13));
bevp_cr = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_codeNew_1(bevt_2_tmpvar_phold);
bevp_lf = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_3));
bevp_colon = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_4));
bevp_lineSplitter = (BEC_4_9_TextTokenizer) (new BEC_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_join_2(BEC_4_6_TextString beva_delim, BEC_6_6_SystemObject beva_splits) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_joinBuffer_2(beva_delim, beva_splits);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_extractString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_joinBuffer_2(BEC_4_6_TextString beva_delim, BEC_6_6_SystemObject beva_splits) {
BEC_6_6_SystemObject bevl_i = null;
BEC_4_6_TextString bevl_buf = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_splits.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1180 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
return bevt_2_tmpvar_phold;
} /* Line: 1181 */
bevl_buf = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_3_tmpvar_phold);
while (true)
 /* Line: 1185 */ {
bevt_4_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 1185 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1187 */
 else  /* Line: 1185 */ {
break;
} /* Line: 1185 */
} /* Line: 1185 */
return bevl_buf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_strip_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevl_beg = null;
BEC_4_3_MathInt bevl_end = null;
BEC_5_4_LogicBool bevl_foundChar = null;
BEC_4_17_TextMultiByteIterator bevl_mb = null;
BEC_4_6_TextString bevl_step = null;
BEC_4_6_TextString bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_beg = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_end = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_foundChar = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1197 */ {
bevt_0_tmpvar_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1197 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpvar_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1199 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1200 */ {
bevl_end = bevl_end.bem_increment_0();
} /* Line: 1201 */
 else  /* Line: 1202 */ {
bevl_beg = bevl_beg.bem_increment_0();
} /* Line: 1203 */
} /* Line: 1200 */
 else  /* Line: 1205 */ {
bevl_end = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_foundChar = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1207 */
} /* Line: 1199 */
 else  /* Line: 1197 */ {
break;
} /* Line: 1197 */
} /* Line: 1197 */
if (bevl_foundChar.bevi_bool) /* Line: 1210 */ {
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_2_tmpvar_phold);
} /* Line: 1211 */
 else  /* Line: 1212 */ {
bevl_toRet = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_5));
} /* Line: 1213 */
return bevl_toRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_commonPrefix_2(BEC_4_6_TextString beva_a, BEC_4_6_TextString beva_b) {
BEC_4_3_MathInt bevl_sz = null;
BEC_6_6_SystemObject bevl_ai = null;
BEC_6_6_SystemObject bevl_bi = null;
BEC_4_6_TextString bevl_av = null;
BEC_4_6_TextString bevl_bv = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_4_MathInts bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
if (beva_a == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1219 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1219 */ {
if (beva_b == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1219 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1219 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1219 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1219 */ {
return null;
} /* Line: 1219 */
bevt_3_tmpvar_phold = (BEC_4_4_MathInts) BEC_4_4_MathInts.bevs_inst;
bevt_4_tmpvar_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpvar_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_4_3_MathInt) bevt_3_tmpvar_phold.bem_min_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_bv = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 1225 */ {
bevt_6_tmpvar_phold = bevl_i.bem_lesser_1(bevl_sz);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1225 */ {
bevl_ai.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_av);
bevl_bi.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_bv);
bevt_7_tmpvar_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1228 */ {
bevt_9_tmpvar_phold = bevo_0;
bevt_8_tmpvar_phold = beva_a.bem_substring_2(bevt_9_tmpvar_phold, bevl_i);
return bevt_8_tmpvar_phold;
} /* Line: 1229 */
bevl_i.bem_incrementValue_0();
} /* Line: 1225 */
 else  /* Line: 1225 */ {
break;
} /* Line: 1225 */
} /* Line: 1225 */
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = beva_a.bem_substring_2(bevt_11_tmpvar_phold, bevl_i);
return bevt_10_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_anyEmpty_1(BEC_6_6_SystemObject beva_strs) {
BEC_4_6_TextString bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_loop = beva_strs.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 1236 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 1236 */ {
bevl_i = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = this.bem_isEmpty_1(bevl_i);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1237 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 1238 */
} /* Line: 1237 */
 else  /* Line: 1236 */ {
break;
} /* Line: 1236 */
} /* Line: 1236 */
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmpty_1(BEC_4_6_TextString beva_value) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_value == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1245 */ {
bevt_3_tmpvar_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_lesser_1(bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1245 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1245 */ {
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /* Line: 1246 */
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_notEmpty_1(BEC_4_6_TextString beva_value) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_value == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1252 */ {
bevt_3_tmpvar_phold = bevo_3;
bevt_2_tmpvar_phold = beva_value.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1252 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1252 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1252 */
 else  /* Line: 1252 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1252 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 1253 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_spaceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_space = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_emptyGet_0() {
return bevp_empty;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emptySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_empty = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_quoteSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_quote = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_tabGet_0() {
return bevp_tab;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_tabSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_tab = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_dosNewlineGet_0() {
return bevp_dosNewline;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_dosNewlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dosNewline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_unixNewlineGet_0() {
return bevp_unixNewline;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_unixNewlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_unixNewline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_crSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lf = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_colonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_colon = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_9_TextTokenizer bem_lineSplitterGet_0() {
return bevp_lineSplitter;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lineSplitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lineSplitter = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_wsGet_0() {
return bevp_ws;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_wsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ws = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1154, 1155, 1156, 1156, 1157, 1157, 1158, 1159, 1161, 1161, 1162, 1163, 1164, 1165, 1168, 1169, 1170, 1171, 1175, 1175, 1175, 1179, 1180, 1180, 1181, 1181, 1183, 1184, 1184, 1185, 1186, 1187, 1187, 1189, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1201, 1203, 1206, 1207, 1211, 1211, 1211, 1213, 1215, 1219, 1219, 0, 1219, 1219, 0, 0, 1219, 1220, 1220, 1220, 1220, 1221, 1222, 1223, 1224, 1225, 1225, 1226, 1227, 1228, 1229, 1229, 1229, 1225, 1232, 1232, 1232, 1236, 0, 1236, 1236, 1237, 1238, 1238, 1241, 1241, 1245, 1245, 0, 1245, 1245, 1245, 0, 0, 1246, 1246, 1248, 1248, 1252, 1252, 1252, 1252, 0, 0, 0, 1253, 1253, 1255, 1255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 65, 66, 67, 78, 79, 80, 82, 83, 85, 86, 87, 90, 92, 93, 94, 100, 113, 114, 115, 116, 119, 121, 122, 125, 128, 132, 133, 141, 142, 143, 146, 148, 169, 174, 175, 178, 183, 184, 187, 191, 193, 194, 195, 196, 197, 198, 199, 200, 201, 204, 206, 207, 208, 210, 211, 212, 214, 220, 221, 222, 231, 231, 234, 236, 237, 239, 240, 247, 248, 258, 263, 264, 267, 268, 269, 271, 274, 278, 279, 281, 282, 291, 296, 297, 298, 300, 303, 307, 310, 311, 313, 314, 317, 320, 324, 327, 331, 334, 338, 341, 345, 348, 352, 355, 359, 362, 366, 369, 373, 376, 380, 383, 387, 390, 394, 397};
/* BEGIN LINEINFO 
assign 1 1154 42
new 0 1154 42
assign 1 1155 43
new 0 1155 43
assign 1 1156 44
new 0 1156 44
assign 1 1156 45
codeNew 1 1156 45
assign 1 1157 46
new 0 1157 46
assign 1 1157 47
codeNew 1 1157 47
assign 1 1158 48
new 0 1158 48
assign 1 1159 49
new 0 1159 49
assign 1 1161 50
new 0 1161 50
assign 1 1161 51
codeNew 1 1161 51
assign 1 1162 52
new 0 1162 52
assign 1 1163 53
new 0 1163 53
assign 1 1164 54
new 1 1164 54
assign 1 1165 55
new 0 1165 55
put 1 1168 56
put 1 1169 57
put 1 1170 58
put 1 1171 59
assign 1 1175 65
joinBuffer 2 1175 65
assign 1 1175 66
extractString 0 1175 66
return 1 1175 67
assign 1 1179 78
iteratorGet 0 1179 78
assign 1 1180 79
hasNextGet 0 1180 79
assign 1 1180 80
not 0 1180 80
assign 1 1181 82
new 0 1181 82
return 1 1181 83
assign 1 1183 85
new 0 1183 85
assign 1 1184 86
nextGet 0 1184 86
addValue 1 1184 87
assign 1 1185 90
hasNextGet 0 1185 90
addValue 1 1186 92
assign 1 1187 93
nextGet 0 1187 93
addValue 1 1187 94
return 1 1189 100
assign 1 1193 113
new 0 1193 113
assign 1 1194 114
new 0 1194 114
assign 1 1195 115
new 0 1195 115
assign 1 1196 116
mbiterGet 0 1196 116
assign 1 1197 119
hasNextGet 0 1197 119
assign 1 1198 121
nextGet 0 1198 121
assign 1 1199 122
has 1 1199 122
assign 1 1201 125
increment 0 1201 125
assign 1 1203 128
increment 0 1203 128
assign 1 1206 132
new 0 1206 132
assign 1 1207 133
new 0 1207 133
assign 1 1211 141
sizeGet 0 1211 141
assign 1 1211 142
subtract 1 1211 142
assign 1 1211 143
substring 2 1211 143
assign 1 1213 146
new 0 1213 146
return 1 1215 148
assign 1 1219 169
undef 1 1219 174
assign 1 0 175
assign 1 1219 178
undef 1 1219 183
assign 1 0 184
assign 1 0 187
return 1 1219 191
assign 1 1220 193
new 0 1220 193
assign 1 1220 194
sizeGet 0 1220 194
assign 1 1220 195
sizeGet 0 1220 195
assign 1 1220 196
min 2 1220 196
assign 1 1221 197
biterGet 0 1221 197
assign 1 1222 198
biterGet 0 1222 198
assign 1 1223 199
new 0 1223 199
assign 1 1224 200
new 0 1224 200
assign 1 1225 201
new 0 1225 201
assign 1 1225 204
lesser 1 1225 204
next 1 1226 206
next 1 1227 207
assign 1 1228 208
notEquals 1 1228 208
assign 1 1229 210
new 0 1229 210
assign 1 1229 211
substring 2 1229 211
return 1 1229 212
incrementValue 0 1225 214
assign 1 1232 220
new 0 1232 220
assign 1 1232 221
substring 2 1232 221
return 1 1232 222
assign 1 1236 231
iteratorGet 0 0 231
assign 1 1236 234
hasNextGet 0 1236 234
assign 1 1236 236
nextGet 0 1236 236
assign 1 1237 237
isEmpty 1 1237 237
assign 1 1238 239
new 0 1238 239
return 1 1238 240
assign 1 1241 247
new 0 1241 247
return 1 1241 248
assign 1 1245 258
undef 1 1245 263
assign 1 0 264
assign 1 1245 267
sizeGet 0 1245 267
assign 1 1245 268
new 0 1245 268
assign 1 1245 269
lesser 1 1245 269
assign 1 0 271
assign 1 0 274
assign 1 1246 278
new 0 1246 278
return 1 1246 279
assign 1 1248 281
new 0 1248 281
return 1 1248 282
assign 1 1252 291
def 1 1252 296
assign 1 1252 297
new 0 1252 297
assign 1 1252 298
notEquals 1 1252 298
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 1253 310
new 0 1253 310
return 1 1253 311
assign 1 1255 313
new 0 1255 313
return 1 1255 314
return 1 0 317
assign 1 0 320
return 1 0 324
assign 1 0 327
return 1 0 331
assign 1 0 334
return 1 0 338
assign 1 0 341
return 1 0 345
assign 1 0 348
return 1 0 352
assign 1 0 355
return 1 0 359
assign 1 0 362
return 1 0 366
assign 1 0 369
return 1 0 373
assign 1 0 376
return 1 0 380
assign 1 0 383
return 1 0 387
assign 1 0 390
return 1 0 394
assign 1 0 397
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 482013217: return bem_spaceGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 1081741254: return bem_emptyGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1259904107: return bem_quoteGet_0();
case 1502128718: return bem_default_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1708371387: return bem_dosNewlineGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1599801355: return bem_wsGet_0();
case 55016493: return bem_lfGet_0();
case 929570062: return bem_tabGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 776765523: return bem_newlineGet_0();
case 1000967768: return bem_crGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1152565608: return bem_colonGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 527120532: return bem_lineSplitterGet_0();
case 1354714650: return bem_copy_0();
case 1567400443: return bem_unixNewlineGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1270986360: return bem_quoteSet_1(bevd_0);
case 1719453640: return bem_dosNewlineSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 516038279: return bem_lineSplitterSet_1(bevd_0);
case 1629015603: return bem_anyEmpty_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1012050021: return bem_crSet_1(bevd_0);
case 66098746: return bem_lfSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1437735788: return bem_notEmpty_1((BEC_4_6_TextString) bevd_0);
case 493095470: return bem_spaceSet_1(bevd_0);
case 918487809: return bem_tabSet_1(bevd_0);
case 1578482696: return bem_unixNewlineSet_1(bevd_0);
case 1610883608: return bem_wsSet_1(bevd_0);
case 2091366709: return bem_isEmpty_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1070659001: return bem_emptySet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1163647861: return bem_colonSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1881757494: return bem_strip_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1154529699: return bem_join_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 941304624: return bem_commonPrefix_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1331758909: return bem_joinBuffer_2((BEC_4_6_TextString) bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_4_7_TextStrings();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_4_7_TextStrings.bevs_inst = (BEC_4_7_TextStrings)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_4_7_TextStrings.bevs_inst;
}
}
}
