namespace be.BEL_4_Base {
/* IO:File: source/build/Build.be */
public class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bels_6 = {0x31};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_11 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 12));
private static byte[] bels_12 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 21));
private static byte[] bels_13 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 6));
private static byte[] bels_14 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 13));
private static byte[] bels_15 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 21));
private static byte[] bels_16 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 6));
private static byte[] bels_17 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_18 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 5));
private static byte[] bels_19 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_21 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_22 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_23 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_24 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_25 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_26 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_27 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_28 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_29 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_30 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_31 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_32 = {0x74,0x72,0x75,0x65};
private static byte[] bels_33 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_35 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_36 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_37 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_38 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_39 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_40 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_42 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_43 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_44 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_45 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_49 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_50 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_51 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_52 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_53 = {0x72,0x75,0x6E};
private static byte[] bels_54 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_55 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_56 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_57 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_58 = {0x67,0x63,0x63};
private static byte[] bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_60 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_61 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_61, 9));
private static byte[] bels_62 = {};
private static byte[] bels_63 = {0x63};
private static byte[] bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_64, 8));
private static byte[] bels_65 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_65, 7));
private static byte[] bels_66 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_67 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_68 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_68, 2));
private static byte[] bels_69 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_69, 2));
private static byte[] bels_70 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_70, 2));
private static byte[] bels_71 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_72 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_72, 19));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_73, 31));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_74, 31));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_75, 41));
private static byte[] bels_76 = {0x2F};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_76, 1));
private static byte[] bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_77, 31));
private static byte[] bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_78, 41));
private static byte[] bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_79, 51));
private static byte[] bels_80 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_80, 14));
private static byte[] bels_81 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_81, 19));
private static byte[] bels_82 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_82, 9));
private static byte[] bels_83 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_83, 13));
private static byte[] bels_84 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_84, 2));
private static byte[] bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_85, 22));
private static byte[] bels_86 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_86, 3));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_87, 15));
private static byte[] bels_88 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_88, 4));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_90, 5));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_92, 6));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_94, 7));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_96, 8));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_98, 9));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bevo_43 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_99, 15));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_44 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_100, 10));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bevo_45 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_101, 15));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_46 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_102, 11));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bevo_47 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_103, 16));
private static byte[] bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_48 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_104, 12));
private static byte[] bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bevo_49 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_105, 16));
private static byte[] bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_50 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_106, 13));
private static byte[] bels_107 = {0x20};
private static BEC_2_4_6_TextString bevo_51 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_107, 1));
private static byte[] bels_108 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bevo_52 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_108, 16));
public static new BEC_2_5_5_BuildBuild bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 97 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevt_2_tmpvar_phold = this.bem_main_1(bevl__args);
bevt_1_tmpvar_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_5));
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevp_params.bem_get_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 115 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevl_res = this.bem_go_0();
bevl_i.bevi_int++;
} /* Line: 115 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return bevl_res;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 125 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_7));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
} /* Line: 128 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 133 */
if (bevp_printSteps.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 135 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 136 */
return bevl_whatResult;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_10));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 148 */
return beva_addTo;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_113_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_120_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_17));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 158 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 159 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 159 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 162 */
} /* Line: 160 */
 else  /* Line: 159 */ {
break;
} /* Line: 159 */
} /* Line: 159 */
} /* Line: 159 */
bevt_13_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 167 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 168 */
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_19));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_20));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_21));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 172 */
 else  /* Line: 173 */ {
bevp_exeName = bevp_libName;
} /* Line: 174 */
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_22));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_23));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_24));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_25));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_26));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_27));
bevt_36_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_28));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_2_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_29));
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_30));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_31));
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_32));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_33));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_34));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_35));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_55_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_36));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_57_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_37));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_38));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_61_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_39));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_40));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_41));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_42));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_69_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_43));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_71_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_44));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 225 */
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_45));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 229 */
 else  /* Line: 230 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 231 */
bevt_75_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_46));
bevt_76_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_47));
bevt_78_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_48));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_49));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_50));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_84_tmpvar_phold.bevi_bool) {
bevt_83_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_83_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 240 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 241 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_51));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bels_52));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_53));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_54));
bevt_90_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_55));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_56));
bevp_emitFlags = bevp_params.bem_get_1(bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_57));
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_58));
bevt_93_tmpvar_phold = bevp_params.bem_get_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_93_tmpvar_phold.bem_firstGet_0();
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_59));
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_60));
bevt_96_tmpvar_phold = bevp_params.bem_get_2(bevt_97_tmpvar_phold, bevt_98_tmpvar_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = bevo_10;
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_102_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_62));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_102_tmpvar_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_63));
} /* Line: 263 */
bevt_106_tmpvar_phold = bevo_11;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevt_107_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_104_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_109_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 272 */
bevt_111_tmpvar_phold = bevo_12;
bevt_110_tmpvar_phold = bevl_outLang.bem_add_1(bevt_111_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_langSources == null) {
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_113_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 277 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_114_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_114_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_115_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_116_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_116_tmpvar_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_existsGet_0();
if (bevt_118_tmpvar_phold.bevi_bool) {
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_120_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpvar_phold.bem_makeDirs_0();
} /* Line: 290 */
if (bevp_emitFileHeader == null) {
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_122_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_122_tmpvar_phold.bem_readerGet_0();
bevt_123_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_123_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 295 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_66));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_67));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 322 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 320 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 327 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 340 */ {
return bevp_emitCommon;
} /* Line: 341 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 348 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 348 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 354 */ {
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_71));
bevt_8_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 355 */
} /* Line: 348 */
} /* Line: 348 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 358 */
return null;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_4_8_TimeInterval bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_16_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_21_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_55_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_67_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
bevt_4_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_4_tmpvar_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 371 */ {
bevt_7_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_libName);
bevt_6_tmpvar_phold.bem_print_0();
} /* Line: 372 */
} /* Line: 371 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 377 */ {
bevt_8_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 377 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_10_tmpvar_phold.bevi_bool) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 378 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 381 */
} /* Line: 378 */
 else  /* Line: 377 */ {
break;
} /* Line: 377 */
} /* Line: 377 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 384 */ {
bevt_11_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 384 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpvar_phold.bevi_bool) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_14_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_14_tmpvar_phold);
} /* Line: 389 */
} /* Line: 385 */
 else  /* Line: 384 */ {
break;
} /* Line: 384 */
} /* Line: 384 */
if (bevp_parse.bevi_bool) /* Line: 392 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 394 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 394 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 397 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 399 */
bevt_17_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_16_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_17_tmpvar_phold.bem_now_0();
bevp_parseTime = bevt_16_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_printSteps.bevi_bool) /* Line: 403 */ {
bevt_19_tmpvar_phold = bevo_17;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_18_tmpvar_phold.bem_print_0();
} /* Line: 404 */
bevt_21_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevt_22_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_22_tmpvar_phold.bem_doEmit_0();
bevt_23_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_23_tmpvar_phold;
} /* Line: 409 */
if (bevp_doEmit.bevi_bool) /* Line: 411 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 415 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 415 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 417 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_26_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_26_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 421 */ {
bevt_27_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 421 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 423 */
 else  /* Line: 421 */ {
break;
} /* Line: 421 */
} /* Line: 421 */
} /* Line: 421 */
bevt_29_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 428 */ {
bevt_32_tmpvar_phold = bevo_18;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_31_tmpvar_phold.bem_print_0();
} /* Line: 429 */
bevt_34_tmpvar_phold = bevo_19;
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_33_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 432 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 434 */
if (bevp_make.bevi_bool) /* Line: 437 */ {
if (bevp_genOnly.bevi_bool) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 438 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 441 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 442 */ {
bevt_36_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 442 */ {
bevl_bp = bevt_2_tmpvar_loop.bem_nextGet_0();
bevt_37_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_37_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_38_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_38_tmpvar_phold.bem_copy_0();
bevt_40_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_39_tmpvar_phold);
bevt_42_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 446 */ {
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_43_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 447 */
bevt_46_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_44_tmpvar_phold != null && bevt_44_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_44_tmpvar_phold).bevi_bool) /* Line: 449 */ {
bevt_47_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_48_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
} /* Line: 450 */
} /* Line: 449 */
 else  /* Line: 442 */ {
break;
} /* Line: 442 */
} /* Line: 442 */
} /* Line: 442 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 457 */ {
bevt_49_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_49_tmpvar_phold != null && bevt_49_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_49_tmpvar_phold).bevi_bool) /* Line: 457 */ {
bevt_50_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 457 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 457 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 457 */
 else  /* Line: 457 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 457 */ {
bevt_51_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_51_tmpvar_phold);
bevt_56_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_55_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_56_tmpvar_phold.bem_copy_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bem_toString_0();
bevt_57_tmpvar_phold = bevo_20;
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_add_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_52_tmpvar_phold);
bevt_60_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 461 */ {
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_61_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 462 */
bevt_64_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_62_tmpvar_phold != null && bevt_62_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_62_tmpvar_phold).bevi_bool) /* Line: 464 */ {
bevt_65_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_66_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_65_tmpvar_phold, bevt_66_tmpvar_phold);
} /* Line: 465 */
} /* Line: 464 */
 else  /* Line: 457 */ {
break;
} /* Line: 457 */
} /* Line: 457 */
} /* Line: 457 */
} /* Line: 438 */
bevt_68_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_67_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_68_tmpvar_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_67_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 472 */ {
bevt_71_tmpvar_phold = bevo_21;
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_70_tmpvar_phold.bem_print_0();
} /* Line: 473 */
if (bevp_parseEmitTime == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 475 */ {
bevt_74_tmpvar_phold = bevo_22;
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_73_tmpvar_phold.bem_print_0();
} /* Line: 476 */
if (bevp_parseEmitCompileTime == null) {
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_75_tmpvar_phold.bevi_bool) /* Line: 478 */ {
bevt_77_tmpvar_phold = bevo_23;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_76_tmpvar_phold.bem_print_0();
} /* Line: 479 */
if (bevp_run.bevi_bool) /* Line: 482 */ {
bevt_78_tmpvar_phold = bevo_24;
bevt_78_tmpvar_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_81_tmpvar_phold = bevo_25;
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bem_add_1(bevl_result);
bevt_82_tmpvar_phold = bevo_26;
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_add_1(bevt_82_tmpvar_phold);
bevt_79_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 486 */
bevt_83_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_83_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 492 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 492 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 496 */
 else  /* Line: 492 */ {
break;
} /* Line: 492 */
} /* Line: 492 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 498 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 498 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 502 */
 else  /* Line: 498 */ {
break;
} /* Line: 498 */
} /* Line: 498 */
bevt_6_tmpvar_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 508 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 509 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 512 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 513 */
 else  /* Line: 514 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 517 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 519 */
 else  /* Line: 520 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 522 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 524 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpvar_phold, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public virtual BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 534 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 535 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 550 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 551 */
return bevp_sharedEmitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 564 */ {
if (bevp_printSteps.bevi_bool) /* Line: 565 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 565 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 565 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 565 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 565 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 565 */ {
bevt_4_tmpvar_phold = bevo_27;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 566 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 575 */ {
bevt_11_tmpvar_phold = bevo_28;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 576 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 579 */ {
bevt_13_tmpvar_phold = bevo_29;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 581 */
if (bevp_printSteps.bevi_bool) /* Line: 584 */ {
bevt_15_tmpvar_phold = bevo_30;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 585 */
bevt_16_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 588 */ {
bevt_17_tmpvar_phold = bevo_31;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 590 */
if (bevp_printSteps.bevi_bool) /* Line: 592 */ {
bevt_19_tmpvar_phold = bevo_32;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 593 */
bevt_20_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 598 */ {
bevt_21_tmpvar_phold = bevo_33;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 600 */
if (bevp_printSteps.bevi_bool) /* Line: 603 */ {
bevt_23_tmpvar_phold = bevo_34;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 604 */
bevt_24_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 607 */ {
bevt_25_tmpvar_phold = bevo_35;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 609 */
if (bevp_printSteps.bevi_bool) /* Line: 612 */ {
bevt_27_tmpvar_phold = bevo_36;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 613 */
bevt_28_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 616 */ {
bevt_29_tmpvar_phold = bevo_37;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 618 */
if (bevp_printSteps.bevi_bool) /* Line: 621 */ {
bevt_31_tmpvar_phold = bevo_38;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 622 */
bevt_32_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 625 */ {
bevt_33_tmpvar_phold = bevo_39;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 627 */
if (bevp_printSteps.bevi_bool) /* Line: 630 */ {
bevt_35_tmpvar_phold = bevo_40;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 631 */
bevt_36_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 634 */ {
bevt_37_tmpvar_phold = bevo_41;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 636 */
if (bevp_printSteps.bevi_bool) /* Line: 639 */ {
bevt_39_tmpvar_phold = bevo_42;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 640 */
bevt_40_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 643 */ {
bevt_41_tmpvar_phold = bevo_43;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 645 */
if (bevp_printSteps.bevi_bool) /* Line: 648 */ {
bevt_43_tmpvar_phold = bevo_44;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 649 */
bevt_44_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 652 */ {
bevt_45_tmpvar_phold = bevo_45;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 654 */
if (bevp_printSteps.bevi_bool) /* Line: 657 */ {
bevt_47_tmpvar_phold = bevo_46;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 658 */
bevt_48_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 661 */ {
bevt_49_tmpvar_phold = bevo_47;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 663 */
if (bevp_printSteps.bevi_bool) /* Line: 665 */ {
bevt_51_tmpvar_phold = bevo_48;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 666 */
bevt_52_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 669 */ {
bevt_53_tmpvar_phold = bevo_49;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 671 */
if (bevp_printSteps.bevi_bool) /* Line: 674 */ {
bevt_55_tmpvar_phold = bevo_50;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_51;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 676 */
bevt_57_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 679 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 679 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 679 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 679 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 679 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 679 */ {
bevt_58_tmpvar_phold = bevo_52;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 681 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 683 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 683 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 694 */
 else  /* Line: 683 */ {
break;
} /* Line: 683 */
} /* Line: 683 */
} /* Line: 683 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 704 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 704 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 708 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 709 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 711 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 713 */
} /* Line: 711 */
 else  /* Line: 704 */ {
break;
} /* Line: 704 */
} /* Line: 704 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {53, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 70, 72, 73, 74, 75, 75, 78, 81, 82, 88, 89, 90, 91, 91, 96, 96, 96, 96, 0, 96, 96, 0, 0, 0, 0, 0, 97, 97, 99, 99, 103, 103, 103, 103, 107, 107, 108, 108, 108, 112, 113, 114, 114, 114, 114, 114, 115, 115, 115, 116, 115, 118, 122, 123, 124, 126, 127, 128, 130, 131, 132, 132, 133, 0, 0, 0, 136, 138, 142, 142, 142, 143, 143, 143, 143, 144, 144, 144, 145, 145, 145, 146, 146, 146, 146, 147, 147, 147, 148, 148, 148, 150, 155, 157, 158, 158, 158, 159, 159, 0, 159, 159, 160, 160, 160, 161, 162, 162, 167, 167, 167, 167, 168, 170, 170, 170, 171, 171, 172, 172, 172, 174, 176, 176, 176, 176, 176, 176, 177, 178, 178, 179, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 185, 185, 185, 186, 186, 186, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 233, 233, 233, 234, 234, 234, 235, 235, 236, 236, 237, 238, 238, 239, 239, 239, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 252, 253, 254, 255, 256, 257, 260, 260, 261, 263, 270, 270, 270, 270, 270, 271, 271, 272, 272, 275, 275, 275, 276, 276, 277, 277, 280, 281, 281, 0, 281, 281, 282, 282, 284, 285, 286, 288, 289, 289, 289, 289, 290, 290, 292, 292, 293, 293, 294, 294, 295, 301, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 304, 308, 309, 309, 309, 310, 311, 311, 311, 311, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 319, 319, 319, 319, 319, 320, 320, 321, 0, 321, 321, 322, 327, 327, 327, 328, 329, 329, 329, 329, 329, 329, 336, 336, 340, 340, 341, 346, 346, 347, 348, 348, 349, 350, 350, 351, 352, 352, 353, 355, 355, 355, 357, 358, 360, 365, 365, 366, 367, 368, 368, 369, 370, 372, 372, 372, 375, 377, 0, 377, 377, 378, 378, 378, 379, 380, 381, 384, 0, 384, 384, 385, 385, 385, 386, 387, 388, 389, 389, 394, 394, 395, 397, 399, 402, 402, 402, 404, 404, 404, 406, 406, 406, 408, 408, 409, 409, 412, 413, 415, 415, 415, 416, 417, 419, 420, 421, 421, 421, 422, 423, 427, 427, 427, 428, 428, 429, 429, 429, 431, 431, 431, 434, 438, 438, 439, 440, 442, 0, 442, 442, 443, 443, 444, 444, 445, 445, 445, 446, 446, 447, 447, 449, 449, 449, 450, 450, 450, 454, 455, 457, 457, 0, 0, 0, 458, 458, 459, 459, 459, 459, 459, 459, 459, 459, 461, 461, 462, 462, 464, 464, 464, 465, 465, 465, 470, 470, 470, 472, 472, 473, 473, 473, 475, 475, 476, 476, 476, 478, 478, 479, 479, 479, 483, 483, 484, 485, 485, 485, 485, 485, 486, 488, 488, 492, 492, 492, 493, 494, 494, 495, 496, 498, 498, 498, 499, 500, 500, 501, 502, 504, 504, 508, 508, 508, 508, 509, 509, 509, 511, 511, 512, 512, 512, 512, 513, 515, 515, 515, 515, 515, 517, 517, 518, 518, 519, 522, 522, 522, 524, 526, 526, 527, 527, 527, 527, 528, 532, 533, 533, 534, 534, 535, 541, 541, 542, 543, 550, 550, 551, 553, 558, 559, 560, 561, 562, 563, 563, 0, 0, 0, 566, 566, 566, 566, 568, 570, 570, 570, 570, 571, 571, 571, 572, 576, 576, 578, 578, 580, 580, 581, 581, 585, 585, 587, 587, 589, 589, 590, 590, 593, 593, 596, 596, 597, 599, 599, 600, 600, 604, 604, 606, 606, 608, 608, 609, 609, 613, 613, 615, 615, 617, 617, 618, 618, 622, 622, 624, 624, 626, 626, 627, 627, 631, 631, 633, 633, 635, 635, 636, 636, 640, 640, 642, 642, 644, 644, 645, 645, 649, 649, 651, 651, 653, 653, 654, 654, 658, 658, 660, 660, 662, 662, 663, 663, 666, 666, 668, 668, 670, 670, 671, 671, 675, 675, 676, 676, 678, 678, 0, 0, 0, 680, 680, 681, 681, 683, 683, 683, 684, 686, 687, 688, 688, 689, 690, 690, 690, 691, 692, 693, 694, 700, 701, 702, 703, 703, 704, 704, 705, 706, 706, 707, 708, 708, 709, 711, 711, 712, 713, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 280, 285, 286, 287, 289, 292, 293, 295, 298, 302, 305, 309, 312, 313, 315, 316, 322, 323, 324, 325, 332, 333, 334, 335, 336, 348, 349, 350, 351, 352, 353, 354, 355, 358, 363, 364, 365, 371, 379, 380, 381, 383, 384, 385, 389, 390, 391, 392, 393, 396, 400, 403, 407, 409, 429, 430, 431, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 454, 590, 591, 592, 593, 598, 599, 600, 600, 603, 605, 606, 607, 612, 613, 614, 615, 623, 624, 625, 626, 628, 630, 631, 632, 633, 634, 636, 637, 638, 641, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 692, 693, 695, 696, 697, 702, 703, 705, 706, 707, 712, 713, 715, 716, 717, 722, 723, 725, 726, 727, 732, 733, 735, 736, 737, 742, 743, 745, 746, 747, 752, 753, 755, 756, 757, 762, 763, 765, 766, 767, 772, 773, 775, 776, 777, 782, 783, 785, 786, 787, 792, 793, 796, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 816, 817, 818, 823, 824, 827, 831, 834, 834, 837, 839, 840, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 883, 884, 887, 889, 890, 891, 892, 893, 894, 899, 900, 901, 903, 904, 905, 906, 911, 912, 913, 915, 916, 917, 917, 920, 922, 923, 924, 930, 931, 932, 933, 934, 935, 936, 941, 942, 943, 945, 950, 951, 952, 953, 954, 955, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 1020, 1021, 1022, 1025, 1027, 1028, 1029, 1030, 1031, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1047, 1048, 1048, 1051, 1053, 1054, 1061, 1062, 1063, 1064, 1065, 1066, 1071, 1072, 1072, 1075, 1077, 1078, 1091, 1092, 1095, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1113, 1114, 1128, 1133, 1134, 1136, 1141, 1142, 1143, 1144, 1146, 1149, 1150, 1152, 1155, 1156, 1158, 1161, 1162, 1163, 1167, 1168, 1170, 1271, 1272, 1273, 1274, 1275, 1280, 1281, 1282, 1284, 1285, 1286, 1289, 1290, 1290, 1293, 1295, 1296, 1297, 1302, 1303, 1304, 1305, 1312, 1312, 1315, 1317, 1318, 1319, 1324, 1325, 1326, 1327, 1328, 1329, 1337, 1340, 1342, 1343, 1349, 1351, 1352, 1353, 1355, 1356, 1357, 1359, 1360, 1365, 1366, 1367, 1368, 1369, 1372, 1373, 1374, 1375, 1378, 1380, 1381, 1387, 1388, 1389, 1390, 1393, 1395, 1396, 1403, 1404, 1405, 1406, 1411, 1412, 1413, 1414, 1416, 1417, 1418, 1420, 1423, 1428, 1429, 1430, 1432, 1432, 1435, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1448, 1449, 1451, 1452, 1453, 1455, 1456, 1457, 1465, 1466, 1469, 1471, 1473, 1476, 1480, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1496, 1497, 1499, 1500, 1501, 1503, 1504, 1505, 1514, 1515, 1516, 1517, 1522, 1523, 1524, 1525, 1527, 1532, 1533, 1534, 1535, 1537, 1542, 1543, 1544, 1545, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1558, 1559, 1572, 1573, 1576, 1578, 1579, 1580, 1581, 1582, 1588, 1589, 1592, 1594, 1595, 1596, 1597, 1598, 1604, 1605, 1633, 1634, 1635, 1640, 1641, 1642, 1643, 1645, 1646, 1647, 1648, 1649, 1654, 1655, 1658, 1659, 1660, 1661, 1662, 1663, 1668, 1669, 1670, 1671, 1674, 1675, 1676, 1678, 1680, 1681, 1682, 1683, 1684, 1685, 1686, 1694, 1695, 1696, 1697, 1702, 1703, 1705, 1706, 1707, 1708, 1712, 1717, 1718, 1720, 1799, 1800, 1801, 1802, 1803, 1804, 1805, 1808, 1812, 1815, 1819, 1820, 1821, 1822, 1824, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1834, 1835, 1837, 1838, 1840, 1841, 1842, 1843, 1846, 1847, 1849, 1850, 1852, 1853, 1854, 1855, 1858, 1859, 1861, 1862, 1863, 1865, 1866, 1867, 1868, 1871, 1872, 1874, 1875, 1877, 1878, 1879, 1880, 1883, 1884, 1886, 1887, 1889, 1890, 1891, 1892, 1895, 1896, 1898, 1899, 1901, 1902, 1903, 1904, 1907, 1908, 1910, 1911, 1913, 1914, 1915, 1916, 1919, 1920, 1922, 1923, 1925, 1926, 1927, 1928, 1931, 1932, 1934, 1935, 1937, 1938, 1939, 1940, 1943, 1944, 1946, 1947, 1949, 1950, 1951, 1952, 1955, 1956, 1958, 1959, 1961, 1962, 1963, 1964, 1967, 1968, 1969, 1970, 1972, 1973, 1975, 1979, 1982, 1986, 1987, 1988, 1989, 1991, 1992, 1995, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2031, 2032, 2033, 2034, 2035, 2036, 2039, 2041, 2042, 2043, 2044, 2045, 2046, 2048, 2050, 2051, 2053, 2054, 2064, 2067, 2071, 2074, 2078, 2081, 2085, 2088, 2092, 2095, 2099, 2102, 2106, 2109, 2113, 2116, 2120, 2123, 2127, 2130, 2134, 2137, 2141, 2144, 2148, 2151, 2155, 2158, 2162, 2165, 2169, 2172, 2176, 2179, 2183, 2186, 2190, 2193, 2197, 2200, 2204, 2207, 2211, 2214, 2218, 2221, 2225, 2228, 2232, 2235, 2239, 2242, 2246, 2249, 2253, 2256, 2260, 2263, 2267, 2270, 2274, 2277, 2281, 2284, 2288, 2291, 2295, 2298, 2302, 2305, 2309, 2312, 2316, 2319, 2323, 2326, 2330, 2333, 2337, 2340, 2344, 2347, 2351, 2354, 2358, 2361, 2365, 2368, 2372, 2375, 2379, 2382, 2386, 2389, 2393, 2396, 2400, 2403, 2407, 2410, 2414, 2417, 2421, 2424, 2428, 2431, 2435, 2438, 2442, 2445, 2449, 2452, 2456, 2459, 2463, 2466, 2470, 2473, 2477, 2480, 2484, 2487, 2491, 2494, 2498, 2501, 2505, 2508, 2512, 2515, 2519, 2522, 2526, 2529, 2533, 2536, 2540};
/* BEGIN LINEINFO 
assign 1 53 243
new 0 53 243
assign 1 55 244
new 0 55 244
assign 1 56 245
new 0 56 245
assign 1 57 246
new 0 57 246
assign 1 58 247
new 0 58 247
assign 1 60 248
new 0 60 248
assign 1 61 249
new 0 61 249
assign 1 62 250
new 0 62 250
assign 1 63 251
new 0 63 251
assign 1 64 252
new 0 64 252
assign 1 65 253
new 0 65 253
assign 1 66 254
new 0 66 254
assign 1 70 255
new 0 70 255
assign 1 72 256
new 1 72 256
assign 1 73 257
ntypesGet 0 73 257
assign 1 74 258
twtokGet 0 74 258
assign 1 75 259
new 0 75 259
assign 1 75 260
new 1 75 260
assign 1 78 261
new 0 78 261
assign 1 81 262
new 0 81 262
assign 1 82 263
new 0 82 263
assign 1 88 264
new 0 88 264
assign 1 89 265
new 0 89 265
assign 1 90 266
new 0 90 266
assign 1 91 267
new 0 91 267
assign 1 91 268
new 1 91 268
assign 1 96 280
def 1 96 285
assign 1 96 286
new 0 96 286
assign 1 96 287
equals 1 96 287
assign 1 0 289
assign 1 96 292
new 0 96 292
assign 1 96 293
ends 1 96 293
assign 1 0 295
assign 1 0 298
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 97 312
new 0 97 312
return 1 97 313
assign 1 99 315
new 0 99 315
return 1 99 316
assign 1 103 322
new 0 103 322
assign 1 103 323
new 0 103 323
assign 1 103 324
swap 2 103 324
return 1 103 325
assign 1 107 332
new 0 107 332
assign 1 107 333
argsGet 0 107 333
assign 1 108 334
new 0 108 334
assign 1 108 335
main 1 108 335
exit 1 108 336
assign 1 112 348
assign 1 113 349
new 1 113 349
assign 1 114 350
new 0 114 350
assign 1 114 351
new 0 114 351
assign 1 114 352
get 2 114 352
assign 1 114 353
firstGet 0 114 353
assign 1 114 354
new 1 114 354
assign 1 115 355
new 0 115 355
assign 1 115 358
lesser 1 115 363
assign 1 116 364
go 0 116 364
incrementValue 0 115 365
return 1 118 371
assign 1 122 379
new 0 122 379
config 0 123 380
assign 1 124 381
new 0 124 381
assign 1 126 383
new 0 126 383
assign 1 127 384
doWhat 0 127 384
assign 1 128 385
new 0 128 385
assign 1 130 389
toString 0 130 389
assign 1 131 390
new 0 131 390
assign 1 132 391
new 0 132 391
assign 1 132 392
add 1 132 392
assign 1 133 393
new 0 133 393
assign 1 0 396
assign 1 0 400
assign 1 0 403
print 0 136 407
return 1 138 409
assign 1 142 429
nameGet 0 142 429
assign 1 142 430
new 0 142 430
assign 1 142 431
equals 1 142 431
assign 1 143 433
new 0 143 433
assign 1 143 434
add 1 143 434
assign 1 143 435
add 1 143 435
assign 1 143 436
add 1 143 436
assign 1 144 437
new 0 144 437
assign 1 144 438
add 1 144 438
assign 1 144 439
add 1 144 439
assign 1 145 440
new 0 145 440
assign 1 145 441
add 1 145 441
assign 1 145 442
add 1 145 442
assign 1 146 443
new 0 146 443
assign 1 146 444
add 1 146 444
assign 1 146 445
add 1 146 445
assign 1 146 446
add 1 146 446
assign 1 147 447
new 0 147 447
assign 1 147 448
add 1 147 448
assign 1 147 449
add 1 147 449
assign 1 148 450
new 0 148 450
assign 1 148 451
add 1 148 451
assign 1 148 452
add 1 148 452
return 1 150 454
assign 1 155 590
new 0 155 590
assign 1 157 591
new 0 157 591
assign 1 158 592
get 1 158 592
assign 1 158 593
def 1 158 598
assign 1 159 599
get 1 159 599
assign 1 159 600
iteratorGet 0 0 600
assign 1 159 603
hasNextGet 0 159 603
assign 1 159 605
nextGet 0 159 605
assign 1 160 606
has 1 160 606
assign 1 160 607
not 0 160 612
put 1 161 613
assign 1 162 614
new 1 162 614
addFile 1 162 615
assign 1 167 623
new 0 167 623
assign 1 167 624
nameGet 0 167 624
assign 1 167 625
new 0 167 625
assign 1 167 626
equals 1 167 626
preProcessorSet 1 168 628
assign 1 170 630
new 0 170 630
assign 1 170 631
get 1 170 631
assign 1 170 632
firstGet 0 170 632
assign 1 171 633
new 0 171 633
assign 1 171 634
has 1 171 634
assign 1 172 636
new 0 172 636
assign 1 172 637
get 1 172 637
assign 1 172 638
firstGet 0 172 638
assign 1 174 641
assign 1 176 643
new 0 176 643
assign 1 176 644
new 0 176 644
assign 1 176 645
get 2 176 645
assign 1 176 646
firstGet 0 176 646
assign 1 176 647
new 1 176 647
assign 1 176 648
pathGet 0 176 648
addStep 1 177 649
assign 1 178 650
new 0 178 650
addStep 1 178 651
assign 1 179 652
new 0 179 652
assign 1 179 653
new 0 179 653
assign 1 179 654
get 2 179 654
assign 1 179 655
firstGet 0 179 655
assign 1 179 656
new 1 179 656
assign 1 179 657
pathGet 0 179 657
assign 1 180 658
new 0 180 658
assign 1 180 659
new 0 180 659
assign 1 180 660
nameGet 0 180 660
assign 1 180 661
get 2 180 661
assign 1 180 662
firstGet 0 180 662
assign 1 180 663
new 1 180 663
assign 1 181 664
new 0 181 664
assign 1 181 665
nameGet 0 181 665
assign 1 181 666
get 2 181 666
assign 1 181 667
firstGet 0 181 667
assign 1 181 668
new 1 181 668
assign 1 182 669
new 0 182 669
assign 1 182 670
new 0 182 670
assign 1 182 671
get 2 182 671
assign 1 182 672
firstGet 0 182 672
assign 1 182 673
new 1 182 673
assign 1 183 674
new 0 183 674
assign 1 183 675
new 0 183 675
assign 1 183 676
get 2 183 676
assign 1 183 677
firstGet 0 183 677
assign 1 183 678
new 1 183 678
assign 1 185 679
new 0 185 679
assign 1 185 680
get 1 185 680
assign 1 185 681
firstGet 0 185 681
assign 1 186 682
new 0 186 682
assign 1 186 683
get 1 186 683
assign 1 186 684
firstGet 0 186 684
assign 1 187 685
new 0 187 685
assign 1 187 686
get 1 187 686
assign 1 188 687
undef 1 188 692
assign 1 189 693
new 0 189 693
assign 1 191 695
new 0 191 695
assign 1 191 696
get 1 191 696
assign 1 192 697
undef 1 192 702
assign 1 193 703
new 0 193 703
assign 1 195 705
new 0 195 705
assign 1 195 706
get 1 195 706
assign 1 196 707
undef 1 196 712
assign 1 197 713
new 0 197 713
assign 1 199 715
new 0 199 715
assign 1 199 716
get 1 199 716
assign 1 200 717
undef 1 200 722
assign 1 201 723
new 0 201 723
assign 1 203 725
new 0 203 725
assign 1 203 726
get 1 203 726
assign 1 204 727
undef 1 204 732
assign 1 205 733
new 0 205 733
assign 1 207 735
new 0 207 735
assign 1 207 736
get 1 207 736
assign 1 208 737
undef 1 208 742
assign 1 209 743
new 0 209 743
assign 1 211 745
new 0 211 745
assign 1 211 746
get 1 211 746
assign 1 212 747
undef 1 212 752
assign 1 213 753
new 0 213 753
assign 1 215 755
new 0 215 755
assign 1 215 756
get 1 215 756
assign 1 216 757
undef 1 216 762
assign 1 217 763
new 0 217 763
assign 1 219 765
new 0 219 765
assign 1 219 766
get 1 219 766
assign 1 220 767
undef 1 220 772
assign 1 221 773
new 0 221 773
assign 1 223 775
new 0 223 775
assign 1 223 776
get 1 223 776
assign 1 224 777
def 1 224 782
assign 1 225 783
firstGet 0 225 783
assign 1 227 785
new 0 227 785
assign 1 227 786
get 1 227 786
assign 1 228 787
def 1 228 792
assign 1 229 793
firstGet 0 229 793
assign 1 231 796
new 0 231 796
assign 1 233 798
new 0 233 798
assign 1 233 799
new 0 233 799
assign 1 233 800
isTrue 2 233 800
assign 1 234 801
new 0 234 801
assign 1 234 802
new 0 234 802
assign 1 234 803
isTrue 2 234 803
assign 1 235 804
new 0 235 804
assign 1 235 805
isTrue 1 235 805
assign 1 236 806
new 0 236 806
assign 1 236 807
isTrue 1 236 807
assign 1 237 808
new 0 237 808
assign 1 238 809
new 0 238 809
assign 1 238 810
get 1 238 810
assign 1 239 811
def 1 239 816
assign 1 239 817
isEmptyGet 0 239 817
assign 1 239 818
not 0 239 823
assign 1 0 824
assign 1 0 827
assign 1 0 831
assign 1 240 834
linkedListIteratorGet 0 0 834
assign 1 240 837
hasNextGet 0 240 837
assign 1 240 839
nextGet 0 240 839
put 1 241 840
assign 1 244 847
new 0 244 847
assign 1 244 848
isTrue 1 244 848
assign 1 245 849
new 0 245 849
assign 1 245 850
isTrue 1 245 850
assign 1 246 851
new 0 246 851
assign 1 246 852
isTrue 1 246 852
assign 1 247 853
new 0 247 853
assign 1 247 854
new 0 247 854
assign 1 247 855
isTrue 2 247 855
assign 1 248 856
new 0 248 856
assign 1 248 857
get 1 248 857
assign 1 249 858
new 0 249 858
assign 1 249 859
get 1 249 859
assign 1 250 860
new 0 250 860
assign 1 250 861
new 0 250 861
assign 1 250 862
get 2 250 862
assign 1 250 863
firstGet 0 250 863
assign 1 251 864
new 0 251 864
assign 1 251 865
new 0 251 865
assign 1 251 866
get 2 251 866
assign 1 251 867
firstGet 0 251 867
assign 1 252 868
new 0 252 868
assign 1 252 869
add 1 252 869
assign 1 252 870
new 0 252 870
assign 1 252 871
get 2 252 871
assign 1 252 872
firstGet 0 252 872
assign 1 253 873
new 0 253 873
assign 1 254 874
new 0 254 874
assign 1 255 875
new 0 255 875
assign 1 256 876
new 0 256 876
assign 1 257 877
new 0 257 877
assign 1 260 878
def 1 260 883
assign 1 261 884
firstGet 0 261 884
assign 1 263 887
new 0 263 887
assign 1 270 889
new 0 270 889
assign 1 270 890
add 1 270 890
assign 1 270 891
nameGet 0 270 891
assign 1 270 892
add 1 270 892
assign 1 270 893
get 1 270 893
assign 1 271 894
def 1 271 899
assign 1 272 900
orderedGet 0 272 900
addAll 1 272 901
assign 1 275 903
new 0 275 903
assign 1 275 904
add 1 275 904
assign 1 275 905
get 1 275 905
assign 1 276 906
def 1 276 911
assign 1 277 912
orderedGet 0 277 912
addAll 1 277 913
assign 1 280 915
new 0 280 915
assign 1 281 916
orderedGet 0 281 916
assign 1 281 917
iteratorGet 0 0 917
assign 1 281 920
hasNextGet 0 281 920
assign 1 281 922
nextGet 0 281 922
assign 1 282 923
new 1 282 923
addValue 1 282 924
assign 1 284 930
newlineGet 0 284 930
assign 1 285 931
assign 1 286 932
new 1 286 932
assign 1 288 933
copy 0 288 933
assign 1 289 934
fileGet 0 289 934
assign 1 289 935
existsGet 0 289 935
assign 1 289 936
not 0 289 941
assign 1 290 942
fileGet 0 290 942
makeDirs 0 290 943
assign 1 292 945
def 1 292 950
assign 1 293 951
new 1 293 951
assign 1 293 952
readerGet 0 293 952
assign 1 294 953
open 0 294 953
assign 1 294 954
readString 0 294 954
close 0 295 955
assign 1 301 969
classNameGet 0 301 969
assign 1 302 970
add 1 302 970
assign 1 302 971
new 0 302 971
assign 1 302 972
add 1 302 972
assign 1 302 973
toString 0 302 973
assign 1 302 974
add 1 302 974
assign 1 303 975
add 1 303 975
assign 1 303 976
new 0 303 976
assign 1 303 977
add 1 303 977
assign 1 303 978
toString 0 303 978
assign 1 303 979
add 1 303 979
return 1 304 980
assign 1 308 1020
new 0 308 1020
assign 1 309 1021
classesGet 0 309 1021
assign 1 309 1022
valueIteratorGet 0 309 1022
assign 1 309 1025
hasNextGet 0 309 1025
assign 1 310 1027
nextGet 0 310 1027
assign 1 311 1028
shouldEmitGet 0 311 1028
assign 1 311 1029
heldGet 0 311 1029
assign 1 311 1030
fromFileGet 0 311 1030
assign 1 311 1031
has 1 311 1031
assign 1 312 1033
heldGet 0 312 1033
assign 1 312 1034
namepathGet 0 312 1034
assign 1 312 1035
toString 0 312 1035
put 1 312 1036
assign 1 313 1037
usedByGet 0 313 1037
assign 1 313 1038
heldGet 0 313 1038
assign 1 313 1039
namepathGet 0 313 1039
assign 1 313 1040
toString 0 313 1040
assign 1 313 1041
get 1 313 1041
assign 1 314 1042
def 1 314 1047
assign 1 315 1048
setIteratorGet 0 0 1048
assign 1 315 1051
hasNextGet 0 315 1051
assign 1 315 1053
nextGet 0 315 1053
put 1 316 1054
assign 1 319 1061
subClassesGet 0 319 1061
assign 1 319 1062
heldGet 0 319 1062
assign 1 319 1063
namepathGet 0 319 1063
assign 1 319 1064
toString 0 319 1064
assign 1 319 1065
get 1 319 1065
assign 1 320 1066
def 1 320 1071
assign 1 321 1072
setIteratorGet 0 0 1072
assign 1 321 1075
hasNextGet 0 321 1075
assign 1 321 1077
nextGet 0 321 1077
put 1 322 1078
assign 1 327 1091
classesGet 0 327 1091
assign 1 327 1092
valueIteratorGet 0 327 1092
assign 1 327 1095
hasNextGet 0 327 1095
assign 1 328 1097
nextGet 0 328 1097
assign 1 329 1098
heldGet 0 329 1098
assign 1 329 1099
heldGet 0 329 1099
assign 1 329 1100
namepathGet 0 329 1100
assign 1 329 1101
toString 0 329 1101
assign 1 329 1102
has 1 329 1102
shouldWriteSet 1 329 1103
assign 1 336 1113
new 0 336 1113
return 1 336 1114
assign 1 340 1128
def 1 340 1133
return 1 341 1134
assign 1 346 1136
def 1 346 1141
assign 1 347 1142
firstGet 0 347 1142
assign 1 348 1143
new 0 348 1143
assign 1 348 1144
equals 1 348 1144
assign 1 349 1146
new 1 349 1146
assign 1 350 1149
new 0 350 1149
assign 1 350 1150
equals 1 350 1150
assign 1 351 1152
new 1 351 1152
assign 1 352 1155
new 0 352 1155
assign 1 352 1156
equals 1 352 1156
assign 1 353 1158
new 1 353 1158
assign 1 355 1161
new 0 355 1161
assign 1 355 1162
new 1 355 1162
throw 1 355 1163
dynConditionsAllSet 1 357 1167
return 1 358 1168
return 1 360 1170
assign 1 365 1271
new 0 365 1271
assign 1 365 1272
now 0 365 1272
assign 1 366 1273
new 0 366 1273
assign 1 367 1274
emitterGet 0 367 1274
assign 1 368 1275
def 1 368 1280
assign 1 369 1281
new 4 369 1281
put 1 370 1282
assign 1 372 1284
new 0 372 1284
assign 1 372 1285
add 1 372 1285
print 0 372 1286
assign 1 375 1289
new 0 375 1289
assign 1 377 1290
iteratorGet 0 0 1290
assign 1 377 1293
hasNextGet 0 377 1293
assign 1 377 1295
nextGet 0 377 1295
assign 1 378 1296
has 1 378 1296
assign 1 378 1297
not 0 378 1302
put 1 379 1303
assign 1 380 1304
new 2 380 1304
addValue 1 381 1305
assign 1 384 1312
iteratorGet 0 0 1312
assign 1 384 1315
hasNextGet 0 384 1315
assign 1 384 1317
nextGet 0 384 1317
assign 1 385 1318
has 1 385 1318
assign 1 385 1319
not 0 385 1324
put 1 386 1325
assign 1 387 1326
new 2 387 1326
addValue 1 388 1327
assign 1 389 1328
libNameGet 0 389 1328
put 1 389 1329
assign 1 394 1337
iteratorGet 0 394 1337
assign 1 394 1340
hasNextGet 0 394 1340
assign 1 395 1342
nextGet 0 395 1342
doParse 1 397 1343
buildSyns 1 399 1349
assign 1 402 1351
new 0 402 1351
assign 1 402 1352
now 0 402 1352
assign 1 402 1353
subtract 1 402 1353
assign 1 404 1355
new 0 404 1355
assign 1 404 1356
add 1 404 1356
print 0 404 1357
assign 1 406 1359
emitCommonGet 0 406 1359
assign 1 406 1360
def 1 406 1365
assign 1 408 1366
emitCommonGet 0 408 1366
doEmit 0 408 1367
assign 1 409 1368
new 0 409 1368
return 1 409 1369
setClassesToWrite 0 412 1372
libnameInfoGet 0 413 1373
assign 1 415 1374
classesGet 0 415 1374
assign 1 415 1375
valueIteratorGet 0 415 1375
assign 1 415 1378
hasNextGet 0 415 1378
assign 1 416 1380
nextGet 0 416 1380
doEmit 1 417 1381
emitMain 0 419 1387
emitCUInit 0 420 1388
assign 1 421 1389
classesGet 0 421 1389
assign 1 421 1390
valueIteratorGet 0 421 1390
assign 1 421 1393
hasNextGet 0 421 1393
assign 1 422 1395
nextGet 0 422 1395
emitSyn 1 423 1396
assign 1 427 1403
new 0 427 1403
assign 1 427 1404
now 0 427 1404
assign 1 427 1405
subtract 1 427 1405
assign 1 428 1406
def 1 428 1411
assign 1 429 1412
new 0 429 1412
assign 1 429 1413
add 1 429 1413
print 0 429 1414
assign 1 431 1416
new 0 431 1416
assign 1 431 1417
add 1 431 1417
print 0 431 1418
prepMake 1 434 1420
assign 1 438 1423
not 0 438 1428
make 1 439 1429
deployLibrary 1 440 1430
assign 1 442 1432
linkedListIteratorGet 0 0 1432
assign 1 442 1435
hasNextGet 0 442 1435
assign 1 442 1437
nextGet 0 442 1437
assign 1 443 1438
libnameInfoGet 0 443 1438
assign 1 443 1439
unitShlibGet 0 443 1439
assign 1 444 1440
emitPathGet 0 444 1440
assign 1 444 1441
copy 0 444 1441
assign 1 445 1442
stepsGet 0 445 1442
assign 1 445 1443
lastGet 0 445 1443
addStep 1 445 1444
assign 1 446 1445
fileGet 0 446 1445
assign 1 446 1446
existsGet 0 446 1446
assign 1 447 1448
fileGet 0 447 1448
delete 0 447 1449
assign 1 449 1451
fileGet 0 449 1451
assign 1 449 1452
existsGet 0 449 1452
assign 1 449 1453
not 0 449 1453
assign 1 450 1455
fileGet 0 450 1455
assign 1 450 1456
fileGet 0 450 1456
deployFile 2 450 1457
assign 1 454 1465
iteratorGet 0 454 1465
assign 1 455 1466
iteratorGet 0 455 1466
assign 1 457 1469
hasNextGet 0 457 1469
assign 1 457 1471
hasNextGet 0 457 1471
assign 1 0 1473
assign 1 0 1476
assign 1 0 1480
assign 1 458 1483
nextGet 0 458 1483
assign 1 458 1484
apNew 1 458 1484
assign 1 459 1485
emitPathGet 0 459 1485
assign 1 459 1486
copy 0 459 1486
assign 1 459 1487
toString 0 459 1487
assign 1 459 1488
new 0 459 1488
assign 1 459 1489
add 1 459 1489
assign 1 459 1490
nextGet 0 459 1490
assign 1 459 1491
add 1 459 1491
assign 1 459 1492
apNew 1 459 1492
assign 1 461 1493
fileGet 0 461 1493
assign 1 461 1494
existsGet 0 461 1494
assign 1 462 1496
fileGet 0 462 1496
delete 0 462 1497
assign 1 464 1499
fileGet 0 464 1499
assign 1 464 1500
existsGet 0 464 1500
assign 1 464 1501
not 0 464 1501
assign 1 465 1503
fileGet 0 465 1503
assign 1 465 1504
fileGet 0 465 1504
deployFile 2 465 1505
assign 1 470 1514
new 0 470 1514
assign 1 470 1515
now 0 470 1515
assign 1 470 1516
subtract 1 470 1516
assign 1 472 1517
def 1 472 1522
assign 1 473 1523
new 0 473 1523
assign 1 473 1524
add 1 473 1524
print 0 473 1525
assign 1 475 1527
def 1 475 1532
assign 1 476 1533
new 0 476 1533
assign 1 476 1534
add 1 476 1534
print 0 476 1535
assign 1 478 1537
def 1 478 1542
assign 1 479 1543
new 0 479 1543
assign 1 479 1544
add 1 479 1544
print 0 479 1545
assign 1 483 1548
new 0 483 1548
print 0 483 1549
assign 1 484 1550
run 2 484 1550
assign 1 485 1551
new 0 485 1551
assign 1 485 1552
add 1 485 1552
assign 1 485 1553
new 0 485 1553
assign 1 485 1554
add 1 485 1554
print 0 485 1555
return 1 486 1556
assign 1 488 1558
new 0 488 1558
return 1 488 1559
assign 1 492 1572
justParsedGet 0 492 1572
assign 1 492 1573
valueIteratorGet 0 492 1573
assign 1 492 1576
hasNextGet 0 492 1576
assign 1 493 1578
nextGet 0 493 1578
assign 1 494 1579
heldGet 0 494 1579
libNameSet 1 494 1580
assign 1 495 1581
getSyn 2 495 1581
libNameSet 1 496 1582
assign 1 498 1588
justParsedGet 0 498 1588
assign 1 498 1589
valueIteratorGet 0 498 1589
assign 1 498 1592
hasNextGet 0 498 1592
assign 1 499 1594
nextGet 0 499 1594
assign 1 500 1595
heldGet 0 500 1595
assign 1 500 1596
synGet 0 500 1596
checkInheritance 2 501 1597
integrate 1 502 1598
assign 1 504 1604
new 0 504 1604
justParsedSet 1 504 1605
assign 1 508 1633
heldGet 0 508 1633
assign 1 508 1634
synGet 0 508 1634
assign 1 508 1635
def 1 508 1640
assign 1 509 1641
heldGet 0 509 1641
assign 1 509 1642
synGet 0 509 1642
return 1 509 1643
assign 1 511 1645
heldGet 0 511 1645
libNameSet 1 511 1646
assign 1 512 1647
heldGet 0 512 1647
assign 1 512 1648
extendsGet 0 512 1648
assign 1 512 1649
undef 1 512 1654
assign 1 513 1655
new 1 513 1655
assign 1 515 1658
classesGet 0 515 1658
assign 1 515 1659
heldGet 0 515 1659
assign 1 515 1660
extendsGet 0 515 1660
assign 1 515 1661
toString 0 515 1661
assign 1 515 1662
get 1 515 1662
assign 1 517 1663
def 1 517 1668
assign 1 518 1669
heldGet 0 518 1669
libNameSet 1 518 1670
assign 1 519 1671
getSyn 2 519 1671
assign 1 522 1674
heldGet 0 522 1674
assign 1 522 1675
extendsGet 0 522 1675
assign 1 522 1676
loadSyn 1 522 1676
assign 1 524 1678
new 2 524 1678
assign 1 526 1680
heldGet 0 526 1680
synSet 1 526 1681
assign 1 527 1682
heldGet 0 527 1682
assign 1 527 1683
namepathGet 0 527 1683
assign 1 527 1684
toString 0 527 1684
addSynClass 2 527 1685
return 1 528 1686
assign 1 532 1694
toString 0 532 1694
assign 1 533 1695
synClassesGet 0 533 1695
assign 1 533 1696
get 1 533 1696
assign 1 534 1697
def 1 534 1702
return 1 535 1703
assign 1 541 1705
emitterGet 0 541 1705
assign 1 541 1706
loadSyn 1 541 1706
addSynClass 2 542 1707
return 1 543 1708
assign 1 550 1712
undef 1 550 1717
assign 1 551 1718
new 1 551 1718
return 1 553 1720
assign 1 558 1799
new 1 558 1799
assign 1 559 1800
new 0 559 1800
assign 1 560 1801
emitterGet 0 560 1801
assign 1 561 1802
assign 1 562 1803
new 0 562 1803
assign 1 563 1804
shouldEmitGet 0 563 1804
put 1 563 1805
assign 1 0 1808
assign 1 0 1812
assign 1 0 1815
assign 1 566 1819
new 0 566 1819
assign 1 566 1820
toString 0 566 1820
assign 1 566 1821
add 1 566 1821
print 0 566 1822
assign 1 568 1824
assign 1 570 1825
fileGet 0 570 1825
assign 1 570 1826
readerGet 0 570 1826
assign 1 570 1827
open 0 570 1827
assign 1 570 1828
readBuffer 1 570 1828
assign 1 571 1829
fileGet 0 571 1829
assign 1 571 1830
readerGet 0 571 1830
close 0 571 1831
assign 1 572 1832
tokenize 1 572 1832
assign 1 576 1834
new 0 576 1834
echo 0 576 1835
assign 1 578 1837
outermostGet 0 578 1837
nodify 2 578 1838
assign 1 580 1840
new 0 580 1840
print 0 580 1841
assign 1 581 1842
new 2 581 1842
traverse 1 581 1843
assign 1 585 1846
new 0 585 1846
echo 0 585 1847
assign 1 587 1849
new 0 587 1849
traverse 1 587 1850
assign 1 589 1852
new 0 589 1852
print 0 589 1853
assign 1 590 1854
new 2 590 1854
traverse 1 590 1855
assign 1 593 1858
new 0 593 1858
echo 0 593 1859
assign 1 596 1861
new 0 596 1861
traverse 1 596 1862
contain 0 597 1863
assign 1 599 1865
new 0 599 1865
print 0 599 1866
assign 1 600 1867
new 2 600 1867
traverse 1 600 1868
assign 1 604 1871
new 0 604 1871
echo 0 604 1872
assign 1 606 1874
new 0 606 1874
traverse 1 606 1875
assign 1 608 1877
new 0 608 1877
print 0 608 1878
assign 1 609 1879
new 2 609 1879
traverse 1 609 1880
assign 1 613 1883
new 0 613 1883
echo 0 613 1884
assign 1 615 1886
new 0 615 1886
traverse 1 615 1887
assign 1 617 1889
new 0 617 1889
print 0 617 1890
assign 1 618 1891
new 2 618 1891
traverse 1 618 1892
assign 1 622 1895
new 0 622 1895
echo 0 622 1896
assign 1 624 1898
new 0 624 1898
traverse 1 624 1899
assign 1 626 1901
new 0 626 1901
print 0 626 1902
assign 1 627 1903
new 2 627 1903
traverse 1 627 1904
assign 1 631 1907
new 0 631 1907
echo 0 631 1908
assign 1 633 1910
new 0 633 1910
traverse 1 633 1911
assign 1 635 1913
new 0 635 1913
print 0 635 1914
assign 1 636 1915
new 2 636 1915
traverse 1 636 1916
assign 1 640 1919
new 0 640 1919
echo 0 640 1920
assign 1 642 1922
new 0 642 1922
traverse 1 642 1923
assign 1 644 1925
new 0 644 1925
print 0 644 1926
assign 1 645 1927
new 2 645 1927
traverse 1 645 1928
assign 1 649 1931
new 0 649 1931
echo 0 649 1932
assign 1 651 1934
new 0 651 1934
traverse 1 651 1935
assign 1 653 1937
new 0 653 1937
print 0 653 1938
assign 1 654 1939
new 2 654 1939
traverse 1 654 1940
assign 1 658 1943
new 0 658 1943
echo 0 658 1944
assign 1 660 1946
new 0 660 1946
traverse 1 660 1947
assign 1 662 1949
new 0 662 1949
print 0 662 1950
assign 1 663 1951
new 2 663 1951
traverse 1 663 1952
assign 1 666 1955
new 0 666 1955
echo 0 666 1956
assign 1 668 1958
new 0 668 1958
traverse 1 668 1959
assign 1 670 1961
new 0 670 1961
print 0 670 1962
assign 1 671 1963
new 2 671 1963
traverse 1 671 1964
assign 1 675 1967
new 0 675 1967
echo 0 675 1968
assign 1 676 1969
new 0 676 1969
print 0 676 1970
assign 1 678 1972
new 0 678 1972
traverse 1 678 1973
assign 1 0 1975
assign 1 0 1979
assign 1 0 1982
assign 1 680 1986
new 0 680 1986
print 0 680 1987
assign 1 681 1988
new 2 681 1988
traverse 1 681 1989
assign 1 683 1991
classesGet 0 683 1991
assign 1 683 1992
valueIteratorGet 0 683 1992
assign 1 683 1995
hasNextGet 0 683 1995
assign 1 684 1997
nextGet 0 684 1997
assign 1 686 1998
transUnitGet 0 686 1998
assign 1 687 1999
new 1 687 1999
assign 1 688 2000
TRANSUNITGet 0 688 2000
typenameSet 1 688 2001
assign 1 689 2002
new 0 689 2002
assign 1 690 2003
heldGet 0 690 2003
assign 1 690 2004
emitsGet 0 690 2004
emitsSet 1 690 2005
heldSet 1 691 2006
delete 0 692 2007
addValue 1 693 2008
copyLoc 1 694 2009
reInitContained 0 700 2031
assign 1 701 2032
containedGet 0 701 2032
assign 1 702 2033
new 0 702 2033
assign 1 703 2034
new 0 703 2034
assign 1 703 2035
crGet 0 703 2035
assign 1 704 2036
linkedListIteratorGet 0 704 2036
assign 1 704 2039
hasNextGet 0 704 2039
assign 1 705 2041
new 1 705 2041
assign 1 706 2042
nextGet 0 706 2042
heldSet 1 706 2043
nlcSet 1 707 2044
assign 1 708 2045
heldGet 0 708 2045
assign 1 708 2046
equals 1 708 2046
assign 1 709 2048
increment 0 709 2048
assign 1 711 2050
heldGet 0 711 2050
assign 1 711 2051
notEquals 1 711 2051
addValue 1 712 2053
containerSet 1 713 2054
return 1 0 2064
assign 1 0 2067
return 1 0 2071
assign 1 0 2074
return 1 0 2078
assign 1 0 2081
return 1 0 2085
assign 1 0 2088
return 1 0 2092
assign 1 0 2095
return 1 0 2099
assign 1 0 2102
return 1 0 2106
assign 1 0 2109
return 1 0 2113
assign 1 0 2116
return 1 0 2120
assign 1 0 2123
return 1 0 2127
assign 1 0 2130
return 1 0 2134
assign 1 0 2137
return 1 0 2141
assign 1 0 2144
return 1 0 2148
assign 1 0 2151
return 1 0 2155
assign 1 0 2158
return 1 0 2162
assign 1 0 2165
return 1 0 2169
assign 1 0 2172
return 1 0 2176
assign 1 0 2179
return 1 0 2183
assign 1 0 2186
return 1 0 2190
assign 1 0 2193
return 1 0 2197
assign 1 0 2200
return 1 0 2204
assign 1 0 2207
return 1 0 2211
assign 1 0 2214
return 1 0 2218
assign 1 0 2221
return 1 0 2225
assign 1 0 2228
return 1 0 2232
assign 1 0 2235
return 1 0 2239
assign 1 0 2242
return 1 0 2246
assign 1 0 2249
return 1 0 2253
assign 1 0 2256
return 1 0 2260
assign 1 0 2263
return 1 0 2267
assign 1 0 2270
return 1 0 2274
assign 1 0 2277
return 1 0 2281
assign 1 0 2284
return 1 0 2288
assign 1 0 2291
return 1 0 2295
assign 1 0 2298
return 1 0 2302
assign 1 0 2305
return 1 0 2309
assign 1 0 2312
return 1 0 2316
assign 1 0 2319
return 1 0 2323
assign 1 0 2326
return 1 0 2330
assign 1 0 2333
return 1 0 2337
assign 1 0 2340
return 1 0 2344
assign 1 0 2347
return 1 0 2351
assign 1 0 2354
return 1 0 2358
assign 1 0 2361
return 1 0 2365
assign 1 0 2368
return 1 0 2372
assign 1 0 2375
return 1 0 2379
assign 1 0 2382
return 1 0 2386
assign 1 0 2389
return 1 0 2393
assign 1 0 2396
return 1 0 2400
assign 1 0 2403
return 1 0 2407
assign 1 0 2410
return 1 0 2414
assign 1 0 2417
return 1 0 2421
assign 1 0 2424
return 1 0 2428
assign 1 0 2431
return 1 0 2435
assign 1 0 2438
return 1 0 2442
assign 1 0 2445
return 1 0 2449
assign 1 0 2452
return 1 0 2456
assign 1 0 2459
return 1 0 2463
assign 1 0 2466
return 1 0 2470
assign 1 0 2473
return 1 0 2477
assign 1 0 2480
return 1 0 2484
assign 1 0 2487
return 1 0 2491
assign 1 0 2494
return 1 0 2498
assign 1 0 2501
return 1 0 2505
assign 1 0 2508
return 1 0 2512
assign 1 0 2515
return 1 0 2519
assign 1 0 2522
return 1 0 2526
assign 1 0 2529
return 1 0 2533
assign 1 0 2536
assign 1 0 2540
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 404051026: return bem_printPlacesGet_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 902949587: return bem_printStepsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 392968773: return bem_printPlacesSet_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 891867334: return bem_printStepsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bevs_inst = (BEC_2_5_5_BuildBuild)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bevs_inst;
}
}
}
