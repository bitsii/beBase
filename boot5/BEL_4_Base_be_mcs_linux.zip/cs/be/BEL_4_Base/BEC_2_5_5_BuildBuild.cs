namespace be.BEL_4_Base {
/* IO:File: source/build/Build.be */
public class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bels_6 = {0x31};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_11 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 12));
private static byte[] bels_12 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 21));
private static byte[] bels_13 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 6));
private static byte[] bels_14 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 13));
private static byte[] bels_15 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 21));
private static byte[] bels_16 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 6));
private static byte[] bels_17 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_18 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 5));
private static byte[] bels_19 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_21 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_22 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_23 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_24 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_25 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_26 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_27 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_28 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_29 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_30 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_31 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_32 = {0x74,0x72,0x75,0x65};
private static byte[] bels_33 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_35 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_36 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_37 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_38 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_39 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_40 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_42 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_43 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_44 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_45 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_49 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_50 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_51 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_52 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_53 = {0x72,0x75,0x6E};
private static byte[] bels_54 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_55 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_56 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_57 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_58 = {0x67,0x63,0x63};
private static byte[] bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_60 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_61 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_61, 9));
private static byte[] bels_62 = {};
private static byte[] bels_63 = {0x63};
private static byte[] bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_64, 8));
private static byte[] bels_65 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_65, 7));
private static byte[] bels_66 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_67 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_68 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_68, 2));
private static byte[] bels_69 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_69, 2));
private static byte[] bels_70 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_70, 2));
private static byte[] bels_71 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_72 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_72, 19));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_73, 31));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_74, 31));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_75, 41));
private static byte[] bels_76 = {0x2F};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_76, 1));
private static byte[] bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_77, 31));
private static byte[] bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_78, 41));
private static byte[] bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_79, 51));
private static byte[] bels_80 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_80, 14));
private static byte[] bels_81 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_81, 19));
private static byte[] bels_82 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_82, 9));
private static byte[] bels_83 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_83, 13));
private static byte[] bels_84 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_84, 2));
private static byte[] bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_85, 22));
private static byte[] bels_86 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_86, 3));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_87, 15));
private static byte[] bels_88 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_88, 4));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_90, 5));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_92, 6));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_94, 7));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_96, 8));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_98, 9));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bevo_43 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_99, 15));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_44 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_100, 10));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bevo_45 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_101, 15));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_46 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_102, 11));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bevo_47 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_103, 16));
private static byte[] bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_48 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_104, 12));
private static byte[] bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bevo_49 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_105, 16));
private static byte[] bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_50 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_106, 13));
private static byte[] bels_107 = {0x20};
private static BEC_2_4_6_TextString bevo_51 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_107, 1));
private static byte[] bels_108 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bevo_52 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_108, 16));
public static new BEC_2_5_5_BuildBuild bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_5_ContainerArray bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 104 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 105 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_9_5_ContainerArray bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevt_2_tmpvar_phold = this.bem_main_1(bevl__args);
bevt_1_tmpvar_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_5_ContainerArray beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_5));
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevp_params.bem_get_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 123 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(bevl_times);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevl_res = this.bem_go_0();
bevl_i.bem_incrementValue_0();
} /* Line: 123 */
 else  /* Line: 123 */ {
break;
} /* Line: 123 */
} /* Line: 123 */
return bevl_res;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 133 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_7));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
} /* Line: 136 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 141 */
if (bevp_printSteps.bevi_bool) /* Line: 143 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 143 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 144 */
return bevl_whatResult;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_10));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 150 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 156 */
return beva_addTo;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_113_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_120_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_17));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 167 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 167 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 170 */
} /* Line: 168 */
 else  /* Line: 167 */ {
break;
} /* Line: 167 */
} /* Line: 167 */
} /* Line: 167 */
bevt_13_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 176 */
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_19));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_20));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 179 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_21));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 180 */
 else  /* Line: 181 */ {
bevp_exeName = bevp_libName;
} /* Line: 182 */
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_22));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_23));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_24));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_25));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_26));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_27));
bevt_36_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_28));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_2_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_29));
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_30));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_31));
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_32));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_33));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_34));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_35));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_55_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_36));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_57_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_37));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_38));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_61_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_39));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_40));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_41));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_42));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 225 */
bevt_69_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_43));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 229 */
bevt_71_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_44));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 233 */
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_45));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 237 */
 else  /* Line: 238 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 239 */
bevt_75_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_46));
bevt_76_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_47));
bevt_78_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_48));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_49));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_50));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_not_0();
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 247 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 247 */
 else  /* Line: 247 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 247 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 248 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 249 */
 else  /* Line: 248 */ {
break;
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_51));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bels_52));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_53));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_54));
bevt_90_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_55));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_56));
bevp_emitFlags = bevp_params.bem_get_1(bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_57));
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_58));
bevt_93_tmpvar_phold = bevp_params.bem_get_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_93_tmpvar_phold.bem_firstGet_0();
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_59));
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_60));
bevt_96_tmpvar_phold = bevp_params.bem_get_2(bevt_97_tmpvar_phold, bevt_98_tmpvar_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = bevo_10;
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_102_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_62));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_102_tmpvar_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 269 */
 else  /* Line: 270 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_63));
} /* Line: 271 */
bevt_106_tmpvar_phold = bevo_11;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevt_107_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_104_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 279 */ {
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_109_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 280 */
bevt_111_tmpvar_phold = bevo_12;
bevt_110_tmpvar_phold = bevl_outLang.bem_add_1(bevt_111_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_langSources == null) {
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 284 */ {
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_113_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 285 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_114_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_114_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 289 */ {
bevt_115_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 289 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_116_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_116_tmpvar_phold);
} /* Line: 290 */
 else  /* Line: 289 */ {
break;
} /* Line: 289 */
} /* Line: 289 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_existsGet_0();
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bem_not_0();
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_120_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpvar_phold.bem_makeDirs_0();
} /* Line: 298 */
if (bevp_emitFileHeader == null) {
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_122_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_122_tmpvar_phold.bem_readerGet_0();
bevt_123_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_123_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 303 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_66));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_67));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 317 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 319 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 322 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 323 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 323 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 324 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
} /* Line: 323 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 328 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 329 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 330 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 328 */
} /* Line: 319 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 335 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 335 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 337 */
 else  /* Line: 335 */ {
break;
} /* Line: 335 */
} /* Line: 335 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 348 */ {
return bevp_emitCommon;
} /* Line: 349 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 357 */
 else  /* Line: 356 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 358 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 359 */
 else  /* Line: 356 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 360 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 361 */
 else  /* Line: 362 */ {
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_71));
bevt_8_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 363 */
} /* Line: 356 */
} /* Line: 356 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 366 */
return null;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_4_8_TimeInterval bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_16_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_21_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_55_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_67_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
bevt_4_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_4_tmpvar_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 379 */ {
bevt_7_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_libName);
bevt_6_tmpvar_phold.bem_print_0();
} /* Line: 380 */
} /* Line: 379 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 385 */ {
bevt_8_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 385 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_not_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 389 */
} /* Line: 386 */
 else  /* Line: 385 */ {
break;
} /* Line: 385 */
} /* Line: 385 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 392 */ {
bevt_11_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 392 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_not_0();
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 393 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_14_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_14_tmpvar_phold);
} /* Line: 397 */
} /* Line: 393 */
 else  /* Line: 392 */ {
break;
} /* Line: 392 */
} /* Line: 392 */
if (bevp_parse.bevi_bool) /* Line: 400 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 402 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 402 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 405 */
 else  /* Line: 402 */ {
break;
} /* Line: 402 */
} /* Line: 402 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 407 */
bevt_17_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_16_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_17_tmpvar_phold.bem_now_0();
bevp_parseTime = bevt_16_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_printSteps.bevi_bool) /* Line: 411 */ {
bevt_19_tmpvar_phold = bevo_17;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_18_tmpvar_phold.bem_print_0();
} /* Line: 412 */
bevt_21_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 414 */ {
bevt_22_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_22_tmpvar_phold.bem_doEmit_0();
bevt_23_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_23_tmpvar_phold;
} /* Line: 417 */
if (bevp_doEmit.bevi_bool) /* Line: 419 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 423 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 423 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 425 */
 else  /* Line: 423 */ {
break;
} /* Line: 423 */
} /* Line: 423 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_26_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_26_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 429 */ {
bevt_27_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 429 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 431 */
 else  /* Line: 429 */ {
break;
} /* Line: 429 */
} /* Line: 429 */
} /* Line: 429 */
bevt_29_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 436 */ {
bevt_32_tmpvar_phold = bevo_18;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_31_tmpvar_phold.bem_print_0();
} /* Line: 437 */
bevt_34_tmpvar_phold = bevo_19;
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_33_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 440 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 442 */
if (bevp_make.bevi_bool) /* Line: 445 */ {
bevt_35_tmpvar_phold = bevp_genOnly.bem_not_0();
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 446 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 449 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 450 */ {
bevt_36_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 450 */ {
bevl_bp = bevt_2_tmpvar_loop.bem_nextGet_0();
bevt_37_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_37_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_38_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_38_tmpvar_phold.bem_copy_0();
bevt_40_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_39_tmpvar_phold);
bevt_42_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 454 */ {
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_43_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 455 */
bevt_46_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_44_tmpvar_phold != null && bevt_44_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_44_tmpvar_phold).bevi_bool) /* Line: 457 */ {
bevt_47_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_48_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
} /* Line: 458 */
} /* Line: 457 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
} /* Line: 450 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 465 */ {
bevt_49_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_49_tmpvar_phold != null && bevt_49_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_49_tmpvar_phold).bevi_bool) /* Line: 465 */ {
bevt_50_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 465 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 465 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 465 */
 else  /* Line: 465 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 465 */ {
bevt_51_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_51_tmpvar_phold);
bevt_56_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_55_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_56_tmpvar_phold.bem_copy_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bem_toString_0();
bevt_57_tmpvar_phold = bevo_20;
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_add_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_52_tmpvar_phold);
bevt_60_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 469 */ {
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_61_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 470 */
bevt_64_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_62_tmpvar_phold != null && bevt_62_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_62_tmpvar_phold).bevi_bool) /* Line: 472 */ {
bevt_65_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_66_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_65_tmpvar_phold, bevt_66_tmpvar_phold);
} /* Line: 473 */
} /* Line: 472 */
 else  /* Line: 465 */ {
break;
} /* Line: 465 */
} /* Line: 465 */
} /* Line: 465 */
} /* Line: 446 */
bevt_68_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_67_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_68_tmpvar_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_67_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 480 */ {
bevt_71_tmpvar_phold = bevo_21;
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_70_tmpvar_phold.bem_print_0();
} /* Line: 481 */
if (bevp_parseEmitTime == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 483 */ {
bevt_74_tmpvar_phold = bevo_22;
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_73_tmpvar_phold.bem_print_0();
} /* Line: 484 */
if (bevp_parseEmitCompileTime == null) {
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_75_tmpvar_phold.bevi_bool) /* Line: 486 */ {
bevt_77_tmpvar_phold = bevo_23;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_76_tmpvar_phold.bem_print_0();
} /* Line: 487 */
if (bevp_run.bevi_bool) /* Line: 490 */ {
bevt_78_tmpvar_phold = bevo_24;
bevt_78_tmpvar_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_81_tmpvar_phold = bevo_25;
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bem_add_1(bevl_result);
bevt_82_tmpvar_phold = bevo_26;
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_add_1(bevt_82_tmpvar_phold);
bevt_79_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 494 */
bevt_83_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_83_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 500 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 500 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 504 */
 else  /* Line: 500 */ {
break;
} /* Line: 500 */
} /* Line: 500 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 506 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 506 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 510 */
 else  /* Line: 506 */ {
break;
} /* Line: 506 */
} /* Line: 506 */
bevt_6_tmpvar_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 517 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 520 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 521 */
 else  /* Line: 522 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 525 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 527 */
 else  /* Line: 528 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 530 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 532 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpvar_phold, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public virtual BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 542 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 543 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 558 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 559 */
return bevp_sharedEmitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 572 */ {
if (bevp_printSteps.bevi_bool) /* Line: 573 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 573 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 573 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 573 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 573 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 573 */ {
bevt_4_tmpvar_phold = bevo_27;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 574 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 583 */ {
bevt_11_tmpvar_phold = bevo_28;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 584 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 587 */ {
bevt_13_tmpvar_phold = bevo_29;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 589 */
if (bevp_printSteps.bevi_bool) /* Line: 592 */ {
bevt_15_tmpvar_phold = bevo_30;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 593 */
bevt_16_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 596 */ {
bevt_17_tmpvar_phold = bevo_31;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 598 */
if (bevp_printSteps.bevi_bool) /* Line: 600 */ {
bevt_19_tmpvar_phold = bevo_32;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 601 */
bevt_20_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 606 */ {
bevt_21_tmpvar_phold = bevo_33;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 608 */
if (bevp_printSteps.bevi_bool) /* Line: 611 */ {
bevt_23_tmpvar_phold = bevo_34;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 612 */
bevt_24_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 615 */ {
bevt_25_tmpvar_phold = bevo_35;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 617 */
if (bevp_printSteps.bevi_bool) /* Line: 620 */ {
bevt_27_tmpvar_phold = bevo_36;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 621 */
bevt_28_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 624 */ {
bevt_29_tmpvar_phold = bevo_37;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 626 */
if (bevp_printSteps.bevi_bool) /* Line: 629 */ {
bevt_31_tmpvar_phold = bevo_38;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 630 */
bevt_32_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_33_tmpvar_phold = bevo_39;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_35_tmpvar_phold = bevo_40;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 639 */
bevt_36_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_37_tmpvar_phold = bevo_41;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_39_tmpvar_phold = bevo_42;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 648 */
bevt_40_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_41_tmpvar_phold = bevo_43;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_43_tmpvar_phold = bevo_44;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 657 */
bevt_44_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_45_tmpvar_phold = bevo_45;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 665 */ {
bevt_47_tmpvar_phold = bevo_46;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 666 */
bevt_48_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 669 */ {
bevt_49_tmpvar_phold = bevo_47;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 671 */
if (bevp_printSteps.bevi_bool) /* Line: 673 */ {
bevt_51_tmpvar_phold = bevo_48;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 674 */
bevt_52_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 677 */ {
bevt_53_tmpvar_phold = bevo_49;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 679 */
if (bevp_printSteps.bevi_bool) /* Line: 682 */ {
bevt_55_tmpvar_phold = bevo_50;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_51;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 684 */
bevt_57_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 687 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 687 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 687 */ {
bevt_58_tmpvar_phold = bevo_52;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 689 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 691 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 691 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 702 */
 else  /* Line: 691 */ {
break;
} /* Line: 691 */
} /* Line: 691 */
} /* Line: 691 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 712 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 712 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 716 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 717 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 719 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 721 */
} /* Line: 719 */
 else  /* Line: 712 */ {
break;
} /* Line: 712 */
} /* Line: 712 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_argsGet_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_args = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {61, 63, 64, 65, 66, 68, 69, 70, 71, 72, 73, 74, 78, 80, 81, 82, 83, 86, 89, 90, 96, 97, 98, 99, 104, 0, 104, 0, 105, 107, 111, 115, 116, 120, 121, 122, 123, 124, 123, 126, 130, 131, 132, 134, 135, 136, 138, 139, 140, 141, 0, 144, 146, 150, 151, 152, 153, 154, 155, 156, 158, 163, 165, 166, 167, 0, 167, 168, 169, 170, 175, 176, 178, 179, 180, 182, 184, 185, 186, 187, 188, 189, 190, 191, 193, 194, 195, 196, 197, 199, 200, 201, 203, 204, 205, 207, 208, 209, 211, 212, 213, 215, 216, 217, 219, 220, 221, 223, 224, 225, 227, 228, 229, 231, 232, 233, 235, 236, 237, 239, 241, 242, 243, 244, 245, 246, 247, 0, 248, 0, 248, 249, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 268, 269, 271, 278, 279, 280, 283, 284, 285, 288, 289, 0, 289, 290, 292, 293, 294, 296, 297, 298, 300, 301, 302, 303, 309, 310, 311, 312, 316, 317, 318, 319, 320, 321, 322, 323, 0, 323, 324, 327, 328, 329, 0, 329, 330, 335, 336, 337, 344, 348, 349, 354, 355, 356, 357, 358, 359, 360, 361, 363, 365, 366, 368, 373, 374, 375, 376, 377, 378, 380, 383, 385, 0, 385, 386, 387, 388, 389, 392, 0, 392, 393, 394, 395, 396, 397, 402, 403, 405, 407, 410, 412, 414, 416, 417, 420, 421, 423, 424, 425, 427, 428, 429, 430, 431, 435, 436, 437, 439, 442, 446, 447, 448, 450, 0, 450, 451, 452, 453, 454, 455, 457, 458, 462, 463, 465, 0, 466, 467, 469, 470, 472, 473, 478, 480, 481, 483, 484, 486, 487, 491, 492, 493, 494, 496, 500, 501, 502, 503, 504, 506, 507, 508, 509, 510, 512, 516, 517, 519, 520, 521, 523, 525, 526, 527, 530, 532, 534, 535, 536, 540, 541, 542, 543, 549, 550, 551, 558, 559, 561, 566, 567, 568, 569, 570, 571, 0, 574, 576, 578, 579, 580, 584, 586, 588, 589, 593, 595, 597, 598, 601, 604, 605, 607, 608, 612, 614, 616, 617, 621, 623, 625, 626, 630, 632, 634, 635, 639, 641, 643, 644, 648, 650, 652, 653, 657, 659, 661, 662, 666, 668, 670, 671, 674, 676, 678, 679, 683, 684, 686, 0, 688, 689, 691, 692, 694, 695, 696, 697, 698, 699, 700, 701, 702, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 719, 720, 721, 0};
public static new int[] bevs_smnlec
 = new int[] {243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243};
/* BEGIN LINEINFO 
assign 1 61 243
new 0 61 243
assign 1 63 243
new 0 63 243
assign 1 64 243
new 0 64 243
assign 1 65 243
new 0 65 243
assign 1 66 243
new 0 66 243
assign 1 68 243
new 0 68 243
assign 1 69 243
new 0 69 243
assign 1 70 243
new 0 70 243
assign 1 71 243
new 0 71 243
assign 1 72 243
new 0 72 243
assign 1 73 243
new 0 73 243
assign 1 74 243
new 0 74 243
assign 1 78 243
new 0 78 243
assign 1 80 243
new 1 80 243
assign 1 81 243
ntypesGet 0 81 243
assign 1 82 243
twtokGet 0 82 243
assign 1 83 243
new 0 83 243
assign 1 83 243
new 1 83 243
assign 1 86 243
new 0 86 243
assign 1 89 243
new 0 89 243
assign 1 90 243
new 0 90 243
assign 1 96 243
new 0 96 243
assign 1 97 243
new 0 97 243
assign 1 98 243
new 0 98 243
assign 1 99 243
new 0 99 243
assign 1 99 243
new 1 99 243
assign 1 104 243
def 1 104 243
assign 1 104 243
new 0 104 243
assign 1 104 243
equals 1 104 243
assign 1 0 243
assign 1 104 243
new 0 104 243
assign 1 104 243
ends 1 104 243
assign 1 0 243
assign 1 0 243
assign 1 0 243
assign 1 0 243
assign 1 0 243
assign 1 105 243
new 0 105 243
return 1 105 243
assign 1 107 243
new 0 107 243
return 1 107 243
assign 1 111 243
new 0 111 243
assign 1 111 243
new 0 111 243
assign 1 111 243
swap 2 111 243
return 1 111 243
assign 1 115 243
new 0 115 243
assign 1 115 243
argsGet 0 115 243
assign 1 116 243
new 0 116 243
assign 1 116 243
main 1 116 243
exit 1 116 243
assign 1 120 243
assign 1 121 243
new 1 121 243
assign 1 122 243
new 0 122 243
assign 1 122 243
new 0 122 243
assign 1 122 243
get 2 122 243
assign 1 122 243
firstGet 0 122 243
assign 1 122 243
new 1 122 243
assign 1 123 243
new 0 123 243
assign 1 123 243
lesser 1 123 243
assign 1 124 243
go 0 124 243
incrementValue 0 123 243
return 1 126 243
assign 1 130 243
new 0 130 243
config 0 131 243
assign 1 132 243
new 0 132 243
assign 1 134 243
new 0 134 243
assign 1 135 243
doWhat 0 135 243
assign 1 136 243
new 0 136 243
assign 1 138 243
toString 0 138 243
assign 1 139 243
new 0 139 243
assign 1 140 243
new 0 140 243
assign 1 140 243
add 1 140 243
assign 1 141 243
new 0 141 243
assign 1 0 243
assign 1 0 243
assign 1 0 243
print 0 144 243
return 1 146 243
assign 1 150 243
nameGet 0 150 243
assign 1 150 243
new 0 150 243
assign 1 150 243
equals 1 150 243
assign 1 151 243
new 0 151 243
assign 1 151 243
add 1 151 243
assign 1 151 243
add 1 151 243
assign 1 151 243
add 1 151 243
assign 1 152 243
new 0 152 243
assign 1 152 243
add 1 152 243
assign 1 152 243
add 1 152 243
assign 1 153 243
new 0 153 243
assign 1 153 243
add 1 153 243
assign 1 153 243
add 1 153 243
assign 1 154 243
new 0 154 243
assign 1 154 243
add 1 154 243
assign 1 154 243
add 1 154 243
assign 1 154 243
add 1 154 243
assign 1 155 243
new 0 155 243
assign 1 155 243
add 1 155 243
assign 1 155 243
add 1 155 243
assign 1 156 243
new 0 156 243
assign 1 156 243
add 1 156 243
assign 1 156 243
add 1 156 243
return 1 158 243
assign 1 163 243
new 0 163 243
assign 1 165 243
new 0 165 243
assign 1 166 243
get 1 166 243
assign 1 166 243
def 1 166 243
assign 1 167 243
get 1 167 243
assign 1 167 243
iteratorGet 0 0 243
assign 1 167 243
hasNextGet 0 167 243
assign 1 167 243
nextGet 0 167 243
assign 1 168 243
has 1 168 243
assign 1 168 243
not 0 168 243
put 1 169 243
assign 1 170 243
new 1 170 243
addFile 1 170 243
assign 1 175 243
new 0 175 243
assign 1 175 243
nameGet 0 175 243
assign 1 175 243
new 0 175 243
assign 1 175 243
equals 1 175 243
preProcessorSet 1 176 243
assign 1 178 243
new 0 178 243
assign 1 178 243
get 1 178 243
assign 1 178 243
firstGet 0 178 243
assign 1 179 243
new 0 179 243
assign 1 179 243
has 1 179 243
assign 1 180 243
new 0 180 243
assign 1 180 243
get 1 180 243
assign 1 180 243
firstGet 0 180 243
assign 1 182 243
assign 1 184 243
new 0 184 243
assign 1 184 243
new 0 184 243
assign 1 184 243
get 2 184 243
assign 1 184 243
firstGet 0 184 243
assign 1 184 243
new 1 184 243
assign 1 184 243
pathGet 0 184 243
addStep 1 185 243
assign 1 186 243
new 0 186 243
addStep 1 186 243
assign 1 187 243
new 0 187 243
assign 1 187 243
new 0 187 243
assign 1 187 243
get 2 187 243
assign 1 187 243
firstGet 0 187 243
assign 1 187 243
new 1 187 243
assign 1 187 243
pathGet 0 187 243
assign 1 188 243
new 0 188 243
assign 1 188 243
new 0 188 243
assign 1 188 243
nameGet 0 188 243
assign 1 188 243
get 2 188 243
assign 1 188 243
firstGet 0 188 243
assign 1 188 243
new 1 188 243
assign 1 189 243
new 0 189 243
assign 1 189 243
nameGet 0 189 243
assign 1 189 243
get 2 189 243
assign 1 189 243
firstGet 0 189 243
assign 1 189 243
new 1 189 243
assign 1 190 243
new 0 190 243
assign 1 190 243
new 0 190 243
assign 1 190 243
get 2 190 243
assign 1 190 243
firstGet 0 190 243
assign 1 190 243
new 1 190 243
assign 1 191 243
new 0 191 243
assign 1 191 243
new 0 191 243
assign 1 191 243
get 2 191 243
assign 1 191 243
firstGet 0 191 243
assign 1 191 243
new 1 191 243
assign 1 193 243
new 0 193 243
assign 1 193 243
get 1 193 243
assign 1 193 243
firstGet 0 193 243
assign 1 194 243
new 0 194 243
assign 1 194 243
get 1 194 243
assign 1 194 243
firstGet 0 194 243
assign 1 195 243
new 0 195 243
assign 1 195 243
get 1 195 243
assign 1 196 243
undef 1 196 243
assign 1 197 243
new 0 197 243
assign 1 199 243
new 0 199 243
assign 1 199 243
get 1 199 243
assign 1 200 243
undef 1 200 243
assign 1 201 243
new 0 201 243
assign 1 203 243
new 0 203 243
assign 1 203 243
get 1 203 243
assign 1 204 243
undef 1 204 243
assign 1 205 243
new 0 205 243
assign 1 207 243
new 0 207 243
assign 1 207 243
get 1 207 243
assign 1 208 243
undef 1 208 243
assign 1 209 243
new 0 209 243
assign 1 211 243
new 0 211 243
assign 1 211 243
get 1 211 243
assign 1 212 243
undef 1 212 243
assign 1 213 243
new 0 213 243
assign 1 215 243
new 0 215 243
assign 1 215 243
get 1 215 243
assign 1 216 243
undef 1 216 243
assign 1 217 243
new 0 217 243
assign 1 219 243
new 0 219 243
assign 1 219 243
get 1 219 243
assign 1 220 243
undef 1 220 243
assign 1 221 243
new 0 221 243
assign 1 223 243
new 0 223 243
assign 1 223 243
get 1 223 243
assign 1 224 243
undef 1 224 243
assign 1 225 243
new 0 225 243
assign 1 227 243
new 0 227 243
assign 1 227 243
get 1 227 243
assign 1 228 243
undef 1 228 243
assign 1 229 243
new 0 229 243
assign 1 231 243
new 0 231 243
assign 1 231 243
get 1 231 243
assign 1 232 243
def 1 232 243
assign 1 233 243
firstGet 0 233 243
assign 1 235 243
new 0 235 243
assign 1 235 243
get 1 235 243
assign 1 236 243
def 1 236 243
assign 1 237 243
firstGet 0 237 243
assign 1 239 243
new 0 239 243
assign 1 241 243
new 0 241 243
assign 1 241 243
new 0 241 243
assign 1 241 243
isTrue 2 241 243
assign 1 242 243
new 0 242 243
assign 1 242 243
new 0 242 243
assign 1 242 243
isTrue 2 242 243
assign 1 243 243
new 0 243 243
assign 1 243 243
isTrue 1 243 243
assign 1 244 243
new 0 244 243
assign 1 244 243
isTrue 1 244 243
assign 1 245 243
new 0 245 243
assign 1 246 243
new 0 246 243
assign 1 246 243
get 1 246 243
assign 1 247 243
def 1 247 243
assign 1 247 243
isEmptyGet 0 247 243
assign 1 247 243
not 0 247 243
assign 1 0 243
assign 1 0 243
assign 1 0 243
assign 1 248 243
linkedListIteratorGet 0 0 243
assign 1 248 243
hasNextGet 0 248 243
assign 1 248 243
nextGet 0 248 243
put 1 249 243
assign 1 252 243
new 0 252 243
assign 1 252 243
isTrue 1 252 243
assign 1 253 243
new 0 253 243
assign 1 253 243
isTrue 1 253 243
assign 1 254 243
new 0 254 243
assign 1 254 243
isTrue 1 254 243
assign 1 255 243
new 0 255 243
assign 1 255 243
new 0 255 243
assign 1 255 243
isTrue 2 255 243
assign 1 256 243
new 0 256 243
assign 1 256 243
get 1 256 243
assign 1 257 243
new 0 257 243
assign 1 257 243
get 1 257 243
assign 1 258 243
new 0 258 243
assign 1 258 243
new 0 258 243
assign 1 258 243
get 2 258 243
assign 1 258 243
firstGet 0 258 243
assign 1 259 243
new 0 259 243
assign 1 259 243
new 0 259 243
assign 1 259 243
get 2 259 243
assign 1 259 243
firstGet 0 259 243
assign 1 260 243
new 0 260 243
assign 1 260 243
add 1 260 243
assign 1 260 243
new 0 260 243
assign 1 260 243
get 2 260 243
assign 1 260 243
firstGet 0 260 243
assign 1 261 243
new 0 261 243
assign 1 262 243
new 0 262 243
assign 1 263 243
new 0 263 243
assign 1 264 243
new 0 264 243
assign 1 265 243
new 0 265 243
assign 1 268 243
def 1 268 243
assign 1 269 243
firstGet 0 269 243
assign 1 271 243
new 0 271 243
assign 1 278 243
new 0 278 243
assign 1 278 243
add 1 278 243
assign 1 278 243
nameGet 0 278 243
assign 1 278 243
add 1 278 243
assign 1 278 243
get 1 278 243
assign 1 279 243
def 1 279 243
assign 1 280 243
orderedGet 0 280 243
addAll 1 280 243
assign 1 283 243
new 0 283 243
assign 1 283 243
add 1 283 243
assign 1 283 243
get 1 283 243
assign 1 284 243
def 1 284 243
assign 1 285 243
orderedGet 0 285 243
addAll 1 285 243
assign 1 288 243
new 0 288 243
assign 1 289 243
orderedGet 0 289 243
assign 1 289 243
iteratorGet 0 0 243
assign 1 289 243
hasNextGet 0 289 243
assign 1 289 243
nextGet 0 289 243
assign 1 290 243
new 1 290 243
addValue 1 290 243
assign 1 292 243
newlineGet 0 292 243
assign 1 293 243
assign 1 294 243
new 1 294 243
assign 1 296 243
copy 0 296 243
assign 1 297 243
fileGet 0 297 243
assign 1 297 243
existsGet 0 297 243
assign 1 297 243
not 0 297 243
assign 1 298 243
fileGet 0 298 243
makeDirs 0 298 243
assign 1 300 243
def 1 300 243
assign 1 301 243
new 1 301 243
assign 1 301 243
readerGet 0 301 243
assign 1 302 243
open 0 302 243
assign 1 302 243
readString 0 302 243
close 0 303 243
assign 1 309 243
classNameGet 0 309 243
assign 1 310 243
add 1 310 243
assign 1 310 243
new 0 310 243
assign 1 310 243
add 1 310 243
assign 1 310 243
toString 0 310 243
assign 1 310 243
add 1 310 243
assign 1 311 243
add 1 311 243
assign 1 311 243
new 0 311 243
assign 1 311 243
add 1 311 243
assign 1 311 243
toString 0 311 243
assign 1 311 243
add 1 311 243
return 1 312 243
assign 1 316 243
new 0 316 243
assign 1 317 243
classesGet 0 317 243
assign 1 317 243
valueIteratorGet 0 317 243
assign 1 317 243
hasNextGet 0 317 243
assign 1 318 243
nextGet 0 318 243
assign 1 319 243
shouldEmitGet 0 319 243
assign 1 319 243
heldGet 0 319 243
assign 1 319 243
fromFileGet 0 319 243
assign 1 319 243
has 1 319 243
assign 1 320 243
heldGet 0 320 243
assign 1 320 243
namepathGet 0 320 243
assign 1 320 243
toString 0 320 243
put 1 320 243
assign 1 321 243
usedByGet 0 321 243
assign 1 321 243
heldGet 0 321 243
assign 1 321 243
namepathGet 0 321 243
assign 1 321 243
toString 0 321 243
assign 1 321 243
get 1 321 243
assign 1 322 243
def 1 322 243
assign 1 323 243
setIteratorGet 0 0 243
assign 1 323 243
hasNextGet 0 323 243
assign 1 323 243
nextGet 0 323 243
put 1 324 243
assign 1 327 243
subClassesGet 0 327 243
assign 1 327 243
heldGet 0 327 243
assign 1 327 243
namepathGet 0 327 243
assign 1 327 243
toString 0 327 243
assign 1 327 243
get 1 327 243
assign 1 328 243
def 1 328 243
assign 1 329 243
setIteratorGet 0 0 243
assign 1 329 243
hasNextGet 0 329 243
assign 1 329 243
nextGet 0 329 243
put 1 330 243
assign 1 335 243
classesGet 0 335 243
assign 1 335 243
valueIteratorGet 0 335 243
assign 1 335 243
hasNextGet 0 335 243
assign 1 336 243
nextGet 0 336 243
assign 1 337 243
heldGet 0 337 243
assign 1 337 243
heldGet 0 337 243
assign 1 337 243
namepathGet 0 337 243
assign 1 337 243
toString 0 337 243
assign 1 337 243
has 1 337 243
shouldWriteSet 1 337 243
assign 1 344 243
new 0 344 243
return 1 344 243
assign 1 348 243
def 1 348 243
return 1 349 243
assign 1 354 243
def 1 354 243
assign 1 355 243
firstGet 0 355 243
assign 1 356 243
new 0 356 243
assign 1 356 243
equals 1 356 243
assign 1 357 243
new 1 357 243
assign 1 358 243
new 0 358 243
assign 1 358 243
equals 1 358 243
assign 1 359 243
new 1 359 243
assign 1 360 243
new 0 360 243
assign 1 360 243
equals 1 360 243
assign 1 361 243
new 1 361 243
assign 1 363 243
new 0 363 243
assign 1 363 243
new 1 363 243
throw 1 363 243
dynConditionsAllSet 1 365 243
return 1 366 243
return 1 368 243
assign 1 373 243
new 0 373 243
assign 1 373 243
now 0 373 243
assign 1 374 243
new 0 374 243
assign 1 375 243
emitterGet 0 375 243
assign 1 376 243
def 1 376 243
assign 1 377 243
new 4 377 243
put 1 378 243
assign 1 380 243
new 0 380 243
assign 1 380 243
add 1 380 243
print 0 380 243
assign 1 383 243
new 0 383 243
assign 1 385 243
iteratorGet 0 0 243
assign 1 385 243
hasNextGet 0 385 243
assign 1 385 243
nextGet 0 385 243
assign 1 386 243
has 1 386 243
assign 1 386 243
not 0 386 243
put 1 387 243
assign 1 388 243
new 2 388 243
addValue 1 389 243
assign 1 392 243
iteratorGet 0 0 243
assign 1 392 243
hasNextGet 0 392 243
assign 1 392 243
nextGet 0 392 243
assign 1 393 243
has 1 393 243
assign 1 393 243
not 0 393 243
put 1 394 243
assign 1 395 243
new 2 395 243
addValue 1 396 243
assign 1 397 243
libNameGet 0 397 243
put 1 397 243
assign 1 402 243
iteratorGet 0 402 243
assign 1 402 243
hasNextGet 0 402 243
assign 1 403 243
nextGet 0 403 243
doParse 1 405 243
buildSyns 1 407 243
assign 1 410 243
new 0 410 243
assign 1 410 243
now 0 410 243
assign 1 410 243
subtract 1 410 243
assign 1 412 243
new 0 412 243
assign 1 412 243
add 1 412 243
print 0 412 243
assign 1 414 243
emitCommonGet 0 414 243
assign 1 414 243
def 1 414 243
assign 1 416 243
emitCommonGet 0 416 243
doEmit 0 416 243
assign 1 417 243
new 0 417 243
return 1 417 243
setClassesToWrite 0 420 243
libnameInfoGet 0 421 243
assign 1 423 243
classesGet 0 423 243
assign 1 423 243
valueIteratorGet 0 423 243
assign 1 423 243
hasNextGet 0 423 243
assign 1 424 243
nextGet 0 424 243
doEmit 1 425 243
emitMain 0 427 243
emitCUInit 0 428 243
assign 1 429 243
classesGet 0 429 243
assign 1 429 243
valueIteratorGet 0 429 243
assign 1 429 243
hasNextGet 0 429 243
assign 1 430 243
nextGet 0 430 243
emitSyn 1 431 243
assign 1 435 243
new 0 435 243
assign 1 435 243
now 0 435 243
assign 1 435 243
subtract 1 435 243
assign 1 436 243
def 1 436 243
assign 1 437 243
new 0 437 243
assign 1 437 243
add 1 437 243
print 0 437 243
assign 1 439 243
new 0 439 243
assign 1 439 243
add 1 439 243
print 0 439 243
prepMake 1 442 243
assign 1 446 243
not 0 446 243
make 1 447 243
deployLibrary 1 448 243
assign 1 450 243
linkedListIteratorGet 0 0 243
assign 1 450 243
hasNextGet 0 450 243
assign 1 450 243
nextGet 0 450 243
assign 1 451 243
libnameInfoGet 0 451 243
assign 1 451 243
unitShlibGet 0 451 243
assign 1 452 243
emitPathGet 0 452 243
assign 1 452 243
copy 0 452 243
assign 1 453 243
stepsGet 0 453 243
assign 1 453 243
lastGet 0 453 243
addStep 1 453 243
assign 1 454 243
fileGet 0 454 243
assign 1 454 243
existsGet 0 454 243
assign 1 455 243
fileGet 0 455 243
delete 0 455 243
assign 1 457 243
fileGet 0 457 243
assign 1 457 243
existsGet 0 457 243
assign 1 457 243
not 0 457 243
assign 1 458 243
fileGet 0 458 243
assign 1 458 243
fileGet 0 458 243
deployFile 2 458 243
assign 1 462 243
iteratorGet 0 462 243
assign 1 463 243
iteratorGet 0 463 243
assign 1 465 243
hasNextGet 0 465 243
assign 1 465 243
hasNextGet 0 465 243
assign 1 0 243
assign 1 0 243
assign 1 0 243
assign 1 466 243
nextGet 0 466 243
assign 1 466 243
apNew 1 466 243
assign 1 467 243
emitPathGet 0 467 243
assign 1 467 243
copy 0 467 243
assign 1 467 243
toString 0 467 243
assign 1 467 243
new 0 467 243
assign 1 467 243
add 1 467 243
assign 1 467 243
nextGet 0 467 243
assign 1 467 243
add 1 467 243
assign 1 467 243
apNew 1 467 243
assign 1 469 243
fileGet 0 469 243
assign 1 469 243
existsGet 0 469 243
assign 1 470 243
fileGet 0 470 243
delete 0 470 243
assign 1 472 243
fileGet 0 472 243
assign 1 472 243
existsGet 0 472 243
assign 1 472 243
not 0 472 243
assign 1 473 243
fileGet 0 473 243
assign 1 473 243
fileGet 0 473 243
deployFile 2 473 243
assign 1 478 243
new 0 478 243
assign 1 478 243
now 0 478 243
assign 1 478 243
subtract 1 478 243
assign 1 480 243
def 1 480 243
assign 1 481 243
new 0 481 243
assign 1 481 243
add 1 481 243
print 0 481 243
assign 1 483 243
def 1 483 243
assign 1 484 243
new 0 484 243
assign 1 484 243
add 1 484 243
print 0 484 243
assign 1 486 243
def 1 486 243
assign 1 487 243
new 0 487 243
assign 1 487 243
add 1 487 243
print 0 487 243
assign 1 491 243
new 0 491 243
print 0 491 243
assign 1 492 243
run 2 492 243
assign 1 493 243
new 0 493 243
assign 1 493 243
add 1 493 243
assign 1 493 243
new 0 493 243
assign 1 493 243
add 1 493 243
print 0 493 243
return 1 494 243
assign 1 496 243
new 0 496 243
return 1 496 243
assign 1 500 243
justParsedGet 0 500 243
assign 1 500 243
valueIteratorGet 0 500 243
assign 1 500 243
hasNextGet 0 500 243
assign 1 501 243
nextGet 0 501 243
assign 1 502 243
heldGet 0 502 243
libNameSet 1 502 243
assign 1 503 243
getSyn 2 503 243
libNameSet 1 504 243
assign 1 506 243
justParsedGet 0 506 243
assign 1 506 243
valueIteratorGet 0 506 243
assign 1 506 243
hasNextGet 0 506 243
assign 1 507 243
nextGet 0 507 243
assign 1 508 243
heldGet 0 508 243
assign 1 508 243
synGet 0 508 243
checkInheritance 2 509 243
integrate 1 510 243
assign 1 512 243
new 0 512 243
justParsedSet 1 512 243
assign 1 516 243
heldGet 0 516 243
assign 1 516 243
synGet 0 516 243
assign 1 516 243
def 1 516 243
assign 1 517 243
heldGet 0 517 243
assign 1 517 243
synGet 0 517 243
return 1 517 243
assign 1 519 243
heldGet 0 519 243
libNameSet 1 519 243
assign 1 520 243
heldGet 0 520 243
assign 1 520 243
extendsGet 0 520 243
assign 1 520 243
undef 1 520 243
assign 1 521 243
new 1 521 243
assign 1 523 243
classesGet 0 523 243
assign 1 523 243
heldGet 0 523 243
assign 1 523 243
extendsGet 0 523 243
assign 1 523 243
toString 0 523 243
assign 1 523 243
get 1 523 243
assign 1 525 243
def 1 525 243
assign 1 526 243
heldGet 0 526 243
libNameSet 1 526 243
assign 1 527 243
getSyn 2 527 243
assign 1 530 243
heldGet 0 530 243
assign 1 530 243
extendsGet 0 530 243
assign 1 530 243
loadSyn 1 530 243
assign 1 532 243
new 2 532 243
assign 1 534 243
heldGet 0 534 243
synSet 1 534 243
assign 1 535 243
heldGet 0 535 243
assign 1 535 243
namepathGet 0 535 243
assign 1 535 243
toString 0 535 243
addSynClass 2 535 243
return 1 536 243
assign 1 540 243
toString 0 540 243
assign 1 541 243
synClassesGet 0 541 243
assign 1 541 243
get 1 541 243
assign 1 542 243
def 1 542 243
return 1 543 243
assign 1 549 243
emitterGet 0 549 243
assign 1 549 243
loadSyn 1 549 243
addSynClass 2 550 243
return 1 551 243
assign 1 558 243
undef 1 558 243
assign 1 559 243
new 1 559 243
return 1 561 243
assign 1 566 243
new 1 566 243
assign 1 567 243
new 0 567 243
assign 1 568 243
emitterGet 0 568 243
assign 1 569 243
assign 1 570 243
new 0 570 243
assign 1 571 243
shouldEmitGet 0 571 243
put 1 571 243
assign 1 0 243
assign 1 0 243
assign 1 0 243
assign 1 574 243
new 0 574 243
assign 1 574 243
toString 0 574 243
assign 1 574 243
add 1 574 243
print 0 574 243
assign 1 576 243
assign 1 578 243
fileGet 0 578 243
assign 1 578 243
readerGet 0 578 243
assign 1 578 243
open 0 578 243
assign 1 578 243
readBuffer 1 578 243
assign 1 579 243
fileGet 0 579 243
assign 1 579 243
readerGet 0 579 243
close 0 579 243
assign 1 580 243
tokenize 1 580 243
assign 1 584 243
new 0 584 243
echo 0 584 243
assign 1 586 243
outermostGet 0 586 243
nodify 2 586 243
assign 1 588 243
new 0 588 243
print 0 588 243
assign 1 589 243
new 2 589 243
traverse 1 589 243
assign 1 593 243
new 0 593 243
echo 0 593 243
assign 1 595 243
new 0 595 243
traverse 1 595 243
assign 1 597 243
new 0 597 243
print 0 597 243
assign 1 598 243
new 2 598 243
traverse 1 598 243
assign 1 601 243
new 0 601 243
echo 0 601 243
assign 1 604 243
new 0 604 243
traverse 1 604 243
contain 0 605 243
assign 1 607 243
new 0 607 243
print 0 607 243
assign 1 608 243
new 2 608 243
traverse 1 608 243
assign 1 612 243
new 0 612 243
echo 0 612 243
assign 1 614 243
new 0 614 243
traverse 1 614 243
assign 1 616 243
new 0 616 243
print 0 616 243
assign 1 617 243
new 2 617 243
traverse 1 617 243
assign 1 621 243
new 0 621 243
echo 0 621 243
assign 1 623 243
new 0 623 243
traverse 1 623 243
assign 1 625 243
new 0 625 243
print 0 625 243
assign 1 626 243
new 2 626 243
traverse 1 626 243
assign 1 630 243
new 0 630 243
echo 0 630 243
assign 1 632 243
new 0 632 243
traverse 1 632 243
assign 1 634 243
new 0 634 243
print 0 634 243
assign 1 635 243
new 2 635 243
traverse 1 635 243
assign 1 639 243
new 0 639 243
echo 0 639 243
assign 1 641 243
new 0 641 243
traverse 1 641 243
assign 1 643 243
new 0 643 243
print 0 643 243
assign 1 644 243
new 2 644 243
traverse 1 644 243
assign 1 648 243
new 0 648 243
echo 0 648 243
assign 1 650 243
new 0 650 243
traverse 1 650 243
assign 1 652 243
new 0 652 243
print 0 652 243
assign 1 653 243
new 2 653 243
traverse 1 653 243
assign 1 657 243
new 0 657 243
echo 0 657 243
assign 1 659 243
new 0 659 243
traverse 1 659 243
assign 1 661 243
new 0 661 243
print 0 661 243
assign 1 662 243
new 2 662 243
traverse 1 662 243
assign 1 666 243
new 0 666 243
echo 0 666 243
assign 1 668 243
new 0 668 243
traverse 1 668 243
assign 1 670 243
new 0 670 243
print 0 670 243
assign 1 671 243
new 2 671 243
traverse 1 671 243
assign 1 674 243
new 0 674 243
echo 0 674 243
assign 1 676 243
new 0 676 243
traverse 1 676 243
assign 1 678 243
new 0 678 243
print 0 678 243
assign 1 679 243
new 2 679 243
traverse 1 679 243
assign 1 683 243
new 0 683 243
echo 0 683 243
assign 1 684 243
new 0 684 243
print 0 684 243
assign 1 686 243
new 0 686 243
traverse 1 686 243
assign 1 0 243
assign 1 0 243
assign 1 0 243
assign 1 688 243
new 0 688 243
print 0 688 243
assign 1 689 243
new 2 689 243
traverse 1 689 243
assign 1 691 243
classesGet 0 691 243
assign 1 691 243
valueIteratorGet 0 691 243
assign 1 691 243
hasNextGet 0 691 243
assign 1 692 243
nextGet 0 692 243
assign 1 694 243
transUnitGet 0 694 243
assign 1 695 243
new 1 695 243
assign 1 696 243
TRANSUNITGet 0 696 243
typenameSet 1 696 243
assign 1 697 243
new 0 697 243
assign 1 698 243
heldGet 0 698 243
assign 1 698 243
emitsGet 0 698 243
emitsSet 1 698 243
heldSet 1 699 243
delete 0 700 243
addValue 1 701 243
copyLoc 1 702 243
reInitContained 0 708 243
assign 1 709 243
containedGet 0 709 243
assign 1 710 243
new 0 710 243
assign 1 711 243
new 0 711 243
assign 1 711 243
crGet 0 711 243
assign 1 712 243
linkedListIteratorGet 0 712 243
assign 1 712 243
hasNextGet 0 712 243
assign 1 713 243
new 1 713 243
assign 1 714 243
nextGet 0 714 243
heldSet 1 714 243
nlcSet 1 715 243
assign 1 716 243
heldGet 0 716 243
assign 1 716 243
equals 1 716 243
assign 1 717 243
increment 0 717 243
assign 1 719 243
heldGet 0 719 243
assign 1 719 243
notEquals 1 719 243
addValue 1 720 243
containerSet 1 721 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
return 1 0 243
assign 1 0 243
assign 1 0 243
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 404051026: return bem_printPlacesGet_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 902949587: return bem_printStepsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 392968773: return bem_printPlacesSet_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 891867334: return bem_printStepsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_2_9_5_ContainerArray) bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bevs_inst = (BEC_2_5_5_BuildBuild)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bevs_inst;
}
}
}
