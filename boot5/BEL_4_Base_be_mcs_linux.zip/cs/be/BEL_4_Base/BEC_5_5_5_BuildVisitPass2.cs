namespace be.BEL_4_Base {
/* IO:File: source/build/Pass2.be */
public class BEC_5_5_5_BuildVisitPass2 : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass2() { }
static BEC_5_5_5_BuildVisitPass2() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x32};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2E};
public static new BEC_5_5_5_BuildVisitPass2 bevs_inst;
public BEC_4_3_MathInt bevp_idType;
public BEC_4_3_MathInt bevp_intType;
public BEC_9_3_ContainerMap bevp_matchMap;
public BEC_9_3_ContainerMap bevp_rwords;
public override BEC_6_6_SystemObject bem_begin_1(BEC_6_6_SystemObject beva_transi) {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
BEC_5_9_BuildConstants bevt_1_tmpvar_phold = null;
base.bem_begin_1(beva_transi);
bevp_idType = bevp_ntypes.bem_IDGet_0();
bevp_intType = bevp_ntypes.bem_INTLGet_0();
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_matchMap = bevt_0_tmpvar_phold.bem_matchMapGet_0();
bevt_1_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_rwords = bevt_1_tmpvar_phold.bem_rwordsGet_0();
return this;
} /*method end*/
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevl_held = null;
BEC_6_6_SystemObject bevl_type = null;
BEC_5_4_BuildNode bevl_nxp = null;
BEC_5_4_BuildNode bevl_nxp2 = null;
BEC_5_4_BuildNode bevl_nxp3 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_27_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 35 */ {
bevt_5_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpvar_phold;
} /* Line: 36 */
bevl_held = beva_node.bem_heldGet_0();
if (bevl_held == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevl_type = bevp_matchMap.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 41 */ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 43 */
 else  /* Line: 44 */ {
bevt_8_tmpvar_phold = bevl_held.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 46 */ {
bevl_nxp = beva_node.bem_nextPeerGet_0();
if (bevl_nxp == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_11_tmpvar_phold = bevl_nxp.bem_heldGet_0();
if (bevt_11_tmpvar_phold == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 48 */ {
bevt_13_tmpvar_phold = bevl_nxp.bem_heldGet_0();
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_0));
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 49 */ {
bevl_nxp2 = bevl_nxp.bem_nextPeerGet_0();
if (bevl_nxp2 == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_17_tmpvar_phold = bevl_nxp2.bem_heldGet_0();
if (bevt_17_tmpvar_phold == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
 else  /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevl_nxp3 = bevl_nxp2.bem_nextDescendGet_0();
bevt_19_tmpvar_phold = bevl_nxp2.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_23_tmpvar_phold = bevl_nxp.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevl_nxp2.bem_heldGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_20_tmpvar_phold);
bevt_25_tmpvar_phold = bevp_ntypes.bem_FLOATLGet_0();
beva_node.bem_typenameSet_1(bevt_25_tmpvar_phold);
bevl_nxp2.bem_delete_0();
bevl_nxp.bem_delete_0();
return bevl_nxp3;
} /* Line: 58 */
} /* Line: 53 */
} /* Line: 51 */
} /* Line: 49 */
beva_node.bem_typenameSet_1(bevp_intType);
} /* Line: 63 */
 else  /* Line: 64 */ {
bevl_type = bevp_rwords.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 66 */ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 67 */
 else  /* Line: 68 */ {
beva_node.bem_typenameSet_1(bevp_idType);
} /* Line: 69 */
} /* Line: 66 */
} /* Line: 46 */
} /* Line: 41 */
bevt_27_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_27_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_idTypeGet_0() {
return bevp_idType;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_idTypeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_idType = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_intTypeGet_0() {
return bevp_intType;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_intTypeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_intType = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_matchMapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_matchMap = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rwordsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rwords = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {21, 24, 25, 26, 26, 27, 27, 35, 35, 35, 36, 36, 38, 39, 39, 40, 41, 41, 43, 46, 47, 48, 48, 48, 48, 48, 0, 0, 0, 49, 49, 49, 50, 51, 51, 51, 51, 51, 0, 0, 0, 52, 53, 53, 54, 54, 54, 54, 54, 54, 55, 55, 56, 57, 58, 63, 65, 66, 66, 67, 69, 74, 74, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 20, 21, 22, 23, 60, 61, 62, 64, 65, 67, 68, 73, 74, 75, 80, 81, 84, 86, 87, 92, 93, 94, 99, 100, 103, 107, 110, 111, 112, 114, 115, 120, 121, 122, 127, 128, 131, 135, 138, 139, 140, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 157, 160, 161, 166, 167, 170, 175, 176, 179, 182, 186, 189, 193, 196, 200, 203};
/* BEGIN LINEINFO 
begin 1 21 17
assign 1 24 18
IDGet 0 24 18
assign 1 25 19
INTLGet 0 25 19
assign 1 26 20
constantsGet 0 26 20
assign 1 26 21
matchMapGet 0 26 21
assign 1 27 22
constantsGet 0 27 22
assign 1 27 23
rwordsGet 0 27 23
assign 1 35 60
typenameGet 0 35 60
assign 1 35 61
TRANSUNITGet 0 35 61
assign 1 35 62
equals 1 35 62
assign 1 36 64
nextDescendGet 0 36 64
return 1 36 65
assign 1 38 67
heldGet 0 38 67
assign 1 39 68
def 1 39 73
assign 1 40 74
get 1 40 74
assign 1 41 75
def 1 41 80
typenameSet 1 43 81
assign 1 46 84
isInteger 0 46 84
assign 1 47 86
nextPeerGet 0 47 86
assign 1 48 87
def 1 48 92
assign 1 48 93
heldGet 0 48 93
assign 1 48 94
def 1 48 99
assign 1 0 100
assign 1 0 103
assign 1 0 107
assign 1 49 110
heldGet 0 49 110
assign 1 49 111
new 0 49 111
assign 1 49 112
equals 1 49 112
assign 1 50 114
nextPeerGet 0 50 114
assign 1 51 115
def 1 51 120
assign 1 51 121
heldGet 0 51 121
assign 1 51 122
def 1 51 127
assign 1 0 128
assign 1 0 131
assign 1 0 135
assign 1 52 138
nextDescendGet 0 52 138
assign 1 53 139
heldGet 0 53 139
assign 1 53 140
isInteger 0 53 140
assign 1 54 142
heldGet 0 54 142
assign 1 54 143
heldGet 0 54 143
assign 1 54 144
add 1 54 144
assign 1 54 145
heldGet 0 54 145
assign 1 54 146
add 1 54 146
heldSet 1 54 147
assign 1 55 148
FLOATLGet 0 55 148
typenameSet 1 55 149
delete 0 56 150
delete 0 57 151
return 1 58 152
typenameSet 1 63 157
assign 1 65 160
get 1 65 160
assign 1 66 161
def 1 66 166
typenameSet 1 67 167
typenameSet 1 69 170
assign 1 74 175
nextDescendGet 0 74 175
return 1 74 176
return 1 0 179
assign 1 0 182
return 1 0 186
assign 1 0 189
return 1 0 193
assign 1 0 196
return 1 0 200
assign 1 0 203
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 327922578: return bem_idTypeGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1323554192: return bem_matchMapGet_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1752635198: return bem_intTypeGet_0();
case 1102720804: return bem_classNameGet_0();
case 634261936: return bem_rwordsGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 623179683: return bem_rwordsSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 339004831: return bem_idTypeSet_1(bevd_0);
case 1312471939: return bem_matchMapSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1763717451: return bem_intTypeSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_5_BuildVisitPass2();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_5_BuildVisitPass2.bevs_inst = (BEC_5_5_5_BuildVisitPass2)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_5_BuildVisitPass2.bevs_inst;
}
}
}
