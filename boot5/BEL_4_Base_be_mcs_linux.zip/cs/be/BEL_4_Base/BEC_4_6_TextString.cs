namespace be.BEL_4_Base {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_4_6_TextString : BEC_6_6_SystemObject {
public BEC_4_6_TextString() { }
static BEC_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_length);
    }
    public BEC_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_length);
    }
    public BEC_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x42,0x75,0x66,0x66,0x65,0x72,0x20,0x72,0x65,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_1 = {0x0A};
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_7 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_8 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(57));
private static BEC_4_3_MathInt bevo_9 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(48));
private static BEC_4_3_MathInt bevo_10 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(64));
private static BEC_4_3_MathInt bevo_11 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(91));
private static BEC_4_3_MathInt bevo_12 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(96));
private static BEC_4_3_MathInt bevo_13 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(123));
private static BEC_4_3_MathInt bevo_14 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_15 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_16 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_17 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_18 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_19 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_20 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_21 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_22 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_23 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_24 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_25 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_26 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
private static BEC_4_3_MathInt bevo_27 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_28 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_2 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_4_3_MathInt bevo_29 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_30 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
public static new BEC_4_6_TextString bevs_inst;
public BEC_6_6_SystemObject bevp_vstring;
public BEC_4_3_MathInt bevp_size;
public BEC_4_3_MathInt bevp_capacity;
public BEC_4_3_MathInt bevp_leni;
public BEC_4_3_MathInt bevp_sizi;
public virtual BEC_6_6_SystemObject bem_vstringGet_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_vstringSet_0() {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_new_1(BEC_4_3_MathInt beva__capacity) {
this.bem_capacitySet_1(beva__capacity);
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_capacitySet_1(BEC_4_3_MathInt beva_ncap) {
BEC_4_6_TextString bevl_failed = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
if (bevp_capacity == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_3_tmpvar_phold = bevp_capacity.bem_equals_1(beva_ncap);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 211 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 211 */
 else  /* Line: 211 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 211 */ {
return this;
} /* Line: 212 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevl_failed == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(26, bels_0));
bevt_5_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 264 */
if (bevp_size == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_8_tmpvar_phold = bevp_size.bem_greater_1(beva_ncap);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 266 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 266 */ {
bevp_size = (BEC_4_3_MathInt) beva_ncap.bem_copy_0();
} /* Line: 267 */
bevp_capacity = beva_ncap;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_hexNew_1(BEC_4_6_TextString beva_val) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_setHex_2(bevt_1_tmpvar_phold, beva_val);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_getHex_1(BEC_4_3_MathInt beva_pos) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_1_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_4_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevt_5_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(16));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_toString_3(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_setHex_2(BEC_4_3_MathInt beva_pos, BEC_4_6_TextString beva_hval) {
BEC_4_3_MathInt bevl_val = null;
bevl_val = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_addValue_1(BEC_6_6_SystemObject beva_astr) {
BEC_4_6_TextString bevl_str = null;
BEC_4_3_MathInt bevl_nsize = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_str = (BEC_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
if (bevp_leni == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevp_leni = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevp_sizi = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 291 */
bevt_1_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bem_setValue_1(bevt_1_tmpvar_phold);
bevp_sizi.bem_addValue_1(bevp_size);
bevt_2_tmpvar_phold = bevp_capacity.bem_lesser_1(bevp_sizi);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevt_5_tmpvar_phold = bevo_0;
bevt_4_tmpvar_phold = bevp_sizi.bem_add_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_multiply_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_2;
bevl_nsize = bevt_3_tmpvar_phold.bem_divide_1(bevt_7_tmpvar_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 298 */
bevt_8_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_9_tmpvar_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold, bevp_size);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_write_1(BEC_6_6_SystemObject beva_stri) {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_writeTo_1(BEC_6_6_SystemObject beva_w) {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_open_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_close_0() {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_extractString_0() {
BEC_4_6_TextString bevl_str = null;
bevl_str = (BEC_4_6_TextString) this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public virtual BEC_4_6_TextString bem_clear_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevp_size.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 334 */ {
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_setIntUnchecked_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
} /* Line: 336 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_codeNew_1(BEC_6_6_SystemObject beva_codei) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_setCodeUnchecked_2(bevt_1_tmpvar_phold, (BEC_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_chomp_0() {
BEC_4_6_TextString bevl_nl = null;
BEC_6_15_SystemCurrentPlatform bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpvar_phold.bem_newlineGet_0();
bevt_1_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_5_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevp_size.bem_subtract_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = this.bem_substring_2(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 349 */
bevl_nl = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_1));
bevt_6_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevt_8_tmpvar_phold = bevo_5;
bevt_10_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevp_size.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_substring_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
return bevt_7_tmpvar_phold;
} /* Line: 353 */
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_4_6_TextString bevl_c = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_c = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_c.bem_addValue_1(this);
return (BEC_6_6_SystemObject) bevl_c;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_begins_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 366 */ {
bevt_3_tmpvar_phold = bevo_7;
bevt_2_tmpvar_phold = bevl_found.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 366 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 366 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 367 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_ends_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 373 */ {
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 373 */
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevp_size.bem_subtract_1(bevt_3_tmpvar_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpvar_phold);
if (bevl_found == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 376 */
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_4_6_TextString beva_str) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_str == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 382 */ {
bevt_3_tmpvar_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 382 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 382 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 382 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 383 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isInteger_0() {
BEC_4_3_MathInt bevl_ic = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
bevl_ic = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 390 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 390 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevl_ic.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 392 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 392 */ {
bevt_5_tmpvar_phold = bevo_9;
bevt_4_tmpvar_phold = bevl_ic.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 392 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 392 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 392 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 392 */ {
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 393 */
bevl_j.bem_incrementValue_0();
} /* Line: 390 */
 else  /* Line: 390 */ {
break;
} /* Line: 390 */
} /* Line: 390 */
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lowerValue_0() {
BEC_4_3_MathInt bevl_vc = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 401 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 401 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_5_tmpvar_phold = bevo_11;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 403 */
 else  /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 403 */ {
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(32));
bevl_vc.bem_addValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 405 */
bevl_j.bem_incrementValue_0();
} /* Line: 401 */
 else  /* Line: 401 */ {
break;
} /* Line: 401 */
} /* Line: 401 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_lower_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_lowerValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_upperValue_0() {
BEC_4_3_MathInt bevl_vc = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 416 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 416 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_12;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevt_5_tmpvar_phold = bevo_13;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 418 */
 else  /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 418 */ {
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 420 */
bevl_j.bem_incrementValue_0();
} /* Line: 416 */
 else  /* Line: 416 */ {
break;
} /* Line: 416 */
} /* Line: 416 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_upper_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_upperValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_swap_2(BEC_4_6_TextString beva_from, BEC_4_6_TextString beva_to) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_2_tmpvar_phold = this.bem_split_1(beva_from);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_to, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_getPoint_1(BEC_4_3_MathInt beva_posi) {
BEC_4_6_TextString bevl_buf = null;
BEC_6_6_SystemObject bevl_j = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_6_TextString bevl_y = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_buf = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 437 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_posi);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 437 */ {
bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 437 */
 else  /* Line: 437 */ {
break;
} /* Line: 437 */
} /* Line: 437 */
bevt_2_tmpvar_phold = bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_y = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
return bevl_y;
} /*method end*/
public virtual BEC_4_3_MathInt bem_hashValue_1(BEC_4_3_MathInt beva_into) {
BEC_4_3_MathInt bevl_c = null;
BEC_4_3_MathInt bevl_j = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_c = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
beva_into.bem_setValue_1(bevt_0_tmpvar_phold);
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 447 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 447 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpvar_phold);
beva_into.bem_addValue_1(bevl_c);
bevl_j.bem_incrementValue_0();
} /* Line: 447 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
bevt_3_tmpvar_phold = beva_into.bem_absValue_0();
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_4_3_MathInt bem_hashGet_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_hashValue_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_getCode_1(BEC_4_3_MathInt beva_pos) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_getInt_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_14;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 470 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 470 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 470 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 470 */
 else  /* Line: 470 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 470 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 490 */
 else  /* Line: 498 */ {
return null;
} /* Line: 499 */
return beva_into;
} /*method end*/
public virtual BEC_4_3_MathInt bem_getCode_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_15;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 512 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 512 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 512 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 512 */
 else  /* Line: 512 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 512 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 536 */
 else  /* Line: 541 */ {
return null;
} /* Line: 542 */
return beva_into;
} /*method end*/
public virtual BEC_4_6_TextString bem_setInt_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_16;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 548 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 548 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 548 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 548 */
 else  /* Line: 548 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 548 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 549 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_setCode_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_17;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 554 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 554 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 554 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 554 */
 else  /* Line: 554 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 554 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 555 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevp_size.bem_lesserEquals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 560 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 561 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_setIntUnchecked_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_setCodeUnchecked_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_reverseFind_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_rfind_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevl_rpos = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_reverseBytes_0();
bevt_3_tmpvar_phold = (BEC_4_6_TextString) beva_str.bem_copy_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpvar_phold.bem_find_1(bevt_2_tmpvar_phold);
if (bevl_rpos == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 654 */ {
bevt_5_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpvar_phold;
} /* Line: 656 */
return null;
} /*method end*/
public virtual BEC_4_3_MathInt bem_find_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_19;
bevt_0_tmpvar_phold = this.bem_find_2(beva_str, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_find_2(BEC_4_6_TextString beva_str, BEC_4_3_MathInt beva_start) {
BEC_4_3_MathInt bevl_end = null;
BEC_4_3_MathInt bevl_current = null;
BEC_4_3_MathInt bevl_myval = null;
BEC_4_3_MathInt bevl_strfirst = null;
BEC_4_3_MathInt bevl_strsize = null;
BEC_4_3_MathInt bevl_strval = null;
BEC_4_3_MathInt bevl_current2 = null;
BEC_4_3_MathInt bevl_end2 = null;
BEC_4_3_MathInt bevl_currentstr2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
if (beva_str == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
if (beva_start == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_9_tmpvar_phold = bevo_20;
bevt_8_tmpvar_phold = beva_start.bem_lesser_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_10_tmpvar_phold = beva_start.bem_greaterEquals_1(bevp_size);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_12_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_greater_1(bevp_size);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_14_tmpvar_phold = bevo_21;
bevt_13_tmpvar_phold = bevp_size.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_16_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpvar_phold = bevo_22;
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
return null;
} /* Line: 669 */
bevl_end = bevp_size;
bevl_current = (BEC_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_strfirst = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_18_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpvar_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpvar_phold = bevo_23;
bevt_19_tmpvar_phold = bevl_strsize.bem_greater_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 680 */ {
bevl_strval = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_current2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_end2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 683 */
while (true)
 /* Line: 686 */ {
bevt_21_tmpvar_phold = bevl_current.bem_lesser_1(bevl_end);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 686 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
bevt_22_tmpvar_phold = bevl_myval.bem_equals_1(bevl_strfirst);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 688 */ {
bevt_24_tmpvar_phold = bevo_24;
bevt_23_tmpvar_phold = bevl_strsize.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 689 */ {
return bevl_current;
} /* Line: 690 */
bevl_current2.bem_setValue_1(bevl_current);
bevl_current2.bem_incrementValue_0();
bevl_end2.bem_setValue_1(bevl_current);
bevt_25_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_end2.bem_addValue_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_end2.bem_greater_1(bevp_size);
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 696 */ {
return null;
} /* Line: 697 */
bevl_currentstr2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 700 */ {
bevt_27_tmpvar_phold = bevl_current2.bem_lesser_1(bevl_end2);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 700 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
bevt_28_tmpvar_phold = bevl_myval.bem_notEquals_1(bevl_strval);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 703 */ {
break;
} /* Line: 704 */
bevl_current2.bem_incrementValue_0();
bevl_currentstr2.bem_incrementValue_0();
} /* Line: 707 */
 else  /* Line: 700 */ {
break;
} /* Line: 700 */
} /* Line: 700 */
bevt_29_tmpvar_phold = bevl_current2.bem_equals_1(bevl_end2);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 709 */ {
return bevl_current;
} /* Line: 710 */
} /* Line: 709 */
bevl_current.bem_incrementValue_0();
} /* Line: 713 */
 else  /* Line: 686 */ {
break;
} /* Line: 686 */
} /* Line: 686 */
return null;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_split_1(BEC_4_6_TextString beva_delim) {
BEC_9_10_ContainerLinkedList bevl_splits = null;
BEC_4_3_MathInt bevl_last = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_ds = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevl_splits = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 723 */ {
if (bevl_i == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 723 */ {
bevt_1_tmpvar_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpvar_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 726 */
 else  /* Line: 723 */ {
break;
} /* Line: 723 */
} /* Line: 723 */
bevt_2_tmpvar_phold = bevl_last.bem_lesser_1(bevp_size);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 728 */ {
bevt_3_tmpvar_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 729 */
return bevl_splits;
} /*method end*/
public virtual BEC_4_6_TextString bem_join_2(BEC_4_6_TextString beva_delim, BEC_6_6_SystemObject beva_splits) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_9_TextTokenizer bevt_1_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lineSplitterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_tokenize_1(this);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_compare_1(BEC_6_6_SystemObject beva_stri) {
BEC_4_3_MathInt bevl_mysize = null;
BEC_4_3_MathInt bevl_osize = null;
BEC_4_3_MathInt bevl_maxsize = null;
BEC_4_3_MathInt bevl_myret = null;
BEC_4_3_MathInt bevl_mv = null;
BEC_4_3_MathInt bevl_ov = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 751 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 751 */ {
bevt_2_tmpvar_phold = beva_stri.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 751 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 751 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 751 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 751 */ {
return null;
} /* Line: 752 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevt_3_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 756 */ {
bevl_maxsize = bevl_osize;
} /* Line: 757 */
 else  /* Line: 758 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 759 */
bevl_myret = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_mv = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_ov = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 764 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(bevl_maxsize);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 764 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
bevt_5_tmpvar_phold = bevl_mv.bem_notEquals_1(bevl_ov);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 767 */ {
bevt_6_tmpvar_phold = bevl_mv.bem_greater_1(bevl_ov);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 768 */ {
bevt_7_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
return bevt_7_tmpvar_phold;
} /* Line: 769 */
 else  /* Line: 770 */ {
bevt_8_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
return bevt_8_tmpvar_phold;
} /* Line: 771 */
} /* Line: 768 */
bevl_i.bem_incrementValue_0();
} /* Line: 764 */
 else  /* Line: 764 */ {
break;
} /* Line: 764 */
} /* Line: 764 */
bevt_10_tmpvar_phold = bevo_25;
bevt_9_tmpvar_phold = bevl_myret.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 775 */ {
bevt_11_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 776 */ {
bevl_myret = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
} /* Line: 777 */
 else  /* Line: 776 */ {
bevt_12_tmpvar_phold = bevl_osize.bem_greater_1(bevl_mysize);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 778 */ {
bevl_myret = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
} /* Line: 779 */
} /* Line: 776 */
} /* Line: 776 */
return bevl_myret;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_lesser_1(BEC_4_6_TextString beva_stri) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 786 */ {
return null;
} /* Line: 786 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_26;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 787 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 788 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_greater_1(BEC_4_6_TextString beva_stri) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 794 */ {
return null;
} /* Line: 794 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_27;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 795 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 796 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_stri) {
BEC_4_3_MathInt bevl_mysize = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 809 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 810 */

  var bevls_stri = beva_stri as BEC_4_6_TextString;
  if (bevls_stri != null) {
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BELS_Base.BECS_Runtime.boolFalse;
          }
       }
       return be.BELS_Base.BECS_Runtime.boolTrue;
   }
  }
  bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_str) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_str);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_add_1(BEC_6_6_SystemObject beva_astr) {
BEC_4_6_TextString bevl_str = null;
BEC_4_6_TextString bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
bevl_str = (BEC_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_res = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpvar_phold, bevp_size, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_5_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_6_6_SystemObject bem_create_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
return (BEC_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_copyValue_4(BEC_4_6_TextString beva_org, BEC_4_3_MathInt beva_starti, BEC_4_3_MathInt beva_endi, BEC_4_3_MathInt beva_dstarti) {
BEC_4_3_MathInt bevl_mleni = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_9_SystemException bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_28;
bevt_1_tmpvar_phold = beva_starti.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_4_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_3_tmpvar_phold = beva_starti.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_6_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_5_tmpvar_phold = beva_endi.bem_greater_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 910 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 910 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 910 */ {
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_2));
bevt_7_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_8_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 911 */
 else  /* Line: 912 */ {
if (bevp_leni == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 915 */ {
bevp_leni = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevp_sizi = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 917 */
bevp_leni.bem_setValue_1(beva_endi);
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bem_setValue_1(beva_dstarti);
bevp_sizi.bem_addValue_1(bevp_leni);
bevt_10_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_capacity);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 926 */ {
bevt_11_tmpvar_phold = (BEC_4_3_MathInt) bevp_sizi.bem_copy_0();
this.bem_capacitySet_1(bevt_11_tmpvar_phold);
} /* Line: 927 */

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         bevt_12_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_size);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 982 */ {
bevp_size = (BEC_4_3_MathInt) bevp_sizi.bem_copy_0();
} /* Line: 986 */
return this;
} /* Line: 988 */
} /*method end*/
public virtual BEC_4_6_TextString bem_substring_1(BEC_4_3_MathInt beva_starti) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sizeGet_0();
bevt_0_tmpvar_phold = this.bem_substring_2(beva_starti, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_substring_2(BEC_4_3_MathInt beva_starti, BEC_4_3_MathInt beva_endi) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_echo_0() {
this.bem_output_0();
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_iteratorGet_0() {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_17_TextMultiByteIterator) (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_12_TextByteIterator) (new BEC_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_17_TextMultiByteIterator) (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_12_TextByteIterator bem_biterGet_0() {
BEC_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_12_TextByteIterator) (new BEC_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_17_TextMultiByteIterator) (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_17_TextMultiByteIterator) (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
if (beva_snw == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1114 */ {
this.bem_new_0();
} /* Line: 1115 */
 else  /* Line: 1116 */ {
bevt_2_tmpvar_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevo_29;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
this.bem_new_1(bevt_1_tmpvar_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1118 */
return this;
} /*method end*/
public override BEC_5_4_LogicBool bem_serializeContents_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_strip_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_strip_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_reverseBytes_0() {
BEC_4_3_MathInt bevl_vb = null;
BEC_4_3_MathInt bevl_ve = null;
BEC_4_3_MathInt bevl_b = null;
BEC_4_3_MathInt bevl_e = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevl_vb = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_ve = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_b = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = bevo_30;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpvar_phold);
while (true)
 /* Line: 1135 */ {
bevt_1_tmpvar_phold = bevl_e.bem_greater_1(bevl_b);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1135 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bem_incrementValue_0();
bevl_e.bem_decrementValue_0();
} /* Line: 1141 */
 else  /* Line: 1135 */ {
break;
} /* Line: 1135 */
} /* Line: 1135 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_vstringSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_vstring = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_leniSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_leni = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_siziSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sizi = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {183, 193, 197, 197, 211, 211, 211, 0, 0, 0, 212, 263, 263, 264, 264, 264, 266, 266, 0, 266, 0, 0, 267, 269, 273, 273, 274, 275, 275, 279, 279, 279, 279, 279, 279, 279, 283, 284, 288, 289, 289, 290, 291, 293, 293, 294, 296, 297, 297, 297, 297, 297, 297, 298, 300, 300, 300, 305, 309, 313, 317, 328, 329, 330, 334, 334, 335, 335, 335, 336, 341, 341, 342, 343, 343, 347, 347, 348, 349, 349, 349, 349, 349, 351, 352, 353, 353, 353, 353, 353, 355, 359, 359, 359, 360, 361, 365, 366, 366, 0, 366, 366, 0, 0, 367, 367, 369, 369, 373, 373, 373, 373, 374, 374, 374, 375, 375, 376, 376, 378, 378, 382, 382, 0, 382, 382, 382, 0, 0, 383, 383, 385, 385, 389, 390, 390, 391, 392, 392, 0, 392, 392, 0, 0, 393, 393, 390, 396, 396, 400, 401, 401, 402, 403, 403, 403, 403, 0, 0, 0, 404, 404, 405, 401, 411, 411, 411, 415, 416, 416, 417, 418, 418, 418, 418, 0, 0, 0, 419, 419, 420, 416, 426, 426, 426, 430, 430, 430, 430, 435, 435, 436, 437, 437, 438, 437, 440, 440, 441, 445, 446, 446, 447, 447, 448, 449, 449, 450, 447, 452, 452, 456, 456, 456, 460, 460, 460, 470, 470, 470, 0, 0, 0, 499, 501, 512, 512, 512, 0, 0, 0, 542, 544, 548, 548, 548, 0, 0, 0, 549, 554, 554, 554, 0, 0, 0, 555, 560, 560, 561, 561, 563, 563, 646, 646, 652, 652, 652, 652, 652, 654, 654, 655, 655, 656, 656, 658, 662, 662, 662, 668, 668, 0, 668, 668, 0, 0, 0, 668, 668, 0, 0, 0, 668, 0, 0, 0, 668, 668, 0, 0, 0, 668, 668, 0, 0, 0, 668, 668, 668, 0, 0, 669, 672, 673, 674, 675, 676, 676, 678, 680, 680, 681, 682, 683, 686, 687, 688, 689, 689, 690, 692, 693, 694, 695, 695, 696, 697, 699, 700, 701, 702, 703, 706, 707, 709, 710, 713, 715, 719, 720, 721, 722, 723, 723, 724, 724, 725, 726, 728, 729, 729, 731, 735, 735, 735, 739, 739, 739, 739, 743, 751, 751, 0, 751, 0, 0, 752, 754, 755, 756, 757, 759, 761, 762, 763, 764, 764, 765, 766, 767, 768, 769, 769, 771, 771, 764, 775, 775, 776, 777, 778, 779, 782, 786, 786, 786, 787, 787, 787, 788, 788, 790, 790, 794, 794, 794, 795, 795, 795, 796, 796, 798, 798, 809, 809, 810, 810, 869, 869, 874, 874, 874, 878, 879, 879, 879, 880, 880, 880, 881, 881, 881, 882, 885, 885, 910, 910, 0, 910, 910, 0, 910, 910, 0, 0, 0, 0, 911, 911, 911, 915, 915, 916, 917, 919, 920, 921, 923, 924, 926, 927, 927, 982, 986, 988, 993, 993, 993, 997, 997, 997, 997, 997, 1082, 1086, 1086, 1090, 1090, 1094, 1094, 1098, 1098, 1102, 1102, 1106, 1106, 1110, 1114, 1114, 1115, 1117, 1117, 1117, 1117, 1118, 1123, 1123, 1127, 1127, 1127, 1131, 1132, 1133, 1134, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {90, 91, 96, 97, 111, 116, 117, 119, 122, 126, 129, 139, 144, 145, 146, 147, 149, 154, 155, 158, 160, 163, 167, 169, 175, 176, 177, 178, 179, 189, 190, 191, 192, 193, 194, 195, 199, 200, 216, 217, 222, 223, 224, 226, 227, 228, 229, 231, 232, 233, 234, 235, 236, 237, 239, 240, 241, 245, 248, 251, 255, 266, 267, 268, 275, 276, 278, 279, 280, 281, 288, 289, 290, 291, 292, 308, 309, 310, 312, 313, 314, 315, 316, 318, 319, 321, 322, 323, 324, 325, 327, 333, 334, 335, 336, 337, 347, 348, 353, 354, 357, 358, 360, 363, 367, 368, 370, 371, 382, 387, 388, 389, 391, 392, 393, 394, 399, 400, 401, 403, 404, 413, 418, 419, 422, 423, 428, 429, 432, 436, 437, 439, 440, 453, 454, 457, 459, 460, 461, 463, 466, 467, 469, 472, 476, 477, 479, 485, 486, 498, 499, 502, 504, 505, 506, 508, 509, 511, 514, 518, 521, 522, 523, 525, 536, 537, 538, 550, 551, 554, 556, 557, 558, 560, 561, 563, 566, 570, 573, 574, 575, 577, 588, 589, 590, 596, 597, 598, 599, 609, 610, 611, 612, 615, 617, 618, 624, 625, 626, 635, 636, 637, 638, 641, 643, 644, 645, 646, 647, 653, 654, 659, 660, 661, 666, 667, 668, 675, 676, 678, 680, 683, 687, 697, 699, 706, 707, 709, 711, 714, 718, 725, 727, 734, 735, 737, 739, 742, 746, 749, 758, 759, 761, 763, 766, 770, 773, 782, 783, 785, 786, 788, 789, 807, 808, 819, 820, 821, 822, 823, 824, 829, 830, 831, 832, 833, 835, 840, 841, 842, 884, 889, 890, 893, 898, 899, 902, 906, 909, 910, 912, 915, 919, 922, 924, 927, 931, 934, 935, 937, 940, 944, 947, 948, 950, 953, 957, 960, 961, 962, 964, 967, 971, 973, 974, 975, 976, 977, 978, 979, 980, 981, 983, 984, 985, 989, 991, 992, 994, 995, 997, 999, 1000, 1001, 1002, 1003, 1004, 1006, 1008, 1011, 1013, 1014, 1015, 1019, 1020, 1026, 1028, 1031, 1037, 1048, 1049, 1050, 1051, 1054, 1059, 1060, 1061, 1062, 1063, 1069, 1071, 1072, 1074, 1079, 1080, 1081, 1087, 1088, 1089, 1090, 1093, 1116, 1121, 1122, 1125, 1127, 1130, 1134, 1136, 1137, 1138, 1140, 1143, 1145, 1146, 1147, 1148, 1151, 1153, 1154, 1155, 1157, 1159, 1160, 1163, 1164, 1167, 1173, 1174, 1176, 1178, 1181, 1183, 1187, 1196, 1201, 1202, 1204, 1205, 1206, 1208, 1209, 1211, 1212, 1221, 1226, 1227, 1229, 1230, 1231, 1233, 1234, 1236, 1237, 1249, 1254, 1255, 1256, 1270, 1271, 1276, 1277, 1278, 1289, 1290, 1291, 1292, 1293, 1294, 1295, 1296, 1297, 1298, 1299, 1303, 1304, 1322, 1323, 1325, 1328, 1329, 1331, 1334, 1335, 1337, 1340, 1344, 1347, 1351, 1352, 1353, 1356, 1361, 1362, 1363, 1365, 1366, 1367, 1368, 1369, 1370, 1372, 1373, 1378, 1380, 1382, 1388, 1389, 1390, 1397, 1398, 1399, 1400, 1401, 1417, 1422, 1423, 1427, 1428, 1432, 1433, 1437, 1438, 1442, 1443, 1447, 1448, 1451, 1458, 1463, 1464, 1467, 1468, 1469, 1470, 1471, 1477, 1478, 1483, 1484, 1485, 1494, 1495, 1496, 1497, 1498, 1501, 1503, 1504, 1505, 1506, 1507, 1508, 1517, 1521, 1524, 1528, 1531, 1534, 1538, 1541};
/* BEGIN LINEINFO 
capacitySet 1 183 90
assign 1 193 91
new 0 193 91
assign 1 197 96
new 0 197 96
new 1 197 97
assign 1 211 111
def 1 211 116
assign 1 211 117
equals 1 211 117
assign 1 0 119
assign 1 0 122
assign 1 0 126
return 1 212 129
assign 1 263 139
def 1 263 144
assign 1 264 145
new 0 264 145
assign 1 264 146
new 1 264 146
throw 1 264 147
assign 1 266 149
undef 1 266 154
assign 1 0 155
assign 1 266 158
greater 1 266 158
assign 1 0 160
assign 1 0 163
assign 1 267 167
copy 0 267 167
assign 1 269 169
assign 1 273 175
new 0 273 175
new 1 273 176
assign 1 274 177
new 0 274 177
assign 1 275 178
new 0 275 178
setHex 2 275 179
assign 1 279 189
new 0 279 189
assign 1 279 190
getCode 2 279 190
assign 1 279 191
new 0 279 191
assign 1 279 192
new 0 279 192
assign 1 279 193
new 0 279 193
assign 1 279 194
toString 3 279 194
return 1 279 195
assign 1 283 199
hexNew 1 283 199
setCode 2 284 200
assign 1 288 216
toString 0 288 216
assign 1 289 217
undef 1 289 222
assign 1 290 223
new 0 290 223
assign 1 291 224
new 0 291 224
assign 1 293 226
sizeGet 0 293 226
setValue 1 293 227
addValue 1 294 228
assign 1 296 229
lesser 1 296 229
assign 1 297 231
new 0 297 231
assign 1 297 232
add 1 297 232
assign 1 297 233
new 0 297 233
assign 1 297 234
multiply 1 297 234
assign 1 297 235
new 0 297 235
assign 1 297 236
divide 1 297 236
capacitySet 1 298 237
assign 1 300 239
new 0 300 239
assign 1 300 240
sizeGet 0 300 240
copyValue 4 300 241
return 1 305 245
return 1 309 248
addValue 1 313 251
write 1 317 255
assign 1 328 266
copy 0 328 266
clear 0 329 267
return 1 330 268
assign 1 334 275
new 0 334 275
assign 1 334 276
greater 1 334 276
assign 1 335 278
new 0 335 278
assign 1 335 279
new 0 335 279
setIntUnchecked 2 335 280
assign 1 336 281
new 0 336 281
assign 1 341 288
new 0 341 288
new 1 341 289
assign 1 342 290
new 0 342 290
assign 1 343 291
new 0 343 291
setCodeUnchecked 2 343 292
assign 1 347 308
new 0 347 308
assign 1 347 309
newlineGet 0 347 309
assign 1 348 310
ends 1 348 310
assign 1 349 312
new 0 349 312
assign 1 349 313
sizeGet 0 349 313
assign 1 349 314
subtract 1 349 314
assign 1 349 315
substring 2 349 315
return 1 349 316
assign 1 351 318
new 0 351 318
assign 1 352 319
ends 1 352 319
assign 1 353 321
new 0 353 321
assign 1 353 322
sizeGet 0 353 322
assign 1 353 323
subtract 1 353 323
assign 1 353 324
substring 2 353 324
return 1 353 325
return 1 355 327
assign 1 359 333
new 0 359 333
assign 1 359 334
add 1 359 334
assign 1 359 335
new 1 359 335
addValue 1 360 336
return 1 361 337
assign 1 365 347
find 1 365 347
assign 1 366 348
undef 1 366 353
assign 1 0 354
assign 1 366 357
new 0 366 357
assign 1 366 358
notEquals 1 366 358
assign 1 0 360
assign 1 0 363
assign 1 367 367
new 0 367 367
return 1 367 368
assign 1 369 370
new 0 369 370
return 1 369 371
assign 1 373 382
undef 1 373 387
assign 1 373 388
new 0 373 388
return 1 373 389
assign 1 374 391
sizeGet 0 374 391
assign 1 374 392
subtract 1 374 392
assign 1 374 393
find 2 374 393
assign 1 375 394
undef 1 375 399
assign 1 376 400
new 0 376 400
return 1 376 401
assign 1 378 403
new 0 378 403
return 1 378 404
assign 1 382 413
undef 1 382 418
assign 1 0 419
assign 1 382 422
find 1 382 422
assign 1 382 423
undef 1 382 428
assign 1 0 429
assign 1 0 432
assign 1 383 436
new 0 383 436
return 1 383 437
assign 1 385 439
new 0 385 439
return 1 385 440
assign 1 389 453
new 0 389 453
assign 1 390 454
new 0 390 454
assign 1 390 457
lesser 1 390 457
getInt 2 391 459
assign 1 392 460
new 0 392 460
assign 1 392 461
greater 1 392 461
assign 1 0 463
assign 1 392 466
new 0 392 466
assign 1 392 467
lesser 1 392 467
assign 1 0 469
assign 1 0 472
assign 1 393 476
new 0 393 476
return 1 393 477
incrementValue 0 390 479
assign 1 396 485
new 0 396 485
return 1 396 486
assign 1 400 498
new 0 400 498
assign 1 401 499
new 0 401 499
assign 1 401 502
lesser 1 401 502
getInt 2 402 504
assign 1 403 505
new 0 403 505
assign 1 403 506
greater 1 403 506
assign 1 403 508
new 0 403 508
assign 1 403 509
lesser 1 403 509
assign 1 0 511
assign 1 0 514
assign 1 0 518
assign 1 404 521
new 0 404 521
addValue 1 404 522
setIntUnchecked 2 405 523
incrementValue 0 401 525
assign 1 411 536
copy 0 411 536
assign 1 411 537
lowerValue 0 411 537
return 1 411 538
assign 1 415 550
new 0 415 550
assign 1 416 551
new 0 416 551
assign 1 416 554
lesser 1 416 554
getInt 2 417 556
assign 1 418 557
new 0 418 557
assign 1 418 558
greater 1 418 558
assign 1 418 560
new 0 418 560
assign 1 418 561
lesser 1 418 561
assign 1 0 563
assign 1 0 566
assign 1 0 570
assign 1 419 573
new 0 419 573
subtractValue 1 419 574
setIntUnchecked 2 420 575
incrementValue 0 416 577
assign 1 426 588
copy 0 426 588
assign 1 426 589
upperValue 0 426 589
return 1 426 590
assign 1 430 596
new 0 430 596
assign 1 430 597
split 1 430 597
assign 1 430 598
join 2 430 598
return 1 430 599
assign 1 435 609
new 0 435 609
assign 1 435 610
new 1 435 610
assign 1 436 611
mbiterGet 0 436 611
assign 1 437 612
new 0 437 612
assign 1 437 615
lesser 1 437 615
next 1 438 617
assign 1 437 618
increment 0 437 618
assign 1 440 624
next 1 440 624
assign 1 440 625
toString 0 440 625
return 1 441 626
assign 1 445 635
new 0 445 635
assign 1 446 636
new 0 446 636
setValue 1 446 637
assign 1 447 638
new 0 447 638
assign 1 447 641
lesser 1 447 641
getInt 2 448 643
assign 1 449 644
new 0 449 644
multiplyValue 1 449 645
addValue 1 450 646
incrementValue 0 447 647
assign 1 452 653
absValue 0 452 653
return 1 452 654
assign 1 456 659
new 0 456 659
assign 1 456 660
hashValue 1 456 660
return 1 456 661
assign 1 460 666
new 0 460 666
assign 1 460 667
getCode 2 460 667
return 1 460 668
assign 1 470 675
new 0 470 675
assign 1 470 676
greaterEquals 1 470 676
assign 1 470 678
greater 1 470 678
assign 1 0 680
assign 1 0 683
assign 1 0 687
return 1 499 697
return 1 501 699
assign 1 512 706
new 0 512 706
assign 1 512 707
greaterEquals 1 512 707
assign 1 512 709
greater 1 512 709
assign 1 0 711
assign 1 0 714
assign 1 0 718
return 1 542 725
return 1 544 727
assign 1 548 734
new 0 548 734
assign 1 548 735
greaterEquals 1 548 735
assign 1 548 737
greater 1 548 737
assign 1 0 739
assign 1 0 742
assign 1 0 746
setIntUnchecked 2 549 749
assign 1 554 758
new 0 554 758
assign 1 554 759
greaterEquals 1 554 759
assign 1 554 761
greater 1 554 761
assign 1 0 763
assign 1 0 766
assign 1 0 770
setCodeUnchecked 2 555 773
assign 1 560 782
new 0 560 782
assign 1 560 783
lesserEquals 1 560 783
assign 1 561 785
new 0 561 785
return 1 561 786
assign 1 563 788
new 0 563 788
return 1 563 789
assign 1 646 807
rfind 1 646 807
return 1 646 808
assign 1 652 819
copy 0 652 819
assign 1 652 820
reverseBytes 0 652 820
assign 1 652 821
copy 0 652 821
assign 1 652 822
reverseBytes 0 652 822
assign 1 652 823
find 1 652 823
assign 1 654 824
def 1 654 829
assign 1 655 830
sizeGet 0 655 830
addValue 1 655 831
assign 1 656 832
subtract 1 656 832
return 1 656 833
return 1 658 835
assign 1 662 840
new 0 662 840
assign 1 662 841
find 2 662 841
return 1 662 842
assign 1 668 884
undef 1 668 889
assign 1 0 890
assign 1 668 893
undef 1 668 898
assign 1 0 899
assign 1 0 902
assign 1 0 906
assign 1 668 909
new 0 668 909
assign 1 668 910
lesser 1 668 910
assign 1 0 912
assign 1 0 915
assign 1 0 919
assign 1 668 922
greaterEquals 1 668 922
assign 1 0 924
assign 1 0 927
assign 1 0 931
assign 1 668 934
sizeGet 0 668 934
assign 1 668 935
greater 1 668 935
assign 1 0 937
assign 1 0 940
assign 1 0 944
assign 1 668 947
new 0 668 947
assign 1 668 948
equals 1 668 948
assign 1 0 950
assign 1 0 953
assign 1 0 957
assign 1 668 960
sizeGet 0 668 960
assign 1 668 961
new 0 668 961
assign 1 668 962
equals 1 668 962
assign 1 0 964
assign 1 0 967
return 1 669 971
assign 1 672 973
assign 1 673 974
copy 0 673 974
assign 1 674 975
new 0 674 975
assign 1 675 976
new 0 675 976
assign 1 676 977
new 0 676 977
getInt 2 676 978
assign 1 678 979
sizeGet 0 678 979
assign 1 680 980
new 0 680 980
assign 1 680 981
greater 1 680 981
assign 1 681 983
new 0 681 983
assign 1 682 984
new 0 682 984
assign 1 683 985
new 0 683 985
assign 1 686 989
lesser 1 686 989
getInt 2 687 991
assign 1 688 992
equals 1 688 992
assign 1 689 994
new 0 689 994
assign 1 689 995
equals 1 689 995
return 1 690 997
setValue 1 692 999
incrementValue 0 693 1000
setValue 1 694 1001
assign 1 695 1002
sizeGet 0 695 1002
addValue 1 695 1003
assign 1 696 1004
greater 1 696 1004
return 1 697 1006
assign 1 699 1008
new 0 699 1008
assign 1 700 1011
lesser 1 700 1011
getInt 2 701 1013
getInt 2 702 1014
assign 1 703 1015
notEquals 1 703 1015
incrementValue 0 706 1019
incrementValue 0 707 1020
assign 1 709 1026
equals 1 709 1026
return 1 710 1028
incrementValue 0 713 1031
return 1 715 1037
assign 1 719 1048
new 0 719 1048
assign 1 720 1049
new 0 720 1049
assign 1 721 1050
find 2 721 1050
assign 1 722 1051
sizeGet 0 722 1051
assign 1 723 1054
def 1 723 1059
assign 1 724 1060
substring 2 724 1060
addValue 1 724 1061
assign 1 725 1062
add 1 725 1062
assign 1 726 1063
find 2 726 1063
assign 1 728 1069
lesser 1 728 1069
assign 1 729 1071
substring 2 729 1071
addValue 1 729 1072
return 1 731 1074
assign 1 735 1079
new 0 735 1079
assign 1 735 1080
join 2 735 1080
return 1 735 1081
assign 1 739 1087
new 0 739 1087
assign 1 739 1088
lineSplitterGet 0 739 1088
assign 1 739 1089
tokenize 1 739 1089
return 1 739 1090
return 1 743 1093
assign 1 751 1116
undef 1 751 1121
assign 1 0 1122
assign 1 751 1125
otherType 1 751 1125
assign 1 0 1127
assign 1 0 1130
return 1 752 1134
assign 1 754 1136
assign 1 755 1137
sizeGet 0 755 1137
assign 1 756 1138
greater 1 756 1138
assign 1 757 1140
assign 1 759 1143
assign 1 761 1145
new 0 761 1145
assign 1 762 1146
new 0 762 1146
assign 1 763 1147
new 0 763 1147
assign 1 764 1148
new 0 764 1148
assign 1 764 1151
lesser 1 764 1151
getCode 2 765 1153
getCode 2 766 1154
assign 1 767 1155
notEquals 1 767 1155
assign 1 768 1157
greater 1 768 1157
assign 1 769 1159
new 0 769 1159
return 1 769 1160
assign 1 771 1163
new 0 771 1163
return 1 771 1164
incrementValue 0 764 1167
assign 1 775 1173
new 0 775 1173
assign 1 775 1174
equals 1 775 1174
assign 1 776 1176
greater 1 776 1176
assign 1 777 1178
new 0 777 1178
assign 1 778 1181
greater 1 778 1181
assign 1 779 1183
new 0 779 1183
return 1 782 1187
assign 1 786 1196
undef 1 786 1201
return 1 786 1202
assign 1 787 1204
compare 1 787 1204
assign 1 787 1205
new 0 787 1205
assign 1 787 1206
equals 1 787 1206
assign 1 788 1208
new 0 788 1208
return 1 788 1209
assign 1 790 1211
new 0 790 1211
return 1 790 1212
assign 1 794 1221
undef 1 794 1226
return 1 794 1227
assign 1 795 1229
compare 1 795 1229
assign 1 795 1230
new 0 795 1230
assign 1 795 1231
equals 1 795 1231
assign 1 796 1233
new 0 796 1233
return 1 796 1234
assign 1 798 1236
new 0 798 1236
return 1 798 1237
assign 1 809 1249
undef 1 809 1254
assign 1 810 1255
new 0 810 1255
return 1 810 1256
assign 1 869 1270
new 0 869 1270
return 1 869 1271
assign 1 874 1276
equals 1 874 1276
assign 1 874 1277
not 0 874 1277
return 1 874 1278
assign 1 878 1289
toString 0 878 1289
assign 1 879 1290
sizeGet 0 879 1290
assign 1 879 1291
add 1 879 1291
assign 1 879 1292
new 1 879 1292
assign 1 880 1293
new 0 880 1293
assign 1 880 1294
new 0 880 1294
copyValue 4 880 1295
assign 1 881 1296
new 0 881 1296
assign 1 881 1297
sizeGet 0 881 1297
copyValue 4 881 1298
return 1 882 1299
assign 1 885 1303
new 0 885 1303
return 1 885 1304
assign 1 910 1322
new 0 910 1322
assign 1 910 1323
lesser 1 910 1323
assign 1 0 1325
assign 1 910 1328
sizeGet 0 910 1328
assign 1 910 1329
greater 1 910 1329
assign 1 0 1331
assign 1 910 1334
sizeGet 0 910 1334
assign 1 910 1335
greater 1 910 1335
assign 1 0 1337
assign 1 0 1340
assign 1 0 1344
assign 1 0 1347
assign 1 911 1351
new 0 911 1351
assign 1 911 1352
new 1 911 1352
throw 1 911 1353
assign 1 915 1356
undef 1 915 1361
assign 1 916 1362
new 0 916 1362
assign 1 917 1363
new 0 917 1363
setValue 1 919 1365
subtractValue 1 920 1366
assign 1 921 1367
setValue 1 923 1368
addValue 1 924 1369
assign 1 926 1370
greater 1 926 1370
assign 1 927 1372
copy 0 927 1372
capacitySet 1 927 1373
assign 1 982 1378
greater 1 982 1378
assign 1 986 1380
copy 0 986 1380
return 1 988 1382
assign 1 993 1388
sizeGet 0 993 1388
assign 1 993 1389
substring 2 993 1389
return 1 993 1390
assign 1 997 1397
subtract 1 997 1397
assign 1 997 1398
new 1 997 1398
assign 1 997 1399
new 0 997 1399
assign 1 997 1400
copyValue 4 997 1400
return 1 997 1401
output 0 1082 1417
assign 1 1086 1422
new 1 1086 1422
return 1 1086 1423
assign 1 1090 1427
new 1 1090 1427
return 1 1090 1428
assign 1 1094 1432
new 1 1094 1432
return 1 1094 1433
assign 1 1098 1437
new 1 1098 1437
return 1 1098 1438
assign 1 1102 1442
new 1 1102 1442
return 1 1102 1443
assign 1 1106 1447
new 1 1106 1447
return 1 1106 1448
return 1 1110 1451
assign 1 1114 1458
undef 1 1114 1463
new 0 1115 1464
assign 1 1117 1467
sizeGet 0 1117 1467
assign 1 1117 1468
new 0 1117 1468
assign 1 1117 1469
add 1 1117 1469
new 1 1117 1470
addValue 1 1118 1471
assign 1 1123 1477
new 0 1123 1477
return 1 1123 1478
assign 1 1127 1483
new 0 1127 1483
assign 1 1127 1484
strip 1 1127 1484
return 1 1127 1485
assign 1 1131 1494
new 0 1131 1494
assign 1 1132 1495
new 0 1132 1495
assign 1 1133 1496
new 0 1133 1496
assign 1 1134 1497
new 0 1134 1497
assign 1 1134 1498
subtract 1 1134 1498
assign 1 1135 1501
greater 1 1135 1501
getInt 2 1136 1503
getInt 2 1137 1504
setInt 2 1138 1505
setInt 2 1139 1506
incrementValue 0 1140 1507
decrementValue 0 1141 1508
assign 1 0 1517
return 1 0 1521
assign 1 0 1524
return 1 0 1528
return 1 0 1531
assign 1 0 1534
return 1 0 1538
assign 1 0 1541
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case 1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case 855090856: return bem_multiByteIteratorGet_0();
case 1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 416660294: return bem_objectIteratorGet_0();
case 195899181: return bem_biterGet_0();
case 1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1607888168: return bem_stringIteratorGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case 729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case 1881757495: return bem_strip_0();
case 139115914: return bem_splitLines_0();
case 1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case 800915430: return bem_reverseBytes_0();
case 1354714650: return bem_copy_0();
case 85457677: return bem_leniGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 599761551: return bem_siziSet_1(bevd_0);
case 1274448085: return bem_find_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1143153819: return bem_codeNew_1(bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_4_3_MathInt) bevd_0);
case 1954998871: return bem_getHex_1((BEC_4_3_MathInt) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1406325780: return bem_writeTo_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2001811380: return bem_split_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_4_6_TextString) bevd_0);
case 636254476: return bem_getPoint_1((BEC_4_3_MathInt) bevd_0);
case 1958502700: return bem_greater_1((BEC_4_6_TextString) bevd_0);
case 1250088509: return bem_substring_1((BEC_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_4_6_TextString) bevd_0);
case 74375424: return bem_leniSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 1298743126: return bem_ends_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 340923733: return bem_getCode_1((BEC_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 825000909: return bem_vstringSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1412717737: return bem_compare_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 477101321: return bem_hexNew_1((BEC_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1395074208: return bem_setInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1154529699: return bem_join_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 889715578: return bem_swap_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1393886412: return bem_setHex_2((BEC_4_3_MathInt) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 761715532: return bem_setIntUnchecked_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1250088508: return bem_substring_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1274448084: return bem_find_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 340923734: return bem_getCode_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1956186668: return bem_getInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) {
switch (callHash) {
case 391213135: return bem_copyValue_4((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_4_6_TextString();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_4_6_TextString.bevs_inst = (BEC_4_6_TextString)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_4_6_TextString.bevs_inst;
}
}
}
