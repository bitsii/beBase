namespace be.BEL_4_Base {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator : BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
static BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 1));
private static byte[] bels_1 = {0x3C};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 1));
private static byte[] bels_2 = {0x3C};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x3C};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x3E};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 1));
private static byte[] bels_5 = {0x3E};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 1));
private static byte[] bels_6 = {0x3E};
private static byte[] bels_7 = {0x3C};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_7, 1));
private static byte[] bels_8 = {0x3E};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 1));
private static byte[] bels_9 = {0x3E};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 1));
private static byte[] bels_10 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x3C};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 1));
private static byte[] bels_12 = {0x3E};
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x3F};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 1));
private static byte[] bels_15 = {0x3C,0x3F};
private static byte[] bels_16 = {0x21};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 1));
private static byte[] bels_17 = {0x3C,0x21};
private static byte[] bels_18 = {0x2F};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 1));
private static byte[] bels_19 = {0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_19, 1));
private static byte[] bels_20 = {0x3E};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_20, 1));
private static byte[] bels_21 = {0x2F};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_21, 1));
private static byte[] bels_22 = {0x3E};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_22, 1));
private static byte[] bels_23 = {0x2F};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_23, 1));
private static byte[] bels_24 = {0x20};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_24, 1));
private static byte[] bels_25 = {0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_25, 1));
private static byte[] bels_26 = {0x3E};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_26, 1));
private static byte[] bels_27 = {0x2F};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_27, 1));
private static byte[] bels_28 = {0x3D};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_28, 1));
private static byte[] bels_29 = {0x3E};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_29, 1));
private static byte[] bels_30 = {0x2F};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_30, 1));
private static byte[] bels_31 = {0x20};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_31, 1));
private static byte[] bels_32 = {0x3D};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_32, 1));
private static byte[] bels_33 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_33, 51));
private static byte[] bels_34 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_34, 51));
private static byte[] bels_35 = {0x20};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_35, 1));
private static byte[] bels_36 = {0x3C};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_36, 1));
private static byte[] bels_37 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_38 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_38, 35));
private static byte[] bels_39 = {0x3A};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_39, 1));
public static new BEC_2_3_11_XmlTagIterator bevs_inst;
public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_started = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_skip = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_debug = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) {
this.bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_restart_0() {
this.bem_new_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_start_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpvar_phold.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 171 */ {
if (bevl_nxt == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_5_tmpvar_phold = bevo_0;
bevt_4_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
 else  /* Line: 171 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 171 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 172 */
 else  /* Line: 171 */ {
break;
} /* Line: 171 */
} /* Line: 171 */
if (bevl_nxt == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_8_tmpvar_phold = bevo_1;
bevt_7_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 174 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 174 */
 else  /* Line: 174 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 174 */ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 175 */
return this;
} /*method end*/
public virtual BEC_2_3_3_XmlTag bem_nextGet_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_21_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_3_8_XmlTextNode bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_3_7_XmlComment bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_106_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_116_tmpvar_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpvar_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_137_tmpvar_phold = null;
if (bevp_started.bevi_bool) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 180 */ {
this.bem_start_0();
} /* Line: 181 */
bevt_21_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_q = bevt_21_tmpvar_phold.bem_quoteGet_0();
bevt_22_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_nl = bevt_22_tmpvar_phold.bem_newlineGet_0();
if (bevp_skip.bevi_bool) /* Line: 186 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1446310798, BEL_4_Base.bevn_currentGet_0);
bevp_skip = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 188 */
 else  /* Line: 189 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 190 */
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 193 */ {
if (bevp_textNode.bevi_bool) /* Line: 193 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 193 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 193 */
 else  /* Line: 193 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 193 */ {
while (true)
 /* Line: 194 */ {
bevt_25_tmpvar_phold = bevo_2;
bevt_24_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_25_tmpvar_phold);
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 196 */
 else  /* Line: 194 */ {
break;
} /* Line: 194 */
} /* Line: 194 */
bevp_textNode = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_skip = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_27_tmpvar_phold = bevl_accum.bem_extractString_0();
bevt_26_tmpvar_phold = (BEC_2_3_8_XmlTextNode) (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_tmpvar_phold);
return bevt_26_tmpvar_phold;
} /* Line: 200 */
 else  /* Line: 193 */ {
if (bevl_nxt == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevt_30_tmpvar_phold = bevo_3;
bevt_29_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_30_tmpvar_phold);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevl_tagName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isStart = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
while (true)
 /* Line: 209 */ {
bevt_32_tmpvar_phold = bevo_4;
bevt_31_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_32_tmpvar_phold);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 209 */ {
if (bevl_pinstruct.bevi_bool) /* Line: 210 */ {
bevl_instr = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
while (true)
 /* Line: 212 */ {
if (bevl_instr.bevi_bool) /* Line: 212 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 212 */ {
bevt_34_tmpvar_phold = bevo_5;
bevt_33_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_34_tmpvar_phold);
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 212 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 212 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 212 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 214 */ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BELS_Base.BECS_Runtime.boolTrue;
}
} /* Line: 215 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 217 */
 else  /* Line: 212 */ {
break;
} /* Line: 212 */
} /* Line: 212 */
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevl_accum.bem_addValue_1(bevt_36_tmpvar_phold);
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
while (true)
 /* Line: 221 */ {
if (bevl_nxt == null) {
bevt_37_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_37_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevt_39_tmpvar_phold = bevo_6;
bevt_38_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_39_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
 else  /* Line: 221 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 221 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 222 */
 else  /* Line: 221 */ {
break;
} /* Line: 221 */
} /* Line: 221 */
bevp_skip = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_41_tmpvar_phold = bevl_accum.bem_toString_0();
bevt_40_tmpvar_phold = (BEC_2_3_21_XmlProcessingInstruction) (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_tmpvar_phold);
return bevt_40_tmpvar_phold;
} /* Line: 225 */
if (bevl_comment.bevi_bool) /* Line: 227 */ {
while (true)
 /* Line: 228 */ {
bevt_43_tmpvar_phold = bevo_7;
bevt_42_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_43_tmpvar_phold);
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_45_tmpvar_phold = bevo_8;
bevt_44_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 231 */ {
bevt_48_tmpvar_phold = bevl_accum.bem_toString_0();
bevt_49_tmpvar_phold = bevo_9;
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_ends_1(bevt_49_tmpvar_phold);
if (bevt_47_tmpvar_phold.bevi_bool) {
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 231 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 231 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 231 */
 else  /* Line: 231 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 231 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 233 */
} /* Line: 231 */
 else  /* Line: 228 */ {
break;
} /* Line: 228 */
} /* Line: 228 */
bevl_comment = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
while (true)
 /* Line: 237 */ {
if (bevl_nxt == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_52_tmpvar_phold = bevo_10;
bevt_51_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_52_tmpvar_phold);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 237 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 238 */
 else  /* Line: 237 */ {
break;
} /* Line: 237 */
} /* Line: 237 */
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_12));
bevl_accum.bem_addValue_1(bevt_53_tmpvar_phold);
bevp_skip = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_55_tmpvar_phold = bevl_accum.bem_extractString_0();
bevt_54_tmpvar_phold = (BEC_2_3_7_XmlComment) (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_tmpvar_phold);
return bevt_54_tmpvar_phold;
} /* Line: 242 */
if (bevl_tagName.bevi_bool) /* Line: 244 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 246 */ {
bevt_57_tmpvar_phold = bevo_11;
bevt_56_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_57_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 246 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 246 */ {
bevt_58_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 246 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 246 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 246 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 246 */ {
bevt_59_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 247 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 248 */
 else  /* Line: 246 */ {
break;
} /* Line: 246 */
} /* Line: 246 */
bevt_61_tmpvar_phold = bevo_12;
bevt_60_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_61_tmpvar_phold);
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 250 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_accum.bem_extractString_0();
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_15));
bevl_accum.bem_addValue_1(bevt_62_tmpvar_phold);
} /* Line: 255 */
 else  /* Line: 250 */ {
bevt_64_tmpvar_phold = bevo_13;
bevt_63_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_64_tmpvar_phold);
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 256 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_accum.bem_extractString_0();
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_17));
bevl_accum.bem_addValue_1(bevt_65_tmpvar_phold);
} /* Line: 261 */
 else  /* Line: 262 */ {
bevt_67_tmpvar_phold = bevo_14;
bevt_66_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_67_tmpvar_phold);
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 265 */
while (true)
 /* Line: 267 */ {
bevt_69_tmpvar_phold = bevo_15;
bevt_68_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_69_tmpvar_phold);
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 267 */ {
bevt_70_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 267 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 267 */
 else  /* Line: 267 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 267 */ {
bevt_72_tmpvar_phold = bevo_16;
bevt_71_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_72_tmpvar_phold);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 267 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 267 */
 else  /* Line: 267 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 267 */ {
bevt_74_tmpvar_phold = bevo_17;
bevt_73_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_74_tmpvar_phold);
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 267 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 267 */
 else  /* Line: 267 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 267 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 269 */
 else  /* Line: 267 */ {
break;
} /* Line: 267 */
} /* Line: 267 */
bevt_75_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 271 */
bevl_tagName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 273 */ {
bevl_myElement = (BEC_2_3_12_XmlStartElement) (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_tmpvar_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_tmpvar_phold);
} /* Line: 276 */
 else  /* Line: 277 */ {
bevl_myEndElement = (BEC_2_3_10_XmlEndElement) (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_tmpvar_phold = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_tmpvar_phold);
bevl_myTag = bevl_myEndElement;
} /* Line: 280 */
bevt_79_tmpvar_phold = bevo_18;
bevt_78_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_79_tmpvar_phold);
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 284 */ {
bevp_textNode = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 285 */
} /* Line: 284 */
 else  /* Line: 282 */ {
bevt_81_tmpvar_phold = bevo_19;
bevt_80_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_81_tmpvar_phold);
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 287 */ {
if (bevl_isStart.bevi_bool) /* Line: 287 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 287 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_82_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_tmpvar_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 290 */
 else  /* Line: 282 */ {
if (bevl_isStart.bevi_bool) /* Line: 291 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 292 */
 else  /* Line: 293 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 294 */
} /* Line: 282 */
} /* Line: 282 */
} /* Line: 282 */
} /* Line: 250 */
} /* Line: 250 */
if (bevl_attributeName.bevi_bool) /* Line: 298 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 300 */ {
bevt_84_tmpvar_phold = bevo_20;
bevt_83_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_84_tmpvar_phold);
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_85_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 300 */ {
bevt_86_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 301 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 301 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 302 */
 else  /* Line: 300 */ {
break;
} /* Line: 300 */
} /* Line: 300 */
while (true)
 /* Line: 304 */ {
bevt_88_tmpvar_phold = bevo_21;
bevt_87_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_88_tmpvar_phold);
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_89_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
 else  /* Line: 304 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 304 */ {
bevt_91_tmpvar_phold = bevo_22;
bevt_90_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_91_tmpvar_phold);
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
 else  /* Line: 304 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 304 */ {
bevt_93_tmpvar_phold = bevo_23;
bevt_92_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_93_tmpvar_phold);
if (bevt_92_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
 else  /* Line: 304 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 304 */ {
bevt_95_tmpvar_phold = bevo_24;
bevt_94_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevt_95_tmpvar_phold);
if (bevt_94_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
 else  /* Line: 304 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 304 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 306 */
 else  /* Line: 304 */ {
break;
} /* Line: 304 */
} /* Line: 304 */
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_96_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 309 */
bevt_98_tmpvar_phold = bevo_25;
bevt_97_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_98_tmpvar_phold);
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 310 */ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 312 */
 else  /* Line: 310 */ {
bevt_100_tmpvar_phold = bevo_26;
bevt_99_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_100_tmpvar_phold);
if (bevt_99_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_101_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_tmpvar_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 316 */
 else  /* Line: 317 */ {
bevt_102_tmpvar_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_tmpvar_phold);
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 319 */
} /* Line: 310 */
} /* Line: 310 */
if (bevl_attributeValue.bevi_bool) /* Line: 322 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 324 */ {
bevt_104_tmpvar_phold = bevo_27;
bevt_103_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_104_tmpvar_phold);
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 324 */ {
bevt_105_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 324 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 324 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 324 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 324 */ {
bevt_107_tmpvar_phold = bevo_28;
bevt_106_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_107_tmpvar_phold);
if (bevt_106_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 324 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 324 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 324 */ {
bevt_108_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 326 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 326 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 327 */
 else  /* Line: 324 */ {
break;
} /* Line: 324 */
} /* Line: 324 */
bevt_109_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 329 */ {
bevt_112_tmpvar_phold = bevo_29;
bevt_113_tmpvar_phold = bevp_line.bem_toString_0();
bevt_111_tmpvar_phold = bevt_112_tmpvar_phold.bem_add_1(bevt_113_tmpvar_phold);
bevt_110_tmpvar_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_110_tmpvar_phold);
} /* Line: 330 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 333 */ {
bevt_114_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_tmpvar_phold.bevi_bool) /* Line: 333 */ {
bevt_115_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_tmpvar_phold.bevi_bool) /* Line: 334 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 334 */
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 336 */
 else  /* Line: 333 */ {
break;
} /* Line: 333 */
} /* Line: 333 */
bevt_116_tmpvar_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_tmpvar_phold.bevi_bool) /* Line: 338 */ {
bevt_119_tmpvar_phold = bevo_30;
bevt_120_tmpvar_phold = bevp_line.bem_toString_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_add_1(bevt_120_tmpvar_phold);
bevt_117_tmpvar_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_117_tmpvar_phold);
} /* Line: 339 */
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_121_tmpvar_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_tmpvar_phold);
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 343 */
} /* Line: 322 */
 else  /* Line: 209 */ {
break;
} /* Line: 209 */
} /* Line: 209 */
if (bevl_myEndElement == null) {
bevt_122_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_122_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_122_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
if (bevl_myElement == null) {
bevt_123_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevt_124_tmpvar_phold = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 346 */
 else  /* Line: 346 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 346 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 346 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 346 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 348 */ {
if (bevl_nxt == null) {
bevt_125_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_125_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_125_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevt_127_tmpvar_phold = bevo_31;
bevt_126_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_127_tmpvar_phold);
if (bevt_126_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 348 */ {
bevt_128_tmpvar_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 348 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 348 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 348 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 348 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 348 */
 else  /* Line: 348 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 348 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 348 */
 else  /* Line: 348 */ {
break;
} /* Line: 348 */
} /* Line: 348 */
if (bevl_nxt == null) {
bevt_129_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_129_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_129_tmpvar_phold.bevi_bool) /* Line: 349 */ {
bevt_131_tmpvar_phold = bevo_32;
bevt_130_tmpvar_phold = bevl_nxt.bem_equals_1(bevt_131_tmpvar_phold);
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 349 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 349 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 349 */
 else  /* Line: 349 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_19_tmpvar_anchor.bevi_bool) /* Line: 349 */ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 349 */
} /* Line: 349 */
} /* Line: 346 */
 else  /* Line: 351 */ {
if (bevl_nxt == null) {
bevt_132_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevl_nxt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_37));
} /* Line: 352 */
bevt_136_tmpvar_phold = bevo_33;
bevt_135_tmpvar_phold = bevt_136_tmpvar_phold.bem_add_1(bevl_nxt);
bevt_137_tmpvar_phold = bevo_34;
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bem_add_1(bevt_137_tmpvar_phold);
bevt_133_tmpvar_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_133_tmpvar_phold);
} /* Line: 353 */
} /* Line: 202 */
} /* Line: 193 */
return bevl_myTag;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_started.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 360 */ {
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_1_tmpvar_phold;
} /* Line: 360 */
bevt_2_tmpvar_phold = bevp_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
return (BEC_2_5_4_LogicBool) bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_xmlStringGet_0() {
return bevp_xmlString;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_startedGet_0() {
return bevp_started;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_3_10_XmlXTokenizer bem_xtGet_0() {
return bevp_xt;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_resGet_0() {
return bevp_res;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iterGet_0() {
return bevp_iter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_iter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_textNodeGet_0() {
return bevp_textNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lineGet_0() {
return bevp_line;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_skipGet_0() {
return bevp_skip;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {141, 142, 143, 144, 145, 146, 147, 148, 153, 154, 158, 162, 166, 166, 167, 168, 170, 171, 171, 171, 171, 0, 0, 0, 172, 174, 174, 174, 174, 0, 0, 0, 175, 180, 180, 181, 184, 184, 185, 185, 187, 188, 190, 192, 193, 193, 0, 0, 0, 194, 194, 195, 196, 198, 199, 200, 200, 200, 201, 201, 202, 202, 203, 204, 205, 206, 207, 208, 209, 209, 211, 0, 212, 212, 0, 0, 213, 214, 215, 215, 217, 219, 219, 220, 221, 221, 221, 221, 0, 0, 0, 222, 224, 225, 225, 225, 228, 228, 229, 230, 231, 231, 231, 231, 231, 231, 231, 0, 0, 0, 232, 233, 236, 237, 237, 237, 237, 0, 0, 0, 238, 240, 240, 241, 242, 242, 242, 245, 246, 246, 0, 246, 0, 0, 247, 247, 248, 250, 250, 251, 252, 253, 254, 255, 255, 256, 256, 257, 258, 259, 260, 261, 261, 263, 263, 264, 265, 267, 267, 267, 0, 0, 0, 267, 267, 0, 0, 0, 267, 267, 0, 0, 0, 268, 269, 271, 271, 272, 274, 275, 276, 276, 278, 279, 279, 280, 282, 282, 283, 285, 287, 287, 0, 0, 0, 288, 289, 289, 290, 292, 294, 299, 300, 300, 0, 300, 0, 0, 301, 301, 302, 304, 304, 304, 0, 0, 0, 304, 304, 0, 0, 0, 304, 304, 0, 0, 0, 304, 304, 0, 0, 0, 305, 306, 308, 309, 309, 310, 310, 311, 312, 313, 313, 314, 315, 315, 316, 318, 318, 319, 323, 324, 324, 0, 324, 0, 0, 0, 324, 324, 0, 0, 326, 326, 327, 329, 330, 330, 330, 330, 330, 332, 333, 334, 334, 335, 336, 338, 339, 339, 339, 339, 339, 341, 342, 342, 343, 346, 346, 0, 346, 346, 346, 0, 0, 0, 0, 0, 347, 348, 348, 348, 348, 0, 348, 0, 0, 0, 0, 0, 348, 349, 349, 349, 349, 0, 0, 0, 349, 352, 352, 352, 353, 353, 353, 353, 353, 353, 356, 360, 360, 360, 360, 361, 361, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {94, 95, 96, 97, 98, 99, 100, 101, 105, 106, 110, 114, 127, 128, 129, 130, 131, 134, 139, 140, 141, 143, 146, 150, 153, 159, 164, 165, 166, 168, 171, 175, 178, 335, 340, 341, 343, 344, 345, 346, 348, 349, 352, 354, 355, 360, 362, 365, 369, 374, 375, 377, 378, 384, 385, 386, 387, 388, 391, 396, 397, 398, 400, 401, 402, 403, 404, 405, 408, 409, 412, 416, 419, 420, 422, 425, 429, 430, 432, 437, 438, 444, 445, 446, 449, 454, 455, 456, 458, 461, 465, 468, 474, 475, 476, 477, 482, 483, 485, 486, 487, 488, 490, 491, 492, 493, 498, 499, 502, 506, 509, 510, 517, 520, 525, 526, 527, 529, 532, 536, 539, 545, 546, 547, 548, 549, 550, 553, 556, 557, 559, 562, 564, 567, 571, 573, 575, 581, 582, 584, 585, 586, 587, 588, 589, 592, 593, 595, 596, 597, 598, 599, 600, 603, 604, 606, 607, 611, 612, 614, 616, 619, 623, 626, 627, 629, 632, 636, 639, 640, 642, 645, 649, 652, 653, 659, 661, 663, 665, 666, 667, 668, 671, 672, 673, 674, 676, 677, 679, 681, 685, 686, 689, 692, 696, 699, 700, 701, 702, 706, 709, 717, 720, 721, 723, 726, 728, 731, 735, 737, 739, 747, 748, 750, 752, 755, 759, 762, 763, 765, 768, 772, 775, 776, 778, 781, 785, 788, 789, 791, 794, 798, 801, 802, 808, 809, 811, 813, 814, 816, 817, 820, 821, 823, 824, 825, 826, 829, 830, 831, 836, 839, 840, 842, 845, 847, 850, 854, 857, 858, 860, 863, 867, 869, 871, 877, 879, 880, 881, 882, 883, 885, 888, 890, 892, 894, 895, 901, 903, 904, 905, 906, 907, 909, 910, 911, 912, 919, 924, 925, 928, 933, 934, 936, 939, 943, 946, 949, 953, 956, 961, 962, 963, 965, 968, 970, 973, 977, 980, 984, 987, 993, 998, 999, 1000, 1002, 1005, 1009, 1012, 1017, 1022, 1023, 1025, 1026, 1027, 1028, 1029, 1030, 1034, 1040, 1045, 1046, 1047, 1049, 1050, 1053, 1056, 1060, 1063, 1067, 1070, 1074, 1077, 1081, 1084, 1088, 1091, 1095, 1098, 1102, 1105, 1109, 1112};
/* BEGIN LINEINFO 
assign 1 141 94
new 0 141 94
assign 1 142 95
new 0 142 95
assign 1 143 96
assign 1 144 97
assign 1 145 98
new 0 145 98
assign 1 146 99
new 0 146 99
assign 1 147 100
new 0 147 100
assign 1 148 101
new 0 148 101
new 0 153 105
assign 1 154 106
new 0 158 110
return 1 162 114
assign 1 166 127
tokGet 0 166 127
assign 1 166 128
tokenize 1 166 128
assign 1 167 129
iteratorGet 0 167 129
assign 1 168 130
new 0 168 130
assign 1 170 131
nextGet 0 170 131
assign 1 171 134
def 1 171 139
assign 1 171 140
new 0 171 140
assign 1 171 141
notEquals 1 171 141
assign 1 0 143
assign 1 0 146
assign 1 0 150
assign 1 172 153
nextGet 0 172 153
assign 1 174 159
def 1 174 164
assign 1 174 165
new 0 174 165
assign 1 174 166
equals 1 174 166
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 175 178
new 0 175 178
assign 1 180 335
not 0 180 340
start 0 181 341
assign 1 184 343
new 0 184 343
assign 1 184 344
quoteGet 0 184 344
assign 1 185 345
new 0 185 345
assign 1 185 346
newlineGet 0 185 346
assign 1 187 348
currentGet 0 187 348
assign 1 188 349
new 0 188 349
assign 1 190 352
nextGet 0 190 352
assign 1 192 354
new 0 192 354
assign 1 193 355
def 1 193 360
assign 1 0 362
assign 1 0 365
assign 1 0 369
assign 1 194 374
new 0 194 374
assign 1 194 375
notEquals 1 194 375
addValue 1 195 377
assign 1 196 378
nextGet 0 196 378
assign 1 198 384
new 0 198 384
assign 1 199 385
new 0 199 385
assign 1 200 386
extractString 0 200 386
assign 1 200 387
new 1 200 387
return 1 200 388
assign 1 201 391
def 1 201 396
assign 1 202 397
new 0 202 397
assign 1 202 398
equals 1 202 398
assign 1 203 400
new 0 203 400
assign 1 204 401
new 0 204 401
assign 1 205 402
new 0 205 402
assign 1 206 403
new 0 206 403
assign 1 207 404
new 0 207 404
assign 1 208 405
new 0 208 405
assign 1 209 408
new 0 209 408
assign 1 209 409
notEquals 1 209 409
assign 1 211 412
new 0 211 412
assign 1 0 416
assign 1 212 419
new 0 212 419
assign 1 212 420
notEquals 1 212 420
assign 1 0 422
assign 1 0 425
addValue 1 213 429
assign 1 214 430
equals 1 214 430
assign 1 215 432
not 0 215 437
assign 1 217 438
nextGet 0 217 438
assign 1 219 444
new 0 219 444
addValue 1 219 445
assign 1 220 446
new 0 220 446
assign 1 221 449
def 1 221 454
assign 1 221 455
new 0 221 455
assign 1 221 456
notEquals 1 221 456
assign 1 0 458
assign 1 0 461
assign 1 0 465
assign 1 222 468
nextGet 0 222 468
assign 1 224 474
new 0 224 474
assign 1 225 475
toString 0 225 475
assign 1 225 476
new 1 225 476
return 1 225 477
assign 1 228 482
new 0 228 482
assign 1 228 483
notEquals 1 228 483
addValue 1 229 485
assign 1 230 486
nextGet 0 230 486
assign 1 231 487
new 0 231 487
assign 1 231 488
equals 1 231 488
assign 1 231 490
toString 0 231 490
assign 1 231 491
new 0 231 491
assign 1 231 492
ends 1 231 492
assign 1 231 493
not 0 231 498
assign 1 0 499
assign 1 0 502
assign 1 0 506
addValue 1 232 509
assign 1 233 510
nextGet 0 233 510
assign 1 236 517
new 0 236 517
assign 1 237 520
def 1 237 525
assign 1 237 526
new 0 237 526
assign 1 237 527
notEquals 1 237 527
assign 1 0 529
assign 1 0 532
assign 1 0 536
assign 1 238 539
nextGet 0 238 539
assign 1 240 545
new 0 240 545
addValue 1 240 546
assign 1 241 547
new 0 241 547
assign 1 242 548
extractString 0 242 548
assign 1 242 549
new 1 242 549
return 1 242 550
assign 1 245 553
nextGet 0 245 553
assign 1 246 556
new 0 246 556
assign 1 246 557
equals 1 246 557
assign 1 0 559
assign 1 246 562
equals 1 246 562
assign 1 0 564
assign 1 0 567
assign 1 247 571
equals 1 247 571
assign 1 247 573
increment 0 247 573
assign 1 248 575
nextGet 0 248 575
assign 1 250 581
new 0 250 581
assign 1 250 582
equals 1 250 582
assign 1 251 584
new 0 251 584
assign 1 252 585
new 0 252 585
assign 1 253 586
nextGet 0 253 586
extractString 0 254 587
assign 1 255 588
new 0 255 588
addValue 1 255 589
assign 1 256 592
new 0 256 592
assign 1 256 593
equals 1 256 593
assign 1 257 595
new 0 257 595
assign 1 258 596
new 0 258 596
assign 1 259 597
nextGet 0 259 597
extractString 0 260 598
assign 1 261 599
new 0 261 599
addValue 1 261 600
assign 1 263 603
new 0 263 603
assign 1 263 604
equals 1 263 604
assign 1 264 606
new 0 264 606
assign 1 265 607
nextGet 0 265 607
assign 1 267 611
new 0 267 611
assign 1 267 612
notEquals 1 267 612
assign 1 267 614
notEquals 1 267 614
assign 1 0 616
assign 1 0 619
assign 1 0 623
assign 1 267 626
new 0 267 626
assign 1 267 627
notEquals 1 267 627
assign 1 0 629
assign 1 0 632
assign 1 0 636
assign 1 267 639
new 0 267 639
assign 1 267 640
notEquals 1 267 640
assign 1 0 642
assign 1 0 645
assign 1 0 649
addValue 1 268 652
assign 1 269 653
nextGet 0 269 653
assign 1 271 659
equals 1 271 659
assign 1 271 661
increment 0 271 661
assign 1 272 663
new 0 272 663
assign 1 274 665
new 0 274 665
assign 1 275 666
assign 1 276 667
extractString 0 276 667
nameSet 1 276 668
assign 1 278 671
new 0 278 671
assign 1 279 672
extractString 0 279 672
nameSet 1 279 673
assign 1 280 674
assign 1 282 676
new 0 282 676
assign 1 282 677
equals 1 282 677
assign 1 283 679
new 0 283 679
assign 1 285 681
new 0 285 681
assign 1 287 685
new 0 287 685
assign 1 287 686
equals 1 287 686
assign 1 0 689
assign 1 0 692
assign 1 0 696
assign 1 288 699
new 0 288 699
assign 1 289 700
new 0 289 700
isClosedSet 1 289 701
assign 1 290 702
nextGet 0 290 702
assign 1 292 706
new 0 292 706
assign 1 294 709
new 0 294 709
assign 1 299 717
nextGet 0 299 717
assign 1 300 720
new 0 300 720
assign 1 300 721
equals 1 300 721
assign 1 0 723
assign 1 300 726
equals 1 300 726
assign 1 0 728
assign 1 0 731
assign 1 301 735
equals 1 301 735
assign 1 301 737
increment 0 301 737
assign 1 302 739
nextGet 0 302 739
assign 1 304 747
new 0 304 747
assign 1 304 748
notEquals 1 304 748
assign 1 304 750
notEquals 1 304 750
assign 1 0 752
assign 1 0 755
assign 1 0 759
assign 1 304 762
new 0 304 762
assign 1 304 763
notEquals 1 304 763
assign 1 0 765
assign 1 0 768
assign 1 0 772
assign 1 304 775
new 0 304 775
assign 1 304 776
notEquals 1 304 776
assign 1 0 778
assign 1 0 781
assign 1 0 785
assign 1 304 788
new 0 304 788
assign 1 304 789
notEquals 1 304 789
assign 1 0 791
assign 1 0 794
assign 1 0 798
addValue 1 305 801
assign 1 306 802
nextGet 0 306 802
assign 1 308 808
new 0 308 808
assign 1 309 809
equals 1 309 809
assign 1 309 811
increment 0 309 811
assign 1 310 813
new 0 310 813
assign 1 310 814
equals 1 310 814
assign 1 311 816
new 0 311 816
assign 1 312 817
new 0 312 817
assign 1 313 820
new 0 313 820
assign 1 313 821
equals 1 313 821
assign 1 314 823
new 0 314 823
assign 1 315 824
new 0 315 824
isClosedSet 1 315 825
assign 1 316 826
nextGet 0 316 826
assign 1 318 829
extractString 0 318 829
addAttributeName 1 318 830
assign 1 319 831
new 0 319 831
assign 1 323 836
nextGet 0 323 836
assign 1 324 839
new 0 324 839
assign 1 324 840
equals 1 324 840
assign 1 0 842
assign 1 324 845
equals 1 324 845
assign 1 0 847
assign 1 0 850
assign 1 0 854
assign 1 324 857
new 0 324 857
assign 1 324 858
equals 1 324 858
assign 1 0 860
assign 1 0 863
assign 1 326 867
equals 1 326 867
assign 1 326 869
increment 0 326 869
assign 1 327 871
nextGet 0 327 871
assign 1 329 877
notEquals 1 329 877
assign 1 330 879
new 0 330 879
assign 1 330 880
toString 0 330 880
assign 1 330 881
add 1 330 881
assign 1 330 882
new 1 330 882
throw 1 330 883
assign 1 332 885
nextGet 0 332 885
assign 1 333 888
notEquals 1 333 888
assign 1 334 890
equals 1 334 890
assign 1 334 892
increment 0 334 892
addValue 1 335 894
assign 1 336 895
nextGet 0 336 895
assign 1 338 901
notEquals 1 338 901
assign 1 339 903
new 0 339 903
assign 1 339 904
toString 0 339 904
assign 1 339 905
add 1 339 905
assign 1 339 906
new 1 339 906
throw 1 339 907
assign 1 341 909
new 0 341 909
assign 1 342 910
extractString 0 342 910
addAttributeValue 1 342 911
assign 1 343 912
new 0 343 912
assign 1 346 919
def 1 346 924
assign 1 0 925
assign 1 346 928
def 1 346 933
assign 1 346 934
isClosedGet 0 346 934
assign 1 0 936
assign 1 0 939
assign 1 0 943
assign 1 0 946
assign 1 0 949
assign 1 347 953
nextGet 0 347 953
assign 1 348 956
def 1 348 961
assign 1 348 962
new 0 348 962
assign 1 348 963
equals 1 348 963
assign 1 0 965
assign 1 348 968
equals 1 348 968
assign 1 0 970
assign 1 0 973
assign 1 0 977
assign 1 0 980
assign 1 0 984
assign 1 348 987
nextGet 0 348 987
assign 1 349 993
def 1 349 998
assign 1 349 999
new 0 349 999
assign 1 349 1000
equals 1 349 1000
assign 1 0 1002
assign 1 0 1005
assign 1 0 1009
assign 1 349 1012
new 0 349 1012
assign 1 352 1017
undef 1 352 1022
assign 1 352 1023
new 0 352 1023
assign 1 353 1025
new 0 353 1025
assign 1 353 1026
add 1 353 1026
assign 1 353 1027
new 0 353 1027
assign 1 353 1028
add 1 353 1028
assign 1 353 1029
new 1 353 1029
throw 1 353 1030
return 1 356 1034
assign 1 360 1040
not 0 360 1045
assign 1 360 1046
new 0 360 1046
return 1 360 1047
assign 1 361 1049
hasNextGet 0 361 1049
return 1 361 1050
return 1 0 1053
assign 1 0 1056
return 1 0 1060
assign 1 0 1063
return 1 0 1067
assign 1 0 1070
return 1 0 1074
assign 1 0 1077
return 1 0 1081
assign 1 0 1084
return 1 0 1088
assign 1 0 1091
return 1 0 1095
assign 1 0 1098
return 1 0 1102
assign 1 0 1105
return 1 0 1109
assign 1 0 1112
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1262689441: return bem_xmlStringGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1862823180: return bem_debugGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1858379264: return bem_restart_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 576066950: return bem_startedGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1818667533: return bem_lineGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 2020613809: return bem_iterGet_0();
case 1194623572: return bem_nextGet_0();
case 718097912: return bem_textNodeGet_0();
case 378480441: return bem_resGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 2072043336: return bem_skipGet_0();
case 1820417453: return bem_create_0();
case 1897185389: return bem_start_0();
case 786424307: return bem_tagGet_0();
case 1779033109: return bem_xtGet_0();
case 1354714650: return bem_copy_0();
case 108485850: return bem_hasNextGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2009531556: return bem_iterSet_1(bevd_0);
case 367398188: return bem_resSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 729180165: return bem_textNodeSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1767950856: return bem_xtSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2083125589: return bem_skipSet_1(bevd_0);
case 587149203: return bem_startedSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1526472767: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1851740927: return bem_debugSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1807585280: return bem_lineSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1251607188: return bem_xmlStringSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_11_XmlTagIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_11_XmlTagIterator.bevs_inst = (BEC_2_3_11_XmlTagIterator)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_11_XmlTagIterator.bevs_inst;
}
}
}
