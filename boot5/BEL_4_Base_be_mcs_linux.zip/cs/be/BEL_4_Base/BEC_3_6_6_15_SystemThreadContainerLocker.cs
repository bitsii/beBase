namespace be.BEL_4_Base {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bevs_inst;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 823 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 825 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 828 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 834 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 836 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 839 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 846 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(99049421, BEL_4_Base.bevn_has_2, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 848 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 851 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 858 */ {
bevl_r = bevp_container.bemd_0(98246023, BEL_4_Base.bevn_get_0);
bevp_lock.bem_unlock_0();
} /* Line: 860 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 863 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 870 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 872 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 875 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 882 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 885 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 888 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 895 */ {
bevl_r = bevp_container.bemd_2(98246025, BEL_4_Base.bevn_get_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 897 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 900 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 907 */ {
bevp_container.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 909 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 912 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 918 */ {
bevl_r = bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 920 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 923 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 930 */ {
bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 932 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 935 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 941 */ {
bevl_r = bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 943 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 946 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 953 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 955 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 958 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 964 */ {
bevl_rc = bevp_container.bemd_3(250195426, BEL_4_Base.bevn_testAndPut_3, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 966 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 969 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 976 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(1959489623, BEL_4_Base.bevn_getMap_0);
bevp_lock.bem_unlock_0();
} /* Line: 978 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 981 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 988 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(1959489624, BEL_4_Base.bevn_getMap_1, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 990 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 993 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1000 */ {
bevt_0_tmpvar_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1001 */ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1002 */
 else  /* Line: 1003 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1005 */
bevp_lock.bem_unlock_0();
} /* Line: 1007 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1010 */
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1017 */ {
bevt_0_tmpvar_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1018 */ {
bevl_result = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
} /* Line: 1019 */
 else  /* Line: 1020 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1022 */
bevp_lock.bem_unlock_0();
} /* Line: 1024 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1027 */
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1034 */ {
bevp_container.bemd_3(107034371, BEL_4_Base.bevn_put_3, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1036 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1039 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1045 */ {
bevl_r = bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1047 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1050 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1057 */ {
bevl_r = bevp_container.bemd_2(819712670, BEL_4_Base.bevn_delete_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1059 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1062 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1069 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1071 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1074 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1081 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(1089531140, BEL_4_Base.bevn_isEmptyGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1083 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1086 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1093 */ {
bevl_r = bevp_container.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevp_lock.bem_unlock_0();
} /* Line: 1095 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1098 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1105 */ {
bevp_container.bemd_0(856777406, BEL_4_Base.bevn_clear_0);
bevp_lock.bem_unlock_0();
} /* Line: 1107 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1110 */
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1116 */ {
bevp_container.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_lock.bem_unlock_0();
} /* Line: 1118 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1121 */
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_container = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {819, 822, 824, 825, 827, 828, 833, 835, 836, 838, 839, 841, 845, 847, 848, 850, 851, 853, 857, 859, 860, 862, 863, 865, 869, 871, 872, 874, 875, 877, 881, 883, 884, 885, 887, 888, 890, 894, 896, 897, 899, 900, 902, 906, 908, 909, 911, 912, 917, 919, 920, 922, 923, 925, 929, 931, 932, 934, 935, 940, 942, 943, 945, 946, 948, 952, 954, 955, 957, 958, 963, 965, 966, 968, 969, 971, 975, 977, 978, 980, 981, 983, 987, 989, 990, 992, 993, 995, 999, 1001, 1002, 1004, 1005, 1007, 1009, 1010, 1012, 1016, 1018, 1019, 1021, 1022, 1024, 1026, 1027, 1029, 1033, 1035, 1036, 1038, 1039, 1044, 1046, 1047, 1049, 1050, 1052, 1056, 1058, 1059, 1061, 1062, 1064, 1068, 1070, 1071, 1073, 1074, 1076, 1080, 1082, 1083, 1085, 1086, 1088, 1092, 1094, 1095, 1097, 1098, 1100, 1104, 1106, 1107, 1109, 1110, 1115, 1117, 1118, 1120, 1121, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 21, 22, 26, 27, 34, 36, 37, 41, 42, 44, 49, 51, 52, 56, 57, 59, 64, 66, 67, 71, 72, 74, 79, 81, 82, 86, 87, 89, 94, 96, 97, 98, 102, 103, 105, 110, 112, 113, 117, 118, 120, 124, 126, 127, 131, 132, 139, 141, 142, 146, 147, 149, 153, 155, 156, 160, 161, 168, 170, 171, 175, 176, 178, 182, 184, 185, 189, 190, 197, 199, 200, 204, 205, 207, 212, 214, 215, 219, 220, 222, 227, 229, 230, 234, 235, 237, 243, 245, 247, 250, 251, 253, 257, 258, 260, 266, 268, 270, 273, 274, 276, 280, 281, 283, 287, 289, 290, 294, 295, 302, 304, 305, 309, 310, 312, 317, 319, 320, 324, 325, 327, 332, 334, 335, 339, 340, 342, 347, 349, 350, 354, 355, 357, 362, 364, 365, 369, 370, 372, 376, 378, 379, 383, 384, 390, 392, 393, 397, 398, 403, 406, 410, 413};
/* BEGIN LINEINFO 
assign 1 819 18
new 0 819 18
lock 0 822 19
assign 1 824 21
unlock 0 825 22
unlock 0 827 26
throw 1 828 27
lock 0 833 34
assign 1 835 36
has 1 835 36
unlock 0 836 37
unlock 0 838 41
throw 1 839 42
return 1 841 44
lock 0 845 49
assign 1 847 51
has 2 847 51
unlock 0 848 52
unlock 0 850 56
throw 1 851 57
return 1 853 59
lock 0 857 64
assign 1 859 66
get 0 859 66
unlock 0 860 67
unlock 0 862 71
throw 1 863 72
return 1 865 74
lock 0 869 79
assign 1 871 81
get 1 871 81
unlock 0 872 82
unlock 0 874 86
throw 1 875 87
return 1 877 89
lock 0 881 94
assign 1 883 96
get 1 883 96
delete 1 884 97
unlock 0 885 98
unlock 0 887 102
throw 1 888 103
return 1 890 105
lock 0 894 110
assign 1 896 112
get 2 896 112
unlock 0 897 113
unlock 0 899 117
throw 1 900 118
return 1 902 120
lock 0 906 124
addValue 1 908 126
unlock 0 909 127
unlock 0 911 131
throw 1 912 132
lock 0 917 139
assign 1 919 141
put 1 919 141
unlock 0 920 142
unlock 0 922 146
throw 1 923 147
return 1 925 149
lock 0 929 153
put 1 931 155
unlock 0 932 156
unlock 0 934 160
throw 1 935 161
lock 0 940 168
assign 1 942 170
put 2 942 170
unlock 0 943 171
unlock 0 945 175
throw 1 946 176
return 1 948 178
lock 0 952 182
put 2 954 184
unlock 0 955 185
unlock 0 957 189
throw 1 958 190
lock 0 963 197
assign 1 965 199
testAndPut 3 965 199
unlock 0 966 200
unlock 0 968 204
throw 1 969 205
return 1 971 207
lock 0 975 212
assign 1 977 214
getMap 0 977 214
unlock 0 978 215
unlock 0 980 219
throw 1 981 220
return 1 983 222
lock 0 987 227
assign 1 989 229
getMap 1 989 229
unlock 0 990 230
unlock 0 992 234
throw 1 993 235
return 1 995 237
lock 0 999 243
assign 1 1001 245
has 1 1001 245
assign 1 1002 247
new 0 1002 247
put 2 1004 250
assign 1 1005 251
new 0 1005 251
unlock 0 1007 253
unlock 0 1009 257
throw 1 1010 258
return 1 1012 260
lock 0 1016 266
assign 1 1018 268
has 1 1018 268
assign 1 1019 270
get 1 1019 270
put 2 1021 273
assign 1 1022 274
unlock 0 1024 276
unlock 0 1026 280
throw 1 1027 281
return 1 1029 283
lock 0 1033 287
put 3 1035 289
unlock 0 1036 290
unlock 0 1038 294
throw 1 1039 295
lock 0 1044 302
assign 1 1046 304
delete 1 1046 304
unlock 0 1047 305
unlock 0 1049 309
throw 1 1050 310
return 1 1052 312
lock 0 1056 317
assign 1 1058 319
delete 2 1058 319
unlock 0 1059 320
unlock 0 1061 324
throw 1 1062 325
return 1 1064 327
lock 0 1068 332
assign 1 1070 334
sizeGet 0 1070 334
unlock 0 1071 335
unlock 0 1073 339
throw 1 1074 340
return 1 1076 342
lock 0 1080 347
assign 1 1082 349
isEmptyGet 0 1082 349
unlock 0 1083 350
unlock 0 1085 354
throw 1 1086 355
return 1 1088 357
lock 0 1092 362
assign 1 1094 364
copy 0 1094 364
unlock 0 1095 365
unlock 0 1097 369
throw 1 1098 370
return 1 1100 372
lock 0 1104 376
clear 0 1106 378
unlock 0 1107 379
unlock 0 1109 383
throw 1 1110 384
lock 0 1115 390
close 0 1117 392
unlock 0 1118 393
unlock 0 1120 397
throw 1 1121 398
return 1 0 403
assign 1 0 406
return 1 0 410
assign 1 0 413
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 833063302: return bem_containerGet_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 952571108: return bem_lockGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 866536361: return bem_close_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 98246023: return bem_get_0();
case 1820417453: return bem_create_0();
case 454584637: return bem_copyContainer_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 1959489623: return bem_getMap_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 941488855: return bem_lockSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 365996783: return bem_putReturn_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1572587742: return bem_getAndClear_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1959489624: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2(bevd_0, bevd_1);
case 98246025: return bem_get_2(bevd_0, bevd_1);
case 819712670: return bem_delete_2(bevd_0, bevd_1);
case 99049421: return bem_has_2(bevd_0, bevd_1);
case 365996782: return bem_putReturn_2(bevd_0, bevd_1);
case 188241239: return bem_getOrPut_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2074693976: return bem_putIfAbsent_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 107034371: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 250195426: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bevs_inst;
}
}
}
