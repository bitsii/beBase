namespace be.BEL_4_Base {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_5_SystemTypes : BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemTypes() { }
static BEC_2_6_5_SystemTypes() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_5_SystemTypes bevs_inst;
public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_bool;
public BEC_2_4_5_MathFloat bevp_float;
public BEC_2_6_5_SystemThing bevp_thing;
public BEC_2_4_6_TextString bevp_string;
public BEC_2_4_6_TextString bevp_byteBuffer;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_5_SystemTypes bem_default_0() {
bevp_int = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevp_bool = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_float = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
bevp_thing = (BEC_2_6_5_SystemThing) (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_string = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_byteBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_intGet_0() {
return bevp_int;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_boolGet_0() {
return bevp_bool;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_boolSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_5_MathFloat bem_floatGet_0() {
return bevp_float;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_floatSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_5_SystemThing bem_thingGet_0() {
return bevp_thing;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_stringGet_0() {
return bevp_string;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_stringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_string = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_byteBufferGet_0() {
return bevp_byteBuffer;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_byteBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {323, 324, 325, 326, 327, 328, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 27, 28, 29, 33, 36, 40, 43, 47, 50, 54, 57, 61, 64, 68, 71};
/* BEGIN LINEINFO 
assign 1 323 24
new 0 323 24
assign 1 324 25
new 0 324 25
assign 1 325 26
new 0 325 26
assign 1 326 27
new 0 326 27
assign 1 327 28
new 0 327 28
assign 1 328 29
new 0 328 29
return 1 0 33
assign 1 0 36
return 1 0 40
assign 1 0 43
return 1 0 47
assign 1 0 50
return 1 0 54
assign 1 0 57
return 1 0 61
assign 1 0 64
return 1 0 68
assign 1 0 71
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 2030843069: return bem_boolGet_0();
case 1532940298: return bem_stringGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 542323416: return bem_intGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 1039457141: return bem_floatGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 147288775: return bem_thingGet_0();
case 1102720804: return bem_classNameGet_0();
case 1765872383: return bem_byteBufferGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 136206522: return bem_thingSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1521858045: return bem_stringSet_1(bevd_0);
case 1776954636: return bem_byteBufferSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2041925322: return bem_boolSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 553405669: return bem_intSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1028374888: return bem_floatSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_5_SystemTypes();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_5_SystemTypes.bevs_inst = (BEC_2_6_5_SystemTypes)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_5_SystemTypes.bevs_inst;
}
}
}
