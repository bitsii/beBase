namespace be.BEL_4_Base {
/* IO:File: source/base/LinkedList.be */
public class BEC_9_10_ContainerLinkedList : BEC_6_6_SystemObject {
public BEC_9_10_ContainerLinkedList() { }
static BEC_9_10_ContainerLinkedList() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
public static new BEC_9_10_ContainerLinkedList bevs_inst;
public BEC_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_9_10_4_ContainerLinkedListNode bevp_lastNode;
public override BEC_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_6_6_SystemObject beva_toHold) {
BEC_9_10_4_ContainerLinkedListNode bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_10_4_ContainerLinkedListNode) (new BEC_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_9_10_ContainerLinkedList bevl_other = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_other = (BEC_9_10_ContainerLinkedList) this.bem_create_0();
bevl_iter = this.bem_linkedListIteratorGet_0();
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 142 */ {
return (BEC_6_6_SystemObject) bevl_other;
} /* Line: 143 */
while (true)
 /* Line: 147 */ {
if (bevl_f == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 147 */ {
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 149 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 150 */
if (bevl_fnode == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 153 */ {
bevl_fnode = bevl_f;
} /* Line: 154 */
bevl_last = bevl_f;
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 157 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_appendNode_1(BEC_6_6_SystemObject beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_lastNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 166 */ {
beva_node.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 169 */
 else  /* Line: 170 */ {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 172 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prependNode_1(BEC_6_6_SystemObject beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 178 */ {
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 181 */
 else  /* Line: 182 */ {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 184 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deleteNode_1(BEC_6_6_SystemObject beva_node) {
beva_node.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_insertBeforeNode_2(BEC_6_6_SystemObject beva_toIns, BEC_6_6_SystemObject beva_node) {
beva_node.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, beva_toIns);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_1(BEC_4_3_MathInt beva_pos) {
BEC_4_3_MathInt bevl_i = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = beva_pos.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevt_2_tmpvar_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpvar_phold;
} /* Line: 198 */
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 201 */ {
bevt_3_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 201 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(beva_pos);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 203 */
 else  /* Line: 204 */ {
break;
} /* Line: 205 */
bevl_i.bem_incrementValue_0();
} /* Line: 207 */
 else  /* Line: 201 */ {
break;
} /* Line: 201 */
} /* Line: 201 */
bevt_5_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 209 */ {
return null;
} /* Line: 210 */
bevt_6_tmpvar_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_put_2(BEC_4_3_MathInt beva_pos, BEC_6_6_SystemObject beva_value) {
BEC_4_3_MathInt bevl_i = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpvar_phold);
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 218 */ {
bevt_1_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 218 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(beva_pos);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 220 */
 else  /* Line: 221 */ {
break;
} /* Line: 222 */
bevl_i.bem_incrementValue_0();
} /* Line: 224 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevt_3_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 226 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 227 */
bevt_5_tmpvar_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_firstGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 233 */ {
return null;
} /* Line: 233 */
bevt_1_tmpvar_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_secondGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_5_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 238 */ {
bevt_5_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_heldGet_0();
return bevt_4_tmpvar_phold;
} /* Line: 239 */
return null;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_thirdGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_6_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_9_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_10_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_4_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_7_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_nextGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_10_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_nextGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_heldGet_0();
return bevt_8_tmpvar_phold;
} /* Line: 246 */
return null;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 252 */ {
return null;
} /* Line: 252 */
bevt_1_tmpvar_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getNode_1(BEC_6_6_SystemObject beva_pos) {
BEC_4_3_MathInt bevl_i = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = beva_pos.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 257 */ {
return bevp_firstNode;
} /* Line: 258 */
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 261 */ {
bevt_2_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 261 */ {
bevt_3_tmpvar_phold = bevl_i.bem_lesser_1((BEC_4_3_MathInt) beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 263 */
 else  /* Line: 264 */ {
break;
} /* Line: 265 */
bevl_i.bem_incrementValue_0();
} /* Line: 267 */
 else  /* Line: 261 */ {
break;
} /* Line: 261 */
} /* Line: 261 */
bevt_4_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 269 */ {
return null;
} /* Line: 270 */
bevt_5_tmpvar_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addValueWhole_1(BEC_6_6_SystemObject beva_held) {
BEC_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addValue_1(BEC_6_6_SystemObject beva_held) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_held == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevt_2_tmpvar_phold = beva_held.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 281 */
 else  /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 281 */ {
this.bem_addAll_1(beva_held);
} /* Line: 282 */
 else  /* Line: 283 */ {
this.bem_addValueWhole_1(beva_held);
} /* Line: 284 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_iterateAdd_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 289 */ {
while (true)
 /* Line: 290 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 291 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
} /* Line: 290 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addAll_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 298 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepend_1(BEC_6_6_SystemObject beva_held) {
BEC_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lengthGet_0() {
BEC_4_3_MathInt bevl_cnt = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_cnt = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bem_incrementValue_0();
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
return bevl_cnt;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_lengthGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_1_tmpvar_phold;
} /* Line: 322 */
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_toNodeArray_0() {
BEC_4_3_MathInt bevl_len = null;
BEC_9_5_ContainerArray bevl_toret = null;
BEC_4_3_MathInt bevl_cnt = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevl_len);
bevl_cnt = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 331 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 331 */ {
bevt_1_tmpvar_phold = bevl_cnt.bem_lesser_1(bevl_len);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 332 */ {
bevt_2_tmpvar_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpvar_phold);
} /* Line: 333 */
bevl_cnt.bem_incrementValue_0();
} /* Line: 335 */
 else  /* Line: 331 */ {
break;
} /* Line: 331 */
} /* Line: 331 */
return bevl_toret;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_toArray_0() {
BEC_4_3_MathInt bevl_len = null;
BEC_9_5_ContainerArray bevl_toret = null;
BEC_4_3_MathInt bevl_cnt = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevl_len);
bevl_cnt = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 344 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 344 */ {
bevt_1_tmpvar_phold = bevl_cnt.bem_lesser_1(bevl_len);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevt_3_tmpvar_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpvar_phold);
} /* Line: 346 */
bevl_cnt.bem_incrementValue_0();
} /* Line: 348 */
 else  /* Line: 344 */ {
break;
} /* Line: 344 */
} /* Line: 344 */
return bevl_toret;
} /*method end*/
public override BEC_6_6_SystemObject bem_iteratorGet_0() {
BEC_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() {
BEC_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_subList_1(BEC_4_3_MathInt beva_start) {
BEC_9_10_ContainerLinkedList bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_4_MathInts bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_4_MathInts) BEC_4_4_MathInts.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_maxGet_0();
bevt_0_tmpvar_phold = this.bem_subList_2(beva_start, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_subList_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) {
BEC_9_10_ContainerLinkedList bevl_res = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_4_3_MathInt bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_res = (BEC_9_10_ContainerLinkedList) this.bem_create_0();
bevt_0_tmpvar_phold = beva_end.bem_lesserEquals_1(beva_start);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 371 */ {
return bevl_res;
} /* Line: 372 */
bevl_iter = this.bem_linkedListIteratorGet_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 375 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_end);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevt_3_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 376 */ {
return bevl_res;
} /* Line: 377 */
bevl_x = bevl_iter.bem_nextGet_0();
bevt_4_tmpvar_phold = bevl_i.bem_greaterEquals_1(beva_start);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 381 */
bevl_i.bem_incrementValue_0();
} /* Line: 375 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
return bevl_res;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_reverse_0() {
BEC_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_1_tmpvar_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 424 */ {
if (bevl_current == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpvar_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpvar_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 429 */
 else  /* Line: 424 */ {
break;
} /* Line: 424 */
} /* Line: 424 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public virtual BEC_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() {
return bevp_firstNode;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_firstNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() {
return bevp_lastNode;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {134, 139, 140, 141, 142, 143, 147, 148, 149, 150, 153, 154, 156, 157, 159, 160, 161, 165, 166, 167, 168, 169, 171, 172, 177, 178, 179, 180, 181, 183, 184, 189, 193, 197, 198, 200, 201, 202, 203, 207, 209, 210, 212, 216, 217, 218, 219, 220, 224, 226, 227, 229, 233, 234, 238, 0, 239, 241, 245, 0, 245, 0, 246, 248, 252, 253, 257, 258, 260, 261, 262, 263, 267, 269, 270, 272, 276, 277, 281, 0, 282, 284, 289, 290, 291, 297, 298, 303, 304, 308, 309, 310, 311, 313, 317, 321, 322, 324, 328, 329, 330, 331, 332, 333, 335, 337, 341, 342, 343, 344, 345, 346, 348, 350, 354, 358, 362, 366, 370, 371, 372, 374, 375, 376, 377, 379, 380, 381, 375, 384, 422, 423, 424, 425, 426, 427, 428, 429, 431, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14};
/* BEGIN LINEINFO 
assign 1 134 14
new 2 134 14
return 1 134 14
assign 1 139 14
create 0 139 14
assign 1 140 14
linkedListIteratorGet 0 140 14
assign 1 141 14
nextNodeGet 0 141 14
assign 1 142 14
undef 1 142 14
return 1 143 14
assign 1 147 14
def 1 147 14
assign 1 148 14
copy 0 148 14
assign 1 149 14
def 1 149 14
nextSet 1 150 14
assign 1 153 14
undef 1 153 14
assign 1 154 14
assign 1 156 14
assign 1 157 14
nextNodeGet 0 157 14
firstNodeSet 1 159 14
lastNodeSet 1 160 14
return 1 161 14
nextSet 1 165 14
assign 1 166 14
def 1 166 14
priorSet 1 167 14
nextSet 1 168 14
assign 1 169 14
assign 1 171 14
assign 1 172 14
nextSet 1 177 14
assign 1 178 14
def 1 178 14
nextSet 1 179 14
priorSet 1 180 14
assign 1 181 14
assign 1 183 14
assign 1 184 14
delete 0 189 14
insertBefore 1 193 14
assign 1 197 14
new 0 197 14
assign 1 197 14
equals 1 197 14
assign 1 198 14
heldGet 0 198 14
return 1 198 14
assign 1 200 14
new 0 200 14
assign 1 201 14
linkedListIteratorGet 0 201 14
assign 1 201 14
hasNextGet 0 201 14
assign 1 202 14
lesser 1 202 14
nextGet 0 203 14
incrementValue 0 207 14
assign 1 209 14
notEquals 1 209 14
return 1 210 14
assign 1 212 14
nextGet 0 212 14
return 1 212 14
assign 1 216 14
new 0 216 14
assign 1 216 14
add 1 216 14
assign 1 217 14
new 0 217 14
assign 1 218 14
linkedListIteratorGet 0 218 14
assign 1 218 14
hasNextGet 0 218 14
assign 1 219 14
lesser 1 219 14
nextGet 0 220 14
incrementValue 0 224 14
assign 1 226 14
notEquals 1 226 14
assign 1 227 14
new 0 227 14
return 1 227 14
assign 1 229 14
currentSet 1 229 14
return 1 229 14
assign 1 233 14
undef 1 233 14
return 1 233 14
assign 1 234 14
heldGet 0 234 14
return 1 234 14
assign 1 238 14
def 1 238 14
assign 1 238 14
nextGet 0 238 14
assign 1 238 14
def 1 238 14
assign 1 0 14
assign 1 0 14
assign 1 0 14
assign 1 239 14
nextGet 0 239 14
assign 1 239 14
heldGet 0 239 14
return 1 239 14
return 1 241 14
assign 1 245 14
def 1 245 14
assign 1 245 14
nextGet 0 245 14
assign 1 245 14
def 1 245 14
assign 1 0 14
assign 1 0 14
assign 1 0 14
assign 1 245 14
nextGet 0 245 14
assign 1 245 14
nextGet 0 245 14
assign 1 245 14
def 1 245 14
assign 1 0 14
assign 1 0 14
assign 1 0 14
assign 1 246 14
nextGet 0 246 14
assign 1 246 14
nextGet 0 246 14
assign 1 246 14
heldGet 0 246 14
return 1 246 14
return 1 248 14
assign 1 252 14
undef 1 252 14
return 1 252 14
assign 1 253 14
heldGet 0 253 14
return 1 253 14
assign 1 257 14
new 0 257 14
assign 1 257 14
equals 1 257 14
return 1 258 14
assign 1 260 14
new 0 260 14
assign 1 261 14
linkedListIteratorGet 0 261 14
assign 1 261 14
hasNextGet 0 261 14
assign 1 262 14
lesser 1 262 14
nextGet 0 263 14
incrementValue 0 267 14
assign 1 269 14
notEquals 1 269 14
return 1 270 14
assign 1 272 14
nextNodeGet 0 272 14
return 1 272 14
assign 1 276 14
newNode 1 276 14
appendNode 1 277 14
assign 1 281 14
def 1 281 14
assign 1 281 14
sameType 1 281 14
assign 1 0 14
assign 1 0 14
assign 1 0 14
addAll 1 282 14
addValueWhole 1 284 14
assign 1 289 14
def 1 289 14
assign 1 290 14
hasNextGet 0 290 14
assign 1 291 14
nextGet 0 291 14
addValueWhole 1 291 14
assign 1 297 14
def 1 297 14
assign 1 298 14
iteratorGet 0 298 14
iterateAdd 1 298 14
assign 1 303 14
newNode 1 303 14
prependNode 1 304 14
assign 1 308 14
new 0 308 14
assign 1 309 14
linkedListIteratorGet 0 309 14
assign 1 309 14
hasNextGet 0 309 14
nextGet 0 310 14
incrementValue 0 311 14
return 1 313 14
assign 1 317 14
lengthGet 0 317 14
return 1 317 14
assign 1 321 14
undef 1 321 14
assign 1 322 14
new 0 322 14
return 1 322 14
assign 1 324 14
new 0 324 14
return 1 324 14
assign 1 328 14
lengthGet 0 328 14
assign 1 329 14
new 1 329 14
assign 1 330 14
new 0 330 14
assign 1 331 14
linkedListIteratorGet 0 331 14
assign 1 331 14
hasNextGet 0 331 14
assign 1 332 14
lesser 1 332 14
assign 1 333 14
nextNodeGet 0 333 14
put 2 333 14
incrementValue 0 335 14
return 1 337 14
assign 1 341 14
lengthGet 0 341 14
assign 1 342 14
new 1 342 14
assign 1 343 14
new 0 343 14
assign 1 344 14
linkedListIteratorGet 0 344 14
assign 1 344 14
hasNextGet 0 344 14
assign 1 345 14
lesser 1 345 14
assign 1 346 14
nextNodeGet 0 346 14
assign 1 346 14
heldGet 0 346 14
put 2 346 14
incrementValue 0 348 14
return 1 350 14
assign 1 354 14
new 1 354 14
return 1 354 14
assign 1 358 14
new 1 358 14
return 1 358 14
assign 1 362 14
iteratorGet 0 362 14
return 1 362 14
assign 1 366 14
new 0 366 14
assign 1 366 14
maxGet 0 366 14
assign 1 366 14
subList 2 366 14
return 1 366 14
assign 1 370 14
create 0 370 14
assign 1 371 14
lesserEquals 1 371 14
return 1 372 14
assign 1 374 14
linkedListIteratorGet 0 374 14
assign 1 375 14
new 0 375 14
assign 1 375 14
lesser 1 375 14
assign 1 376 14
hasNextGet 0 376 14
assign 1 376 14
not 0 376 14
return 1 377 14
assign 1 379 14
nextGet 0 379 14
assign 1 380 14
greaterEquals 1 380 14
addValue 1 381 14
incrementValue 0 375 14
return 1 384 14
assign 1 422 14
assign 1 423 14
assign 1 424 14
def 1 424 14
assign 1 425 14
nextGet 0 425 14
assign 1 426 14
priorGet 0 426 14
nextSet 1 426 14
priorSet 1 427 14
assign 1 428 14
assign 1 429 14
assign 1 431 14
return 1 0 14
assign 1 0 14
return 1 0 14
assign 1 0 14
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 789570067: return bem_toNodeArray_0();
case 390409747: return bem_reverse_0();
case 1696089045: return bem_firstNodeGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1616433729: return bem_lengthGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1897309391: return bem_toArray_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 978128800: return bem_thirdGet_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case 1990707345: return bem_lastGet_0();
case 1351154001: return bem_lastNodeGet_0();
case 786424307: return bem_tagGet_0();
case 242848115: return bem_secondGet_0();
case 1354714650: return bem_copy_0();
case 874473310: return bem_linkedListIteratorGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 228068295: return bem_addValueWhole_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 908228929: return bem_deleteNode_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1707171298: return bem_firstNodeSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 655844394: return bem_getNode_1(bevd_0);
case 596113616: return bem_subList_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 743891212: return bem_newNode_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1167376622: return bem_appendNode_1(bevd_0);
case 1340071748: return bem_lastNodeSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1007846464: return bem_prepend_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1142954398: return bem_prependNode_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 107034370: return bem_put_2((BEC_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 596113615: return bem_subList_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1098622227: return bem_insertBeforeNode_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_9_10_ContainerLinkedList();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_9_10_ContainerLinkedList.bevs_inst = (BEC_9_10_ContainerLinkedList)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_9_10_ContainerLinkedList.bevs_inst;
}
}
}
