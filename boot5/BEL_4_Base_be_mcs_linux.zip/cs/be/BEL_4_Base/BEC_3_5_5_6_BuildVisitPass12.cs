namespace be.BEL_4_Base {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_6_BuildVisitPass12 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass12() { }
static BEC_3_5_5_6_BuildVisitPass12() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x32};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_3 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_4 = {0x47,0x45,0x54};
private static byte[] bels_5 = {0x5F,0x30};
private static byte[] bels_6 = {0x53,0x45,0x54};
private static byte[] bels_7 = {0x5F,0x31};
private static byte[] bels_8 = {0x53,0x45,0x54};
private static byte[] bels_9 = {0x43,0x61,0x6C,0x6C,0x20,0x68,0x65,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_10 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_11 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 64));
private static byte[] bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x70,0x72,0x6F,0x62,0x61,0x62,0x6C,0x79,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x65,0x78,0x69,0x73,0x74,0x2C,0x20,0x76,0x65,0x72,0x69,0x66,0x79,0x20,0x6E,0x61,0x6D,0x65,0x20,0x61,0x6E,0x64,0x20,0x75,0x73,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] bels_13 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 52));
private static byte[] bels_14 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74};
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_15 = {0x5F};
private static byte[] bels_16 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_17 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_18 = {0x6D,0x61,0x6E,0x79,0x5F,0x30};
public static new BEC_3_5_5_6_BuildVisitPass12 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_classnp;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAccessor_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_myselfn = null;
BEC_2_6_6_SystemObject bevl_myself = null;
BEC_2_6_6_SystemObject bevl_mtdmyn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_6_6_SystemObject bevl_myparn = null;
BEC_2_6_6_SystemObject bevl_mybr = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_myselfn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_myselfn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpvar_phold);
bevl_myself = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_0));
bevl_myself.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_2_tmpvar_phold);
bevl_myself.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevp_classnp);
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_3_tmpvar_phold);
bevl_myselfn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_myself);
bevl_mtdmyn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_4_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mtdmyn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_4_tmpvar_phold);
bevl_mtdmy = (new BEC_2_5_6_BuildMethod()).bem_new_0();
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_mtdmy.bemd_1(1725653351, BEL_4_Base.bevn_isGenAccessorSet_1, bevt_5_tmpvar_phold);
bevl_mtdmyn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_mtdmy);
bevl_myparn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_6_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_myparn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_6_tmpvar_phold);
bevl_myparn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_myselfn);
bevl_mtdmyn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_myparn);
bevl_myselfn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_mybr = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_7_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_mybr.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_7_tmpvar_phold);
bevl_mtdmyn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_mybr);
return bevl_mtdmyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getRetNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_retnoden = null;
BEC_2_6_6_SystemObject bevl_retnode = null;
BEC_2_6_6_SystemObject bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevl_retnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_retnoden.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpvar_phold);
bevl_retnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevl_retnode.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpvar_phold);
bevl_retnoden.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_retnode);
bevl_sn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_sn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_2));
bevl_sn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_3_tmpvar_phold);
bevl_retnoden.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_sn);
return bevl_retnoden;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAsNode_1(BEC_2_6_6_SystemObject beva_selfnode) {
BEC_2_6_6_SystemObject bevl_asnoden = null;
BEC_2_6_6_SystemObject bevl_asnode = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_asnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asnoden.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpvar_phold);
bevl_asnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_3));
bevl_asnode.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpvar_phold);
bevl_asnoden.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asnode);
return bevl_asnoden;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_ia = null;
BEC_2_6_6_SystemObject bevl_tst = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ename = null;
BEC_2_6_6_SystemObject bevl_anode = null;
BEC_2_6_6_SystemObject bevl_rettnode = null;
BEC_2_6_6_SystemObject bevl_rin = null;
BEC_2_6_6_SystemObject bevl_sv = null;
BEC_2_6_6_SystemObject bevl_svn = null;
BEC_2_6_6_SystemObject bevl_svn2 = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_newNp = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_c1 = null;
BEC_2_6_6_SystemObject bevl_bn = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_102_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_131_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_156_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_160_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_165_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_166_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_169_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_182_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_183_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_186_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_189_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_191_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_192_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_193_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_194_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_195_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_197_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_198_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_199_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_200_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_201_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_204_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_205_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_206_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_13_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_firstGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ia = bevt_11_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpvar_phold = bevl_ia.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_14_tmpvar_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_ia.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevp_classnp);
} /* Line: 78 */
 else  /* Line: 75 */ {
bevt_18_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_18_tmpvar_phold.bevi_int == bevt_19_tmpvar_phold.bevi_int) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_20_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_tst = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_ii = bevt_21_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 82 */ {
bevt_23_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 82 */ {
bevt_24_tmpvar_phold = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i = bevt_24_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpvar_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_4));
bevl_tst.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_27_tmpvar_phold);
bevl_tst.bemd_0(173192194, BEL_4_Base.bevn_toAccessorName_0);
bevl_ename = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_29_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_5));
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_30_tmpvar_phold);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_28_tmpvar_phold);
bevt_31_tmpvar_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 89 */ {
bevt_35_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_36_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_36_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 89 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 89 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 89 */
 else  /* Line: 89 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 89 */ {
bevl_anode = this.bem_getAccessor_1(beva_node);
bevt_37_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold.bemd_1(1030895937, BEL_4_Base.bevn_propertySet_1, bevl_i);
bevt_38_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_ename);
bevt_39_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_40_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_39_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_41_tmpvar_phold.bemd_1(537631759, BEL_4_Base.bevn_numargsSet_1, bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_46_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_43_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_45_tmpvar_phold, bevl_anode);
bevt_48_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_47_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_50_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_lastGet_0();
bevt_49_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevl_rettnode = this.bem_getRetNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_51_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_51_tmpvar_phold);
bevt_53_tmpvar_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevl_rin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_52_tmpvar_phold);
bevl_rettnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rin);
bevt_55_tmpvar_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevt_54_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rettnode);
bevt_57_tmpvar_phold = bevl_rettnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_56_tmpvar_phold.bemd_1(205397975, BEL_4_Base.bevn_syncVariable_1, this);
bevl_rin.bemd_1(205397975, BEL_4_Base.bevn_syncVariable_1, this);
bevt_58_tmpvar_phold = bevl_i.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 108 */ {
bevt_59_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_59_tmpvar_phold.bemd_1(419853240, BEL_4_Base.bevn_rtypeSet_1, bevl_i);
} /* Line: 109 */
} /* Line: 108 */
bevt_61_tmpvar_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_60_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_6));
bevl_tst.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_62_tmpvar_phold);
bevl_tst.bemd_0(173192194, BEL_4_Base.bevn_toAccessorName_0);
bevl_ename = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_64_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_7));
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_65_tmpvar_phold);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_63_tmpvar_phold);
bevt_66_tmpvar_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_66_tmpvar_phold != null && bevt_66_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_66_tmpvar_phold).bevi_bool) /* Line: 119 */ {
bevt_70_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_71_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_71_tmpvar_phold);
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 119 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 119 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 119 */
 else  /* Line: 119 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 119 */ {
bevl_anode = this.bem_getAccessor_1(beva_node);
bevt_72_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_72_tmpvar_phold.bemd_1(1030895937, BEL_4_Base.bevn_propertySet_1, bevl_i);
bevt_73_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_73_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_ename);
bevt_74_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_75_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_74_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_75_tmpvar_phold);
bevt_76_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_77_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_76_tmpvar_phold.bemd_1(537631759, BEL_4_Base.bevn_numargsSet_1, bevt_77_tmpvar_phold);
bevt_79_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_81_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_78_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_80_tmpvar_phold, bevl_anode);
bevt_83_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_82_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_85_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_84_tmpvar_phold = bevt_85_tmpvar_phold.bem_lastGet_0();
bevt_84_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_8));
bevl_sv = bevl_anode.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_86_tmpvar_phold, bevp_build);
bevt_87_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_sv.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_87_tmpvar_phold);
bevl_svn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_svn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_88_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_88_tmpvar_phold);
bevl_svn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_sv);
bevt_90_tmpvar_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_89_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_svn);
bevl_svn2 = (new BEC_2_5_4_BuildNode());
bevl_svn2.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_91_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn2.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_91_tmpvar_phold);
bevl_svn2.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_sv);
bevl_asn = this.bem_getAsNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_92_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_93_tmpvar_phold = bevt_94_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevl_rin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_93_tmpvar_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rin);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_svn2);
bevt_96_tmpvar_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevt_95_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_asn);
bevl_svn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_rin.bemd_1(205397975, BEL_4_Base.bevn_syncVariable_1, this);
} /* Line: 153 */
} /* Line: 119 */
 else  /* Line: 82 */ {
break;
} /* Line: 82 */
} /* Line: 82 */
} /* Line: 82 */
 else  /* Line: 75 */ {
bevt_98_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_99_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_98_tmpvar_phold.bevi_int == bevt_99_tmpvar_phold.bevi_int) {
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_101_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_101_tmpvar_phold == null) {
bevt_100_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_100_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_100_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevt_103_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bels_9));
bevt_102_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_103_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_102_tmpvar_phold);
} /* Line: 161 */
bevt_105_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 163 */ {
bevt_108_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_107_tmpvar_phold == null) {
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_106_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 163 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 163 */
 else  /* Line: 163 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 163 */ {
bevt_109_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_newNp = bevt_109_tmpvar_phold.bem_firstGet_0();
bevt_111_tmpvar_phold = bevl_newNp.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_112_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_110_tmpvar_phold = bevt_111_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_112_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 165 */ {
bevt_114_tmpvar_phold = bevl_newNp.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_115_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_113_tmpvar_phold = bevt_114_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_115_tmpvar_phold);
if (bevt_113_tmpvar_phold != null && bevt_113_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_113_tmpvar_phold).bevi_bool) /* Line: 166 */ {
bevt_118_tmpvar_phold = bevl_newNp.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_119_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_10));
bevt_116_tmpvar_phold = bevt_117_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_119_tmpvar_phold);
if (bevt_116_tmpvar_phold != null && bevt_116_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_116_tmpvar_phold).bevi_bool) /* Line: 166 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
 else  /* Line: 166 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 166 */ {
bevl_newNp = beva_node.bem_secondGet_0();
bevt_121_tmpvar_phold = bevl_newNp.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_122_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_122_tmpvar_phold);
if (bevt_120_tmpvar_phold != null && bevt_120_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_120_tmpvar_phold).bevi_bool) /* Line: 168 */ {
bevt_124_tmpvar_phold = bevo_0;
bevt_125_tmpvar_phold = bevl_newNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bem_add_1(bevt_125_tmpvar_phold);
bevt_123_tmpvar_phold.bem_print_0();
bevt_127_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(131, bels_12));
bevt_126_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 170 */
} /* Line: 168 */
 else  /* Line: 172 */ {
bevt_129_tmpvar_phold = bevo_1;
bevt_130_tmpvar_phold = bevl_newNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bem_add_1(bevt_130_tmpvar_phold);
bevt_128_tmpvar_phold.bem_print_0();
bevt_132_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bels_14));
bevt_131_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_132_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_131_tmpvar_phold);
} /* Line: 174 */
} /* Line: 166 */
bevt_133_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_134_tmpvar_phold = bevl_newNp.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_133_tmpvar_phold.bemd_1(1572840142, BEL_4_Base.bevn_newNpSet_1, bevt_134_tmpvar_phold);
bevl_newNp.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 178 */
bevt_135_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_138_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_137_tmpvar_phold = bevt_138_tmpvar_phold.bem_lengthGet_0();
bevt_139_tmpvar_phold = bevo_2;
bevt_136_tmpvar_phold = bevt_137_tmpvar_phold.bem_subtract_1(bevt_139_tmpvar_phold);
bevt_135_tmpvar_phold.bemd_1(537631759, BEL_4_Base.bevn_numargsSet_1, bevt_136_tmpvar_phold);
bevt_140_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_142_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_141_tmpvar_phold = bevt_142_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_140_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_141_tmpvar_phold);
bevt_143_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_147_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_148_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_15));
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_148_tmpvar_phold);
bevt_151_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_144_tmpvar_phold = bevt_145_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_149_tmpvar_phold);
bevt_143_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_144_tmpvar_phold);
bevt_154_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_155_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_16));
bevt_152_tmpvar_phold = bevt_153_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_155_tmpvar_phold);
if (bevt_152_tmpvar_phold != null && bevt_152_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_152_tmpvar_phold).bevi_bool) /* Line: 183 */ {
bevt_156_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_c0 = bevt_156_tmpvar_phold.bem_firstGet_0();
if (bevl_c0 == null) {
bevt_157_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_157_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_157_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevt_159_tmpvar_phold = bevl_c0.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_160_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_160_tmpvar_phold);
if (bevt_158_tmpvar_phold != null && bevt_158_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpvar_phold).bevi_bool) /* Line: 185 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 185 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 185 */
 else  /* Line: 185 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 185 */ {
bevt_161_tmpvar_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_164_tmpvar_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_163_tmpvar_phold = bevt_164_tmpvar_phold.bemd_0(389100841, BEL_4_Base.bevn_numAssignsGet_0);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_161_tmpvar_phold.bemd_1(400183094, BEL_4_Base.bevn_numAssignsSet_1, bevt_162_tmpvar_phold);
} /* Line: 186 */
bevt_165_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_c1 = bevt_165_tmpvar_phold.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_166_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_166_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_166_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevt_168_tmpvar_phold = bevl_c1.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_169_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_167_tmpvar_phold = bevt_168_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_169_tmpvar_phold);
if (bevt_167_tmpvar_phold != null && bevt_167_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_167_tmpvar_phold).bevi_bool) /* Line: 189 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
 else  /* Line: 189 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 189 */ {
bevt_172_tmpvar_phold = bevl_c1.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_171_tmpvar_phold = bevt_172_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_173_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_17));
bevt_170_tmpvar_phold = bevt_171_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_173_tmpvar_phold);
if (bevt_170_tmpvar_phold != null && bevt_170_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_170_tmpvar_phold).bevi_bool) /* Line: 194 */ {
bevt_174_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_175_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_174_tmpvar_phold.bemd_1(1489916809, BEL_4_Base.bevn_isOnceSet_1, bevt_175_tmpvar_phold);
} /* Line: 195 */
bevt_178_tmpvar_phold = bevl_c1.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_177_tmpvar_phold = bevt_178_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_179_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_18));
bevt_176_tmpvar_phold = bevt_177_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_179_tmpvar_phold);
if (bevt_176_tmpvar_phold != null && bevt_176_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_176_tmpvar_phold).bevi_bool) /* Line: 197 */ {
bevt_180_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_181_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_180_tmpvar_phold.bemd_1(1373349483, BEL_4_Base.bevn_isManySet_1, bevt_181_tmpvar_phold);
} /* Line: 198 */
} /* Line: 197 */
} /* Line: 189 */
} /* Line: 183 */
 else  /* Line: 75 */ {
bevt_183_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_184_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_183_tmpvar_phold.bevi_int == bevt_184_tmpvar_phold.bevi_int) {
bevt_182_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_182_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_182_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevl_bn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_186_tmpvar_phold = beva_node.bem_containedGet_0();
if (bevt_186_tmpvar_phold == null) {
bevt_185_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_185_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_185_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_189_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bem_lastGet_0();
if (bevt_188_tmpvar_phold == null) {
bevt_187_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_187_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_187_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 204 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 204 */
 else  /* Line: 204 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 204 */ {
bevt_192_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_191_tmpvar_phold = bevt_192_tmpvar_phold.bem_lastGet_0();
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bemd_0(1595262430, BEL_4_Base.bevn_nlcGet_0);
bevl_bn.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevt_190_tmpvar_phold);
} /* Line: 205 */
 else  /* Line: 206 */ {
bevl_bn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
} /* Line: 207 */
bevt_193_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevl_bn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_193_tmpvar_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_bn);
} /* Line: 210 */
 else  /* Line: 75 */ {
bevt_195_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_196_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_195_tmpvar_phold.bevi_int == bevt_196_tmpvar_phold.bevi_int) {
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_194_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevl_pn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_198_tmpvar_phold = beva_node.bem_containedGet_0();
if (bevt_198_tmpvar_phold == null) {
bevt_197_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_197_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_197_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevt_201_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_200_tmpvar_phold = bevt_201_tmpvar_phold.bem_lastGet_0();
if (bevt_200_tmpvar_phold == null) {
bevt_199_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_199_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_199_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 213 */
 else  /* Line: 213 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 213 */ {
bevt_204_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_203_tmpvar_phold = bevt_204_tmpvar_phold.bem_lastGet_0();
bevt_202_tmpvar_phold = bevt_203_tmpvar_phold.bemd_0(1595262430, BEL_4_Base.bevn_nlcGet_0);
bevl_pn.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevt_202_tmpvar_phold);
} /* Line: 214 */
 else  /* Line: 215 */ {
bevl_pn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
} /* Line: 216 */
bevt_205_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
bevl_pn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_205_tmpvar_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_pn);
} /* Line: 219 */
} /* Line: 75 */
} /* Line: 75 */
} /* Line: 75 */
} /* Line: 75 */
bevt_206_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_206_tmpvar_phold;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_classnpGet_0() {
return bevp_classnp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classnpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {24, 25, 25, 26, 27, 27, 28, 28, 29, 30, 30, 31, 32, 33, 33, 34, 35, 35, 36, 37, 38, 38, 39, 40, 41, 42, 43, 43, 44, 45, 49, 50, 50, 51, 52, 52, 53, 54, 55, 55, 56, 56, 57, 58, 62, 63, 63, 64, 65, 65, 66, 67, 75, 75, 75, 75, 76, 76, 76, 76, 77, 77, 77, 78, 78, 79, 79, 79, 79, 80, 80, 81, 82, 82, 82, 82, 83, 83, 84, 84, 84, 85, 85, 86, 87, 88, 88, 88, 88, 89, 89, 89, 89, 89, 89, 0, 0, 0, 91, 92, 92, 93, 93, 94, 94, 94, 95, 95, 95, 96, 96, 96, 96, 96, 97, 97, 97, 98, 98, 98, 99, 100, 101, 102, 102, 103, 103, 103, 104, 105, 105, 105, 106, 106, 106, 107, 108, 109, 109, 114, 114, 114, 115, 115, 116, 117, 118, 118, 118, 118, 119, 119, 119, 119, 119, 119, 0, 0, 0, 121, 122, 122, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 126, 126, 127, 127, 127, 128, 128, 128, 130, 130, 131, 131, 132, 133, 134, 134, 135, 137, 137, 137, 138, 139, 140, 140, 141, 143, 144, 145, 146, 146, 147, 147, 147, 148, 149, 150, 150, 150, 152, 153, 159, 159, 159, 159, 160, 160, 160, 161, 161, 161, 163, 163, 163, 163, 163, 163, 0, 0, 0, 164, 164, 165, 165, 165, 166, 166, 166, 166, 166, 166, 166, 0, 0, 0, 167, 168, 168, 168, 169, 169, 169, 169, 170, 170, 170, 173, 173, 173, 173, 174, 174, 174, 177, 177, 177, 178, 180, 180, 180, 180, 180, 180, 181, 181, 181, 181, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 184, 184, 185, 185, 185, 185, 185, 0, 0, 0, 186, 186, 186, 186, 186, 188, 188, 189, 189, 189, 189, 189, 0, 0, 0, 194, 194, 194, 194, 195, 195, 195, 197, 197, 197, 197, 198, 198, 198, 202, 202, 202, 202, 203, 204, 204, 204, 204, 204, 204, 204, 0, 0, 0, 205, 205, 205, 205, 207, 209, 209, 210, 211, 211, 211, 211, 212, 213, 213, 213, 213, 213, 213, 213, 0, 0, 0, 214, 214, 214, 214, 216, 218, 218, 219, 221, 221, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 109, 110, 111, 112, 113, 114, 115, 116, 343, 344, 345, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 362, 363, 364, 369, 370, 371, 372, 373, 374, 375, 378, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 395, 396, 397, 398, 399, 401, 404, 408, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 451, 452, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 468, 469, 470, 471, 472, 474, 477, 481, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 546, 547, 548, 553, 554, 555, 560, 561, 562, 563, 565, 566, 568, 569, 570, 575, 576, 579, 583, 586, 587, 588, 589, 590, 592, 593, 594, 596, 597, 598, 599, 601, 604, 608, 611, 612, 613, 614, 616, 617, 618, 619, 620, 621, 622, 626, 627, 628, 629, 630, 631, 632, 635, 636, 637, 638, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 665, 666, 667, 672, 673, 674, 675, 677, 680, 684, 687, 688, 689, 690, 691, 693, 694, 695, 700, 701, 702, 703, 705, 708, 712, 715, 716, 717, 718, 720, 721, 722, 724, 725, 726, 727, 729, 730, 731, 737, 738, 739, 744, 745, 746, 747, 752, 753, 754, 755, 760, 761, 764, 768, 771, 772, 773, 774, 777, 779, 780, 781, 784, 785, 786, 791, 792, 793, 794, 799, 800, 801, 802, 807, 808, 811, 815, 818, 819, 820, 821, 824, 826, 827, 828, 834, 835, 838, 841};
/* BEGIN LINEINFO 
assign 1 24 50
new 1 24 50
assign 1 25 51
VARGet 0 25 51
typenameSet 1 25 52
assign 1 26 53
new 0 26 53
assign 1 27 54
new 0 27 54
nameSet 1 27 55
assign 1 28 56
new 0 28 56
isTypedSet 1 28 57
namepathSet 1 29 58
assign 1 30 59
new 0 30 59
isArgSet 1 30 60
heldSet 1 31 61
assign 1 32 62
new 1 32 62
assign 1 33 63
METHODGet 0 33 63
typenameSet 1 33 64
assign 1 34 65
new 0 34 65
assign 1 35 66
new 0 35 66
isGenAccessorSet 1 35 67
heldSet 1 36 68
assign 1 37 69
new 1 37 69
assign 1 38 70
PARENSGet 0 38 70
typenameSet 1 38 71
addValue 1 39 72
addValue 1 40 73
addVariable 0 41 74
assign 1 42 75
new 1 42 75
assign 1 43 76
BRACESGet 0 43 76
typenameSet 1 43 77
addValue 1 44 78
return 1 45 79
assign 1 49 89
new 1 49 89
assign 1 50 90
CALLGet 0 50 90
typenameSet 1 50 91
assign 1 51 92
new 0 51 92
assign 1 52 93
new 0 52 93
nameSet 1 52 94
heldSet 1 53 95
assign 1 54 96
new 1 54 96
assign 1 55 97
VARGet 0 55 97
typenameSet 1 55 98
assign 1 56 99
new 0 56 99
heldSet 1 56 100
addValue 1 57 101
return 1 58 102
assign 1 62 109
new 1 62 109
assign 1 63 110
CALLGet 0 63 110
typenameSet 1 63 111
assign 1 64 112
new 0 64 112
assign 1 65 113
new 0 65 113
nameSet 1 65 114
heldSet 1 66 115
return 1 67 116
assign 1 75 343
typenameGet 0 75 343
assign 1 75 344
METHODGet 0 75 344
assign 1 75 345
equals 1 75 350
assign 1 76 351
containedGet 0 76 351
assign 1 76 352
firstGet 0 76 352
assign 1 76 353
containedGet 0 76 353
assign 1 76 354
firstGet 0 76 354
assign 1 77 355
heldGet 0 77 355
assign 1 77 356
new 0 77 356
isTypedSet 1 77 357
assign 1 78 358
heldGet 0 78 358
namepathSet 1 78 359
assign 1 79 362
typenameGet 0 79 362
assign 1 79 363
CLASSGet 0 79 363
assign 1 79 364
equals 1 79 369
assign 1 80 370
heldGet 0 80 370
assign 1 80 371
namepathGet 0 80 371
assign 1 81 372
new 0 81 372
assign 1 82 373
heldGet 0 82 373
assign 1 82 374
orderedVarsGet 0 82 374
assign 1 82 375
iteratorGet 0 82 375
assign 1 82 378
hasNextGet 0 82 378
assign 1 83 380
nextGet 0 83 380
assign 1 83 381
heldGet 0 83 381
assign 1 84 382
nameGet 0 84 382
assign 1 84 383
copy 0 84 383
nameSet 1 84 384
assign 1 85 385
new 0 85 385
accessorTypeSet 1 85 386
toAccessorName 0 86 387
assign 1 87 388
nameGet 0 87 388
assign 1 88 389
nameGet 0 88 389
assign 1 88 390
new 0 88 390
assign 1 88 391
add 1 88 391
nameSet 1 88 392
assign 1 89 393
isDeclaredGet 0 89 393
assign 1 89 395
heldGet 0 89 395
assign 1 89 396
methodsGet 0 89 396
assign 1 89 397
nameGet 0 89 397
assign 1 89 398
has 1 89 398
assign 1 89 399
not 0 89 399
assign 1 0 401
assign 1 0 404
assign 1 0 408
assign 1 91 411
getAccessor 1 91 411
assign 1 92 412
heldGet 0 92 412
propertySet 1 92 413
assign 1 93 414
heldGet 0 93 414
orgNameSet 1 93 415
assign 1 94 416
heldGet 0 94 416
assign 1 94 417
nameGet 0 94 417
nameSet 1 94 418
assign 1 95 419
heldGet 0 95 419
assign 1 95 420
new 0 95 420
numargsSet 1 95 421
assign 1 96 422
heldGet 0 96 422
assign 1 96 423
methodsGet 0 96 423
assign 1 96 424
heldGet 0 96 424
assign 1 96 425
nameGet 0 96 425
put 2 96 426
assign 1 97 427
heldGet 0 97 427
assign 1 97 428
orderedMethodsGet 0 97 428
addValue 1 97 429
assign 1 98 430
containedGet 0 98 430
assign 1 98 431
lastGet 0 98 431
addValue 1 98 432
assign 1 99 433
getRetNode 1 99 433
assign 1 100 434
new 1 100 434
copyLoc 1 101 435
assign 1 102 436
VARGet 0 102 436
typenameSet 1 102 437
assign 1 103 438
nameGet 0 103 438
assign 1 103 439
copy 0 103 439
heldSet 1 103 440
addValue 1 104 441
assign 1 105 442
containedGet 0 105 442
assign 1 105 443
lastGet 0 105 443
addValue 1 105 444
assign 1 106 445
containedGet 0 106 445
assign 1 106 446
firstGet 0 106 446
syncVariable 1 106 447
syncVariable 1 107 448
assign 1 108 449
isTypedGet 0 108 449
assign 1 109 451
heldGet 0 109 451
rtypeSet 1 109 452
assign 1 114 455
nameGet 0 114 455
assign 1 114 456
copy 0 114 456
nameSet 1 114 457
assign 1 115 458
new 0 115 458
accessorTypeSet 1 115 459
toAccessorName 0 116 460
assign 1 117 461
nameGet 0 117 461
assign 1 118 462
nameGet 0 118 462
assign 1 118 463
new 0 118 463
assign 1 118 464
add 1 118 464
nameSet 1 118 465
assign 1 119 466
isDeclaredGet 0 119 466
assign 1 119 468
heldGet 0 119 468
assign 1 119 469
methodsGet 0 119 469
assign 1 119 470
nameGet 0 119 470
assign 1 119 471
has 1 119 471
assign 1 119 472
not 0 119 472
assign 1 0 474
assign 1 0 477
assign 1 0 481
assign 1 121 484
getAccessor 1 121 484
assign 1 122 485
heldGet 0 122 485
propertySet 1 122 486
assign 1 123 487
heldGet 0 123 487
orgNameSet 1 123 488
assign 1 124 489
heldGet 0 124 489
assign 1 124 490
nameGet 0 124 490
nameSet 1 124 491
assign 1 125 492
heldGet 0 125 492
assign 1 125 493
new 0 125 493
numargsSet 1 125 494
assign 1 126 495
heldGet 0 126 495
assign 1 126 496
methodsGet 0 126 496
assign 1 126 497
heldGet 0 126 497
assign 1 126 498
nameGet 0 126 498
put 2 126 499
assign 1 127 500
heldGet 0 127 500
assign 1 127 501
orderedMethodsGet 0 127 501
addValue 1 127 502
assign 1 128 503
containedGet 0 128 503
assign 1 128 504
lastGet 0 128 504
addValue 1 128 505
assign 1 130 506
new 0 130 506
assign 1 130 507
tmpVar 2 130 507
assign 1 131 508
new 0 131 508
isArgSet 1 131 509
assign 1 132 510
new 1 132 510
copyLoc 1 133 511
assign 1 134 512
VARGet 0 134 512
typenameSet 1 134 513
heldSet 1 135 514
assign 1 137 515
containedGet 0 137 515
assign 1 137 516
firstGet 0 137 516
addValue 1 137 517
assign 1 138 518
new 0 138 518
copyLoc 1 139 519
assign 1 140 520
VARGet 0 140 520
typenameSet 1 140 521
heldSet 1 141 522
assign 1 143 523
getAsNode 1 143 523
assign 1 144 524
new 1 144 524
copyLoc 1 145 525
assign 1 146 526
VARGet 0 146 526
typenameSet 1 146 527
assign 1 147 528
nameGet 0 147 528
assign 1 147 529
copy 0 147 529
heldSet 1 147 530
addValue 1 148 531
addValue 1 149 532
assign 1 150 533
containedGet 0 150 533
assign 1 150 534
lastGet 0 150 534
addValue 1 150 535
addVariable 0 152 536
syncVariable 1 153 537
assign 1 159 546
typenameGet 0 159 546
assign 1 159 547
CALLGet 0 159 547
assign 1 159 548
equals 1 159 553
assign 1 160 554
heldGet 0 160 554
assign 1 160 555
undef 1 160 560
assign 1 161 561
new 0 161 561
assign 1 161 562
new 2 161 562
throw 1 161 563
assign 1 163 565
heldGet 0 163 565
assign 1 163 566
isConstructGet 0 163 566
assign 1 163 568
heldGet 0 163 568
assign 1 163 569
newNpGet 0 163 569
assign 1 163 570
undef 1 163 575
assign 1 0 576
assign 1 0 579
assign 1 0 583
assign 1 164 586
containedGet 0 164 586
assign 1 164 587
firstGet 0 164 587
assign 1 165 588
typenameGet 0 165 588
assign 1 165 589
NAMEPATHGet 0 165 589
assign 1 165 590
notEquals 1 165 590
assign 1 166 592
typenameGet 0 166 592
assign 1 166 593
VARGet 0 166 593
assign 1 166 594
equals 1 166 594
assign 1 166 596
heldGet 0 166 596
assign 1 166 597
nameGet 0 166 597
assign 1 166 598
new 0 166 598
assign 1 166 599
equals 1 166 599
assign 1 0 601
assign 1 0 604
assign 1 0 608
assign 1 167 611
secondGet 0 167 611
assign 1 168 612
typenameGet 0 168 612
assign 1 168 613
NAMEPATHGet 0 168 613
assign 1 168 614
notEquals 1 168 614
assign 1 169 616
new 0 169 616
assign 1 169 617
toString 0 169 617
assign 1 169 618
add 1 169 618
print 0 169 619
assign 1 170 620
new 0 170 620
assign 1 170 621
new 2 170 621
throw 1 170 622
assign 1 173 626
new 0 173 626
assign 1 173 627
toString 0 173 627
assign 1 173 628
add 1 173 628
print 0 173 629
assign 1 174 630
new 0 174 630
assign 1 174 631
new 2 174 631
throw 1 174 632
assign 1 177 635
heldGet 0 177 635
assign 1 177 636
heldGet 0 177 636
newNpSet 1 177 637
delete 0 178 638
assign 1 180 640
heldGet 0 180 640
assign 1 180 641
containedGet 0 180 641
assign 1 180 642
lengthGet 0 180 642
assign 1 180 643
new 0 180 643
assign 1 180 644
subtract 1 180 644
numargsSet 1 180 645
assign 1 181 646
heldGet 0 181 646
assign 1 181 647
heldGet 0 181 647
assign 1 181 648
nameGet 0 181 648
orgNameSet 1 181 649
assign 1 182 650
heldGet 0 182 650
assign 1 182 651
heldGet 0 182 651
assign 1 182 652
nameGet 0 182 652
assign 1 182 653
new 0 182 653
assign 1 182 654
add 1 182 654
assign 1 182 655
heldGet 0 182 655
assign 1 182 656
numargsGet 0 182 656
assign 1 182 657
toString 0 182 657
assign 1 182 658
add 1 182 658
nameSet 1 182 659
assign 1 183 660
heldGet 0 183 660
assign 1 183 661
orgNameGet 0 183 661
assign 1 183 662
new 0 183 662
assign 1 183 663
equals 1 183 663
assign 1 184 665
containedGet 0 184 665
assign 1 184 666
firstGet 0 184 666
assign 1 185 667
def 1 185 672
assign 1 185 673
typenameGet 0 185 673
assign 1 185 674
VARGet 0 185 674
assign 1 185 675
equals 1 185 675
assign 1 0 677
assign 1 0 680
assign 1 0 684
assign 1 186 687
heldGet 0 186 687
assign 1 186 688
heldGet 0 186 688
assign 1 186 689
numAssignsGet 0 186 689
assign 1 186 690
increment 0 186 690
numAssignsSet 1 186 691
assign 1 188 693
containedGet 0 188 693
assign 1 188 694
secondGet 0 188 694
assign 1 189 695
def 1 189 700
assign 1 189 701
typenameGet 0 189 701
assign 1 189 702
CALLGet 0 189 702
assign 1 189 703
equals 1 189 703
assign 1 0 705
assign 1 0 708
assign 1 0 712
assign 1 194 715
heldGet 0 194 715
assign 1 194 716
nameGet 0 194 716
assign 1 194 717
new 0 194 717
assign 1 194 718
equals 1 194 718
assign 1 195 720
heldGet 0 195 720
assign 1 195 721
new 0 195 721
isOnceSet 1 195 722
assign 1 197 724
heldGet 0 197 724
assign 1 197 725
nameGet 0 197 725
assign 1 197 726
new 0 197 726
assign 1 197 727
equals 1 197 727
assign 1 198 729
heldGet 0 198 729
assign 1 198 730
new 0 198 730
isManySet 1 198 731
assign 1 202 737
typenameGet 0 202 737
assign 1 202 738
BRACESGet 0 202 738
assign 1 202 739
equals 1 202 744
assign 1 203 745
new 1 203 745
assign 1 204 746
containedGet 0 204 746
assign 1 204 747
def 1 204 752
assign 1 204 753
containedGet 0 204 753
assign 1 204 754
lastGet 0 204 754
assign 1 204 755
def 1 204 760
assign 1 0 761
assign 1 0 764
assign 1 0 768
assign 1 205 771
containedGet 0 205 771
assign 1 205 772
lastGet 0 205 772
assign 1 205 773
nlcGet 0 205 773
nlcSet 1 205 774
copyLoc 1 207 777
assign 1 209 779
RBRACESGet 0 209 779
typenameSet 1 209 780
addValue 1 210 781
assign 1 211 784
typenameGet 0 211 784
assign 1 211 785
PARENSGet 0 211 785
assign 1 211 786
equals 1 211 791
assign 1 212 792
new 1 212 792
assign 1 213 793
containedGet 0 213 793
assign 1 213 794
def 1 213 799
assign 1 213 800
containedGet 0 213 800
assign 1 213 801
lastGet 0 213 801
assign 1 213 802
def 1 213 807
assign 1 0 808
assign 1 0 811
assign 1 0 815
assign 1 214 818
containedGet 0 214 818
assign 1 214 819
lastGet 0 214 819
assign 1 214 820
nlcGet 0 214 820
nlcSet 1 214 821
copyLoc 1 216 824
assign 1 218 826
RPARENSGet 0 218 826
typenameSet 1 218 827
addValue 1 219 828
assign 1 221 834
nextDescendGet 0 221 834
return 1 221 835
return 1 0 838
assign 1 0 841
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 487303277: return bem_classnpGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 2055890305: return bem_getRetNode_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 498385530: return bem_classnpSet_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 654182780: return bem_getAsNode_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1438955473: return bem_getAccessor_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass12();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass12.bevs_inst = (BEC_3_5_5_6_BuildVisitPass12)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass12.bevs_inst;
}
}
}
