namespace be.BEL_4_Base {
/* IO:File: source/build/Pass12.be */
public class BEC_3_5_5_8_BuildVisitAllCalls : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_8_BuildVisitAllCalls() { }
static BEC_3_5_5_8_BuildVisitAllCalls() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x41,0x6C,0x6C,0x43,0x61,0x6C,0x6C,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
public static new BEC_3_5_5_8_BuildVisitAllCalls bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_10_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_3_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_2_tmpvar_phold.bevi_int == bevt_3_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 652 */ {
bevt_4_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_0_tmpvar_loop = bevt_4_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 653 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 653 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpvar_phold = bevl_cci.bem_typenameGet_0();
bevt_8_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_7_tmpvar_phold.bevi_int == bevt_8_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 654 */ {
bevt_9_tmpvar_phold = bevl_cci.bem_heldGet_0();
bevt_9_tmpvar_phold.bemd_1(474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 655 */
} /* Line: 654 */
 else  /* Line: 653 */ {
break;
} /* Line: 653 */
} /* Line: 653 */
} /* Line: 653 */
bevt_10_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_10_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {652, 652, 652, 652, 653, 653, 0, 653, 653, 654, 654, 654, 654, 655, 655, 659, 659, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 33, 34, 35, 35, 38, 40, 41, 42, 43, 48, 49, 50, 58, 59, 62, 65};
/* BEGIN LINEINFO 
assign 1 652 26
typenameGet 0 652 26
assign 1 652 27
CALLGet 0 652 27
assign 1 652 28
equals 1 652 33
assign 1 653 34
containedGet 0 653 34
assign 1 653 35
iteratorGet 0 0 35
assign 1 653 38
hasNextGet 0 653 38
assign 1 653 40
nextGet 0 653 40
assign 1 654 41
typenameGet 0 654 41
assign 1 654 42
VARGet 0 654 42
assign 1 654 43
equals 1 654 48
assign 1 655 49
heldGet 0 655 49
addCall 1 655 50
assign 1 659 58
nextDescendGet 0 659 58
return 1 659 59
return 1 0 62
assign 1 0 65
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_8_BuildVisitAllCalls();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_8_BuildVisitAllCalls.bevs_inst = (BEC_3_5_5_8_BuildVisitAllCalls)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_8_BuildVisitAllCalls.bevs_inst;
}
}
}
