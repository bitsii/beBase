namespace be.BEL_4_Base {
/* IO:File: source/build/Pass9.be */
public class BEC_3_5_5_5_BuildVisitPass9 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
static BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 44));
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x53,0x45,0x54};
private static byte[] bels_3 = {0x47,0x45,0x54};
private static byte[] bels_4 = {0x53,0x45,0x54};
private static byte[] bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_6 = {0x70,0x75,0x74};
private static byte[] bels_7 = {0x67,0x65,0x74};
private static byte[] bels_8 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bels_9 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_11 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_12 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_13 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_14 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bels_15 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_16 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static new BEC_3_5_5_5_BuildVisitPass9 bevs_inst;
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lvar = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_22_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_44_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_67_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_72_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_74_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_78_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_113_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_119_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_121_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_125_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_141_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 36 */ {
beva_node.bem_initContained_0();
bevt_8_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_8_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 41 */ {
bevt_9_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 41 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_11_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 44 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_14_tmpvar_phold == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevt_17_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_i.bemd_1(1671186230, BEL_4_Base.bevn_beforeInsert_1, bevt_16_tmpvar_phold);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 47 */
 else  /* Line: 48 */ {
bevt_18_tmpvar_phold = bevo_0;
bevt_21_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_estr = bevt_18_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_22_tmpvar_phold);
} /* Line: 50 */
} /* Line: 45 */
} /* Line: 44 */
 else  /* Line: 41 */ {
break;
} /* Line: 41 */
} /* Line: 41 */
bevt_23_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_23_tmpvar_phold;
} /* Line: 54 */
 else  /* Line: 36 */ {
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_equals_1(bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_27_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_c.bemd_1(671626972, BEL_4_Base.bevn_wasAccessorSet_1, bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_typenameGet_0();
bevt_31_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_equals_1(bevt_31_tmpvar_phold);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_35_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_heldGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_36_tmpvar_phold);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 62 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 62 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 62 */
 else  /* Line: 62 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 62 */ {
bevt_37_tmpvar_phold = beva_node.bem_isFirstGet_0();
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 62 */
 else  /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 62 */ {
bevt_38_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_2));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_38_tmpvar_phold);
} /* Line: 63 */
 else  /* Line: 64 */ {
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_3));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_39_tmpvar_phold);
} /* Line: 65 */
bevt_40_tmpvar_phold = bevl_ac.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_40_tmpvar_phold);
bevl_c.bemd_0(173192194, BEL_4_Base.bevn_toAccessorName_0);
bevt_42_tmpvar_phold = bevl_c.bemd_0(783669222, BEL_4_Base.bevn_accessorTypeGet_0);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_4));
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpvar_phold);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 69 */ {
bevt_44_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_44_tmpvar_phold.bem_heldSet_1(bevl_c);
bevt_45_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_45_tmpvar_phold.bem_firstGet_0();
bevt_46_tmpvar_phold = bevl_ntarg.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_47_tmpvar_phold);
bevt_48_tmpvar_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_48_tmpvar_phold);
bevt_50_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_nextDescendGet_0();
return bevt_49_tmpvar_phold;
} /* Line: 76 */
 else  /* Line: 77 */ {
bevt_51_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_51_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 79 */
bevt_52_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_52_tmpvar_phold;
} /* Line: 81 */
 else  /* Line: 36 */ {
bevt_54_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_equals_1(bevt_55_tmpvar_phold);
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_58_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_equals_1(bevt_59_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevt_63_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_heldGet_0();
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_64_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_5));
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_64_tmpvar_phold);
if (bevt_60_tmpvar_phold != null && bevt_60_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_60_tmpvar_phold).bevi_bool) /* Line: 86 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 86 */ {
bevt_65_tmpvar_phold = beva_node.bem_isFirstGet_0();
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 86 */ {
bevl_isPut = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 88 */
 else  /* Line: 89 */ {
bevl_isPut = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 91 */
if (bevl_isPut != null && bevl_isPut is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_isPut).bevi_bool) /* Line: 93 */ {
bevt_66_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_6));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_67_tmpvar_phold.bem_heldSet_1(bevl_c);
bevt_68_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_68_tmpvar_phold.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_69_tmpvar_phold = bevl_ntarg.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_72_tmpvar_phold.bem_addValue_1(bevl_narg2);
bevt_73_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_73_tmpvar_phold.bem_addValue_1(bevl_narg3);
bevt_75_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_nextDescendGet_0();
return bevt_74_tmpvar_phold;
} /* Line: 111 */
 else  /* Line: 112 */ {
bevt_76_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_7));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_77_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 119 */
bevt_78_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_78_tmpvar_phold;
} /* Line: 121 */
} /* Line: 36 */
} /* Line: 36 */
bevt_80_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_81_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_equals_1(bevt_81_tmpvar_phold);
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_82_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_82_tmpvar_phold);
bevt_83_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_83_tmpvar_phold.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_84_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lin = bevt_84_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_85_tmpvar_phold = bevl_lin.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lvar = bevt_85_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_toit = bevl_lin.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_pnode.bemd_1(443337441, BEL_4_Base.bevn_containedSet_1, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_8));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_87_tmpvar_phold, bevp_build);
bevl_tmpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_88_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_88_tmpvar_phold);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gic);
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_9));
bevl_gic.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(666017654, BEL_4_Base.bevn_wasForeachGennedSet_1, bevt_90_tmpvar_phold);
bevl_gin.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_91_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_91_tmpvar_phold);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asc);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_10));
bevl_asc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_92_tmpvar_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpn);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn);
bevl_tmpn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_93_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_93_tmpvar_phold);
bevl_tmpnt.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_94_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_94_tmpvar_phold);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tcc);
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_11));
bevl_tcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_95_tmpvar_phold);
bevl_tcn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpnt);
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_96_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_96_tmpvar_phold);
bevl_tmpng.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_97_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_97_tmpvar_phold);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iagc);
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_12));
bevl_iagc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_98_tmpvar_phold);
bevl_iagn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_99_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_99_tmpvar_phold);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iasc);
bevt_100_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_13));
bevl_iasc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_100_tmpvar_phold);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lvar);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_iagn);
bevl_brnode.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 213 */
bevt_102_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_103_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_101_tmpvar_phold = bevt_102_tmpvar_phold.bem_equals_1(bevt_103_tmpvar_phold);
if (bevt_101_tmpvar_phold.bevi_bool) /* Line: 215 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_104_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_104_tmpvar_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_105_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_105_tmpvar_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_106_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_106_tmpvar_phold);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevt_108_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_108_tmpvar_phold == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_110_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_111_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_14));
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_111_tmpvar_phold);
if (bevt_109_tmpvar_phold != null && bevt_109_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_109_tmpvar_phold).bevi_bool) /* Line: 227 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
 else  /* Line: 227 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 227 */ {
bevt_112_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_15));
bevl_loopif.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_112_tmpvar_phold);
} /* Line: 228 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_113_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_113_tmpvar_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_114_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_114_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_115_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_115_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_116_tmpvar_phold = bevl_lnode.bemd_0(1779180144, BEL_4_Base.bevn_nextDescendGet_0);
return (BEC_2_5_4_BuildNode) bevt_116_tmpvar_phold;
} /* Line: 242 */
 else  /* Line: 215 */ {
bevt_118_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_119_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bem_equals_1(bevt_119_tmpvar_phold);
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_120_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_120_tmpvar_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevt_121_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_121_tmpvar_phold.bem_firstGet_0();
bevl_pnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_124_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_125_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_125_tmpvar_phold);
if (bevt_122_tmpvar_phold != null && bevt_122_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_122_tmpvar_phold).bevi_bool) /* Line: 250 */ {
bevt_127_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bels_16));
bevt_126_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 251 */
bevt_128_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_init = bevt_128_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_cond = bevl_pnode.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_atStep = null;
bevt_131_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_132_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_129_tmpvar_phold = bevt_130_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_132_tmpvar_phold);
if (bevt_129_tmpvar_phold != null && bevt_129_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_129_tmpvar_phold).bevi_bool) /* Line: 256 */ {
bevl_atStep = bevl_pnode.bemd_0(978128800, BEL_4_Base.bevn_thirdGet_0);
bevl_atStep.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 258 */
bevl_init.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevl_lnode.bemd_1(1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_133_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_133_tmpvar_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_134_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_134_tmpvar_phold);
bevl_loopif.bemd_1(875977779, BEL_4_Base.bevn_takeContents_1, beva_node);
if (bevl_atStep == null) {
bevt_135_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_137_tmpvar_phold = bevl_loopif.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_136_tmpvar_phold = bevt_137_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_136_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_atStep);
} /* Line: 274 */
bevl_loopif.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_pnode);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_138_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_138_tmpvar_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_139_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_139_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_140_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_140_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 291 */
} /* Line: 215 */
bevt_141_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_141_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {36, 40, 41, 43, 44, 45, 46, 47, 49, 50, 54, 55, 59, 60, 61, 62, 0, 62, 0, 63, 65, 67, 68, 69, 70, 71, 73, 74, 75, 76, 78, 79, 81, 82, 84, 85, 86, 0, 86, 0, 88, 91, 94, 95, 96, 99, 100, 102, 103, 105, 106, 107, 109, 110, 111, 117, 118, 119, 121, 123, 124, 125, 126, 127, 128, 129, 130, 149, 150, 151, 152, 153, 155, 156, 157, 158, 159, 160, 161, 163, 164, 165, 166, 167, 168, 169, 170, 172, 173, 175, 176, 177, 178, 180, 181, 182, 183, 184, 185, 186, 188, 190, 191, 192, 193, 195, 196, 197, 198, 199, 200, 201, 203, 204, 205, 206, 207, 208, 209, 210, 212, 213, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 0, 228, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 253, 254, 255, 256, 257, 258, 260, 262, 263, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 293};
public static new int[] bevs_smnlec
 = new int[] {207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207, 207};
/* BEGIN LINEINFO 
assign 1 36 207
typenameGet 0 36 207
assign 1 36 207
CALLGet 0 36 207
assign 1 36 207
equals 1 36 207
initContained 0 40 207
assign 1 41 207
containedGet 0 41 207
assign 1 41 207
iteratorGet 0 41 207
assign 1 41 207
hasNextGet 0 41 207
assign 1 43 207
nextGet 0 43 207
assign 1 44 207
typenameGet 0 44 207
assign 1 44 207
PARENSGet 0 44 207
assign 1 44 207
equals 1 44 207
assign 1 45 207
containedGet 0 45 207
assign 1 45 207
firstNodeGet 0 45 207
assign 1 45 207
def 1 45 207
assign 1 46 207
containedGet 0 46 207
assign 1 46 207
firstGet 0 46 207
beforeInsert 1 46 207
delete 0 47 207
assign 1 49 207
new 0 49 207
assign 1 49 207
containedGet 0 49 207
assign 1 49 207
lengthGet 0 49 207
assign 1 49 207
toString 0 49 207
assign 1 49 207
add 1 49 207
assign 1 50 207
new 2 50 207
throw 1 50 207
assign 1 54 207
nextDescendGet 0 54 207
return 1 54 207
assign 1 55 207
typenameGet 0 55 207
assign 1 55 207
ACCESSORGet 0 55 207
assign 1 55 207
equals 1 55 207
assign 1 59 207
heldGet 0 59 207
assign 1 60 207
new 0 60 207
assign 1 61 207
new 0 61 207
wasAccessorSet 1 61 207
assign 1 62 207
containerGet 0 62 207
assign 1 62 207
typenameGet 0 62 207
assign 1 62 207
CALLGet 0 62 207
assign 1 62 207
equals 1 62 207
assign 1 62 207
containerGet 0 62 207
assign 1 62 207
heldGet 0 62 207
assign 1 62 207
nameGet 0 62 207
assign 1 62 207
new 0 62 207
assign 1 62 207
equals 1 62 207
assign 1 0 207
assign 1 0 207
assign 1 0 207
assign 1 62 207
isFirstGet 0 62 207
assign 1 0 207
assign 1 0 207
assign 1 0 207
assign 1 63 207
new 0 63 207
accessorTypeSet 1 63 207
assign 1 65 207
new 0 65 207
accessorTypeSet 1 65 207
assign 1 67 207
nameGet 0 67 207
nameSet 1 67 207
toAccessorName 0 68 207
assign 1 69 207
accessorTypeGet 0 69 207
assign 1 69 207
new 0 69 207
assign 1 69 207
equals 1 69 207
assign 1 70 207
containerGet 0 70 207
heldSet 1 70 207
assign 1 71 207
containedGet 0 71 207
assign 1 71 207
firstGet 0 71 207
assign 1 73 207
typenameGet 0 73 207
typenameSet 1 73 207
assign 1 74 207
heldGet 0 74 207
heldSet 1 74 207
assign 1 75 207
containedGet 0 75 207
containedSet 1 75 207
assign 1 76 207
containerGet 0 76 207
assign 1 76 207
nextDescendGet 0 76 207
return 1 76 207
assign 1 78 207
CALLGet 0 78 207
typenameSet 1 78 207
heldSet 1 79 207
assign 1 81 207
nextDescendGet 0 81 207
return 1 81 207
assign 1 82 207
typenameGet 0 82 207
assign 1 82 207
IDXACCGet 0 82 207
assign 1 82 207
equals 1 82 207
assign 1 84 207
heldGet 0 84 207
assign 1 85 207
new 0 85 207
assign 1 86 207
containerGet 0 86 207
assign 1 86 207
typenameGet 0 86 207
assign 1 86 207
CALLGet 0 86 207
assign 1 86 207
equals 1 86 207
assign 1 86 207
containerGet 0 86 207
assign 1 86 207
heldGet 0 86 207
assign 1 86 207
nameGet 0 86 207
assign 1 86 207
new 0 86 207
assign 1 86 207
equals 1 86 207
assign 1 0 207
assign 1 0 207
assign 1 0 207
assign 1 86 207
isFirstGet 0 86 207
assign 1 0 207
assign 1 0 207
assign 1 0 207
assign 1 88 207
new 0 88 207
assign 1 91 207
new 0 91 207
assign 1 94 207
new 0 94 207
nameSet 1 94 207
assign 1 95 207
containerGet 0 95 207
heldSet 1 95 207
assign 1 96 207
containedGet 0 96 207
assign 1 96 207
firstGet 0 96 207
assign 1 99 207
nextPeerGet 0 99 207
assign 1 100 207
nextPeerGet 0 100 207
delete 0 102 207
delete 0 103 207
assign 1 105 207
typenameGet 0 105 207
typenameSet 1 105 207
assign 1 106 207
heldGet 0 106 207
heldSet 1 106 207
assign 1 107 207
containedGet 0 107 207
containedSet 1 107 207
assign 1 109 207
containerGet 0 109 207
addValue 1 109 207
assign 1 110 207
containerGet 0 110 207
addValue 1 110 207
assign 1 111 207
containerGet 0 111 207
assign 1 111 207
nextDescendGet 0 111 207
return 1 111 207
assign 1 117 207
new 0 117 207
nameSet 1 117 207
assign 1 118 207
CALLGet 0 118 207
typenameSet 1 118 207
heldSet 1 119 207
assign 1 121 207
nextDescendGet 0 121 207
return 1 121 207
assign 1 123 207
typenameGet 0 123 207
assign 1 123 207
FOREACHGet 0 123 207
assign 1 123 207
equals 1 123 207
assign 1 124 207
WHILEGet 0 124 207
typenameSet 1 124 207
assign 1 125 207
containedGet 0 125 207
assign 1 125 207
firstGet 0 125 207
assign 1 126 207
secondGet 0 126 207
assign 1 127 207
containedGet 0 127 207
assign 1 127 207
firstGet 0 127 207
assign 1 128 207
containedGet 0 128 207
assign 1 128 207
firstGet 0 128 207
assign 1 129 207
secondGet 0 129 207
containedSet 1 130 207
assign 1 149 207
new 1 149 207
copyLoc 1 150 207
assign 1 151 207
VARGet 0 151 207
typenameSet 1 151 207
assign 1 152 207
new 0 152 207
assign 1 152 207
tmpVar 2 152 207
heldSet 1 153 207
assign 1 155 207
new 1 155 207
assign 1 156 207
CALLGet 0 156 207
typenameSet 1 156 207
assign 1 157 207
new 0 157 207
heldSet 1 158 207
assign 1 159 207
new 0 159 207
nameSet 1 159 207
assign 1 160 207
new 0 160 207
wasForeachGennedSet 1 160 207
addValue 1 161 207
assign 1 163 207
new 1 163 207
copyLoc 1 164 207
assign 1 165 207
CALLGet 0 165 207
typenameSet 1 165 207
assign 1 166 207
new 0 166 207
heldSet 1 167 207
assign 1 168 207
new 0 168 207
nameSet 1 168 207
addValue 1 169 207
addValue 1 170 207
beforeInsert 1 172 207
addVariable 0 173 207
assign 1 175 207
new 1 175 207
copyLoc 1 176 207
assign 1 177 207
VARGet 0 177 207
typenameSet 1 177 207
heldSet 1 178 207
assign 1 180 207
new 1 180 207
copyLoc 1 181 207
assign 1 182 207
CALLGet 0 182 207
typenameSet 1 182 207
assign 1 183 207
new 0 183 207
heldSet 1 184 207
assign 1 185 207
new 0 185 207
nameSet 1 185 207
addValue 1 186 207
addValue 1 188 207
assign 1 190 207
new 1 190 207
copyLoc 1 191 207
assign 1 192 207
VARGet 0 192 207
typenameSet 1 192 207
heldSet 1 193 207
assign 1 195 207
new 1 195 207
copyLoc 1 196 207
assign 1 197 207
CALLGet 0 197 207
typenameSet 1 197 207
assign 1 198 207
new 0 198 207
heldSet 1 199 207
assign 1 200 207
new 0 200 207
nameSet 1 200 207
addValue 1 201 207
assign 1 203 207
new 1 203 207
copyLoc 1 204 207
assign 1 205 207
CALLGet 0 205 207
typenameSet 1 205 207
assign 1 206 207
new 0 206 207
heldSet 1 207 207
assign 1 208 207
new 0 208 207
nameSet 1 208 207
addValue 1 209 207
addValue 1 210 207
prepend 1 212 207
return 1 213 207
assign 1 215 207
typenameGet 0 215 207
assign 1 215 207
WHILEGet 0 215 207
assign 1 215 207
equals 1 215 207
assign 1 216 207
new 1 216 207
copyLoc 1 217 207
assign 1 218 207
LOOPGet 0 218 207
typenameSet 1 218 207
replaceWith 1 219 207
assign 1 220 207
new 1 220 207
copyLoc 1 221 207
assign 1 222 207
BRACESGet 0 222 207
typenameSet 1 222 207
addValue 1 223 207
assign 1 224 207
assign 1 225 207
IFGet 0 225 207
typenameSet 1 225 207
addValue 1 226 207
assign 1 227 207
heldGet 0 227 207
assign 1 227 207
def 1 227 207
assign 1 227 207
heldGet 0 227 207
assign 1 227 207
new 0 227 207
assign 1 227 207
equals 1 227 207
assign 1 0 207
assign 1 0 207
assign 1 0 207
assign 1 228 207
new 0 228 207
heldSet 1 228 207
assign 1 230 207
new 1 230 207
copyLoc 1 231 207
assign 1 232 207
ELSEGet 0 232 207
typenameSet 1 232 207
addValue 1 233 207
assign 1 234 207
new 1 234 207
copyLoc 1 235 207
assign 1 236 207
BRACESGet 0 236 207
typenameSet 1 236 207
addValue 1 237 207
assign 1 238 207
new 1 238 207
copyLoc 1 239 207
assign 1 240 207
BREAKGet 0 240 207
typenameSet 1 240 207
addValue 1 241 207
assign 1 242 207
nextDescendGet 0 242 207
return 1 242 207
assign 1 243 207
typenameGet 0 243 207
assign 1 243 207
FORGet 0 243 207
assign 1 243 207
equals 1 243 207
assign 1 244 207
new 1 244 207
copyLoc 1 245 207
assign 1 246 207
LOOPGet 0 246 207
typenameSet 1 246 207
replaceWith 1 247 207
assign 1 248 207
containedGet 0 248 207
assign 1 248 207
firstGet 0 248 207
delete 0 249 207
assign 1 250 207
containedGet 0 250 207
assign 1 250 207
lengthGet 0 250 207
assign 1 250 207
new 0 250 207
assign 1 250 207
lesser 1 250 207
assign 1 251 207
new 0 251 207
assign 1 251 207
new 2 251 207
throw 1 251 207
assign 1 253 207
containedGet 0 253 207
assign 1 253 207
firstGet 0 253 207
assign 1 254 207
secondGet 0 254 207
assign 1 255 207
assign 1 256 207
containedGet 0 256 207
assign 1 256 207
lengthGet 0 256 207
assign 1 256 207
new 0 256 207
assign 1 256 207
greater 1 256 207
assign 1 257 207
thirdGet 0 257 207
delete 0 258 207
delete 0 260 207
replaceWith 1 262 207
beforeInsert 1 263 207
assign 1 265 207
new 1 265 207
copyLoc 1 266 207
assign 1 267 207
BRACESGet 0 267 207
typenameSet 1 267 207
addValue 1 268 207
assign 1 269 207
new 1 269 207
copyLoc 1 270 207
assign 1 271 207
IFGet 0 271 207
typenameSet 1 271 207
takeContents 1 272 207
assign 1 273 207
def 1 273 207
assign 1 274 207
containedGet 0 274 207
assign 1 274 207
firstGet 0 274 207
addValue 1 274 207
prepend 1 276 207
addValue 1 277 207
assign 1 278 207
new 1 278 207
copyLoc 1 279 207
assign 1 280 207
ELSEGet 0 280 207
typenameSet 1 280 207
addValue 1 281 207
assign 1 282 207
new 1 282 207
copyLoc 1 283 207
assign 1 284 207
BRACESGet 0 284 207
typenameSet 1 284 207
addValue 1 285 207
assign 1 286 207
new 1 286 207
copyLoc 1 287 207
assign 1 288 207
BREAKGet 0 288 207
typenameSet 1 288 207
addValue 1 289 207
return 1 291 207
assign 1 293 207
nextDescendGet 0 293 207
return 1 293 207
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass9.bevs_inst = (BEC_3_5_5_5_BuildVisitPass9)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass9.bevs_inst;
}
}
}
