namespace be.BEL_4_Base {
/* IO:File: source/build/Transport.be */
public class BEC_5_9_BuildTransport : BEC_6_6_SystemObject {
public BEC_5_9_BuildTransport() { }
static BEC_5_9_BuildTransport() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65,0x3A};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 38));
private static byte[] bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 10));
private static byte[] bels_3 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_4, 10));
private static byte[] bels_5 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_6 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_7 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_8 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static new BEC_5_9_BuildTransport bevs_inst;
public BEC_5_5_BuildBuild bevp_build;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_5_4_BuildNode bevp_outermost;
public BEC_5_4_BuildNode bevp_current;
public virtual BEC_5_9_BuildTransport bem_new_1(BEC_5_5_BuildBuild beva__build) {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = (BEC_5_4_BuildNode) (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_5_9_BuildTransport bem_new_2(BEC_5_5_BuildBuild beva__build, BEC_5_4_BuildNode beva__outermost) {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_traverse_1(BEC_5_5_7_BuildVisitVisitor beva_visitor) {
BEC_5_4_BuildNode bevl_node = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
try  /* Line: 40 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 45 */ {
if (bevl_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 46 */
 else  /* Line: 45 */ {
break;
} /* Line: 45 */
} /* Line: 45 */
beva_visitor.bem_end_1(this);
} /* Line: 49 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold.bem_print_0();
bevl_node.bem_print_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 55 */
 else  /* Line: 56 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold.bem_print_0();
bevt_5_tmpvar_phold = bevo_3;
bevt_5_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 59 */
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 61 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_contain_0() {
BEC_9_3_ContainerMap bevl_conTypes = null;
BEC_5_4_BuildNode bevl_curr = null;
BEC_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_5_4_BuildNode bevl_node = null;
BEC_5_4_BuildNode bevl_wf = null;
BEC_5_4_BuildNode bevl_cnode = null;
BEC_5_4_BuildNode bevl_mnode = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_9_BuildConstants bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
bevt_7_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpvar_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 70 */ {
bevt_8_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 70 */ {
bevl_node = (BEC_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpvar_phold = bevl_node.bem_delayDeleteGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_not_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 74 */ {
bevt_12_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_13_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_15_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 75 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 75 */
 else  /* Line: 75 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 75 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 79 */ {
if (bevl_wf == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_19_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_equals_1(bevt_20_tmpvar_phold);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_22_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_equals_1(bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 79 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 80 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_25_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_equals_1(bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 80 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 79 */
 else  /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 80 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 81 */
 else  /* Line: 79 */ {
break;
} /* Line: 79 */
} /* Line: 79 */
if (bevl_wf == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevt_29_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_equals_1(bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_32_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_equals_1(bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 83 */ {
bevl_cnode = (BEC_5_4_BuildNode) (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_5));
bevl_cnode.bem_heldSet_1(bevt_35_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 90 */
} /* Line: 83 */
bevt_37_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_equals_1(bevt_38_tmpvar_phold);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevt_41_tmpvar_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_equals_1(bevt_42_tmpvar_phold);
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 93 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 93 */
 else  /* Line: 93 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 93 */ {
bevt_44_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 93 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 93 */
 else  /* Line: 93 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 93 */ {
bevl_mnode = (BEC_5_4_BuildNode) (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_6));
bevl_mnode.bem_heldSet_1(bevt_47_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 99 */
bevt_49_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bem_equals_1(bevt_50_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_52_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_equals_1(bevt_53_tmpvar_phold);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 102 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 102 */
 else  /* Line: 102 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 102 */ {
bevl_mnode = (BEC_5_4_BuildNode) (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_7));
bevl_mnode.bem_heldSet_1(bevt_55_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 108 */
bevt_57_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_equals_1(bevt_58_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 112 */
 else  /* Line: 111 */ {
bevt_60_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpvar_phold = bevp_ntypes.bem_RIDXGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bem_equals_1(bevt_61_tmpvar_phold);
if (bevt_59_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 114 */
 else  /* Line: 111 */ {
bevt_63_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_equals_1(bevt_64_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_67_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(32, bels_8));
bevt_66_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_66_tmpvar_phold);
} /* Line: 118 */
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_70_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(32, bels_9));
bevt_69_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_69_tmpvar_phold);
} /* Line: 122 */
} /* Line: 121 */
 else  /* Line: 124 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 125 */
} /* Line: 111 */
} /* Line: 111 */
bevt_72_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevl_conTypes.bem_has_1(bevt_72_tmpvar_phold);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevl_curr = bevl_node;
} /* Line: 128 */
} /* Line: 127 */
} /* Line: 74 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_stepBack_1(BEC_5_4_BuildNode beva_curr) {
BEC_5_4_BuildNode bevl_hop = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(32, bels_10));
bevt_1_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpvar_phold, beva_curr);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 137 */
return bevl_hop;
} /*method end*/
public virtual BEC_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_outermostGet_0() {
return bevp_outermost;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_outermostSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outermost = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_currentGet_0() {
return bevp_current;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_currentSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_current = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {22, 23, 24, 25, 27, 28, 32, 33, 34, 35, 41, 43, 45, 46, 49, 51, 52, 53, 54, 55, 57, 58, 59, 61, 66, 67, 68, 69, 70, 73, 74, 75, 0, 78, 79, 0, 79, 0, 80, 0, 81, 83, 0, 83, 0, 86, 87, 88, 89, 90, 93, 0, 93, 0, 95, 96, 97, 98, 99, 102, 0, 104, 105, 106, 107, 108, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 125, 127, 128, 135, 136, 137, 139, 0};
public static new int[] bevs_smnlec
 = new int[] {32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32};
/* BEGIN LINEINFO 
assign 1 22 32
assign 1 23 32
constantsGet 0 23 32
assign 1 23 32
ntypesGet 0 23 32
assign 1 24 32
new 1 24 32
assign 1 25 32
assign 1 27 32
TRANSUNITGet 0 27 32
typenameSet 1 27 32
assign 1 28 32
new 0 28 32
heldSet 1 28 32
assign 1 32 32
assign 1 33 32
constantsGet 0 33 32
assign 1 33 32
ntypesGet 0 33 32
assign 1 34 32
assign 1 35 32
begin 1 41 33
assign 1 43 33
accept 1 43 33
assign 1 45 33
def 1 45 33
assign 1 46 33
accept 1 46 33
end 1 49 33
assign 1 51 33
def 1 51 33
assign 1 52 33
new 0 52 33
print 0 52 33
print 0 53 33
assign 1 54 33
new 0 54 33
print 0 54 33
print 0 55 33
assign 1 57 33
new 0 57 33
print 0 57 33
assign 1 58 33
new 0 58 33
print 0 58 33
print 0 59 33
throw 1 61 33
assign 1 66 32
constantsGet 0 66 32
assign 1 66 32
conTypesGet 0 66 32
assign 1 67 32
assign 1 68 32
containedGet 0 68 32
containedSet 1 69 32
assign 1 70 32
linkedListIteratorGet 0 70 32
assign 1 70 32
hasNextGet 0 70 32
assign 1 73 32
nextGet 0 73 32
assign 1 74 32
delayDeleteGet 0 74 32
assign 1 74 32
not 0 74 32
assign 1 75 32
typenameGet 0 75 32
assign 1 75 32
TRANSUNITGet 0 75 32
assign 1 75 32
equals 1 75 32
assign 1 75 32
typenameGet 0 75 32
assign 1 75 32
IDGet 0 75 32
assign 1 75 32
equals 1 75 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 78 32
assign 1 79 32
def 1 79 32
assign 1 79 32
typenameGet 0 79 32
assign 1 79 32
IDGet 0 79 32
assign 1 79 32
equals 1 79 32
assign 1 0 32
assign 1 79 32
typenameGet 0 79 32
assign 1 79 32
COLONGet 0 79 32
assign 1 79 32
equals 1 79 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 80 32
typenameGet 0 80 32
assign 1 80 32
SPACEGet 0 80 32
assign 1 80 32
equals 1 80 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 81 32
nextPeerGet 0 81 32
assign 1 83 32
def 1 83 32
assign 1 83 32
typenameGet 0 83 32
assign 1 83 32
PARENSGet 0 83 32
assign 1 83 32
equals 1 83 32
assign 1 0 32
assign 1 83 32
typenameGet 0 83 32
assign 1 83 32
BRACESGet 0 83 32
assign 1 83 32
equals 1 83 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 86 32
new 1 86 32
assign 1 87 32
CLASSGet 0 87 32
typenameSet 1 87 32
assign 1 88 32
new 0 88 32
heldSet 1 88 32
addValue 1 89 32
assign 1 90 32
assign 1 93 32
typenameGet 0 93 32
assign 1 93 32
BRACESGet 0 93 32
assign 1 93 32
equals 1 93 32
assign 1 93 32
containerGet 0 93 32
assign 1 93 32
typenameGet 0 93 32
assign 1 93 32
CLASSGet 0 93 32
assign 1 93 32
equals 1 93 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 93 32
typenameGet 0 93 32
assign 1 93 32
IDGet 0 93 32
assign 1 93 32
equals 1 93 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 95 32
new 1 95 32
assign 1 96 32
METHODGet 0 96 32
typenameSet 1 96 32
assign 1 97 32
new 0 97 32
heldSet 1 97 32
addValue 1 98 32
assign 1 99 32
assign 1 102 32
typenameGet 0 102 32
assign 1 102 32
BRACESGet 0 102 32
assign 1 102 32
equals 1 102 32
assign 1 102 32
typenameGet 0 102 32
assign 1 102 32
BRACESGet 0 102 32
assign 1 102 32
equals 1 102 32
assign 1 0 32
assign 1 0 32
assign 1 0 32
assign 1 104 32
new 1 104 32
assign 1 105 32
PROPERTIESGet 0 105 32
typenameSet 1 105 32
assign 1 106 32
new 0 106 32
heldSet 1 106 32
addValue 1 107 32
assign 1 108 32
assign 1 111 32
typenameGet 0 111 32
assign 1 111 32
RPARENSGet 0 111 32
assign 1 111 32
equals 1 111 32
assign 1 112 32
stepBack 1 112 32
assign 1 113 32
typenameGet 0 113 32
assign 1 113 32
RIDXGet 0 113 32
assign 1 113 32
equals 1 113 32
assign 1 114 32
stepBack 1 114 32
assign 1 115 32
typenameGet 0 115 32
assign 1 115 32
RBRACESGet 0 115 32
assign 1 115 32
equals 1 115 32
assign 1 116 32
stepBack 1 116 32
assign 1 117 32
undef 1 117 32
assign 1 118 32
new 0 118 32
assign 1 118 32
new 2 118 32
throw 1 118 32
assign 1 120 32
stepBack 1 120 32
assign 1 121 32
undef 1 121 32
assign 1 122 32
new 0 122 32
assign 1 122 32
new 2 122 32
throw 1 122 32
addValue 1 125 32
assign 1 127 32
typenameGet 0 127 32
assign 1 127 32
has 1 127 32
assign 1 128 32
assign 1 135 32
containerGet 0 135 32
assign 1 136 32
undef 1 136 32
assign 1 137 32
new 0 137 32
assign 1 137 32
new 2 137 32
throw 1 137 32
return 1 139 32
return 1 0 32
assign 1 0 32
return 1 0 32
assign 1 0 32
return 1 0 32
assign 1 0 32
return 1 0 32
assign 1 0 32
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 410956923: return bem_contain_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case 1081412016: return bem_many_0();
case 1380522583: return bem_outermostGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 2101994299: return bem_stepBack_1((BEC_5_4_BuildNode) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1369440330: return bem_outermostSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 688372900: return bem_traverse_1((BEC_5_5_7_BuildVisitVisitor) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_5_5_BuildBuild) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_9_BuildTransport();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_9_BuildTransport.bevs_inst = (BEC_5_9_BuildTransport)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_9_BuildTransport.bevs_inst;
}
}
}
