namespace be.BEL_4_Base {
/* IO:File: source/build/Pass12.be */
public class BEC_5_5_6_BuildVisitRewind : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_6_BuildVisitRewind() { }
static BEC_5_5_6_BuildVisitRewind() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 11));
private static byte[] bels_2 = {0x5F,0x30};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 2));
private static byte[] bels_3 = {0x5F,0x30};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 2));
private static byte[] bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_6 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_6, 27));
private static byte[] bels_7 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_8 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_8, 13));
private static byte[] bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 10));
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_5_5_6_BuildVisitRewind bevs_inst;
public BEC_6_6_SystemObject bevp_tvmap;
public BEC_6_6_SystemObject bevp_rmap;
public BEC_6_6_SystemObject bevp_inClass;
public BEC_6_6_SystemObject bevp_inClassNp;
public BEC_6_6_SystemObject bevp_inClassSyn;
public BEC_6_6_SystemObject bevp_nl;
public BEC_6_6_SystemObject bevp_emitter;
public override BEC_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_5_8_BuildNamePath bevl_fgnp = null;
BEC_4_6_TextString bevl_fgcn = null;
BEC_4_6_TextString bevl_fgin = null;
BEC_5_8_BuildClassSyn bevl_fgsy = null;
BEC_5_6_BuildMtdSyn bevl_fgms = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_79_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_80_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_83_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_84_tmpvar_phold = null;
BEC_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_86_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_12_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(654935401, BEL_4_Base.bevn_wasForeachGennedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 247 */
 else  /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 247 */ {
bevt_15_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_20_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_0));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 249 */
 else  /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 249 */ {
bevt_22_tmpvar_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 249 */
 else  /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 249 */ {
bevt_26_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_firstGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 251 */ {
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_firstGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 251 */ {
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_firstGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_fgnp = (BEC_5_8_BuildNamePath) bevt_32_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_4_6_TextString) bevt_35_tmpvar_phold.bem_lastGet_0();
bevt_39_tmpvar_phold = bevo_0;
bevt_40_tmpvar_phold = bevo_1;
bevt_38_tmpvar_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpvar_phold, bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) bevt_38_tmpvar_phold.bem_lowerValue_0();
bevt_42_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_41_tmpvar_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_add_1(bevt_41_tmpvar_phold);
bevt_43_tmpvar_phold = bevo_2;
bevl_fgin = bevt_36_tmpvar_phold.bem_add_1(bevt_43_tmpvar_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpvar_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpvar_phold = bevo_3;
bevt_45_tmpvar_phold = bevl_fgin.bem_add_1(bevt_46_tmpvar_phold);
bevl_fgms = (BEC_5_6_BuildMtdSyn) bevt_44_tmpvar_phold.bem_get_1(bevt_45_tmpvar_phold);
if (bevl_fgms == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_48_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_48_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_fgin);
bevt_49_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = bevo_4;
bevt_50_tmpvar_phold = bevl_fgin.bem_add_1(bevt_51_tmpvar_phold);
bevt_49_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpvar_phold);
} /* Line: 261 */
} /* Line: 258 */
} /* Line: 251 */
} /* Line: 249 */
bevt_53_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_equals_1(bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevp_inClass = beva_node;
bevt_55_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_56_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 269 */
bevt_58_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_equals_1(bevt_59_tmpvar_phold);
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevp_tvmap = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_9_3_ContainerMap()).bem_new_0();
} /* Line: 273 */
 else  /* Line: 271 */ {
bevt_61_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_equals_1(bevt_62_tmpvar_phold);
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 274 */ {
bevt_64_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 274 */
 else  /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 274 */ {
bevt_66_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_67_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_65_tmpvar_phold, bevt_67_tmpvar_phold);
bevt_69_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_68_tmpvar_phold);
if (bevl_ll == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevl_ll = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_rmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_71_tmpvar_phold, bevl_ll);
} /* Line: 279 */
bevl_ll.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 281 */
 else  /* Line: 271 */ {
bevt_74_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bem_equals_1(bevt_75_tmpvar_phold);
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_77_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpvar_phold == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
bevt_80_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_containerGet_0();
if (bevt_79_tmpvar_phold == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
bevt_84_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_containerGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_typenameGet_0();
bevt_85_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_equals_1(bevt_85_tmpvar_phold);
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
this.bem_processTmps_0();
} /* Line: 284 */
} /* Line: 271 */
} /* Line: 271 */
bevt_86_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_processTmps_0() {
BEC_6_6_SystemObject bevl_foundone = null;
BEC_6_6_SystemObject bevl_targ = null;
BEC_6_6_SystemObject bevl_tvar = null;
BEC_6_6_SystemObject bevl_tcall = null;
BEC_5_8_BuildClassSyn bevl_syn = null;
BEC_6_6_SystemObject bevl_targNp = null;
BEC_6_6_SystemObject bevl_mtdc = null;
BEC_6_6_SystemObject bevl_ovar = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_nv = null;
BEC_6_6_SystemObject bevl_nvname = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_k = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_91_tmpvar_phold = null;
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
while (true)
 /* Line: 298 */ {
if (bevl_foundone != null && bevl_foundone is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_foundone).bevi_bool) /* Line: 298 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(2145224760, BEL_4_Base.bevn_valueIteratorGet_0);
while (true)
 /* Line: 300 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 300 */ {
bevl_nv = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_nv.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevl_nvname = bevl_nv.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_nvname);
bevt_0_tmpvar_loop = bevl_ll.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 308 */ {
bevt_11_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 308 */ {
bevl_k = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_15_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_20_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_4));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_25_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_26_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_26_tmpvar_phold);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_27_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevl_tcall = bevt_27_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targNp = null;
bevt_30_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_29_tmpvar_phold == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_31_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_targNp = bevt_31_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
} /* Line: 314 */
 else  /* Line: 315 */ {
bevt_32_tmpvar_phold = bevl_tcall.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_targ = bevt_32_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_34_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_tvar = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 321 */
 else  /* Line: 322 */ {
bevt_36_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_38_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_37_tmpvar_phold);
bevl_tvar = bevt_35_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 323 */
bevt_39_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 326 */ {
bevl_targNp = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 327 */
} /* Line: 326 */
if (bevl_targNp == null) {
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 330 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_41_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_43_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_41_tmpvar_phold.bem_get_1(bevt_42_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 334 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevl_ovar == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 337 */ {
bevt_46_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 337 */
 else  /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 337 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_47_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 340 */ {
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_targNp);
} /* Line: 341 */
 else  /* Line: 342 */ {
bevt_48_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_48_tmpvar_phold);
} /* Line: 343 */
bevt_49_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = bevp_inClass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_50_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_51_tmpvar_phold);
bevt_54_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_5));
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 347 */ {
bevt_57_tmpvar_phold = bevo_5;
bevt_58_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 347 */
} /* Line: 347 */
} /* Line: 337 */
 else  /* Line: 334 */ {
bevt_61_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_62_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_7));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_62_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 349 */ {
bevt_67_tmpvar_phold = bevo_6;
bevt_69_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = bevo_7;
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_add_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_targNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_add_1(bevt_71_tmpvar_phold);
bevt_63_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpvar_phold, bevl_tcall);
throw new be.BELS_Base.BECS_ThrowBack(bevt_63_tmpvar_phold);
} /* Line: 350 */
} /* Line: 334 */
} /* Line: 334 */
} /* Line: 330 */
 else  /* Line: 309 */ {
bevt_72_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_72_tmpvar_phold != null && bevt_72_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_72_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_75_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_80_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_81_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_10));
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_85_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_84_tmpvar_phold = bevt_85_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_86_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_88_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targ = bevt_87_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_89_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_89_tmpvar_phold != null && bevt_89_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_89_tmpvar_phold).bevi_bool) /* Line: 358 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_90_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_targ.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_91_tmpvar_phold);
} /* Line: 363 */
} /* Line: 358 */
} /* Line: 309 */
} /* Line: 309 */
 else  /* Line: 308 */ {
break;
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 303 */
 else  /* Line: 300 */ {
break;
} /* Line: 300 */
} /* Line: 300 */
} /* Line: 300 */
 else  /* Line: 298 */ {
break;
} /* Line: 298 */
} /* Line: 298 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_tvmapGet_0() {
return bevp_tvmap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_tvmapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_tvmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rmapGet_0() {
return bevp_rmap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rmapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClass = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassSynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {247, 0, 249, 0, 249, 0, 251, 0, 252, 253, 254, 256, 257, 258, 260, 261, 266, 267, 268, 269, 271, 272, 273, 274, 0, 275, 276, 277, 278, 279, 281, 282, 0, 282, 0, 282, 0, 284, 286, 290, 299, 300, 301, 303, 306, 307, 308, 0, 308, 309, 0, 309, 0, 309, 0, 311, 312, 313, 314, 316, 320, 321, 323, 326, 327, 330, 332, 333, 334, 336, 337, 0, 338, 340, 341, 343, 345, 346, 347, 349, 350, 355, 0, 355, 0, 355, 0, 356, 358, 360, 362, 363, 0};
public static new int[] bevs_smnlec
 = new int[] {36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36};
/* BEGIN LINEINFO 
assign 1 247 36
typenameGet 0 247 36
assign 1 247 36
CALLGet 0 247 36
assign 1 247 36
equals 1 247 36
assign 1 247 36
heldGet 0 247 36
assign 1 247 36
wasForeachGennedGet 0 247 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 249 36
containerGet 0 249 36
assign 1 249 36
typenameGet 0 249 36
assign 1 249 36
CALLGet 0 249 36
assign 1 249 36
equals 1 249 36
assign 1 249 36
containerGet 0 249 36
assign 1 249 36
heldGet 0 249 36
assign 1 249 36
orgNameGet 0 249 36
assign 1 249 36
new 0 249 36
assign 1 249 36
equals 1 249 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 249 36
isSecondGet 0 249 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 251 36
containedGet 0 251 36
assign 1 251 36
firstGet 0 251 36
assign 1 251 36
typenameGet 0 251 36
assign 1 251 36
VARGet 0 251 36
assign 1 251 36
equals 1 251 36
assign 1 251 36
containedGet 0 251 36
assign 1 251 36
firstGet 0 251 36
assign 1 251 36
heldGet 0 251 36
assign 1 251 36
isTypedGet 0 251 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 252 36
containedGet 0 252 36
assign 1 252 36
firstGet 0 252 36
assign 1 252 36
heldGet 0 252 36
assign 1 252 36
namepathGet 0 252 36
assign 1 253 36
stepsGet 0 253 36
assign 1 253 36
lastGet 0 253 36
assign 1 254 36
new 0 254 36
assign 1 254 36
new 0 254 36
assign 1 254 36
substring 2 254 36
assign 1 254 36
lowerValue 0 254 36
assign 1 254 36
new 0 254 36
assign 1 254 36
substring 1 254 36
assign 1 254 36
add 1 254 36
assign 1 254 36
new 0 254 36
assign 1 254 36
add 1 254 36
assign 1 256 36
getSynNp 1 256 36
assign 1 257 36
mtdMapGet 0 257 36
assign 1 257 36
new 0 257 36
assign 1 257 36
add 1 257 36
assign 1 257 36
get 1 257 36
assign 1 258 36
def 1 258 36
assign 1 260 36
heldGet 0 260 36
orgNameSet 1 260 36
assign 1 261 36
heldGet 0 261 36
assign 1 261 36
new 0 261 36
assign 1 261 36
add 1 261 36
nameSet 1 261 36
assign 1 266 36
typenameGet 0 266 36
assign 1 266 36
CLASSGet 0 266 36
assign 1 266 36
equals 1 266 36
assign 1 267 36
assign 1 268 36
heldGet 0 268 36
assign 1 268 36
namepathGet 0 268 36
assign 1 269 36
heldGet 0 269 36
assign 1 269 36
synGet 0 269 36
assign 1 271 36
typenameGet 0 271 36
assign 1 271 36
METHODGet 0 271 36
assign 1 271 36
equals 1 271 36
assign 1 272 36
new 0 272 36
assign 1 273 36
new 0 273 36
assign 1 274 36
typenameGet 0 274 36
assign 1 274 36
VARGet 0 274 36
assign 1 274 36
equals 1 274 36
assign 1 274 36
heldGet 0 274 36
assign 1 274 36
isTmpVarGet 0 274 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 275 36
heldGet 0 275 36
assign 1 275 36
nameGet 0 275 36
assign 1 275 36
heldGet 0 275 36
put 2 275 36
assign 1 276 36
heldGet 0 276 36
assign 1 276 36
nameGet 0 276 36
assign 1 276 36
get 1 276 36
assign 1 277 36
undef 1 277 36
assign 1 278 36
new 0 278 36
assign 1 279 36
heldGet 0 279 36
assign 1 279 36
nameGet 0 279 36
put 2 279 36
addValue 1 281 36
assign 1 282 36
typenameGet 0 282 36
assign 1 282 36
RBRACESGet 0 282 36
assign 1 282 36
equals 1 282 36
assign 1 282 36
containerGet 0 282 36
assign 1 282 36
def 1 282 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 282 36
containerGet 0 282 36
assign 1 282 36
containerGet 0 282 36
assign 1 282 36
def 1 282 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 282 36
containerGet 0 282 36
assign 1 282 36
containerGet 0 282 36
assign 1 282 36
typenameGet 0 282 36
assign 1 282 36
METHODGet 0 282 36
assign 1 282 36
equals 1 282 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
processTmps 0 284 36
assign 1 286 36
nextDescendGet 0 286 36
return 1 286 36
assign 1 290 36
new 0 290 36
assign 1 299 36
new 0 299 36
assign 1 300 36
valueIteratorGet 0 300 36
assign 1 300 36
hasNextGet 0 300 36
assign 1 301 36
nextGet 0 301 36
assign 1 303 36
isTypedGet 0 303 36
assign 1 303 36
not 0 303 36
assign 1 306 36
nameGet 0 306 36
assign 1 307 36
get 1 307 36
assign 1 308 36
iteratorGet 0 0 36
assign 1 308 36
hasNextGet 0 308 36
assign 1 308 36
nextGet 0 308 36
assign 1 309 36
isFirstGet 0 309 36
assign 1 309 36
containerGet 0 309 36
assign 1 309 36
typenameGet 0 309 36
assign 1 309 36
CALLGet 0 309 36
assign 1 309 36
equals 1 309 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 309 36
containerGet 0 309 36
assign 1 309 36
heldGet 0 309 36
assign 1 309 36
orgNameGet 0 309 36
assign 1 309 36
new 0 309 36
assign 1 309 36
equals 1 309 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 309 36
containerGet 0 309 36
assign 1 309 36
secondGet 0 309 36
assign 1 309 36
typenameGet 0 309 36
assign 1 309 36
CALLGet 0 309 36
assign 1 309 36
equals 1 309 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 311 36
containerGet 0 311 36
assign 1 311 36
secondGet 0 311 36
assign 1 312 36
assign 1 313 36
heldGet 0 313 36
assign 1 313 36
newNpGet 0 313 36
assign 1 313 36
def 1 313 36
assign 1 314 36
heldGet 0 314 36
assign 1 314 36
newNpGet 0 314 36
assign 1 316 36
containedGet 0 316 36
assign 1 316 36
firstGet 0 316 36
assign 1 320 36
heldGet 0 320 36
assign 1 320 36
isDeclaredGet 0 320 36
assign 1 321 36
heldGet 0 321 36
assign 1 323 36
ptyMapGet 0 323 36
assign 1 323 36
heldGet 0 323 36
assign 1 323 36
nameGet 0 323 36
assign 1 323 36
get 1 323 36
assign 1 323 36
memSynGet 0 323 36
assign 1 326 36
isTypedGet 0 326 36
assign 1 327 36
namepathGet 0 327 36
assign 1 330 36
def 1 330 36
assign 1 332 36
getSynNp 1 332 36
assign 1 333 36
mtdMapGet 0 333 36
assign 1 333 36
heldGet 0 333 36
assign 1 333 36
nameGet 0 333 36
assign 1 333 36
get 1 333 36
assign 1 334 36
def 1 334 36
assign 1 336 36
rsynGet 0 336 36
assign 1 337 36
def 1 337 36
assign 1 337 36
isTypedGet 0 337 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 338 36
new 0 338 36
assign 1 340 36
isSelfGet 0 340 36
namepathSet 1 341 36
assign 1 343 36
namepathGet 0 343 36
namepathSet 1 343 36
assign 1 345 36
isTypedGet 0 345 36
isTypedSet 1 345 36
assign 1 346 36
heldGet 0 346 36
assign 1 346 36
namepathGet 0 346 36
addUsed 1 346 36
assign 1 347 36
namepathGet 0 347 36
assign 1 347 36
toString 0 347 36
assign 1 347 36
new 0 347 36
assign 1 347 36
equals 1 347 36
assign 1 347 36
new 0 347 36
assign 1 347 36
isSelfGet 0 347 36
assign 1 347 36
add 1 347 36
print 0 347 36
assign 1 349 36
heldGet 0 349 36
assign 1 349 36
orgNameGet 0 349 36
assign 1 349 36
new 0 349 36
assign 1 349 36
notEquals 1 349 36
assign 1 350 36
new 0 350 36
assign 1 350 36
heldGet 0 350 36
assign 1 350 36
nameGet 0 350 36
assign 1 350 36
add 1 350 36
assign 1 350 36
new 0 350 36
assign 1 350 36
add 1 350 36
assign 1 350 36
toString 0 350 36
assign 1 350 36
add 1 350 36
assign 1 350 36
new 2 350 36
throw 1 350 36
assign 1 355 36
isFirstGet 0 355 36
assign 1 355 36
containerGet 0 355 36
assign 1 355 36
typenameGet 0 355 36
assign 1 355 36
CALLGet 0 355 36
assign 1 355 36
equals 1 355 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 355 36
containerGet 0 355 36
assign 1 355 36
heldGet 0 355 36
assign 1 355 36
orgNameGet 0 355 36
assign 1 355 36
new 0 355 36
assign 1 355 36
equals 1 355 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 355 36
containerGet 0 355 36
assign 1 355 36
secondGet 0 355 36
assign 1 355 36
typenameGet 0 355 36
assign 1 355 36
VARGet 0 355 36
assign 1 355 36
equals 1 355 36
assign 1 0 36
assign 1 0 36
assign 1 0 36
assign 1 356 36
containerGet 0 356 36
assign 1 356 36
secondGet 0 356 36
assign 1 356 36
heldGet 0 356 36
assign 1 358 36
isTypedGet 0 358 36
assign 1 360 36
new 0 360 36
assign 1 362 36
isTypedGet 0 362 36
isTypedSet 1 362 36
assign 1 363 36
namepathGet 0 363 36
namepathSet 1 363 36
return 1 0 36
assign 1 0 36
return 1 0 36
assign 1 0 36
return 1 0 36
assign 1 0 36
return 1 0 36
assign 1 0 36
return 1 0 36
assign 1 0 36
return 1 0 36
assign 1 0 36
return 1 0 36
assign 1 0 36
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2001798761: return bem_nlGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 304475661: return bem_tvmapGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 1344145980: return bem_processTmps_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
case 265089021: return bem_rmapGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 315557914: return bem_tvmapSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 276171274: return bem_rmapSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_6_BuildVisitRewind();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_6_BuildVisitRewind.bevs_inst = (BEC_5_5_6_BuildVisitRewind)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_6_BuildVisitRewind.bevs_inst;
}
}
}
