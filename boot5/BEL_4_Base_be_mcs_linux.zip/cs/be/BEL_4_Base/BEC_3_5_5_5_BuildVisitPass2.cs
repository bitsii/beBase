namespace be.BEL_4_Base {
/* IO:File: source/build/Pass2.be */
public sealed class BEC_3_5_5_5_BuildVisitPass2 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass2() { }
static BEC_3_5_5_5_BuildVisitPass2() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x32};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2E};
public static new BEC_3_5_5_5_BuildVisitPass2 bevs_inst;
public BEC_2_4_3_MathInt bevp_idType;
public BEC_2_4_3_MathInt bevp_intType;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public override BEC_2_6_6_SystemObject bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
BEC_2_5_9_BuildConstants bevt_0_tmpvar_phold = null;
BEC_2_5_9_BuildConstants bevt_1_tmpvar_phold = null;
base.bem_begin_1(beva_transi);
bevp_idType = bevp_ntypes.bem_IDGet_0();
bevp_intType = bevp_ntypes.bem_INTLGet_0();
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_matchMap = bevt_0_tmpvar_phold.bem_matchMapGet_0();
bevt_1_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_rwords = bevt_1_tmpvar_phold.bem_rwordsGet_0();
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_held = null;
BEC_2_6_6_SystemObject bevl_type = null;
BEC_2_5_4_BuildNode bevl_nxp = null;
BEC_2_5_4_BuildNode bevl_nxp2 = null;
BEC_2_5_4_BuildNode bevl_nxp3 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_27_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_3_tmpvar_phold.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 33 */ {
bevt_5_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpvar_phold;
} /* Line: 34 */
bevl_held = beva_node.bem_heldGet_0();
if (bevl_held == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 37 */ {
bevl_type = bevp_matchMap.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 39 */ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 41 */
 else  /* Line: 42 */ {
bevt_8_tmpvar_phold = bevl_held.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 44 */ {
bevl_nxp = beva_node.bem_nextPeerGet_0();
if (bevl_nxp == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 46 */ {
bevt_11_tmpvar_phold = bevl_nxp.bem_heldGet_0();
if (bevt_11_tmpvar_phold == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 46 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
 else  /* Line: 46 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 46 */ {
bevt_13_tmpvar_phold = bevl_nxp.bem_heldGet_0();
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 47 */ {
bevl_nxp2 = bevl_nxp.bem_nextPeerGet_0();
if (bevl_nxp2 == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevt_17_tmpvar_phold = bevl_nxp2.bem_heldGet_0();
if (bevt_17_tmpvar_phold == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
 else  /* Line: 49 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 49 */ {
bevl_nxp3 = bevl_nxp2.bem_nextDescendGet_0();
bevt_19_tmpvar_phold = bevl_nxp2.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_23_tmpvar_phold = bevl_nxp.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevl_nxp2.bem_heldGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_20_tmpvar_phold);
bevt_25_tmpvar_phold = bevp_ntypes.bem_FLOATLGet_0();
beva_node.bem_typenameSet_1(bevt_25_tmpvar_phold);
bevl_nxp2.bem_delete_0();
bevl_nxp.bem_delete_0();
return bevl_nxp3;
} /* Line: 56 */
} /* Line: 51 */
} /* Line: 49 */
} /* Line: 47 */
beva_node.bem_typenameSet_1(bevp_intType);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevl_type = bevp_rwords.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 64 */ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 65 */
 else  /* Line: 66 */ {
beva_node.bem_typenameSet_1(bevp_idType);
} /* Line: 67 */
} /* Line: 64 */
} /* Line: 44 */
} /* Line: 39 */
bevt_27_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_27_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_idTypeGet_0() {
return bevp_idType;
} /*method end*/
public BEC_2_6_6_SystemObject bem_idTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intTypeGet_0() {
return bevp_intType;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {19, 22, 23, 24, 24, 25, 25, 33, 33, 33, 33, 34, 34, 36, 37, 37, 38, 39, 39, 41, 44, 45, 46, 46, 46, 46, 46, 0, 0, 0, 47, 47, 47, 48, 49, 49, 49, 49, 49, 0, 0, 0, 50, 51, 51, 52, 52, 52, 52, 52, 52, 53, 53, 54, 55, 56, 61, 63, 64, 64, 65, 67, 72, 72, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 20, 21, 22, 23, 60, 61, 62, 67, 68, 69, 71, 72, 77, 78, 79, 84, 85, 88, 90, 91, 96, 97, 98, 103, 104, 107, 111, 114, 115, 116, 118, 119, 124, 125, 126, 131, 132, 135, 139, 142, 143, 144, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 161, 164, 165, 170, 171, 174, 179, 180, 183, 186, 190, 193, 197, 200, 204, 207};
/* BEGIN LINEINFO 
begin 1 19 17
assign 1 22 18
IDGet 0 22 18
assign 1 23 19
INTLGet 0 23 19
assign 1 24 20
constantsGet 0 24 20
assign 1 24 21
matchMapGet 0 24 21
assign 1 25 22
constantsGet 0 25 22
assign 1 25 23
rwordsGet 0 25 23
assign 1 33 60
typenameGet 0 33 60
assign 1 33 61
TRANSUNITGet 0 33 61
assign 1 33 62
equals 1 33 67
assign 1 34 68
nextDescendGet 0 34 68
return 1 34 69
assign 1 36 71
heldGet 0 36 71
assign 1 37 72
def 1 37 77
assign 1 38 78
get 1 38 78
assign 1 39 79
def 1 39 84
typenameSet 1 41 85
assign 1 44 88
isInteger 0 44 88
assign 1 45 90
nextPeerGet 0 45 90
assign 1 46 91
def 1 46 96
assign 1 46 97
heldGet 0 46 97
assign 1 46 98
def 1 46 103
assign 1 0 104
assign 1 0 107
assign 1 0 111
assign 1 47 114
heldGet 0 47 114
assign 1 47 115
new 0 47 115
assign 1 47 116
equals 1 47 116
assign 1 48 118
nextPeerGet 0 48 118
assign 1 49 119
def 1 49 124
assign 1 49 125
heldGet 0 49 125
assign 1 49 126
def 1 49 131
assign 1 0 132
assign 1 0 135
assign 1 0 139
assign 1 50 142
nextDescendGet 0 50 142
assign 1 51 143
heldGet 0 51 143
assign 1 51 144
isInteger 0 51 144
assign 1 52 146
heldGet 0 52 146
assign 1 52 147
heldGet 0 52 147
assign 1 52 148
add 1 52 148
assign 1 52 149
heldGet 0 52 149
assign 1 52 150
add 1 52 150
heldSet 1 52 151
assign 1 53 152
FLOATLGet 0 53 152
typenameSet 1 53 153
delete 0 54 154
delete 0 55 155
return 1 56 156
typenameSet 1 61 161
assign 1 63 164
get 1 63 164
assign 1 64 165
def 1 64 170
typenameSet 1 65 171
typenameSet 1 67 174
assign 1 72 179
nextDescendGet 0 72 179
return 1 72 180
return 1 0 183
assign 1 0 186
return 1 0 190
assign 1 0 193
return 1 0 197
assign 1 0 200
return 1 0 204
assign 1 0 207
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 634261936: return bem_rwordsGet_0();
case 104713553: return bem_new_0();
case 327922578: return bem_idTypeGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1752635198: return bem_intTypeGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 1323554192: return bem_matchMapGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 623179683: return bem_rwordsSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 339004831: return bem_idTypeSet_1(bevd_0);
case 1312471939: return bem_matchMapSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1763717451: return bem_intTypeSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass2();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass2.bevs_inst = (BEC_3_5_5_5_BuildVisitPass2)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass2.bevs_inst;
}
}
}
