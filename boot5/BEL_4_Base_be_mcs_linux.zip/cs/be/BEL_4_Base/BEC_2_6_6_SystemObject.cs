namespace be.BEL_4_Base {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject : be.BELS_Base.BECS_Object {
public BEC_2_6_6_SystemObject() { }
static BEC_2_6_6_SystemObject() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x69,0x6E,0x20,0x61,0x20,0x63,0x6F,0x6E,0x74,0x65,0x78,0x74,0x20,0x77,0x68,0x65,0x72,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x20,0x77,0x65,0x72,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x76,0x61,0x69,0x6C,0x61,0x62,0x6C,0x65,0x20,0x66,0x72,0x6F,0x6D,0x20,0x74,0x68,0x65,0x20,0x73,0x74,0x61,0x63,0x6B};
private static byte[] bels_1 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64};
private static byte[] bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 8));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 23));
private static byte[] bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 16));
private static byte[] bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x41,0x72,0x72,0x61,0x79,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x5F};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 1));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static byte[] bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_11 = {0x5F};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 1));
public static BEC_2_6_6_SystemObject bevs_inst;
public virtual BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNotDefined_0() {
BEC_2_6_11_SystemForwardCall bevl_forwardCall = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_forwardCall = (BEC_2_6_11_SystemForwardCall) (new BEC_2_6_11_SystemForwardCall()).bem_new_0();
bevt_0_tmpvar_phold = bevl_forwardCall.bem_notReadyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(86, bels_0));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 80 */
bevt_3_tmpvar_phold = this.bem_methodNotDefined_1(bevl_forwardCall);
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNotDefined_1(BEC_2_6_11_SystemForwardCall beva_forwardCall) {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_1));
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = this.bem_can_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevl_s = this;
bevl_result = bevl_s.bemd_1(2097807671, BEL_4_Base.bevn_forward_1, beva_forwardCall);
return bevl_result;
} /* Line: 90 */
 else  /* Line: 86 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_8_tmpvar_phold = bevo_0;
bevt_9_tmpvar_phold = beva_forwardCall.bem_nameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_1;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = this.bem_classNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 92 */
} /* Line: 86 */
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_phold = this.bem_createInstance_2(beva_cname, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_4_3_MathInt bevl_mhash = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_11_SystemInitializer bevt_9_tmpvar_phold = null;
if (beva_cname == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_4));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 118 */
bevl_result = null;

        string key = System.Text.Encoding.UTF8.GetString(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int);
        Type ti = be.BELS_Base.BECS_Runtime.typeInstances[key];
        if (ti != null) {
            bevl_result = (BEC_2_6_6_SystemObject) Activator.CreateInstance(ti);
        }
        if (bevl_result == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 196 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 197 */ {
bevt_7_tmpvar_phold = bevo_2;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(beva_cname);
bevt_5_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 198 */
 else  /* Line: 199 */ {
return null;
} /* Line: 200 */
} /* Line: 197 */
bevt_9_tmpvar_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_initializeIfShould_1(bevl_result);
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_5_ContainerArray beva_args) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_5_ContainerArray bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bels_6));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 239 */
if (beva_args == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 241 */ {
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bels_7));
bevt_4_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 242 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpvar_phold = bevo_3;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();
 /* Line: 251 */ {
bevt_10_tmpvar_phold = bevo_4;
bevt_9_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_12_tmpvar_phold = bevo_5;
bevt_11_tmpvar_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpvar_phold);
bevl_args2 = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_11_tmpvar_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 254 */ {
bevt_13_tmpvar_phold = bevl_i.bem_lesser_1(bevl_numargs);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_15_tmpvar_phold = bevo_6;
bevt_14_tmpvar_phold = bevl_i.bem_subtract_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpvar_phold, bevt_16_tmpvar_phold);
bevl_i.bem_incrementValue_0();
} /* Line: 254 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 252 */

        int ci = be.BELS_Base.BECS_Ids.callIds[System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int)];
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(bevl_chash.bevi_int, ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(bevl_chash.bevi_int, ci, beva_args.bevi_array[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5], beva_args.bevi_array[6]);
        } else {
            bevl_rval = bemd_x(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5], beva_args.bevi_array[6], bevl_args2.bevi_array);
        }
        bevt_17_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 382 */
return bevl_rval;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_9));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 410 */
if (beva_numargs == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 412 */ {
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_10));
bevt_4_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 413 */
bevt_7_tmpvar_phold = bevo_7;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      string name = "bem_" + System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int);
      System.Reflection.MethodInfo[] methods = this.GetType().GetMethods();
      for (int i = 0;i < methods.Length;i++) {
        if (methods[i].Name.Equals(name)) {
            return be.BELS_Base.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 469 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 470 */
if (bevl_rval == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 472 */ {
bevt_11_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /* Line: 473 */
bevt_12_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_classNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clname();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      return bevl_xi;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_sourceFileNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clfile();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      return bevl_xi;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_tagGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_tagGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_print_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_echo_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_echo_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_6_6_SystemObject) this.bem_create_0();
bevt_0_tmpvar_phold = (BEC_2_6_6_SystemObject) this.bem_copyTo_1(bevt_1_tmpvar_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
if (beva_copy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 660 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 661 */
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpvar_phold);
while (true)
 /* Line: 665 */ {
bevt_3_tmpvar_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_4_tmpvar_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpvar_phold);
} /* Line: 666 */
 else  /* Line: 665 */ {
break;
} /* Line: 665 */
} /* Line: 665 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_serializeToString_0() {
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_19_SystemObjectFieldIterator bem_objectIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && this.GetType() == beva_other.GetType()) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameClass_1(beva_other);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && beva_other.GetType().IsAssignableFrom(this.GetType())) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameType_1(beva_other);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_once_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_many_0() {
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {39, 50, 61, 72, 77, 79, 80, 82, 86, 88, 89, 90, 91, 92, 94, 98, 117, 118, 120, 196, 198, 200, 203, 238, 239, 241, 242, 244, 245, 246, 252, 253, 254, 255, 254, 380, 382, 384, 409, 410, 412, 413, 415, 416, 469, 470, 472, 473, 475, 509, 531, 563, 595, 606, 632, 636, 640, 644, 648, 652, 656, 660, 661, 663, 664, 665, 666, 672, 678, 684, 688, 692, 696, 719, 766, 770, 825, 829};
public static int[] bevs_smnlec
 = new int[] {32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 35, 35, 36, 36, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 34, 36, 32, 36, 32};
/* BEGIN LINEINFO 
assign 1 39 32
new 0 39 32
return 1 39 32
assign 1 50 32
new 0 50 32
return 1 50 32
assign 1 61 32
new 0 61 32
return 1 61 32
assign 1 72 32
new 0 72 32
return 1 72 32
assign 1 77 32
new 0 77 32
assign 1 79 32
notReadyGet 0 79 32
assign 1 80 32
new 0 80 32
assign 1 80 32
new 1 80 32
throw 1 80 32
assign 1 82 32
methodNotDefined 1 82 32
return 1 82 32
assign 1 86 32
new 0 86 32
assign 1 86 32
new 0 86 32
assign 1 86 32
can 2 86 32
assign 1 88 32
assign 1 89 32
forward 1 89 32
return 1 90 32
assign 1 91 32
new 0 91 32
assign 1 92 32
new 0 92 32
assign 1 92 32
nameGet 0 92 32
assign 1 92 32
add 1 92 32
assign 1 92 32
new 0 92 32
assign 1 92 32
add 1 92 32
assign 1 92 32
classNameGet 0 92 32
assign 1 92 32
add 1 92 32
assign 1 92 32
new 1 92 32
throw 1 92 32
return 1 94 32
assign 1 98 32
new 0 98 32
assign 1 98 32
createInstance 2 98 32
return 1 98 32
assign 1 117 32
undef 1 117 32
assign 1 118 32
new 0 118 32
assign 1 118 32
new 1 118 32
throw 1 118 32
assign 1 120 32
assign 1 196 32
undef 1 196 32
assign 1 198 32
new 0 198 32
assign 1 198 32
add 1 198 32
assign 1 198 32
new 1 198 32
throw 1 198 32
return 1 200 32
assign 1 203 32
new 0 203 32
assign 1 203 32
initializeIfShould 1 203 32
return 1 203 32
assign 1 238 32
undef 1 238 32
assign 1 239 32
new 0 239 32
assign 1 239 32
new 1 239 32
throw 1 239 32
assign 1 241 32
undef 1 241 32
assign 1 242 32
new 0 242 32
assign 1 242 32
new 1 242 32
throw 1 242 32
assign 1 244 32
lengthGet 0 244 32
assign 1 245 32
new 0 245 32
assign 1 245 32
add 1 245 32
assign 1 245 32
toString 0 245 32
assign 1 245 32
add 1 245 32
assign 1 246 32
hashGet 0 246 32
assign 1 252 32
new 0 252 32
assign 1 252 32
greater 1 252 32
assign 1 253 32
new 0 253 32
assign 1 253 32
subtract 1 253 32
assign 1 253 32
new 1 253 32
assign 1 254 32
new 0 254 32
assign 1 254 32
lesser 1 254 32
assign 1 255 32
new 0 255 32
assign 1 255 32
subtract 1 255 32
assign 1 255 32
get 1 255 32
put 2 255 32
incrementValue 0 254 32
assign 1 380 32
new 0 380 32
toString 0 382 32
return 1 384 32
assign 1 409 32
undef 1 409 32
assign 1 410 32
new 0 410 32
assign 1 410 32
new 1 410 32
throw 1 410 32
assign 1 412 32
undef 1 412 32
assign 1 413 32
new 0 413 32
assign 1 413 32
new 1 413 32
throw 1 413 32
assign 1 415 32
new 0 415 32
assign 1 415 32
add 1 415 32
assign 1 415 32
toString 0 415 32
assign 1 415 32
add 1 415 32
assign 1 416 32
hashGet 0 416 32
assign 1 469 32
new 0 469 32
toString 0 470 32
assign 1 472 32
def 1 472 32
assign 1 473 32
new 0 473 32
return 1 473 32
assign 1 475 32
new 0 475 32
return 1 475 32
return 1 509 35
return 1 531 35
assign 1 563 36
new 0 563 36
return 1 563 36
assign 1 595 36
new 0 595 36
return 1 595 36
assign 1 606 32
new 0 606 32
return 1 632 32
assign 1 636 32
tagGet 0 636 32
return 1 636 32
assign 1 640 32
equals 1 640 32
assign 1 640 32
not 0 640 32
return 1 640 32
assign 1 644 32
classNameGet 0 644 32
return 1 644 32
assign 1 648 32
toString 0 648 32
print 0 648 32
assign 1 652 32
toString 0 652 32
echo 0 652 32
assign 1 656 32
create 0 656 32
assign 1 656 32
copyTo 1 656 32
return 1 656 32
assign 1 660 32
undef 1 660 32
return 1 661 32
assign 1 663 32
new 0 663 32
assign 1 663 32
new 2 663 32
assign 1 664 32
new 0 664 32
assign 1 664 32
new 2 664 32
assign 1 665 32
hasNextGet 0 665 32
assign 1 666 32
nextGet 0 666 32
nextSet 1 666 32
assign 1 672 32
classNameGet 0 672 32
return 1 672 32
return 1 678 32
assign 1 684 32
new 1 684 32
return 1 684 32
assign 1 688 32
new 1 688 32
return 1 688 32
assign 1 692 32
new 1 692 32
return 1 692 32
assign 1 696 32
new 0 696 32
return 1 696 32
return 1 719 34
assign 1 766 36
new 0 766 36
return 1 766 36
assign 1 770 32
sameClass 1 770 32
assign 1 770 32
not 0 770 32
return 1 770 32
assign 1 825 36
new 0 825 36
return 1 825 36
assign 1 829 32
sameType 1 829 32
assign 1 829 32
not 0 829 32
return 1 829 32
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemObject();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemObject.bevs_inst = becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemObject.bevs_inst;
}
}
}
