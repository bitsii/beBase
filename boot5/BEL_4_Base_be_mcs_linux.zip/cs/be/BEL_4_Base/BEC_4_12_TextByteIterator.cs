namespace be.BEL_4_Base {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_4_12_TextByteIterator : BEC_6_6_SystemObject {
public BEC_4_12_TextByteIterator() { }
static BEC_4_12_TextByteIterator() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
public static new BEC_4_12_TextByteIterator bevs_inst;
public BEC_4_6_TextString bevp_str;
public BEC_4_3_MathInt bevp_pos;
public BEC_4_3_MathInt bevp_vcopy;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_emptyGet_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_containerGet_0() {
return bevp_str;
} /*method end*/
public override BEC_4_6_TextString bem_serializeToString_0() {
return bevp_str;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_str) {
this.bem_new_1(beva_str);
return this;
} /*method end*/
public virtual BEC_4_12_TextByteIterator bem_new_1(BEC_4_6_TextString beva__str) {
bevp_str = beva__str;
bevp_pos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_vcopy = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_hasNextGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_str.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_greater_1(bevp_pos);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1230 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 1231 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_nextGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_next_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_next_1(BEC_4_6_TextString beva_buf) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_str.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_greater_1(bevp_pos);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1241 */ {
bevt_3_tmpvar_phold = beva_buf.bem_capacityGet_0();
bevt_4_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_lesser_1(bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1242 */ {
bevt_5_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_tmpvar_phold);
} /* Line: 1243 */
bevt_7_tmpvar_phold = beva_buf.bem_sizeGet_0();
bevt_8_tmpvar_phold = bevo_1;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_notEquals_1(bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1245 */ {
bevt_9_tmpvar_phold = beva_buf.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevo_2;
bevt_10_tmpvar_phold = (BEC_4_3_MathInt) bevt_11_tmpvar_phold.bem_once_0();
bevt_9_tmpvar_phold.bem_setValue_1(bevt_10_tmpvar_phold);
} /* Line: 1246 */
bevt_12_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_13_tmpvar_phold = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevp_pos.bem_incrementValue_0();
} /* Line: 1252 */
return beva_buf;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nextInt_1(BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_str.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_greater_1(bevp_pos);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1258 */ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bem_incrementValue_0();
} /* Line: 1260 */
return beva_into;
} /*method end*/
public virtual BEC_4_3_MathInt bem_currentInt_1(BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_3;
bevt_1_tmpvar_phold = bevp_pos.bem_greater_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1266 */ {
bevt_4_tmpvar_phold = bevp_str.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_greaterEquals_1(bevp_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1266 */
 else  /* Line: 1266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1266 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bem_incrementValue_0();
} /* Line: 1269 */
return beva_into;
} /*method end*/
public virtual BEC_4_12_TextByteIterator bem_currentIntSet_1(BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_4;
bevt_1_tmpvar_phold = bevp_pos.bem_greater_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1275 */ {
bevt_4_tmpvar_phold = bevp_str.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_greaterEquals_1(bevp_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1275 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1275 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1275 */
 else  /* Line: 1275 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1275 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bem_incrementValue_0();
} /* Line: 1278 */
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_strSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_str = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_posSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_pos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_vcopyGet_0() {
return bevp_vcopy;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_vcopySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_vcopy = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1206, 1210, 1214, 1218, 1223, 1224, 1225, 1230, 1231, 1233, 1237, 1241, 1242, 1243, 1245, 1246, 1248, 1252, 1254, 1258, 1259, 1260, 1262, 1266, 0, 1267, 1268, 1269, 1271, 1275, 0, 1276, 1277, 1278, 1284, 1288, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23};
/* BEGIN LINEINFO 
assign 1 1206 23
new 0 1206 23
assign 1 1206 23
emptyGet 0 1206 23
new 1 1206 23
return 1 1210 23
return 1 1214 23
new 1 1218 23
assign 1 1223 23
assign 1 1224 23
new 0 1224 23
assign 1 1225 23
new 0 1225 23
assign 1 1230 23
sizeGet 0 1230 23
assign 1 1230 23
greater 1 1230 23
assign 1 1231 23
new 0 1231 23
return 1 1231 23
assign 1 1233 23
new 0 1233 23
return 1 1233 23
assign 1 1237 23
new 0 1237 23
assign 1 1237 23
new 1 1237 23
assign 1 1237 23
next 1 1237 23
return 1 1237 23
assign 1 1241 23
sizeGet 0 1241 23
assign 1 1241 23
greater 1 1241 23
assign 1 1242 23
capacityGet 0 1242 23
assign 1 1242 23
new 0 1242 23
assign 1 1242 23
lesser 1 1242 23
assign 1 1243 23
new 0 1243 23
capacitySet 1 1243 23
assign 1 1245 23
sizeGet 0 1245 23
assign 1 1245 23
new 0 1245 23
assign 1 1245 23
notEquals 1 1245 23
assign 1 1246 23
sizeGet 0 1246 23
assign 1 1246 23
new 0 1246 23
assign 1 1246 23
once 0 1246 23
setValue 1 1246 23
assign 1 1248 23
new 0 1248 23
assign 1 1248 23
getInt 2 1248 23
setIntUnchecked 2 1248 23
incrementValue 0 1252 23
return 1 1254 23
assign 1 1258 23
sizeGet 0 1258 23
assign 1 1258 23
greater 1 1258 23
getInt 2 1259 23
incrementValue 0 1260 23
return 1 1262 23
assign 1 1266 23
new 0 1266 23
assign 1 1266 23
greater 1 1266 23
assign 1 1266 23
sizeGet 0 1266 23
assign 1 1266 23
greaterEquals 1 1266 23
assign 1 0 23
assign 1 0 23
assign 1 0 23
decrementValue 0 1267 23
getInt 2 1268 23
incrementValue 0 1269 23
return 1 1271 23
assign 1 1275 23
new 0 1275 23
assign 1 1275 23
greater 1 1275 23
assign 1 1275 23
sizeGet 0 1275 23
assign 1 1275 23
greaterEquals 1 1275 23
assign 1 0 23
assign 1 0 23
assign 1 0 23
decrementValue 0 1276 23
setIntUnchecked 2 1277 23
incrementValue 0 1278 23
return 1 1284 23
return 1 1288 23
return 1 0 23
assign 1 0 23
return 1 0 23
assign 1 0 23
return 1 0 23
assign 1 0 23
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 833063302: return bem_containerGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 715968403: return bem_posGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 248879165: return bem_byteIteratorIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 108485850: return bem_hasNextGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1763354070: return bem_strGet_0();
case 1102720804: return bem_classNameGet_0();
case 230685860: return bem_vcopyGet_0();
case 1194623572: return bem_nextGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1774436323: return bem_strSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 219603607: return bem_vcopySet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1488067202: return bem_currentIntSet_1((BEC_4_3_MathInt) bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 1048795675: return bem_next_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1196738734: return bem_nextInt_1((BEC_4_3_MathInt) bevd_0);
case 1448425960: return bem_currentInt_1((BEC_4_3_MathInt) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_4_12_TextByteIterator();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_4_12_TextByteIterator.bevs_inst = (BEC_4_12_TextByteIterator)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_4_12_TextByteIterator.bevs_inst;
}
}
}
