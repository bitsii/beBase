namespace be.BEL_4_Base {
/* IO:File: source/build/JSEmitter.be */
public class BEC_5_9_BuildJSEmitter : BEC_5_10_BuildEmitCommon {
public BEC_5_9_BuildJSEmitter() { }
static BEC_5_9_BuildJSEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6A,0x73};
private static byte[] bels_1 = {0x2E,0x6A,0x73};
private static byte[] bels_2 = {};
private static byte[] bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bels_7 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_8 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bels_9 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 5));
private static byte[] bels_10 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bels_11 = {0x29,0x20,0x7B};
private static byte[] bels_12 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_12, 41));
private static byte[] bels_13 = {0x29,0x29};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bels_15 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_18 = {0x28,0x29,0x3B};
private static byte[] bels_19 = {0x7D};
private static byte[] bels_20 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bels_21 = {0x2C,0x20};
private static byte[] bels_22 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_23 = {0x5D,0x3B};
private static byte[] bels_24 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bels_25 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_26 = {0x7D};
private static byte[] bels_27 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_28 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_29 = {0x3B};
private static byte[] bels_30 = {0x7D};
private static byte[] bels_31 = {0x5D,0x3B};
private static byte[] bels_32 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_32, 10));
private static byte[] bels_33 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_34 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_35 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bels_36 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x28,0x29};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_37, 2));
private static byte[] bels_38 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_39 = {0x29,0x3B};
private static byte[] bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_41 = {0x29,0x3B};
private static byte[] bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_43 = {0x2C,0x20};
private static byte[] bels_44 = {0x29,0x3B};
private static byte[] bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_46 = {0x2C,0x20};
private static byte[] bels_47 = {0x29,0x3B};
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bels_51 = {};
private static byte[] bels_52 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_53 = {0x28,0x29,0x3B};
private static byte[] bels_54 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bels_55 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bels_56 = {0x22,0x3B};
private static byte[] bels_57 = {};
private static byte[] bels_58 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_59 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_60 = {0x28,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x36,0x5F,0x37,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x28,0x29,0x29,0x2E,0x62,0x65,0x6D,0x5F,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30,0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_60, 60));
private static byte[] bels_61 = {0x76,0x61,0x72,0x20};
private static byte[] bels_62 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bels_63 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_63, 25));
private static byte[] bels_64 = {0x20,0x7B};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_64, 2));
private static byte[] bels_65 = {0x74,0x68,0x69,0x73};
private static byte[] bels_66 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_66, 17));
private static byte[] bels_67 = {0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_67, 3));
private static byte[] bels_68 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_68, 38));
private static byte[] bels_69 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_69, 4));
private static byte[] bels_70 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_70, 21));
private static byte[] bels_71 = {0x29};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_71, 1));
private static byte[] bels_72 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_72, 4));
private static byte[] bels_73 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_73, 23));
private static byte[] bels_74 = {0x29};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_74, 1));
private static byte[] bels_75 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_75, 4));
private static byte[] bels_76 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_76, 27));
private static byte[] bels_77 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_77, 22));
private static byte[] bels_78 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_78, 2));
private static byte[] bels_79 = {0x29};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_79, 1));
private static byte[] bels_80 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_24 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_80, 4));
private static byte[] bels_81 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_4_6_TextString bevo_25 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_81, 32));
private static byte[] bels_82 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_26 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_82, 22));
private static byte[] bels_83 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_27 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_83, 2));
private static byte[] bels_84 = {0x29};
private static BEC_4_6_TextString bevo_28 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_84, 1));
private static byte[] bels_85 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_86 = {0x76,0x61,0x72,0x20};
private static byte[] bels_87 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_88 = {0x7D};
private static byte[] bels_89 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_4_6_TextString bevo_29 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_89, 5));
private static byte[] bels_90 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_30 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {};
private static byte[] bels_92 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_4_6_TextString bevo_31 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_92, 11));
private static byte[] bels_93 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_4_6_TextString bevo_32 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_93, 5));
private static byte[] bels_94 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_33 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_94, 3));
private static byte[] bels_95 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_4_6_TextString bevo_34 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_95, 11));
private static byte[] bels_96 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_35 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_96, 4));
private static byte[] bels_97 = {0x3B};
private static BEC_4_6_TextString bevo_36 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_97, 1));
private static byte[] bels_98 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_99 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_100 = {};
private static byte[] bels_101 = {};
private static byte[] bels_102 = {};
private static byte[] bels_103 = {};
private static byte[] bels_104 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_105 = {};
private static byte[] bels_106 = {};
private static byte[] bels_107 = {};
private static byte[] bels_108 = {};
private static byte[] bels_109 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_4_6_TextString bevo_37 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_109, 7));
private static byte[] bels_110 = {0x3A,0x20};
private static BEC_4_6_TextString bevo_38 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_110, 2));
private static byte[] bels_111 = {};
private static byte[] bels_112 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_113 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_39 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_113, 22));
private static byte[] bels_114 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_4_6_TextString bevo_40 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_114, 5));
private static byte[] bels_115 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_116 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bels_117 = {0x29,0x20,0x7B};
private static byte[] bels_118 = {};
private static byte[] bels_119 = {0x5F};
private static BEC_4_6_TextString bevo_41 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_119, 1));
private static byte[] bels_120 = {0x62,0x65,0x5F};
private static BEC_4_6_TextString bevo_42 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_120, 3));
public static new BEC_5_9_BuildJSEmitter bevs_inst;
public BEC_4_6_TextString bevp_allOnceDecs;
public BEC_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_6_6_SystemObject bem_new_1(BEC_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_0));
bevp_fileExt = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_1));
bevp_exceptDec = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_4_6_TextString) (new BEC_4_6_TextString(44, bels_3));
bevp_falseValue = (BEC_4_6_TextString) (new BEC_4_6_TextString(45, bels_4));
bevp_instanceEqual = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_5));
bevp_instanceNotEqual = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_6));
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_acceptThrow_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(38, bels_7));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_4_tmpvar_phold = this.bem_formTarg_1(bevt_5_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_8));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_acceptCatch_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_catchVar = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpvar_phold.bem_add_1(bevt_1_tmpvar_phold);
bevp_methodCatch = bevp_methodCatch.bem_increment_0();
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_10));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_11));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_firstGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpvar_phold = bevo_1;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_8_tmpvar_phold, bevt_12_tmpvar_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_4_6_TextString beva_belsBase) {
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_lstringStart_2(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_belsName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_14));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_15));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_buildCreate_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(37, bels_16));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_17));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_10_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_relEmitName_1(bevt_12_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_18));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_19));
bevt_14_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_14_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildPropList_0() {
BEC_5_8_BuildClassSyn bevl_syn = null;
BEC_9_5_ContainerArray bevl_ptyList = null;
BEC_5_4_LogicBool bevl_first = null;
BEC_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_5_8_BuildClassSyn) bevt_1_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(26, bels_20));
bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevl_first = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = bevl_ptyList.bem_arrayIteratorGet_0();
while (true)
 /* Line: 77 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevl_ptySyn = (BEC_5_6_BuildPtySyn) bevt_0_tmpvar_loop.bem_nextGet_0();
if (bevl_first.bevi_bool) /* Line: 78 */ {
bevl_first = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 79 */
 else  /* Line: 80 */ {
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_21));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpvar_phold);
} /* Line: 81 */
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_22));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold.bem_addValue_1(bevp_q);
} /* Line: 83 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_23));
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_12_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_buildInitial_0() {
BEC_5_11_BuildClassConfig bevl_newcc = null;
BEC_4_6_TextString bevl_stinst = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_0_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(50, bels_24));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_25));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_26));
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(41, bels_27));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_11_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_28));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) bevt_17_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_29));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_30));
bevt_20_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevp_nl);
this.bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_lstringByte_5(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_lival, BEC_4_3_MathInt beva_lipos, BEC_4_3_MathInt beva_bcode, BEC_4_6_TextString beva_hs) {
BEC_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_lstringEnd_1(BEC_4_6_TextString beva_sdec) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_31));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_nameForVar_1(BEC_5_3_BuildVar beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevt_2_tmpvar_phold = bevo_3;
bevt_3_tmpvar_phold = beva_v.bem_nameGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /* Line: 128 */
bevt_4_tmpvar_phold = base.bem_nameForVar_1(beva_v);
return bevt_4_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_emitLib_0() {
BEC_2_4_6_IOFileWriter bevl_libe = null;
BEC_4_6_TextString bevl_typeInstances = null;
BEC_4_6_TextString bevl_libInit = null;
BEC_4_6_TextString bevl_notNullInitConstruct = null;
BEC_4_6_TextString bevl_notNullInitDefault = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_4_6_TextString bevl_nc = null;
BEC_4_6_TextString bevl_smap = null;
BEC_4_6_TextString bevl_smk = null;
BEC_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_5_11_BuildClassConfig bevl_maincc = null;
BEC_4_6_TextString bevl_main = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_9_3_11_ContainerSetKeyIterator bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_4_6_TextString bevt_107_tmpvar_phold = null;
bevl_libe = this.bem_getLibOutput_0();
bevl_typeInstances = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_libInit = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 142 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(50, bels_33));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_12_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_34));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_17_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_16_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_relEmitName_1(bevt_18_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_35));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 148 */ {
bevt_24_tmpvar_phold = bevo_4;
bevt_28_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_27_tmpvar_phold);
bevt_29_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_relEmitName_1(bevt_29_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_30_tmpvar_phold = bevo_5;
bevl_nc = bevt_23_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(75, bels_38));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) bevt_33_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_39));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 157 */ {
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(73, bels_40));
bevt_41_tmpvar_phold = (BEC_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) bevt_41_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_41));
bevt_39_tmpvar_phold = (BEC_4_6_TextString) bevt_40_tmpvar_phold.bem_addValue_1(bevt_43_tmpvar_phold);
bevt_39_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 158 */
} /* Line: 157 */
} /* Line: 148 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_smap = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_44_tmpvar_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpvar_loop = bevt_44_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 166 */ {
bevt_45_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 166 */ {
bevl_smk = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(52, bels_42));
bevt_52_tmpvar_phold = (BEC_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_55_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bem_quoteGet_0();
bevt_51_tmpvar_phold = (BEC_4_6_TextString) bevt_52_tmpvar_phold.bem_addValue_1(bevt_54_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_4_6_TextString) bevt_51_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_quoteGet_0();
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_58_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_43));
bevt_48_tmpvar_phold = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpvar_phold = (BEC_4_6_TextString) bevt_48_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_60_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_44));
bevt_46_tmpvar_phold = (BEC_4_6_TextString) bevt_47_tmpvar_phold.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_46_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(53, bels_45));
bevt_67_tmpvar_phold = (BEC_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_quoteGet_0();
bevt_66_tmpvar_phold = (BEC_4_6_TextString) bevt_67_tmpvar_phold.bem_addValue_1(bevt_69_tmpvar_phold);
bevt_65_tmpvar_phold = (BEC_4_6_TextString) bevt_66_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bem_quoteGet_0();
bevt_64_tmpvar_phold = (BEC_4_6_TextString) bevt_65_tmpvar_phold.bem_addValue_1(bevt_71_tmpvar_phold);
bevt_73_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_46));
bevt_63_tmpvar_phold = (BEC_4_6_TextString) bevt_64_tmpvar_phold.bem_addValue_1(bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpvar_phold = (BEC_4_6_TextString) bevt_63_tmpvar_phold.bem_addValue_1(bevt_74_tmpvar_phold);
bevt_75_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_47));
bevt_61_tmpvar_phold = (BEC_4_6_TextString) bevt_62_tmpvar_phold.bem_addValue_1(bevt_75_tmpvar_phold);
bevt_61_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 169 */
 else  /* Line: 166 */ {
break;
} /* Line: 166 */
} /* Line: 166 */
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_typeInstances);
bevt_78_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bem_sizeGet_0();
bevt_79_tmpvar_phold = bevo_6;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_equals_1(bevt_79_tmpvar_phold);
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 178 */ {
bevt_81_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(110, bels_48));
bevt_80_tmpvar_phold = (BEC_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_81_tmpvar_phold);
bevt_80_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(112, bels_49));
bevt_82_tmpvar_phold = (BEC_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_83_tmpvar_phold);
bevt_82_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(97, bels_50));
bevt_84_tmpvar_phold = (BEC_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_85_tmpvar_phold);
bevt_84_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 181 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpvar_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpvar_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_51));
bevt_90_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_52));
bevt_89_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpvar_phold = (BEC_4_6_TextString) bevt_89_tmpvar_phold.bem_addValue_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_53));
bevt_87_tmpvar_phold = (BEC_4_6_TextString) bevt_88_tmpvar_phold.bem_addValue_1(bevt_92_tmpvar_phold);
bevt_87_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpvar_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_95_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(56, bels_54));
bevt_94_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_95_tmpvar_phold);
bevt_94_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 195 */
bevt_99_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(52, bels_55));
bevt_98_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_99_tmpvar_phold);
bevt_101_tmpvar_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_97_tmpvar_phold = (BEC_4_6_TextString) bevt_98_tmpvar_phold.bem_addValue_1(bevt_100_tmpvar_phold);
bevt_102_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_56));
bevt_96_tmpvar_phold = (BEC_4_6_TextString) bevt_97_tmpvar_phold.bem_addValue_1(bevt_102_tmpvar_phold);
bevt_96_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_57));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpvar_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_105_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_58));
bevt_104_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_tmpvar_phold);
bevt_104_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_59));
bevt_106_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_107_tmpvar_phold);
bevt_106_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 205 */
bevl_libe.bem_write_1(bevl_main);
this.bem_finishLibOutput_1(bevl_libe);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_procStartGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_7;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_decForVar_2(BEC_4_6_TextString beva_b, BEC_5_3_BuildVar beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 218 */ {
} /* Line: 218 */
 else  /* Line: 220 */ {
bevt_2_tmpvar_phold = beva_v.bem_isArgGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_not_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_61));
beva_b.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 222 */
bevt_4_tmpvar_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 224 */
return this;
} /*method end*/
public override BEC_4_6_TextString bem_boolTypeGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_62));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_mainStartGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpvar_phold = bevo_9;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_superNameGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_65));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_extend_1(BEC_4_6_TextString beva_parent) {
BEC_4_6_TextString bevl_extstr = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_parent);
bevt_5_tmpvar_phold = bevo_11;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevl_extstr = (BEC_4_6_TextString) bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevl_extstr.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_12;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevl_extstr = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_4_6_TextString bem_lintConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_13;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_14;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_15;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_lfloatConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_17;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_lstringConstruct_5(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node, BEC_4_6_TextString beva_belsName, BEC_4_3_MathInt beva_lisz, BEC_5_4_LogicBool beva_isOnce) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 256 */ {
bevt_8_tmpvar_phold = bevo_19;
bevt_10_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_20;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_21;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(beva_belsName);
bevt_14_tmpvar_phold = bevo_22;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_lisz);
bevt_15_tmpvar_phold = bevo_23;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /* Line: 257 */
bevt_24_tmpvar_phold = bevo_24;
bevt_26_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_25;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = bevo_26;
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(beva_belsName);
bevt_30_tmpvar_phold = bevo_27;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(beva_lisz);
bevt_31_tmpvar_phold = bevo_28;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
return bevt_16_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_classBeginGet_0() {
BEC_4_6_TextString bevl_extends = null;
BEC_4_6_TextString bevl_begin = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevl_extends = this.bem_extend_1((BEC_4_6_TextString) bevt_1_tmpvar_phold);
} /* Line: 264 */
 else  /* Line: 265 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(24, bels_85));
bevl_extends = this.bem_extend_1(bevt_3_tmpvar_phold);
} /* Line: 266 */
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_86));
bevt_6_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_87));
bevl_begin = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_88));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_4_6_TextString bem_emitNameForCall_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1796577138, BEL_4_Base.bevn_superCallGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 282 */ {
bevt_3_tmpvar_phold = bevo_29;
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 283 */
bevt_7_tmpvar_phold = bevo_30;
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
return bevt_6_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_classEndGet_0() {
BEC_4_6_TextString bevl_end = null;
BEC_5_4_BuildNode bevl_node = null;
BEC_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
bevl_end = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_91));
bevt_0_tmpvar_loop = bevp_superCalls.bem_arrayIteratorGet_0();
while (true)
 /* Line: 290 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevl_node = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpvar_phold = bevo_31;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_32;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevo_33;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_34;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_35;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_22_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 291 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
return bevl_end;
} /*method end*/
public override BEC_6_6_SystemObject bem_writeOnceDecs_2(BEC_6_6_SystemObject beva_cle, BEC_6_6_SystemObject beva_onceDecs) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevp_allOnceDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 301 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return bevt_1_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_2_4_6_IOFileWriter bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getLibOutput_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_finishClassOutput_1(BEC_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_4_6_TextString bevl_p = null;
BEC_2_4_IOFile bevl_jsi = null;
BEC_4_6_TextString bevl_inc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_IOFile bevt_4_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_5_tmpvar_phold = null;
BEC_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_IOFile bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_10_SystemParameters bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_13_tmpvar_phold = null;
BEC_6_10_SystemParameters bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 317 */ {
bevp_lineCount = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_5_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_fileGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_existsGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 319 */ {
bevt_7_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_fileGet_0();
bevt_6_tmpvar_phold.bem_makeDirs_0();
} /* Line: 320 */
bevt_9_tmpvar_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevp_shlibe = (BEC_2_4_6_IOFileWriter) bevt_8_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevt_11_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_98));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_has_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevt_14_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_99));
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_get_1(bevt_15_tmpvar_phold);
bevt_0_tmpvar_loop = bevt_13_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 325 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 325 */ {
bevl_p = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_17_tmpvar_phold = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpvar_phold.bem_fileGet_0();
bevt_19_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_4_6_TextString) bevt_18_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_20_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_21_tmpvar_phold = this.bem_countLines_1(bevl_inc);
bevp_lineCount.bem_addValue_1(bevt_21_tmpvar_phold);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 330 */
 else  /* Line: 325 */ {
break;
} /* Line: 325 */
} /* Line: 325 */
} /* Line: 325 */
} /* Line: 324 */
return bevp_shlibe;
} /*method end*/
public override BEC_6_6_SystemObject bem_finishLibOutput_1(BEC_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_4_6_TextString bem_beginNs_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_100));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_beginNs_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_101));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_libNs_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_102));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_endNs_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_103));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_klassDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_104));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_spropDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_105));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_propDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_106));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_initialDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_107));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_baseSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_108));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_overrideSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_37;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_varName);
bevt_4_tmpvar_phold = bevo_38;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_typeName);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_onceDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_111));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_getInitialInst_1(BEC_5_11_BuildClassConfig beva_newcc) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_112));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_onceVarDec_1(BEC_4_6_TextString beva_count) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_39;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_40;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_count);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_startMethod_5(BEC_4_6_TextString beva_mtdDec, BEC_5_11_BuildClassConfig beva_returnType, BEC_4_6_TextString beva_mtdName, BEC_4_6_TextString beva_argDecs, BEC_6_6_SystemObject beva_exceptDec) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_115));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_116));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_117));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_formCast_1(BEC_5_11_BuildClassConfig beva_cc) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_118));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_getFullEmitName_2(BEC_4_6_TextString beva_nameSpace, BEC_4_6_TextString beva_emitName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_41;
bevt_1_tmpvar_phold = beva_nameSpace.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_emitName);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_getNameSpace_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_42;
bevt_2_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_5_11_BuildClassConfig bem_getClassConfig_1(BEC_5_8_BuildNamePath beva_np) {
BEC_5_11_BuildClassConfig bevl_cc = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public override BEC_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_5_8_BuildNamePath beva_np) {
BEC_5_11_BuildClassConfig bevl_cc = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public virtual BEC_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_allOnceDecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allOnceDecs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_shlibeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_shlibe = (BEC_2_4_6_IOFileWriter) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {27, 28, 29, 33, 35, 36, 38, 39, 43, 47, 48, 49, 51, 59, 63, 64, 66, 71, 72, 74, 76, 77, 0, 77, 79, 81, 83, 87, 92, 93, 95, 98, 100, 102, 105, 107, 109, 114, 115, 116, 122, 127, 128, 130, 136, 138, 139, 140, 141, 142, 144, 146, 148, 150, 156, 157, 158, 164, 166, 0, 166, 168, 169, 173, 175, 178, 179, 180, 181, 184, 185, 188, 189, 190, 192, 193, 194, 195, 197, 199, 200, 201, 202, 203, 204, 205, 207, 209, 214, 218, 221, 222, 224, 229, 233, 237, 242, 243, 244, 248, 252, 257, 259, 263, 264, 266, 268, 276, 277, 278, 282, 283, 285, 289, 290, 0, 290, 291, 293, 300, 301, 303, 304, 309, 317, 318, 319, 320, 322, 324, 325, 0, 325, 326, 327, 328, 329, 330, 336, 340, 341, 346, 350, 354, 358, 362, 366, 370, 375, 380, 384, 388, 392, 397, 402, 404, 406, 411, 415, 419, 423, 427, 428, 429, 433, 434, 435, 0};
public static new int[] bevs_smnlec
 = new int[] {176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 177, 177, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176};
/* BEGIN LINEINFO 
assign 1 27 176
new 0 27 176
assign 1 28 176
new 0 28 176
assign 1 29 176
new 0 29 176
new 1 33 176
assign 1 35 176
new 0 35 176
assign 1 36 176
new 0 36 176
assign 1 38 176
new 0 38 176
assign 1 39 176
new 0 39 176
assign 1 43 176
new 0 43 176
assign 1 43 176
addValue 1 43 176
assign 1 43 176
secondGet 0 43 176
assign 1 43 176
formTarg 1 43 176
assign 1 43 176
addValue 1 43 176
assign 1 43 176
new 0 43 176
assign 1 43 176
addValue 1 43 176
addValue 1 43 176
assign 1 47 176
new 0 47 176
assign 1 47 176
toString 0 47 176
assign 1 47 176
add 1 47 176
assign 1 48 176
increment 0 48 176
assign 1 49 176
new 0 49 176
assign 1 49 176
addValue 1 49 176
assign 1 49 176
addValue 1 49 176
assign 1 49 176
new 0 49 176
assign 1 49 176
addValue 1 49 176
addValue 1 49 176
assign 1 51 176
containedGet 0 51 176
assign 1 51 176
firstGet 0 51 176
assign 1 51 176
containedGet 0 51 176
assign 1 51 176
firstGet 0 51 176
assign 1 51 176
new 0 51 176
assign 1 51 176
add 1 51 176
assign 1 51 176
new 0 51 176
assign 1 51 176
add 1 51 176
assign 1 51 176
finalAssign 3 51 176
addValue 1 51 176
assign 1 59 176
emitNameGet 0 59 176
assign 1 59 176
addValue 1 59 176
assign 1 59 176
new 0 59 176
assign 1 59 176
addValue 1 59 176
assign 1 59 176
addValue 1 59 176
assign 1 59 176
new 0 59 176
addValue 1 59 176
assign 1 63 176
emitNameGet 0 63 176
assign 1 63 176
addValue 1 63 176
assign 1 63 176
new 0 63 176
assign 1 63 176
addValue 1 63 176
addValue 1 63 176
assign 1 64 176
new 0 64 176
assign 1 64 176
addValue 1 64 176
assign 1 64 176
heldGet 0 64 176
assign 1 64 176
namepathGet 0 64 176
assign 1 64 176
getClassConfig 1 64 176
assign 1 64 176
libNameGet 0 64 176
assign 1 64 176
relEmitName 1 64 176
assign 1 64 176
addValue 1 64 176
assign 1 64 176
new 0 64 176
assign 1 64 176
addValue 1 64 176
addValue 1 64 176
assign 1 66 176
new 0 66 176
assign 1 66 176
addValue 1 66 176
addValue 1 66 176
assign 1 71 176
heldGet 0 71 176
assign 1 71 176
synGet 0 71 176
assign 1 72 176
ptyListGet 0 72 176
assign 1 74 176
emitNameGet 0 74 176
assign 1 74 176
addValue 1 74 176
assign 1 74 176
new 0 74 176
addValue 1 74 176
assign 1 76 176
new 0 76 176
assign 1 77 176
arrayIteratorGet 0 0 176
assign 1 77 176
hasNextGet 0 77 176
assign 1 77 176
nextGet 0 77 176
assign 1 79 176
new 0 79 176
assign 1 81 176
new 0 81 176
addValue 1 81 176
assign 1 83 176
addValue 1 83 176
assign 1 83 176
new 0 83 176
assign 1 83 176
addValue 1 83 176
assign 1 83 176
nameGet 0 83 176
assign 1 83 176
addValue 1 83 176
addValue 1 83 176
assign 1 87 176
new 0 87 176
assign 1 87 176
addValue 1 87 176
addValue 1 87 176
assign 1 92 176
heldGet 0 92 176
assign 1 92 176
namepathGet 0 92 176
assign 1 92 176
getClassConfig 1 92 176
assign 1 93 176
getInitialInst 1 93 176
assign 1 95 176
emitNameGet 0 95 176
assign 1 95 176
addValue 1 95 176
assign 1 95 176
new 0 95 176
assign 1 95 176
addValue 1 95 176
addValue 1 95 176
assign 1 98 176
addValue 1 98 176
assign 1 98 176
new 0 98 176
assign 1 98 176
addValue 1 98 176
addValue 1 98 176
assign 1 100 176
new 0 100 176
assign 1 100 176
addValue 1 100 176
addValue 1 100 176
assign 1 102 176
emitNameGet 0 102 176
assign 1 102 176
addValue 1 102 176
assign 1 102 176
new 0 102 176
assign 1 102 176
addValue 1 102 176
addValue 1 102 176
assign 1 105 176
new 0 105 176
assign 1 105 176
addValue 1 105 176
assign 1 105 176
addValue 1 105 176
assign 1 105 176
new 0 105 176
assign 1 105 176
addValue 1 105 176
addValue 1 105 176
assign 1 107 176
new 0 107 176
assign 1 107 176
addValue 1 107 176
addValue 1 107 176
buildPropList 0 109 176
getCode 2 114 176
assign 1 115 176
toString 0 115 176
addValue 1 116 176
assign 1 122 176
new 0 122 176
assign 1 122 176
addValue 1 122 176
addValue 1 122 176
assign 1 127 176
isPropertyGet 0 127 176
assign 1 128 176
new 0 128 176
assign 1 128 176
nameGet 0 128 176
assign 1 128 176
add 1 128 176
return 1 128 176
assign 1 130 176
nameForVar 1 130 176
return 1 130 176
assign 1 136 176
getLibOutput 0 136 176
assign 1 138 176
new 0 138 176
assign 1 139 176
new 0 139 176
assign 1 140 176
new 0 140 176
assign 1 141 176
new 0 141 176
assign 1 142 176
iteratorGet 0 142 176
assign 1 142 176
hasNextGet 0 142 176
assign 1 144 176
nextGet 0 144 176
assign 1 146 176
new 0 146 176
assign 1 146 176
addValue 1 146 176
assign 1 146 176
addValue 1 146 176
assign 1 146 176
heldGet 0 146 176
assign 1 146 176
namepathGet 0 146 176
assign 1 146 176
toString 0 146 176
assign 1 146 176
addValue 1 146 176
assign 1 146 176
addValue 1 146 176
assign 1 146 176
new 0 146 176
assign 1 146 176
addValue 1 146 176
assign 1 146 176
heldGet 0 146 176
assign 1 146 176
namepathGet 0 146 176
assign 1 146 176
getClassConfig 1 146 176
assign 1 146 176
libNameGet 0 146 176
assign 1 146 176
relEmitName 1 146 176
assign 1 146 176
addValue 1 146 176
assign 1 146 176
new 0 146 176
assign 1 146 176
addValue 1 146 176
addValue 1 146 176
assign 1 148 176
heldGet 0 148 176
assign 1 148 176
synGet 0 148 176
assign 1 148 176
hasDefaultGet 0 148 176
assign 1 150 176
new 0 150 176
assign 1 150 176
heldGet 0 150 176
assign 1 150 176
namepathGet 0 150 176
assign 1 150 176
getClassConfig 1 150 176
assign 1 150 176
libNameGet 0 150 176
assign 1 150 176
relEmitName 1 150 176
assign 1 150 176
add 1 150 176
assign 1 150 176
new 0 150 176
assign 1 150 176
add 1 150 176
assign 1 156 176
new 0 156 176
assign 1 156 176
addValue 1 156 176
assign 1 156 176
addValue 1 156 176
assign 1 156 176
new 0 156 176
assign 1 156 176
addValue 1 156 176
addValue 1 156 176
assign 1 157 176
heldGet 0 157 176
assign 1 157 176
synGet 0 157 176
assign 1 157 176
hasDefaultGet 0 157 176
assign 1 158 176
new 0 158 176
assign 1 158 176
addValue 1 158 176
assign 1 158 176
addValue 1 158 176
assign 1 158 176
new 0 158 176
assign 1 158 176
addValue 1 158 176
addValue 1 158 176
assign 1 164 176
new 0 164 176
assign 1 166 176
keysGet 0 166 176
assign 1 166 176
iteratorGet 0 0 176
assign 1 166 176
hasNextGet 0 166 176
assign 1 166 176
nextGet 0 166 176
assign 1 168 176
new 0 168 176
assign 1 168 176
addValue 1 168 176
assign 1 168 176
new 0 168 176
assign 1 168 176
quoteGet 0 168 176
assign 1 168 176
addValue 1 168 176
assign 1 168 176
addValue 1 168 176
assign 1 168 176
new 0 168 176
assign 1 168 176
quoteGet 0 168 176
assign 1 168 176
addValue 1 168 176
assign 1 168 176
new 0 168 176
assign 1 168 176
addValue 1 168 176
assign 1 168 176
get 1 168 176
assign 1 168 176
addValue 1 168 176
assign 1 168 176
new 0 168 176
assign 1 168 176
addValue 1 168 176
addValue 1 168 176
assign 1 169 176
new 0 169 176
assign 1 169 176
addValue 1 169 176
assign 1 169 176
new 0 169 176
assign 1 169 176
quoteGet 0 169 176
assign 1 169 176
addValue 1 169 176
assign 1 169 176
addValue 1 169 176
assign 1 169 176
new 0 169 176
assign 1 169 176
quoteGet 0 169 176
assign 1 169 176
addValue 1 169 176
assign 1 169 176
new 0 169 176
assign 1 169 176
addValue 1 169 176
assign 1 169 176
get 1 169 176
assign 1 169 176
addValue 1 169 176
assign 1 169 176
new 0 169 176
assign 1 169 176
addValue 1 169 176
addValue 1 169 176
write 1 173 176
write 1 175 176
assign 1 178 176
usedLibrarysGet 0 178 176
assign 1 178 176
sizeGet 0 178 176
assign 1 178 176
new 0 178 176
assign 1 178 176
equals 1 178 176
assign 1 179 176
new 0 179 176
assign 1 179 176
addValue 1 179 176
addValue 1 179 176
assign 1 180 176
new 0 180 176
assign 1 180 176
addValue 1 180 176
addValue 1 180 176
assign 1 181 176
new 0 181 176
assign 1 181 176
addValue 1 181 176
addValue 1 181 176
write 1 184 176
write 1 185 176
assign 1 188 176
new 0 188 176
assign 1 189 176
mainNameGet 0 189 176
fromString 1 189 176
assign 1 190 176
getClassConfig 1 190 176
assign 1 192 176
new 0 192 176
assign 1 193 176
new 0 193 176
assign 1 193 176
addValue 1 193 176
assign 1 193 176
fullEmitNameGet 0 193 176
assign 1 193 176
addValue 1 193 176
assign 1 193 176
new 0 193 176
assign 1 193 176
addValue 1 193 176
addValue 1 193 176
assign 1 194 176
ownProcessGet 0 194 176
assign 1 195 176
new 0 195 176
assign 1 195 176
addValue 1 195 176
addValue 1 195 176
assign 1 197 176
new 0 197 176
assign 1 197 176
addValue 1 197 176
assign 1 197 176
outputPlatformGet 0 197 176
assign 1 197 176
nameGet 0 197 176
assign 1 197 176
addValue 1 197 176
assign 1 197 176
new 0 197 176
assign 1 197 176
addValue 1 197 176
addValue 1 197 176
write 1 199 176
assign 1 200 176
new 0 200 176
write 1 201 176
write 1 202 176
assign 1 203 176
ownProcessGet 0 203 176
assign 1 204 176
new 0 204 176
assign 1 204 176
addValue 1 204 176
addValue 1 204 176
assign 1 205 176
new 0 205 176
assign 1 205 176
addValue 1 205 176
addValue 1 205 176
write 1 207 176
finishLibOutput 1 209 176
assign 1 214 176
new 0 214 176
assign 1 214 176
add 1 214 176
return 1 214 176
assign 1 218 176
isPropertyGet 0 218 176
assign 1 221 176
isArgGet 0 221 176
assign 1 221 176
not 0 221 176
assign 1 222 176
new 0 222 176
addValue 1 222 176
assign 1 224 176
nameForVar 1 224 176
addValue 1 224 176
assign 1 229 176
new 0 229 176
return 1 229 176
assign 1 233 176
new 0 233 176
assign 1 233 176
add 1 233 176
assign 1 233 176
new 0 233 176
assign 1 233 176
add 1 233 176
assign 1 233 176
add 1 233 176
return 1 233 176
assign 1 237 176
new 0 237 176
return 1 237 176
assign 1 242 176
emitNameGet 0 242 176
assign 1 242 176
new 0 242 176
assign 1 242 176
add 1 242 176
assign 1 242 176
add 1 242 176
assign 1 242 176
new 0 242 176
assign 1 242 176
add 1 242 176
assign 1 242 176
addValue 1 242 176
assign 1 243 176
emitNameGet 0 243 176
assign 1 243 176
add 1 243 176
assign 1 243 176
new 0 243 176
assign 1 243 176
add 1 243 176
assign 1 243 176
addValue 1 243 176
return 1 244 176
assign 1 248 176
new 0 248 176
assign 1 248 176
libNameGet 0 248 176
assign 1 248 176
relEmitName 1 248 176
assign 1 248 176
add 1 248 176
assign 1 248 176
new 0 248 176
assign 1 248 176
add 1 248 176
assign 1 248 176
heldGet 0 248 176
assign 1 248 176
literalValueGet 0 248 176
assign 1 248 176
add 1 248 176
assign 1 248 176
new 0 248 176
assign 1 248 176
add 1 248 176
return 1 248 176
assign 1 252 176
new 0 252 176
assign 1 252 176
libNameGet 0 252 176
assign 1 252 176
relEmitName 1 252 176
assign 1 252 176
add 1 252 176
assign 1 252 176
new 0 252 176
assign 1 252 176
add 1 252 176
assign 1 252 176
heldGet 0 252 176
assign 1 252 176
literalValueGet 0 252 176
assign 1 252 176
add 1 252 176
assign 1 252 176
new 0 252 176
assign 1 252 176
add 1 252 176
return 1 252 176
assign 1 257 177
new 0 257 177
assign 1 257 177
libNameGet 0 257 177
assign 1 257 177
relEmitName 1 257 177
assign 1 257 177
add 1 257 177
assign 1 257 177
new 0 257 177
assign 1 257 177
add 1 257 177
assign 1 257 177
emitNameGet 0 257 177
assign 1 257 177
add 1 257 177
assign 1 257 177
new 0 257 177
assign 1 257 177
add 1 257 177
assign 1 257 177
add 1 257 177
assign 1 257 177
new 0 257 177
assign 1 257 177
add 1 257 177
assign 1 257 177
add 1 257 177
assign 1 257 177
new 0 257 177
assign 1 257 177
add 1 257 177
return 1 257 177
assign 1 259 177
new 0 259 177
assign 1 259 177
libNameGet 0 259 177
assign 1 259 177
relEmitName 1 259 177
assign 1 259 177
add 1 259 177
assign 1 259 177
new 0 259 177
assign 1 259 177
add 1 259 177
assign 1 259 177
emitNameGet 0 259 177
assign 1 259 177
add 1 259 177
assign 1 259 177
new 0 259 177
assign 1 259 177
add 1 259 177
assign 1 259 177
add 1 259 177
assign 1 259 177
new 0 259 177
assign 1 259 177
add 1 259 177
assign 1 259 177
add 1 259 177
assign 1 259 177
new 0 259 177
assign 1 259 177
add 1 259 177
return 1 259 177
assign 1 263 176
def 1 263 176
assign 1 264 176
libNameGet 0 264 176
assign 1 264 176
relEmitName 1 264 176
assign 1 264 176
extend 1 264 176
assign 1 266 176
new 0 266 176
assign 1 266 176
extend 1 266 176
assign 1 268 176
new 0 268 176
assign 1 268 176
emitNameGet 0 268 176
assign 1 268 176
addValue 1 268 176
assign 1 268 176
new 0 268 176
assign 1 268 176
addValue 1 268 176
assign 1 276 176
new 0 276 176
assign 1 276 176
addValue 1 276 176
addValue 1 276 176
addValue 1 277 176
return 1 278 176
assign 1 282 176
heldGet 0 282 176
assign 1 282 176
superCallGet 0 282 176
assign 1 283 176
new 0 283 176
assign 1 283 176
heldGet 0 283 176
assign 1 283 176
nameGet 0 283 176
assign 1 283 176
add 1 283 176
return 1 283 176
assign 1 285 176
new 0 285 176
assign 1 285 176
heldGet 0 285 176
assign 1 285 176
nameGet 0 285 176
assign 1 285 176
add 1 285 176
return 1 285 176
assign 1 289 176
new 0 289 176
assign 1 290 176
arrayIteratorGet 0 0 176
assign 1 290 176
hasNextGet 0 290 176
assign 1 290 176
nextGet 0 290 176
assign 1 291 176
emitNameGet 0 291 176
assign 1 291 176
new 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
new 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
heldGet 0 291 176
assign 1 291 176
nameGet 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
new 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
emitNameGet 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
new 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
new 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
heldGet 0 291 176
assign 1 291 176
nameGet 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
new 0 291 176
assign 1 291 176
add 1 291 176
assign 1 291 176
add 1 291 176
addValue 1 291 176
return 1 293 176
assign 1 300 176
undef 1 300 176
assign 1 301 176
new 0 301 176
addValue 1 303 176
assign 1 304 176
new 0 304 176
return 1 304 176
assign 1 309 176
getLibOutput 0 309 176
return 1 309 176
assign 1 317 176
undef 1 317 176
assign 1 318 176
new 0 318 176
assign 1 319 176
parentGet 0 319 176
assign 1 319 176
fileGet 0 319 176
assign 1 319 176
existsGet 0 319 176
assign 1 319 176
not 0 319 176
assign 1 320 176
parentGet 0 320 176
assign 1 320 176
fileGet 0 320 176
makeDirs 0 320 176
assign 1 322 176
fileGet 0 322 176
assign 1 322 176
writerGet 0 322 176
assign 1 322 176
open 0 322 176
assign 1 324 176
paramsGet 0 324 176
assign 1 324 176
new 0 324 176
assign 1 324 176
has 1 324 176
assign 1 325 176
paramsGet 0 325 176
assign 1 325 176
new 0 325 176
assign 1 325 176
get 1 325 176
assign 1 325 176
iteratorGet 0 0 176
assign 1 325 176
hasNextGet 0 325 176
assign 1 325 176
nextGet 0 325 176
assign 1 326 176
apNew 1 326 176
assign 1 326 176
fileGet 0 326 176
assign 1 327 176
readerGet 0 327 176
assign 1 327 176
open 0 327 176
assign 1 327 176
readString 0 327 176
assign 1 328 176
readerGet 0 328 176
close 0 328 176
assign 1 329 176
countLines 1 329 176
addValue 1 329 176
write 1 330 176
return 1 336 176
close 0 340 176
assign 1 341 176
assign 1 346 176
new 0 346 176
return 1 346 176
assign 1 350 176
new 0 350 176
return 1 350 176
assign 1 354 176
new 0 354 176
return 1 354 176
assign 1 358 176
new 0 358 176
return 1 358 176
assign 1 362 176
new 0 362 176
return 1 362 176
assign 1 366 176
new 0 366 176
return 1 366 176
assign 1 370 176
new 0 370 176
return 1 370 176
assign 1 375 176
new 0 375 176
return 1 375 176
assign 1 380 176
new 0 380 176
return 1 380 176
assign 1 384 176
new 0 384 176
assign 1 384 176
add 1 384 176
assign 1 384 176
new 0 384 176
assign 1 384 176
add 1 384 176
assign 1 384 176
add 1 384 176
return 1 384 176
assign 1 388 176
new 0 388 176
return 1 388 176
assign 1 392 176
libNameGet 0 392 176
assign 1 392 176
relEmitName 1 392 176
assign 1 392 176
new 0 392 176
assign 1 392 176
add 1 392 176
return 1 392 176
assign 1 397 176
emitNameGet 0 397 176
assign 1 397 176
new 0 397 176
assign 1 397 176
add 1 397 176
assign 1 397 176
new 0 397 176
assign 1 397 176
add 1 397 176
assign 1 397 176
add 1 397 176
return 1 397 176
assign 1 402 176
emitNameGet 0 402 176
assign 1 402 176
addValue 1 402 176
assign 1 402 176
new 0 402 176
assign 1 402 176
addValue 1 402 176
assign 1 402 176
addValue 1 402 176
assign 1 402 176
new 0 402 176
addValue 1 402 176
addValue 1 404 176
assign 1 406 176
new 0 406 176
assign 1 406 176
addValue 1 406 176
addValue 1 406 176
assign 1 411 176
new 0 411 176
return 1 411 176
assign 1 415 176
new 0 415 176
return 1 415 176
assign 1 419 176
new 0 419 176
assign 1 419 176
add 1 419 176
assign 1 419 176
add 1 419 176
return 1 419 176
assign 1 423 176
new 0 423 176
assign 1 423 176
libEmitName 1 423 176
assign 1 423 176
add 1 423 176
return 1 423 176
assign 1 427 176
getClassConfig 1 427 176
assign 1 428 176
fullEmitNameGet 0 428 176
emitNameSet 1 428 176
return 1 429 176
assign 1 433 176
getLocalClassConfig 1 433 176
assign 1 434 176
fullEmitNameGet 0 434 176
emitNameSet 1 434 176
return 1 435 176
return 1 0 176
assign 1 0 176
return 1 0 176
assign 1 0 176
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1109279973: return bem_spropDecGet_0();
case 397629001: return bem_maxSpillArgsLenGet_0();
case 229958684: return bem_constGet_0();
case 944442837: return bem_classConfGet_0();
case 362974009: return bem_parentConfGet_0();
case 1413054881: return bem_smnlcsGet_0();
case 103017121: return bem_runtimeInitGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1859739893: return bem_methodsGet_0();
case 1529527065: return bem_onceCountGet_0();
case 1947619572: return bem_msynGet_0();
case 89706405: return bem_ccCacheGet_0();
case 708434875: return bem_klassDecGet_0();
case 1967844855: return bem_initialDecGet_0();
case 1774940957: return bem_toString_0();
case 1566392515: return bem_covariantReturnsGet_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 4647121: return bem_doEmit_0();
case 2039613615: return bem_instanceNotEqualGet_0();
case 955058175: return bem_lastMethodBodyLinesGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2001798761: return bem_nlGet_0();
case 1711936384: return bem_baseSmtdDecGet_0();
case 1308786538: return bem_echo_0();
case 160277051: return bem_procStartGet_0();
case 1372235405: return bem_superCallsGet_0();
case 1786051763: return bem_methodCatchGet_0();
case 1081275759: return bem_classesInDepthOrderGet_0();
case 1380285640: return bem_objectCcGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 604504089: return bem_falseValueGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case 378762597: return bem_boolNpGet_0();
case 1727672536: return bem_propDecGet_0();
case 628036310: return bem_lastMethodsSizeGet_0();
case 1487140092: return bem_classEndGet_0();
case 104713553: return bem_new_0();
case 402158238: return bem_inFilePathedGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1177623581: return bem_callNamesGet_0();
case 991179882: return bem_qGet_0();
case 644675716: return bem_ntypesGet_0();
case 1081412016: return bem_many_0();
case 1638160588: return bem_lineCountGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 772789066: return bem_libEmitPathGet_0();
case 2055025483: return bem_serializeContents_0();
case 1312373307: return bem_buildCreate_0();
case 1703922349: return bem_fullLibEmitNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 36542021: return bem_mainEndGet_0();
case 916491491: return bem_emitLib_0();
case 603479476: return bem_allOnceDecsGet_0();
case 1747980150: return bem_smnlecsGet_0();
case 1841706211: return bem_returnTypeGet_0();
case 1073009537: return bem_beginNs_0();
case 2085643372: return bem_stringNpGet_0();
case 1500143225: return bem_useDynMethodsGet_0();
case 1052944126: return bem_csynGet_0();
case 1607412815: return bem_endNs_0();
case 86482693: return bem_overrideSmtdDecGet_0();
case 1923547459: return bem_boolCcGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 498080472: return bem_mnodeGet_0();
case 1820417453: return bem_create_0();
case 962646066: return bem_shlibeGet_0();
case 946095539: return bem_mainInClassGet_0();
case 681402717: return bem_boolTypeGet_0();
case 101343106: return bem_nativeCSlotsGet_0();
case 493012039: return bem_buildGet_0();
case 1354714650: return bem_copy_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 254265568: return bem_buildPropList_0();
case 361542143: return bem_classEmitsGet_0();
case 2019411446: return bem_classBeginGet_0();
case 902412214: return bem_classCallsGet_0();
case 294732055: return bem_floatNpGet_0();
case 729571811: return bem_serializeToString_0();
case 1831751774: return bem_cnodeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 622039562: return bem_intNpGet_0();
case 1240611285: return bem_onceDecsGet_0();
case 786424307: return bem_tagGet_0();
case 991255330: return bem_mainStartGet_0();
case 722876119: return bem_buildClassInfo_0();
case 1910715228: return bem_libEmitNameGet_0();
case 797225458: return bem_dynMethodsGet_0();
case 1181505319: return bem_buildInitial_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1755995201: return bem_transGet_0();
case 1449942744: return bem_instanceEqualGet_0();
case 1012494862: return bem_once_0();
case 1369896794: return bem_objectNpGet_0();
case 1498619679: return bem_getLibOutput_0();
case 287040793: return bem_hashGet_0();
case 1317806639: return bem_baseMtdDecGet_0();
case 483359873: return bem_superNameGet_0();
case 1241388883: return bem_lastMethodBodySizeGet_0();
case 1795655423: return bem_propertyDecsGet_0();
case 1152064310: return bem_instOfGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1102720804: return bem_classNameGet_0();
case 727049506: return bem_exceptDecGet_0();
case 57260628: return bem_getClassOutput_0();
case 388723214: return bem_preClassGet_0();
case 1327064356: return bem_methodBodyGet_0();
case 1064889660: return bem_trueValueGet_0();
case 314718434: return bem_print_0();
case 220901978: return bem_emitLangGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 571409003: return bem_libEmitName_1((BEC_4_6_TextString) bevd_0);
case 367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 1053807407: return bem_trueValueSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 165152860: return bem_libNs_1((BEC_4_6_TextString) bevd_0);
case 1227314505: return bem_acceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 541207893: return bem_complete_1((BEC_5_4_BuildNode) bevd_0);
case 283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case 1702694534: return bem_acceptBraces_1((BEC_5_4_BuildNode) bevd_0);
case 1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 610957309: return bem_intNpSet_1(bevd_0);
case 386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_5_4_BuildNode) bevd_0);
case 593061802: return bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case 891329961: return bem_classCallsSet_1(bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_5_4_BuildNode) bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1820669521: return bem_cnodeSet_1(bevd_0);
case 945327254: return bem_acceptIfEmit_1((BEC_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case 1073009536: return bem_beginNs_1((BEC_4_6_TextString) bevd_0);
case 90260853: return bem_nativeCSlotsSet_1(bevd_0);
case 1022041723: return bem_acceptCatch_1((BEC_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case 1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1901078234: return bem_getEmitName_1((BEC_5_8_BuildNamePath) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_4_6_TextString) bevd_0);
case 1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case 1912465206: return bem_boolCcSet_1(bevd_0);
case 377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case 943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case 1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 70425956: return bem_acceptRbraces_1((BEC_5_4_BuildNode) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 16141842: return bem_onceVarDec_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case 1980754914: return bem_oldacceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 1936537319: return bem_msynSet_1(bevd_0);
case 551679723: return bem_formCast_1((BEC_5_11_BuildClassConfig) bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1438860491: return bem_instanceEqualSet_1(bevd_0);
case 1899632975: return bem_libEmitNameSet_1(bevd_0);
case 478502832: return bem_lstringEnd_1((BEC_4_6_TextString) bevd_0);
case 1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_5_3_BuildVar) bevd_0);
case 2110408325: return bem_acceptMethod_1((BEC_5_4_BuildNode) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_5_4_BuildNode) bevd_0);
case 391075985: return bem_inFilePathedSet_1(bevd_0);
case 36312873: return bem_buildStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 1041861873: return bem_csynSet_1(bevd_0);
case 1931824221: return bem_mangleName_1((BEC_5_8_BuildNamePath) bevd_0);
case 715967253: return bem_exceptDecSet_1(bevd_0);
case 1830623958: return bem_returnTypeSet_1(bevd_0);
case 1562282714: return bem_getInitialInst_1((BEC_5_11_BuildClassConfig) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case 1774969510: return bem_methodCatchSet_1(bevd_0);
case 614561729: return bem_allOnceDecsSet_1(bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case 1358814541: return bem_objectNpSet_1(bevd_0);
case 1820890036: return bem_extend_1((BEC_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case 2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case 65026440: return bem_formTarg_1((BEC_5_4_BuildNode) bevd_0);
case 627952553: return bem_getLocalClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 508002125: return bem_emitting_1((BEC_4_6_TextString) bevd_0);
case 707569329: return bem_getTraceInfo_1((BEC_5_4_BuildNode) bevd_0);
case 724180734: return bem_acceptClass_1((BEC_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_5_4_BuildNode) bevd_0, (BEC_5_8_BuildNamePath) bevd_1);
case 1978614329: return bem_lintConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1604046278: return bem_lfloatConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 569933480: return bem_lstringStart_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1697242261: return bem_overrideSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1671519971: return bem_countLines_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 6388749: return bem_decForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 722876117: return bem_buildClassInfo_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_5_4_BuildNode) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_5_8_BuildNamePath) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_6_6_SystemObject bemd_5(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3, BEC_6_6_SystemObject bevd_4) {
switch (callHash) {
case 316092711: return bem_startMethod_5((BEC_4_6_TextString) bevd_0, (BEC_5_11_BuildClassConfig) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_6_TextString) bevd_3, bevd_4);
case 2023930725: return bem_lstringByte_5((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_4_6_TextString) bevd_4);
case 1591575024: return bem_lstringConstruct_5((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_9_BuildJSEmitter.bevs_inst = (BEC_5_9_BuildJSEmitter)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_9_BuildJSEmitter.bevs_inst;
}
}
}
