namespace be.BEL_4_Base {

using System;
    /* IO:File: source/base/Array.be */
public class BEC_2_9_5_ContainerArray : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerArray() { }
static BEC_2_9_5_ContainerArray() { }

   
    public BEC_2_6_6_SystemObject[] bevi_array;
    
   
   
   public BEC_2_9_5_ContainerArray(BEC_2_6_6_SystemObject[] bevi_array) {
        this.bevi_array = bevi_array;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_array.Length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_array.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
public static new BEC_2_9_5_ContainerArray bevs_inst;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpvar_phold, bevt_2_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_new_1(BEC_2_4_3_MathInt beva_leni) {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_leni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
if (beva_capi == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 145 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 145 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bels_0));
bevt_3_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 146 */
if (bevp_length == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 148 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 151 */ {
return this;
} /* Line: 152 */
} /* Line: 151 */

      bevi_array = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_2_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_2_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 179 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 180 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_varrayGet_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_varraySet_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevp_length.bem_subtract_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bels_1));
bevt_2_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 213 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 215 */ {
bevt_6_tmpvar_phold = bevo_7;
bevt_5_tmpvar_phold = beva_posi.bem_add_1(bevt_6_tmpvar_phold);
this.bem_lengthSet_1(bevt_5_tmpvar_phold);
} /* Line: 216 */

      this.bevi_array[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 227 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
 else  /* Line: 227 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 227 */ {

      bevl_val = this.bevi_array[beva_posi.bevi_int];
      } /* Line: 228 */
return bevl_val;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_1_tmpvar_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_i = beva_pos;
while (true)
 /* Line: 240 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_5_tmpvar_phold = bevo_10;
bevt_4_tmpvar_phold = bevl_i.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = this.bem_get_1(bevt_4_tmpvar_phold);
this.bem_put_2(bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 240 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
this.bem_put_2(bevl_fl, null);
bevt_7_tmpvar_phold = bevo_11;
bevt_6_tmpvar_phold = bevp_length.bem_subtract_1(bevt_7_tmpvar_phold);
this.bem_lengthSet_1(bevt_6_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 245 */
bevt_9_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_3_9_5_8_ContainerArrayIterator) (new BEC_3_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_5_8_ContainerArrayIterator bem_arrayIteratorGet_0() {
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_3_9_5_8_ContainerArrayIterator) (new BEC_3_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_clear_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 259 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 259 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 259 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_5_ContainerArray bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_n = (BEC_2_9_5_ContainerArray) this.bem_create_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 266 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_1_tmpvar_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 266 */
 else  /* Line: 266 */ {
break;
} /* Line: 266 */
} /* Line: 266 */
return (BEC_2_6_6_SystemObject) bevl_n;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(beva_len);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(bevp_length);
return (BEC_2_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_add_1(BEC_2_9_5_ContainerArray beva_xi) {
BEC_2_9_5_ContainerArray bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_1_tmpvar_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_tmpvar_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_length.bem_add_1(bevt_4_tmpvar_phold);
bevl_yi = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_loop = this.bem_arrayIteratorGet_0();
while (true)
 /* Line: 278 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevl_c = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 279 */
 else  /* Line: 278 */ {
break;
} /* Line: 278 */
} /* Line: 278 */
bevt_1_tmpvar_loop = beva_xi.bem_arrayIteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_6_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevl_c = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
return (BEC_2_9_5_ContainerArray) bevl_yi;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_sort_0() {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) this.bem_mergeSort_0();
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_sortValue_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
this.bem_sortValue_2(bevt_0_tmpvar_phold, bevp_length);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_start;
while (true)
 /* Line: 296 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevl_c = bevl_i;
bevl_j = bevl_i;
while (true)
 /* Line: 298 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 298 */ {
bevt_3_tmpvar_phold = this.bem_get_1(bevl_j);
bevt_4_tmpvar_phold = this.bem_get_1(bevl_c);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 299 */ {
bevl_c = bevl_j;
} /* Line: 300 */
bevl_j = bevl_j.bem_increment_0();
} /* Line: 298 */
 else  /* Line: 298 */ {
break;
} /* Line: 298 */
} /* Line: 298 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpvar_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpvar_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 296 */
 else  /* Line: 296 */ {
break;
} /* Line: 296 */
} /* Line: 296 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_mergeIn_2(BEC_2_9_5_ContainerArray beva_first, BEC_2_9_5_ContainerArray beva_second) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_si = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 315 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 315 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 316 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 316 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 316 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 316 */
 else  /* Line: 316 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 316 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpvar_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 319 */ {
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 321 */
 else  /* Line: 322 */ {
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 324 */
} /* Line: 319 */
 else  /* Line: 316 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 326 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 329 */
 else  /* Line: 316 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 330 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 333 */
} /* Line: 316 */
} /* Line: 316 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 335 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_mergeSort_0() {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) this.bem_mergeSort_2(bevt_1_tmpvar_phold, bevp_length);
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_5_ContainerArray bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_5_ContainerArray bevl_fa = null;
BEC_2_9_5_ContainerArray bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpvar_phold = bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_2_tmpvar_phold = this.bem_create_1(bevt_3_tmpvar_phold);
return (BEC_2_9_5_ContainerArray) bevt_2_tmpvar_phold;
} /* Line: 346 */
 else  /* Line: 345 */ {
bevt_5_tmpvar_phold = bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 347 */ {
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_5_ContainerArray) this.bem_create_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_tmpvar_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
return (BEC_2_9_5_ContainerArray) bevl_ra;
} /* Line: 350 */
 else  /* Line: 351 */ {
bevt_9_tmpvar_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpvar_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_2_9_5_ContainerArray) this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_2_9_5_ContainerArray) this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_5_ContainerArray) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_5_ContainerArray) bevl_ra;
} /* Line: 359 */
} /* Line: 345 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 364 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_2));
bevt_1_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 365 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 371 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_array, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 388 */
while (true)
 /* Line: 391 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 391 */ {

         this.bevi_array[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 397 */
 else  /* Line: 391 */ {
break;
} /* Line: 391 */
} /* Line: 391 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 403 */ {
while (true)
 /* Line: 404 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 404 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 405 */
 else  /* Line: 404 */ {
break;
} /* Line: 404 */
} /* Line: 404 */
} /* Line: 404 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 411 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 412 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 417 */ {

       this.bevi_array[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 423 */
 else  /* Line: 424 */ {
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) bevp_length.bem_copy_0();
this.bem_put_2(bevt_1_tmpvar_phold, beva_val);
} /* Line: 426 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_addValue_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 431 */ {
bevt_2_tmpvar_phold = beva_val.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 431 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 431 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 431 */
 else  /* Line: 431 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 431 */ {
this.bem_addAll_1(beva_val);
} /* Line: 432 */
 else  /* Line: 433 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 434 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 440 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 440 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevt_3_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 442 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 442 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 442 */
 else  /* Line: 442 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 442 */ {
return bevl_i;
} /* Line: 443 */
bevl_i.bevi_int++;
} /* Line: 440 */
 else  /* Line: 440 */ {
break;
} /* Line: 440 */
} /* Line: 440 */
return null;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 450 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 451 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 470 */ {
bevt_3_tmpvar_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpvar_phold = bevo_15;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_divide_1(bevt_4_tmpvar_phold);
bevl_mid = bevt_2_tmpvar_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 473 */ {
return bevl_mid;
} /* Line: 474 */
 else  /* Line: 473 */ {
bevt_6_tmpvar_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 475 */ {
bevl_low = bevl_mid;
} /* Line: 477 */
 else  /* Line: 473 */ {
bevt_7_tmpvar_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 478 */ {
bevl_high = bevl_mid;
} /* Line: 480 */
} /* Line: 473 */
} /* Line: 473 */
if (bevl_lastMid == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 483 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 483 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 483 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 483 */
 else  /* Line: 483 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 483 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 484 */ {
bevt_11_tmpvar_phold = this.bem_get_1(bevl_low);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 484 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 484 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 484 */
 else  /* Line: 484 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 484 */ {
return bevl_low;
} /* Line: 485 */
return null;
} /* Line: 487 */
bevl_lastMid = bevl_mid;
bevt_12_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 490 */ {
return null;
} /* Line: 491 */
} /* Line: 490 */
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {137, 137, 137, 137, 137, 141, 145, 145, 0, 145, 145, 0, 0, 146, 146, 146, 148, 148, 151, 151, 152, 168, 169, 170, 175, 179, 179, 179, 180, 180, 182, 182, 192, 192, 196, 196, 200, 200, 204, 204, 204, 208, 208, 208, 208, 212, 212, 212, 213, 213, 213, 215, 215, 216, 216, 216, 227, 227, 227, 227, 227, 0, 0, 0, 234, 238, 238, 239, 239, 240, 240, 240, 241, 241, 241, 241, 240, 243, 244, 244, 244, 245, 245, 247, 247, 251, 251, 255, 255, 259, 259, 259, 260, 259, 265, 266, 266, 266, 267, 267, 266, 269, 272, 272, 274, 274, 277, 277, 277, 277, 278, 0, 278, 278, 279, 281, 0, 281, 281, 282, 284, 288, 288, 292, 292, 296, 296, 296, 297, 298, 298, 298, 299, 299, 299, 300, 298, 303, 304, 304, 305, 296, 310, 311, 312, 313, 314, 315, 315, 316, 316, 316, 316, 0, 0, 0, 317, 318, 319, 320, 321, 323, 324, 326, 326, 327, 328, 329, 330, 330, 331, 332, 333, 335, 340, 340, 340, 344, 345, 345, 345, 346, 346, 346, 347, 347, 347, 348, 348, 349, 349, 349, 350, 352, 352, 353, 354, 355, 356, 357, 358, 359, 364, 365, 365, 365, 371, 371, 372, 388, 391, 391, 397, 399, 403, 403, 404, 405, 405, 411, 411, 412, 412, 417, 417, 423, 426, 426, 431, 431, 431, 0, 0, 0, 432, 434, 440, 440, 440, 441, 442, 442, 442, 0, 0, 0, 443, 440, 446, 450, 450, 450, 451, 451, 453, 453, 459, 459, 459, 466, 467, 471, 471, 471, 471, 472, 473, 474, 475, 477, 478, 480, 483, 483, 483, 483, 0, 0, 0, 484, 484, 0, 0, 0, 485, 487, 489, 490, 491, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {51, 52, 53, 54, 55, 59, 70, 75, 76, 79, 84, 85, 88, 92, 93, 94, 96, 101, 102, 107, 108, 113, 114, 115, 119, 126, 127, 132, 133, 134, 136, 137, 147, 148, 152, 153, 158, 159, 164, 165, 166, 172, 173, 174, 175, 185, 186, 191, 192, 193, 194, 196, 201, 202, 203, 204, 216, 217, 222, 223, 228, 229, 232, 236, 242, 257, 262, 263, 264, 265, 268, 273, 274, 275, 276, 277, 278, 284, 285, 286, 287, 288, 289, 291, 292, 296, 297, 301, 302, 307, 310, 315, 316, 317, 330, 331, 334, 339, 340, 341, 342, 348, 352, 353, 357, 358, 370, 371, 372, 373, 374, 374, 377, 379, 380, 386, 386, 389, 391, 392, 398, 402, 403, 407, 408, 422, 425, 430, 431, 432, 435, 440, 441, 442, 443, 445, 447, 453, 454, 455, 456, 457, 480, 481, 482, 483, 484, 487, 492, 493, 498, 499, 504, 505, 508, 512, 515, 516, 517, 519, 520, 523, 524, 528, 533, 534, 535, 536, 539, 544, 545, 546, 547, 551, 562, 563, 564, 584, 585, 586, 591, 592, 593, 594, 597, 598, 603, 604, 605, 606, 607, 608, 609, 612, 613, 614, 615, 616, 617, 618, 619, 620, 628, 630, 631, 632, 640, 645, 646, 649, 653, 658, 661, 667, 674, 679, 682, 684, 685, 697, 702, 703, 704, 711, 716, 719, 722, 723, 731, 736, 737, 739, 742, 746, 749, 752, 763, 766, 771, 772, 773, 778, 779, 781, 784, 788, 791, 793, 799, 806, 807, 812, 813, 814, 816, 817, 822, 823, 824, 845, 846, 849, 850, 851, 852, 853, 854, 856, 859, 861, 864, 866, 870, 875, 876, 881, 882, 885, 889, 893, 894, 896, 899, 903, 906, 908, 910, 911, 913, 918, 921, 924, 927};
/* BEGIN LINEINFO 
assign 1 137 51
new 0 137 51
assign 1 137 52
once 0 137 52
assign 1 137 53
new 0 137 53
assign 1 137 54
once 0 137 54
new 2 137 55
new 2 141 59
assign 1 145 70
undef 1 145 75
assign 1 0 76
assign 1 145 79
undef 1 145 84
assign 1 0 85
assign 1 0 88
assign 1 146 92
new 0 146 92
assign 1 146 93
new 1 146 93
throw 1 146 94
assign 1 148 96
def 1 148 101
assign 1 151 102
equals 1 151 107
return 1 152 108
assign 1 168 113
copy 0 168 113
assign 1 169 114
copy 0 169 114
assign 1 170 115
new 0 170 115
return 1 175 119
assign 1 179 126
new 0 179 126
assign 1 179 127
equals 1 179 132
assign 1 180 133
new 0 180 133
return 1 180 134
assign 1 182 136
new 0 182 136
return 1 182 137
assign 1 192 147
toString 0 192 147
return 1 192 148
assign 1 196 152
new 1 196 152
new 1 196 153
assign 1 200 158
iteratorGet 0 200 158
return 1 200 159
assign 1 204 164
new 0 204 164
assign 1 204 165
get 1 204 165
return 1 204 166
assign 1 208 172
new 0 208 172
assign 1 208 173
subtract 1 208 173
assign 1 208 174
get 1 208 174
return 1 208 175
assign 1 212 185
new 0 212 185
assign 1 212 186
lesser 1 212 191
assign 1 213 192
new 0 213 192
assign 1 213 193
new 1 213 193
throw 1 213 194
assign 1 215 196
greaterEquals 1 215 201
assign 1 216 202
new 0 216 202
assign 1 216 203
add 1 216 203
lengthSet 1 216 204
assign 1 227 216
new 0 227 216
assign 1 227 217
greaterEquals 1 227 222
assign 1 227 223
lesser 1 227 228
assign 1 0 229
assign 1 0 232
assign 1 0 236
return 1 234 242
assign 1 238 257
lesser 1 238 262
assign 1 239 263
new 0 239 263
assign 1 239 264
subtract 1 239 264
assign 1 240 265
assign 1 240 268
lesser 1 240 273
assign 1 241 274
new 0 241 274
assign 1 241 275
add 1 241 275
assign 1 241 276
get 1 241 276
put 2 241 277
assign 1 240 278
increment 0 240 278
put 2 243 284
assign 1 244 285
new 0 244 285
assign 1 244 286
subtract 1 244 286
lengthSet 1 244 287
assign 1 245 288
new 0 245 288
return 1 245 289
assign 1 247 291
new 0 247 291
return 1 247 292
assign 1 251 296
new 1 251 296
return 1 251 297
assign 1 255 301
new 1 255 301
return 1 255 302
assign 1 259 307
new 0 259 307
assign 1 259 310
lesser 1 259 315
put 2 260 316
assign 1 259 317
increment 0 259 317
assign 1 265 330
create 0 265 330
assign 1 266 331
new 0 266 331
assign 1 266 334
lesser 1 266 339
assign 1 267 340
get 1 267 340
put 2 267 341
assign 1 266 342
increment 0 266 342
return 1 269 348
assign 1 272 352
new 1 272 352
return 1 272 353
assign 1 274 357
new 1 274 357
return 1 274 358
assign 1 277 370
new 0 277 370
assign 1 277 371
lengthGet 0 277 371
assign 1 277 372
add 1 277 372
assign 1 277 373
new 2 277 373
assign 1 278 374
arrayIteratorGet 0 0 374
assign 1 278 377
hasNextGet 0 278 377
assign 1 278 379
nextGet 0 278 379
addValueWhole 1 279 380
assign 1 281 386
arrayIteratorGet 0 0 386
assign 1 281 389
hasNextGet 0 281 389
assign 1 281 391
nextGet 0 281 391
addValueWhole 1 282 392
return 1 284 398
assign 1 288 402
mergeSort 0 288 402
return 1 288 403
assign 1 292 407
new 0 292 407
sortValue 2 292 408
assign 1 296 422
assign 1 296 425
lesser 1 296 430
assign 1 297 431
assign 1 298 432
assign 1 298 435
lesser 1 298 440
assign 1 299 441
get 1 299 441
assign 1 299 442
get 1 299 442
assign 1 299 443
lesser 1 299 443
assign 1 300 445
assign 1 298 447
increment 0 298 447
assign 1 303 453
get 1 303 453
assign 1 304 454
get 1 304 454
put 2 304 455
put 2 305 456
assign 1 296 457
increment 0 296 457
assign 1 310 480
new 0 310 480
assign 1 311 481
new 0 311 481
assign 1 312 482
new 0 312 482
assign 1 313 483
lengthGet 0 313 483
assign 1 314 484
lengthGet 0 314 484
assign 1 315 487
lesser 1 315 492
assign 1 316 493
lesser 1 316 498
assign 1 316 499
lesser 1 316 504
assign 1 0 505
assign 1 0 508
assign 1 0 512
assign 1 317 515
get 1 317 515
assign 1 318 516
get 1 318 516
assign 1 319 517
lesser 1 319 517
assign 1 320 519
increment 0 320 519
put 2 321 520
assign 1 323 523
increment 0 323 523
put 2 324 524
assign 1 326 528
lesser 1 326 533
assign 1 327 534
get 1 327 534
assign 1 328 535
increment 0 328 535
put 2 329 536
assign 1 330 539
lesser 1 330 544
assign 1 331 545
get 1 331 545
assign 1 332 546
increment 0 332 546
put 2 333 547
assign 1 335 551
increment 0 335 551
assign 1 340 562
new 0 340 562
assign 1 340 563
mergeSort 2 340 563
return 1 340 564
assign 1 344 584
subtract 1 344 584
assign 1 345 585
new 0 345 585
assign 1 345 586
equals 1 345 591
assign 1 346 592
new 0 346 592
assign 1 346 593
create 1 346 593
return 1 346 594
assign 1 347 597
new 0 347 597
assign 1 347 598
equals 1 347 603
assign 1 348 604
new 0 348 604
assign 1 348 605
create 1 348 605
assign 1 349 606
new 0 349 606
assign 1 349 607
get 1 349 607
put 2 349 608
return 1 350 609
assign 1 352 612
new 0 352 612
assign 1 352 613
divide 1 352 613
assign 1 353 614
subtract 1 353 614
assign 1 354 615
add 1 354 615
assign 1 355 616
mergeSort 2 355 616
assign 1 356 617
mergeSort 2 356 617
assign 1 357 618
create 1 357 618
mergeIn 2 358 619
return 1 359 620
assign 1 364 628
new 0 364 628
assign 1 365 630
new 0 365 630
assign 1 365 631
new 1 365 631
throw 1 365 632
assign 1 371 640
greater 1 371 645
assign 1 372 646
multiply 1 372 646
assign 1 388 649
assign 1 391 653
lesser 1 391 658
incrementValue 0 397 661
setValue 1 399 667
assign 1 403 674
def 1 403 679
assign 1 404 682
hasNextGet 0 404 682
assign 1 405 684
nextGet 0 405 684
addValueWhole 1 405 685
assign 1 411 697
def 1 411 702
assign 1 412 703
iteratorGet 0 412 703
iterateAdd 1 412 704
assign 1 417 711
lesser 1 417 716
incrementValue 0 423 719
assign 1 426 722
copy 0 426 722
put 2 426 723
assign 1 431 731
def 1 431 736
assign 1 431 737
sameType 1 431 737
assign 1 0 739
assign 1 0 742
assign 1 0 746
addAll 1 432 749
addValueWhole 1 434 752
assign 1 440 763
new 0 440 763
assign 1 440 766
lesser 1 440 771
assign 1 441 772
get 1 441 772
assign 1 442 773
def 1 442 778
assign 1 442 779
equals 1 442 779
assign 1 0 781
assign 1 0 784
assign 1 0 788
return 1 443 791
incrementValue 0 440 793
return 1 446 799
assign 1 450 806
find 1 450 806
assign 1 450 807
def 1 450 812
assign 1 451 813
new 0 451 813
return 1 451 814
assign 1 453 816
new 0 453 816
return 1 453 817
assign 1 459 822
new 0 459 822
assign 1 459 823
sortedFind 2 459 823
return 1 459 824
assign 1 466 845
assign 1 467 846
new 0 467 846
assign 1 471 849
subtract 1 471 849
assign 1 471 850
new 0 471 850
assign 1 471 851
divide 1 471 851
assign 1 471 852
add 1 471 852
assign 1 472 853
get 1 472 853
assign 1 473 854
equals 1 473 854
return 1 474 856
assign 1 475 859
greater 1 475 859
assign 1 477 861
assign 1 478 864
lesser 1 478 864
assign 1 480 866
assign 1 483 870
def 1 483 875
assign 1 483 876
equals 1 483 881
assign 1 0 882
assign 1 0 885
assign 1 0 889
assign 1 484 893
get 1 484 893
assign 1 484 894
lesser 1 484 894
assign 1 0 896
assign 1 0 899
assign 1 0 903
return 1 485 906
return 1 487 908
assign 1 489 910
assign 1 490 911
new 0 490 911
return 1 491 913
return 1 0 918
return 1 0 921
return 1 0 924
assign 1 0 927
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 188061735: return bem_mergeSort_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 1616433729: return bem_lengthGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 183400265: return bem_firstGet_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1525854240: return bem_arrayIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1484114352: return bem_varraySet_0();
case 1473032100: return bem_varrayGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1478277476: return bem_sortValue_0();
case 729571811: return bem_serializeToString_0();
case 1990707345: return bem_lastGet_0();
case 1479417926: return bem_multiplierGet_0();
case 1751843603: return bem_capacityGet_0();
case 1354714650: return bem_copy_0();
case 896593457: return bem_sort_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1274448085: return bem_find_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_5_ContainerArray) bevd_0);
case 228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 104713555: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1478277478: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_2_9_5_ContainerArray) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ContainerArray();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ContainerArray.bevs_inst = (BEC_2_9_5_ContainerArray)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ContainerArray.bevs_inst;
}
}
}
