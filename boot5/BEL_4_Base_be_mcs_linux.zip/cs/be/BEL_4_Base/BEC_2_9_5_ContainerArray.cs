namespace be.BEL_4_Base {

using System;
    /* IO:File: source/base/Array.be */
public class BEC_2_9_5_ContainerArray : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerArray() { }
static BEC_2_9_5_ContainerArray() { }

   
    public BEC_2_6_6_SystemObject[] bevi_array;
    
   
   
   public BEC_2_9_5_ContainerArray(BEC_2_6_6_SystemObject[] bevi_array) {
        this.bevi_array = bevi_array;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_array.Length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_array.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
public static new BEC_2_9_5_ContainerArray bevs_inst;
public BEC_2_6_6_SystemObject bevp_varray;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpvar_phold, bevt_2_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_new_1(BEC_2_4_3_MathInt beva_leni) {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_leni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
if (beva_capi == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bels_0));
bevt_3_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 142 */
if (bevp_length == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 144 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 147 */ {
return this;
} /* Line: 148 */
} /* Line: 147 */

      bevi_array = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_2_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_2_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 176 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_varrayGet_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_varraySet_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevp_length.bem_subtract_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bels_1));
bevt_2_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 209 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_6_tmpvar_phold = bevo_7;
bevt_5_tmpvar_phold = beva_posi.bem_add_1(bevt_6_tmpvar_phold);
this.bem_lengthSet_1(bevt_5_tmpvar_phold);
} /* Line: 212 */

      this.bevi_array[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 223 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 223 */ {

      bevl_val = this.bevi_array[beva_posi.bevi_int];
      } /* Line: 224 */
return bevl_val;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_1_tmpvar_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_i = beva_pos;
while (true)
 /* Line: 236 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_5_tmpvar_phold = bevo_10;
bevt_4_tmpvar_phold = bevl_i.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = this.bem_get_1(bevt_4_tmpvar_phold);
this.bem_put_2(bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 236 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
this.bem_put_2(bevl_fl, null);
bevt_7_tmpvar_phold = bevo_11;
bevt_6_tmpvar_phold = bevp_length.bem_subtract_1(bevt_7_tmpvar_phold);
this.bem_lengthSet_1(bevt_6_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 241 */
bevt_9_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_3_9_5_8_ContainerArrayIterator) (new BEC_3_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_5_8_ContainerArrayIterator bem_arrayIteratorGet_0() {
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_3_9_5_8_ContainerArrayIterator) (new BEC_3_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_clear_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 255 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 255 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 255 */
 else  /* Line: 255 */ {
break;
} /* Line: 255 */
} /* Line: 255 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_5_ContainerArray bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_n = (BEC_2_9_5_ContainerArray) this.bem_create_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 262 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevt_1_tmpvar_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 262 */
 else  /* Line: 262 */ {
break;
} /* Line: 262 */
} /* Line: 262 */
return (BEC_2_6_6_SystemObject) bevl_n;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(beva_len);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(bevp_length);
return (BEC_2_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_add_1(BEC_2_9_5_ContainerArray beva_xi) {
BEC_2_9_5_ContainerArray bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_1_tmpvar_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_tmpvar_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_length.bem_add_1(bevt_4_tmpvar_phold);
bevl_yi = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_loop = this.bem_arrayIteratorGet_0();
while (true)
 /* Line: 274 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 274 */ {
bevl_c = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 275 */
 else  /* Line: 274 */ {
break;
} /* Line: 274 */
} /* Line: 274 */
bevt_1_tmpvar_loop = beva_xi.bem_arrayIteratorGet_0();
while (true)
 /* Line: 277 */ {
bevt_6_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevl_c = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 278 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
return (BEC_2_9_5_ContainerArray) bevl_yi;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_sort_0() {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) this.bem_mergeSort_0();
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_sortValue_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
this.bem_sortValue_2(bevt_0_tmpvar_phold, bevp_length);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_start;
while (true)
 /* Line: 292 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevl_c = bevl_i;
bevl_j = bevl_i;
while (true)
 /* Line: 294 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_3_tmpvar_phold = this.bem_get_1(bevl_j);
bevt_4_tmpvar_phold = this.bem_get_1(bevl_c);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 295 */ {
bevl_c = bevl_j;
} /* Line: 296 */
bevl_j = bevl_j.bem_increment_0();
} /* Line: 294 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpvar_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpvar_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 292 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_mergeIn_2(BEC_2_9_5_ContainerArray beva_first, BEC_2_9_5_ContainerArray beva_second) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_si = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 311 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 311 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 312 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 312 */
 else  /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 312 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpvar_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 315 */ {
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 317 */
 else  /* Line: 318 */ {
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 320 */
} /* Line: 315 */
 else  /* Line: 312 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 322 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 325 */
 else  /* Line: 312 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 326 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 329 */
} /* Line: 312 */
} /* Line: 312 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 331 */
 else  /* Line: 311 */ {
break;
} /* Line: 311 */
} /* Line: 311 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_mergeSort_0() {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) this.bem_mergeSort_2(bevt_1_tmpvar_phold, bevp_length);
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_5_ContainerArray bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_5_ContainerArray bevl_fa = null;
BEC_2_9_5_ContainerArray bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpvar_phold = bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 341 */ {
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_2_tmpvar_phold = this.bem_create_1(bevt_3_tmpvar_phold);
return (BEC_2_9_5_ContainerArray) bevt_2_tmpvar_phold;
} /* Line: 342 */
 else  /* Line: 341 */ {
bevt_5_tmpvar_phold = bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 343 */ {
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_5_ContainerArray) this.bem_create_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_tmpvar_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
return (BEC_2_9_5_ContainerArray) bevl_ra;
} /* Line: 346 */
 else  /* Line: 347 */ {
bevt_9_tmpvar_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpvar_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_2_9_5_ContainerArray) this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_2_9_5_ContainerArray) this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_5_ContainerArray) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_5_ContainerArray) bevl_ra;
} /* Line: 355 */
} /* Line: 341 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 360 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_2));
bevt_1_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 361 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_array, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 384 */
while (true)
 /* Line: 387 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 387 */ {

         this.bevi_array[this.bevp_length.bevi_int] = null;
         bevp_length.bem_incrementValue_0();
} /* Line: 393 */
 else  /* Line: 387 */ {
break;
} /* Line: 387 */
} /* Line: 387 */
bevp_length.bem_setValue_1(beva_newlen);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 399 */ {
while (true)
 /* Line: 400 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
} /* Line: 400 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 408 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 413 */ {

       this.bevi_array[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bem_incrementValue_0();
} /* Line: 419 */
 else  /* Line: 420 */ {
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) bevp_length.bem_copy_0();
this.bem_put_2(bevt_1_tmpvar_phold, beva_val);
} /* Line: 422 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_addValue_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_2_tmpvar_phold = beva_val.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 427 */
 else  /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 427 */ {
this.bem_addAll_1(beva_val);
} /* Line: 428 */
 else  /* Line: 429 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 430 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 436 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 436 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 438 */ {
bevt_3_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 438 */
 else  /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 438 */ {
return bevl_i;
} /* Line: 439 */
bevl_i.bem_incrementValue_0();
} /* Line: 436 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
return null;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 446 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 447 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 466 */ {
bevt_3_tmpvar_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpvar_phold = bevo_15;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_divide_1(bevt_4_tmpvar_phold);
bevl_mid = bevt_2_tmpvar_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 469 */ {
return bevl_mid;
} /* Line: 470 */
 else  /* Line: 469 */ {
bevt_6_tmpvar_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 471 */ {
bevl_low = bevl_mid;
} /* Line: 473 */
 else  /* Line: 469 */ {
bevt_7_tmpvar_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 474 */ {
bevl_high = bevl_mid;
} /* Line: 476 */
} /* Line: 469 */
} /* Line: 469 */
if (bevl_lastMid == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 479 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 479 */
 else  /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 479 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 480 */ {
bevt_11_tmpvar_phold = this.bem_get_1(bevl_low);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 480 */
 else  /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 480 */ {
return bevl_low;
} /* Line: 481 */
return null;
} /* Line: 483 */
bevl_lastMid = bevl_mid;
bevt_12_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 486 */ {
return null;
} /* Line: 487 */
} /* Line: 486 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_varraySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_varray = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {133, 133, 133, 133, 133, 137, 141, 141, 0, 141, 141, 0, 0, 142, 142, 142, 144, 144, 147, 147, 148, 164, 165, 166, 171, 175, 175, 175, 176, 176, 178, 178, 188, 188, 192, 192, 196, 196, 200, 200, 200, 204, 204, 204, 204, 208, 208, 208, 209, 209, 209, 211, 211, 212, 212, 212, 223, 223, 223, 223, 223, 0, 0, 0, 230, 234, 234, 235, 235, 236, 236, 236, 237, 237, 237, 237, 236, 239, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 255, 255, 255, 256, 255, 261, 262, 262, 262, 263, 263, 262, 265, 268, 268, 270, 270, 273, 273, 273, 273, 274, 0, 274, 274, 275, 277, 0, 277, 277, 278, 280, 284, 284, 288, 288, 292, 292, 292, 293, 294, 294, 294, 295, 295, 295, 296, 294, 299, 300, 300, 301, 292, 306, 307, 308, 309, 310, 311, 311, 312, 312, 312, 312, 0, 0, 0, 313, 314, 315, 316, 317, 319, 320, 322, 322, 323, 324, 325, 326, 326, 327, 328, 329, 331, 336, 336, 336, 340, 341, 341, 341, 342, 342, 342, 343, 343, 343, 344, 344, 345, 345, 345, 346, 348, 348, 349, 350, 351, 352, 353, 354, 355, 360, 361, 361, 361, 367, 367, 368, 384, 387, 387, 393, 395, 399, 399, 400, 401, 401, 407, 407, 408, 408, 413, 413, 419, 422, 422, 427, 427, 427, 0, 0, 0, 428, 430, 436, 436, 436, 437, 438, 438, 438, 0, 0, 0, 439, 436, 442, 446, 446, 446, 447, 447, 449, 449, 455, 455, 455, 462, 463, 467, 467, 467, 467, 468, 469, 470, 471, 473, 474, 476, 479, 479, 479, 479, 0, 0, 0, 480, 480, 0, 0, 0, 481, 483, 485, 486, 487, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {52, 53, 54, 55, 56, 60, 71, 76, 77, 80, 85, 86, 89, 93, 94, 95, 97, 102, 103, 108, 109, 114, 115, 116, 120, 127, 128, 133, 134, 135, 137, 138, 148, 149, 153, 154, 159, 160, 165, 166, 167, 173, 174, 175, 176, 186, 187, 192, 193, 194, 195, 197, 202, 203, 204, 205, 217, 218, 223, 224, 229, 230, 233, 237, 243, 258, 263, 264, 265, 266, 269, 274, 275, 276, 277, 278, 279, 285, 286, 287, 288, 289, 290, 292, 293, 297, 298, 302, 303, 308, 311, 316, 317, 318, 331, 332, 335, 340, 341, 342, 343, 349, 353, 354, 358, 359, 371, 372, 373, 374, 375, 375, 378, 380, 381, 387, 387, 390, 392, 393, 399, 403, 404, 408, 409, 423, 426, 431, 432, 433, 436, 441, 442, 443, 444, 446, 448, 454, 455, 456, 457, 458, 481, 482, 483, 484, 485, 488, 493, 494, 499, 500, 505, 506, 509, 513, 516, 517, 518, 520, 521, 524, 525, 529, 534, 535, 536, 537, 540, 545, 546, 547, 548, 552, 563, 564, 565, 585, 586, 587, 592, 593, 594, 595, 598, 599, 604, 605, 606, 607, 608, 609, 610, 613, 614, 615, 616, 617, 618, 619, 620, 621, 629, 631, 632, 633, 641, 646, 647, 650, 654, 659, 662, 668, 675, 680, 683, 685, 686, 698, 703, 704, 705, 712, 717, 720, 723, 724, 732, 737, 738, 740, 743, 747, 750, 753, 764, 767, 772, 773, 774, 779, 780, 782, 785, 789, 792, 794, 800, 807, 808, 813, 814, 815, 817, 818, 823, 824, 825, 846, 847, 850, 851, 852, 853, 854, 855, 857, 860, 862, 865, 867, 871, 876, 877, 882, 883, 886, 890, 894, 895, 897, 900, 904, 907, 909, 911, 912, 914, 919, 923, 926, 929, 932};
/* BEGIN LINEINFO 
assign 1 133 52
new 0 133 52
assign 1 133 53
once 0 133 53
assign 1 133 54
new 0 133 54
assign 1 133 55
once 0 133 55
new 2 133 56
new 2 137 60
assign 1 141 71
undef 1 141 76
assign 1 0 77
assign 1 141 80
undef 1 141 85
assign 1 0 86
assign 1 0 89
assign 1 142 93
new 0 142 93
assign 1 142 94
new 1 142 94
throw 1 142 95
assign 1 144 97
def 1 144 102
assign 1 147 103
equals 1 147 108
return 1 148 109
assign 1 164 114
copy 0 164 114
assign 1 165 115
copy 0 165 115
assign 1 166 116
new 0 166 116
return 1 171 120
assign 1 175 127
new 0 175 127
assign 1 175 128
equals 1 175 133
assign 1 176 134
new 0 176 134
return 1 176 135
assign 1 178 137
new 0 178 137
return 1 178 138
assign 1 188 148
toString 0 188 148
return 1 188 149
assign 1 192 153
new 1 192 153
new 1 192 154
assign 1 196 159
iteratorGet 0 196 159
return 1 196 160
assign 1 200 165
new 0 200 165
assign 1 200 166
get 1 200 166
return 1 200 167
assign 1 204 173
new 0 204 173
assign 1 204 174
subtract 1 204 174
assign 1 204 175
get 1 204 175
return 1 204 176
assign 1 208 186
new 0 208 186
assign 1 208 187
lesser 1 208 192
assign 1 209 193
new 0 209 193
assign 1 209 194
new 1 209 194
throw 1 209 195
assign 1 211 197
greaterEquals 1 211 202
assign 1 212 203
new 0 212 203
assign 1 212 204
add 1 212 204
lengthSet 1 212 205
assign 1 223 217
new 0 223 217
assign 1 223 218
greaterEquals 1 223 223
assign 1 223 224
lesser 1 223 229
assign 1 0 230
assign 1 0 233
assign 1 0 237
return 1 230 243
assign 1 234 258
lesser 1 234 263
assign 1 235 264
new 0 235 264
assign 1 235 265
subtract 1 235 265
assign 1 236 266
assign 1 236 269
lesser 1 236 274
assign 1 237 275
new 0 237 275
assign 1 237 276
add 1 237 276
assign 1 237 277
get 1 237 277
put 2 237 278
assign 1 236 279
increment 0 236 279
put 2 239 285
assign 1 240 286
new 0 240 286
assign 1 240 287
subtract 1 240 287
lengthSet 1 240 288
assign 1 241 289
new 0 241 289
return 1 241 290
assign 1 243 292
new 0 243 292
return 1 243 293
assign 1 247 297
new 1 247 297
return 1 247 298
assign 1 251 302
new 1 251 302
return 1 251 303
assign 1 255 308
new 0 255 308
assign 1 255 311
lesser 1 255 316
put 2 256 317
assign 1 255 318
increment 0 255 318
assign 1 261 331
create 0 261 331
assign 1 262 332
new 0 262 332
assign 1 262 335
lesser 1 262 340
assign 1 263 341
get 1 263 341
put 2 263 342
assign 1 262 343
increment 0 262 343
return 1 265 349
assign 1 268 353
new 1 268 353
return 1 268 354
assign 1 270 358
new 1 270 358
return 1 270 359
assign 1 273 371
new 0 273 371
assign 1 273 372
lengthGet 0 273 372
assign 1 273 373
add 1 273 373
assign 1 273 374
new 2 273 374
assign 1 274 375
arrayIteratorGet 0 0 375
assign 1 274 378
hasNextGet 0 274 378
assign 1 274 380
nextGet 0 274 380
addValueWhole 1 275 381
assign 1 277 387
arrayIteratorGet 0 0 387
assign 1 277 390
hasNextGet 0 277 390
assign 1 277 392
nextGet 0 277 392
addValueWhole 1 278 393
return 1 280 399
assign 1 284 403
mergeSort 0 284 403
return 1 284 404
assign 1 288 408
new 0 288 408
sortValue 2 288 409
assign 1 292 423
assign 1 292 426
lesser 1 292 431
assign 1 293 432
assign 1 294 433
assign 1 294 436
lesser 1 294 441
assign 1 295 442
get 1 295 442
assign 1 295 443
get 1 295 443
assign 1 295 444
lesser 1 295 444
assign 1 296 446
assign 1 294 448
increment 0 294 448
assign 1 299 454
get 1 299 454
assign 1 300 455
get 1 300 455
put 2 300 456
put 2 301 457
assign 1 292 458
increment 0 292 458
assign 1 306 481
new 0 306 481
assign 1 307 482
new 0 307 482
assign 1 308 483
new 0 308 483
assign 1 309 484
lengthGet 0 309 484
assign 1 310 485
lengthGet 0 310 485
assign 1 311 488
lesser 1 311 493
assign 1 312 494
lesser 1 312 499
assign 1 312 500
lesser 1 312 505
assign 1 0 506
assign 1 0 509
assign 1 0 513
assign 1 313 516
get 1 313 516
assign 1 314 517
get 1 314 517
assign 1 315 518
lesser 1 315 518
assign 1 316 520
increment 0 316 520
put 2 317 521
assign 1 319 524
increment 0 319 524
put 2 320 525
assign 1 322 529
lesser 1 322 534
assign 1 323 535
get 1 323 535
assign 1 324 536
increment 0 324 536
put 2 325 537
assign 1 326 540
lesser 1 326 545
assign 1 327 546
get 1 327 546
assign 1 328 547
increment 0 328 547
put 2 329 548
assign 1 331 552
increment 0 331 552
assign 1 336 563
new 0 336 563
assign 1 336 564
mergeSort 2 336 564
return 1 336 565
assign 1 340 585
subtract 1 340 585
assign 1 341 586
new 0 341 586
assign 1 341 587
equals 1 341 592
assign 1 342 593
new 0 342 593
assign 1 342 594
create 1 342 594
return 1 342 595
assign 1 343 598
new 0 343 598
assign 1 343 599
equals 1 343 604
assign 1 344 605
new 0 344 605
assign 1 344 606
create 1 344 606
assign 1 345 607
new 0 345 607
assign 1 345 608
get 1 345 608
put 2 345 609
return 1 346 610
assign 1 348 613
new 0 348 613
assign 1 348 614
divide 1 348 614
assign 1 349 615
subtract 1 349 615
assign 1 350 616
add 1 350 616
assign 1 351 617
mergeSort 2 351 617
assign 1 352 618
mergeSort 2 352 618
assign 1 353 619
create 1 353 619
mergeIn 2 354 620
return 1 355 621
assign 1 360 629
new 0 360 629
assign 1 361 631
new 0 361 631
assign 1 361 632
new 1 361 632
throw 1 361 633
assign 1 367 641
greater 1 367 646
assign 1 368 647
multiply 1 368 647
assign 1 384 650
assign 1 387 654
lesser 1 387 659
incrementValue 0 393 662
setValue 1 395 668
assign 1 399 675
def 1 399 680
assign 1 400 683
hasNextGet 0 400 683
assign 1 401 685
nextGet 0 401 685
addValueWhole 1 401 686
assign 1 407 698
def 1 407 703
assign 1 408 704
iteratorGet 0 408 704
iterateAdd 1 408 705
assign 1 413 712
lesser 1 413 717
incrementValue 0 419 720
assign 1 422 723
copy 0 422 723
put 2 422 724
assign 1 427 732
def 1 427 737
assign 1 427 738
sameType 1 427 738
assign 1 0 740
assign 1 0 743
assign 1 0 747
addAll 1 428 750
addValueWhole 1 430 753
assign 1 436 764
new 0 436 764
assign 1 436 767
lesser 1 436 772
assign 1 437 773
get 1 437 773
assign 1 438 774
def 1 438 779
assign 1 438 780
equals 1 438 780
assign 1 0 782
assign 1 0 785
assign 1 0 789
return 1 439 792
incrementValue 0 436 794
return 1 442 800
assign 1 446 807
find 1 446 807
assign 1 446 808
def 1 446 813
assign 1 447 814
new 0 447 814
return 1 447 815
assign 1 449 817
new 0 449 817
return 1 449 818
assign 1 455 823
new 0 455 823
assign 1 455 824
sortedFind 2 455 824
return 1 455 825
assign 1 462 846
assign 1 463 847
new 0 463 847
assign 1 467 850
subtract 1 467 850
assign 1 467 851
new 0 467 851
assign 1 467 852
divide 1 467 852
assign 1 467 853
add 1 467 853
assign 1 468 854
get 1 468 854
assign 1 469 855
equals 1 469 855
return 1 470 857
assign 1 471 860
greater 1 471 860
assign 1 473 862
assign 1 474 865
lesser 1 474 865
assign 1 476 867
assign 1 479 871
def 1 479 876
assign 1 479 877
equals 1 479 882
assign 1 0 883
assign 1 0 886
assign 1 0 890
assign 1 480 894
get 1 480 894
assign 1 480 895
lesser 1 480 895
assign 1 0 897
assign 1 0 900
assign 1 0 904
return 1 481 907
return 1 483 909
assign 1 485 911
assign 1 486 912
new 0 486 912
return 1 487 914
assign 1 0 919
return 1 0 923
return 1 0 926
return 1 0 929
assign 1 0 932
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 188061735: return bem_mergeSort_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 1616433729: return bem_lengthGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 183400265: return bem_firstGet_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1525854240: return bem_arrayIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1484114352: return bem_varraySet_0();
case 1473032100: return bem_varrayGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1478277476: return bem_sortValue_0();
case 729571811: return bem_serializeToString_0();
case 1990707345: return bem_lastGet_0();
case 1479417926: return bem_multiplierGet_0();
case 1751843603: return bem_capacityGet_0();
case 1354714650: return bem_copy_0();
case 896593457: return bem_sort_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1484114353: return bem_varraySet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1274448085: return bem_find_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_5_ContainerArray) bevd_0);
case 228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 104713555: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1478277478: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_2_9_5_ContainerArray) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ContainerArray();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ContainerArray.bevs_inst = (BEC_2_9_5_ContainerArray)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ContainerArray.bevs_inst;
}
}
}
