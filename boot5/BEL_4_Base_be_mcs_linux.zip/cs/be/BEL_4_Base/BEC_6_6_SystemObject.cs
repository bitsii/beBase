namespace be.BEL_4_Base {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_6_6_SystemObject : be.BELS_Base.BECS_Object {
public BEC_6_6_SystemObject() { }
static BEC_6_6_SystemObject() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x69,0x6E,0x20,0x61,0x20,0x63,0x6F,0x6E,0x74,0x65,0x78,0x74,0x20,0x77,0x68,0x65,0x72,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x20,0x77,0x65,0x72,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x76,0x61,0x69,0x6C,0x61,0x62,0x6C,0x65,0x20,0x66,0x72,0x6F,0x6D,0x20,0x74,0x68,0x65,0x20,0x73,0x74,0x61,0x63,0x6B};
private static byte[] bels_1 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64};
private static byte[] bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 8));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 23));
private static byte[] bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_5, 16));
private static byte[] bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x41,0x72,0x72,0x61,0x79,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x5F};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_8, 1));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(7));
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(7));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(7));
private static byte[] bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_11 = {0x5F};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_11, 1));
public static BEC_6_6_SystemObject bevs_inst;
public virtual BEC_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_undefined_1(BEC_6_6_SystemObject beva_ref) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_defined_1(BEC_6_6_SystemObject beva_ref) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_undef_1(BEC_6_6_SystemObject beva_ref) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_def_1(BEC_6_6_SystemObject beva_ref) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodNotDefined_0() {
BEC_6_11_SystemForwardCall bevl_forwardCall = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_forwardCall = (BEC_6_11_SystemForwardCall) (new BEC_6_11_SystemForwardCall()).bem_new_0();
bevt_0_tmpvar_phold = bevl_forwardCall.bem_notReadyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(86, bels_0));
bevt_1_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 80 */
bevt_3_tmpvar_phold = this.bem_methodNotDefined_1(bevl_forwardCall);
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodNotDefined_1(BEC_6_11_SystemForwardCall beva_forwardCall) {
BEC_6_6_SystemObject bevl_s = null;
BEC_6_6_SystemObject bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_16_SystemMethodNotDefined bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_1));
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = this.bem_can_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 86 */ {
bevl_s = this;
bevl_result = bevl_s.bemd_1(2097807671, BEL_4_Base.bevn_forward_1, beva_forwardCall);
return bevl_result;
} /* Line: 90 */
 else  /* Line: 86 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_8_tmpvar_phold = bevo_0;
bevt_9_tmpvar_phold = beva_forwardCall.bem_nameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_1;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = this.bem_classNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_6_16_SystemMethodNotDefined) (new BEC_6_16_SystemMethodNotDefined()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 92 */
} /* Line: 86 */
return bevl_result;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_createInstance_1(BEC_4_6_TextString beva_cname) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_phold = this.bem_createInstance_2(beva_cname, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_createInstance_2(BEC_4_6_TextString beva_cname, BEC_5_4_LogicBool beva_throwOnFail) {
BEC_6_6_SystemObject bevl_result = null;
BEC_4_3_MathInt bevl_chash = null;
BEC_4_6_TextString bevl_mname = null;
BEC_4_3_MathInt bevl_mhash = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_11_SystemInitializer bevt_9_tmpvar_phold = null;
if (beva_cname == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_4));
bevt_1_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 118 */
bevl_result = null;

        string key = System.Text.Encoding.UTF8.GetString(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int);
        Type ti = be.BELS_Base.BECS_Runtime.typeInstances[key];
        if (ti != null) {
            bevl_result = (BEC_6_6_SystemObject) Activator.CreateInstance(ti);
        }
        if (bevl_result == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 196 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 197 */ {
bevt_7_tmpvar_phold = bevo_2;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(beva_cname);
bevt_5_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 198 */
 else  /* Line: 199 */ {
return null;
} /* Line: 200 */
} /* Line: 197 */
bevt_9_tmpvar_phold = (BEC_6_11_SystemInitializer) (new BEC_6_11_SystemInitializer()).bem_new_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_initializeIfShould_1(bevl_result);
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_invoke_2(BEC_4_6_TextString beva_name, BEC_9_5_ContainerArray beva_args) {
BEC_4_6_TextString bevl_cname = null;
BEC_4_3_MathInt bevl_chash = null;
BEC_6_6_SystemObject bevl_rval = null;
BEC_4_3_MathInt bevl_numargs = null;
BEC_9_5_ContainerArray bevl_args2 = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(23, bels_6));
bevt_1_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 239 */
if (beva_args == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 241 */ {
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(33, bels_7));
bevt_4_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 242 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpvar_phold = bevo_3;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();
 /* Line: 251 */ {
bevt_10_tmpvar_phold = bevo_4;
bevt_9_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_12_tmpvar_phold = bevo_5;
bevt_11_tmpvar_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpvar_phold);
bevl_args2 = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevt_11_tmpvar_phold);
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(7));
while (true)
 /* Line: 254 */ {
bevt_13_tmpvar_phold = bevl_i.bem_lesser_1(bevl_numargs);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_15_tmpvar_phold = bevo_6;
bevt_14_tmpvar_phold = bevl_i.bem_subtract_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpvar_phold, bevt_16_tmpvar_phold);
bevl_i.bem_incrementValue_0();
} /* Line: 254 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 252 */

        int ci = be.BELS_Base.BECS_Ids.callIds[System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int)];
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(bevl_chash.bevi_int, ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(bevl_chash.bevi_int, ci, beva_args.bevi_array[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5], beva_args.bevi_array[6]);
        } else {
            bevl_rval = bemd_x(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5], beva_args.bevi_array[6], bevl_args2.bevi_array);
        }
        bevt_17_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 382 */
return bevl_rval;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_can_2(BEC_4_6_TextString beva_name, BEC_4_3_MathInt beva_numargs) {
BEC_4_6_TextString bevl_cname = null;
BEC_4_3_MathInt bevl_chash = null;
BEC_6_6_SystemObject bevl_rval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_9));
bevt_1_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 410 */
if (beva_numargs == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 412 */ {
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_10));
bevt_4_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 413 */
bevt_7_tmpvar_phold = bevo_7;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      string name = "bem_" + System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int);
      System.Reflection.MethodInfo[] methods = this.GetType().GetMethods();
      for (int i = 0;i < methods.Length;i++) {
        if (methods[i].Name.Equals(name)) {
            return be.BELS_Base.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 469 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 470 */
if (bevl_rval == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 472 */ {
bevt_11_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /* Line: 473 */
bevt_12_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_classNameGet_0() {
BEC_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clname();
      bevl_xi = new BEC_4_6_TextString(bevls_clname.Length, bevls_clname);
      return bevl_xi;
} /*method end*/
public virtual BEC_4_6_TextString bem_sourceFileNameGet_0() {
BEC_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clfile();
      bevl_xi = new BEC_4_6_TextString(bevls_clname.Length, bevls_clname);
      return bevl_xi;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_x) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_sameObject_1(BEC_6_6_SystemObject beva_x) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_tagGet_0() {
BEC_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_4_3_MathInt bem_hashGet_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_tagGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_x) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_toString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_print_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_echo_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_echo_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_copy_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_create_0();
bevt_0_tmpvar_phold = this.bem_copyTo_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_copyTo_1(BEC_6_6_SystemObject beva_copy) {
BEC_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
if (beva_copy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 660 */ {
return beva_copy;
} /* Line: 661 */
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpvar_phold);
while (true)
 /* Line: 665 */ {
bevt_3_tmpvar_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_4_tmpvar_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpvar_phold);
} /* Line: 666 */
 else  /* Line: 665 */ {
break;
} /* Line: 665 */
} /* Line: 665 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deserializeFromString_1(BEC_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_serializeToString_0() {
return null;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_iteratorGet_0() {
BEC_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_serializeContents_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_create_0() {
BEC_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return bevl_copy;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_sameClass_1(BEC_6_6_SystemObject beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && this.GetType() == beva_other.GetType()) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_otherClass_1(BEC_6_6_SystemObject beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameClass_1(beva_other);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_sameType_1(BEC_6_6_SystemObject beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && beva_other.GetType().IsAssignableFrom(this.GetType())) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_otherType_1(BEC_6_6_SystemObject beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameType_1(beva_other);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_once_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_many_0() {
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {39, 39, 50, 50, 61, 61, 72, 72, 77, 79, 80, 80, 80, 82, 82, 86, 86, 86, 88, 89, 90, 91, 92, 92, 92, 92, 92, 92, 92, 92, 92, 94, 98, 98, 98, 117, 117, 118, 118, 118, 120, 196, 196, 198, 198, 198, 198, 200, 203, 203, 203, 238, 238, 239, 239, 239, 241, 241, 242, 242, 242, 244, 245, 245, 245, 245, 246, 252, 252, 253, 253, 253, 254, 254, 255, 255, 255, 255, 254, 380, 382, 384, 409, 409, 410, 410, 410, 412, 412, 413, 413, 413, 415, 415, 415, 415, 416, 469, 470, 472, 472, 473, 473, 475, 475, 509, 531, 563, 563, 595, 595, 606, 632, 636, 636, 640, 640, 640, 644, 644, 648, 648, 652, 652, 656, 656, 656, 660, 660, 661, 663, 663, 664, 664, 665, 666, 666, 672, 672, 678, 684, 684, 688, 688, 692, 692, 715, 762, 762, 766, 766, 766, 821, 821, 825, 825, 825};
public static int[] bevs_smnlec
 = new int[] {36, 37, 41, 42, 46, 47, 51, 52, 60, 61, 63, 64, 65, 67, 68, 85, 86, 87, 89, 90, 91, 94, 96, 97, 98, 99, 100, 101, 102, 103, 104, 107, 112, 113, 114, 131, 136, 137, 138, 139, 141, 148, 153, 155, 156, 157, 158, 161, 164, 165, 166, 193, 198, 199, 200, 201, 203, 208, 209, 210, 211, 213, 214, 215, 216, 217, 218, 220, 221, 223, 224, 225, 226, 229, 231, 232, 233, 234, 235, 265, 267, 269, 288, 293, 294, 295, 296, 298, 303, 304, 305, 306, 308, 309, 310, 311, 312, 321, 323, 325, 330, 331, 332, 334, 335, 342, 349, 357, 358, 366, 367, 371, 374, 378, 379, 384, 385, 386, 390, 391, 395, 396, 401, 402, 408, 409, 410, 420, 425, 426, 428, 429, 430, 431, 434, 436, 437, 447, 448, 454, 461, 462, 466, 467, 471, 472, 478, 486, 487, 492, 493, 494, 502, 503, 508, 509, 510};
/* BEGIN LINEINFO 
assign 1 39 36
new 0 39 36
return 1 39 37
assign 1 50 41
new 0 50 41
return 1 50 42
assign 1 61 46
new 0 61 46
return 1 61 47
assign 1 72 51
new 0 72 51
return 1 72 52
assign 1 77 60
new 0 77 60
assign 1 79 61
notReadyGet 0 79 61
assign 1 80 63
new 0 80 63
assign 1 80 64
new 1 80 64
throw 1 80 65
assign 1 82 67
methodNotDefined 1 82 67
return 1 82 68
assign 1 86 85
new 0 86 85
assign 1 86 86
new 0 86 86
assign 1 86 87
can 2 86 87
assign 1 88 89
assign 1 89 90
forward 1 89 90
return 1 90 91
assign 1 91 94
new 0 91 94
assign 1 92 96
new 0 92 96
assign 1 92 97
nameGet 0 92 97
assign 1 92 98
add 1 92 98
assign 1 92 99
new 0 92 99
assign 1 92 100
add 1 92 100
assign 1 92 101
classNameGet 0 92 101
assign 1 92 102
add 1 92 102
assign 1 92 103
new 1 92 103
throw 1 92 104
return 1 94 107
assign 1 98 112
new 0 98 112
assign 1 98 113
createInstance 2 98 113
return 1 98 114
assign 1 117 131
undef 1 117 136
assign 1 118 137
new 0 118 137
assign 1 118 138
new 1 118 138
throw 1 118 139
assign 1 120 141
assign 1 196 148
undef 1 196 153
assign 1 198 155
new 0 198 155
assign 1 198 156
add 1 198 156
assign 1 198 157
new 1 198 157
throw 1 198 158
return 1 200 161
assign 1 203 164
new 0 203 164
assign 1 203 165
initializeIfShould 1 203 165
return 1 203 166
assign 1 238 193
undef 1 238 198
assign 1 239 199
new 0 239 199
assign 1 239 200
new 1 239 200
throw 1 239 201
assign 1 241 203
undef 1 241 208
assign 1 242 209
new 0 242 209
assign 1 242 210
new 1 242 210
throw 1 242 211
assign 1 244 213
lengthGet 0 244 213
assign 1 245 214
new 0 245 214
assign 1 245 215
add 1 245 215
assign 1 245 216
toString 0 245 216
assign 1 245 217
add 1 245 217
assign 1 246 218
hashGet 0 246 218
assign 1 252 220
new 0 252 220
assign 1 252 221
greater 1 252 221
assign 1 253 223
new 0 253 223
assign 1 253 224
subtract 1 253 224
assign 1 253 225
new 1 253 225
assign 1 254 226
new 0 254 226
assign 1 254 229
lesser 1 254 229
assign 1 255 231
new 0 255 231
assign 1 255 232
subtract 1 255 232
assign 1 255 233
get 1 255 233
put 2 255 234
incrementValue 0 254 235
assign 1 380 265
new 0 380 265
toString 0 382 267
return 1 384 269
assign 1 409 288
undef 1 409 293
assign 1 410 294
new 0 410 294
assign 1 410 295
new 1 410 295
throw 1 410 296
assign 1 412 298
undef 1 412 303
assign 1 413 304
new 0 413 304
assign 1 413 305
new 1 413 305
throw 1 413 306
assign 1 415 308
new 0 415 308
assign 1 415 309
add 1 415 309
assign 1 415 310
toString 0 415 310
assign 1 415 311
add 1 415 311
assign 1 416 312
hashGet 0 416 312
assign 1 469 321
new 0 469 321
toString 0 470 323
assign 1 472 325
def 1 472 330
assign 1 473 331
new 0 473 331
return 1 473 332
assign 1 475 334
new 0 475 334
return 1 475 335
return 1 509 342
return 1 531 349
assign 1 563 357
new 0 563 357
return 1 563 358
assign 1 595 366
new 0 595 366
return 1 595 367
assign 1 606 371
new 0 606 371
return 1 632 374
assign 1 636 378
tagGet 0 636 378
return 1 636 379
assign 1 640 384
equals 1 640 384
assign 1 640 385
not 0 640 385
return 1 640 386
assign 1 644 390
classNameGet 0 644 390
return 1 644 391
assign 1 648 395
toString 0 648 395
print 0 648 396
assign 1 652 401
toString 0 652 401
echo 0 652 402
assign 1 656 408
create 0 656 408
assign 1 656 409
copyTo 1 656 409
return 1 656 410
assign 1 660 420
undef 1 660 425
return 1 661 426
assign 1 663 428
new 0 663 428
assign 1 663 429
new 2 663 429
assign 1 664 430
new 0 664 430
assign 1 664 431
new 2 664 431
assign 1 665 434
hasNextGet 0 665 434
assign 1 666 436
nextGet 0 666 436
nextSet 1 666 437
assign 1 672 447
classNameGet 0 672 447
return 1 672 448
return 1 678 454
assign 1 684 461
new 1 684 461
return 1 684 462
assign 1 688 466
new 1 688 466
return 1 688 467
assign 1 692 471
new 0 692 471
return 1 692 472
return 1 715 478
assign 1 762 486
new 0 762 486
return 1 762 487
assign 1 766 492
sameClass 1 766 492
assign 1 766 493
not 0 766 493
return 1 766 494
assign 1 821 502
new 0 821 502
return 1 821 503
assign 1 825 508
sameType 1 825 508
assign 1 825 509
not 0 825 509
return 1 825 510
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_6_6_SystemObject();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_6_6_SystemObject.bevs_inst = becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_6_6_SystemObject.bevs_inst;
}
}
}
