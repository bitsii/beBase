namespace be.BEL_4_Base {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_6_JsonParser : BEC_2_6_6_SystemObject {
public BEC_2_4_6_JsonParser() { }
static BEC_2_4_6_JsonParser() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x7B};
private static byte[] bels_1 = {0x7D};
private static byte[] bels_2 = {0x5B};
private static byte[] bels_3 = {0x5D};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x2C};
private static byte[] bels_6 = {0x62,0x66,0x6E,0x72,0x74,0x2F};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 6));
private static byte[] bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bels_8 = {0x44,0x43,0x30,0x30};
private static byte[] bels_9 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55296));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(56319));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(56320));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57343));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
private static byte[] bels_10 = {0x74,0x6F,0x6B,0x20,0x74,0x6F,0x6F,0x20,0x73,0x6D,0x61,0x6C,0x6C};
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_11 = {0x38,0x30};
private static byte[] bels_12 = {0x38,0x30,0x30};
private static byte[] bels_13 = {0x43,0x30};
private static byte[] bels_14 = {0x37,0x43,0x30};
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_15 = {0x38,0x30};
private static byte[] bels_16 = {0x30,0x33,0x46};
private static byte[] bels_17 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bels_18 = {0x45,0x30};
private static byte[] bels_19 = {0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_20 = {0x38,0x30};
private static byte[] bels_21 = {0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_22 = {0x38,0x30};
private static byte[] bels_23 = {0x30,0x30,0x33,0x46};
private static byte[] bels_24 = {0x31,0x30,0x46,0x46,0x46,0x46};
private static byte[] bels_25 = {0x46,0x30};
private static byte[] bels_26 = {0x31,0x43,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_27 = {0x38,0x30};
private static byte[] bels_28 = {0x30,0x33,0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_29 = {0x38,0x30};
private static byte[] bels_30 = {0x30,0x30,0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_31 = {0x38,0x30};
private static byte[] bels_32 = {0x30,0x30,0x30,0x30,0x33,0x46};
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_33 = {0x66,0x61,0x69,0x6C,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x74,0x6F,0x20,0x62,0x75,0x66,0x66,0x65,0x72,0x20,0x63,0x6F,0x6E,0x76,0x65,0x72,0x74};
private static byte[] bels_34 = {0x75};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_34, 1));
private static byte[] bels_35 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x69,0x73,0x20,0x69,0x6E,0x76,0x61,0x6C,0x69,0x64};
private static byte[] bels_36 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x65,0x64,0x20,0x62,0x79,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64};
private static byte[] bels_37 = {0x74};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_37, 1));
private static byte[] bels_38 = {0x72};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_38, 1));
private static byte[] bels_39 = {0x66};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_39, 1));
private static byte[] bels_40 = {0x6E};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_40, 1));
private static byte[] bels_41 = {0x75,0x65};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_41, 2));
private static byte[] bels_42 = {0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_42, 4));
private static byte[] bels_43 = {0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_43, 3));
public static new BEC_2_4_6_JsonParser bevs_inst;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_lbrace;
public BEC_2_4_6_TextString bevp_rbrace;
public BEC_2_4_6_TextString bevp_lbracket;
public BEC_2_4_6_TextString bevp_rbracket;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_6_TextString bevp_escape;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_comma;
public BEC_2_4_6_TextString bevp_tokens;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_4_3_MathInt bevp_hsub;
public BEC_2_4_3_MathInt bevp_vsub;
public BEC_2_4_3_MathInt bevp_hmAdd;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_quote = bevt_0_tmpvar_phold.bem_quoteGet_0();
bevp_lbrace = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevp_rbrace = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevp_lbracket = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_2));
bevp_rbracket = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_space = bevt_1_tmpvar_phold.bem_spaceGet_0();
bevt_2_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_colon = bevt_2_tmpvar_phold.bem_colonGet_0();
bevp_escape = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_3_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_cr = bevt_3_tmpvar_phold.bem_crGet_0();
bevt_4_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_lf = bevt_4_tmpvar_phold.bem_lfGet_0();
bevp_comma = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_5));
bevt_14_tmpvar_phold = bevp_quote.bem_add_1(bevp_lbrace);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevp_rbrace);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevp_lbracket);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevp_rbracket);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_space);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevp_colon);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevp_escape);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevp_cr);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_lf);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_comma);
bevt_15_tmpvar_phold = bevo_0;
bevp_tokens = bevt_5_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_toker = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevp_tokens, bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
bevp_hsub = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_8));
bevp_vsub = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_9));
bevp_hmAdd = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_19_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parse_2(BEC_2_4_6_TextString beva_str, BEC_2_6_6_SystemObject beva_handler) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_toker.bem_tokenize_1(beva_str);
this.bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_phold, beva_handler);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_jsonUcIsPairStart_1(BEC_2_4_3_MathInt beva_value) {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_1;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lesserEquals_1(beva_value);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_3_tmpvar_phold = beva_value.bem_lesserEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 65 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 65 */
 else  /* Line: 65 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 65 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 68 */
return bevl_result;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_jsonUcIsPairEnd_1(BEC_2_4_3_MathInt beva_value) {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_3;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lesserEquals_1(beva_value);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevt_4_tmpvar_phold = bevo_4;
bevt_3_tmpvar_phold = beva_value.bem_lesserEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 76 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 76 */
 else  /* Line: 76 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 76 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 77 */
 else  /* Line: 78 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 79 */
return bevl_result;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_jsonUcGetAfterPart_1(BEC_2_4_6_TextString beva_tok) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevo_5;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {
return null;
} /* Line: 87 */
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_3_tmpvar_phold = beva_tok.bem_substring_1(bevt_4_tmpvar_phold);
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_jsonUcUnescape_1(BEC_2_4_6_TextString beva_tok) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_10));
bevt_3_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 94 */
bevt_7_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_6_tmpvar_phold = beva_tok.bem_substring_1(bevt_7_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_6_tmpvar_phold);
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_jsonUcAppendValue_3(BEC_2_4_3_MathInt beva_heldValue, BEC_2_4_3_MathInt beva_value, BEC_2_4_6_TextString beva_accum) {
BEC_2_4_3_MathInt bevl_sizeNow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_heldm = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_accum.bem_capacityGet_0();
bevt_3_tmpvar_phold = beva_accum.bem_sizeGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_subtract_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevo_7;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_lesser_1(bevt_4_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevt_6_tmpvar_phold = beva_accum.bem_sizeGet_0();
bevt_7_tmpvar_phold = bevo_8;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
beva_accum.bem_capacitySet_1(bevt_5_tmpvar_phold);
} /* Line: 102 */
bevl_sizeNow = beva_accum.bem_sizeGet_0();
if (beva_heldValue == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 107 */ {
bevl_heldm = beva_heldValue;
bevl_heldm.bem_subtractValue_1(bevp_hsub);
bevt_9_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_heldm.bem_shiftLeftValue_1(bevt_9_tmpvar_phold);
bevl_heldm.bem_subtractValue_1(bevp_vsub);
bevl_heldm.bem_addValue_1(beva_value);
bevl_heldm.bem_addValue_1(bevp_hmAdd);
beva_value = bevl_heldm;
} /* Line: 115 */
bevt_11_tmpvar_phold = bevo_9;
bevt_10_tmpvar_phold = beva_value.bem_lesser_1(bevt_11_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 122 */
 else  /* Line: 121 */ {
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_11));
bevt_13_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = beva_value.bem_lesser_1(bevt_13_tmpvar_phold);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 123 */ {
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, beva_value);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 125 */
 else  /* Line: 121 */ {
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_12));
bevt_16_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpvar_phold);
bevt_15_tmpvar_phold = beva_value.bem_lesser_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_13));
bevt_19_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_20_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_14));
bevt_23_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_24_tmpvar_phold);
bevt_22_tmpvar_phold = beva_value.bem_and_1(bevt_23_tmpvar_phold);
bevt_25_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_shiftRight_1(bevt_25_tmpvar_phold);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_18_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_10;
bevt_26_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_15));
bevt_29_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_30_tmpvar_phold);
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_16));
bevt_32_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_33_tmpvar_phold);
bevt_31_tmpvar_phold = beva_value.bem_and_1(bevt_32_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_26_tmpvar_phold, bevt_28_tmpvar_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 129 */
 else  /* Line: 121 */ {
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_17));
bevt_35_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_36_tmpvar_phold);
bevt_34_tmpvar_phold = beva_value.bem_lesser_1(bevt_35_tmpvar_phold);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 130 */ {
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_18));
bevt_38_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_39_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_19));
bevt_42_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_43_tmpvar_phold);
bevt_41_tmpvar_phold = beva_value.bem_and_1(bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_shiftRight_1(bevt_44_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_add_1(bevt_40_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_37_tmpvar_phold);
bevt_46_tmpvar_phold = bevo_11;
bevt_45_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_46_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_20));
bevt_48_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_49_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_21));
bevt_52_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_53_tmpvar_phold);
bevt_51_tmpvar_phold = beva_value.bem_and_1(bevt_52_tmpvar_phold);
bevt_54_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bem_shiftRight_1(bevt_54_tmpvar_phold);
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_add_1(bevt_50_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_45_tmpvar_phold, bevt_47_tmpvar_phold);
bevt_56_tmpvar_phold = bevo_12;
bevt_55_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_56_tmpvar_phold);
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_22));
bevt_58_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_59_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_23));
bevt_61_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_tmpvar_phold);
bevt_60_tmpvar_phold = beva_value.bem_and_1(bevt_61_tmpvar_phold);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_add_1(bevt_60_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_55_tmpvar_phold, bevt_57_tmpvar_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
} /* Line: 134 */
 else  /* Line: 121 */ {
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_24));
bevt_64_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_tmpvar_phold);
bevt_63_tmpvar_phold = beva_value.bem_lesserEquals_1(bevt_64_tmpvar_phold);
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_68_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_25));
bevt_67_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_tmpvar_phold);
bevt_72_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_26));
bevt_71_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_72_tmpvar_phold);
bevt_70_tmpvar_phold = beva_value.bem_and_1(bevt_71_tmpvar_phold);
bevt_73_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(18));
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_shiftRight_1(bevt_73_tmpvar_phold);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevt_69_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_66_tmpvar_phold);
bevt_75_tmpvar_phold = bevo_13;
bevt_74_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_75_tmpvar_phold);
bevt_78_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_27));
bevt_77_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_78_tmpvar_phold);
bevt_82_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_28));
bevt_81_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_82_tmpvar_phold);
bevt_80_tmpvar_phold = beva_value.bem_and_1(bevt_81_tmpvar_phold);
bevt_83_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_shiftRight_1(bevt_83_tmpvar_phold);
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevt_79_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_74_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_85_tmpvar_phold = bevo_14;
bevt_84_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_85_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_29));
bevt_87_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_88_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_30));
bevt_91_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_92_tmpvar_phold);
bevt_90_tmpvar_phold = beva_value.bem_and_1(bevt_91_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_shiftRight_1(bevt_93_tmpvar_phold);
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bem_add_1(bevt_89_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_84_tmpvar_phold, bevt_86_tmpvar_phold);
bevt_95_tmpvar_phold = bevo_15;
bevt_94_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_95_tmpvar_phold);
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_31));
bevt_97_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_98_tmpvar_phold);
bevt_101_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_32));
bevt_100_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_101_tmpvar_phold);
bevt_99_tmpvar_phold = beva_value.bem_and_1(bevt_100_tmpvar_phold);
bevt_96_tmpvar_phold = bevt_97_tmpvar_phold.bem_add_1(bevt_99_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_94_tmpvar_phold, bevt_96_tmpvar_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 140 */
 else  /* Line: 141 */ {
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 142 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
bevt_103_tmpvar_phold = bevo_16;
bevt_102_tmpvar_phold = bevl_size.bem_lesser_1(bevt_103_tmpvar_phold);
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_105_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bels_33));
bevt_104_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_105_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_104_tmpvar_phold);
} /* Line: 146 */
bevt_107_tmpvar_phold = beva_accum.bem_sizeGet_0();
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bem_add_1(bevl_size);
beva_accum.bem_sizeSet_1(bevt_106_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parseTokens_2(BEC_2_9_10_ContainerLinkedList beva_toks, BEC_2_6_6_SystemObject beva_handler) {
BEC_2_5_4_LogicBool bevl_inString = null;
BEC_2_5_4_LogicBool bevl_inEscape = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_9_3_ContainerMap bevl_fromEscapes = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_tokIter = null;
BEC_2_4_3_MathInt bevl_heldValue = null;
BEC_2_4_6_TextString bevl_tok = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_6_TextString bevl_remainder = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_4_7_JsonEscapes bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
bevl_inString = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpvar_phold = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bevs_inst;
bevl_fromEscapes = bevt_9_tmpvar_phold.bem_fromEscapesGet_0();
bevl_tokIter = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 179 */ {
bevt_10_tmpvar_phold = bevl_tokIter.bem_hasNextGet_0();
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 179 */ {
bevl_tok = (BEC_2_4_6_TextString) bevl_tokIter.bem_nextGet_0();
if (bevl_inString.bevi_bool) /* Line: 182 */ {
bevt_11_tmpvar_phold = bevl_inEscape.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 183 */ {
bevt_12_tmpvar_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 183 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 183 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 183 */
 else  /* Line: 183 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 183 */ {
bevl_inString = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_13_tmpvar_phold = bevl_accum.bem_extractString_0();
beva_handler.bemd_1(1774332469, BEL_4_Base.bevn_handleString_1, bevt_13_tmpvar_phold);
} /* Line: 185 */
 else  /* Line: 186 */ {
if (bevl_inEscape.bevi_bool) /* Line: 187 */ {
bevl_escval = (BEC_2_4_6_TextString) bevl_fromEscapes.bem_get_1(bevl_tok);
if (bevl_escval == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevl_accum.bem_addValue_1(bevl_escval);
} /* Line: 190 */
 else  /* Line: 189 */ {
bevt_16_tmpvar_phold = bevo_17;
bevt_15_tmpvar_phold = bevl_tok.bem_begins_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevl_value = this.bem_jsonUcUnescape_1(bevl_tok);
bevl_remainder = this.bem_jsonUcGetAfterPart_1(bevl_tok);
bevl_isStart = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevl_heldValue == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_19_tmpvar_phold = this.bem_jsonUcIsPairEnd_1(bevl_value);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_not_0();
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 195 */ {
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(62, bels_35));
bevt_20_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_21_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 196 */
 else  /* Line: 195 */ {
if (bevl_heldValue == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevl_isStart = this.bem_jsonUcIsPairStart_1(bevl_value);
} /* Line: 198 */
} /* Line: 195 */
if (bevl_isStart.bevi_bool) /* Line: 200 */ {
if (bevl_remainder == null) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 200 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 200 */
 else  /* Line: 200 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 200 */ {
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(73, bels_36));
bevt_24_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_24_tmpvar_phold);
} /* Line: 201 */
if (bevl_isStart.bevi_bool) /* Line: 203 */ {
bevl_heldValue = bevl_value;
} /* Line: 204 */
 else  /* Line: 205 */ {
this.bem_jsonUcAppendValue_3(bevl_heldValue, bevl_value, bevl_accum);
bevl_heldValue = null;
if (bevl_remainder == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevl_accum.bem_addValue_1(bevl_remainder);
} /* Line: 209 */
} /* Line: 208 */
} /* Line: 203 */
 else  /* Line: 212 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 213 */
} /* Line: 189 */
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 215 */
 else  /* Line: 187 */ {
bevt_27_tmpvar_phold = bevl_tok.bem_equals_1(bevp_escape);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 217 */
 else  /* Line: 218 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 219 */
} /* Line: 187 */
} /* Line: 187 */
} /* Line: 183 */
 else  /* Line: 222 */ {
bevt_28_tmpvar_phold = bevl_tok.bem_equals_1(bevp_space);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_29_tmpvar_phold = bevl_tok.bem_equals_1(bevp_cr);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 224 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_30_tmpvar_phold = bevl_tok.bem_equals_1(bevp_lf);
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 224 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_31_tmpvar_phold = bevl_tok.bem_equals_1(bevp_comma);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 224 */ {
} /* Line: 224 */
 else  /* Line: 224 */ {
bevt_32_tmpvar_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevl_inString = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 226 */
 else  /* Line: 224 */ {
bevt_33_tmpvar_phold = bevl_tok.bem_equals_1(bevp_lbrace);
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 227 */ {
beva_handler.bemd_0(1095000804, BEL_4_Base.bevn_beginMap_0);
} /* Line: 228 */
 else  /* Line: 224 */ {
bevt_34_tmpvar_phold = bevl_tok.bem_equals_1(bevp_rbrace);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 229 */ {
beva_handler.bemd_0(1708368370, BEL_4_Base.bevn_endMap_0);
} /* Line: 230 */
 else  /* Line: 224 */ {
bevt_35_tmpvar_phold = bevl_tok.bem_equals_1(bevp_colon);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 231 */ {
beva_handler.bemd_0(368775858, BEL_4_Base.bevn_kvMid_0);
} /* Line: 232 */
 else  /* Line: 224 */ {
bevt_36_tmpvar_phold = bevl_tok.bem_equals_1(bevp_lbracket);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 233 */ {
beva_handler.bemd_0(435843368, BEL_4_Base.bevn_beginList_0);
} /* Line: 234 */
 else  /* Line: 224 */ {
bevt_37_tmpvar_phold = bevl_tok.bem_equals_1(bevp_rbracket);
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 235 */ {
beva_handler.bemd_0(1398681994, BEL_4_Base.bevn_endList_0);
} /* Line: 236 */
 else  /* Line: 237 */ {
bevt_39_tmpvar_phold = bevo_18;
bevt_38_tmpvar_phold = bevl_tok.bem_equals_1(bevt_39_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_41_tmpvar_phold = bevo_19;
bevt_40_tmpvar_phold = bevl_tok.bem_equals_1(bevt_41_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 240 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_43_tmpvar_phold = bevo_20;
bevt_42_tmpvar_phold = bevl_tok.bem_equals_1(bevt_43_tmpvar_phold);
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 240 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_45_tmpvar_phold = bevo_21;
bevt_44_tmpvar_phold = bevl_tok.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 240 */ {
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_47_tmpvar_phold = bevo_22;
bevt_46_tmpvar_phold = bevl_tok.bem_equals_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 243 */ {
beva_handler.bemd_0(1262128633, BEL_4_Base.bevn_handleTrue_0);
} /* Line: 244 */
 else  /* Line: 240 */ {
bevt_49_tmpvar_phold = bevo_23;
bevt_48_tmpvar_phold = bevl_tok.bem_equals_1(bevt_49_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 245 */ {
beva_handler.bemd_0(506014516, BEL_4_Base.bevn_handleFalse_0);
} /* Line: 246 */
 else  /* Line: 240 */ {
bevt_51_tmpvar_phold = bevo_24;
bevt_50_tmpvar_phold = bevl_tok.bem_equals_1(bevt_51_tmpvar_phold);
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 247 */ {
beva_handler.bemd_0(1431394368, BEL_4_Base.bevn_handleNull_0);
} /* Line: 248 */
 else  /* Line: 249 */ {
bevt_52_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_tok);
beva_handler.bemd_1(1512002600, BEL_4_Base.bevn_handleInteger_1, bevt_52_tmpvar_phold);
} /* Line: 251 */
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 182 */
 else  /* Line: 179 */ {
break;
} /* Line: 179 */
} /* Line: 179 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lbraceGet_0() {
return bevp_lbrace;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_rbraceGet_0() {
return bevp_rbrace;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lbracketGet_0() {
return bevp_lbracket;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_rbracketGet_0() {
return bevp_rbracket;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_escapeGet_0() {
return bevp_escape;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_escapeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_commaGet_0() {
return bevp_comma;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_commaSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_tokensGet_0() {
return bevp_tokens;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_tokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_tokerGet_0() {
return bevp_toker;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hsubGet_0() {
return bevp_hsub;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vsubGet_0() {
return bevp_vsub;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_vsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hmAddGet_0() {
return bevp_hmAdd;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hmAddSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 60, 65, 0, 66, 68, 70, 76, 0, 77, 79, 81, 86, 87, 89, 93, 94, 96, 101, 102, 104, 107, 109, 110, 111, 112, 113, 114, 115, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 142, 145, 146, 148, 169, 170, 171, 173, 175, 179, 180, 183, 0, 184, 185, 188, 189, 190, 191, 192, 193, 194, 195, 0, 196, 197, 198, 200, 0, 201, 204, 206, 207, 208, 209, 213, 215, 216, 217, 219, 224, 0, 224, 0, 224, 0, 224, 0, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 240, 0, 240, 0, 240, 0, 240, 0, 243, 244, 245, 246, 247, 248, 251, 0};
public static new int[] bevs_smnlec
 = new int[] {115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115, 115};
/* BEGIN LINEINFO 
assign 1 39 115
new 0 39 115
assign 1 39 115
quoteGet 0 39 115
assign 1 40 115
new 0 40 115
assign 1 41 115
new 0 41 115
assign 1 42 115
new 0 42 115
assign 1 43 115
new 0 43 115
assign 1 44 115
new 0 44 115
assign 1 44 115
spaceGet 0 44 115
assign 1 45 115
new 0 45 115
assign 1 45 115
colonGet 0 45 115
assign 1 46 115
new 0 46 115
assign 1 47 115
new 0 47 115
assign 1 47 115
crGet 0 47 115
assign 1 48 115
new 0 48 115
assign 1 48 115
lfGet 0 48 115
assign 1 49 115
new 0 49 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
add 1 50 115
assign 1 50 115
new 0 50 115
assign 1 50 115
add 1 50 115
assign 1 51 115
new 0 51 115
assign 1 51 115
new 2 51 115
assign 1 52 115
new 0 52 115
assign 1 52 115
hexNew 1 52 115
assign 1 53 115
new 0 53 115
assign 1 53 115
hexNew 1 53 115
assign 1 54 115
new 0 54 115
assign 1 54 115
hexNew 1 54 115
assign 1 60 115
tokenize 1 60 115
parseTokens 2 60 115
assign 1 65 115
new 0 65 115
assign 1 65 115
lesserEquals 1 65 115
assign 1 65 115
new 0 65 115
assign 1 65 115
lesserEquals 1 65 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 66 115
new 0 66 115
assign 1 68 115
new 0 68 115
return 1 70 115
assign 1 76 115
new 0 76 115
assign 1 76 115
lesserEquals 1 76 115
assign 1 76 115
new 0 76 115
assign 1 76 115
lesserEquals 1 76 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 77 115
new 0 77 115
assign 1 79 115
new 0 79 115
return 1 81 115
assign 1 86 115
sizeGet 0 86 115
assign 1 86 115
new 0 86 115
assign 1 86 115
lesser 1 86 115
return 1 87 115
assign 1 89 115
new 0 89 115
assign 1 89 115
substring 1 89 115
return 1 89 115
assign 1 93 115
sizeGet 0 93 115
assign 1 93 115
new 0 93 115
assign 1 93 115
lesser 1 93 115
assign 1 94 115
new 0 94 115
assign 1 94 115
new 1 94 115
throw 1 94 115
assign 1 96 115
new 0 96 115
assign 1 96 115
substring 1 96 115
assign 1 96 115
hexNew 1 96 115
return 1 96 115
assign 1 101 115
capacityGet 0 101 115
assign 1 101 115
sizeGet 0 101 115
assign 1 101 115
subtract 1 101 115
assign 1 101 115
new 0 101 115
assign 1 101 115
lesser 1 101 115
assign 1 102 115
sizeGet 0 102 115
assign 1 102 115
new 0 102 115
assign 1 102 115
add 1 102 115
capacitySet 1 102 115
assign 1 104 115
sizeGet 0 104 115
assign 1 107 115
def 1 107 115
assign 1 109 115
subtractValue 1 110 115
assign 1 111 115
new 0 111 115
shiftLeftValue 1 111 115
subtractValue 1 112 115
addValue 1 113 115
addValue 1 114 115
assign 1 115 115
assign 1 121 115
new 0 121 115
assign 1 121 115
lesser 1 121 115
assign 1 122 115
new 0 122 115
assign 1 123 115
new 0 123 115
assign 1 123 115
hexNew 1 123 115
assign 1 123 115
lesser 1 123 115
setIntUnchecked 2 124 115
assign 1 125 115
new 0 125 115
assign 1 126 115
new 0 126 115
assign 1 126 115
hexNew 1 126 115
assign 1 126 115
lesser 1 126 115
assign 1 127 115
new 0 127 115
assign 1 127 115
hexNew 1 127 115
assign 1 127 115
new 0 127 115
assign 1 127 115
hexNew 1 127 115
assign 1 127 115
and 1 127 115
assign 1 127 115
new 0 127 115
assign 1 127 115
shiftRight 1 127 115
assign 1 127 115
add 1 127 115
setIntUnchecked 2 127 115
assign 1 128 115
new 0 128 115
assign 1 128 115
add 1 128 115
assign 1 128 115
new 0 128 115
assign 1 128 115
hexNew 1 128 115
assign 1 128 115
new 0 128 115
assign 1 128 115
hexNew 1 128 115
assign 1 128 115
and 1 128 115
assign 1 128 115
add 1 128 115
setIntUnchecked 2 128 115
assign 1 129 115
new 0 129 115
assign 1 130 115
new 0 130 115
assign 1 130 115
hexNew 1 130 115
assign 1 130 115
lesser 1 130 115
assign 1 131 115
new 0 131 115
assign 1 131 115
hexNew 1 131 115
assign 1 131 115
new 0 131 115
assign 1 131 115
hexNew 1 131 115
assign 1 131 115
and 1 131 115
assign 1 131 115
new 0 131 115
assign 1 131 115
shiftRight 1 131 115
assign 1 131 115
add 1 131 115
setIntUnchecked 2 131 115
assign 1 132 115
new 0 132 115
assign 1 132 115
add 1 132 115
assign 1 132 115
new 0 132 115
assign 1 132 115
hexNew 1 132 115
assign 1 132 115
new 0 132 115
assign 1 132 115
hexNew 1 132 115
assign 1 132 115
and 1 132 115
assign 1 132 115
new 0 132 115
assign 1 132 115
shiftRight 1 132 115
assign 1 132 115
add 1 132 115
setIntUnchecked 2 132 115
assign 1 133 115
new 0 133 115
assign 1 133 115
add 1 133 115
assign 1 133 115
new 0 133 115
assign 1 133 115
hexNew 1 133 115
assign 1 133 115
new 0 133 115
assign 1 133 115
hexNew 1 133 115
assign 1 133 115
and 1 133 115
assign 1 133 115
add 1 133 115
setIntUnchecked 2 133 115
assign 1 134 115
new 0 134 115
assign 1 135 115
new 0 135 115
assign 1 135 115
hexNew 1 135 115
assign 1 135 115
lesserEquals 1 135 115
assign 1 136 115
new 0 136 115
assign 1 136 115
hexNew 1 136 115
assign 1 136 115
new 0 136 115
assign 1 136 115
hexNew 1 136 115
assign 1 136 115
and 1 136 115
assign 1 136 115
new 0 136 115
assign 1 136 115
shiftRight 1 136 115
assign 1 136 115
add 1 136 115
setIntUnchecked 2 136 115
assign 1 137 115
new 0 137 115
assign 1 137 115
add 1 137 115
assign 1 137 115
new 0 137 115
assign 1 137 115
hexNew 1 137 115
assign 1 137 115
new 0 137 115
assign 1 137 115
hexNew 1 137 115
assign 1 137 115
and 1 137 115
assign 1 137 115
new 0 137 115
assign 1 137 115
shiftRight 1 137 115
assign 1 137 115
add 1 137 115
setIntUnchecked 2 137 115
assign 1 138 115
new 0 138 115
assign 1 138 115
add 1 138 115
assign 1 138 115
new 0 138 115
assign 1 138 115
hexNew 1 138 115
assign 1 138 115
new 0 138 115
assign 1 138 115
hexNew 1 138 115
assign 1 138 115
and 1 138 115
assign 1 138 115
new 0 138 115
assign 1 138 115
shiftRight 1 138 115
assign 1 138 115
add 1 138 115
setIntUnchecked 2 138 115
assign 1 139 115
new 0 139 115
assign 1 139 115
add 1 139 115
assign 1 139 115
new 0 139 115
assign 1 139 115
hexNew 1 139 115
assign 1 139 115
new 0 139 115
assign 1 139 115
hexNew 1 139 115
assign 1 139 115
and 1 139 115
assign 1 139 115
add 1 139 115
setIntUnchecked 2 139 115
assign 1 140 115
new 0 140 115
assign 1 142 115
new 0 142 115
assign 1 145 115
new 0 145 115
assign 1 145 115
lesser 1 145 115
assign 1 146 115
new 0 146 115
assign 1 146 115
new 1 146 115
throw 1 146 115
assign 1 148 115
sizeGet 0 148 115
assign 1 148 115
add 1 148 115
sizeSet 1 148 115
assign 1 169 115
new 0 169 115
assign 1 170 115
new 0 170 115
assign 1 171 115
new 0 171 115
assign 1 173 115
new 0 173 115
assign 1 173 115
fromEscapesGet 0 173 115
assign 1 175 115
linkedListIteratorGet 0 175 115
assign 1 179 115
hasNextGet 0 179 115
assign 1 180 115
nextGet 0 180 115
assign 1 183 115
not 0 183 115
assign 1 183 115
equals 1 183 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 184 115
new 0 184 115
assign 1 185 115
extractString 0 185 115
handleString 1 185 115
assign 1 188 115
get 1 188 115
assign 1 189 115
def 1 189 115
addValue 1 190 115
assign 1 191 115
new 0 191 115
assign 1 191 115
begins 1 191 115
assign 1 192 115
jsonUcUnescape 1 192 115
assign 1 193 115
jsonUcGetAfterPart 1 193 115
assign 1 194 115
new 0 194 115
assign 1 195 115
def 1 195 115
assign 1 195 115
jsonUcIsPairEnd 1 195 115
assign 1 195 115
not 0 195 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 196 115
new 0 196 115
assign 1 196 115
new 1 196 115
throw 1 196 115
assign 1 197 115
undef 1 197 115
assign 1 198 115
jsonUcIsPairStart 1 198 115
assign 1 200 115
def 1 200 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 201 115
new 0 201 115
assign 1 201 115
new 1 201 115
throw 1 201 115
assign 1 204 115
jsonUcAppendValue 3 206 115
assign 1 207 115
assign 1 208 115
def 1 208 115
addValue 1 209 115
addValue 1 213 115
assign 1 215 115
new 0 215 115
assign 1 216 115
equals 1 216 115
assign 1 217 115
new 0 217 115
addValue 1 219 115
assign 1 224 115
equals 1 224 115
assign 1 0 115
assign 1 224 115
equals 1 224 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 224 115
equals 1 224 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 224 115
equals 1 224 115
assign 1 0 115
assign 1 0 115
assign 1 225 115
equals 1 225 115
assign 1 226 115
new 0 226 115
assign 1 227 115
equals 1 227 115
beginMap 0 228 115
assign 1 229 115
equals 1 229 115
endMap 0 230 115
assign 1 231 115
equals 1 231 115
kvMid 0 232 115
assign 1 233 115
equals 1 233 115
beginList 0 234 115
assign 1 235 115
equals 1 235 115
endList 0 236 115
assign 1 240 115
new 0 240 115
assign 1 240 115
equals 1 240 115
assign 1 0 115
assign 1 240 115
new 0 240 115
assign 1 240 115
equals 1 240 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 240 115
new 0 240 115
assign 1 240 115
equals 1 240 115
assign 1 0 115
assign 1 0 115
assign 1 0 115
assign 1 240 115
new 0 240 115
assign 1 240 115
equals 1 240 115
assign 1 0 115
assign 1 0 115
assign 1 243 115
new 0 243 115
assign 1 243 115
equals 1 243 115
handleTrue 0 244 115
assign 1 245 115
new 0 245 115
assign 1 245 115
equals 1 245 115
handleFalse 0 246 115
assign 1 247 115
new 0 247 115
assign 1 247 115
equals 1 247 115
handleNull 0 248 115
assign 1 251 115
new 1 251 115
handleInteger 1 251 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
return 1 0 115
assign 1 0 115
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1098879089: return bem_hsubGet_0();
case 1887047473: return bem_rbracketGet_0();
case 1081412016: return bem_many_0();
case 589384576: return bem_lbraceGet_0();
case 633437795: return bem_vsubGet_0();
case 399609227: return bem_hmAddGet_0();
case 748189618: return bem_commaGet_0();
case 617801715: return bem_tokensGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 1000967768: return bem_crGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 647501781: return bem_lbracketGet_0();
case 1152565608: return bem_colonGet_0();
case 55016493: return bem_lfGet_0();
case 1259904107: return bem_quoteGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 193407370: return bem_tokerGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1513809158: return bem_rbraceGet_0();
case 1820417453: return bem_create_0();
case 482013217: return bem_spaceGet_0();
case 53269894: return bem_escapeGet_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 64352147: return bem_escapeSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1012050021: return bem_crSet_1(bevd_0);
case 410691480: return bem_hmAddSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2072727009: return bem_jsonUcGetAfterPart_1((BEC_2_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1087796836: return bem_hsubSet_1(bevd_0);
case 1180729747: return bem_jsonUcIsPairEnd_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1898129726: return bem_rbracketSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 493095470: return bem_spaceSet_1(bevd_0);
case 204489623: return bem_tokerSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1270986360: return bem_quoteSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 519708122: return bem_jsonUcIsPairStart_1((BEC_2_4_3_MathInt) bevd_0);
case 606719462: return bem_tokensSet_1(bevd_0);
case 622355542: return bem_vsubSet_1(bevd_0);
case 636419528: return bem_lbracketSet_1(bevd_0);
case 759271871: return bem_commaSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1163647861: return bem_colonSet_1(bevd_0);
case 66098746: return bem_lfSet_1(bevd_0);
case 578302323: return bem_lbraceSet_1(bevd_0);
case 1524891411: return bem_rbraceSet_1(bevd_0);
case 1855747134: return bem_jsonUcUnescape_1((BEC_2_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 792967770: return bem_parse_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1886933344: return bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 1217293707: return bem_jsonUcAppendValue_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_JsonParser();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_JsonParser.bevs_inst = (BEC_2_4_6_JsonParser)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_JsonParser.bevs_inst;
}
}
}
