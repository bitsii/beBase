namespace be.BEL_4_Base {
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_10_BuildEmitCommon : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_2_5_10_BuildEmitCommon() { }
static BEC_2_5_10_BuildEmitCommon() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_4 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_5 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_6 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_7 = {0x20,0x3D,0x3D,0x20};
private static byte[] bels_8 = {0x20,0x21,0x3D,0x20};
private static byte[] bels_9 = {0x62,0x65};
private static byte[] bels_10 = {0x63,0x73};
private static byte[] bels_11 = {0x20,0x69,0x73,0x20};
private static byte[] bels_12 = {0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x6F,0x66,0x20};
private static byte[] bels_13 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 33));
private static byte[] bels_14 = {0x42,0x45,0x4C,0x5F};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 4));
private static byte[] bels_15 = {0x5F};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 1));
private static byte[] bels_16 = {0x2E};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 1));
private static byte[] bels_17 = {0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x69,0x6E,0x67,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 17));
private static byte[] bels_18 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 2));
private static byte[] bels_19 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_19, 3));
private static byte[] bels_20 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_20, 4));
private static byte[] bels_21 = {0x20};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_21, 1));
private static byte[] bels_22 = {0x2F,0x2A,0x20,0x42,0x45,0x47,0x49,0x4E,0x20,0x4C,0x49,0x4E,0x45,0x49,0x4E,0x46,0x4F,0x20};
private static byte[] bels_23 = {0x2C,0x20};
private static byte[] bels_24 = {0x2C,0x20};
private static byte[] bels_25 = {0x20};
private static byte[] bels_26 = {0x20};
private static byte[] bels_27 = {0x20};
private static byte[] bels_28 = {0x45,0x4E,0x44,0x20,0x4C,0x49,0x4E,0x45,0x49,0x4E,0x46,0x4F,0x20,0x2A,0x2F};
private static byte[] bels_29 = {0x2E};
private static byte[] bels_30 = {0x6A,0x73};
private static byte[] bels_31 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_31, 11));
private static byte[] bels_32 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_32, 10));
private static byte[] bels_33 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_33, 11));
private static byte[] bels_34 = {0x63,0x73};
private static byte[] bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_37 = {0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x7B};
private static byte[] bels_38 = {0x7D,0x3B};
private static byte[] bels_39 = {0x6A,0x76};
private static byte[] bels_40 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x6D,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x28,0x29,0x20,0x7B};
private static byte[] bels_41 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x7B};
private static byte[] bels_42 = {0x7D,0x3B};
private static byte[] bels_43 = {0x7D};
private static byte[] bels_44 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_45 = {0x20,0x3D,0x20,0x62,0x65,0x6D,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x28,0x29,0x3B};
private static byte[] bels_46 = {0x6A,0x73};
private static byte[] bels_47 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_48 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_49 = {0x5D,0x3B};
private static byte[] bels_50 = {0x63,0x73};
private static byte[] bels_51 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_52 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_53 = {0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x7B};
private static byte[] bels_54 = {0x7D,0x3B};
private static byte[] bels_55 = {0x6A,0x76};
private static byte[] bels_56 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x6D,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x28,0x29,0x20,0x7B};
private static byte[] bels_57 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x7B};
private static byte[] bels_58 = {0x7D,0x3B};
private static byte[] bels_59 = {0x7D};
private static byte[] bels_60 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_61 = {0x20,0x3D,0x20,0x62,0x65,0x6D,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x28,0x29,0x3B};
private static byte[] bels_62 = {0x6A,0x73};
private static byte[] bels_63 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_64 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_65 = {0x5D,0x3B};
private static byte[] bels_66 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_67 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_68 = {};
private static byte[] bels_69 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_70 = {};
private static byte[] bels_71 = {};
private static byte[] bels_72 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bels_73 = {};
private static byte[] bels_74 = {0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bels_75 = {0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_76 = {0x28,0x29,0x3B};
private static byte[] bels_77 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_78 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_79 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62};
private static byte[] bels_80 = {0x20,0x20,0x7B};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_80, 3));
private static byte[] bels_81 = {0x20,0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x20,0x3D,0x20,0x66,0x61,0x6C,0x73,0x65,0x3B};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_81, 19));
private static byte[] bels_82 = {0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bels_83 = {0x6A,0x76};
private static byte[] bels_84 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x2E,0x70,0x75,0x74,0x28};
private static byte[] bels_85 = {0x2C,0x20,0x43,0x6C,0x61,0x73,0x73,0x2E,0x66,0x6F,0x72,0x4E,0x61,0x6D,0x65,0x28};
private static byte[] bels_86 = {0x29,0x29,0x3B};
private static byte[] bels_87 = {0x63,0x73};
private static byte[] bels_88 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_89 = {0x5D,0x20,0x3D,0x20,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_90 = {0x29,0x3B};
private static byte[] bels_91 = {0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_92 = {0x29};
private static byte[] bels_93 = {0x2E,0x47,0x65,0x74,0x46,0x69,0x65,0x6C,0x64,0x28};
private static byte[] bels_94 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_95 = {0x29,0x2E,0x47,0x65,0x74,0x56,0x61,0x6C,0x75,0x65,0x28,0x6E,0x75,0x6C,0x6C,0x29,0x3B};
private static byte[] bels_96 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_96, 4));
private static byte[] bels_97 = {0x28,0x29};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_97, 2));
private static byte[] bels_98 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_99 = {0x29,0x3B};
private static byte[] bels_100 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_101 = {0x29,0x3B};
private static byte[] bels_102 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x76,0x6E,0x5F};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_102, 9));
private static byte[] bels_103 = {0x3B};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_103, 1));
private static byte[] bels_104 = {0x62,0x65,0x76,0x6E,0x5F};
private static byte[] bels_105 = {0x20,0x3D,0x20,0x67,0x65,0x74,0x43,0x61,0x6C,0x6C,0x49,0x64,0x28};
private static byte[] bels_106 = {0x29,0x3B};
private static byte[] bels_107 = {0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_108 = {0x2C,0x20};
private static byte[] bels_109 = {0x29,0x3B};
private static byte[] bels_110 = {0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_111 = {0x2C,0x20};
private static byte[] bels_112 = {0x29,0x3B};
private static byte[] bels_113 = {0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_113, 11));
private static byte[] bels_114 = {0x20,0x7B};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_114, 2));
private static byte[] bels_115 = {0x6A,0x76};
private static byte[] bels_116 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_116, 14));
private static byte[] bels_117 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_117, 9));
private static byte[] bels_118 = {0x63,0x73};
private static byte[] bels_119 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_119, 13));
private static byte[] bels_120 = {0x29,0x29,0x20,0x7B};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_120, 4));
private static byte[] bels_121 = {0x69,0x66,0x20,0x28,0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x29,0x20,0x7B,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x3B,0x20,0x7D};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_121, 26));
private static byte[] bels_122 = {0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x20,0x3D,0x20,0x74,0x72,0x75,0x65,0x3B};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_122, 17));
private static byte[] bels_123 = {0x6A,0x76};
private static byte[] bels_124 = {0x63,0x73};
private static byte[] bels_125 = {0x7D};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_125, 1));
private static byte[] bels_126 = {0x7D};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_126, 1));
private static byte[] bels_127 = {0x7D};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_127, 1));
private static byte[] bels_128 = {0x28,0x6E,0x65,0x77,0x20,0x62,0x65,0x2E,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x37,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x28,0x29,0x29,0x2E,0x62,0x65,0x6D,0x5F,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_128, 62));
private static byte[] bels_129 = {};
private static byte[] bels_130 = {0x6A,0x76};
private static byte[] bels_131 = {0x63,0x73};
private static byte[] bels_132 = {0x7D,0x20,0x7D};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_132, 3));
private static byte[] bels_133 = {0x7D};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_133, 1));
private static byte[] bels_134 = {};
private static byte[] bels_135 = {0x62,0x65,0x76,0x74,0x5F};
private static byte[] bels_136 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_137 = {0x62,0x65,0x76,0x61,0x5F};
private static byte[] bels_138 = {0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bels_139 = {0x20};
private static byte[] bels_140 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_140, 4));
private static byte[] bels_141 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_141, 4));
private static byte[] bels_142 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_143 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_144 = {0x2C,0x20};
private static byte[] bels_145 = {0x4E,0x75,0x6C,0x6C,0x20,0x61,0x72,0x67,0x20,0x68,0x65,0x6C,0x64,0x20};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_145, 14));
private static byte[] bels_146 = {0x6A,0x73};
private static byte[] bels_147 = {0x3B};
private static byte[] bels_148 = {0x20,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x3B};
private static byte[] bels_149 = {0x20};
private static byte[] bels_150 = {0x28};
private static byte[] bels_151 = {0x29};
private static byte[] bels_152 = {0x20,0x7B};
private static byte[] bels_153 = {0x2F};
private static BEC_2_4_3_MathInt bevo_35 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_36 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_154 = {0x3B};
private static byte[] bels_155 = {0x62,0x65,0x6D,0x64,0x5F};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_155, 5));
private static byte[] bels_156 = {0x62,0x65,0x6D,0x64,0x5F,0x78};
private static byte[] bels_157 = {0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x2C,0x20,0x63,0x61,0x6C,0x6C,0x49,0x64};
private static byte[] bels_158 = {0x69,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x2C,0x20,0x69,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x49,0x64};
private static BEC_2_4_3_MathInt bevo_38 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_159 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_159, 2));
private static byte[] bels_160 = {0x20,0x62,0x65,0x76,0x64,0x5F};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_160, 6));
private static BEC_2_4_3_MathInt bevo_41 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_161 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_161, 2));
private static byte[] bels_162 = {0x62,0x65,0x76,0x64,0x5F};
private static BEC_2_4_6_TextString bevo_43 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_162, 5));
private static BEC_2_4_3_MathInt bevo_44 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_163 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_45 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_163, 2));
private static byte[] bels_164 = {0x5B,0x5D,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_2_4_6_TextString bevo_46 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_164, 9));
private static byte[] bels_165 = {0x2C,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_2_4_6_TextString bevo_47 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_165, 8));
private static byte[] bels_166 = {0x20};
private static byte[] bels_167 = {0x28};
private static byte[] bels_168 = {0x29};
private static byte[] bels_169 = {0x20,0x7B};
private static byte[] bels_170 = {0x73,0x77,0x69,0x74,0x63,0x68,0x20,0x28,0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x29,0x20,0x7B};
private static byte[] bels_171 = {0x63,0x61,0x73,0x65,0x20};
private static byte[] bels_172 = {0x3A,0x20};
private static BEC_2_4_3_MathInt bevo_48 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_173 = {0x2E,0x62,0x65,0x76,0x6E,0x5F};
private static BEC_2_4_6_TextString bevo_49 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_173, 6));
private static byte[] bels_174 = {0x69,0x66,0x20,0x28,0x63,0x61,0x6C,0x6C,0x49,0x64,0x20,0x3D,0x3D,0x20};
private static byte[] bels_175 = {0x29,0x20,0x7B};
private static byte[] bels_176 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x62,0x65,0x6D,0x5F};
private static byte[] bels_177 = {0x28};
private static BEC_2_4_3_MathInt bevo_50 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_178 = {0x20};
private static BEC_2_4_6_TextString bevo_51 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_178, 1));
private static byte[] bels_179 = {};
private static BEC_2_4_3_MathInt bevo_52 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_180 = {0x2C,0x20};
private static byte[] bels_181 = {};
private static byte[] bels_182 = {0x62,0x65,0x76,0x64,0x5F};
private static BEC_2_4_6_TextString bevo_53 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_182, 5));
private static BEC_2_4_3_MathInt bevo_54 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_183 = {0x62,0x65,0x76,0x64,0x5F,0x78,0x5B};
private static BEC_2_4_6_TextString bevo_55 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_183, 7));
private static byte[] bels_184 = {0x5D};
private static BEC_2_4_6_TextString bevo_56 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_184, 1));
private static byte[] bels_185 = {0x29,0x3B};
private static byte[] bels_186 = {0x7D};
private static byte[] bels_187 = {0x62,0x72,0x65,0x61,0x6B,0x3B};
private static byte[] bels_188 = {0x7D};
private static byte[] bels_189 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_57 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_189, 7));
private static byte[] bels_190 = {0x2E};
private static BEC_2_4_6_TextString bevo_58 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_190, 1));
private static byte[] bels_191 = {0x28};
private static byte[] bels_192 = {0x29,0x3B};
private static byte[] bels_193 = {0x7D};
private static byte[] bels_194 = {0x2F};
private static byte[] bels_195 = {0x2A,0x2D,0x61,0x74,0x74,0x72,0x2D,0x20,0x2D,0x66,0x69,0x72,0x73,0x74,0x53,0x6C,0x6F,0x74,0x4E,0x61,0x74,0x69,0x76,0x65,0x2D,0x2A};
private static byte[] bels_196 = {0x2A,0x2D,0x61,0x74,0x74,0x72,0x2D,0x20,0x2D,0x6E,0x61,0x74,0x69,0x76,0x65,0x53,0x6C,0x6F,0x74,0x73};
private static BEC_2_4_3_MathInt bevo_59 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_197 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bels_198 = {0x20,0x7B};
private static byte[] bels_199 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_200 = {0x28,0x29,0x3B};
private static byte[] bels_201 = {0x7D};
private static byte[] bels_202 = {0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bels_203 = {0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bels_204 = {0x20,0x7B};
private static byte[] bels_205 = {};
private static byte[] bels_206 = {0x20,0x3D,0x20};
private static byte[] bels_207 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_208 = {0x7D};
private static byte[] bels_209 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bels_210 = {0x20,0x7B};
private static byte[] bels_211 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_212 = {0x3B};
private static byte[] bels_213 = {0x7D};
private static byte[] bels_214 = {0x63,0x6C,0x6E,0x61,0x6D,0x65};
private static byte[] bels_215 = {0x63,0x6C,0x66,0x69,0x6C,0x65};
private static byte[] bels_216 = {0x62,0x65,0x63,0x63,0x5F};
private static BEC_2_4_6_TextString bevo_60 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_216, 5));
private static BEC_2_4_3_MathInt bevo_61 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_217 = {0x2C};
private static BEC_2_4_6_TextString bevo_62 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_217, 1));
private static byte[] bels_218 = {0x62,0x79,0x74,0x65,0x5B,0x5D,0x20,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bels_219 = {0x28,0x29};
private static byte[] bels_220 = {0x20,0x7B};
private static byte[] bels_221 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bels_222 = {0x3B};
private static byte[] bels_223 = {0x7D};
private static byte[] bels_224 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_225 = {0x3B};
private static byte[] bels_226 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_227 = {0x3B};
private static byte[] bels_228 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_229 = {0x2F,0x2A,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_230 = {0x20,0x2A,0x2F};
private static byte[] bels_231 = {0x20,0x7B};
private static byte[] bels_232 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bels_233 = {0x28,0x29,0x20,0x7B};
private static byte[] bels_234 = {0x20,0x7D};
private static byte[] bels_235 = {0x63,0x73};
private static byte[] bels_236 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_237 = {0x28,0x29,0x20,0x7B};
private static byte[] bels_238 = {0x20,0x7D};
private static byte[] bels_239 = {0x7D};
private static byte[] bels_240 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bevo_63 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_240, 14));
private static byte[] bels_241 = {0x20};
private static BEC_2_4_6_TextString bevo_64 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_241, 1));
private static byte[] bels_242 = {};
private static byte[] bels_243 = {};
private static byte[] bels_244 = {0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_245 = {0x20,0x2F,0x2A,0x20};
private static byte[] bels_246 = {0x20,0x2A,0x2F,0x20,0x7B};
private static byte[] bels_247 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_248 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x68,0x69,0x73,0x3B};
private static BEC_2_4_3_MathInt bevo_65 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_249 = {0x5B,0x5D,0x20,0x62,0x65,0x76,0x64,0x5F,0x78,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_250 = {0x5B};
private static byte[] bels_251 = {0x5D,0x3B};
private static byte[] bels_252 = {0x7D,0x20,0x2F,0x2A,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x65,0x6E,0x64,0x2A,0x2F};
private static byte[] bels_253 = {0x7D,0x20,0x2F,0x2A,0x20};
private static byte[] bels_254 = {0x20,0x2A,0x2F};
private static byte[] bels_255 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_256 = {};
private static byte[] bels_257 = {0x21,0x28};
private static byte[] bels_258 = {0x2E,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bels_259 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x26,0x26,0x20};
private static byte[] bels_260 = {0x20,0x26,0x26,0x20};
private static byte[] bels_261 = {0x6A,0x73};
private static byte[] bels_262 = {0x28};
private static byte[] bels_263 = {0x6A,0x73};
private static byte[] bels_264 = {0x29};
private static byte[] bels_265 = {0x2E,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bels_266 = {0x29};
private static byte[] bels_267 = {0x69,0x66,0x20,0x28};
private static byte[] bels_268 = {0x29};
private static byte[] bels_269 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_270 = {0x69,0x66,0x20,0x28};
private static byte[] bels_271 = {0x29};
private static byte[] bels_272 = {0x3B};
private static BEC_2_4_6_TextString bevo_66 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_272, 1));
private static byte[] bels_273 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x6C,0x69,0x74,0x65,0x72,0x61,0x6C,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_274 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_275 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66};
private static byte[] bels_276 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_277 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_278 = {};
private static byte[] bels_279 = {0x20};
private static BEC_2_4_6_TextString bevo_67 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_279, 1));
private static byte[] bels_280 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bevo_68 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_280, 3));
private static byte[] bels_281 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_282 = {0x28};
private static BEC_2_4_6_TextString bevo_69 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_282, 1));
private static byte[] bels_283 = {0x29};
private static BEC_2_4_6_TextString bevo_70 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_283, 1));
private static byte[] bels_284 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_285 = {0x29,0x3B};
private static byte[] bels_286 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bevo_71 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_286, 5));
private static byte[] bels_287 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bevo_72 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_288 = {0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x20};
private static BEC_2_4_6_TextString bevo_73 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_288, 51));
private static byte[] bels_289 = {0x20,0x21,0x21,0x21};
private static byte[] bels_290 = {0x21,0x21,0x20};
private static byte[] bels_291 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_292 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_293 = {0x73,0x65,0x6C,0x66,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x74,0x6F};
private static byte[] bels_294 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_295 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_296 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_297 = {0x75,0x6E,0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_298 = {0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_299 = {0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_300 = {0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_301 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_302 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x75,0x6E,0x64,0x65,0x66,0x2F,0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74};
private static byte[] bels_303 = {0x75};
private static byte[] bels_304 = {0x69,0x66,0x20,0x28};
private static byte[] bels_305 = {0x20,0x3D,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x29,0x20,0x7B};
private static byte[] bels_306 = {0x20,0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_307 = {0x7D};
private static byte[] bels_308 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_309 = {};
private static byte[] bels_310 = {0x20};
private static BEC_2_4_6_TextString bevo_74 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_310, 1));
private static byte[] bels_311 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_312 = {0x3B};
private static byte[] bels_313 = {0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_314 = {0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_315 = {0x75,0x6E,0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_316 = {0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_317 = {0x5F};
private static byte[] bels_318 = {0x42,0x61,0x64,0x20,0x6E,0x61,0x6D,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bevo_75 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_318, 18));
private static byte[] bels_319 = {0x20};
private static BEC_2_4_6_TextString bevo_76 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_319, 1));
private static byte[] bels_320 = {0x20};
private static BEC_2_4_6_TextString bevo_77 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_320, 1));
private static byte[] bels_321 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_322 = {0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_3_MathInt bevo_78 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_79 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_323 = {0x2C,0x20};
private static byte[] bels_324 = {0x20};
private static byte[] bels_325 = {0x62,0x65,0x76,0x64,0x5F,0x78,0x5B};
private static byte[] bels_326 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_327 = {0x3B};
private static byte[] bels_328 = {0x69,0x73,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x69,0x73,0x54,0x79,0x70,0x65,0x64};
private static byte[] bels_329 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_330 = {};
private static byte[] bels_331 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bevo_80 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_331, 3));
private static byte[] bels_332 = {0x3B};
private static BEC_2_4_6_TextString bevo_81 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_332, 1));
private static byte[] bels_333 = {0x20};
private static BEC_2_4_6_TextString bevo_82 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_333, 1));
private static byte[] bels_334 = {};
private static byte[] bels_335 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bevo_83 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_335, 3));
private static byte[] bels_336 = {0x6A,0x76};
private static byte[] bels_337 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bels_338 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bels_339 = {0x63,0x73};
private static byte[] bels_340 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_341 = {0x29,0x29,0x20,0x7B};
private static byte[] bels_342 = {0x69,0x66,0x20,0x28};
private static BEC_2_4_6_TextString bevo_84 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_342, 4));
private static byte[] bels_343 = {0x20,0x3D,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x29,0x20,0x7B};
private static BEC_2_4_6_TextString bevo_85 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_343, 11));
private static byte[] bels_344 = {0x62,0x65,0x6C,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_86 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_344, 5));
private static byte[] bels_345 = {0x5B};
private static BEC_2_4_6_TextString bevo_87 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_345, 1));
private static byte[] bels_346 = {0x5D};
private static BEC_2_4_6_TextString bevo_88 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_346, 1));
private static BEC_2_4_3_MathInt bevo_89 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_347 = {0x2C};
private static BEC_2_4_6_TextString bevo_90 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_347, 1));
private static byte[] bels_348 = {0x74,0x72,0x75,0x65};
private static byte[] bels_349 = {0x55,0x4E,0x48,0x41,0x4E,0x44,0x4C,0x45,0x44,0x20,0x4C,0x49,0x54,0x45,0x52,0x41,0x4C,0x20,0x54,0x59,0x50,0x45,0x20};
private static BEC_2_4_6_TextString bevo_91 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_349, 23));
private static byte[] bels_350 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_92 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_350, 4));
private static byte[] bels_351 = {0x28,0x29};
private static BEC_2_4_6_TextString bevo_93 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_351, 2));
private static byte[] bels_352 = {0x28};
private static BEC_2_4_6_TextString bevo_94 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_352, 1));
private static byte[] bels_353 = {0x29};
private static BEC_2_4_6_TextString bevo_95 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_353, 1));
private static byte[] bels_354 = {0x20};
private static byte[] bels_355 = {0x6F,0x68,0x20,0x6E,0x6F,0x65,0x73,0x20,0x6F,0x6E,0x63,0x65,0x20,0x64,0x65,0x63,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_96 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_355, 19));
private static byte[] bels_356 = {0x74,0x72,0x75,0x65};
private static byte[] bels_357 = {0x3B};
private static byte[] bels_358 = {0x3B};
private static byte[] bels_359 = {0x6E,0x65,0x77,0x5F,0x30};
private static BEC_2_4_6_TextString bevo_97 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_359, 5));
private static byte[] bels_360 = {0x6E,0x65,0x77,0x5F,0x30};
private static byte[] bels_361 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_98 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_361, 13));
private static byte[] bels_362 = {0x3B};
private static byte[] bels_363 = {0x2E};
private static byte[] bels_364 = {0x28};
private static byte[] bels_365 = {0x29,0x3B};
private static byte[] bels_366 = {0x2E};
private static byte[] bels_367 = {0x28};
private static byte[] bels_368 = {0x29,0x3B};
private static byte[] bels_369 = {0x2E};
private static byte[] bels_370 = {0x28};
private static byte[] bels_371 = {0x29,0x3B};
private static byte[] bels_372 = {};
private static byte[] bels_373 = {0x78};
private static BEC_2_4_3_MathInt bevo_99 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_374 = {0x2C,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_2_4_3_MathInt bevo_100 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_375 = {0x2C,0x20};
private static byte[] bels_376 = {};
private static byte[] bels_377 = {0x2E,0x62,0x65,0x6D,0x64,0x5F};
private static byte[] bels_378 = {0x28};
private static byte[] bels_379 = {0x2C,0x20};
private static byte[] bels_380 = {0x2E,0x62,0x65,0x76,0x6E,0x5F};
private static byte[] bels_381 = {0x29,0x3B};
private static byte[] bels_382 = {0x7D};
private static byte[] bels_383 = {0x6A,0x76};
private static byte[] bels_384 = {0x63,0x73};
private static byte[] bels_385 = {0x7D};
private static byte[] bels_386 = {0x3B};
private static byte[] bels_387 = {0x28};
private static byte[] bels_388 = {0x6A,0x73};
private static byte[] bels_389 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x49,0x74,0x5F,0x31,0x28};
private static byte[] bels_390 = {0x29};
private static byte[] bels_391 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x49,0x74,0x5F,0x31,0x28};
private static byte[] bels_392 = {0x29};
private static byte[] bels_393 = {0x29};
private static byte[] bels_394 = {0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_395 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_101 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_395, 4));
private static byte[] bels_396 = {0x28};
private static BEC_2_4_6_TextString bevo_102 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_396, 1));
private static byte[] bels_397 = {0x29};
private static BEC_2_4_6_TextString bevo_103 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_397, 1));
private static byte[] bels_398 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_104 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_398, 4));
private static byte[] bels_399 = {0x28};
private static BEC_2_4_6_TextString bevo_105 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_399, 1));
private static byte[] bels_400 = {0x66,0x29};
private static BEC_2_4_6_TextString bevo_106 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_400, 2));
private static byte[] bels_401 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_107 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_401, 4));
private static byte[] bels_402 = {0x28};
private static BEC_2_4_6_TextString bevo_108 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_402, 1));
private static byte[] bels_403 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_109 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_403, 2));
private static byte[] bels_404 = {0x29};
private static BEC_2_4_6_TextString bevo_110 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_404, 1));
private static byte[] bels_405 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_111 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_405, 4));
private static byte[] bels_406 = {0x28};
private static BEC_2_4_6_TextString bevo_112 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_406, 1));
private static byte[] bels_407 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_113 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_407, 2));
private static byte[] bels_408 = {0x29};
private static BEC_2_4_6_TextString bevo_114 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_408, 1));
private static byte[] bels_409 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x62,0x79,0x74,0x65,0x5B,0x5D,0x20};
private static byte[] bels_410 = {0x20,0x3D,0x20,0x7B};
private static byte[] bels_411 = {0x7D,0x3B};
private static byte[] bels_412 = {0x24,0x2F};
private static byte[] bels_413 = {0x2F,0x2A,0x2D,0x61,0x74,0x74,0x72,0x2D,0x20,0x2D,0x6E,0x6F,0x72,0x65,0x70,0x6C,0x61,0x63,0x65,0x2D,0x2A,0x2F};
private static BEC_2_4_6_TextString bevo_115 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_413, 22));
private static byte[] bels_414 = {0x24};
private static BEC_2_4_6_TextString bevo_116 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_414, 1));
private static BEC_2_4_3_MathInt bevo_117 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_415 = {0x24};
private static BEC_2_4_6_TextString bevo_118 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_415, 1));
private static BEC_2_4_3_MathInt bevo_119 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_416 = {0x63,0x6C,0x61,0x73,0x73};
private static BEC_2_4_6_TextString bevo_120 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_416, 5));
private static byte[] bels_417 = {0x63,0x6C,0x61,0x73,0x73};
private static BEC_2_4_6_TextString bevo_121 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_417, 5));
private static BEC_2_4_3_MathInt bevo_122 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_123 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_418 = {0x63,0x6C,0x61,0x73,0x73};
private static BEC_2_4_6_TextString bevo_124 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_418, 5));
private static BEC_2_4_3_MathInt bevo_125 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static byte[] bels_419 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bels_420 = {0x62,0x72,0x65,0x61,0x6B,0x3B};
private static byte[] bels_421 = {0x77,0x68,0x69,0x6C,0x65,0x20,0x28,0x74,0x72,0x75,0x65,0x29};
private static byte[] bels_422 = {0x20,0x65,0x6C,0x73,0x65,0x20};
private static byte[] bels_423 = {0x74,0x72,0x79,0x20};
private static byte[] bels_424 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_425 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_426 = {0x74,0x68,0x69,0x73};
private static byte[] bels_427 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_428 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_429 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_430 = {0x74,0x68,0x69,0x73};
private static byte[] bels_431 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_432 = {};
private static byte[] bels_433 = {};
private static byte[] bels_434 = {};
private static byte[] bels_435 = {};
private static byte[] bels_436 = {};
private static byte[] bels_437 = {};
private static byte[] bels_438 = {};
private static byte[] bels_439 = {};
private static BEC_2_4_6_TextString bevo_126 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_439, 0));
private static byte[] bels_440 = {0x5F};
private static BEC_2_4_6_TextString bevo_127 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_440, 1));
private static byte[] bels_441 = {0x5F};
private static BEC_2_4_6_TextString bevo_128 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_441, 1));
private static byte[] bels_442 = {0x5F};
private static byte[] bels_443 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_129 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_443, 4));
private static byte[] bels_444 = {0x2E};
private static BEC_2_4_6_TextString bevo_130 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_444, 1));
private static byte[] bels_445 = {0x62,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_131 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_445, 3));
public static new BEC_2_5_10_BuildEmitCommon bevs_inst;
public BEC_2_5_11_BuildClassConfig bevp_classConf;
public BEC_2_5_11_BuildClassConfig bevp_parentConf;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_4_6_TextString bevp_fileExt;
public BEC_2_4_6_TextString bevp_exceptDec;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_q;
public BEC_2_9_3_ContainerMap bevp_ccCache;
public BEC_2_5_8_BuildNamePath bevp_objectNp;
public BEC_2_5_8_BuildNamePath bevp_boolNp;
public BEC_2_5_8_BuildNamePath bevp_intNp;
public BEC_2_5_8_BuildNamePath bevp_floatNp;
public BEC_2_5_8_BuildNamePath bevp_stringNp;
public BEC_2_4_6_TextString bevp_trueValue;
public BEC_2_4_6_TextString bevp_falseValue;
public BEC_2_4_6_TextString bevp_instanceEqual;
public BEC_2_4_6_TextString bevp_instanceNotEqual;
public BEC_2_4_6_TextString bevp_libEmitName;
public BEC_2_4_6_TextString bevp_fullLibEmitName;
public BEC_3_2_4_4_IOFilePath bevp_libEmitPath;
public BEC_2_4_6_TextString bevp_methodBody;
public BEC_2_4_3_MathInt bevp_lastMethodBodySize;
public BEC_2_4_3_MathInt bevp_lastMethodBodyLines;
public BEC_2_9_5_ContainerArray bevp_methodCalls;
public BEC_2_4_3_MathInt bevp_methodCatch;
public BEC_2_4_3_MathInt bevp_maxDynArgs;
public BEC_2_4_3_MathInt bevp_maxSpillArgsLen;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_BuildNode bevp_lastCall;
public BEC_2_9_3_ContainerSet bevp_callNames;
public BEC_2_5_11_BuildClassConfig bevp_objectCc;
public BEC_2_5_11_BuildClassConfig bevp_boolCc;
public BEC_2_4_6_TextString bevp_instOf;
public BEC_2_9_3_ContainerMap bevp_smnlcs;
public BEC_2_9_3_ContainerMap bevp_smnlecs;
public BEC_2_9_5_ContainerArray bevp_classesInDepthOrder;
public BEC_2_4_3_MathInt bevp_lineCount;
public BEC_2_4_6_TextString bevp_methods;
public BEC_2_9_5_ContainerArray bevp_classCalls;
public BEC_2_4_3_MathInt bevp_lastMethodsSize;
public BEC_2_4_3_MathInt bevp_lastMethodsLines;
public BEC_2_5_4_BuildNode bevp_mnode;
public BEC_2_5_11_BuildClassConfig bevp_returnType;
public BEC_2_5_6_BuildMtdSyn bevp_msyn;
public BEC_2_4_6_TextString bevp_preClass;
public BEC_2_4_6_TextString bevp_classEmits;
public BEC_2_4_6_TextString bevp_onceDecs;
public BEC_2_4_3_MathInt bevp_onceCount;
public BEC_2_4_6_TextString bevp_propertyDecs;
public BEC_2_5_4_BuildNode bevp_cnode;
public BEC_2_5_8_BuildClassSyn bevp_csyn;
public BEC_2_4_6_TextString bevp_dynMethods;
public BEC_2_4_6_TextString bevp_ccMethods;
public BEC_2_9_5_ContainerArray bevp_superCalls;
public BEC_2_4_3_MathInt bevp_nativeCSlots;
public BEC_2_4_6_TextString bevp_inFilePathed;
public virtual BEC_2_6_6_SystemObject bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_11_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
bevp_build = beva__build;
bevp_nl = bevp_build.bem_nlGet_0();
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_q = bevt_0_tmpvar_phold.bem_quoteGet_0();
bevp_ccCache = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_0));
bevp_objectNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_1));
bevp_boolNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_2));
bevp_intNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_3));
bevp_floatNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_4));
bevp_stringNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_5_tmpvar_phold);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_5));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bels_6));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_8));
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevp_libEmitName = (BEC_2_4_6_TextString) this.bem_libEmitName_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevp_fullLibEmitName = (BEC_2_4_6_TextString) this.bem_fullLibEmitName_1(bevt_7_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_11_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_12_tmpvar_phold.bem_copy_0();
bevt_13_tmpvar_phold = this.bem_emitLangGet_0();
bevt_10_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_11_tmpvar_phold.bem_addStep_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_9));
bevt_9_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_10_tmpvar_phold.bem_addStep_1(bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpvar_phold = this.bem_libEmitName_1(bevt_16_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_9_tmpvar_phold.bem_addStep_1(bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevp_libEmitName.bem_add_1(bevp_fileExt);
bevp_libEmitPath = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpvar_phold.bem_addStep_1(bevt_17_tmpvar_phold);
bevp_methodBody = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_lastMethodBodySize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_lastMethodBodyLines = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_methodCalls = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_methodCatch = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_maxDynArgs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_maxSpillArgsLen = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_callNames = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_objectCc = this.bem_getClassConfig_1(bevp_objectNp);
bevp_boolCc = this.bem_getClassConfig_1(bevp_boolNp);
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_10));
bevt_18_tmpvar_phold = this.bem_emitting_1(bevt_19_tmpvar_phold);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 140 */ {
bevp_instOf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_11));
} /* Line: 141 */
 else  /* Line: 142 */ {
bevp_instOf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_12));
} /* Line: 143 */
bevp_smnlcs = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_smnlecs = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_runtimeInitGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_libEmitName_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_libName.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_2;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_libName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fullLibEmitName_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_libNs_1(beva_libName);
bevt_3_tmpvar_phold = bevo_3;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_4_6_TextString bevl_dname = null;
BEC_2_5_11_BuildClassConfig bevl_toRet = null;
BEC_2_5_7_BuildLibrary bevl_pack = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevl_dname = beva_np.bem_toString_0();
bevl_toRet = (BEC_2_5_11_BuildClassConfig) bevp_ccCache.bem_get_1(bevl_dname);
if (bevl_toRet == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 169 */ {
bevt_2_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_0_tmpvar_loop = bevt_2_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 170 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 170 */ {
bevl_pack = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_pack.bem_emitPathGet_0();
bevt_5_tmpvar_phold = bevl_pack.bem_libNameGet_0();
bevl_toRet = (BEC_2_5_11_BuildClassConfig) (new BEC_2_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_toRet.bem_synPathGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_fileGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_existsGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
return bevl_toRet;
} /* Line: 174 */
} /* Line: 172 */
 else  /* Line: 170 */ {
break;
} /* Line: 170 */
} /* Line: 170 */
bevt_9_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_10_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_toRet = (BEC_2_5_11_BuildClassConfig) (new BEC_2_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_9_tmpvar_phold, bevt_10_tmpvar_phold);
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
} /* Line: 178 */
return bevl_toRet;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_4_6_TextString bevl_dname = null;
BEC_2_5_11_BuildClassConfig bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_dname = beva_np.bem_toString_0();
bevl_toRet = (BEC_2_5_11_BuildClassConfig) bevp_ccCache.bem_get_1(bevl_dname);
if (bevl_toRet == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevt_1_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_toRet = (BEC_2_5_11_BuildClassConfig) (new BEC_2_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
} /* Line: 188 */
return bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_complete_1(BEC_2_5_4_BuildNode beva_clgen) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_emvisit = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_2_tmpvar_phold = bevp_build.bem_printPlacesGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 194 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 194 */ {
bevt_4_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_clgen.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 195 */
bevt_7_tmpvar_phold = beva_clgen.bem_transUnitGet_0();
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_2(bevp_build, (BEC_2_5_4_BuildNode) bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_9_tmpvar_phold = bevo_5;
bevt_9_tmpvar_phold.bem_echo_0();
} /* Line: 203 */
bevl_emvisit = (new BEC_3_5_5_6_BuildVisitRewind()).bem_new_0();
bevl_emvisit.bemd_1(2017492794, BEL_4_Base.bevn_emitterSet_1, this);
bevl_emvisit.bemd_1(481929786, BEL_4_Base.bevn_buildSet_1, bevp_build);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevl_emvisit);
bevt_10_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_11_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 211 */
bevl_emvisit = (new BEC_3_5_5_9_BuildVisitTypeCheck()).bem_new_0();
bevl_emvisit.bemd_1(2017492794, BEL_4_Base.bevn_emitterSet_1, this);
bevl_emvisit.bemd_1(481929786, BEL_4_Base.bevn_buildSet_1, bevp_build);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevl_emvisit);
bevt_12_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_13_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold.bem_echo_0();
bevt_14_tmpvar_phold = bevo_8;
bevt_14_tmpvar_phold.bem_print_0();
} /* Line: 220 */
bevt_15_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 222 */ {
} /* Line: 222 */
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, this);
bevt_16_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 226 */ {
} /* Line: 226 */
bevt_17_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 230 */ {
} /* Line: 230 */
this.bem_buildStackLines_1(beva_clgen);
bevt_18_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 234 */ {
} /* Line: 234 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_doEmit_0() {
BEC_2_9_3_ContainerMap bevl_depthClasses = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_4_6_TextString bevl_clName = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_4_3_MathInt bevl_depth = null;
BEC_2_9_5_ContainerArray bevl_classes = null;
BEC_2_9_5_ContainerArray bevl_depths = null;
BEC_3_2_4_6_IOFileWriter bevl_cle = null;
BEC_2_4_6_TextString bevl_bns = null;
BEC_2_4_6_TextString bevl_cb = null;
BEC_2_4_6_TextString bevl_idec = null;
BEC_2_4_6_TextString bevl_nlcs = null;
BEC_2_4_6_TextString bevl_nlecs = null;
BEC_2_5_4_LogicBool bevl_firstNlc = null;
BEC_2_4_3_MathInt bevl_lastNlc = null;
BEC_2_4_3_MathInt bevl_lastNlec = null;
BEC_2_4_6_TextString bevl_lineInfo = null;
BEC_2_5_4_BuildNode bevl_cc = null;
BEC_2_4_6_TextString bevl_nlcNName = null;
BEC_2_4_6_TextString bevl_smpref = null;
BEC_2_4_6_TextString bevl_ce = null;
BEC_2_4_6_TextString bevl_en = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_1_tmpvar_loop = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_8_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_121_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_130_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_131_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_141_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_142_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_145_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_146_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_147_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_148_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_149_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_150_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_151_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_152_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_153_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_154_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_156_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_157_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_160_tmpvar_phold = null;
bevl_depthClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_6_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_parseOrderClassNamesGet_0();
bevl_ci = bevt_5_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 245 */ {
bevt_7_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevl_clName = (BEC_2_4_6_TextString) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_classesGet_0();
bevl_clnode = (BEC_2_5_4_BuildNode) bevt_8_tmpvar_phold.bem_get_1(bevl_clName);
bevt_11_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_depth = (BEC_2_4_3_MathInt) bevt_10_tmpvar_phold.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevl_classes = (BEC_2_9_5_ContainerArray) bevl_depthClasses.bem_get_1(bevl_depth);
if (bevl_classes == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevl_classes = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_depthClasses.bem_put_2(bevl_depth, bevl_classes);
} /* Line: 254 */
bevl_classes.bem_addValue_1(bevl_clnode);
} /* Line: 256 */
 else  /* Line: 245 */ {
break;
} /* Line: 245 */
} /* Line: 245 */
bevl_depths = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_ci = bevl_depthClasses.bem_keyIteratorGet_0();
while (true)
 /* Line: 260 */ {
bevt_13_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevl_depth = (BEC_2_4_3_MathInt) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_depths.bem_addValue_1(bevl_depth);
} /* Line: 262 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
bevl_depths = (BEC_2_9_5_ContainerArray) bevl_depths.bem_sort_0();
bevp_classesInDepthOrder = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevt_0_tmpvar_loop = bevl_depths.bem_arrayIteratorGet_0();
while (true)
 /* Line: 269 */ {
bevt_14_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevl_depth = (BEC_2_4_3_MathInt) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_classes = (BEC_2_9_5_ContainerArray) bevl_depthClasses.bem_get_1(bevl_depth);
bevt_1_tmpvar_loop = bevl_classes.bem_arrayIteratorGet_0();
while (true)
 /* Line: 271 */ {
bevt_15_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevl_clnode = (BEC_2_5_4_BuildNode) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_classesInDepthOrder.bem_addValue_1(bevl_clnode);
} /* Line: 272 */
 else  /* Line: 271 */ {
break;
} /* Line: 271 */
} /* Line: 271 */
} /* Line: 271 */
 else  /* Line: 269 */ {
break;
} /* Line: 269 */
} /* Line: 269 */
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 276 */ {
bevt_16_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 276 */ {
bevl_clnode = (BEC_2_5_4_BuildNode) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_18_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_classConf = this.bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 281 */ {
} /* Line: 281 */
this.bem_complete_1(bevl_clnode);
bevl_cle = this.bem_getClassOutput_0();
bevl_bns = this.bem_beginNs_0();
bevt_20_tmpvar_phold = this.bem_countLines_1(bevl_bns);
bevp_lineCount.bem_addValue_1(bevt_20_tmpvar_phold);
bevl_cle.bem_write_1(bevl_bns);
bevt_21_tmpvar_phold = this.bem_countLines_1(bevp_preClass);
bevp_lineCount.bem_addValue_1(bevt_21_tmpvar_phold);
bevl_cle.bem_write_1(bevp_preClass);
bevl_cb = this.bem_classBeginGet_0();
bevt_22_tmpvar_phold = this.bem_countLines_1(bevl_cb);
bevp_lineCount.bem_addValue_1(bevt_22_tmpvar_phold);
bevl_cle.bem_write_1(bevl_cb);
bevt_23_tmpvar_phold = this.bem_countLines_1(bevp_classEmits);
bevp_lineCount.bem_addValue_1(bevt_23_tmpvar_phold);
bevl_cle.bem_write_1(bevp_classEmits);
bevt_24_tmpvar_phold = this.bem_writeOnceDecs_2(bevl_cle, bevp_onceDecs);
bevp_lineCount.bem_addValue_1((BEC_2_4_3_MathInt) bevt_24_tmpvar_phold);
bevl_idec = this.bem_initialDecGet_0();
bevt_25_tmpvar_phold = this.bem_countLines_1(bevl_idec);
bevp_lineCount.bem_addValue_1(bevt_25_tmpvar_phold);
bevl_cle.bem_write_1(bevl_idec);
bevt_26_tmpvar_phold = this.bem_countLines_1(bevp_propertyDecs);
bevp_lineCount.bem_addValue_1(bevt_26_tmpvar_phold);
bevl_cle.bem_write_1(bevp_propertyDecs);
bevl_nlcs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_nlecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_firstNlc = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_22));
bevl_lineInfo = (BEC_2_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_2_tmpvar_loop = bevp_classCalls.bem_arrayIteratorGet_0();
while (true)
 /* Line: 335 */ {
bevt_28_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 335 */ {
bevl_cc = (BEC_2_5_4_BuildNode) bevt_2_tmpvar_loop.bem_nextGet_0();
bevt_29_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_29_tmpvar_phold.bem_addValue_1(bevp_lineCount);
bevt_30_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_30_tmpvar_phold.bem_incrementValue_0();
if (bevl_lastNlc == null) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 339 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 339 */ {
bevt_33_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevt_32_tmpvar_phold = bevl_lastNlc.bem_notEquals_1(bevt_33_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 339 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 339 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 339 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 339 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 339 */ {
bevt_35_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_34_tmpvar_phold = bevl_lastNlec.bem_notEquals_1(bevt_35_tmpvar_phold);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 339 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 339 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 339 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 339 */ {
if (bevl_firstNlc.bevi_bool) /* Line: 342 */ {
bevl_firstNlc = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 343 */
 else  /* Line: 344 */ {
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_23));
bevl_nlcs.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_24));
bevl_nlecs.bem_addValue_1(bevt_37_tmpvar_phold);
} /* Line: 346 */
bevt_38_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevl_nlcs.bem_addValue_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevl_nlecs.bem_addValue_1(bevt_39_tmpvar_phold);
} /* Line: 349 */
bevl_lastNlc = bevl_cc.bem_nlcGet_0();
bevl_lastNlec = bevl_cc.bem_nlecGet_0();
bevt_48_tmpvar_phold = bevl_cc.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_46_tmpvar_phold = (BEC_2_4_6_TextString) bevl_lineInfo.bem_addValue_1(bevt_47_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_25));
bevt_45_tmpvar_phold = (BEC_2_4_6_TextString) bevt_46_tmpvar_phold.bem_addValue_1(bevt_49_tmpvar_phold);
bevt_51_tmpvar_phold = bevl_cc.bem_heldGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) bevt_45_tmpvar_phold.bem_addValue_1(bevt_50_tmpvar_phold);
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_26));
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) bevt_44_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevt_42_tmpvar_phold = (BEC_2_4_6_TextString) bevt_43_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_54_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_27));
bevt_41_tmpvar_phold = (BEC_2_4_6_TextString) bevt_42_tmpvar_phold.bem_addValue_1(bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) bevt_41_tmpvar_phold.bem_addValue_1(bevt_55_tmpvar_phold);
bevt_40_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 354 */
 else  /* Line: 335 */ {
break;
} /* Line: 335 */
} /* Line: 335 */
bevt_57_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_28));
bevt_56_tmpvar_phold = (BEC_2_4_6_TextString) bevl_lineInfo.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_56_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_61_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_59_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_60_tmpvar_phold);
bevt_62_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bem_relEmitName_1(bevt_62_tmpvar_phold);
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_29));
bevl_nlcNName = (BEC_2_4_6_TextString) bevt_58_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_63_tmpvar_phold);
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_30));
bevt_64_tmpvar_phold = this.bem_emitting_1(bevt_65_tmpvar_phold);
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 362 */ {
bevt_69_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_68_tmpvar_phold);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_emitNameGet_0();
bevt_70_tmpvar_phold = bevo_9;
bevl_smpref = bevt_66_tmpvar_phold.bem_add_1(bevt_70_tmpvar_phold);
bevl_nlcNName = bevl_smpref;
} /* Line: 365 */
bevt_73_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_75_tmpvar_phold = bevo_10;
bevt_74_tmpvar_phold = bevl_nlcNName.bem_add_1(bevt_75_tmpvar_phold);
bevp_smnlcs.bem_put_2(bevt_71_tmpvar_phold, bevt_74_tmpvar_phold);
bevt_78_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_80_tmpvar_phold = bevo_11;
bevt_79_tmpvar_phold = bevl_nlcNName.bem_add_1(bevt_80_tmpvar_phold);
bevp_smnlecs.bem_put_2(bevt_76_tmpvar_phold, bevt_79_tmpvar_phold);
bevt_82_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_34));
bevt_81_tmpvar_phold = this.bem_emitting_1(bevt_82_tmpvar_phold);
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 371 */ {
bevt_84_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 372 */ {
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bels_35));
bevt_85_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_86_tmpvar_phold);
bevt_85_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 373 */
 else  /* Line: 374 */ {
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_36));
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_88_tmpvar_phold);
bevt_87_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 375 */
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_37));
bevt_91_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_92_tmpvar_phold);
bevt_90_tmpvar_phold = (BEC_2_4_6_TextString) bevt_91_tmpvar_phold.bem_addValue_1(bevl_nlcs);
bevt_93_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_38));
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) bevt_90_tmpvar_phold.bem_addValue_1(bevt_93_tmpvar_phold);
bevt_89_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 377 */
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_39));
bevt_94_tmpvar_phold = this.bem_emitting_1(bevt_95_tmpvar_phold);
if (bevt_94_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_40));
bevt_96_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_97_tmpvar_phold);
bevt_96_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_101_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_41));
bevt_100_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_101_tmpvar_phold);
bevt_99_tmpvar_phold = (BEC_2_4_6_TextString) bevt_100_tmpvar_phold.bem_addValue_1(bevl_nlcs);
bevt_102_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_42));
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) bevt_99_tmpvar_phold.bem_addValue_1(bevt_102_tmpvar_phold);
bevt_98_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_104_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_43));
bevt_103_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_104_tmpvar_phold);
bevt_103_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_106_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bels_44));
bevt_105_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_106_tmpvar_phold);
bevt_105_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_108_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_45));
bevt_107_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_108_tmpvar_phold);
bevt_107_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 384 */
bevt_110_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_46));
bevt_109_tmpvar_phold = this.bem_emitting_1(bevt_110_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevt_111_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevl_smpref);
bevt_112_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_47));
bevt_111_tmpvar_phold.bem_addValue_1(bevt_112_tmpvar_phold);
bevt_116_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_48));
bevt_115_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_116_tmpvar_phold);
bevt_114_tmpvar_phold = (BEC_2_4_6_TextString) bevt_115_tmpvar_phold.bem_addValue_1(bevl_nlcs);
bevt_117_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_49));
bevt_113_tmpvar_phold = (BEC_2_4_6_TextString) bevt_114_tmpvar_phold.bem_addValue_1(bevt_117_tmpvar_phold);
bevt_113_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 388 */
bevt_119_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_50));
bevt_118_tmpvar_phold = this.bem_emitting_1(bevt_119_tmpvar_phold);
if (bevt_118_tmpvar_phold.bevi_bool) /* Line: 390 */ {
bevt_121_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_120_tmpvar_phold.bevi_bool) /* Line: 392 */ {
bevt_123_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bels_51));
bevt_122_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_123_tmpvar_phold);
bevt_122_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 393 */
 else  /* Line: 394 */ {
bevt_125_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bels_52));
bevt_124_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_125_tmpvar_phold);
bevt_124_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 395 */
bevt_129_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_53));
bevt_128_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_129_tmpvar_phold);
bevt_127_tmpvar_phold = (BEC_2_4_6_TextString) bevt_128_tmpvar_phold.bem_addValue_1(bevl_nlecs);
bevt_130_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_54));
bevt_126_tmpvar_phold = (BEC_2_4_6_TextString) bevt_127_tmpvar_phold.bem_addValue_1(bevt_130_tmpvar_phold);
bevt_126_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 397 */
bevt_132_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_55));
bevt_131_tmpvar_phold = this.bem_emitting_1(bevt_132_tmpvar_phold);
if (bevt_131_tmpvar_phold.bevi_bool) /* Line: 399 */ {
bevt_134_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bels_56));
bevt_133_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_134_tmpvar_phold);
bevt_133_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_138_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_57));
bevt_137_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_138_tmpvar_phold);
bevt_136_tmpvar_phold = (BEC_2_4_6_TextString) bevt_137_tmpvar_phold.bem_addValue_1(bevl_nlecs);
bevt_139_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_58));
bevt_135_tmpvar_phold = (BEC_2_4_6_TextString) bevt_136_tmpvar_phold.bem_addValue_1(bevt_139_tmpvar_phold);
bevt_135_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_141_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_59));
bevt_140_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_141_tmpvar_phold);
bevt_140_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_143_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bels_60));
bevt_142_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_143_tmpvar_phold);
bevt_142_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_145_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bels_61));
bevt_144_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_145_tmpvar_phold);
bevt_144_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 404 */
bevt_147_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_62));
bevt_146_tmpvar_phold = this.bem_emitting_1(bevt_147_tmpvar_phold);
if (bevt_146_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevt_148_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevl_smpref);
bevt_149_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_63));
bevt_148_tmpvar_phold.bem_addValue_1(bevt_149_tmpvar_phold);
bevt_153_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_64));
bevt_152_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_153_tmpvar_phold);
bevt_151_tmpvar_phold = (BEC_2_4_6_TextString) bevt_152_tmpvar_phold.bem_addValue_1(bevl_nlecs);
bevt_154_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_65));
bevt_150_tmpvar_phold = (BEC_2_4_6_TextString) bevt_151_tmpvar_phold.bem_addValue_1(bevt_154_tmpvar_phold);
bevt_150_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 408 */
bevp_methods.bem_addValue_1(bevl_lineInfo);
bevt_155_tmpvar_phold = this.bem_countLines_1(bevp_methods);
bevp_lineCount.bem_addValue_1(bevt_155_tmpvar_phold);
bevl_cle.bem_write_1(bevp_methods);
bevt_156_tmpvar_phold = this.bem_useDynMethodsGet_0();
if (bevt_156_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevt_157_tmpvar_phold = this.bem_countLines_1(bevp_dynMethods);
bevp_lineCount.bem_addValue_1(bevt_157_tmpvar_phold);
bevl_cle.bem_write_1(bevp_dynMethods);
} /* Line: 420 */
bevt_158_tmpvar_phold = this.bem_countLines_1(bevp_ccMethods);
bevp_lineCount.bem_addValue_1(bevt_158_tmpvar_phold);
bevl_cle.bem_write_1(bevp_ccMethods);
bevl_ce = this.bem_classEndGet_0();
bevt_159_tmpvar_phold = this.bem_countLines_1(bevl_ce);
bevp_lineCount.bem_addValue_1(bevt_159_tmpvar_phold);
bevl_cle.bem_write_1(bevl_ce);
bevl_en = this.bem_endNs_0();
bevt_160_tmpvar_phold = this.bem_countLines_1(bevl_en);
bevp_lineCount.bem_addValue_1(bevt_160_tmpvar_phold);
bevl_cle.bem_write_1(bevl_en);
this.bem_finishClassOutput_1(bevl_cle);
} /* Line: 438 */
 else  /* Line: 276 */ {
break;
} /* Line: 276 */
} /* Line: 276 */
this.bem_emitLib_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
beva_cle.bemd_1(1603004369, BEL_4_Base.bevn_write_1, beva_onceDecs);
bevt_0_tmpvar_phold = this.bem_countLines_1((BEC_2_4_6_TextString) beva_onceDecs);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_lineCount = (BEC_2_4_3_MathInt) bevt_0_tmpvar_phold.bem_copy_0();
bevt_4_tmpvar_phold = bevp_classConf.bem_classDirGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_fileGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_existsGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_not_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 457 */ {
bevt_6_tmpvar_phold = bevp_classConf.bem_classDirGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_fileGet_0();
bevt_5_tmpvar_phold.bem_makeDirs_0();
} /* Line: 458 */
bevt_10_tmpvar_phold = bevp_classConf.bem_classPathGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
return (BEC_3_2_4_6_IOFileWriter) bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
beva_cle.bem_close_0();
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_writerGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
return (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_66));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_67));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_overrideSmtdDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_68));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_baseSmtdDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_69));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_baseMtdDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_70));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_overrideMtdDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_71));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_72));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_emitting_1(BEC_2_4_6_TextString beva_lang) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_emitLangGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(beva_lang);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 504 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 505 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLib_0() {
BEC_2_4_6_TextString bevl_getNames = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_initLibs = null;
BEC_2_5_7_BuildLibrary bevl_bl = null;
BEC_2_4_6_TextString bevl_typeInstances = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_callName = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_89_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_130_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_145_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_146_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_147_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_148_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_149_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_150_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_151_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_152_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_153_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_154_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_157_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_158_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_160_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_161_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_162_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_166_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_167_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_169_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_172_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_174_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_176_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_177_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_180_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_182_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_184_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_185_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_186_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_188_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_189_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_190_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_191_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_192_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_193_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_194_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_195_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_196_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_197_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_198_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_199_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_201_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_203_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_204_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_205_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_206_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_207_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_208_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_209_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_210_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_211_tmpvar_phold = null;
bevl_getNames = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_4_tmpvar_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_4_tmpvar_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_73));
bevt_5_tmpvar_phold = this.bem_mainStartGet_0();
bevl_main.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevp_fullLibEmitName);
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_74));
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_75));
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_76));
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_77));
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_17_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_78));
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_19_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = this.bem_mainEndGet_0();
bevl_main.bem_addValue_1(bevt_21_tmpvar_phold);
bevl_libe = this.bem_getLibOutput_0();
bevt_22_tmpvar_phold = this.bem_beginNs_0();
bevl_libe.bem_write_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_79));
bevl_extends = this.bem_extend_1(bevt_23_tmpvar_phold);
bevt_28_tmpvar_phold = this.bem_klassDecGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevl_extends);
bevt_29_tmpvar_phold = bevo_12;
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_24_tmpvar_phold);
bevt_33_tmpvar_phold = this.bem_spropDecGet_0();
bevt_34_tmpvar_phold = this.bem_boolTypeGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = bevo_13;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_add_1(bevt_35_tmpvar_phold);
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_30_tmpvar_phold);
bevl_initLibs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_36_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_0_tmpvar_loop = bevt_36_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 534 */ {
bevt_37_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 534 */ {
bevl_bl = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpvar_phold = bevl_bl.bem_libNameGet_0();
bevt_40_tmpvar_phold = this.bem_fullLibEmitName_1(bevt_41_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) bevl_initLibs.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_42_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_82));
bevt_38_tmpvar_phold = (BEC_2_4_6_TextString) bevt_39_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_38_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 536 */
 else  /* Line: 534 */ {
break;
} /* Line: 534 */
} /* Line: 534 */
bevl_typeInstances = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 542 */ {
bevt_43_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_43_tmpvar_phold != null && bevt_43_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_43_tmpvar_phold).bevi_bool) /* Line: 542 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_45_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_83));
bevt_44_tmpvar_phold = this.bem_emitting_1(bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 546 */ {
bevt_55_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(44, bels_84));
bevt_54_tmpvar_phold = (BEC_2_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_55_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) bevt_54_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_58_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) bevt_53_tmpvar_phold.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_51_tmpvar_phold = (BEC_2_4_6_TextString) bevt_52_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_85));
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) bevt_51_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_2_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_63_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_61_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_62_tmpvar_phold);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_fullEmitNameGet_0();
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) bevt_48_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_64_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_86));
bevt_46_tmpvar_phold = (BEC_2_4_6_TextString) bevt_47_tmpvar_phold.bem_addValue_1(bevt_64_tmpvar_phold);
bevt_46_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 547 */
bevt_66_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_87));
bevt_65_tmpvar_phold = this.bem_emitting_1(bevt_66_tmpvar_phold);
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 549 */ {
bevt_74_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(40, bels_88));
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_74_tmpvar_phold);
bevt_72_tmpvar_phold = (BEC_2_4_6_TextString) bevt_73_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_77_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_71_tmpvar_phold = (BEC_2_4_6_TextString) bevt_72_tmpvar_phold.bem_addValue_1(bevt_75_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_2_4_6_TextString) bevt_71_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_78_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_89));
bevt_69_tmpvar_phold = (BEC_2_4_6_TextString) bevt_70_tmpvar_phold.bem_addValue_1(bevt_78_tmpvar_phold);
bevt_82_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_80_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_81_tmpvar_phold);
bevt_83_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_relEmitName_1(bevt_83_tmpvar_phold);
bevt_68_tmpvar_phold = (BEC_2_4_6_TextString) bevt_69_tmpvar_phold.bem_addValue_1(bevt_79_tmpvar_phold);
bevt_84_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_90));
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) bevt_68_tmpvar_phold.bem_addValue_1(bevt_84_tmpvar_phold);
bevt_67_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_91));
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_87_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_90_tmpvar_phold = bevt_91_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_89_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_90_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_relEmitName_1(bevt_92_tmpvar_phold);
bevt_85_tmpvar_phold = (BEC_2_4_6_TextString) bevt_86_tmpvar_phold.bem_addValue_1(bevt_88_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_92));
bevt_85_tmpvar_phold.bem_addValue_1(bevt_93_tmpvar_phold);
bevt_99_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_93));
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_99_tmpvar_phold);
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) bevt_98_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_100_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_94));
bevt_96_tmpvar_phold = (BEC_2_4_6_TextString) bevt_97_tmpvar_phold.bem_addValue_1(bevt_100_tmpvar_phold);
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) bevt_96_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_101_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bels_95));
bevt_94_tmpvar_phold = (BEC_2_4_6_TextString) bevt_95_tmpvar_phold.bem_addValue_1(bevt_101_tmpvar_phold);
bevt_94_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 552 */
bevt_104_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_102_tmpvar_phold != null && bevt_102_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_102_tmpvar_phold).bevi_bool) /* Line: 555 */ {
bevt_106_tmpvar_phold = bevo_14;
bevt_110_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_108_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_109_tmpvar_phold);
bevt_111_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bem_relEmitName_1(bevt_111_tmpvar_phold);
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevt_112_tmpvar_phold = bevo_15;
bevl_nc = bevt_105_tmpvar_phold.bem_add_1(bevt_112_tmpvar_phold);
bevt_116_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bels_98));
bevt_115_tmpvar_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_116_tmpvar_phold);
bevt_114_tmpvar_phold = (BEC_2_4_6_TextString) bevt_115_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_117_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_99));
bevt_113_tmpvar_phold = (BEC_2_4_6_TextString) bevt_114_tmpvar_phold.bem_addValue_1(bevt_117_tmpvar_phold);
bevt_113_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_121_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bels_100));
bevt_120_tmpvar_phold = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_121_tmpvar_phold);
bevt_119_tmpvar_phold = (BEC_2_4_6_TextString) bevt_120_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_122_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_101));
bevt_118_tmpvar_phold = (BEC_2_4_6_TextString) bevt_119_tmpvar_phold.bem_addValue_1(bevt_122_tmpvar_phold);
bevt_118_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 558 */
} /* Line: 555 */
 else  /* Line: 542 */ {
break;
} /* Line: 542 */
} /* Line: 542 */
bevt_1_tmpvar_loop = bevp_callNames.bem_setIteratorGet_0();
while (true)
 /* Line: 562 */ {
bevt_123_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_123_tmpvar_phold.bevi_bool) /* Line: 562 */ {
bevl_callName = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevt_128_tmpvar_phold = this.bem_spropDecGet_0();
bevt_129_tmpvar_phold = bevo_16;
bevt_127_tmpvar_phold = bevt_128_tmpvar_phold.bem_add_1(bevt_129_tmpvar_phold);
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bem_add_1(bevl_callName);
bevt_130_tmpvar_phold = bevo_17;
bevt_125_tmpvar_phold = bevt_126_tmpvar_phold.bem_add_1(bevt_130_tmpvar_phold);
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_124_tmpvar_phold);
bevt_138_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_104));
bevt_137_tmpvar_phold = (BEC_2_4_6_TextString) bevl_getNames.bem_addValue_1(bevt_138_tmpvar_phold);
bevt_136_tmpvar_phold = (BEC_2_4_6_TextString) bevt_137_tmpvar_phold.bem_addValue_1(bevl_callName);
bevt_139_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_105));
bevt_135_tmpvar_phold = (BEC_2_4_6_TextString) bevt_136_tmpvar_phold.bem_addValue_1(bevt_139_tmpvar_phold);
bevt_134_tmpvar_phold = (BEC_2_4_6_TextString) bevt_135_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_133_tmpvar_phold = (BEC_2_4_6_TextString) bevt_134_tmpvar_phold.bem_addValue_1(bevl_callName);
bevt_132_tmpvar_phold = (BEC_2_4_6_TextString) bevt_133_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_140_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_106));
bevt_131_tmpvar_phold = (BEC_2_4_6_TextString) bevt_132_tmpvar_phold.bem_addValue_1(bevt_140_tmpvar_phold);
bevt_131_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 564 */
 else  /* Line: 562 */ {
break;
} /* Line: 562 */
} /* Line: 562 */
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_141_tmpvar_phold = bevp_smnlcs.bem_keysGet_0();
bevt_2_tmpvar_loop = bevt_141_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 569 */ {
bevt_142_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_142_tmpvar_phold != null && bevt_142_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_142_tmpvar_phold).bevi_bool) /* Line: 569 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_150_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_107));
bevt_149_tmpvar_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_150_tmpvar_phold);
bevt_152_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_151_tmpvar_phold = bevt_152_tmpvar_phold.bem_quoteGet_0();
bevt_148_tmpvar_phold = (BEC_2_4_6_TextString) bevt_149_tmpvar_phold.bem_addValue_1(bevt_151_tmpvar_phold);
bevt_147_tmpvar_phold = (BEC_2_4_6_TextString) bevt_148_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_154_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bem_quoteGet_0();
bevt_146_tmpvar_phold = (BEC_2_4_6_TextString) bevt_147_tmpvar_phold.bem_addValue_1(bevt_153_tmpvar_phold);
bevt_155_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_108));
bevt_145_tmpvar_phold = (BEC_2_4_6_TextString) bevt_146_tmpvar_phold.bem_addValue_1(bevt_155_tmpvar_phold);
bevt_156_tmpvar_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_144_tmpvar_phold = (BEC_2_4_6_TextString) bevt_145_tmpvar_phold.bem_addValue_1(bevt_156_tmpvar_phold);
bevt_157_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_109));
bevt_143_tmpvar_phold = (BEC_2_4_6_TextString) bevt_144_tmpvar_phold.bem_addValue_1(bevt_157_tmpvar_phold);
bevt_143_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_165_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bels_110));
bevt_164_tmpvar_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_165_tmpvar_phold);
bevt_167_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_166_tmpvar_phold = bevt_167_tmpvar_phold.bem_quoteGet_0();
bevt_163_tmpvar_phold = (BEC_2_4_6_TextString) bevt_164_tmpvar_phold.bem_addValue_1(bevt_166_tmpvar_phold);
bevt_162_tmpvar_phold = (BEC_2_4_6_TextString) bevt_163_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_169_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_168_tmpvar_phold = bevt_169_tmpvar_phold.bem_quoteGet_0();
bevt_161_tmpvar_phold = (BEC_2_4_6_TextString) bevt_162_tmpvar_phold.bem_addValue_1(bevt_168_tmpvar_phold);
bevt_170_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_111));
bevt_160_tmpvar_phold = (BEC_2_4_6_TextString) bevt_161_tmpvar_phold.bem_addValue_1(bevt_170_tmpvar_phold);
bevt_171_tmpvar_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_159_tmpvar_phold = (BEC_2_4_6_TextString) bevt_160_tmpvar_phold.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_172_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_112));
bevt_158_tmpvar_phold = (BEC_2_4_6_TextString) bevt_159_tmpvar_phold.bem_addValue_1(bevt_172_tmpvar_phold);
bevt_158_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 572 */
 else  /* Line: 569 */ {
break;
} /* Line: 569 */
} /* Line: 569 */
bevt_176_tmpvar_phold = this.bem_baseSmtdDecGet_0();
bevt_177_tmpvar_phold = bevo_18;
bevt_175_tmpvar_phold = bevt_176_tmpvar_phold.bem_add_1(bevt_177_tmpvar_phold);
bevt_174_tmpvar_phold = (BEC_2_4_6_TextString) bevt_175_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_179_tmpvar_phold = bevo_19;
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bem_add_1(bevp_nl);
bevt_173_tmpvar_phold = (BEC_2_4_6_TextString) bevt_174_tmpvar_phold.bem_addValue_1(bevt_178_tmpvar_phold);
bevl_libe.bem_write_1(bevt_173_tmpvar_phold);
bevt_181_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_115));
bevt_180_tmpvar_phold = this.bem_emitting_1(bevt_181_tmpvar_phold);
if (bevt_180_tmpvar_phold.bevi_bool) /* Line: 577 */ {
bevt_185_tmpvar_phold = bevo_20;
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_186_tmpvar_phold = bevo_21;
bevt_183_tmpvar_phold = bevt_184_tmpvar_phold.bem_add_1(bevt_186_tmpvar_phold);
bevt_182_tmpvar_phold = bevt_183_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_182_tmpvar_phold);
} /* Line: 578 */
 else  /* Line: 577 */ {
bevt_188_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_118));
bevt_187_tmpvar_phold = this.bem_emitting_1(bevt_188_tmpvar_phold);
if (bevt_187_tmpvar_phold.bevi_bool) /* Line: 579 */ {
bevt_192_tmpvar_phold = bevo_22;
bevt_191_tmpvar_phold = bevt_192_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_193_tmpvar_phold = bevo_23;
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bem_add_1(bevt_193_tmpvar_phold);
bevt_189_tmpvar_phold = bevt_190_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_189_tmpvar_phold);
} /* Line: 580 */
} /* Line: 577 */
bevt_195_tmpvar_phold = bevo_24;
bevt_194_tmpvar_phold = bevt_195_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_194_tmpvar_phold);
bevt_197_tmpvar_phold = bevo_25;
bevt_196_tmpvar_phold = bevt_197_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_196_tmpvar_phold);
bevt_198_tmpvar_phold = this.bem_runtimeInitGet_0();
bevl_libe.bem_write_1(bevt_198_tmpvar_phold);
bevl_libe.bem_write_1(bevl_getNames);
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_initLibs);
bevl_libe.bem_write_1(bevl_typeInstances);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_200_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_123));
bevt_199_tmpvar_phold = this.bem_emitting_1(bevt_200_tmpvar_phold);
if (bevt_199_tmpvar_phold.bevi_bool) /* Line: 591 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
bevt_202_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_124));
bevt_201_tmpvar_phold = this.bem_emitting_1(bevt_202_tmpvar_phold);
if (bevt_201_tmpvar_phold.bevi_bool) /* Line: 591 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 591 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 591 */ {
bevt_204_tmpvar_phold = bevo_26;
bevt_203_tmpvar_phold = bevt_204_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_203_tmpvar_phold);
} /* Line: 593 */
bevt_206_tmpvar_phold = bevo_27;
bevt_205_tmpvar_phold = bevt_206_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_205_tmpvar_phold);
bevt_207_tmpvar_phold = this.bem_mainInClassGet_0();
if (bevt_207_tmpvar_phold.bevi_bool) /* Line: 597 */ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 598 */
bevt_209_tmpvar_phold = bevo_28;
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_208_tmpvar_phold);
bevt_210_tmpvar_phold = this.bem_endNs_0();
bevl_libe.bem_write_1(bevt_210_tmpvar_phold);
bevt_211_tmpvar_phold = this.bem_mainOutsideNsGet_0();
if (bevt_211_tmpvar_phold.bevi_bool) /* Line: 604 */ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 605 */
this.bem_finishLibOutput_1(bevl_libe);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_procStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_29;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_mainInClassGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_129));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_mainEndGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_130));
bevt_1_tmpvar_phold = this.bem_emitting_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 631 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 631 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_131));
bevt_3_tmpvar_phold = this.bem_emitting_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 631 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 631 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 631 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 631 */ {
bevt_6_tmpvar_phold = bevo_30;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_5_tmpvar_phold;
} /* Line: 633 */
bevt_8_tmpvar_phold = bevo_31;
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_134));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bevp_methods = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classCalls = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_lastMethodsSize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_lastMethodsLines = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_4_6_TextString bevl_prefix = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isTmpVarGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 657 */ {
bevl_prefix = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_135));
} /* Line: 658 */
 else  /* Line: 657 */ {
bevt_1_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 659 */ {
bevl_prefix = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_136));
} /* Line: 660 */
 else  /* Line: 657 */ {
bevt_2_tmpvar_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 661 */ {
bevl_prefix = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_137));
} /* Line: 662 */
 else  /* Line: 663 */ {
bevl_prefix = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_138));
} /* Line: 664 */
} /* Line: 657 */
} /* Line: 657 */
bevt_4_tmpvar_phold = beva_v.bem_nameGet_0();
bevt_3_tmpvar_phold = bevl_prefix.bem_add_1(bevt_4_tmpvar_phold);
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_5_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_v.bem_isTypedGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 671 */ {
bevt_3_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_2_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_3_tmpvar_phold);
beva_b.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 672 */
 else  /* Line: 673 */ {
bevt_6_tmpvar_phold = beva_v.bem_namepathGet_0();
bevt_5_tmpvar_phold = this.bem_getClassConfig_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_relEmitName_1(bevt_7_tmpvar_phold);
beva_b.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 674 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_decForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
this.bem_typeDecForVar_2(beva_b, beva_v);
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_139));
beva_b.bem_addValue_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitNameForMethod_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_32;
bevt_3_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitNameForCall_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_33;
bevt_3_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptMethod_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_argDecs = null;
BEC_2_4_6_TextString bevl_varDecs = null;
BEC_2_5_4_LogicBool bevl_isFirstArg = null;
BEC_2_5_4_BuildNode bevl_ov = null;
BEC_2_5_8_BuildNamePath bevl_ertype = null;
BEC_2_4_6_TextString bevl_mtdDec = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_40_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
bevp_mnode = beva_node;
bevp_returnType = null;
bevt_2_tmpvar_phold = bevp_csyn.bem_mtdMapGet_0();
bevt_4_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_2_tmpvar_phold.bem_get_1(bevt_3_tmpvar_phold);
bevt_6_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_callNames.bem_put_1(bevt_5_tmpvar_phold);
bevl_argDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_varDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_isFirstArg = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_8_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_0_tmpvar_loop = bevt_7_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 706 */ {
bevt_9_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 706 */ {
bevl_ov = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_142));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_13_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 707 */ {
bevt_16_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_143));
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_17_tmpvar_phold);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 707 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 707 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 707 */
 else  /* Line: 707 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 707 */ {
bevt_19_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 708 */ {
if (!(bevl_isFirstArg.bevi_bool)) /* Line: 709 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_144));
bevl_argDecs.bem_addValue_1(bevt_20_tmpvar_phold);
} /* Line: 710 */
bevl_isFirstArg = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_22_tmpvar_phold = bevl_ov.bem_heldGet_0();
if (bevt_22_tmpvar_phold == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 713 */ {
bevt_25_tmpvar_phold = bevo_34;
bevt_26_tmpvar_phold = bevl_ov.bem_toString_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevt_26_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_24_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_23_tmpvar_phold);
} /* Line: 714 */
bevt_27_tmpvar_phold = bevl_ov.bem_heldGet_0();
this.bem_decForVar_2(bevl_argDecs, (BEC_2_5_3_BuildVar) bevt_27_tmpvar_phold);
} /* Line: 716 */
 else  /* Line: 717 */ {
bevt_28_tmpvar_phold = bevl_ov.bem_heldGet_0();
this.bem_decForVar_2(bevl_varDecs, (BEC_2_5_3_BuildVar) bevt_28_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_146));
bevt_29_tmpvar_phold = this.bem_emitting_1(bevt_30_tmpvar_phold);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 719 */ {
bevt_32_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_147));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) bevl_varDecs.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 720 */
 else  /* Line: 721 */ {
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_148));
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) bevl_varDecs.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_33_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 722 */
} /* Line: 719 */
bevt_35_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_37_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_36_tmpvar_phold = this.bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_37_tmpvar_phold);
bevt_35_tmpvar_phold.bemd_1(792634738, BEL_4_Base.bevn_nativeNameSet_1, bevt_36_tmpvar_phold);
} /* Line: 725 */
} /* Line: 707 */
 else  /* Line: 706 */ {
break;
} /* Line: 706 */
} /* Line: 706 */
bevl_ertype = bevp_msyn.bem_getEmitReturnType_2(bevp_csyn, bevp_build);
if (bevl_ertype == null) {
bevt_38_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_38_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 731 */ {
bevp_returnType = this.bem_getClassConfig_1(bevl_ertype);
} /* Line: 732 */
 else  /* Line: 733 */ {
bevp_returnType = bevp_objectCc;
} /* Line: 734 */
bevt_40_tmpvar_phold = bevp_msyn.bem_declarationGet_0();
bevt_41_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_equals_1(bevt_41_tmpvar_phold);
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 738 */ {
bevl_mtdDec = this.bem_baseMtdDecGet_0();
} /* Line: 739 */
 else  /* Line: 740 */ {
bevl_mtdDec = this.bem_overrideMtdDecGet_0();
} /* Line: 741 */
bevt_42_tmpvar_phold = this.bem_emitNameForMethod_1(beva_node);
this.bem_startMethod_5(bevl_mtdDec, bevp_returnType, bevt_42_tmpvar_phold, bevl_argDecs, bevp_exceptDec);
bevp_methods.bem_addValue_1(bevl_varDecs);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_5_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpvar_phold = beva_returnType.bem_relEmitName_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_149));
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_mtdName);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_150));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_151));
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(beva_exceptDec);
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_152));
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isClose_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_8_BuildClassSyn bevl_orgsyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_orgsyn = bevp_build.bem_getSynNp_1(beva_np);
bevt_1_tmpvar_phold = bevp_build.bem_closeLibrariesGet_0();
bevt_2_tmpvar_phold = bevl_orgsyn.bem_libNameGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_has_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 762 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 763 */
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptClass_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_te = null;
BEC_2_6_6_SystemObject bevl_jn = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_4_6_TextString bevl_inlang = null;
BEC_2_5_4_BuildNode bevl_innode = null;
BEC_2_4_3_MathInt bevl_ovcount = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_9_3_ContainerMap bevl_dynGen = null;
BEC_2_9_3_ContainerSet bevl_mq = null;
BEC_2_5_6_BuildMtdSyn bevl_msyn = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_3_ContainerMap bevl_dgm = null;
BEC_2_4_3_MathInt bevl_msh = null;
BEC_2_9_5_ContainerArray bevl_dgv = null;
BEC_3_9_3_7_ContainerMapMapNode bevl_dnode = null;
BEC_2_4_3_MathInt bevl_dnumargs = null;
BEC_2_4_6_TextString bevl_dmname = null;
BEC_2_4_6_TextString bevl_superArgs = null;
BEC_2_4_6_TextString bevl_args = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_3_9_3_7_ContainerMapMapNode bevl_msnode = null;
BEC_2_4_3_MathInt bevl_thisHash = null;
BEC_2_5_4_LogicBool bevl_dynConditions = null;
BEC_2_4_6_TextString bevl_mcall = null;
BEC_2_4_6_TextString bevl_constName = null;
BEC_2_4_3_MathInt bevl_vnumargs = null;
BEC_2_5_6_BuildVarSyn bevl_vsyn = null;
BEC_2_4_6_TextString bevl_vcast = null;
BEC_2_4_6_TextString bevl_vcma = null;
BEC_2_4_6_TextString bevl_varg = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_2_tmpvar_loop = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_3_tmpvar_loop = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_4_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_67_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_70_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_131_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_133_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_141_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_142_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_145_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_146_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_147_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_149_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_150_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_151_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_152_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_153_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_154_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_155_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_156_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_157_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_158_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_160_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_161_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_162_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_163_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_169_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_172_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_174_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_176_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_177_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_180_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_182_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_184_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_185_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_186_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_187_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_188_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_189_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_190_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_191_tmpvar_phold = null;
bevp_preClass = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classEmits = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_propertyDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_cnode = beva_node;
bevt_10_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_csyn = (BEC_2_5_8_BuildClassSyn) bevt_10_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevp_dynMethods = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_ccMethods = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_superCalls = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_nativeCSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_12_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_153));
bevp_inFilePathed = (BEC_2_4_6_TextString) bevt_11_tmpvar_phold.bemd_1(450717861, BEL_4_Base.bevn_toStringWithSeparator_1, bevt_13_tmpvar_phold);
bevt_15_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_te = bevt_14_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
if (bevl_te == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 785 */ {
bevl_te = bevl_te.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 786 */ {
bevt_17_tmpvar_phold = bevl_te.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 786 */ {
bevl_jn = bevl_te.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_20_tmpvar_phold = bevl_jn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_21_tmpvar_phold = this.bem_emitLangGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_21_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 788 */ {
bevt_24_tmpvar_phold = bevl_jn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevt_22_tmpvar_phold = this.bem_emitReplace_1((BEC_2_4_6_TextString) bevt_23_tmpvar_phold);
bevp_preClass.bem_addValue_1(bevt_22_tmpvar_phold);
} /* Line: 789 */
} /* Line: 788 */
 else  /* Line: 786 */ {
break;
} /* Line: 786 */
} /* Line: 786 */
} /* Line: 786 */
bevt_27_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_26_tmpvar_phold == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 794 */ {
bevt_29_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevp_parentConf = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_28_tmpvar_phold);
bevt_31_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = bevp_build.bem_getSynNp_1(bevt_30_tmpvar_phold);
} /* Line: 796 */
 else  /* Line: 797 */ {
bevp_parentConf = null;
} /* Line: 798 */
bevt_34_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
if (bevt_33_tmpvar_phold == null) {
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 802 */ {
bevl_inlang = this.bem_emitLangGet_0();
bevt_36_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevt_0_tmpvar_loop = bevt_35_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 804 */ {
bevt_37_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 804 */ {
bevl_innode = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_39_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_nativeCSlots = this.bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevt_38_tmpvar_phold);
bevt_42_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_inlang);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 807 */ {
bevt_45_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevt_43_tmpvar_phold = this.bem_emitReplace_1((BEC_2_4_6_TextString) bevt_44_tmpvar_phold);
bevp_classEmits.bem_addValue_1(bevt_43_tmpvar_phold);
} /* Line: 808 */
} /* Line: 807 */
 else  /* Line: 804 */ {
break;
} /* Line: 804 */
} /* Line: 804 */
} /* Line: 804 */
if (bevl_psyn == null) {
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 813 */ {
bevt_48_tmpvar_phold = bevo_35;
bevt_47_tmpvar_phold = bevp_nativeCSlots.bem_greater_1(bevt_48_tmpvar_phold);
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 813 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 813 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 813 */
 else  /* Line: 813 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 813 */ {
bevt_50_tmpvar_phold = bevl_psyn.bem_ptyListGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_sizeGet_0();
bevp_nativeCSlots = bevp_nativeCSlots.bem_subtract_1(bevt_49_tmpvar_phold);
bevt_52_tmpvar_phold = bevo_36;
bevt_51_tmpvar_phold = bevp_nativeCSlots.bem_lesser_1(bevt_52_tmpvar_phold);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 815 */ {
bevp_nativeCSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 816 */
} /* Line: 815 */
bevl_ovcount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_54_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_ii = bevt_53_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 823 */ {
bevt_55_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_55_tmpvar_phold != null && bevt_55_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_55_tmpvar_phold).bevi_bool) /* Line: 823 */ {
bevt_56_tmpvar_phold = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i = bevt_56_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_57_tmpvar_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_57_tmpvar_phold != null && bevt_57_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_57_tmpvar_phold).bevi_bool) /* Line: 825 */ {
bevt_58_tmpvar_phold = bevl_ovcount.bem_greaterEquals_1(bevp_nativeCSlots);
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 826 */ {
bevt_59_tmpvar_phold = this.bem_propDecGet_0();
bevp_propertyDecs.bem_addValue_1(bevt_59_tmpvar_phold);
this.bem_decForVar_2(bevp_propertyDecs, (BEC_2_5_3_BuildVar) bevl_i);
bevt_61_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_154));
bevt_60_tmpvar_phold = (BEC_2_4_6_TextString) bevp_propertyDecs.bem_addValue_1(bevt_61_tmpvar_phold);
bevt_60_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 829 */
bevl_ovcount = bevl_ovcount.bem_increment_0();
} /* Line: 831 */
} /* Line: 825 */
 else  /* Line: 823 */ {
break;
} /* Line: 823 */
} /* Line: 823 */
bevl_dynGen = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mq = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_62_tmpvar_phold = bevp_csyn.bem_mtdListGet_0();
bevt_1_tmpvar_loop = bevt_62_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 838 */ {
bevt_63_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 838 */ {
bevl_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_65_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevt_64_tmpvar_phold = bevl_mq.bem_has_1(bevt_65_tmpvar_phold);
if (!(bevt_64_tmpvar_phold.bevi_bool)) /* Line: 839 */ {
bevt_66_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_mq.bem_put_1(bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = bevp_csyn.bem_mtdMapGet_0();
bevt_68_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_67_tmpvar_phold.bem_get_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = bevl_msyn.bem_originGet_0();
bevt_69_tmpvar_phold = this.bem_isClose_1(bevt_70_tmpvar_phold);
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 842 */ {
bevl_numargs = bevl_msyn.bem_numargsGet_0();
bevt_71_tmpvar_phold = bevl_numargs.bem_greater_1(bevp_maxDynArgs);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 844 */ {
bevl_numargs = bevp_maxDynArgs;
} /* Line: 845 */
bevl_dgm = (BEC_2_9_3_ContainerMap) bevl_dynGen.bem_get_1(bevl_numargs);
if (bevl_dgm == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 848 */ {
bevl_dgm = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_dynGen.bem_put_2(bevl_numargs, bevl_dgm);
} /* Line: 850 */
bevt_73_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_msh = bevt_73_tmpvar_phold.bem_hashGet_0();
bevl_dgv = (BEC_2_9_5_ContainerArray) bevl_dgm.bem_get_1(bevl_msh);
if (bevl_dgv == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 854 */ {
bevl_dgv = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_dgm.bem_put_2(bevl_msh, bevl_dgv);
} /* Line: 856 */
bevl_dgv.bem_addValue_1(bevl_msyn);
} /* Line: 858 */
} /* Line: 842 */
} /* Line: 839 */
 else  /* Line: 838 */ {
break;
} /* Line: 838 */
} /* Line: 838 */
bevt_2_tmpvar_loop = bevl_dynGen.bem_mapIteratorGet_0();
while (true)
 /* Line: 864 */ {
bevt_75_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_75_tmpvar_phold.bevi_bool) /* Line: 864 */ {
bevl_dnode = (BEC_3_9_3_7_ContainerMapMapNode) bevt_2_tmpvar_loop.bem_nextGet_0();
bevl_dnumargs = (BEC_2_4_3_MathInt) bevl_dnode.bem_keyGet_0();
bevt_76_tmpvar_phold = bevl_dnumargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 867 */ {
bevt_77_tmpvar_phold = bevo_37;
bevt_78_tmpvar_phold = bevl_dnumargs.bem_toString_0();
bevl_dmname = bevt_77_tmpvar_phold.bem_add_1(bevt_78_tmpvar_phold);
} /* Line: 868 */
 else  /* Line: 869 */ {
bevl_dmname = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_156));
} /* Line: 870 */
bevl_superArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_157));
bevl_args = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bels_158));
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 875 */ {
bevt_81_tmpvar_phold = bevo_38;
bevt_80_tmpvar_phold = bevl_dnumargs.bem_add_1(bevt_81_tmpvar_phold);
bevt_79_tmpvar_phold = bevl_j.bem_lesser_1(bevt_80_tmpvar_phold);
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 875 */ {
bevt_82_tmpvar_phold = bevl_j.bem_lesser_1(bevp_maxDynArgs);
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 875 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 875 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 875 */
 else  /* Line: 875 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 875 */ {
bevt_86_tmpvar_phold = bevo_39;
bevt_85_tmpvar_phold = bevl_args.bem_add_1(bevt_86_tmpvar_phold);
bevt_88_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_87_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_88_tmpvar_phold);
bevt_84_tmpvar_phold = bevt_85_tmpvar_phold.bem_add_1(bevt_87_tmpvar_phold);
bevt_89_tmpvar_phold = bevo_40;
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_add_1(bevt_89_tmpvar_phold);
bevt_91_tmpvar_phold = bevo_41;
bevt_90_tmpvar_phold = bevl_j.bem_subtract_1(bevt_91_tmpvar_phold);
bevl_args = bevt_83_tmpvar_phold.bem_add_1(bevt_90_tmpvar_phold);
bevt_94_tmpvar_phold = bevo_42;
bevt_93_tmpvar_phold = bevl_superArgs.bem_add_1(bevt_94_tmpvar_phold);
bevt_95_tmpvar_phold = bevo_43;
bevt_92_tmpvar_phold = bevt_93_tmpvar_phold.bem_add_1(bevt_95_tmpvar_phold);
bevt_97_tmpvar_phold = bevo_44;
bevt_96_tmpvar_phold = bevl_j.bem_subtract_1(bevt_97_tmpvar_phold);
bevl_superArgs = bevt_92_tmpvar_phold.bem_add_1(bevt_96_tmpvar_phold);
bevl_j = bevl_j.bem_increment_0();
} /* Line: 878 */
 else  /* Line: 875 */ {
break;
} /* Line: 875 */
} /* Line: 875 */
bevt_98_tmpvar_phold = bevl_dnumargs.bem_greaterEquals_1(bevp_maxDynArgs);
if (bevt_98_tmpvar_phold.bevi_bool) /* Line: 880 */ {
bevt_101_tmpvar_phold = bevo_45;
bevt_100_tmpvar_phold = bevl_args.bem_add_1(bevt_101_tmpvar_phold);
bevt_103_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_102_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_103_tmpvar_phold);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bem_add_1(bevt_102_tmpvar_phold);
bevt_104_tmpvar_phold = bevo_46;
bevl_args = bevt_99_tmpvar_phold.bem_add_1(bevt_104_tmpvar_phold);
bevt_105_tmpvar_phold = bevo_47;
bevl_superArgs = bevl_superArgs.bem_add_1(bevt_105_tmpvar_phold);
} /* Line: 882 */
bevt_115_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_114_tmpvar_phold = (BEC_2_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_115_tmpvar_phold);
bevt_117_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_116_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_117_tmpvar_phold);
bevt_113_tmpvar_phold = (BEC_2_4_6_TextString) bevt_114_tmpvar_phold.bem_addValue_1(bevt_116_tmpvar_phold);
bevt_118_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_166));
bevt_112_tmpvar_phold = (BEC_2_4_6_TextString) bevt_113_tmpvar_phold.bem_addValue_1(bevt_118_tmpvar_phold);
bevt_111_tmpvar_phold = (BEC_2_4_6_TextString) bevt_112_tmpvar_phold.bem_addValue_1(bevl_dmname);
bevt_119_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_167));
bevt_110_tmpvar_phold = (BEC_2_4_6_TextString) bevt_111_tmpvar_phold.bem_addValue_1(bevt_119_tmpvar_phold);
bevt_109_tmpvar_phold = (BEC_2_4_6_TextString) bevt_110_tmpvar_phold.bem_addValue_1(bevl_args);
bevt_120_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_168));
bevt_108_tmpvar_phold = (BEC_2_4_6_TextString) bevt_109_tmpvar_phold.bem_addValue_1(bevt_120_tmpvar_phold);
bevt_107_tmpvar_phold = (BEC_2_4_6_TextString) bevt_108_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_121_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_169));
bevt_106_tmpvar_phold = (BEC_2_4_6_TextString) bevt_107_tmpvar_phold.bem_addValue_1(bevt_121_tmpvar_phold);
bevt_106_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_123_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bels_170));
bevt_122_tmpvar_phold = (BEC_2_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_123_tmpvar_phold);
bevt_122_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_dgm = (BEC_2_9_3_ContainerMap) bevl_dnode.bem_valueGet_0();
bevt_3_tmpvar_loop = bevl_dgm.bem_mapIteratorGet_0();
while (true)
 /* Line: 888 */ {
bevt_124_tmpvar_phold = bevt_3_tmpvar_loop.bem_hasNextGet_0();
if (bevt_124_tmpvar_phold.bevi_bool) /* Line: 888 */ {
bevl_msnode = (BEC_3_9_3_7_ContainerMapMapNode) bevt_3_tmpvar_loop.bem_nextGet_0();
bevl_thisHash = (BEC_2_4_3_MathInt) bevl_msnode.bem_keyGet_0();
bevl_dgv = (BEC_2_9_5_ContainerArray) bevl_msnode.bem_valueGet_0();
bevt_127_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_171));
bevt_126_tmpvar_phold = (BEC_2_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_127_tmpvar_phold);
bevt_128_tmpvar_phold = bevl_thisHash.bem_toString_0();
bevt_125_tmpvar_phold = (BEC_2_4_6_TextString) bevt_126_tmpvar_phold.bem_addValue_1(bevt_128_tmpvar_phold);
bevt_129_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_172));
bevt_125_tmpvar_phold.bem_addValue_1(bevt_129_tmpvar_phold);
if (bevp_dynConditionsAll.bevi_bool) /* Line: 895 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 895 */ {
bevt_131_tmpvar_phold = bevl_dgv.bem_sizeGet_0();
bevt_132_tmpvar_phold = bevo_48;
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bem_greater_1(bevt_132_tmpvar_phold);
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 895 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 895 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 895 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 895 */ {
bevl_dynConditions = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 896 */
 else  /* Line: 897 */ {
bevl_dynConditions = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 898 */
bevt_4_tmpvar_loop = bevl_dgv.bem_arrayIteratorGet_0();
while (true)
 /* Line: 900 */ {
bevt_133_tmpvar_phold = bevt_4_tmpvar_loop.bem_hasNextGet_0();
if (bevt_133_tmpvar_phold.bevi_bool) /* Line: 900 */ {
bevl_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_4_tmpvar_loop.bem_nextGet_0();
bevl_mcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_dynConditions.bevi_bool) /* Line: 902 */ {
bevt_135_tmpvar_phold = bevo_49;
bevt_134_tmpvar_phold = bevp_libEmitName.bem_add_1(bevt_135_tmpvar_phold);
bevt_136_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_constName = bevt_134_tmpvar_phold.bem_add_1(bevt_136_tmpvar_phold);
bevt_140_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_174));
bevt_139_tmpvar_phold = (BEC_2_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_140_tmpvar_phold);
bevt_138_tmpvar_phold = (BEC_2_4_6_TextString) bevt_139_tmpvar_phold.bem_addValue_1(bevl_constName);
bevt_141_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_175));
bevt_137_tmpvar_phold = (BEC_2_4_6_TextString) bevt_138_tmpvar_phold.bem_addValue_1(bevt_141_tmpvar_phold);
bevt_137_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 904 */
bevt_144_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_176));
bevt_143_tmpvar_phold = (BEC_2_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_144_tmpvar_phold);
bevt_145_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevt_142_tmpvar_phold = (BEC_2_4_6_TextString) bevt_143_tmpvar_phold.bem_addValue_1(bevt_145_tmpvar_phold);
bevt_146_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_177));
bevt_142_tmpvar_phold.bem_addValue_1(bevt_146_tmpvar_phold);
bevl_vnumargs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_147_tmpvar_phold = bevl_msyn.bem_argSynsGet_0();
bevt_5_tmpvar_loop = bevt_147_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 908 */ {
bevt_148_tmpvar_phold = bevt_5_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_148_tmpvar_phold != null && bevt_148_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_148_tmpvar_phold).bevi_bool) /* Line: 908 */ {
bevl_vsyn = (BEC_2_5_6_BuildVarSyn) bevt_5_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_150_tmpvar_phold = bevo_50;
bevt_149_tmpvar_phold = bevl_vnumargs.bem_greater_1(bevt_150_tmpvar_phold);
if (bevt_149_tmpvar_phold.bevi_bool) /* Line: 909 */ {
bevt_151_tmpvar_phold = bevl_vsyn.bem_isTypedGet_0();
if (bevt_151_tmpvar_phold.bevi_bool) /* Line: 910 */ {
bevt_153_tmpvar_phold = bevl_vsyn.bem_namepathGet_0();
bevt_152_tmpvar_phold = bevt_153_tmpvar_phold.bem_notEquals_1(bevp_objectNp);
if (bevt_152_tmpvar_phold.bevi_bool) /* Line: 910 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 910 */
 else  /* Line: 910 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 910 */ {
bevt_156_tmpvar_phold = bevl_vsyn.bem_namepathGet_0();
bevt_155_tmpvar_phold = this.bem_getClassConfig_1(bevt_156_tmpvar_phold);
bevt_154_tmpvar_phold = this.bem_formCast_1(bevt_155_tmpvar_phold);
bevt_157_tmpvar_phold = bevo_51;
bevl_vcast = bevt_154_tmpvar_phold.bem_add_1(bevt_157_tmpvar_phold);
} /* Line: 911 */
 else  /* Line: 912 */ {
bevl_vcast = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_179));
} /* Line: 913 */
bevt_159_tmpvar_phold = bevo_52;
bevt_158_tmpvar_phold = bevl_vnumargs.bem_greater_1(bevt_159_tmpvar_phold);
if (bevt_158_tmpvar_phold.bevi_bool) /* Line: 915 */ {
bevl_vcma = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_180));
} /* Line: 916 */
 else  /* Line: 917 */ {
bevl_vcma = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_181));
} /* Line: 918 */
bevt_160_tmpvar_phold = bevl_vnumargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_160_tmpvar_phold.bevi_bool) /* Line: 920 */ {
bevt_161_tmpvar_phold = bevo_53;
bevt_163_tmpvar_phold = bevo_54;
bevt_162_tmpvar_phold = bevl_vnumargs.bem_subtract_1(bevt_163_tmpvar_phold);
bevl_varg = bevt_161_tmpvar_phold.bem_add_1(bevt_162_tmpvar_phold);
} /* Line: 921 */
 else  /* Line: 922 */ {
bevt_165_tmpvar_phold = bevo_55;
bevt_166_tmpvar_phold = bevl_vnumargs.bem_subtract_1(bevp_maxDynArgs);
bevt_164_tmpvar_phold = bevt_165_tmpvar_phold.bem_add_1(bevt_166_tmpvar_phold);
bevt_167_tmpvar_phold = bevo_56;
bevl_varg = bevt_164_tmpvar_phold.bem_add_1(bevt_167_tmpvar_phold);
} /* Line: 923 */
bevt_169_tmpvar_phold = (BEC_2_4_6_TextString) bevl_mcall.bem_addValue_1(bevl_vcma);
bevt_168_tmpvar_phold = (BEC_2_4_6_TextString) bevt_169_tmpvar_phold.bem_addValue_1(bevl_vcast);
bevt_168_tmpvar_phold.bem_addValue_1(bevl_varg);
} /* Line: 925 */
bevl_vnumargs = bevl_vnumargs.bem_increment_0();
} /* Line: 927 */
 else  /* Line: 908 */ {
break;
} /* Line: 908 */
} /* Line: 908 */
bevt_171_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_185));
bevt_170_tmpvar_phold = (BEC_2_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_170_tmpvar_phold.bem_addValue_1(bevp_nl);
if (bevl_dynConditions.bevi_bool) /* Line: 930 */ {
bevt_173_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_186));
bevt_172_tmpvar_phold = (BEC_2_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_173_tmpvar_phold);
bevt_172_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 932 */
bevp_dynMethods.bem_addValue_1(bevl_mcall);
} /* Line: 935 */
 else  /* Line: 900 */ {
break;
} /* Line: 900 */
} /* Line: 900 */
if (bevl_dynConditions.bevi_bool) /* Line: 937 */ {
bevt_175_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_187));
bevt_174_tmpvar_phold = (BEC_2_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_175_tmpvar_phold);
bevt_174_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 938 */
} /* Line: 937 */
 else  /* Line: 888 */ {
break;
} /* Line: 888 */
} /* Line: 888 */
bevt_177_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_188));
bevt_176_tmpvar_phold = (BEC_2_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_177_tmpvar_phold);
bevt_176_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_185_tmpvar_phold = bevo_57;
bevt_186_tmpvar_phold = this.bem_superNameGet_0();
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_add_1(bevt_186_tmpvar_phold);
bevt_187_tmpvar_phold = bevo_58;
bevt_183_tmpvar_phold = bevt_184_tmpvar_phold.bem_add_1(bevt_187_tmpvar_phold);
bevt_182_tmpvar_phold = (BEC_2_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_183_tmpvar_phold);
bevt_181_tmpvar_phold = (BEC_2_4_6_TextString) bevt_182_tmpvar_phold.bem_addValue_1(bevl_dmname);
bevt_188_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_191));
bevt_180_tmpvar_phold = (BEC_2_4_6_TextString) bevt_181_tmpvar_phold.bem_addValue_1(bevt_188_tmpvar_phold);
bevt_179_tmpvar_phold = (BEC_2_4_6_TextString) bevt_180_tmpvar_phold.bem_addValue_1(bevl_superArgs);
bevt_189_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_192));
bevt_178_tmpvar_phold = (BEC_2_4_6_TextString) bevt_179_tmpvar_phold.bem_addValue_1(bevt_189_tmpvar_phold);
bevt_178_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_191_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_193));
bevt_190_tmpvar_phold = (BEC_2_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_191_tmpvar_phold);
bevt_190_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 943 */
 else  /* Line: 864 */ {
break;
} /* Line: 864 */
} /* Line: 864 */
this.bem_buildClassInfo_0();
this.bem_buildCreate_0();
this.bem_buildInitial_0();
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_getNativeCSlots_1(BEC_2_4_6_TextString beva_text) {
BEC_2_4_3_MathInt bevl_nativeSlots = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_isfn = null;
BEC_2_6_6_SystemObject bevl_nextIsNativeSlots = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
bevl_nativeSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_194));
bevl_ll = beva_text.bem_split_1(bevt_1_tmpvar_phold);
bevl_isfn = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_loop = bevl_ll.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 962 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 962 */ {
bevl_i = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_nextIsNativeSlots != null && bevl_nextIsNativeSlots is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_nextIsNativeSlots).bevi_bool) /* Line: 963 */ {
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nativeSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_i);
bevl_isfn = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 966 */
 else  /* Line: 963 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bels_195));
bevt_3_tmpvar_phold = bevl_i.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 967 */ {
bevl_isfn = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nativeSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 969 */
 else  /* Line: 963 */ {
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bels_196));
bevt_5_tmpvar_phold = bevl_i.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 970 */ {
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 971 */
} /* Line: 963 */
} /* Line: 963 */
} /* Line: 963 */
 else  /* Line: 962 */ {
break;
} /* Line: 962 */
} /* Line: 962 */
bevt_8_tmpvar_phold = bevo_59;
bevt_7_tmpvar_phold = bevl_nativeSlots.bem_greater_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 974 */ {
} /* Line: 974 */
return bevl_nativeSlots;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
bevt_5_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_8_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_relEmitName_1(bevt_8_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_197));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_198));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_199));
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_16_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_relEmitName_1(bevt_19_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) bevt_13_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_200));
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_11_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_201));
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_21_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_vcast = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_oname = (BEC_2_4_6_TextString) bevt_0_tmpvar_phold.bem_relEmitName_1(bevt_1_tmpvar_phold);
bevl_mname = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_2_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_10_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_202));
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevl_oname);
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_203));
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_204));
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpvar_phold = bevl_mname.bem_notEquals_1(bevl_oname);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 995 */ {
bevl_vcast = this.bem_formCast_1(bevp_classConf);
} /* Line: 996 */
 else  /* Line: 997 */ {
bevl_vcast = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_205));
} /* Line: 998 */
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_206));
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) bevt_18_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) bevt_17_tmpvar_phold.bem_addValue_1(bevl_vcast);
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_207));
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_208));
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_21_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevl_oname);
bevt_29_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_209));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_210));
bevt_23_tmpvar_phold = (BEC_2_4_6_TextString) bevt_24_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_211));
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_2_4_6_TextString) bevt_33_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_35_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_212));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_213));
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_tmpvar_phold);
bevt_36_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_buildClassInfo_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_214));
bevt_3_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
this.bem_buildClassInfo_2(bevt_0_tmpvar_phold, (BEC_2_4_6_TextString) bevt_1_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_215));
this.bem_buildClassInfo_2(bevt_4_tmpvar_phold, bevp_inFilePathed);
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_buildClassInfo_2(BEC_2_4_6_TextString beva_belsBase, BEC_2_4_6_TextString beva_lival) {
BEC_2_4_6_TextString bevl_belsName = null;
BEC_2_4_6_TextString bevl_sdec = null;
BEC_2_4_3_MathInt bevl_lisz = null;
BEC_2_4_3_MathInt bevl_lipos = null;
BEC_2_4_3_MathInt bevl_bcode = null;
BEC_2_4_6_TextString bevl_hs = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_60;
bevl_belsName = bevt_0_tmpvar_phold.bem_add_1(beva_belsBase);
bevl_sdec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
this.bem_lstringStart_2(bevl_sdec, bevl_belsName);
bevl_lisz = beva_lival.bem_sizeGet_0();
bevl_lipos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_bcode = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_hs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
while (true)
 /* Line: 1030 */ {
bevt_2_tmpvar_phold = bevl_lipos.bem_lesser_1(bevl_lisz);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1030 */ {
bevt_4_tmpvar_phold = bevo_61;
bevt_3_tmpvar_phold = bevl_lipos.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1031 */ {
bevt_6_tmpvar_phold = bevo_62;
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) bevt_6_tmpvar_phold.bem_once_0();
bevl_sdec.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1032 */
this.bem_lstringByte_5(bevl_sdec, beva_lival, bevl_lipos, bevl_bcode, bevl_hs);
bevl_lipos.bem_incrementValue_0();
} /* Line: 1035 */
 else  /* Line: 1030 */ {
break;
} /* Line: 1030 */
} /* Line: 1030 */
this.bem_lstringEnd_1(bevl_sdec);
bevp_onceDecs.bem_addValue_1(bevl_sdec);
this.bem_buildClassInfoMethod_1(beva_belsBase);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_2_4_6_TextString beva_belsBase) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_6_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_218));
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(beva_belsBase);
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_219));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_220));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_221));
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(beva_belsBase);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_222));
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_10_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_223));
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1056 */ {
bevt_5_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_224));
bevt_4_tmpvar_phold = this.bem_baseSpropDec_2(bevt_5_tmpvar_phold, bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_225));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1057 */
 else  /* Line: 1058 */ {
bevt_11_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_226));
bevt_10_tmpvar_phold = this.bem_overrideSpropDec_2(bevt_11_tmpvar_phold, bevt_12_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_227));
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1059 */
return bevl_initialDec;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_classBeginGet_0() {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_clb = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1066 */ {
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevl_extends = this.bem_extend_1((BEC_2_4_6_TextString) bevt_1_tmpvar_phold);
} /* Line: 1067 */
 else  /* Line: 1068 */ {
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bels_228));
bevl_extends = this.bem_extend_1(bevt_3_tmpvar_phold);
} /* Line: 1069 */
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_229));
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_inFilePathed);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_230));
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevl_clb = (BEC_2_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_12_tmpvar_phold = this.bem_klassDecGet_0();
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevl_extends);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_231));
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_232));
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_233));
bevt_15_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_234));
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_235));
bevt_22_tmpvar_phold = this.bem_emitting_1(bevt_23_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 1075 */ {
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_236));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_237));
bevt_24_tmpvar_phold.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_238));
bevt_29_tmpvar_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_29_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1077 */
return bevl_clb;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_239));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_63;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_typeName);
bevt_4_tmpvar_phold = bevo_64;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_varName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_242));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_243));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getTraceInfo_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_trInfo = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_trInfo = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
if (beva_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1102 */ {
bevt_3_tmpvar_phold = beva_node.bem_nlcGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1102 */
 else  /* Line: 1102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1102 */ {
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_244));
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevl_trInfo.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = beva_node.bem_nlcGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_toString_0();
bevt_4_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
} /* Line: 1103 */
return bevl_trInfo;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptBraces_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_3_MathInt bevl_typename = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 1109 */ {
bevt_6_tmpvar_phold = beva_node.bem_containerGet_0();
bevl_typename = bevt_6_tmpvar_phold.bem_typenameGet_0();
bevt_8_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
bevt_10_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_9_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1111 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1111 */
 else  /* Line: 1111 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1111 */ {
bevt_12_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_11_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1111 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1111 */
 else  /* Line: 1111 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1111 */ {
bevt_14_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_13_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1111 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1111 */
 else  /* Line: 1111 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1111 */ {
bevt_16_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_15_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1111 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1111 */
 else  /* Line: 1111 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1111 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_245));
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = this.bem_getTraceInfo_1(beva_node);
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) bevt_19_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_246));
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) bevt_18_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_17_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1113 */
} /* Line: 1111 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptRbraces_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_nct = null;
BEC_2_6_6_SystemObject bevl_typename = null;
BEC_2_4_3_MathInt bevl_methodsOffset = null;
BEC_2_5_4_BuildNode bevl_mc = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_8_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_9_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 1122 */ {
bevt_9_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_containerGet_0();
if (bevt_8_tmpvar_phold == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1122 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1122 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1122 */
 else  /* Line: 1122 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1122 */ {
bevt_10_tmpvar_phold = beva_node.bem_containerGet_0();
bevl_nct = bevt_10_tmpvar_phold.bem_containerGet_0();
bevl_typename = bevl_nct.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_11_tmpvar_phold = bevl_typename.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 1125 */ {
if (bevp_mnode == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 1126 */ {
if (bevp_lastCall == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 1127 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1127 */ {
bevt_17_tmpvar_phold = bevp_lastCall.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_247));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_18_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 1127 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1127 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1127 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1127 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_248));
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_19_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1130 */
bevt_22_tmpvar_phold = bevo_65;
bevt_21_tmpvar_phold = bevp_maxSpillArgsLen.bem_greater_1(bevt_22_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 1133 */ {
bevt_30_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_29_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_30_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_249));
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) bevt_28_tmpvar_phold.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_33_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_32_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_33_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_250));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = bevp_maxSpillArgsLen.bem_toString_0();
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_251));
bevt_23_tmpvar_phold = (BEC_2_4_6_TextString) bevt_24_tmpvar_phold.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1134 */
bevl_methodsOffset = this.bem_countLines_2(bevp_methods, bevp_lastMethodsSize);
bevl_methodsOffset.bem_addValue_1(bevp_lastMethodsLines);
bevp_lastMethodsLines = bevl_methodsOffset;
bevp_lastMethodsSize = bevp_methods.bem_sizeGet_0();
bevt_0_tmpvar_loop = bevp_methodCalls.bem_arrayIteratorGet_0();
while (true)
 /* Line: 1144 */ {
bevt_37_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 1144 */ {
bevl_mc = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_38_tmpvar_phold = bevl_mc.bem_nlecGet_0();
bevt_38_tmpvar_phold.bem_addValue_1(bevl_methodsOffset);
} /* Line: 1145 */
 else  /* Line: 1144 */ {
break;
} /* Line: 1144 */
} /* Line: 1144 */
bevp_classCalls.bem_addValue_1(bevp_methodCalls);
bevt_39_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_methodCalls.bem_lengthSet_1(bevt_39_tmpvar_phold);
bevp_methods.bem_addValue_1(bevp_methodBody);
bevp_methodBody.bem_clear_0();
bevp_lastMethodBodySize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_lastMethodBodyLines = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_methodCatch = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_lastCall = null;
bevp_maxSpillArgsLen = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_41_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_252));
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_40_tmpvar_phold.bem_addValue_1(bevp_nl);
bevp_msyn = null;
bevp_mnode = null;
} /* Line: 1163 */
} /* Line: 1126 */
 else  /* Line: 1125 */ {
bevt_43_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_42_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_43_tmpvar_phold);
if (bevt_42_tmpvar_phold != null && bevt_42_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_42_tmpvar_phold).bevi_bool) /* Line: 1165 */ {
bevt_45_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_44_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold != null && bevt_44_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_44_tmpvar_phold).bevi_bool) /* Line: 1165 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1165 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1165 */
 else  /* Line: 1165 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 1165 */ {
bevt_47_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_46_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 1165 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1165 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1165 */
 else  /* Line: 1165 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1165 */ {
bevt_51_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_253));
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = this.bem_getTraceInfo_1(beva_node);
bevt_49_tmpvar_phold = (BEC_2_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_254));
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_48_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1167 */
} /* Line: 1125 */
} /* Line: 1125 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_countLines_1(BEC_2_4_6_TextString beva_text) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = this.bem_countLines_2(beva_text, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_countLines_2(BEC_2_4_6_TextString beva_text, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_4_3_MathInt bevl_nlval = null;
BEC_2_4_3_MathInt bevl_cursor = null;
BEC_2_4_3_MathInt bevl_slen = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_found = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_nlval = bevp_nl.bem_getInt_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevl_cursor = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_slen = beva_text.bem_sizeGet_0();
bevl_i = beva_start;
while (true)
 /* Line: 1181 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(bevl_slen);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1181 */ {
beva_text.bem_getInt_2(bevl_i, bevl_cursor);
bevt_3_tmpvar_phold = bevl_cursor.bem_equals_1(bevl_nlval);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1183 */ {
bevl_found.bem_incrementValue_0();
} /* Line: 1184 */
bevl_i.bem_incrementValue_0();
} /* Line: 1181 */
 else  /* Line: 1181 */ {
break;
} /* Line: 1181 */
} /* Line: 1181 */
return bevl_found;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptIf_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_targs = null;
BEC_2_5_4_LogicBool bevl_isBool = null;
BEC_2_5_4_LogicBool bevl_isUnless = null;
BEC_2_4_6_TextString bevl_ev = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_firstGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_targs = this.bem_formTarg_1((BEC_2_5_4_BuildNode) bevt_2_tmpvar_phold);
bevt_12_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_firstGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 1192 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1192 */ {
bevt_19_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_firstGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevp_boolNp);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 1192 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1192 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1192 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1192 */ {
bevl_isBool = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1193 */
 else  /* Line: 1194 */ {
bevl_isBool = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1195 */
bevt_21_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 1197 */ {
bevt_23_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_255));
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_24_tmpvar_phold);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 1197 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1197 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1197 */
 else  /* Line: 1197 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1197 */ {
bevl_isUnless = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1198 */
 else  /* Line: 1199 */ {
bevl_isUnless = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1200 */
bevl_ev = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_256));
if (bevl_isUnless.bevi_bool) /* Line: 1203 */ {
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_257));
bevl_ev.bem_addValue_1(bevt_25_tmpvar_phold);
} /* Line: 1204 */
if (bevl_isBool.bevi_bool) /* Line: 1206 */ {
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) bevl_ev.bem_addValue_1(bevl_targs);
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_258));
bevt_26_tmpvar_phold.bem_addValue_1(bevt_27_tmpvar_phold);
} /* Line: 1208 */
 else  /* Line: 1209 */ {
bevt_32_tmpvar_phold = (BEC_2_4_6_TextString) bevl_ev.bem_addValue_1(bevl_targs);
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_259));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) bevt_31_tmpvar_phold.bem_addValue_1(bevl_targs);
bevt_29_tmpvar_phold = (BEC_2_4_6_TextString) bevt_30_tmpvar_phold.bem_addValue_1(bevp_instOf);
bevt_35_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_34_tmpvar_phold = bevp_boolCc.bem_relEmitName_1(bevt_35_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_2_4_6_TextString) bevt_29_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_260));
bevt_28_tmpvar_phold.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_261));
bevt_38_tmpvar_phold = this.bem_emitting_1(bevt_39_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_not_0();
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 1214 */ {
bevt_41_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_262));
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) bevl_ev.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = this.bem_formCast_1(bevp_boolCc);
bevt_40_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
} /* Line: 1215 */
bevl_ev.bem_addValue_1(bevl_targs);
bevt_45_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_263));
bevt_44_tmpvar_phold = this.bem_emitting_1(bevt_45_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_not_0();
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 1218 */ {
bevt_46_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_264));
bevl_ev.bem_addValue_1(bevt_46_tmpvar_phold);
} /* Line: 1219 */
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_265));
bevl_ev.bem_addValue_1(bevt_47_tmpvar_phold);
} /* Line: 1221 */
if (bevl_isUnless.bevi_bool) /* Line: 1223 */ {
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_266));
bevl_ev.bem_addValue_1(bevt_48_tmpvar_phold);
} /* Line: 1224 */
bevt_51_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_267));
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_2_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevl_ev);
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_268));
bevt_49_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_oldacceptIf_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_targs = null;
BEC_2_4_6_TextString bevl_cexpr = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_4_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_firstGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_targs = this.bem_formTarg_1((BEC_2_5_4_BuildNode) bevt_1_tmpvar_phold);
bevt_6_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 1232 */ {
bevt_8_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_269));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1232 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1232 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1232 */
 else  /* Line: 1232 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1232 */ {
bevl_cexpr = bevp_instanceNotEqual;
} /* Line: 1233 */
 else  /* Line: 1234 */ {
bevl_cexpr = bevp_instanceEqual;
} /* Line: 1235 */
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_270));
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) bevt_13_tmpvar_phold.bem_addValue_1(bevp_trueValue);
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevl_cexpr);
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevl_targs);
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_271));
bevt_10_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_finalAssign_3(BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_sFrom, BEC_2_5_8_BuildNamePath beva_castTo) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = this.bem_finalAssignTo_2(beva_node, beva_castTo);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_sFrom);
bevt_4_tmpvar_phold = bevo_66;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_finalAssignTo_2(BEC_2_5_4_BuildNode beva_node, BEC_2_5_8_BuildNamePath beva_castTo) {
BEC_2_4_6_TextString bevl_cast = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1249 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bels_273));
bevt_3_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 1250 */
bevt_7_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_274));
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 1252 */ {
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_275));
bevt_9_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_10_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_9_tmpvar_phold);
} /* Line: 1253 */
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_276));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 1255 */ {
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bels_277));
bevt_15_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_16_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_15_tmpvar_phold);
} /* Line: 1256 */
bevl_cast = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_278));
if (beva_castTo == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 1259 */ {
bevt_19_tmpvar_phold = this.bem_getClassConfig_1(beva_castTo);
bevt_18_tmpvar_phold = this.bem_formCast_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_67;
bevl_cast = bevt_18_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
} /* Line: 1260 */
bevt_24_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_23_tmpvar_phold = this.bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = bevo_68;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevl_cast);
return bevt_21_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_281));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_formCast_1(BEC_2_5_11_BuildClassConfig beva_cc) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_69;
bevt_4_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpvar_phold = beva_cc.bem_relEmitName_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_70;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bels_284));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_4_tmpvar_phold = this.bem_formTarg_1(bevt_5_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_285));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_71;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_count);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptCall_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_3_MathInt bevl_moreLines = null;
BEC_2_6_6_SystemObject bevl_errmsg = null;
BEC_2_4_3_MathInt bevl_ei = null;
BEC_2_5_8_BuildNamePath bevl_castTo = null;
BEC_2_4_6_TextString bevl_nullRes = null;
BEC_2_4_6_TextString bevl_notNullRes = null;
BEC_2_4_6_TextString bevl_returnCast = null;
BEC_2_5_4_LogicBool bevl_selfCall = null;
BEC_2_5_4_LogicBool bevl_superCall = null;
BEC_2_5_4_LogicBool bevl_isConstruct = null;
BEC_2_5_4_LogicBool bevl_isTyped = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_callArgs = null;
BEC_2_4_6_TextString bevl_spillArgs = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_9_5_ContainerArray bevl_argCasts = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_target = null;
BEC_2_5_4_BuildNode bevl_targetNode = null;
BEC_2_4_3_MathInt bevl_spillArgPos = null;
BEC_2_5_4_LogicBool bevl_isOnce = null;
BEC_2_5_4_LogicBool bevl_onceDeced = null;
BEC_2_4_6_TextString bevl_ovar = null;
BEC_2_4_6_TextString bevl_odec = null;
BEC_2_4_6_TextString bevl_callAssign = null;
BEC_2_4_6_TextString bevl_postOnceCallAssign = null;
BEC_2_4_6_TextString bevl_cast = null;
BEC_2_4_6_TextString bevl_belsName = null;
BEC_2_4_6_TextString bevl_sdec = null;
BEC_2_4_6_TextString bevl_liorg = null;
BEC_2_4_6_TextString bevl_lival = null;
BEC_2_4_3_MathInt bevl_lisz = null;
BEC_2_4_3_MathInt bevl_lipos = null;
BEC_2_4_3_MathInt bevl_bcode = null;
BEC_2_4_6_TextString bevl_hs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_odinfo = null;
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_5_8_BuildClassSyn bevl_asyn = null;
BEC_2_4_6_TextString bevl_initialTarg = null;
BEC_2_5_6_BuildMtdSyn bevl_msyn = null;
BEC_2_4_6_TextString bevl_dm = null;
BEC_2_4_6_TextString bevl_callArgSpill = null;
BEC_2_4_3_MathInt bevl_spillArgsLen = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_46_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_72_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_84_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_96_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_107_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_117_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_131_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_133_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_138_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_141_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_142_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_145_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_146_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_147_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_150_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_151_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_152_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_153_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_155_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_156_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_157_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_166_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_169_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_172_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_177_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_182_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_183_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_185_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_189_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_191_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_194_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_196_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_197_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_198_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_200_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_201_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_203_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_204_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_205_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_206_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_208_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_209_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_211_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_212_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_216_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_217_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_219_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_223_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_224_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_227_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_228_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_229_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_230_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_231_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_232_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_233_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_236_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_237_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_238_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_239_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_240_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_241_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_242_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_243_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_244_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_245_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_246_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_247_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_248_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_249_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_250_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_251_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_252_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_253_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_254_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_255_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_256_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_257_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_258_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_259_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_260_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_261_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_262_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_263_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_264_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_265_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_266_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_267_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_268_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_269_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_270_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_271_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_272_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_273_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_274_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_275_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_276_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_277_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_278_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_279_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_280_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_281_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_282_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_283_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_284_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_285_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_286_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_287_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_288_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_289_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_290_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_291_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_292_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_293_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_294_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_295_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_296_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_297_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_298_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_299_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_300_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_301_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_302_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_303_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_304_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_305_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_306_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_307_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_308_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_309_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_310_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_311_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_312_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_313_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_314_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_315_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_316_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_317_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_318_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_319_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_320_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_321_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_322_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_323_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_324_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_325_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_326_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_327_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_328_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_329_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_330_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_331_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_332_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_333_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_334_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_335_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_336_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_337_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_338_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_339_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_340_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_341_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_342_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_343_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_344_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_345_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_346_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_347_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_348_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_349_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_350_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_351_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_352_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_353_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_354_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_355_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_356_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_357_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_358_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_359_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_360_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_361_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_362_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_363_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_364_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_365_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_366_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_367_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_368_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_369_tmpvar_phold = null;
BEC_2_4_12_JsonUnmarshaller bevt_370_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_371_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_372_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_373_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_374_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_375_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_376_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_377_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_378_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_379_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_380_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_381_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_382_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_383_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_384_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_385_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_386_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_387_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_388_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_389_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_390_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_391_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_392_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_393_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_394_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_395_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_396_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_397_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_398_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_399_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_400_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_401_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_402_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_403_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_404_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_405_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_406_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_407_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_408_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_409_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_410_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_411_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_412_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_413_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_414_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_415_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_416_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_417_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_418_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_419_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_420_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_421_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_422_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_423_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_424_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_425_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_426_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_427_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_428_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_429_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_430_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_431_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_432_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_433_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_434_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_435_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_436_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_437_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_438_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_439_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_440_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_441_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_442_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_443_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_444_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_445_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_446_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_447_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_448_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_449_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_450_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_451_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_452_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_453_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_454_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_455_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_456_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_457_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_458_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_459_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_460_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_461_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_462_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_463_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_464_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_465_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_466_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_467_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_468_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_469_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_470_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_471_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_472_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_473_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_474_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_475_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_476_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_477_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_478_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_479_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_480_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_481_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_482_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_483_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_484_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_485_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_486_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_487_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_488_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_489_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_490_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_491_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_492_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_493_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_494_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_495_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_496_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_497_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_498_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_499_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_500_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_501_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_502_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_503_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_504_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_505_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_506_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_507_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_508_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_509_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_510_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_511_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_512_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_513_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_514_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_515_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_516_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_517_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_518_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_519_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_520_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_521_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_522_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_523_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_524_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_525_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_526_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_527_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_528_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_529_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_530_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_531_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_532_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_533_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_534_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_535_tmpvar_phold = null;
bevt_24_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_callNames.bem_put_1(bevt_23_tmpvar_phold);
bevp_lastCall = beva_node;
bevp_methodCalls.bem_addValue_1(beva_node);
bevl_moreLines = this.bem_countLines_2(bevp_methodBody, bevp_lastMethodBodySize);
bevp_lastMethodBodyLines = bevp_lastMethodBodyLines.bem_add_1(bevl_moreLines);
bevp_lastMethodBodySize = bevp_methodBody.bem_sizeGet_0();
beva_node.bem_nlecSet_1(bevp_lastMethodBodyLines);
bevt_27_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_28_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_287));
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_28_tmpvar_phold);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 1298 */ {
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_lengthGet_0();
bevt_32_tmpvar_phold = bevo_72;
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_notEquals_1(bevt_32_tmpvar_phold);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 1298 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1298 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1298 */
 else  /* Line: 1298 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1298 */ {
bevt_33_tmpvar_phold = bevo_73;
bevt_36_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_lengthGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_toString_0();
bevl_errmsg = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevl_ei = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1300 */ {
bevt_39_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_lengthGet_0();
bevt_37_tmpvar_phold = bevl_ei.bem_lesser_1(bevt_38_tmpvar_phold);
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 1300 */ {
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_289));
bevt_42_tmpvar_phold = bevl_errmsg.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_43_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_ei);
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_290));
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_44_tmpvar_phold);
bevt_46_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_get_1(bevl_ei);
bevl_errmsg = bevt_40_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_45_tmpvar_phold);
bevl_ei = bevl_ei.bem_increment_0();
} /* Line: 1300 */
 else  /* Line: 1300 */ {
break;
} /* Line: 1300 */
} /* Line: 1300 */
bevt_47_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_errmsg, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_47_tmpvar_phold);
} /* Line: 1303 */
 else  /* Line: 1298 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_51_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_291));
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_51_tmpvar_phold);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 1304 */ {
bevt_56_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_firstGet_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_57_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_292));
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_57_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 1304 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1304 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1304 */
 else  /* Line: 1304 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1304 */ {
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bels_293));
bevt_58_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_59_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_58_tmpvar_phold);
} /* Line: 1305 */
 else  /* Line: 1298 */ {
bevt_62_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_294));
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_63_tmpvar_phold);
if (bevt_60_tmpvar_phold != null && bevt_60_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_60_tmpvar_phold).bevi_bool) /* Line: 1306 */ {
this.bem_acceptThrow_1(beva_node);
return this;
} /* Line: 1308 */
 else  /* Line: 1298 */ {
bevt_66_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_295));
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_67_tmpvar_phold);
if (bevt_64_tmpvar_phold != null && bevt_64_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_64_tmpvar_phold).bevi_bool) /* Line: 1309 */ {
bevt_69_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_68_tmpvar_phold != null && bevt_68_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_68_tmpvar_phold).bevi_bool) /* Line: 1313 */ {
bevt_72_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bem_firstGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_castTo = (BEC_2_5_8_BuildNamePath) bevt_70_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 1314 */
bevt_75_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_typenameGet_0();
bevt_76_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bem_equals_1(bevt_76_tmpvar_phold);
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 1316 */ {
bevt_79_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bem_firstGet_0();
bevt_81_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_80_tmpvar_phold = this.bem_formTarg_1(bevt_81_tmpvar_phold);
bevt_77_tmpvar_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_78_tmpvar_phold, bevt_80_tmpvar_phold, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_77_tmpvar_phold);
} /* Line: 1318 */
 else  /* Line: 1316 */ {
bevt_84_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_typenameGet_0();
bevt_85_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_equals_1(bevt_85_tmpvar_phold);
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 1319 */ {
bevt_88_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bem_firstGet_0();
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_296));
bevt_86_tmpvar_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_87_tmpvar_phold, bevt_89_tmpvar_phold, null);
bevp_methodBody.bem_addValue_1(bevt_86_tmpvar_phold);
} /* Line: 1320 */
 else  /* Line: 1316 */ {
bevt_92_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_91_tmpvar_phold = bevt_92_tmpvar_phold.bem_typenameGet_0();
bevt_93_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_90_tmpvar_phold = bevt_91_tmpvar_phold.bem_equals_1(bevt_93_tmpvar_phold);
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 1321 */ {
bevt_96_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_94_tmpvar_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_95_tmpvar_phold, bevp_trueValue, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_94_tmpvar_phold);
} /* Line: 1322 */
 else  /* Line: 1316 */ {
bevt_99_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_98_tmpvar_phold = bevt_99_tmpvar_phold.bem_typenameGet_0();
bevt_100_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_equals_1(bevt_100_tmpvar_phold);
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 1323 */ {
bevt_103_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_102_tmpvar_phold, bevp_falseValue, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_101_tmpvar_phold);
} /* Line: 1324 */
 else  /* Line: 1316 */ {
bevt_107_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bem_heldGet_0();
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_108_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_297));
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_108_tmpvar_phold);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 1325 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1325 */ {
bevt_112_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_111_tmpvar_phold = bevt_112_tmpvar_phold.bem_heldGet_0();
bevt_110_tmpvar_phold = bevt_111_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_113_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_298));
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_113_tmpvar_phold);
if (bevt_109_tmpvar_phold != null && bevt_109_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_109_tmpvar_phold).bevi_bool) /* Line: 1325 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1325 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1325 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 1325 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1325 */ {
bevt_117_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_116_tmpvar_phold = bevt_117_tmpvar_phold.bem_heldGet_0();
bevt_115_tmpvar_phold = bevt_116_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_118_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_299));
bevt_114_tmpvar_phold = bevt_115_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_118_tmpvar_phold);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 1325 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1325 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1325 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 1326 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1326 */ {
bevt_122_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bem_heldGet_0();
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_123_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_300));
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_123_tmpvar_phold);
if (bevt_119_tmpvar_phold != null && bevt_119_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_119_tmpvar_phold).bevi_bool) /* Line: 1326 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1326 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1326 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1326 */ {
bevt_125_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_124_tmpvar_phold != null && bevt_124_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_124_tmpvar_phold).bevi_bool) /* Line: 1333 */ {
bevt_131_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bem_firstGet_0();
bevt_129_tmpvar_phold = bevt_130_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_127_tmpvar_phold = bevt_128_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_132_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_301));
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_132_tmpvar_phold);
if (bevt_126_tmpvar_phold != null && bevt_126_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_126_tmpvar_phold).bevi_bool) /* Line: 1334 */ {
bevt_134_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(48, bels_302));
bevt_133_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_134_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_133_tmpvar_phold);
} /* Line: 1335 */
} /* Line: 1334 */
bevt_138_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_137_tmpvar_phold = bevt_138_tmpvar_phold.bem_heldGet_0();
bevt_136_tmpvar_phold = bevt_137_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_139_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_303));
bevt_135_tmpvar_phold = bevt_136_tmpvar_phold.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, bevt_139_tmpvar_phold);
if (bevt_135_tmpvar_phold != null && bevt_135_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_135_tmpvar_phold).bevi_bool) /* Line: 1338 */ {
bevl_nullRes = bevp_trueValue;
bevl_notNullRes = bevp_falseValue;
} /* Line: 1340 */
 else  /* Line: 1341 */ {
bevl_nullRes = bevp_falseValue;
bevl_notNullRes = bevp_trueValue;
} /* Line: 1343 */
bevt_143_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_304));
bevt_142_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_143_tmpvar_phold);
bevt_146_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bem_secondGet_0();
bevt_144_tmpvar_phold = this.bem_formTarg_1(bevt_145_tmpvar_phold);
bevt_141_tmpvar_phold = (BEC_2_4_6_TextString) bevt_142_tmpvar_phold.bem_addValue_1(bevt_144_tmpvar_phold);
bevt_147_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_305));
bevt_140_tmpvar_phold = (BEC_2_4_6_TextString) bevt_141_tmpvar_phold.bem_addValue_1(bevt_147_tmpvar_phold);
bevt_140_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_150_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bem_firstGet_0();
bevt_148_tmpvar_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_149_tmpvar_phold, bevl_nullRes, null);
bevp_methodBody.bem_addValue_1(bevt_148_tmpvar_phold);
bevt_152_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_306));
bevt_151_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_152_tmpvar_phold);
bevt_151_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_155_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_154_tmpvar_phold = bevt_155_tmpvar_phold.bem_firstGet_0();
bevt_153_tmpvar_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_154_tmpvar_phold, bevl_notNullRes, null);
bevp_methodBody.bem_addValue_1(bevt_153_tmpvar_phold);
bevt_157_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_307));
bevt_156_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_157_tmpvar_phold);
bevt_156_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1349 */
} /* Line: 1316 */
} /* Line: 1316 */
} /* Line: 1316 */
} /* Line: 1316 */
return this;
} /* Line: 1351 */
 else  /* Line: 1298 */ {
bevt_160_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_159_tmpvar_phold = bevt_160_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_161_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_308));
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_161_tmpvar_phold);
if (bevt_158_tmpvar_phold != null && bevt_158_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpvar_phold).bevi_bool) /* Line: 1352 */ {
bevl_returnCast = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_309));
bevt_163_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_162_tmpvar_phold != null && bevt_162_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_162_tmpvar_phold).bevi_bool) /* Line: 1355 */ {
bevt_164_tmpvar_phold = this.bem_formCast_1(bevp_returnType);
bevt_165_tmpvar_phold = bevo_74;
bevl_returnCast = bevt_164_tmpvar_phold.bem_add_1(bevt_165_tmpvar_phold);
} /* Line: 1356 */
bevt_170_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_311));
bevt_169_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_170_tmpvar_phold);
bevt_168_tmpvar_phold = (BEC_2_4_6_TextString) bevt_169_tmpvar_phold.bem_addValue_1(bevl_returnCast);
bevt_172_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_171_tmpvar_phold = this.bem_formTarg_1(bevt_172_tmpvar_phold);
bevt_167_tmpvar_phold = (BEC_2_4_6_TextString) bevt_168_tmpvar_phold.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_173_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_312));
bevt_166_tmpvar_phold = (BEC_2_4_6_TextString) bevt_167_tmpvar_phold.bem_addValue_1(bevt_173_tmpvar_phold);
bevt_166_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /* Line: 1359 */
 else  /* Line: 1298 */ {
bevt_176_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_175_tmpvar_phold = bevt_176_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_177_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_313));
bevt_174_tmpvar_phold = bevt_175_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_177_tmpvar_phold);
if (bevt_174_tmpvar_phold != null && bevt_174_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_174_tmpvar_phold).bevi_bool) /* Line: 1360 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1360 */ {
bevt_180_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_179_tmpvar_phold = bevt_180_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_181_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_314));
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_181_tmpvar_phold);
if (bevt_178_tmpvar_phold != null && bevt_178_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_178_tmpvar_phold).bevi_bool) /* Line: 1360 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1360 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1360 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 1360 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1360 */ {
bevt_184_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_183_tmpvar_phold = bevt_184_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_185_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_315));
bevt_182_tmpvar_phold = bevt_183_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_185_tmpvar_phold);
if (bevt_182_tmpvar_phold != null && bevt_182_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_182_tmpvar_phold).bevi_bool) /* Line: 1360 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1360 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1360 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 1360 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1360 */ {
bevt_188_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_189_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_316));
bevt_186_tmpvar_phold = bevt_187_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_189_tmpvar_phold);
if (bevt_186_tmpvar_phold != null && bevt_186_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_186_tmpvar_phold).bevi_bool) /* Line: 1360 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1360 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1360 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 1360 */ {
return this;
} /* Line: 1362 */
} /* Line: 1298 */
} /* Line: 1298 */
} /* Line: 1298 */
} /* Line: 1298 */
} /* Line: 1298 */
bevt_192_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_191_tmpvar_phold = bevt_192_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_196_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_195_tmpvar_phold = bevt_196_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_197_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_317));
bevt_194_tmpvar_phold = bevt_195_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_197_tmpvar_phold);
bevt_199_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_198_tmpvar_phold = bevt_199_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_198_tmpvar_phold);
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_193_tmpvar_phold);
if (bevt_190_tmpvar_phold != null && bevt_190_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_190_tmpvar_phold).bevi_bool) /* Line: 1365 */ {
bevt_206_tmpvar_phold = bevo_75;
bevt_208_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_207_tmpvar_phold = bevt_208_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_205_tmpvar_phold = bevt_206_tmpvar_phold.bem_add_1(bevt_207_tmpvar_phold);
bevt_209_tmpvar_phold = bevo_76;
bevt_204_tmpvar_phold = bevt_205_tmpvar_phold.bem_add_1(bevt_209_tmpvar_phold);
bevt_211_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_203_tmpvar_phold = bevt_204_tmpvar_phold.bem_add_1(bevt_210_tmpvar_phold);
bevt_212_tmpvar_phold = bevo_77;
bevt_202_tmpvar_phold = bevt_203_tmpvar_phold.bem_add_1(bevt_212_tmpvar_phold);
bevt_214_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_213_tmpvar_phold = bevt_214_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_201_tmpvar_phold = bevt_202_tmpvar_phold.bem_add_1(bevt_213_tmpvar_phold);
bevt_200_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_201_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_200_tmpvar_phold);
} /* Line: 1366 */
bevl_selfCall = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_superCall = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isConstruct = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isTyped = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_216_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_215_tmpvar_phold != null && bevt_215_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_215_tmpvar_phold).bevi_bool) /* Line: 1374 */ {
bevl_isConstruct = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_218_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_217_tmpvar_phold = bevt_218_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_217_tmpvar_phold);
} /* Line: 1376 */
 else  /* Line: 1374 */ {
bevt_223_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_222_tmpvar_phold = bevt_223_tmpvar_phold.bem_firstGet_0();
bevt_221_tmpvar_phold = bevt_222_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_220_tmpvar_phold = bevt_221_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_224_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_321));
bevt_219_tmpvar_phold = bevt_220_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_224_tmpvar_phold);
if (bevt_219_tmpvar_phold != null && bevt_219_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_219_tmpvar_phold).bevi_bool) /* Line: 1377 */ {
bevl_selfCall = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1378 */
 else  /* Line: 1374 */ {
bevt_229_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_228_tmpvar_phold = bevt_229_tmpvar_phold.bem_firstGet_0();
bevt_227_tmpvar_phold = bevt_228_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_226_tmpvar_phold = bevt_227_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_230_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_322));
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_230_tmpvar_phold);
if (bevt_225_tmpvar_phold != null && bevt_225_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_225_tmpvar_phold).bevi_bool) /* Line: 1379 */ {
bevl_selfCall = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_superCall = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_superCalls.bem_addValue_1(beva_node);
bevt_231_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_232_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_231_tmpvar_phold.bemd_1(1785494885, BEL_4_Base.bevn_superCallSet_1, bevt_232_tmpvar_phold);
} /* Line: 1383 */
} /* Line: 1374 */
} /* Line: 1374 */
bevl_callArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_spillArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_numargs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_233_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_233_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 1392 */ {
bevt_234_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_234_tmpvar_phold != null && bevt_234_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_234_tmpvar_phold).bevi_bool) /* Line: 1392 */ {
bevt_235_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_argCasts = (BEC_2_9_5_ContainerArray) bevt_235_tmpvar_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_237_tmpvar_phold = bevo_78;
bevt_236_tmpvar_phold = bevl_numargs.bem_equals_1(bevt_237_tmpvar_phold);
if (bevt_236_tmpvar_phold.bevi_bool) /* Line: 1395 */ {
bevl_target = this.bem_formTarg_1((BEC_2_5_4_BuildNode) bevl_i);
bevl_targetNode = (BEC_2_5_4_BuildNode) bevl_i;
bevt_239_tmpvar_phold = bevl_targetNode.bem_heldGet_0();
bevt_238_tmpvar_phold = bevt_239_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_238_tmpvar_phold != null && bevt_238_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_238_tmpvar_phold).bevi_bool) /* Line: 1399 */ {
bevl_isTyped = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1400 */
} /* Line: 1399 */
 else  /* Line: 1402 */ {
if (bevl_isTyped.bevi_bool) /* Line: 1403 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1403 */ {
bevt_240_tmpvar_phold = bevl_numargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_240_tmpvar_phold.bevi_bool) /* Line: 1403 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1403 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1403 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 1403 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1403 */ {
bevt_242_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_241_tmpvar_phold = bevt_242_tmpvar_phold.bem_not_0();
if (bevt_241_tmpvar_phold.bevi_bool) /* Line: 1403 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1403 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1403 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 1403 */ {
bevt_244_tmpvar_phold = bevo_79;
bevt_243_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_244_tmpvar_phold);
if (bevt_243_tmpvar_phold.bevi_bool) /* Line: 1404 */ {
bevt_245_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_323));
bevl_callArgs.bem_addValue_1(bevt_245_tmpvar_phold);
} /* Line: 1405 */
bevt_247_tmpvar_phold = bevl_argCasts.bem_lengthGet_0();
bevt_246_tmpvar_phold = bevt_247_tmpvar_phold.bem_greater_1(bevl_numargs);
if (bevt_246_tmpvar_phold.bevi_bool) /* Line: 1407 */ {
bevt_249_tmpvar_phold = bevl_argCasts.bem_get_1(bevl_numargs);
if (bevt_249_tmpvar_phold == null) {
bevt_248_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_248_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_248_tmpvar_phold.bevi_bool) /* Line: 1407 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1407 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1407 */
 else  /* Line: 1407 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 1407 */ {
bevt_253_tmpvar_phold = bevl_argCasts.bem_get_1(bevl_numargs);
bevt_252_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_253_tmpvar_phold);
bevt_251_tmpvar_phold = this.bem_formCast_1(bevt_252_tmpvar_phold);
bevt_250_tmpvar_phold = (BEC_2_4_6_TextString) bevl_callArgs.bem_addValue_1(bevt_251_tmpvar_phold);
bevt_254_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_324));
bevt_250_tmpvar_phold.bem_addValue_1(bevt_254_tmpvar_phold);
} /* Line: 1408 */
bevt_255_tmpvar_phold = this.bem_formTarg_1((BEC_2_5_4_BuildNode) bevl_i);
bevl_callArgs.bem_addValue_1(bevt_255_tmpvar_phold);
} /* Line: 1410 */
 else  /* Line: 1411 */ {
bevl_spillArgPos = bevl_numargs.bem_subtract_1(bevp_maxDynArgs);
bevt_261_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_325));
bevt_260_tmpvar_phold = (BEC_2_4_6_TextString) bevl_spillArgs.bem_addValue_1(bevt_261_tmpvar_phold);
bevt_262_tmpvar_phold = bevl_spillArgPos.bem_toString_0();
bevt_259_tmpvar_phold = (BEC_2_4_6_TextString) bevt_260_tmpvar_phold.bem_addValue_1(bevt_262_tmpvar_phold);
bevt_263_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_326));
bevt_258_tmpvar_phold = (BEC_2_4_6_TextString) bevt_259_tmpvar_phold.bem_addValue_1(bevt_263_tmpvar_phold);
bevt_264_tmpvar_phold = this.bem_formTarg_1((BEC_2_5_4_BuildNode) bevl_i);
bevt_257_tmpvar_phold = (BEC_2_4_6_TextString) bevt_258_tmpvar_phold.bem_addValue_1(bevt_264_tmpvar_phold);
bevt_265_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_327));
bevt_256_tmpvar_phold = (BEC_2_4_6_TextString) bevt_257_tmpvar_phold.bem_addValue_1(bevt_265_tmpvar_phold);
bevt_256_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1414 */
} /* Line: 1403 */
bevl_numargs = bevl_numargs.bem_increment_0();
} /* Line: 1417 */
 else  /* Line: 1392 */ {
break;
} /* Line: 1392 */
} /* Line: 1392 */
bevl_numargs = bevl_numargs.bem_decrement_0();
if (bevl_isConstruct.bevi_bool) /* Line: 1423 */ {
bevt_266_tmpvar_phold = bevl_isTyped.bem_not_0();
if (bevt_266_tmpvar_phold.bevi_bool) /* Line: 1423 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1423 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1423 */
 else  /* Line: 1423 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 1423 */ {
bevt_268_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(27, bels_328));
bevt_267_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_268_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_267_tmpvar_phold);
} /* Line: 1424 */
bevl_isOnce = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_onceDeced = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_271_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_270_tmpvar_phold = bevt_271_tmpvar_phold.bem_typenameGet_0();
bevt_272_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bem_equals_1(bevt_272_tmpvar_phold);
if (bevt_269_tmpvar_phold.bevi_bool) /* Line: 1431 */ {
bevt_276_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_275_tmpvar_phold = bevt_276_tmpvar_phold.bem_heldGet_0();
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_277_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_329));
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_277_tmpvar_phold);
if (bevt_273_tmpvar_phold != null && bevt_273_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_273_tmpvar_phold).bevi_bool) /* Line: 1431 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1431 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1431 */
 else  /* Line: 1431 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 1431 */ {
bevt_279_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_278_tmpvar_phold = this.bem_isOnceAssign_1(bevt_279_tmpvar_phold);
if (bevt_278_tmpvar_phold.bevi_bool) /* Line: 1432 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1432 */ {
bevt_281_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_280_tmpvar_phold = bevt_281_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_280_tmpvar_phold.bevi_bool) /* Line: 1432 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1432 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1432 */
 else  /* Line: 1432 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
bevt_282_tmpvar_phold = bevt_14_tmpvar_anchor.bem_not_0();
if (bevt_282_tmpvar_phold.bevi_bool) /* Line: 1432 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1432 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1432 */
 else  /* Line: 1432 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 1432 */ {
bevl_isOnce = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_283_tmpvar_phold = bevp_onceCount.bem_toString_0();
bevl_ovar = this.bem_onceVarDec_1(bevt_283_tmpvar_phold);
bevp_onceCount = bevp_onceCount.bem_increment_0();
bevt_289_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_288_tmpvar_phold = bevt_289_tmpvar_phold.bem_containedGet_0();
bevt_287_tmpvar_phold = bevt_288_tmpvar_phold.bem_firstGet_0();
bevt_286_tmpvar_phold = bevt_287_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_285_tmpvar_phold = bevt_286_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_284_tmpvar_phold = bevt_285_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_284_tmpvar_phold != null && bevt_284_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_284_tmpvar_phold).bevi_bool) /* Line: 1437 */ {
bevt_291_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_290_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_291_tmpvar_phold);
bevl_odec = (BEC_2_4_6_TextString) this.bem_onceDec_2((BEC_2_4_6_TextString) bevt_290_tmpvar_phold, bevl_ovar);
} /* Line: 1438 */
 else  /* Line: 1439 */ {
bevt_298_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_297_tmpvar_phold = bevt_298_tmpvar_phold.bem_containedGet_0();
bevt_296_tmpvar_phold = bevt_297_tmpvar_phold.bem_firstGet_0();
bevt_295_tmpvar_phold = bevt_296_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_294_tmpvar_phold = bevt_295_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_293_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_294_tmpvar_phold);
bevt_299_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_292_tmpvar_phold = bevt_293_tmpvar_phold.bem_relEmitName_1(bevt_299_tmpvar_phold);
bevl_odec = (BEC_2_4_6_TextString) this.bem_onceDec_2((BEC_2_4_6_TextString) bevt_292_tmpvar_phold, bevl_ovar);
} /* Line: 1440 */
} /* Line: 1437 */
bevt_302_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_301_tmpvar_phold = bevt_302_tmpvar_phold.bem_heldGet_0();
bevt_300_tmpvar_phold = bevt_301_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_300_tmpvar_phold != null && bevt_300_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_300_tmpvar_phold).bevi_bool) /* Line: 1445 */ {
bevt_306_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_305_tmpvar_phold = bevt_306_tmpvar_phold.bem_containedGet_0();
bevt_304_tmpvar_phold = bevt_305_tmpvar_phold.bem_firstGet_0();
bevt_303_tmpvar_phold = bevt_304_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_castTo = (BEC_2_5_8_BuildNamePath) bevt_303_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 1447 */
bevt_309_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_308_tmpvar_phold = bevt_309_tmpvar_phold.bem_containedGet_0();
bevt_307_tmpvar_phold = bevt_308_tmpvar_phold.bem_firstGet_0();
bevl_callAssign = this.bem_finalAssignTo_2((BEC_2_5_4_BuildNode) bevt_307_tmpvar_phold, bevl_castTo);
} /* Line: 1449 */
 else  /* Line: 1450 */ {
bevl_callAssign = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_330));
} /* Line: 1451 */
if (bevl_isOnce.bevi_bool) /* Line: 1454 */ {
bevt_317_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_316_tmpvar_phold = bevt_317_tmpvar_phold.bem_containedGet_0();
bevt_315_tmpvar_phold = bevt_316_tmpvar_phold.bem_firstGet_0();
bevt_314_tmpvar_phold = bevt_315_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_313_tmpvar_phold = this.bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_314_tmpvar_phold);
bevt_318_tmpvar_phold = bevo_80;
bevt_312_tmpvar_phold = bevt_313_tmpvar_phold.bem_add_1(bevt_318_tmpvar_phold);
bevt_311_tmpvar_phold = bevt_312_tmpvar_phold.bem_add_1(bevl_ovar);
bevt_319_tmpvar_phold = bevo_81;
bevt_310_tmpvar_phold = bevt_311_tmpvar_phold.bem_add_1(bevt_319_tmpvar_phold);
bevl_postOnceCallAssign = bevt_310_tmpvar_phold.bem_add_1(bevp_nl);
if (bevl_castTo == null) {
bevt_320_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_320_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_320_tmpvar_phold.bevi_bool) /* Line: 1458 */ {
bevt_322_tmpvar_phold = this.bem_getClassConfig_1(bevl_castTo);
bevt_321_tmpvar_phold = this.bem_formCast_1(bevt_322_tmpvar_phold);
bevt_323_tmpvar_phold = bevo_82;
bevl_cast = bevt_321_tmpvar_phold.bem_add_1(bevt_323_tmpvar_phold);
} /* Line: 1459 */
 else  /* Line: 1460 */ {
bevl_cast = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_334));
} /* Line: 1461 */
bevt_325_tmpvar_phold = bevo_83;
bevt_324_tmpvar_phold = bevl_ovar.bem_add_1(bevt_325_tmpvar_phold);
bevl_callAssign = bevt_324_tmpvar_phold.bem_add_1(bevl_cast);
} /* Line: 1463 */
if (bevl_isTyped.bevi_bool) /* Line: 1467 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1467 */ {
bevt_327_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_326_tmpvar_phold = bevt_327_tmpvar_phold.bem_not_0();
if (bevt_326_tmpvar_phold.bevi_bool) /* Line: 1467 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1467 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1467 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 1467 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1467 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1467 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1467 */
 else  /* Line: 1467 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 1467 */ {
bevt_329_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_328_tmpvar_phold = bevt_329_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_328_tmpvar_phold != null && bevt_328_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_328_tmpvar_phold).bevi_bool) /* Line: 1467 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1467 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1467 */
 else  /* Line: 1467 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 1467 */ {
if (bevl_isOnce.bevi_bool) /* Line: 1467 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1467 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1467 */
 else  /* Line: 1467 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 1467 */ {
bevl_onceDeced = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1468 */
 else  /* Line: 1467 */ {
if (bevl_isOnce.bevi_bool) /* Line: 1469 */ {
bevt_331_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_336));
bevt_330_tmpvar_phold = this.bem_emitting_1(bevt_331_tmpvar_phold);
if (bevt_330_tmpvar_phold.bevi_bool) /* Line: 1472 */ {
bevt_335_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_337));
bevt_334_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_335_tmpvar_phold);
bevt_336_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_333_tmpvar_phold = (BEC_2_4_6_TextString) bevt_334_tmpvar_phold.bem_addValue_1(bevt_336_tmpvar_phold);
bevt_337_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_338));
bevt_332_tmpvar_phold = (BEC_2_4_6_TextString) bevt_333_tmpvar_phold.bem_addValue_1(bevt_337_tmpvar_phold);
bevt_332_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1473 */
 else  /* Line: 1472 */ {
bevt_339_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_339));
bevt_338_tmpvar_phold = this.bem_emitting_1(bevt_339_tmpvar_phold);
if (bevt_338_tmpvar_phold.bevi_bool) /* Line: 1474 */ {
bevt_343_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_340));
bevt_342_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_343_tmpvar_phold);
bevt_344_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_341_tmpvar_phold = (BEC_2_4_6_TextString) bevt_342_tmpvar_phold.bem_addValue_1(bevt_344_tmpvar_phold);
bevt_345_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_341));
bevt_340_tmpvar_phold = (BEC_2_4_6_TextString) bevt_341_tmpvar_phold.bem_addValue_1(bevt_345_tmpvar_phold);
bevt_340_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1475 */
} /* Line: 1472 */
bevt_349_tmpvar_phold = bevo_84;
bevt_348_tmpvar_phold = bevt_349_tmpvar_phold.bem_add_1(bevl_ovar);
bevt_350_tmpvar_phold = bevo_85;
bevt_347_tmpvar_phold = bevt_348_tmpvar_phold.bem_add_1(bevt_350_tmpvar_phold);
bevt_346_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_347_tmpvar_phold);
bevt_346_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1477 */
} /* Line: 1467 */
if (bevl_isTyped.bevi_bool) /* Line: 1482 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1482 */ {
bevt_352_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_351_tmpvar_phold = bevt_352_tmpvar_phold.bem_not_0();
if (bevt_351_tmpvar_phold.bevi_bool) /* Line: 1482 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1482 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1482 */
if (bevt_19_tmpvar_anchor.bevi_bool) /* Line: 1482 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1483 */ {
bevt_354_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_353_tmpvar_phold = bevt_354_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_353_tmpvar_phold != null && bevt_353_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_353_tmpvar_phold).bevi_bool) /* Line: 1484 */ {
bevt_356_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_355_tmpvar_phold = bevt_356_tmpvar_phold.bem_equals_1(bevp_intNp);
if (bevt_355_tmpvar_phold.bevi_bool) /* Line: 1485 */ {
bevl_newCall = this.bem_lintConstruct_2(bevl_newcc, beva_node);
} /* Line: 1486 */
 else  /* Line: 1485 */ {
bevt_358_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_357_tmpvar_phold = bevt_358_tmpvar_phold.bem_equals_1(bevp_floatNp);
if (bevt_357_tmpvar_phold.bevi_bool) /* Line: 1487 */ {
bevl_newCall = this.bem_lfloatConstruct_2(bevl_newcc, beva_node);
} /* Line: 1488 */
 else  /* Line: 1485 */ {
bevt_360_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_359_tmpvar_phold = bevt_360_tmpvar_phold.bem_equals_1(bevp_stringNp);
if (bevt_359_tmpvar_phold.bevi_bool) /* Line: 1489 */ {
bevt_361_tmpvar_phold = bevo_86;
bevt_364_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_363_tmpvar_phold = bevt_364_tmpvar_phold.bemd_0(368256414, BEL_4_Base.bevn_belsCountGet_0);
bevt_362_tmpvar_phold = bevt_363_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_belsName = bevt_361_tmpvar_phold.bem_add_1(bevt_362_tmpvar_phold);
bevt_366_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_365_tmpvar_phold = bevt_366_tmpvar_phold.bemd_0(368256414, BEL_4_Base.bevn_belsCountGet_0);
bevt_365_tmpvar_phold.bemd_0(1205852557, BEL_4_Base.bevn_incrementValue_0);
bevl_sdec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
this.bem_lstringStart_2(bevl_sdec, bevl_belsName);
bevt_367_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_liorg = (BEC_2_4_6_TextString) bevt_367_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_368_tmpvar_phold = beva_node.bem_wideStringGet_0();
if (bevt_368_tmpvar_phold.bevi_bool) /* Line: 1498 */ {
bevl_lival = bevl_liorg;
} /* Line: 1499 */
 else  /* Line: 1500 */ {
bevt_370_tmpvar_phold = (BEC_2_4_12_JsonUnmarshaller) (new BEC_2_4_12_JsonUnmarshaller()).bem_new_0();
bevt_375_tmpvar_phold = bevo_87;
bevt_377_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_376_tmpvar_phold = bevt_377_tmpvar_phold.bem_quoteGet_0();
bevt_374_tmpvar_phold = bevt_375_tmpvar_phold.bem_add_1(bevt_376_tmpvar_phold);
bevt_373_tmpvar_phold = bevt_374_tmpvar_phold.bem_add_1(bevl_liorg);
bevt_379_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_378_tmpvar_phold = bevt_379_tmpvar_phold.bem_quoteGet_0();
bevt_372_tmpvar_phold = bevt_373_tmpvar_phold.bem_add_1(bevt_378_tmpvar_phold);
bevt_380_tmpvar_phold = bevo_88;
bevt_371_tmpvar_phold = bevt_372_tmpvar_phold.bem_add_1(bevt_380_tmpvar_phold);
bevt_369_tmpvar_phold = bevt_370_tmpvar_phold.bem_unmarshall_1(bevt_371_tmpvar_phold);
bevl_lival = (BEC_2_4_6_TextString) bevt_369_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 1501 */
bevl_lisz = bevl_lival.bem_sizeGet_0();
bevl_lipos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_bcode = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevt_381_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_hs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_381_tmpvar_phold);
while (true)
 /* Line: 1508 */ {
bevt_382_tmpvar_phold = bevl_lipos.bem_lesser_1(bevl_lisz);
if (bevt_382_tmpvar_phold.bevi_bool) /* Line: 1508 */ {
bevt_384_tmpvar_phold = bevo_89;
bevt_383_tmpvar_phold = bevl_lipos.bem_greater_1(bevt_384_tmpvar_phold);
if (bevt_383_tmpvar_phold.bevi_bool) /* Line: 1509 */ {
bevt_386_tmpvar_phold = bevo_90;
bevt_385_tmpvar_phold = (BEC_2_4_6_TextString) bevt_386_tmpvar_phold.bem_once_0();
bevl_sdec.bem_addValue_1(bevt_385_tmpvar_phold);
} /* Line: 1510 */
this.bem_lstringByte_5(bevl_sdec, bevl_lival, bevl_lipos, bevl_bcode, bevl_hs);
bevl_lipos.bem_incrementValue_0();
} /* Line: 1513 */
 else  /* Line: 1508 */ {
break;
} /* Line: 1508 */
} /* Line: 1508 */
this.bem_lstringEnd_1(bevl_sdec);
bevp_onceDecs.bem_addValue_1(bevl_sdec);
bevl_newCall = this.bem_lstringConstruct_5(bevl_newcc, beva_node, bevl_belsName, bevl_lisz, bevl_isOnce);
} /* Line: 1518 */
 else  /* Line: 1485 */ {
bevt_388_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_387_tmpvar_phold = bevt_388_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_387_tmpvar_phold.bevi_bool) /* Line: 1519 */ {
bevt_391_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_390_tmpvar_phold = bevt_391_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_392_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_348));
bevt_389_tmpvar_phold = bevt_390_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_392_tmpvar_phold);
if (bevt_389_tmpvar_phold != null && bevt_389_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_389_tmpvar_phold).bevi_bool) /* Line: 1520 */ {
bevl_newCall = bevp_trueValue;
} /* Line: 1521 */
 else  /* Line: 1522 */ {
bevl_newCall = bevp_falseValue;
} /* Line: 1523 */
} /* Line: 1520 */
 else  /* Line: 1525 */ {
bevt_395_tmpvar_phold = bevo_91;
bevt_397_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_396_tmpvar_phold = bevt_397_tmpvar_phold.bem_toString_0();
bevt_394_tmpvar_phold = bevt_395_tmpvar_phold.bem_add_1(bevt_396_tmpvar_phold);
bevt_393_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_394_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_393_tmpvar_phold);
} /* Line: 1527 */
} /* Line: 1485 */
} /* Line: 1485 */
} /* Line: 1485 */
} /* Line: 1485 */
 else  /* Line: 1529 */ {
bevt_399_tmpvar_phold = bevo_92;
bevt_401_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_400_tmpvar_phold = bevl_newcc.bem_relEmitName_1(bevt_401_tmpvar_phold);
bevt_398_tmpvar_phold = bevt_399_tmpvar_phold.bem_add_1(bevt_400_tmpvar_phold);
bevt_402_tmpvar_phold = bevo_93;
bevl_newCall = bevt_398_tmpvar_phold.bem_add_1(bevt_402_tmpvar_phold);
} /* Line: 1530 */
bevt_404_tmpvar_phold = bevo_94;
bevt_403_tmpvar_phold = bevt_404_tmpvar_phold.bem_add_1(bevl_newCall);
bevt_405_tmpvar_phold = bevo_95;
bevl_target = bevt_403_tmpvar_phold.bem_add_1(bevt_405_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_407_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_406_tmpvar_phold = bevt_407_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_406_tmpvar_phold != null && bevt_406_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_406_tmpvar_phold).bevi_bool) /* Line: 1536 */ {
bevt_409_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_408_tmpvar_phold = bevt_409_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_408_tmpvar_phold.bevi_bool) /* Line: 1537 */ {
if (bevl_onceDeced.bevi_bool) /* Line: 1538 */ {
bevl_odinfo = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_414_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_413_tmpvar_phold = bevt_414_tmpvar_phold.bem_containedGet_0();
bevt_412_tmpvar_phold = bevt_413_tmpvar_phold.bem_firstGet_0();
bevt_411_tmpvar_phold = bevt_412_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_410_tmpvar_phold = bevt_411_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_410_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 1540 */ {
bevt_415_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_415_tmpvar_phold != null && bevt_415_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_415_tmpvar_phold).bevi_bool) /* Line: 1540 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_419_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_418_tmpvar_phold = bevt_419_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_417_tmpvar_phold = bevt_418_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_416_tmpvar_phold = (BEC_2_4_6_TextString) bevl_odinfo.bem_addValue_1(bevt_417_tmpvar_phold);
bevt_420_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_354));
bevt_416_tmpvar_phold.bem_addValue_1(bevt_420_tmpvar_phold);
} /* Line: 1541 */
 else  /* Line: 1540 */ {
break;
} /* Line: 1540 */
} /* Line: 1540 */
bevt_423_tmpvar_phold = bevo_96;
bevt_422_tmpvar_phold = bevt_423_tmpvar_phold.bem_add_1(bevl_odinfo);
bevt_421_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_422_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_421_tmpvar_phold);
} /* Line: 1543 */
bevt_426_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_425_tmpvar_phold = bevt_426_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_427_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_356));
bevt_424_tmpvar_phold = bevt_425_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_427_tmpvar_phold);
if (bevt_424_tmpvar_phold != null && bevt_424_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_424_tmpvar_phold).bevi_bool) /* Line: 1546 */ {
bevl_target = bevp_trueValue;
} /* Line: 1547 */
 else  /* Line: 1548 */ {
bevl_target = bevp_falseValue;
} /* Line: 1549 */
} /* Line: 1546 */
if (bevl_onceDeced.bevi_bool) /* Line: 1552 */ {
bevt_431_tmpvar_phold = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevl_odec);
bevt_430_tmpvar_phold = (BEC_2_4_6_TextString) bevt_431_tmpvar_phold.bem_addValue_1(bevl_callAssign);
bevt_429_tmpvar_phold = (BEC_2_4_6_TextString) bevt_430_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_432_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_357));
bevt_428_tmpvar_phold = (BEC_2_4_6_TextString) bevt_429_tmpvar_phold.bem_addValue_1(bevt_432_tmpvar_phold);
bevt_428_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1553 */
 else  /* Line: 1554 */ {
bevt_435_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_434_tmpvar_phold = (BEC_2_4_6_TextString) bevt_435_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_436_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_358));
bevt_433_tmpvar_phold = (BEC_2_4_6_TextString) bevt_434_tmpvar_phold.bem_addValue_1(bevt_436_tmpvar_phold);
bevt_433_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1555 */
} /* Line: 1552 */
 else  /* Line: 1557 */ {
bevt_437_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevl_asyn = bevp_build.bem_getSynNp_1(bevt_437_tmpvar_phold);
bevt_438_tmpvar_phold = bevl_asyn.bem_hasDefaultGet_0();
if (bevt_438_tmpvar_phold.bevi_bool) /* Line: 1559 */ {
bevl_initialTarg = bevl_stinst;
} /* Line: 1560 */
 else  /* Line: 1562 */ {
bevl_initialTarg = bevl_target;
} /* Line: 1563 */
bevt_439_tmpvar_phold = bevl_asyn.bem_mtdMapGet_0();
bevt_440_tmpvar_phold = bevo_97;
bevl_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_439_tmpvar_phold.bem_get_1(bevt_440_tmpvar_phold);
bevt_442_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_441_tmpvar_phold = bevt_442_tmpvar_phold.bem_notEmpty_1(bevl_callAssign);
if (bevt_441_tmpvar_phold.bevi_bool) /* Line: 1567 */ {
bevt_445_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_444_tmpvar_phold = bevt_445_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_446_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_360));
bevt_443_tmpvar_phold = bevt_444_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_446_tmpvar_phold);
if (bevt_443_tmpvar_phold != null && bevt_443_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_443_tmpvar_phold).bevi_bool) /* Line: 1567 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1567 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1567 */
 else  /* Line: 1567 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_21_tmpvar_anchor.bevi_bool) /* Line: 1567 */ {
bevt_449_tmpvar_phold = bevl_msyn.bem_originGet_0();
bevt_448_tmpvar_phold = bevt_449_tmpvar_phold.bem_toString_0();
bevt_450_tmpvar_phold = bevo_98;
bevt_447_tmpvar_phold = bevt_448_tmpvar_phold.bem_equals_1(bevt_450_tmpvar_phold);
if (bevt_447_tmpvar_phold.bevi_bool) /* Line: 1567 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1567 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1567 */
 else  /* Line: 1567 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_20_tmpvar_anchor.bevi_bool) /* Line: 1567 */ {
bevt_453_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_452_tmpvar_phold = (BEC_2_4_6_TextString) bevt_453_tmpvar_phold.bem_addValue_1(bevl_initialTarg);
bevt_454_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_362));
bevt_451_tmpvar_phold = (BEC_2_4_6_TextString) bevt_452_tmpvar_phold.bem_addValue_1(bevt_454_tmpvar_phold);
bevt_451_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1569 */
 else  /* Line: 1570 */ {
bevt_461_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_460_tmpvar_phold = (BEC_2_4_6_TextString) bevt_461_tmpvar_phold.bem_addValue_1(bevl_initialTarg);
bevt_462_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_363));
bevt_459_tmpvar_phold = (BEC_2_4_6_TextString) bevt_460_tmpvar_phold.bem_addValue_1(bevt_462_tmpvar_phold);
bevt_463_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_458_tmpvar_phold = (BEC_2_4_6_TextString) bevt_459_tmpvar_phold.bem_addValue_1(bevt_463_tmpvar_phold);
bevt_464_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_364));
bevt_457_tmpvar_phold = (BEC_2_4_6_TextString) bevt_458_tmpvar_phold.bem_addValue_1(bevt_464_tmpvar_phold);
bevt_456_tmpvar_phold = (BEC_2_4_6_TextString) bevt_457_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_465_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_365));
bevt_455_tmpvar_phold = (BEC_2_4_6_TextString) bevt_456_tmpvar_phold.bem_addValue_1(bevt_465_tmpvar_phold);
bevt_455_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1571 */
} /* Line: 1567 */
} /* Line: 1536 */
 else  /* Line: 1574 */ {
bevt_466_tmpvar_phold = bevl_isTyped.bem_not_0();
if (bevt_466_tmpvar_phold.bevi_bool) /* Line: 1575 */ {
bevt_473_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_472_tmpvar_phold = (BEC_2_4_6_TextString) bevt_473_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_474_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_366));
bevt_471_tmpvar_phold = (BEC_2_4_6_TextString) bevt_472_tmpvar_phold.bem_addValue_1(bevt_474_tmpvar_phold);
bevt_475_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_470_tmpvar_phold = (BEC_2_4_6_TextString) bevt_471_tmpvar_phold.bem_addValue_1(bevt_475_tmpvar_phold);
bevt_476_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_367));
bevt_469_tmpvar_phold = (BEC_2_4_6_TextString) bevt_470_tmpvar_phold.bem_addValue_1(bevt_476_tmpvar_phold);
bevt_468_tmpvar_phold = (BEC_2_4_6_TextString) bevt_469_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_477_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_368));
bevt_467_tmpvar_phold = (BEC_2_4_6_TextString) bevt_468_tmpvar_phold.bem_addValue_1(bevt_477_tmpvar_phold);
bevt_467_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1576 */
 else  /* Line: 1577 */ {
bevt_484_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_483_tmpvar_phold = (BEC_2_4_6_TextString) bevt_484_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_485_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_369));
bevt_482_tmpvar_phold = (BEC_2_4_6_TextString) bevt_483_tmpvar_phold.bem_addValue_1(bevt_485_tmpvar_phold);
bevt_486_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_481_tmpvar_phold = (BEC_2_4_6_TextString) bevt_482_tmpvar_phold.bem_addValue_1(bevt_486_tmpvar_phold);
bevt_487_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_370));
bevt_480_tmpvar_phold = (BEC_2_4_6_TextString) bevt_481_tmpvar_phold.bem_addValue_1(bevt_487_tmpvar_phold);
bevt_479_tmpvar_phold = (BEC_2_4_6_TextString) bevt_480_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_488_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_371));
bevt_478_tmpvar_phold = (BEC_2_4_6_TextString) bevt_479_tmpvar_phold.bem_addValue_1(bevt_488_tmpvar_phold);
bevt_478_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1578 */
} /* Line: 1575 */
} /* Line: 1483 */
 else  /* Line: 1581 */ {
bevt_489_tmpvar_phold = bevl_numargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_489_tmpvar_phold.bevi_bool) /* Line: 1582 */ {
bevl_dm = bevl_numargs.bem_toString_0();
bevl_callArgSpill = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_372));
} /* Line: 1584 */
 else  /* Line: 1585 */ {
bevl_dm = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_373));
bevt_490_tmpvar_phold = bevl_numargs.bem_subtract_1(bevp_maxDynArgs);
bevt_491_tmpvar_phold = bevo_99;
bevl_spillArgsLen = bevt_490_tmpvar_phold.bem_add_1(bevt_491_tmpvar_phold);
bevt_492_tmpvar_phold = bevl_spillArgsLen.bem_greater_1(bevp_maxSpillArgsLen);
if (bevt_492_tmpvar_phold.bevi_bool) /* Line: 1588 */ {
bevp_maxSpillArgsLen = bevl_spillArgsLen;
} /* Line: 1589 */
bevp_methodBody.bem_addValue_1(bevl_spillArgs);
bevl_callArgSpill = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_374));
} /* Line: 1592 */
bevt_494_tmpvar_phold = bevo_100;
bevt_493_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_494_tmpvar_phold);
if (bevt_493_tmpvar_phold.bevi_bool) /* Line: 1594 */ {
bevl_fc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_375));
} /* Line: 1595 */
 else  /* Line: 1596 */ {
bevl_fc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_376));
} /* Line: 1597 */
bevt_508_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_507_tmpvar_phold = (BEC_2_4_6_TextString) bevt_508_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_509_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_377));
bevt_506_tmpvar_phold = (BEC_2_4_6_TextString) bevt_507_tmpvar_phold.bem_addValue_1(bevt_509_tmpvar_phold);
bevt_505_tmpvar_phold = (BEC_2_4_6_TextString) bevt_506_tmpvar_phold.bem_addValue_1(bevl_dm);
bevt_510_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_378));
bevt_504_tmpvar_phold = (BEC_2_4_6_TextString) bevt_505_tmpvar_phold.bem_addValue_1(bevt_510_tmpvar_phold);
bevt_514_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_513_tmpvar_phold = bevt_514_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_512_tmpvar_phold = bevt_513_tmpvar_phold.bemd_0(287040793, BEL_4_Base.bevn_hashGet_0);
bevt_511_tmpvar_phold = bevt_512_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_503_tmpvar_phold = (BEC_2_4_6_TextString) bevt_504_tmpvar_phold.bem_addValue_1(bevt_511_tmpvar_phold);
bevt_515_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_379));
bevt_502_tmpvar_phold = (BEC_2_4_6_TextString) bevt_503_tmpvar_phold.bem_addValue_1(bevt_515_tmpvar_phold);
bevt_501_tmpvar_phold = (BEC_2_4_6_TextString) bevt_502_tmpvar_phold.bem_addValue_1(bevp_libEmitName);
bevt_516_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_380));
bevt_500_tmpvar_phold = (BEC_2_4_6_TextString) bevt_501_tmpvar_phold.bem_addValue_1(bevt_516_tmpvar_phold);
bevt_518_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_517_tmpvar_phold = bevt_518_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_499_tmpvar_phold = (BEC_2_4_6_TextString) bevt_500_tmpvar_phold.bem_addValue_1(bevt_517_tmpvar_phold);
bevt_498_tmpvar_phold = (BEC_2_4_6_TextString) bevt_499_tmpvar_phold.bem_addValue_1(bevl_fc);
bevt_497_tmpvar_phold = (BEC_2_4_6_TextString) bevt_498_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_496_tmpvar_phold = (BEC_2_4_6_TextString) bevt_497_tmpvar_phold.bem_addValue_1(bevl_callArgSpill);
bevt_519_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_381));
bevt_495_tmpvar_phold = (BEC_2_4_6_TextString) bevt_496_tmpvar_phold.bem_addValue_1(bevt_519_tmpvar_phold);
bevt_495_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1599 */
if (bevl_isOnce.bevi_bool) /* Line: 1602 */ {
bevt_520_tmpvar_phold = bevl_onceDeced.bem_not_0();
if (bevt_520_tmpvar_phold.bevi_bool) /* Line: 1603 */ {
bevt_522_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_382));
bevt_521_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_522_tmpvar_phold);
bevt_521_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_524_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_383));
bevt_523_tmpvar_phold = this.bem_emitting_1(bevt_524_tmpvar_phold);
if (bevt_523_tmpvar_phold.bevi_bool) /* Line: 1606 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1606 */ {
bevt_526_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_384));
bevt_525_tmpvar_phold = this.bem_emitting_1(bevt_526_tmpvar_phold);
if (bevt_525_tmpvar_phold.bevi_bool) /* Line: 1606 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1606 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1606 */
if (bevt_22_tmpvar_anchor.bevi_bool) /* Line: 1606 */ {
bevt_528_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_385));
bevt_527_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_528_tmpvar_phold);
bevt_527_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1608 */
} /* Line: 1606 */
bevp_methodBody.bem_addValue_1(bevl_postOnceCallAssign);
bevt_529_tmpvar_phold = bevl_onceDeced.bem_not_0();
if (bevt_529_tmpvar_phold.bevi_bool) /* Line: 1612 */ {
bevt_531_tmpvar_phold = bevl_odec.bem_isEmptyGet_0();
bevt_530_tmpvar_phold = bevt_531_tmpvar_phold.bem_not_0();
if (bevt_530_tmpvar_phold.bevi_bool) /* Line: 1613 */ {
bevt_534_tmpvar_phold = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevl_odec);
bevt_533_tmpvar_phold = (BEC_2_4_6_TextString) bevt_534_tmpvar_phold.bem_addValue_1(bevl_ovar);
bevt_535_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_386));
bevt_532_tmpvar_phold = (BEC_2_4_6_TextString) bevt_533_tmpvar_phold.bem_addValue_1(bevt_535_tmpvar_phold);
bevt_532_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1614 */
} /* Line: 1613 */
} /* Line: 1612 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_doInitializeIt_1(BEC_2_4_6_TextString beva_nc) {
BEC_2_4_6_TextString bevl_ii = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevl_ii = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_387));
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_388));
bevt_0_tmpvar_phold = this.bem_emitting_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1623 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(67, bels_389));
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) bevl_ii.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(beva_nc);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_390));
bevt_2_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1624 */
 else  /* Line: 1625 */ {
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bels_391));
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) bevl_ii.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(beva_nc);
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_392));
bevt_6_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
} /* Line: 1626 */
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_393));
bevl_ii.bem_addValue_1(bevt_10_tmpvar_phold);
return bevl_ii;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_394));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
return (BEC_2_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_101;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_102;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_103;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_104;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_105;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_106;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 1645 */ {
bevt_6_tmpvar_phold = bevo_107;
bevt_8_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_108;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(beva_belsName);
bevt_10_tmpvar_phold = bevo_109;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_lisz);
bevt_11_tmpvar_phold = bevo_110;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /* Line: 1646 */
bevt_18_tmpvar_phold = bevo_111;
bevt_20_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_112;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(beva_lisz);
bevt_22_tmpvar_phold = bevo_113;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_22_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(beva_belsName);
bevt_23_tmpvar_phold = bevo_114;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
return bevt_12_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bels_409));
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_410));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_3_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_411));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isOnceAssign_1(BEC_2_5_4_BuildNode beva_asnCall) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_asnCall.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1362267230, BEL_4_Base.bevn_isManyGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 1667 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 1668 */
bevt_5_tmpvar_phold = beva_asnCall.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1478834556, BEL_4_Base.bevn_isOnceGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 1670 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1670 */ {
bevt_6_tmpvar_phold = beva_asnCall.bem_isLiteralOnceGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1670 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1670 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1670 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1670 */ {
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 1671 */
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptEmit_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_3_tmpvar_phold = this.bem_emitLangGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_3_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1677 */ {
bevt_6_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevt_4_tmpvar_phold = this.bem_emitReplace_1((BEC_2_4_6_TextString) bevt_5_tmpvar_phold);
bevp_methodBody.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 1678 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitReplace_1(BEC_2_4_6_TextString beva_text) {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_4_9_TextTokenizer bevl_emitTok = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_4_6_TextString bevl_rtext = null;
BEC_2_4_6_TextString bevl_tok = null;
BEC_2_4_6_TextString bevl_type = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevl_rep = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_412));
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_emitTok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevl_emitTok.bem_tokenize_1(beva_text);
bevt_6_tmpvar_phold = bevo_115;
bevt_5_tmpvar_phold = beva_text.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 1686 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1686 */ {
bevt_9_tmpvar_phold = bevo_116;
bevt_8_tmpvar_phold = beva_text.bem_has_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_not_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1686 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1686 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1686 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1686 */ {
return beva_text;
} /* Line: 1687 */
bevl_rtext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpvar_loop = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 1690 */ {
bevt_10_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 1690 */ {
bevl_tok = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_12_tmpvar_phold = bevo_117;
bevt_11_tmpvar_phold = bevl_state.bem_equals_1(bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 1691 */ {
bevt_14_tmpvar_phold = bevo_118;
bevt_13_tmpvar_phold = bevl_tok.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 1691 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1691 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1691 */
 else  /* Line: 1691 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1691 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 1693 */
 else  /* Line: 1691 */ {
bevt_16_tmpvar_phold = bevo_119;
bevt_15_tmpvar_phold = bevl_state.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 1694 */ {
bevt_18_tmpvar_phold = bevo_120;
bevt_17_tmpvar_phold = bevl_tok.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 1695 */ {
bevl_type = bevo_121;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 1697 */
} /* Line: 1695 */
 else  /* Line: 1691 */ {
bevt_20_tmpvar_phold = bevo_122;
bevt_19_tmpvar_phold = bevl_state.bem_equals_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 1699 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
} /* Line: 1701 */
 else  /* Line: 1691 */ {
bevt_22_tmpvar_phold = bevo_123;
bevt_21_tmpvar_phold = bevl_state.bem_equals_1(bevt_22_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 1702 */ {
bevl_value = bevl_tok;
bevt_24_tmpvar_phold = bevo_124;
bevt_23_tmpvar_phold = bevl_type.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 1704 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevl_tok);
bevl_rep = this.bem_getEmitName_1(bevl_np);
bevl_rtext.bem_addValue_1(bevl_rep);
} /* Line: 1709 */
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 1711 */
 else  /* Line: 1691 */ {
bevt_26_tmpvar_phold = bevo_125;
bevt_25_tmpvar_phold = bevl_state.bem_equals_1(bevt_26_tmpvar_phold);
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 1712 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 1714 */
 else  /* Line: 1715 */ {
bevl_rtext.bem_addValue_1(bevl_tok);
} /* Line: 1716 */
} /* Line: 1691 */
} /* Line: 1691 */
} /* Line: 1691 */
} /* Line: 1691 */
} /* Line: 1691 */
 else  /* Line: 1690 */ {
break;
} /* Line: 1690 */
} /* Line: 1690 */
return bevl_rtext;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acceptIfEmit_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevl_include = null;
BEC_2_5_4_LogicBool bevl_negate = null;
BEC_2_4_6_TextString bevl_flag = null;
BEC_2_5_4_LogicBool bevl_foundFlag = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_12_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_31_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_32_tmpvar_phold = null;
bevl_include = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_419));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 1724 */ {
bevl_negate = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1725 */
 else  /* Line: 1726 */ {
bevl_negate = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1727 */
if (bevl_negate.bevi_bool) /* Line: 1729 */ {
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_10_tmpvar_phold = this.bem_emitLangGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_10_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1730 */ {
bevl_include = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1731 */
bevt_12_tmpvar_phold = bevp_build.bem_emitFlagsGet_0();
if (bevt_12_tmpvar_phold == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 1733 */ {
bevt_13_tmpvar_phold = bevp_build.bem_emitFlagsGet_0();
bevt_0_tmpvar_loop = bevt_13_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 1734 */ {
bevt_14_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 1734 */ {
bevl_flag = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_17_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_flag);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 1735 */ {
bevl_include = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1736 */
} /* Line: 1735 */
 else  /* Line: 1734 */ {
break;
} /* Line: 1734 */
} /* Line: 1734 */
} /* Line: 1734 */
} /* Line: 1733 */
 else  /* Line: 1740 */ {
bevl_foundFlag = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_19_tmpvar_phold = bevp_build.bem_emitFlagsGet_0();
if (bevt_19_tmpvar_phold == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 1742 */ {
bevt_20_tmpvar_phold = bevp_build.bem_emitFlagsGet_0();
bevt_1_tmpvar_loop = bevt_20_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 1743 */ {
bevt_21_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 1743 */ {
bevl_flag = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_24_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_flag);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 1744 */ {
bevl_foundFlag = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1745 */
} /* Line: 1744 */
 else  /* Line: 1743 */ {
break;
} /* Line: 1743 */
} /* Line: 1743 */
} /* Line: 1743 */
bevt_25_tmpvar_phold = bevl_foundFlag.bem_not_0();
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 1749 */ {
bevt_29_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_30_tmpvar_phold = this.bem_emitLangGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_30_tmpvar_phold);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_26_tmpvar_phold != null && bevt_26_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_26_tmpvar_phold).bevi_bool) /* Line: 1749 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1749 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1749 */
 else  /* Line: 1749 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1749 */ {
bevl_include = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1750 */
} /* Line: 1749 */
if (bevl_include.bevi_bool) /* Line: 1753 */ {
bevt_31_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_31_tmpvar_phold;
} /* Line: 1754 */
bevt_32_tmpvar_phold = beva_node.bem_nextPeerGet_0();
return bevt_32_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_46_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1760 */ {
this.bem_acceptClass_1(beva_node);
} /* Line: 1761 */
 else  /* Line: 1760 */ {
bevt_4_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_5_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1762 */ {
this.bem_acceptMethod_1(beva_node);
} /* Line: 1763 */
 else  /* Line: 1760 */ {
bevt_7_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_8_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_equals_1(bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1764 */ {
this.bem_acceptRbraces_1(beva_node);
} /* Line: 1765 */
 else  /* Line: 1760 */ {
bevt_10_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_11_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 1766 */ {
this.bem_acceptEmit_1(beva_node);
} /* Line: 1767 */
 else  /* Line: 1760 */ {
bevt_13_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_14_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 1768 */ {
this.bem_addStackLines_1(beva_node);
bevt_15_tmpvar_phold = this.bem_acceptIfEmit_1(beva_node);
return (BEC_2_5_4_BuildNode) bevt_15_tmpvar_phold;
} /* Line: 1770 */
 else  /* Line: 1760 */ {
bevt_17_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_18_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 1771 */ {
this.bem_acceptCall_1(beva_node);
} /* Line: 1772 */
 else  /* Line: 1760 */ {
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 1773 */ {
this.bem_acceptBraces_1(beva_node);
} /* Line: 1774 */
 else  /* Line: 1760 */ {
bevt_23_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_24_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 1775 */ {
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_420));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_26_tmpvar_phold);
bevt_25_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1776 */
 else  /* Line: 1760 */ {
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_equals_1(bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 1777 */ {
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_421));
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_30_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1778 */
 else  /* Line: 1760 */ {
bevt_33_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_equals_1(bevt_34_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 1779 */ {
bevt_35_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_422));
bevp_methodBody.bem_addValue_1(bevt_35_tmpvar_phold);
} /* Line: 1780 */
 else  /* Line: 1760 */ {
bevt_37_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_TRYGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_equals_1(bevt_38_tmpvar_phold);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 1781 */ {
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_423));
bevp_methodBody.bem_addValue_1(bevt_39_tmpvar_phold);
} /* Line: 1782 */
 else  /* Line: 1760 */ {
bevt_41_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_equals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 1783 */ {
this.bem_acceptCatch_1(beva_node);
} /* Line: 1784 */
 else  /* Line: 1760 */ {
bevt_44_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_45_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 1785 */ {
this.bem_acceptIf_1(beva_node);
} /* Line: 1786 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
} /* Line: 1760 */
this.bem_addStackLines_1(beva_node);
bevt_46_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_46_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addStackLines_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_cnode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1793 */ {
} /* Line: 1793 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildStackLines_1(BEC_2_5_4_BuildNode beva_node) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1802 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_424));
} /* Line: 1803 */
 else  /* Line: 1802 */ {
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_425));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 1804 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_426));
} /* Line: 1805 */
 else  /* Line: 1802 */ {
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_427));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_10_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1806 */ {
bevl_tcall = this.bem_superNameGet_0();
} /* Line: 1807 */
 else  /* Line: 1808 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_tcall = this.bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_tmpvar_phold);
} /* Line: 1809 */
} /* Line: 1802 */
} /* Line: 1802 */
return bevl_tcall;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_formRTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1816 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_428));
} /* Line: 1817 */
 else  /* Line: 1816 */ {
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_429));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 1818 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_430));
} /* Line: 1819 */
 else  /* Line: 1816 */ {
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_431));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_10_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1820 */ {
bevl_tcall = this.bem_superNameGet_0();
} /* Line: 1821 */
 else  /* Line: 1822 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_tcall = this.bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_tmpvar_phold);
} /* Line: 1823 */
} /* Line: 1816 */
} /* Line: 1816 */
return bevl_tcall;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_end_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_end_1(beva_transi);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_432));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_433));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_434));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_435));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_436));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_mangleName_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_4_6_TextString bevl_pref = null;
BEC_2_4_6_TextString bevl_suf = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
bevl_pref = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_437));
bevl_suf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_438));
bevt_1_tmpvar_phold = beva_np.bem_stepsGet_0();
bevt_0_tmpvar_loop = bevt_1_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 1860 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 1860 */ {
bevl_step = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevo_126;
bevt_3_tmpvar_phold = bevl_pref.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1861 */ {
bevt_5_tmpvar_phold = bevo_127;
bevl_pref = bevl_pref.bem_add_1(bevt_5_tmpvar_phold);
} /* Line: 1861 */
 else  /* Line: 1863 */ {
bevt_8_tmpvar_phold = beva_np.bem_stepsGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_sizeGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_toString_0();
bevt_9_tmpvar_phold = bevo_128;
bevl_pref = bevt_6_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevl_suf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_442));
} /* Line: 1863 */
bevt_10_tmpvar_phold = bevl_step.bem_sizeGet_0();
bevl_pref = bevl_pref.bem_add_1(bevt_10_tmpvar_phold);
bevl_suf = bevl_suf.bem_add_1(bevl_step);
} /* Line: 1865 */
 else  /* Line: 1860 */ {
break;
} /* Line: 1860 */
} /* Line: 1860 */
bevt_11_tmpvar_phold = bevl_pref.bem_add_1(bevl_suf);
return bevt_11_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getEmitName_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_129;
bevt_2_tmpvar_phold = this.bem_mangleName_1(beva_np);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_130;
bevt_1_tmpvar_phold = beva_nameSpace.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_emitName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_131;
bevt_2_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classConfGet_0() {
return bevp_classConf;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_classConfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classConf = (BEC_2_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_parentConfGet_0() {
return bevp_parentConf;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parentConfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parentConf = (BEC_2_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fileExtGet_0() {
return bevp_fileExt;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fileExt = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_exceptDecGet_0() {
return bevp_exceptDec;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_exceptDecSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exceptDec = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_qGet_0() {
return bevp_q;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_qSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_q = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_ccCacheGet_0() {
return bevp_ccCache;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ccCacheSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccCache = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_objectNpGet_0() {
return bevp_objectNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_objectNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_boolNpGet_0() {
return bevp_boolNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_boolNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_boolNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_intNpGet_0() {
return bevp_intNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_intNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_intNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_floatNpGet_0() {
return bevp_floatNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_floatNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_floatNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_stringNpGet_0() {
return bevp_stringNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_stringNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_stringNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_trueValueGet_0() {
return bevp_trueValue;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_trueValueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_trueValue = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_falseValueGet_0() {
return bevp_falseValue;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_falseValueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_falseValue = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_instanceEqualGet_0() {
return bevp_instanceEqual;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_instanceEqualSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instanceEqual = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_instanceNotEqualGet_0() {
return bevp_instanceNotEqual;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_instanceNotEqualSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instanceNotEqual = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libEmitNameGet_0() {
return bevp_libEmitName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_libEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libEmitName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fullLibEmitNameGet_0() {
return bevp_fullLibEmitName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fullLibEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fullLibEmitName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_libEmitPathGet_0() {
return bevp_libEmitPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_libEmitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libEmitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_methodBodyGet_0() {
return bevp_methodBody;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodBody = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lastMethodBodySizeGet_0() {
return bevp_lastMethodBodySize;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastMethodBodySizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodBodySize = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lastMethodBodyLinesGet_0() {
return bevp_lastMethodBodyLines;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastMethodBodyLinesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodBodyLines = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_methodCallsGet_0() {
return bevp_methodCalls;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodCallsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodCalls = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_methodCatchGet_0() {
return bevp_methodCatch;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodCatchSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodCatch = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_maxDynArgsGet_0() {
return bevp_maxDynArgs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_maxDynArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxDynArgs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_maxSpillArgsLenGet_0() {
return bevp_maxSpillArgsLen;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_maxSpillArgsLenSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxSpillArgsLen = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_lastCallGet_0() {
return bevp_lastCall;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastCallSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastCall = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_callNamesGet_0() {
return bevp_callNames;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_callNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_callNames = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_objectCcGet_0() {
return bevp_objectCc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectCcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_objectCc = (BEC_2_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_boolCcGet_0() {
return bevp_boolCc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_boolCcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_boolCc = (BEC_2_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_instOfGet_0() {
return bevp_instOf;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_instOfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instOf = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_smnlcsGet_0() {
return bevp_smnlcs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_smnlcsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_smnlcs = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_smnlecsGet_0() {
return bevp_smnlecs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_smnlecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_smnlecs = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_classesInDepthOrderGet_0() {
return bevp_classesInDepthOrder;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_classesInDepthOrderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classesInDepthOrder = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lineCountGet_0() {
return bevp_lineCount;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lineCount = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_methodsGet_0() {
return bevp_methods;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methods = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_classCallsGet_0() {
return bevp_classCalls;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_classCallsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classCalls = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lastMethodsSizeGet_0() {
return bevp_lastMethodsSize;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastMethodsSizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodsSize = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lastMethodsLinesGet_0() {
return bevp_lastMethodsLines;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastMethodsLinesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodsLines = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_mnodeGet_0() {
return bevp_mnode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mnodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mnode = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_returnTypeGet_0() {
return bevp_returnType;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_returnTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_returnType = (BEC_2_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_6_BuildMtdSyn bem_msynGet_0() {
return bevp_msyn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_msynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_preClassGet_0() {
return bevp_preClass;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_preClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_preClass = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_classEmitsGet_0() {
return bevp_classEmits;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_classEmitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classEmits = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_onceDecsGet_0() {
return bevp_onceDecs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_onceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_onceDecs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_onceCountGet_0() {
return bevp_onceCount;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_onceCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_onceCount = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_propertyDecsGet_0() {
return bevp_propertyDecs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_propertyDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_propertyDecs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_cnodeGet_0() {
return bevp_cnode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_cnodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cnode = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildClassSyn bem_csynGet_0() {
return bevp_csyn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_csynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_csyn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_dynMethodsGet_0() {
return bevp_dynMethods;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_dynMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynMethods = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_ccMethodsGet_0() {
return bevp_ccMethods;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ccMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccMethods = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_superCallsGet_0() {
return bevp_superCalls;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_superCallsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_superCalls = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_nativeCSlotsGet_0() {
return bevp_nativeCSlots;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nativeCSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nativeCSlots = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_inFilePathedGet_0() {
return bevp_inFilePathed;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inFilePathedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inFilePathed = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {78, 93, 95, 98, 101, 102, 103, 104, 105, 109, 110, 112, 113, 116, 117, 118, 120, 121, 122, 123, 124, 126, 127, 133, 136, 137, 140, 141, 143, 148, 149, 155, 159, 163, 167, 168, 169, 170, 0, 170, 171, 172, 173, 174, 177, 178, 180, 184, 185, 186, 187, 188, 190, 194, 0, 194, 0, 195, 197, 202, 203, 205, 206, 207, 208, 210, 211, 213, 214, 215, 216, 218, 219, 220, 222, 225, 226, 230, 233, 234, 244, 245, 246, 248, 250, 251, 252, 253, 254, 256, 259, 260, 261, 262, 265, 267, 269, 0, 269, 270, 271, 0, 271, 272, 276, 278, 280, 281, 285, 288, 292, 293, 294, 297, 298, 301, 302, 303, 306, 307, 311, 314, 315, 316, 319, 320, 326, 327, 329, 334, 335, 0, 335, 337, 338, 339, 0, 339, 0, 339, 0, 343, 345, 346, 348, 349, 352, 353, 354, 356, 360, 362, 364, 363, 364, 365, 368, 369, 371, 372, 373, 375, 377, 379, 380, 381, 382, 383, 384, 386, 387, 388, 390, 392, 393, 395, 397, 399, 400, 401, 402, 403, 404, 406, 407, 408, 411, 414, 415, 418, 419, 420, 423, 424, 427, 428, 429, 432, 433, 434, 438, 441, 445, 446, 450, 455, 457, 458, 460, 464, 468, 472, 476, 480, 484, 488, 492, 496, 500, 504, 505, 507, 512, 514, 515, 516, 518, 519, 520, 522, 523, 524, 525, 527, 528, 529, 530, 531, 533, 534, 0, 534, 536, 539, 540, 541, 542, 544, 546, 547, 549, 550, 551, 552, 555, 556, 557, 558, 562, 0, 562, 563, 564, 567, 569, 0, 569, 571, 572, 576, 577, 578, 579, 580, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 0, 591, 0, 593, 595, 597, 598, 601, 602, 604, 605, 608, 613, 617, 621, 625, 631, 0, 631, 0, 633, 636, 640, 645, 647, 648, 649, 650, 657, 658, 659, 660, 661, 662, 664, 666, 671, 672, 674, 679, 680, 681, 685, 689, 694, 695, 698, 700, 702, 703, 705, 706, 0, 706, 707, 0, 708, 710, 712, 713, 714, 716, 718, 719, 720, 722, 725, 729, 731, 732, 734, 738, 739, 741, 744, 746, 752, 754, 756, 761, 762, 763, 765, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 784, 785, 786, 787, 788, 789, 794, 795, 796, 798, 802, 803, 804, 0, 804, 806, 807, 808, 813, 0, 814, 815, 816, 822, 823, 824, 825, 826, 827, 828, 829, 831, 836, 837, 838, 0, 838, 839, 840, 841, 842, 843, 844, 845, 847, 848, 849, 850, 852, 853, 854, 855, 856, 858, 864, 0, 864, 865, 867, 868, 870, 872, 873, 874, 875, 0, 876, 877, 878, 880, 881, 882, 884, 885, 887, 888, 0, 888, 889, 890, 891, 0, 895, 0, 896, 898, 900, 0, 900, 901, 903, 904, 906, 907, 908, 0, 908, 909, 910, 0, 911, 913, 915, 916, 918, 920, 921, 923, 925, 927, 929, 932, 935, 938, 941, 942, 943, 946, 948, 950, 958, 959, 960, 961, 962, 0, 962, 964, 965, 966, 967, 968, 969, 970, 971, 974, 977, 981, 982, 984, 988, 989, 990, 991, 993, 995, 996, 998, 1001, 1003, 1006, 1008, 1010, 1015, 1016, 1021, 1023, 1024, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1034, 1035, 1037, 1039, 1041, 1046, 1047, 1049, 1054, 1056, 1057, 1059, 1062, 1066, 1067, 1069, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1079, 1084, 1088, 1092, 1097, 1101, 1102, 0, 1103, 1105, 1109, 1110, 1111, 0, 1111, 0, 1111, 0, 1111, 0, 1113, 1122, 0, 1123, 1124, 1125, 1126, 1127, 0, 1127, 0, 1130, 1133, 1134, 1137, 1138, 1139, 1140, 1144, 0, 1144, 1145, 1147, 1148, 1150, 1151, 1152, 1153, 1156, 1157, 1158, 1161, 1162, 1163, 1165, 0, 1165, 0, 1167, 1173, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1181, 1187, 1191, 1192, 0, 1192, 0, 1193, 1195, 1197, 0, 1198, 1200, 1202, 1204, 1208, 1213, 1214, 1215, 1217, 1218, 1219, 1221, 1224, 1226, 1231, 1232, 0, 1233, 1235, 1237, 1244, 1249, 1250, 1252, 1253, 1255, 1256, 1258, 1259, 1260, 1262, 1266, 1270, 1274, 1278, 1283, 1285, 1287, 1291, 1292, 1293, 1295, 1298, 0, 1299, 1300, 1301, 1300, 1303, 1304, 0, 1305, 1306, 1307, 1308, 1309, 1313, 1314, 1316, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 0, 1325, 0, 1326, 0, 1326, 0, 1333, 1334, 1335, 1338, 1339, 1340, 1342, 1343, 1345, 1346, 1347, 1348, 1349, 1351, 1352, 1354, 1355, 1356, 1358, 1359, 1360, 0, 1360, 0, 1360, 0, 1360, 0, 1362, 1365, 1366, 1369, 1370, 1371, 1372, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1388, 1389, 1391, 1392, 1393, 1394, 1395, 1397, 1398, 1399, 1400, 0, 1403, 0, 1403, 0, 1404, 1405, 1407, 0, 1408, 1410, 1413, 1414, 1417, 1421, 1423, 0, 1424, 1427, 1428, 1431, 0, 1432, 0, 1432, 0, 1433, 1434, 1435, 1437, 1438, 1440, 1445, 1447, 1449, 1451, 1457, 1458, 1459, 1461, 1463, 0, 1467, 0, 1467, 0, 1468, 1472, 1473, 1474, 1475, 1477, 0, 1482, 0, 1484, 1485, 1486, 1487, 1488, 1489, 1491, 1492, 1493, 1494, 1496, 1498, 1499, 1501, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1512, 1513, 1515, 1517, 1518, 1519, 1520, 1521, 1523, 1527, 1530, 1532, 1534, 1536, 1537, 1539, 1540, 0, 1540, 1541, 1543, 1546, 1547, 1549, 1553, 1555, 1558, 1559, 1560, 1563, 1566, 1567, 0, 1567, 0, 1569, 1571, 1575, 1576, 1578, 1582, 1583, 1584, 1586, 1587, 1588, 1589, 1591, 1592, 1594, 1595, 1597, 1599, 1603, 1605, 1606, 0, 1606, 0, 1608, 1611, 1612, 1613, 1614, 1622, 1623, 1624, 1626, 1628, 1629, 1633, 1637, 1641, 1646, 1648, 1652, 1663, 1667, 1668, 1670, 0, 1670, 0, 1671, 1673, 1677, 1678, 1683, 1684, 1685, 1686, 0, 1686, 0, 1687, 1689, 1690, 0, 1690, 1691, 0, 1693, 1694, 1695, 1696, 1697, 1699, 1701, 1702, 1703, 1704, 1706, 1707, 1709, 1711, 1712, 1714, 1716, 1719, 1723, 1724, 1725, 1727, 1730, 1731, 1733, 1734, 0, 1734, 1735, 1736, 1741, 1742, 1743, 0, 1743, 1744, 1745, 1749, 0, 1750, 1754, 1756, 1760, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1770, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1783, 1784, 1785, 1786, 1788, 1789, 1793, 1802, 1803, 1804, 1805, 1806, 1807, 1809, 1811, 1816, 1817, 1818, 1819, 1820, 1821, 1823, 1825, 1829, 1833, 1837, 1841, 1845, 1849, 1854, 1858, 1859, 1860, 0, 1860, 1861, 1863, 1864, 1865, 1867, 1871, 1875, 1879, 0};
public static new int[] bevs_smnlec
 = new int[] {664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 665, 665, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664};
/* BEGIN LINEINFO 
assign 1 78 664
assign 1 93 664
nlGet 0 93 664
assign 1 95 664
new 0 95 664
assign 1 95 664
quoteGet 0 95 664
assign 1 98 664
new 0 98 664
assign 1 101 664
new 0 101 664
assign 1 101 664
new 1 101 664
assign 1 102 664
new 0 102 664
assign 1 102 664
new 1 102 664
assign 1 103 664
new 0 103 664
assign 1 103 664
new 1 103 664
assign 1 104 664
new 0 104 664
assign 1 104 664
new 1 104 664
assign 1 105 664
new 0 105 664
assign 1 105 664
new 1 105 664
assign 1 109 664
new 0 109 664
assign 1 110 664
new 0 110 664
assign 1 112 664
new 0 112 664
assign 1 113 664
new 0 113 664
assign 1 116 664
libNameGet 0 116 664
assign 1 116 664
libEmitName 1 116 664
assign 1 117 664
libNameGet 0 117 664
assign 1 117 664
fullLibEmitName 1 117 664
assign 1 118 664
emitPathGet 0 118 664
assign 1 118 664
copy 0 118 664
assign 1 118 664
emitLangGet 0 118 664
assign 1 118 664
addStep 1 118 664
assign 1 118 664
new 0 118 664
assign 1 118 664
addStep 1 118 664
assign 1 118 664
libNameGet 0 118 664
assign 1 118 664
libEmitName 1 118 664
assign 1 118 664
addStep 1 118 664
assign 1 118 664
add 1 118 664
assign 1 118 664
addStep 1 118 664
assign 1 120 664
new 0 120 664
assign 1 121 664
new 0 121 664
assign 1 122 664
new 0 122 664
assign 1 123 664
new 0 123 664
assign 1 124 664
new 0 124 664
assign 1 126 664
new 0 126 664
assign 1 127 664
new 0 127 664
assign 1 133 664
new 0 133 664
assign 1 136 664
getClassConfig 1 136 664
assign 1 137 664
getClassConfig 1 137 664
assign 1 140 664
new 0 140 664
assign 1 140 664
emitting 1 140 664
assign 1 141 664
new 0 141 664
assign 1 143 664
new 0 143 664
assign 1 148 664
new 0 148 664
assign 1 149 664
new 0 149 664
assign 1 155 664
new 0 155 664
assign 1 155 664
add 1 155 664
return 1 155 664
assign 1 159 664
new 0 159 664
assign 1 159 664
sizeGet 0 159 664
assign 1 159 664
add 1 159 664
assign 1 159 664
new 0 159 664
assign 1 159 664
add 1 159 664
assign 1 159 664
add 1 159 664
return 1 159 664
assign 1 163 664
libNs 1 163 664
assign 1 163 664
new 0 163 664
assign 1 163 664
add 1 163 664
assign 1 163 664
libEmitName 1 163 664
assign 1 163 664
add 1 163 664
return 1 163 664
assign 1 167 664
toString 0 167 664
assign 1 168 664
get 1 168 664
assign 1 169 664
undef 1 169 664
assign 1 170 664
usedLibrarysGet 0 170 664
assign 1 170 664
iteratorGet 0 0 664
assign 1 170 664
hasNextGet 0 170 664
assign 1 170 664
nextGet 0 170 664
assign 1 171 664
emitPathGet 0 171 664
assign 1 171 664
libNameGet 0 171 664
assign 1 171 664
new 4 171 664
assign 1 172 664
synPathGet 0 172 664
assign 1 172 664
fileGet 0 172 664
assign 1 172 664
existsGet 0 172 664
put 2 173 664
return 1 174 664
assign 1 177 664
emitPathGet 0 177 664
assign 1 177 664
libNameGet 0 177 664
assign 1 177 664
new 4 177 664
put 2 178 664
return 1 180 664
assign 1 184 664
toString 0 184 664
assign 1 185 664
get 1 185 664
assign 1 186 664
undef 1 186 664
assign 1 187 664
emitPathGet 0 187 664
assign 1 187 664
libNameGet 0 187 664
assign 1 187 664
new 4 187 664
put 2 188 664
return 1 190 664
assign 1 194 664
printStepsGet 0 194 664
assign 1 0 664
assign 1 194 664
printPlacesGet 0 194 664
assign 1 0 664
assign 1 0 664
assign 1 195 664
new 0 195 664
assign 1 195 664
heldGet 0 195 664
assign 1 195 664
nameGet 0 195 664
assign 1 195 664
add 1 195 664
print 0 195 664
assign 1 197 664
transUnitGet 0 197 664
assign 1 197 664
new 2 197 664
assign 1 202 664
printStepsGet 0 202 664
assign 1 203 664
new 0 203 664
echo 0 203 664
assign 1 205 664
new 0 205 664
emitterSet 1 206 664
buildSet 1 207 664
traverse 1 208 664
assign 1 210 664
printStepsGet 0 210 664
assign 1 211 664
new 0 211 664
echo 0 211 664
assign 1 213 664
new 0 213 664
emitterSet 1 214 664
buildSet 1 215 664
traverse 1 216 664
assign 1 218 664
printStepsGet 0 218 664
assign 1 219 664
new 0 219 664
echo 0 219 664
assign 1 220 664
new 0 220 664
print 0 220 664
assign 1 222 664
printStepsGet 0 222 664
traverse 1 225 664
assign 1 226 664
printStepsGet 0 226 664
assign 1 230 664
printStepsGet 0 230 664
buildStackLines 1 233 664
assign 1 234 664
printStepsGet 0 234 664
assign 1 244 664
new 0 244 664
assign 1 245 664
emitDataGet 0 245 664
assign 1 245 664
parseOrderClassNamesGet 0 245 664
assign 1 245 664
iteratorGet 0 245 664
assign 1 245 664
hasNextGet 0 245 664
assign 1 246 664
nextGet 0 246 664
assign 1 248 664
emitDataGet 0 248 664
assign 1 248 664
classesGet 0 248 664
assign 1 248 664
get 1 248 664
assign 1 250 664
heldGet 0 250 664
assign 1 250 664
synGet 0 250 664
assign 1 250 664
depthGet 0 250 664
assign 1 251 664
get 1 251 664
assign 1 252 664
undef 1 252 664
assign 1 253 664
new 0 253 664
put 2 254 664
addValue 1 256 664
assign 1 259 664
new 0 259 664
assign 1 260 664
keyIteratorGet 0 260 664
assign 1 260 664
hasNextGet 0 260 664
assign 1 261 664
nextGet 0 261 664
addValue 1 262 664
assign 1 265 664
sort 0 265 664
assign 1 267 664
new 0 267 664
assign 1 269 664
arrayIteratorGet 0 0 664
assign 1 269 664
hasNextGet 0 269 664
assign 1 269 664
nextGet 0 269 664
assign 1 270 664
get 1 270 664
assign 1 271 664
arrayIteratorGet 0 0 664
assign 1 271 664
hasNextGet 0 271 664
assign 1 271 664
nextGet 0 271 664
addValue 1 272 664
assign 1 276 664
iteratorGet 0 276 664
assign 1 276 664
hasNextGet 0 276 664
assign 1 278 664
nextGet 0 278 664
assign 1 280 664
heldGet 0 280 664
assign 1 280 664
namepathGet 0 280 664
assign 1 280 664
getLocalClassConfig 1 280 664
assign 1 281 664
printStepsGet 0 281 664
complete 1 285 664
assign 1 288 664
getClassOutput 0 288 664
assign 1 292 664
beginNs 0 292 664
assign 1 293 664
countLines 1 293 664
addValue 1 293 664
write 1 294 664
assign 1 297 664
countLines 1 297 664
addValue 1 297 664
write 1 298 664
assign 1 301 664
classBeginGet 0 301 664
assign 1 302 664
countLines 1 302 664
addValue 1 302 664
write 1 303 664
assign 1 306 664
countLines 1 306 664
addValue 1 306 664
write 1 307 664
assign 1 311 664
writeOnceDecs 2 311 664
addValue 1 311 664
assign 1 314 664
initialDecGet 0 314 664
assign 1 315 664
countLines 1 315 664
addValue 1 315 664
write 1 316 664
assign 1 319 664
countLines 1 319 664
addValue 1 319 664
write 1 320 664
assign 1 326 664
new 0 326 664
assign 1 327 664
new 0 327 664
assign 1 329 664
new 0 329 664
assign 1 334 664
new 0 334 664
assign 1 334 664
addValue 1 334 664
assign 1 335 664
arrayIteratorGet 0 0 664
assign 1 335 664
hasNextGet 0 335 664
assign 1 335 664
nextGet 0 335 664
assign 1 337 664
nlecGet 0 337 664
addValue 1 337 664
assign 1 338 664
nlecGet 0 338 664
incrementValue 0 338 664
assign 1 339 664
undef 1 339 664
assign 1 0 664
assign 1 339 664
nlcGet 0 339 664
assign 1 339 664
notEquals 1 339 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 339 664
nlecGet 0 339 664
assign 1 339 664
notEquals 1 339 664
assign 1 0 664
assign 1 0 664
assign 1 343 664
new 0 343 664
assign 1 345 664
new 0 345 664
addValue 1 345 664
assign 1 346 664
new 0 346 664
addValue 1 346 664
assign 1 348 664
nlcGet 0 348 664
addValue 1 348 664
assign 1 349 664
nlecGet 0 349 664
addValue 1 349 664
assign 1 352 664
nlcGet 0 352 664
assign 1 353 664
nlecGet 0 353 664
assign 1 354 664
heldGet 0 354 664
assign 1 354 664
orgNameGet 0 354 664
assign 1 354 664
addValue 1 354 664
assign 1 354 664
new 0 354 664
assign 1 354 664
addValue 1 354 664
assign 1 354 664
heldGet 0 354 664
assign 1 354 664
numargsGet 0 354 664
assign 1 354 664
addValue 1 354 664
assign 1 354 664
new 0 354 664
assign 1 354 664
addValue 1 354 664
assign 1 354 664
nlcGet 0 354 664
assign 1 354 664
addValue 1 354 664
assign 1 354 664
new 0 354 664
assign 1 354 664
addValue 1 354 664
assign 1 354 664
nlecGet 0 354 664
assign 1 354 664
addValue 1 354 664
addValue 1 354 664
assign 1 356 664
new 0 356 664
assign 1 356 664
addValue 1 356 664
addValue 1 356 664
assign 1 360 664
heldGet 0 360 664
assign 1 360 664
namepathGet 0 360 664
assign 1 360 664
getClassConfig 1 360 664
assign 1 360 664
libNameGet 0 360 664
assign 1 360 664
relEmitName 1 360 664
assign 1 360 664
new 0 360 664
assign 1 360 664
add 1 360 664
assign 1 362 664
new 0 362 664
assign 1 362 664
emitting 1 362 664
assign 1 364 664
heldGet 0 364 664
assign 1 364 664
namepathGet 0 364 664
assign 1 364 664
getClassConfig 1 364 664
assign 1 364 664
emitNameGet 0 364 664
assign 1 364 664
new 0 364 664
assign 1 363 664
add 1 364 664
assign 1 365 664
assign 1 368 664
heldGet 0 368 664
assign 1 368 664
namepathGet 0 368 664
assign 1 368 664
toString 0 368 664
assign 1 368 664
new 0 368 664
assign 1 368 664
add 1 368 664
put 2 368 664
assign 1 369 664
heldGet 0 369 664
assign 1 369 664
namepathGet 0 369 664
assign 1 369 664
toString 0 369 664
assign 1 369 664
new 0 369 664
assign 1 369 664
add 1 369 664
put 2 369 664
assign 1 371 664
new 0 371 664
assign 1 371 664
emitting 1 371 664
assign 1 372 664
namepathGet 0 372 664
assign 1 372 664
equals 1 372 664
assign 1 373 664
new 0 373 664
assign 1 373 664
addValue 1 373 664
addValue 1 373 664
assign 1 375 664
new 0 375 664
assign 1 375 664
addValue 1 375 664
addValue 1 375 664
assign 1 377 664
new 0 377 664
assign 1 377 664
addValue 1 377 664
assign 1 377 664
addValue 1 377 664
assign 1 377 664
new 0 377 664
assign 1 377 664
addValue 1 377 664
addValue 1 377 664
assign 1 379 664
new 0 379 664
assign 1 379 664
emitting 1 379 664
assign 1 380 664
new 0 380 664
assign 1 380 664
addValue 1 380 664
addValue 1 380 664
assign 1 381 664
new 0 381 664
assign 1 381 664
addValue 1 381 664
assign 1 381 664
addValue 1 381 664
assign 1 381 664
new 0 381 664
assign 1 381 664
addValue 1 381 664
addValue 1 381 664
assign 1 382 664
new 0 382 664
assign 1 382 664
addValue 1 382 664
addValue 1 382 664
assign 1 383 664
new 0 383 664
assign 1 383 664
addValue 1 383 664
addValue 1 383 664
assign 1 384 664
new 0 384 664
assign 1 384 664
addValue 1 384 664
addValue 1 384 664
assign 1 386 664
new 0 386 664
assign 1 386 664
emitting 1 386 664
assign 1 387 664
addValue 1 387 664
assign 1 387 664
new 0 387 664
addValue 1 387 664
assign 1 388 664
new 0 388 664
assign 1 388 664
addValue 1 388 664
assign 1 388 664
addValue 1 388 664
assign 1 388 664
new 0 388 664
assign 1 388 664
addValue 1 388 664
addValue 1 388 664
assign 1 390 664
new 0 390 664
assign 1 390 664
emitting 1 390 664
assign 1 392 664
namepathGet 0 392 664
assign 1 392 664
equals 1 392 664
assign 1 393 664
new 0 393 664
assign 1 393 664
addValue 1 393 664
addValue 1 393 664
assign 1 395 664
new 0 395 664
assign 1 395 664
addValue 1 395 664
addValue 1 395 664
assign 1 397 664
new 0 397 664
assign 1 397 664
addValue 1 397 664
assign 1 397 664
addValue 1 397 664
assign 1 397 664
new 0 397 664
assign 1 397 664
addValue 1 397 664
addValue 1 397 664
assign 1 399 664
new 0 399 664
assign 1 399 664
emitting 1 399 664
assign 1 400 664
new 0 400 664
assign 1 400 664
addValue 1 400 664
addValue 1 400 664
assign 1 401 664
new 0 401 664
assign 1 401 664
addValue 1 401 664
assign 1 401 664
addValue 1 401 664
assign 1 401 664
new 0 401 664
assign 1 401 664
addValue 1 401 664
addValue 1 401 664
assign 1 402 664
new 0 402 664
assign 1 402 664
addValue 1 402 664
addValue 1 402 664
assign 1 403 664
new 0 403 664
assign 1 403 664
addValue 1 403 664
addValue 1 403 664
assign 1 404 664
new 0 404 664
assign 1 404 664
addValue 1 404 664
addValue 1 404 664
assign 1 406 664
new 0 406 664
assign 1 406 664
emitting 1 406 664
assign 1 407 664
addValue 1 407 664
assign 1 407 664
new 0 407 664
addValue 1 407 664
assign 1 408 664
new 0 408 664
assign 1 408 664
addValue 1 408 664
assign 1 408 664
addValue 1 408 664
assign 1 408 664
new 0 408 664
assign 1 408 664
addValue 1 408 664
addValue 1 408 664
addValue 1 411 664
assign 1 414 664
countLines 1 414 664
addValue 1 414 664
write 1 415 664
assign 1 418 664
useDynMethodsGet 0 418 664
assign 1 419 664
countLines 1 419 664
addValue 1 419 664
write 1 420 664
assign 1 423 664
countLines 1 423 664
addValue 1 423 664
write 1 424 664
assign 1 427 664
classEndGet 0 427 664
assign 1 428 664
countLines 1 428 664
addValue 1 428 664
write 1 429 664
assign 1 432 664
endNs 0 432 664
assign 1 433 664
countLines 1 433 664
addValue 1 433 664
write 1 434 664
finishClassOutput 1 438 664
emitLib 0 441 664
write 1 445 664
assign 1 446 664
countLines 1 446 664
return 1 446 664
assign 1 450 664
new 0 450 664
return 1 450 664
assign 1 455 664
new 0 455 664
assign 1 455 664
copy 0 455 664
assign 1 457 664
classDirGet 0 457 664
assign 1 457 664
fileGet 0 457 664
assign 1 457 664
existsGet 0 457 664
assign 1 457 664
not 0 457 664
assign 1 458 664
classDirGet 0 458 664
assign 1 458 664
fileGet 0 458 664
makeDirs 0 458 664
assign 1 460 664
classPathGet 0 460 664
assign 1 460 664
fileGet 0 460 664
assign 1 460 664
writerGet 0 460 664
assign 1 460 664
open 0 460 664
return 1 460 664
close 0 464 664
assign 1 468 664
fileGet 0 468 664
assign 1 468 664
writerGet 0 468 664
assign 1 468 664
open 0 468 664
return 1 468 664
close 0 472 664
assign 1 476 664
new 0 476 664
return 1 476 664
assign 1 480 664
new 0 480 664
return 1 480 664
assign 1 484 664
new 0 484 664
return 1 484 664
assign 1 488 664
new 0 488 664
return 1 488 664
assign 1 492 664
new 0 492 664
return 1 492 664
assign 1 496 664
new 0 496 664
return 1 496 664
assign 1 500 664
new 0 500 664
return 1 500 664
assign 1 504 664
emitLangGet 0 504 664
assign 1 504 664
equals 1 504 664
assign 1 505 664
new 0 505 664
return 1 505 664
assign 1 507 664
new 0 507 664
return 1 507 664
assign 1 512 664
new 0 512 664
assign 1 514 664
new 0 514 664
assign 1 515 664
mainNameGet 0 515 664
fromString 1 515 664
assign 1 516 664
getClassConfig 1 516 664
assign 1 518 664
new 0 518 664
assign 1 519 664
mainStartGet 0 519 664
addValue 1 519 664
assign 1 520 664
addValue 1 520 664
assign 1 520 664
new 0 520 664
assign 1 520 664
addValue 1 520 664
addValue 1 520 664
assign 1 522 664
fullEmitNameGet 0 522 664
assign 1 522 664
addValue 1 522 664
assign 1 522 664
new 0 522 664
assign 1 522 664
addValue 1 522 664
assign 1 522 664
fullEmitNameGet 0 522 664
assign 1 522 664
addValue 1 522 664
assign 1 522 664
new 0 522 664
assign 1 522 664
addValue 1 522 664
addValue 1 522 664
assign 1 523 664
new 0 523 664
assign 1 523 664
addValue 1 523 664
addValue 1 523 664
assign 1 524 664
new 0 524 664
assign 1 524 664
addValue 1 524 664
addValue 1 524 664
assign 1 525 664
mainEndGet 0 525 664
addValue 1 525 664
assign 1 527 664
getLibOutput 0 527 664
assign 1 528 664
beginNs 0 528 664
write 1 528 664
assign 1 529 664
new 0 529 664
assign 1 529 664
extend 1 529 664
assign 1 530 664
klassDecGet 0 530 664
assign 1 530 664
add 1 530 664
assign 1 530 664
add 1 530 664
assign 1 530 664
new 0 530 664
assign 1 530 664
add 1 530 664
assign 1 530 664
add 1 530 664
write 1 530 664
assign 1 531 664
spropDecGet 0 531 664
assign 1 531 664
boolTypeGet 0 531 664
assign 1 531 664
add 1 531 664
assign 1 531 664
new 0 531 664
assign 1 531 664
add 1 531 664
assign 1 531 664
add 1 531 664
write 1 531 664
assign 1 533 664
new 0 533 664
assign 1 534 664
usedLibrarysGet 0 534 664
assign 1 534 664
iteratorGet 0 0 664
assign 1 534 664
hasNextGet 0 534 664
assign 1 534 664
nextGet 0 534 664
assign 1 536 664
libNameGet 0 536 664
assign 1 536 664
fullLibEmitName 1 536 664
assign 1 536 664
addValue 1 536 664
assign 1 536 664
new 0 536 664
assign 1 536 664
addValue 1 536 664
addValue 1 536 664
assign 1 539 664
new 0 539 664
assign 1 540 664
new 0 540 664
assign 1 541 664
new 0 541 664
assign 1 542 664
iteratorGet 0 542 664
assign 1 542 664
hasNextGet 0 542 664
assign 1 544 664
nextGet 0 544 664
assign 1 546 664
new 0 546 664
assign 1 546 664
emitting 1 546 664
assign 1 547 664
new 0 547 664
assign 1 547 664
addValue 1 547 664
assign 1 547 664
addValue 1 547 664
assign 1 547 664
heldGet 0 547 664
assign 1 547 664
namepathGet 0 547 664
assign 1 547 664
toString 0 547 664
assign 1 547 664
addValue 1 547 664
assign 1 547 664
addValue 1 547 664
assign 1 547 664
new 0 547 664
assign 1 547 664
addValue 1 547 664
assign 1 547 664
addValue 1 547 664
assign 1 547 664
heldGet 0 547 664
assign 1 547 664
namepathGet 0 547 664
assign 1 547 664
getClassConfig 1 547 664
assign 1 547 664
fullEmitNameGet 0 547 664
assign 1 547 664
addValue 1 547 664
assign 1 547 664
addValue 1 547 664
assign 1 547 664
new 0 547 664
assign 1 547 664
addValue 1 547 664
addValue 1 547 664
assign 1 549 664
new 0 549 664
assign 1 549 664
emitting 1 549 664
assign 1 550 664
new 0 550 664
assign 1 550 664
addValue 1 550 664
assign 1 550 664
addValue 1 550 664
assign 1 550 664
heldGet 0 550 664
assign 1 550 664
namepathGet 0 550 664
assign 1 550 664
toString 0 550 664
assign 1 550 664
addValue 1 550 664
assign 1 550 664
addValue 1 550 664
assign 1 550 664
new 0 550 664
assign 1 550 664
addValue 1 550 664
assign 1 550 664
heldGet 0 550 664
assign 1 550 664
namepathGet 0 550 664
assign 1 550 664
getClassConfig 1 550 664
assign 1 550 664
libNameGet 0 550 664
assign 1 550 664
relEmitName 1 550 664
assign 1 550 664
addValue 1 550 664
assign 1 550 664
new 0 550 664
assign 1 550 664
addValue 1 550 664
addValue 1 550 664
assign 1 551 664
new 0 551 664
assign 1 551 664
addValue 1 551 664
assign 1 551 664
heldGet 0 551 664
assign 1 551 664
namepathGet 0 551 664
assign 1 551 664
getClassConfig 1 551 664
assign 1 551 664
libNameGet 0 551 664
assign 1 551 664
relEmitName 1 551 664
assign 1 551 664
addValue 1 551 664
assign 1 551 664
new 0 551 664
addValue 1 551 664
assign 1 552 664
new 0 552 664
assign 1 552 664
addValue 1 552 664
assign 1 552 664
addValue 1 552 664
assign 1 552 664
new 0 552 664
assign 1 552 664
addValue 1 552 664
assign 1 552 664
addValue 1 552 664
assign 1 552 664
new 0 552 664
assign 1 552 664
addValue 1 552 664
addValue 1 552 664
assign 1 555 664
heldGet 0 555 664
assign 1 555 664
synGet 0 555 664
assign 1 555 664
hasDefaultGet 0 555 664
assign 1 556 664
new 0 556 664
assign 1 556 664
heldGet 0 556 664
assign 1 556 664
namepathGet 0 556 664
assign 1 556 664
getClassConfig 1 556 664
assign 1 556 664
libNameGet 0 556 664
assign 1 556 664
relEmitName 1 556 664
assign 1 556 664
add 1 556 664
assign 1 556 664
new 0 556 664
assign 1 556 664
add 1 556 664
assign 1 557 664
new 0 557 664
assign 1 557 664
addValue 1 557 664
assign 1 557 664
addValue 1 557 664
assign 1 557 664
new 0 557 664
assign 1 557 664
addValue 1 557 664
addValue 1 557 664
assign 1 558 664
new 0 558 664
assign 1 558 664
addValue 1 558 664
assign 1 558 664
addValue 1 558 664
assign 1 558 664
new 0 558 664
assign 1 558 664
addValue 1 558 664
addValue 1 558 664
assign 1 562 664
setIteratorGet 0 0 664
assign 1 562 664
hasNextGet 0 562 664
assign 1 562 664
nextGet 0 562 664
assign 1 563 664
spropDecGet 0 563 664
assign 1 563 664
new 0 563 664
assign 1 563 664
add 1 563 664
assign 1 563 664
add 1 563 664
assign 1 563 664
new 0 563 664
assign 1 563 664
add 1 563 664
assign 1 563 664
add 1 563 664
write 1 563 664
assign 1 564 664
new 0 564 664
assign 1 564 664
addValue 1 564 664
assign 1 564 664
addValue 1 564 664
assign 1 564 664
new 0 564 664
assign 1 564 664
addValue 1 564 664
assign 1 564 664
addValue 1 564 664
assign 1 564 664
addValue 1 564 664
assign 1 564 664
addValue 1 564 664
assign 1 564 664
new 0 564 664
assign 1 564 664
addValue 1 564 664
addValue 1 564 664
assign 1 567 664
new 0 567 664
assign 1 569 664
keysGet 0 569 664
assign 1 569 664
iteratorGet 0 0 664
assign 1 569 664
hasNextGet 0 569 664
assign 1 569 664
nextGet 0 569 664
assign 1 571 664
new 0 571 664
assign 1 571 664
addValue 1 571 664
assign 1 571 664
new 0 571 664
assign 1 571 664
quoteGet 0 571 664
assign 1 571 664
addValue 1 571 664
assign 1 571 664
addValue 1 571 664
assign 1 571 664
new 0 571 664
assign 1 571 664
quoteGet 0 571 664
assign 1 571 664
addValue 1 571 664
assign 1 571 664
new 0 571 664
assign 1 571 664
addValue 1 571 664
assign 1 571 664
get 1 571 664
assign 1 571 664
addValue 1 571 664
assign 1 571 664
new 0 571 664
assign 1 571 664
addValue 1 571 664
addValue 1 571 664
assign 1 572 664
new 0 572 664
assign 1 572 664
addValue 1 572 664
assign 1 572 664
new 0 572 664
assign 1 572 664
quoteGet 0 572 664
assign 1 572 664
addValue 1 572 664
assign 1 572 664
addValue 1 572 664
assign 1 572 664
new 0 572 664
assign 1 572 664
quoteGet 0 572 664
assign 1 572 664
addValue 1 572 664
assign 1 572 664
new 0 572 664
assign 1 572 664
addValue 1 572 664
assign 1 572 664
get 1 572 664
assign 1 572 664
addValue 1 572 664
assign 1 572 664
new 0 572 664
assign 1 572 664
addValue 1 572 664
addValue 1 572 664
assign 1 576 664
baseSmtdDecGet 0 576 664
assign 1 576 664
new 0 576 664
assign 1 576 664
add 1 576 664
assign 1 576 664
addValue 1 576 664
assign 1 576 664
new 0 576 664
assign 1 576 664
add 1 576 664
assign 1 576 664
addValue 1 576 664
write 1 576 664
assign 1 577 664
new 0 577 664
assign 1 577 664
emitting 1 577 664
assign 1 578 664
new 0 578 664
assign 1 578 664
add 1 578 664
assign 1 578 664
new 0 578 664
assign 1 578 664
add 1 578 664
assign 1 578 664
add 1 578 664
write 1 578 664
assign 1 579 664
new 0 579 664
assign 1 579 664
emitting 1 579 664
assign 1 580 664
new 0 580 664
assign 1 580 664
add 1 580 664
assign 1 580 664
new 0 580 664
assign 1 580 664
add 1 580 664
assign 1 580 664
add 1 580 664
write 1 580 664
assign 1 582 664
new 0 582 664
assign 1 582 664
add 1 582 664
write 1 582 664
assign 1 583 664
new 0 583 664
assign 1 583 664
add 1 583 664
write 1 583 664
assign 1 584 664
runtimeInitGet 0 584 664
write 1 584 664
write 1 585 664
write 1 586 664
write 1 587 664
write 1 588 664
write 1 589 664
write 1 590 664
assign 1 591 664
new 0 591 664
assign 1 591 664
emitting 1 591 664
assign 1 0 664
assign 1 591 664
new 0 591 664
assign 1 591 664
emitting 1 591 664
assign 1 0 664
assign 1 0 664
assign 1 593 664
new 0 593 664
assign 1 593 664
add 1 593 664
write 1 593 664
assign 1 595 664
new 0 595 664
assign 1 595 664
add 1 595 664
write 1 595 664
assign 1 597 664
mainInClassGet 0 597 664
write 1 598 664
assign 1 601 664
new 0 601 664
assign 1 601 664
add 1 601 664
write 1 601 664
assign 1 602 664
endNs 0 602 664
write 1 602 664
assign 1 604 664
mainOutsideNsGet 0 604 664
write 1 605 664
finishLibOutput 1 608 664
assign 1 613 664
new 0 613 664
assign 1 613 664
add 1 613 664
return 1 613 664
assign 1 617 664
new 0 617 664
return 1 617 664
assign 1 621 664
new 0 621 664
return 1 621 664
assign 1 625 664
new 0 625 664
return 1 625 664
assign 1 631 664
new 0 631 664
assign 1 631 664
emitting 1 631 664
assign 1 0 664
assign 1 631 664
new 0 631 664
assign 1 631 664
emitting 1 631 664
assign 1 0 664
assign 1 0 664
assign 1 633 664
new 0 633 664
assign 1 633 664
add 1 633 664
return 1 633 664
assign 1 636 664
new 0 636 664
assign 1 636 664
add 1 636 664
return 1 636 664
assign 1 640 664
new 0 640 664
return 1 640 664
begin 1 645 664
assign 1 647 664
new 0 647 664
assign 1 648 664
new 0 648 664
assign 1 649 664
new 0 649 664
assign 1 650 664
new 0 650 664
assign 1 657 664
isTmpVarGet 0 657 664
assign 1 658 664
new 0 658 664
assign 1 659 664
isPropertyGet 0 659 664
assign 1 660 664
new 0 660 664
assign 1 661 664
isArgGet 0 661 664
assign 1 662 664
new 0 662 664
assign 1 664 664
new 0 664 664
assign 1 666 664
nameGet 0 666 664
assign 1 666 664
add 1 666 664
return 1 666 664
assign 1 671 664
isTypedGet 0 671 664
assign 1 671 664
not 0 671 664
assign 1 672 664
libNameGet 0 672 664
assign 1 672 664
relEmitName 1 672 664
addValue 1 672 664
assign 1 674 664
namepathGet 0 674 664
assign 1 674 664
getClassConfig 1 674 664
assign 1 674 664
libNameGet 0 674 664
assign 1 674 664
relEmitName 1 674 664
addValue 1 674 664
typeDecForVar 2 679 664
assign 1 680 664
new 0 680 664
addValue 1 680 664
assign 1 681 664
nameForVar 1 681 664
addValue 1 681 664
assign 1 685 664
new 0 685 664
assign 1 685 664
heldGet 0 685 664
assign 1 685 664
nameGet 0 685 664
assign 1 685 664
add 1 685 664
return 1 685 664
assign 1 689 664
new 0 689 664
assign 1 689 664
heldGet 0 689 664
assign 1 689 664
nameGet 0 689 664
assign 1 689 664
add 1 689 664
return 1 689 664
assign 1 694 664
assign 1 695 664
assign 1 698 664
mtdMapGet 0 698 664
assign 1 698 664
heldGet 0 698 664
assign 1 698 664
nameGet 0 698 664
assign 1 698 664
get 1 698 664
assign 1 700 664
heldGet 0 700 664
assign 1 700 664
nameGet 0 700 664
put 1 700 664
assign 1 702 664
new 0 702 664
assign 1 703 664
new 0 703 664
assign 1 705 664
new 0 705 664
assign 1 706 664
heldGet 0 706 664
assign 1 706 664
orderedVarsGet 0 706 664
assign 1 706 664
iteratorGet 0 0 664
assign 1 706 664
hasNextGet 0 706 664
assign 1 706 664
nextGet 0 706 664
assign 1 707 664
heldGet 0 707 664
assign 1 707 664
nameGet 0 707 664
assign 1 707 664
new 0 707 664
assign 1 707 664
notEquals 1 707 664
assign 1 707 664
heldGet 0 707 664
assign 1 707 664
nameGet 0 707 664
assign 1 707 664
new 0 707 664
assign 1 707 664
notEquals 1 707 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 708 664
heldGet 0 708 664
assign 1 708 664
isArgGet 0 708 664
assign 1 710 664
new 0 710 664
addValue 1 710 664
assign 1 712 664
new 0 712 664
assign 1 713 664
heldGet 0 713 664
assign 1 713 664
undef 1 713 664
assign 1 714 664
new 0 714 664
assign 1 714 664
toString 0 714 664
assign 1 714 664
add 1 714 664
assign 1 714 664
new 2 714 664
throw 1 714 664
assign 1 716 664
heldGet 0 716 664
decForVar 2 716 664
assign 1 718 664
heldGet 0 718 664
decForVar 2 718 664
assign 1 719 664
new 0 719 664
assign 1 719 664
emitting 1 719 664
assign 1 720 664
new 0 720 664
assign 1 720 664
addValue 1 720 664
addValue 1 720 664
assign 1 722 664
new 0 722 664
assign 1 722 664
addValue 1 722 664
addValue 1 722 664
assign 1 725 664
heldGet 0 725 664
assign 1 725 664
heldGet 0 725 664
assign 1 725 664
nameForVar 1 725 664
nativeNameSet 1 725 664
assign 1 729 664
getEmitReturnType 2 729 664
assign 1 731 664
def 1 731 664
assign 1 732 664
getClassConfig 1 732 664
assign 1 734 664
assign 1 738 664
declarationGet 0 738 664
assign 1 738 664
namepathGet 0 738 664
assign 1 738 664
equals 1 738 664
assign 1 739 664
baseMtdDecGet 0 739 664
assign 1 741 664
overrideMtdDecGet 0 741 664
assign 1 744 664
emitNameForMethod 1 744 664
startMethod 5 744 664
addValue 1 746 664
assign 1 752 664
addValue 1 752 664
assign 1 752 664
libNameGet 0 752 664
assign 1 752 664
relEmitName 1 752 664
assign 1 752 664
addValue 1 752 664
assign 1 752 664
new 0 752 664
assign 1 752 664
addValue 1 752 664
assign 1 752 664
addValue 1 752 664
assign 1 752 664
new 0 752 664
addValue 1 752 664
addValue 1 754 664
assign 1 756 664
new 0 756 664
assign 1 756 664
addValue 1 756 664
assign 1 756 664
addValue 1 756 664
assign 1 756 664
new 0 756 664
assign 1 756 664
addValue 1 756 664
addValue 1 756 664
assign 1 761 664
getSynNp 1 761 664
assign 1 762 664
closeLibrariesGet 0 762 664
assign 1 762 664
libNameGet 0 762 664
assign 1 762 664
has 1 762 664
assign 1 763 664
new 0 763 664
return 1 763 664
assign 1 765 664
new 0 765 664
return 1 765 664
assign 1 770 664
new 0 770 664
assign 1 771 664
new 0 771 664
assign 1 772 664
new 0 772 664
assign 1 773 664
new 0 773 664
assign 1 774 664
new 0 774 664
assign 1 775 664
assign 1 776 664
heldGet 0 776 664
assign 1 776 664
synGet 0 776 664
assign 1 777 664
new 0 777 664
assign 1 778 664
new 0 778 664
assign 1 779 664
new 0 779 664
assign 1 780 664
new 0 780 664
assign 1 781 664
heldGet 0 781 664
assign 1 781 664
fromFileGet 0 781 664
assign 1 781 664
new 0 781 664
assign 1 781 664
toStringWithSeparator 1 781 664
assign 1 784 664
transUnitGet 0 784 664
assign 1 784 664
heldGet 0 784 664
assign 1 784 664
emitsGet 0 784 664
assign 1 785 664
def 1 785 664
assign 1 786 664
iteratorGet 0 786 664
assign 1 786 664
hasNextGet 0 786 664
assign 1 787 664
nextGet 0 787 664
assign 1 788 664
heldGet 0 788 664
assign 1 788 664
langsGet 0 788 664
assign 1 788 664
emitLangGet 0 788 664
assign 1 788 664
has 1 788 664
assign 1 789 664
heldGet 0 789 664
assign 1 789 664
textGet 0 789 664
assign 1 789 664
emitReplace 1 789 664
addValue 1 789 664
assign 1 794 664
heldGet 0 794 664
assign 1 794 664
extendsGet 0 794 664
assign 1 794 664
def 1 794 664
assign 1 795 664
heldGet 0 795 664
assign 1 795 664
extendsGet 0 795 664
assign 1 795 664
getClassConfig 1 795 664
assign 1 796 664
heldGet 0 796 664
assign 1 796 664
extendsGet 0 796 664
assign 1 796 664
getSynNp 1 796 664
assign 1 798 664
assign 1 802 664
heldGet 0 802 664
assign 1 802 664
emitsGet 0 802 664
assign 1 802 664
def 1 802 664
assign 1 803 664
emitLangGet 0 803 664
assign 1 804 664
heldGet 0 804 664
assign 1 804 664
emitsGet 0 804 664
assign 1 804 664
iteratorGet 0 0 664
assign 1 804 664
hasNextGet 0 804 664
assign 1 804 664
nextGet 0 804 664
assign 1 806 664
heldGet 0 806 664
assign 1 806 664
textGet 0 806 664
assign 1 806 664
getNativeCSlots 1 806 664
assign 1 807 664
heldGet 0 807 664
assign 1 807 664
langsGet 0 807 664
assign 1 807 664
has 1 807 664
assign 1 808 664
heldGet 0 808 664
assign 1 808 664
textGet 0 808 664
assign 1 808 664
emitReplace 1 808 664
addValue 1 808 664
assign 1 813 664
def 1 813 664
assign 1 813 664
new 0 813 664
assign 1 813 664
greater 1 813 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 814 664
ptyListGet 0 814 664
assign 1 814 664
sizeGet 0 814 664
assign 1 814 664
subtract 1 814 664
assign 1 815 664
new 0 815 664
assign 1 815 664
lesser 1 815 664
assign 1 816 664
new 0 816 664
assign 1 822 664
new 0 822 664
assign 1 823 664
heldGet 0 823 664
assign 1 823 664
orderedVarsGet 0 823 664
assign 1 823 664
iteratorGet 0 823 664
assign 1 823 664
hasNextGet 0 823 664
assign 1 824 664
nextGet 0 824 664
assign 1 824 664
heldGet 0 824 664
assign 1 825 664
isDeclaredGet 0 825 664
assign 1 826 664
greaterEquals 1 826 664
assign 1 827 664
propDecGet 0 827 664
addValue 1 827 664
decForVar 2 828 664
assign 1 829 664
new 0 829 664
assign 1 829 664
addValue 1 829 664
addValue 1 829 664
assign 1 831 664
increment 0 831 664
assign 1 836 664
new 0 836 664
assign 1 837 664
new 0 837 664
assign 1 838 664
mtdListGet 0 838 664
assign 1 838 664
iteratorGet 0 0 664
assign 1 838 664
hasNextGet 0 838 664
assign 1 838 664
nextGet 0 838 664
assign 1 839 664
nameGet 0 839 664
assign 1 839 664
has 1 839 664
assign 1 840 664
nameGet 0 840 664
put 1 840 664
assign 1 841 664
mtdMapGet 0 841 664
assign 1 841 664
nameGet 0 841 664
assign 1 841 664
get 1 841 664
assign 1 842 664
originGet 0 842 664
assign 1 842 664
isClose 1 842 664
assign 1 843 664
numargsGet 0 843 664
assign 1 844 664
greater 1 844 664
assign 1 845 664
assign 1 847 664
get 1 847 664
assign 1 848 664
undef 1 848 664
assign 1 849 664
new 0 849 664
put 2 850 664
assign 1 852 664
nameGet 0 852 664
assign 1 852 664
hashGet 0 852 664
assign 1 853 664
get 1 853 664
assign 1 854 664
undef 1 854 664
assign 1 855 664
new 0 855 664
put 2 856 664
addValue 1 858 664
assign 1 864 664
mapIteratorGet 0 0 664
assign 1 864 664
hasNextGet 0 864 664
assign 1 864 664
nextGet 0 864 664
assign 1 865 664
keyGet 0 865 664
assign 1 867 664
lesser 1 867 664
assign 1 868 664
new 0 868 664
assign 1 868 664
toString 0 868 664
assign 1 868 664
add 1 868 664
assign 1 870 664
new 0 870 664
assign 1 872 664
new 0 872 664
assign 1 873 664
new 0 873 664
assign 1 874 664
new 0 874 664
assign 1 875 664
new 0 875 664
assign 1 875 664
add 1 875 664
assign 1 875 664
lesser 1 875 664
assign 1 875 664
lesser 1 875 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 876 664
new 0 876 664
assign 1 876 664
add 1 876 664
assign 1 876 664
libNameGet 0 876 664
assign 1 876 664
relEmitName 1 876 664
assign 1 876 664
add 1 876 664
assign 1 876 664
new 0 876 664
assign 1 876 664
add 1 876 664
assign 1 876 664
new 0 876 664
assign 1 876 664
subtract 1 876 664
assign 1 876 664
add 1 876 664
assign 1 877 664
new 0 877 664
assign 1 877 664
add 1 877 664
assign 1 877 664
new 0 877 664
assign 1 877 664
add 1 877 664
assign 1 877 664
new 0 877 664
assign 1 877 664
subtract 1 877 664
assign 1 877 664
add 1 877 664
assign 1 878 664
increment 0 878 664
assign 1 880 664
greaterEquals 1 880 664
assign 1 881 664
new 0 881 664
assign 1 881 664
add 1 881 664
assign 1 881 664
libNameGet 0 881 664
assign 1 881 664
relEmitName 1 881 664
assign 1 881 664
add 1 881 664
assign 1 881 664
new 0 881 664
assign 1 881 664
add 1 881 664
assign 1 882 664
new 0 882 664
assign 1 882 664
add 1 882 664
assign 1 884 664
overrideMtdDecGet 0 884 664
assign 1 884 664
addValue 1 884 664
assign 1 884 664
libNameGet 0 884 664
assign 1 884 664
relEmitName 1 884 664
assign 1 884 664
addValue 1 884 664
assign 1 884 664
new 0 884 664
assign 1 884 664
addValue 1 884 664
assign 1 884 664
addValue 1 884 664
assign 1 884 664
new 0 884 664
assign 1 884 664
addValue 1 884 664
assign 1 884 664
addValue 1 884 664
assign 1 884 664
new 0 884 664
assign 1 884 664
addValue 1 884 664
assign 1 884 664
addValue 1 884 664
assign 1 884 664
new 0 884 664
assign 1 884 664
addValue 1 884 664
addValue 1 884 664
assign 1 885 664
new 0 885 664
assign 1 885 664
addValue 1 885 664
addValue 1 885 664
assign 1 887 664
valueGet 0 887 664
assign 1 888 664
mapIteratorGet 0 0 664
assign 1 888 664
hasNextGet 0 888 664
assign 1 888 664
nextGet 0 888 664
assign 1 889 664
keyGet 0 889 664
assign 1 890 664
valueGet 0 890 664
assign 1 891 664
new 0 891 664
assign 1 891 664
addValue 1 891 664
assign 1 891 664
toString 0 891 664
assign 1 891 664
addValue 1 891 664
assign 1 891 664
new 0 891 664
addValue 1 891 664
assign 1 0 664
assign 1 895 664
sizeGet 0 895 664
assign 1 895 664
new 0 895 664
assign 1 895 664
greater 1 895 664
assign 1 0 664
assign 1 0 664
assign 1 896 664
new 0 896 664
assign 1 898 664
new 0 898 664
assign 1 900 664
arrayIteratorGet 0 0 664
assign 1 900 664
hasNextGet 0 900 664
assign 1 900 664
nextGet 0 900 664
assign 1 901 664
new 0 901 664
assign 1 903 664
new 0 903 664
assign 1 903 664
add 1 903 664
assign 1 903 664
nameGet 0 903 664
assign 1 903 664
add 1 903 664
assign 1 904 664
new 0 904 664
assign 1 904 664
addValue 1 904 664
assign 1 904 664
addValue 1 904 664
assign 1 904 664
new 0 904 664
assign 1 904 664
addValue 1 904 664
addValue 1 904 664
assign 1 906 664
new 0 906 664
assign 1 906 664
addValue 1 906 664
assign 1 906 664
nameGet 0 906 664
assign 1 906 664
addValue 1 906 664
assign 1 906 664
new 0 906 664
addValue 1 906 664
assign 1 907 664
new 0 907 664
assign 1 908 664
argSynsGet 0 908 664
assign 1 908 664
iteratorGet 0 0 664
assign 1 908 664
hasNextGet 0 908 664
assign 1 908 664
nextGet 0 908 664
assign 1 909 664
new 0 909 664
assign 1 909 664
greater 1 909 664
assign 1 910 664
isTypedGet 0 910 664
assign 1 910 664
namepathGet 0 910 664
assign 1 910 664
notEquals 1 910 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 911 664
namepathGet 0 911 664
assign 1 911 664
getClassConfig 1 911 664
assign 1 911 664
formCast 1 911 664
assign 1 911 664
new 0 911 664
assign 1 911 664
add 1 911 664
assign 1 913 664
new 0 913 664
assign 1 915 664
new 0 915 664
assign 1 915 664
greater 1 915 664
assign 1 916 664
new 0 916 664
assign 1 918 664
new 0 918 664
assign 1 920 664
lesser 1 920 664
assign 1 921 664
new 0 921 664
assign 1 921 664
new 0 921 664
assign 1 921 664
subtract 1 921 664
assign 1 921 664
add 1 921 664
assign 1 923 664
new 0 923 664
assign 1 923 664
subtract 1 923 664
assign 1 923 664
add 1 923 664
assign 1 923 664
new 0 923 664
assign 1 923 664
add 1 923 664
assign 1 925 664
addValue 1 925 664
assign 1 925 664
addValue 1 925 664
addValue 1 925 664
assign 1 927 664
increment 0 927 664
assign 1 929 664
new 0 929 664
assign 1 929 664
addValue 1 929 664
addValue 1 929 664
assign 1 932 664
new 0 932 664
assign 1 932 664
addValue 1 932 664
addValue 1 932 664
addValue 1 935 664
assign 1 938 664
new 0 938 664
assign 1 938 664
addValue 1 938 664
addValue 1 938 664
assign 1 941 664
new 0 941 664
assign 1 941 664
addValue 1 941 664
addValue 1 941 664
assign 1 942 664
new 0 942 664
assign 1 942 664
superNameGet 0 942 664
assign 1 942 664
add 1 942 664
assign 1 942 664
new 0 942 664
assign 1 942 664
add 1 942 664
assign 1 942 664
addValue 1 942 664
assign 1 942 664
addValue 1 942 664
assign 1 942 664
new 0 942 664
assign 1 942 664
addValue 1 942 664
assign 1 942 664
addValue 1 942 664
assign 1 942 664
new 0 942 664
assign 1 942 664
addValue 1 942 664
addValue 1 942 664
assign 1 943 664
new 0 943 664
assign 1 943 664
addValue 1 943 664
addValue 1 943 664
buildClassInfo 0 946 664
buildCreate 0 948 664
buildInitial 0 950 664
assign 1 958 664
new 0 958 664
assign 1 959 664
new 0 959 664
assign 1 959 664
split 1 959 664
assign 1 960 664
new 0 960 664
assign 1 961 664
new 0 961 664
assign 1 962 664
iteratorGet 0 0 664
assign 1 962 664
hasNextGet 0 962 664
assign 1 962 664
nextGet 0 962 664
assign 1 964 664
new 0 964 664
assign 1 965 664
new 1 965 664
assign 1 966 664
new 0 966 664
assign 1 967 664
new 0 967 664
assign 1 967 664
equals 1 967 664
assign 1 968 664
new 0 968 664
assign 1 969 664
new 0 969 664
assign 1 970 664
new 0 970 664
assign 1 970 664
equals 1 970 664
assign 1 971 664
new 0 971 664
assign 1 974 664
new 0 974 664
assign 1 974 664
greater 1 974 664
return 1 977 664
assign 1 981 664
overrideMtdDecGet 0 981 664
assign 1 981 664
addValue 1 981 664
assign 1 981 664
getClassConfig 1 981 664
assign 1 981 664
libNameGet 0 981 664
assign 1 981 664
relEmitName 1 981 664
assign 1 981 664
addValue 1 981 664
assign 1 981 664
new 0 981 664
assign 1 981 664
addValue 1 981 664
assign 1 981 664
addValue 1 981 664
assign 1 981 664
new 0 981 664
assign 1 981 664
addValue 1 981 664
addValue 1 981 664
assign 1 982 664
new 0 982 664
assign 1 982 664
addValue 1 982 664
assign 1 982 664
heldGet 0 982 664
assign 1 982 664
namepathGet 0 982 664
assign 1 982 664
getClassConfig 1 982 664
assign 1 982 664
libNameGet 0 982 664
assign 1 982 664
relEmitName 1 982 664
assign 1 982 664
addValue 1 982 664
assign 1 982 664
new 0 982 664
assign 1 982 664
addValue 1 982 664
addValue 1 982 664
assign 1 984 664
new 0 984 664
assign 1 984 664
addValue 1 984 664
addValue 1 984 664
assign 1 988 664
getClassConfig 1 988 664
assign 1 988 664
libNameGet 0 988 664
assign 1 988 664
relEmitName 1 988 664
assign 1 989 664
emitNameGet 0 989 664
assign 1 990 664
heldGet 0 990 664
assign 1 990 664
namepathGet 0 990 664
assign 1 990 664
getClassConfig 1 990 664
assign 1 991 664
getInitialInst 1 991 664
assign 1 993 664
overrideMtdDecGet 0 993 664
assign 1 993 664
addValue 1 993 664
assign 1 993 664
new 0 993 664
assign 1 993 664
addValue 1 993 664
assign 1 993 664
addValue 1 993 664
assign 1 993 664
new 0 993 664
assign 1 993 664
addValue 1 993 664
assign 1 993 664
addValue 1 993 664
assign 1 993 664
new 0 993 664
assign 1 993 664
addValue 1 993 664
addValue 1 993 664
assign 1 995 664
notEquals 1 995 664
assign 1 996 664
formCast 1 996 664
assign 1 998 664
new 0 998 664
assign 1 1001 664
addValue 1 1001 664
assign 1 1001 664
new 0 1001 664
assign 1 1001 664
addValue 1 1001 664
assign 1 1001 664
addValue 1 1001 664
assign 1 1001 664
new 0 1001 664
assign 1 1001 664
addValue 1 1001 664
addValue 1 1001 664
assign 1 1003 664
new 0 1003 664
assign 1 1003 664
addValue 1 1003 664
addValue 1 1003 664
assign 1 1006 664
overrideMtdDecGet 0 1006 664
assign 1 1006 664
addValue 1 1006 664
assign 1 1006 664
addValue 1 1006 664
assign 1 1006 664
new 0 1006 664
assign 1 1006 664
addValue 1 1006 664
assign 1 1006 664
addValue 1 1006 664
assign 1 1006 664
new 0 1006 664
assign 1 1006 664
addValue 1 1006 664
addValue 1 1006 664
assign 1 1008 664
new 0 1008 664
assign 1 1008 664
addValue 1 1008 664
assign 1 1008 664
addValue 1 1008 664
assign 1 1008 664
new 0 1008 664
assign 1 1008 664
addValue 1 1008 664
addValue 1 1008 664
assign 1 1010 664
new 0 1010 664
assign 1 1010 664
addValue 1 1010 664
addValue 1 1010 664
assign 1 1015 664
new 0 1015 664
assign 1 1015 664
heldGet 0 1015 664
assign 1 1015 664
namepathGet 0 1015 664
assign 1 1015 664
toString 0 1015 664
buildClassInfo 2 1015 664
assign 1 1016 664
new 0 1016 664
buildClassInfo 2 1016 664
assign 1 1021 664
new 0 1021 664
assign 1 1021 664
add 1 1021 664
assign 1 1023 664
new 0 1023 664
lstringStart 2 1024 664
assign 1 1026 664
sizeGet 0 1026 664
assign 1 1027 664
new 0 1027 664
assign 1 1028 664
new 0 1028 664
assign 1 1029 664
new 0 1029 664
assign 1 1029 664
new 1 1029 664
assign 1 1030 664
lesser 1 1030 664
assign 1 1031 664
new 0 1031 664
assign 1 1031 664
greater 1 1031 664
assign 1 1032 664
new 0 1032 664
assign 1 1032 664
once 0 1032 664
addValue 1 1032 664
lstringByte 5 1034 664
incrementValue 0 1035 664
lstringEnd 1 1037 664
addValue 1 1039 664
buildClassInfoMethod 1 1041 664
assign 1 1046 664
overrideMtdDecGet 0 1046 664
assign 1 1046 664
addValue 1 1046 664
assign 1 1046 664
new 0 1046 664
assign 1 1046 664
addValue 1 1046 664
assign 1 1046 664
addValue 1 1046 664
assign 1 1046 664
new 0 1046 664
assign 1 1046 664
addValue 1 1046 664
assign 1 1046 664
addValue 1 1046 664
assign 1 1046 664
new 0 1046 664
assign 1 1046 664
addValue 1 1046 664
addValue 1 1046 664
assign 1 1047 664
new 0 1047 664
assign 1 1047 664
addValue 1 1047 664
assign 1 1047 664
addValue 1 1047 664
assign 1 1047 664
new 0 1047 664
assign 1 1047 664
addValue 1 1047 664
addValue 1 1047 664
assign 1 1049 664
new 0 1049 664
assign 1 1049 664
addValue 1 1049 664
addValue 1 1049 664
assign 1 1054 664
new 0 1054 664
assign 1 1056 664
namepathGet 0 1056 664
assign 1 1056 664
equals 1 1056 664
assign 1 1057 664
emitNameGet 0 1057 664
assign 1 1057 664
new 0 1057 664
assign 1 1057 664
baseSpropDec 2 1057 664
assign 1 1057 664
addValue 1 1057 664
assign 1 1057 664
new 0 1057 664
assign 1 1057 664
addValue 1 1057 664
addValue 1 1057 664
assign 1 1059 664
emitNameGet 0 1059 664
assign 1 1059 664
new 0 1059 664
assign 1 1059 664
overrideSpropDec 2 1059 664
assign 1 1059 664
addValue 1 1059 664
assign 1 1059 664
new 0 1059 664
assign 1 1059 664
addValue 1 1059 664
addValue 1 1059 664
return 1 1062 664
assign 1 1066 664
def 1 1066 664
assign 1 1067 664
libNameGet 0 1067 664
assign 1 1067 664
relEmitName 1 1067 664
assign 1 1067 664
extend 1 1067 664
assign 1 1069 664
new 0 1069 664
assign 1 1069 664
extend 1 1069 664
assign 1 1071 664
new 0 1071 664
assign 1 1071 664
addValue 1 1071 664
assign 1 1071 664
new 0 1071 664
assign 1 1071 664
addValue 1 1071 664
assign 1 1071 664
addValue 1 1071 664
assign 1 1072 664
klassDecGet 0 1072 664
assign 1 1072 664
addValue 1 1072 664
assign 1 1072 664
emitNameGet 0 1072 664
assign 1 1072 664
addValue 1 1072 664
assign 1 1072 664
addValue 1 1072 664
assign 1 1072 664
new 0 1072 664
assign 1 1072 664
addValue 1 1072 664
addValue 1 1072 664
assign 1 1073 664
new 0 1073 664
assign 1 1073 664
addValue 1 1073 664
assign 1 1073 664
emitNameGet 0 1073 664
assign 1 1073 664
addValue 1 1073 664
assign 1 1073 664
new 0 1073 664
addValue 1 1073 664
assign 1 1074 664
new 0 1074 664
assign 1 1074 664
addValue 1 1074 664
addValue 1 1074 664
assign 1 1075 664
new 0 1075 664
assign 1 1075 664
emitting 1 1075 664
assign 1 1076 664
new 0 1076 664
assign 1 1076 664
addValue 1 1076 664
assign 1 1076 664
emitNameGet 0 1076 664
assign 1 1076 664
addValue 1 1076 664
assign 1 1076 664
new 0 1076 664
addValue 1 1076 664
assign 1 1077 664
new 0 1077 664
assign 1 1077 664
addValue 1 1077 664
addValue 1 1077 664
return 1 1079 664
assign 1 1084 664
new 0 1084 664
assign 1 1084 664
addValue 1 1084 664
return 1 1084 664
assign 1 1088 664
new 0 1088 664
assign 1 1088 664
add 1 1088 664
assign 1 1088 664
new 0 1088 664
assign 1 1088 664
add 1 1088 664
assign 1 1088 664
add 1 1088 664
return 1 1088 664
assign 1 1092 664
new 0 1092 664
return 1 1092 664
assign 1 1097 664
new 0 1097 664
return 1 1097 664
assign 1 1101 664
new 0 1101 664
assign 1 1102 664
def 1 1102 664
assign 1 1102 664
nlcGet 0 1102 664
assign 1 1102 664
def 1 1102 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1103 664
new 0 1103 664
assign 1 1103 664
addValue 1 1103 664
assign 1 1103 664
nlcGet 0 1103 664
assign 1 1103 664
toString 0 1103 664
addValue 1 1103 664
return 1 1105 664
assign 1 1109 664
containerGet 0 1109 664
assign 1 1109 664
def 1 1109 664
assign 1 1110 664
containerGet 0 1110 664
assign 1 1110 664
typenameGet 0 1110 664
assign 1 1111 664
METHODGet 0 1111 664
assign 1 1111 664
notEquals 1 1111 664
assign 1 1111 664
CLASSGet 0 1111 664
assign 1 1111 664
notEquals 1 1111 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1111 664
EXPRGet 0 1111 664
assign 1 1111 664
notEquals 1 1111 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1111 664
PROPERTIESGet 0 1111 664
assign 1 1111 664
notEquals 1 1111 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1111 664
CATCHGet 0 1111 664
assign 1 1111 664
notEquals 1 1111 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1113 664
new 0 1113 664
assign 1 1113 664
addValue 1 1113 664
assign 1 1113 664
getTraceInfo 1 1113 664
assign 1 1113 664
addValue 1 1113 664
assign 1 1113 664
new 0 1113 664
assign 1 1113 664
addValue 1 1113 664
addValue 1 1113 664
assign 1 1122 664
containerGet 0 1122 664
assign 1 1122 664
def 1 1122 664
assign 1 1122 664
containerGet 0 1122 664
assign 1 1122 664
containerGet 0 1122 664
assign 1 1122 664
def 1 1122 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1123 664
containerGet 0 1123 664
assign 1 1123 664
containerGet 0 1123 664
assign 1 1124 664
typenameGet 0 1124 664
assign 1 1125 664
METHODGet 0 1125 664
assign 1 1125 664
equals 1 1125 664
assign 1 1126 664
def 1 1126 664
assign 1 1127 664
undef 1 1127 664
assign 1 0 664
assign 1 1127 664
heldGet 0 1127 664
assign 1 1127 664
orgNameGet 0 1127 664
assign 1 1127 664
new 0 1127 664
assign 1 1127 664
notEquals 1 1127 664
assign 1 0 664
assign 1 0 664
assign 1 1130 664
new 0 1130 664
assign 1 1130 664
addValue 1 1130 664
addValue 1 1130 664
assign 1 1133 664
new 0 1133 664
assign 1 1133 664
greater 1 1133 664
assign 1 1134 664
libNameGet 0 1134 664
assign 1 1134 664
relEmitName 1 1134 664
assign 1 1134 664
addValue 1 1134 664
assign 1 1134 664
new 0 1134 664
assign 1 1134 664
addValue 1 1134 664
assign 1 1134 664
libNameGet 0 1134 664
assign 1 1134 664
relEmitName 1 1134 664
assign 1 1134 664
addValue 1 1134 664
assign 1 1134 664
new 0 1134 664
assign 1 1134 664
addValue 1 1134 664
assign 1 1134 664
toString 0 1134 664
assign 1 1134 664
addValue 1 1134 664
assign 1 1134 664
new 0 1134 664
assign 1 1134 664
addValue 1 1134 664
addValue 1 1134 664
assign 1 1137 664
countLines 2 1137 664
addValue 1 1138 664
assign 1 1139 664
assign 1 1140 664
sizeGet 0 1140 664
assign 1 1144 664
arrayIteratorGet 0 0 664
assign 1 1144 664
hasNextGet 0 1144 664
assign 1 1144 664
nextGet 0 1144 664
assign 1 1145 664
nlecGet 0 1145 664
addValue 1 1145 664
addValue 1 1147 664
assign 1 1148 664
new 0 1148 664
lengthSet 1 1148 664
addValue 1 1150 664
clear 0 1151 664
assign 1 1152 664
new 0 1152 664
assign 1 1153 664
new 0 1153 664
assign 1 1156 664
new 0 1156 664
assign 1 1157 664
assign 1 1158 664
new 0 1158 664
assign 1 1161 664
new 0 1161 664
assign 1 1161 664
addValue 1 1161 664
addValue 1 1161 664
assign 1 1162 664
assign 1 1163 664
assign 1 1165 664
EXPRGet 0 1165 664
assign 1 1165 664
notEquals 1 1165 664
assign 1 1165 664
PROPERTIESGet 0 1165 664
assign 1 1165 664
notEquals 1 1165 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1165 664
CLASSGet 0 1165 664
assign 1 1165 664
notEquals 1 1165 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1167 664
new 0 1167 664
assign 1 1167 664
addValue 1 1167 664
assign 1 1167 664
getTraceInfo 1 1167 664
assign 1 1167 664
addValue 1 1167 664
assign 1 1167 664
new 0 1167 664
assign 1 1167 664
addValue 1 1167 664
addValue 1 1167 664
assign 1 1173 664
new 0 1173 664
assign 1 1173 664
countLines 2 1173 664
return 1 1173 664
assign 1 1177 664
new 0 1177 664
assign 1 1178 664
new 0 1178 664
assign 1 1178 664
new 0 1178 664
assign 1 1178 664
getInt 2 1178 664
assign 1 1179 664
new 0 1179 664
assign 1 1180 664
sizeGet 0 1180 664
assign 1 1181 664
assign 1 1181 664
lesser 1 1181 664
getInt 2 1182 664
assign 1 1183 664
equals 1 1183 664
incrementValue 0 1184 664
incrementValue 0 1181 664
return 1 1187 664
assign 1 1191 664
containedGet 0 1191 664
assign 1 1191 664
firstGet 0 1191 664
assign 1 1191 664
containedGet 0 1191 664
assign 1 1191 664
firstGet 0 1191 664
assign 1 1191 664
formTarg 1 1191 664
assign 1 1192 664
containedGet 0 1192 664
assign 1 1192 664
firstGet 0 1192 664
assign 1 1192 664
containedGet 0 1192 664
assign 1 1192 664
firstGet 0 1192 664
assign 1 1192 664
heldGet 0 1192 664
assign 1 1192 664
isTypedGet 0 1192 664
assign 1 1192 664
not 0 1192 664
assign 1 0 664
assign 1 1192 664
containedGet 0 1192 664
assign 1 1192 664
firstGet 0 1192 664
assign 1 1192 664
containedGet 0 1192 664
assign 1 1192 664
firstGet 0 1192 664
assign 1 1192 664
heldGet 0 1192 664
assign 1 1192 664
namepathGet 0 1192 664
assign 1 1192 664
notEquals 1 1192 664
assign 1 0 664
assign 1 0 664
assign 1 1193 664
new 0 1193 664
assign 1 1195 664
new 0 1195 664
assign 1 1197 664
heldGet 0 1197 664
assign 1 1197 664
def 1 1197 664
assign 1 1197 664
heldGet 0 1197 664
assign 1 1197 664
new 0 1197 664
assign 1 1197 664
equals 1 1197 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1198 664
new 0 1198 664
assign 1 1200 664
new 0 1200 664
assign 1 1202 664
new 0 1202 664
assign 1 1204 664
new 0 1204 664
addValue 1 1204 664
assign 1 1208 664
addValue 1 1208 664
assign 1 1208 664
new 0 1208 664
addValue 1 1208 664
assign 1 1213 664
addValue 1 1213 664
assign 1 1213 664
new 0 1213 664
assign 1 1213 664
addValue 1 1213 664
assign 1 1213 664
addValue 1 1213 664
assign 1 1213 664
addValue 1 1213 664
assign 1 1213 664
libNameGet 0 1213 664
assign 1 1213 664
relEmitName 1 1213 664
assign 1 1213 664
addValue 1 1213 664
assign 1 1213 664
new 0 1213 664
addValue 1 1213 664
assign 1 1214 664
new 0 1214 664
assign 1 1214 664
emitting 1 1214 664
assign 1 1214 664
not 0 1214 664
assign 1 1215 664
new 0 1215 664
assign 1 1215 664
addValue 1 1215 664
assign 1 1215 664
formCast 1 1215 664
addValue 1 1215 664
addValue 1 1217 664
assign 1 1218 664
new 0 1218 664
assign 1 1218 664
emitting 1 1218 664
assign 1 1218 664
not 0 1218 664
assign 1 1219 664
new 0 1219 664
addValue 1 1219 664
assign 1 1221 664
new 0 1221 664
addValue 1 1221 664
assign 1 1224 664
new 0 1224 664
addValue 1 1224 664
assign 1 1226 664
new 0 1226 664
assign 1 1226 664
addValue 1 1226 664
assign 1 1226 664
addValue 1 1226 664
assign 1 1226 664
new 0 1226 664
addValue 1 1226 664
assign 1 1231 664
containedGet 0 1231 664
assign 1 1231 664
firstGet 0 1231 664
assign 1 1231 664
containedGet 0 1231 664
assign 1 1231 664
firstGet 0 1231 664
assign 1 1231 664
formTarg 1 1231 664
assign 1 1232 664
heldGet 0 1232 664
assign 1 1232 664
def 1 1232 664
assign 1 1232 664
heldGet 0 1232 664
assign 1 1232 664
new 0 1232 664
assign 1 1232 664
equals 1 1232 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1233 664
assign 1 1235 664
assign 1 1237 664
new 0 1237 664
assign 1 1237 664
addValue 1 1237 664
assign 1 1237 664
addValue 1 1237 664
assign 1 1237 664
addValue 1 1237 664
assign 1 1237 664
addValue 1 1237 664
assign 1 1237 664
new 0 1237 664
addValue 1 1237 664
assign 1 1244 664
finalAssignTo 2 1244 664
assign 1 1244 664
add 1 1244 664
assign 1 1244 664
new 0 1244 664
assign 1 1244 664
add 1 1244 664
assign 1 1244 664
add 1 1244 664
return 1 1244 664
assign 1 1249 664
typenameGet 0 1249 664
assign 1 1249 664
NULLGet 0 1249 664
assign 1 1249 664
equals 1 1249 664
assign 1 1250 664
new 0 1250 664
assign 1 1250 664
new 1 1250 664
throw 1 1250 664
assign 1 1252 664
heldGet 0 1252 664
assign 1 1252 664
nameGet 0 1252 664
assign 1 1252 664
new 0 1252 664
assign 1 1252 664
equals 1 1252 664
assign 1 1253 664
new 0 1253 664
assign 1 1253 664
new 1 1253 664
throw 1 1253 664
assign 1 1255 664
heldGet 0 1255 664
assign 1 1255 664
nameGet 0 1255 664
assign 1 1255 664
new 0 1255 664
assign 1 1255 664
equals 1 1255 664
assign 1 1256 664
new 0 1256 664
assign 1 1256 664
new 1 1256 664
throw 1 1256 664
assign 1 1258 664
new 0 1258 664
assign 1 1259 664
def 1 1259 664
assign 1 1260 664
getClassConfig 1 1260 664
assign 1 1260 664
formCast 1 1260 664
assign 1 1260 664
new 0 1260 664
assign 1 1260 664
add 1 1260 664
assign 1 1262 664
heldGet 0 1262 664
assign 1 1262 664
nameForVar 1 1262 664
assign 1 1262 664
new 0 1262 664
assign 1 1262 664
add 1 1262 664
assign 1 1262 664
add 1 1262 664
return 1 1262 664
assign 1 1266 664
new 0 1266 664
return 1 1266 664
assign 1 1270 664
new 0 1270 664
assign 1 1270 664
libNameGet 0 1270 664
assign 1 1270 664
relEmitName 1 1270 664
assign 1 1270 664
add 1 1270 664
assign 1 1270 664
new 0 1270 664
assign 1 1270 664
add 1 1270 664
return 1 1270 664
assign 1 1274 664
new 0 1274 664
assign 1 1274 664
addValue 1 1274 664
assign 1 1274 664
secondGet 0 1274 664
assign 1 1274 664
formTarg 1 1274 664
assign 1 1274 664
addValue 1 1274 664
assign 1 1274 664
new 0 1274 664
assign 1 1274 664
addValue 1 1274 664
addValue 1 1274 664
assign 1 1278 664
new 0 1278 664
assign 1 1278 664
add 1 1278 664
return 1 1278 664
assign 1 1283 664
heldGet 0 1283 664
assign 1 1283 664
nameGet 0 1283 664
put 1 1283 664
assign 1 1285 664
addValue 1 1287 664
assign 1 1291 664
countLines 2 1291 664
assign 1 1292 664
add 1 1292 664
assign 1 1293 664
sizeGet 0 1293 664
nlecSet 1 1295 664
assign 1 1298 664
heldGet 0 1298 664
assign 1 1298 664
orgNameGet 0 1298 664
assign 1 1298 664
new 0 1298 664
assign 1 1298 664
equals 1 1298 664
assign 1 1298 664
containedGet 0 1298 664
assign 1 1298 664
lengthGet 0 1298 664
assign 1 1298 664
new 0 1298 664
assign 1 1298 664
notEquals 1 1298 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1299 664
new 0 1299 664
assign 1 1299 664
containedGet 0 1299 664
assign 1 1299 664
lengthGet 0 1299 664
assign 1 1299 664
toString 0 1299 664
assign 1 1299 664
add 1 1299 664
assign 1 1300 664
new 0 1300 664
assign 1 1300 664
containedGet 0 1300 664
assign 1 1300 664
lengthGet 0 1300 664
assign 1 1300 664
lesser 1 1300 664
assign 1 1301 664
new 0 1301 664
assign 1 1301 664
add 1 1301 664
assign 1 1301 664
add 1 1301 664
assign 1 1301 664
new 0 1301 664
assign 1 1301 664
add 1 1301 664
assign 1 1301 664
containedGet 0 1301 664
assign 1 1301 664
get 1 1301 664
assign 1 1301 664
add 1 1301 664
assign 1 1300 664
increment 0 1300 664
assign 1 1303 664
new 2 1303 664
throw 1 1303 664
assign 1 1304 664
heldGet 0 1304 664
assign 1 1304 664
orgNameGet 0 1304 664
assign 1 1304 664
new 0 1304 664
assign 1 1304 664
equals 1 1304 664
assign 1 1304 664
containedGet 0 1304 664
assign 1 1304 664
firstGet 0 1304 664
assign 1 1304 664
heldGet 0 1304 664
assign 1 1304 664
nameGet 0 1304 664
assign 1 1304 664
new 0 1304 664
assign 1 1304 664
equals 1 1304 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1305 664
new 0 1305 664
assign 1 1305 664
new 2 1305 664
throw 1 1305 664
assign 1 1306 664
heldGet 0 1306 664
assign 1 1306 664
orgNameGet 0 1306 664
assign 1 1306 664
new 0 1306 664
assign 1 1306 664
equals 1 1306 664
acceptThrow 1 1307 664
return 1 1308 664
assign 1 1309 664
heldGet 0 1309 664
assign 1 1309 664
orgNameGet 0 1309 664
assign 1 1309 664
new 0 1309 664
assign 1 1309 664
equals 1 1309 664
assign 1 1313 664
heldGet 0 1313 664
assign 1 1313 664
checkTypesGet 0 1313 664
assign 1 1314 664
containedGet 0 1314 664
assign 1 1314 664
firstGet 0 1314 664
assign 1 1314 664
heldGet 0 1314 664
assign 1 1314 664
namepathGet 0 1314 664
assign 1 1316 664
secondGet 0 1316 664
assign 1 1316 664
typenameGet 0 1316 664
assign 1 1316 664
VARGet 0 1316 664
assign 1 1316 664
equals 1 1316 664
assign 1 1318 664
containedGet 0 1318 664
assign 1 1318 664
firstGet 0 1318 664
assign 1 1318 664
secondGet 0 1318 664
assign 1 1318 664
formTarg 1 1318 664
assign 1 1318 664
finalAssign 3 1318 664
addValue 1 1318 664
assign 1 1319 664
secondGet 0 1319 664
assign 1 1319 664
typenameGet 0 1319 664
assign 1 1319 664
NULLGet 0 1319 664
assign 1 1319 664
equals 1 1319 664
assign 1 1320 664
containedGet 0 1320 664
assign 1 1320 664
firstGet 0 1320 664
assign 1 1320 664
new 0 1320 664
assign 1 1320 664
finalAssign 3 1320 664
addValue 1 1320 664
assign 1 1321 664
secondGet 0 1321 664
assign 1 1321 664
typenameGet 0 1321 664
assign 1 1321 664
TRUEGet 0 1321 664
assign 1 1321 664
equals 1 1321 664
assign 1 1322 664
containedGet 0 1322 664
assign 1 1322 664
firstGet 0 1322 664
assign 1 1322 664
finalAssign 3 1322 664
addValue 1 1322 664
assign 1 1323 664
secondGet 0 1323 664
assign 1 1323 664
typenameGet 0 1323 664
assign 1 1323 664
FALSEGet 0 1323 664
assign 1 1323 664
equals 1 1323 664
assign 1 1324 664
containedGet 0 1324 664
assign 1 1324 664
firstGet 0 1324 664
assign 1 1324 664
finalAssign 3 1324 664
addValue 1 1324 664
assign 1 1325 664
secondGet 0 1325 664
assign 1 1325 664
heldGet 0 1325 664
assign 1 1325 664
nameGet 0 1325 664
assign 1 1325 664
new 0 1325 664
assign 1 1325 664
equals 1 1325 664
assign 1 0 664
assign 1 1325 664
secondGet 0 1325 664
assign 1 1325 664
heldGet 0 1325 664
assign 1 1325 664
nameGet 0 1325 664
assign 1 1325 664
new 0 1325 664
assign 1 1325 664
equals 1 1325 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1326 664
secondGet 0 1326 664
assign 1 1326 664
heldGet 0 1326 664
assign 1 1326 664
nameGet 0 1326 664
assign 1 1326 664
new 0 1326 664
assign 1 1326 664
equals 1 1326 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1326 664
secondGet 0 1326 664
assign 1 1326 664
heldGet 0 1326 664
assign 1 1326 664
nameGet 0 1326 664
assign 1 1326 664
new 0 1326 664
assign 1 1326 664
equals 1 1326 664
assign 1 0 664
assign 1 0 664
assign 1 1333 664
heldGet 0 1333 664
assign 1 1333 664
checkTypesGet 0 1333 664
assign 1 1334 664
containedGet 0 1334 664
assign 1 1334 664
firstGet 0 1334 664
assign 1 1334 664
heldGet 0 1334 664
assign 1 1334 664
namepathGet 0 1334 664
assign 1 1334 664
toString 0 1334 664
assign 1 1334 664
new 0 1334 664
assign 1 1334 664
notEquals 1 1334 664
assign 1 1335 664
new 0 1335 664
assign 1 1335 664
new 2 1335 664
throw 1 1335 664
assign 1 1338 664
secondGet 0 1338 664
assign 1 1338 664
heldGet 0 1338 664
assign 1 1338 664
nameGet 0 1338 664
assign 1 1338 664
new 0 1338 664
assign 1 1338 664
begins 1 1338 664
assign 1 1339 664
assign 1 1340 664
assign 1 1342 664
assign 1 1343 664
assign 1 1345 664
new 0 1345 664
assign 1 1345 664
addValue 1 1345 664
assign 1 1345 664
secondGet 0 1345 664
assign 1 1345 664
secondGet 0 1345 664
assign 1 1345 664
formTarg 1 1345 664
assign 1 1345 664
addValue 1 1345 664
assign 1 1345 664
new 0 1345 664
assign 1 1345 664
addValue 1 1345 664
addValue 1 1345 664
assign 1 1346 664
containedGet 0 1346 664
assign 1 1346 664
firstGet 0 1346 664
assign 1 1346 664
finalAssign 3 1346 664
addValue 1 1346 664
assign 1 1347 664
new 0 1347 664
assign 1 1347 664
addValue 1 1347 664
addValue 1 1347 664
assign 1 1348 664
containedGet 0 1348 664
assign 1 1348 664
firstGet 0 1348 664
assign 1 1348 664
finalAssign 3 1348 664
addValue 1 1348 664
assign 1 1349 664
new 0 1349 664
assign 1 1349 664
addValue 1 1349 664
addValue 1 1349 664
return 1 1351 664
assign 1 1352 664
heldGet 0 1352 664
assign 1 1352 664
orgNameGet 0 1352 664
assign 1 1352 664
new 0 1352 664
assign 1 1352 664
equals 1 1352 664
assign 1 1354 664
new 0 1354 664
assign 1 1355 664
heldGet 0 1355 664
assign 1 1355 664
checkTypesGet 0 1355 664
assign 1 1356 664
formCast 1 1356 664
assign 1 1356 664
new 0 1356 664
assign 1 1356 664
add 1 1356 664
assign 1 1358 664
new 0 1358 664
assign 1 1358 664
addValue 1 1358 664
assign 1 1358 664
addValue 1 1358 664
assign 1 1358 664
secondGet 0 1358 664
assign 1 1358 664
formTarg 1 1358 664
assign 1 1358 664
addValue 1 1358 664
assign 1 1358 664
new 0 1358 664
assign 1 1358 664
addValue 1 1358 664
addValue 1 1358 664
return 1 1359 664
assign 1 1360 664
heldGet 0 1360 664
assign 1 1360 664
nameGet 0 1360 664
assign 1 1360 664
new 0 1360 664
assign 1 1360 664
equals 1 1360 664
assign 1 0 664
assign 1 1360 664
heldGet 0 1360 664
assign 1 1360 664
nameGet 0 1360 664
assign 1 1360 664
new 0 1360 664
assign 1 1360 664
equals 1 1360 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1360 664
heldGet 0 1360 664
assign 1 1360 664
nameGet 0 1360 664
assign 1 1360 664
new 0 1360 664
assign 1 1360 664
equals 1 1360 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1360 664
heldGet 0 1360 664
assign 1 1360 664
nameGet 0 1360 664
assign 1 1360 664
new 0 1360 664
assign 1 1360 664
equals 1 1360 664
assign 1 0 664
assign 1 0 664
return 1 1362 664
assign 1 1365 664
heldGet 0 1365 664
assign 1 1365 664
nameGet 0 1365 664
assign 1 1365 664
heldGet 0 1365 664
assign 1 1365 664
orgNameGet 0 1365 664
assign 1 1365 664
new 0 1365 664
assign 1 1365 664
add 1 1365 664
assign 1 1365 664
heldGet 0 1365 664
assign 1 1365 664
numargsGet 0 1365 664
assign 1 1365 664
add 1 1365 664
assign 1 1365 664
notEquals 1 1365 664
assign 1 1366 664
new 0 1366 664
assign 1 1366 664
heldGet 0 1366 664
assign 1 1366 664
nameGet 0 1366 664
assign 1 1366 664
add 1 1366 664
assign 1 1366 664
new 0 1366 664
assign 1 1366 664
add 1 1366 664
assign 1 1366 664
heldGet 0 1366 664
assign 1 1366 664
orgNameGet 0 1366 664
assign 1 1366 664
add 1 1366 664
assign 1 1366 664
new 0 1366 664
assign 1 1366 664
add 1 1366 664
assign 1 1366 664
heldGet 0 1366 664
assign 1 1366 664
numargsGet 0 1366 664
assign 1 1366 664
add 1 1366 664
assign 1 1366 664
new 1 1366 664
throw 1 1366 664
assign 1 1369 664
new 0 1369 664
assign 1 1370 664
new 0 1370 664
assign 1 1371 664
new 0 1371 664
assign 1 1372 664
new 0 1372 664
assign 1 1374 664
heldGet 0 1374 664
assign 1 1374 664
isConstructGet 0 1374 664
assign 1 1375 664
new 0 1375 664
assign 1 1376 664
heldGet 0 1376 664
assign 1 1376 664
newNpGet 0 1376 664
assign 1 1376 664
getClassConfig 1 1376 664
assign 1 1377 664
containedGet 0 1377 664
assign 1 1377 664
firstGet 0 1377 664
assign 1 1377 664
heldGet 0 1377 664
assign 1 1377 664
nameGet 0 1377 664
assign 1 1377 664
new 0 1377 664
assign 1 1377 664
equals 1 1377 664
assign 1 1378 664
new 0 1378 664
assign 1 1379 664
containedGet 0 1379 664
assign 1 1379 664
firstGet 0 1379 664
assign 1 1379 664
heldGet 0 1379 664
assign 1 1379 664
nameGet 0 1379 664
assign 1 1379 664
new 0 1379 664
assign 1 1379 664
equals 1 1379 664
assign 1 1380 664
new 0 1380 664
assign 1 1381 664
new 0 1381 664
addValue 1 1382 664
assign 1 1383 664
heldGet 0 1383 664
assign 1 1383 664
new 0 1383 664
superCallSet 1 1383 664
assign 1 1388 664
new 0 1388 664
assign 1 1389 664
new 0 1389 664
assign 1 1391 664
new 0 1391 664
assign 1 1392 664
containedGet 0 1392 664
assign 1 1392 664
iteratorGet 0 1392 664
assign 1 1392 664
hasNextGet 0 1392 664
assign 1 1393 664
heldGet 0 1393 664
assign 1 1393 664
argCastsGet 0 1393 664
assign 1 1394 664
nextGet 0 1394 664
assign 1 1395 664
new 0 1395 664
assign 1 1395 664
equals 1 1395 664
assign 1 1397 664
formTarg 1 1397 664
assign 1 1398 664
assign 1 1399 664
heldGet 0 1399 664
assign 1 1399 664
isTypedGet 0 1399 664
assign 1 1400 664
new 0 1400 664
assign 1 0 664
assign 1 1403 664
lesser 1 1403 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1403 664
useDynMethodsGet 0 1403 664
assign 1 1403 664
not 0 1403 664
assign 1 0 664
assign 1 0 664
assign 1 1404 664
new 0 1404 664
assign 1 1404 664
greater 1 1404 664
assign 1 1405 664
new 0 1405 664
addValue 1 1405 664
assign 1 1407 664
lengthGet 0 1407 664
assign 1 1407 664
greater 1 1407 664
assign 1 1407 664
get 1 1407 664
assign 1 1407 664
def 1 1407 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1408 664
get 1 1408 664
assign 1 1408 664
getClassConfig 1 1408 664
assign 1 1408 664
formCast 1 1408 664
assign 1 1408 664
addValue 1 1408 664
assign 1 1408 664
new 0 1408 664
addValue 1 1408 664
assign 1 1410 664
formTarg 1 1410 664
addValue 1 1410 664
assign 1 1413 664
subtract 1 1413 664
assign 1 1414 664
new 0 1414 664
assign 1 1414 664
addValue 1 1414 664
assign 1 1414 664
toString 0 1414 664
assign 1 1414 664
addValue 1 1414 664
assign 1 1414 664
new 0 1414 664
assign 1 1414 664
addValue 1 1414 664
assign 1 1414 664
formTarg 1 1414 664
assign 1 1414 664
addValue 1 1414 664
assign 1 1414 664
new 0 1414 664
assign 1 1414 664
addValue 1 1414 664
addValue 1 1414 664
assign 1 1417 664
increment 0 1417 664
assign 1 1421 664
decrement 0 1421 664
assign 1 1423 664
not 0 1423 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1424 664
new 0 1424 664
assign 1 1424 664
new 2 1424 664
throw 1 1424 664
assign 1 1427 664
new 0 1427 664
assign 1 1428 664
new 0 1428 664
assign 1 1431 664
containerGet 0 1431 664
assign 1 1431 664
typenameGet 0 1431 664
assign 1 1431 664
CALLGet 0 1431 664
assign 1 1431 664
equals 1 1431 664
assign 1 1431 664
containerGet 0 1431 664
assign 1 1431 664
heldGet 0 1431 664
assign 1 1431 664
orgNameGet 0 1431 664
assign 1 1431 664
new 0 1431 664
assign 1 1431 664
equals 1 1431 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1432 664
containerGet 0 1432 664
assign 1 1432 664
isOnceAssign 1 1432 664
assign 1 1432 664
npGet 0 1432 664
assign 1 1432 664
equals 1 1432 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1432 664
not 0 1432 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1433 664
new 0 1433 664
assign 1 1434 664
toString 0 1434 664
assign 1 1434 664
onceVarDec 1 1434 664
assign 1 1435 664
increment 0 1435 664
assign 1 1437 664
containerGet 0 1437 664
assign 1 1437 664
containedGet 0 1437 664
assign 1 1437 664
firstGet 0 1437 664
assign 1 1437 664
heldGet 0 1437 664
assign 1 1437 664
isTypedGet 0 1437 664
assign 1 1437 664
not 0 1437 664
assign 1 1438 664
libNameGet 0 1438 664
assign 1 1438 664
relEmitName 1 1438 664
assign 1 1438 664
onceDec 2 1438 664
assign 1 1440 664
containerGet 0 1440 664
assign 1 1440 664
containedGet 0 1440 664
assign 1 1440 664
firstGet 0 1440 664
assign 1 1440 664
heldGet 0 1440 664
assign 1 1440 664
namepathGet 0 1440 664
assign 1 1440 664
getClassConfig 1 1440 664
assign 1 1440 664
libNameGet 0 1440 664
assign 1 1440 664
relEmitName 1 1440 664
assign 1 1440 664
onceDec 2 1440 664
assign 1 1445 664
containerGet 0 1445 664
assign 1 1445 664
heldGet 0 1445 664
assign 1 1445 664
checkTypesGet 0 1445 664
assign 1 1447 664
containerGet 0 1447 664
assign 1 1447 664
containedGet 0 1447 664
assign 1 1447 664
firstGet 0 1447 664
assign 1 1447 664
heldGet 0 1447 664
assign 1 1447 664
namepathGet 0 1447 664
assign 1 1449 664
containerGet 0 1449 664
assign 1 1449 664
containedGet 0 1449 664
assign 1 1449 664
firstGet 0 1449 664
assign 1 1449 664
finalAssignTo 2 1449 664
assign 1 1451 664
new 0 1451 664
assign 1 1457 664
containerGet 0 1457 664
assign 1 1457 664
containedGet 0 1457 664
assign 1 1457 664
firstGet 0 1457 664
assign 1 1457 664
heldGet 0 1457 664
assign 1 1457 664
nameForVar 1 1457 664
assign 1 1457 664
new 0 1457 664
assign 1 1457 664
add 1 1457 664
assign 1 1457 664
add 1 1457 664
assign 1 1457 664
new 0 1457 664
assign 1 1457 664
add 1 1457 664
assign 1 1457 664
add 1 1457 664
assign 1 1458 664
def 1 1458 664
assign 1 1459 664
getClassConfig 1 1459 664
assign 1 1459 664
formCast 1 1459 664
assign 1 1459 664
new 0 1459 664
assign 1 1459 664
add 1 1459 664
assign 1 1461 664
new 0 1461 664
assign 1 1463 664
new 0 1463 664
assign 1 1463 664
add 1 1463 664
assign 1 1463 664
add 1 1463 664
assign 1 0 664
assign 1 1467 664
useDynMethodsGet 0 1467 664
assign 1 1467 664
not 0 1467 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1467 664
heldGet 0 1467 664
assign 1 1467 664
isLiteralGet 0 1467 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1468 664
new 0 1468 664
assign 1 1472 664
new 0 1472 664
assign 1 1472 664
emitting 1 1472 664
assign 1 1473 664
new 0 1473 664
assign 1 1473 664
addValue 1 1473 664
assign 1 1473 664
emitNameGet 0 1473 664
assign 1 1473 664
addValue 1 1473 664
assign 1 1473 664
new 0 1473 664
assign 1 1473 664
addValue 1 1473 664
addValue 1 1473 664
assign 1 1474 664
new 0 1474 664
assign 1 1474 664
emitting 1 1474 664
assign 1 1475 664
new 0 1475 664
assign 1 1475 664
addValue 1 1475 664
assign 1 1475 664
emitNameGet 0 1475 664
assign 1 1475 664
addValue 1 1475 664
assign 1 1475 664
new 0 1475 664
assign 1 1475 664
addValue 1 1475 664
addValue 1 1475 664
assign 1 1477 664
new 0 1477 664
assign 1 1477 664
add 1 1477 664
assign 1 1477 664
new 0 1477 664
assign 1 1477 664
add 1 1477 664
assign 1 1477 664
addValue 1 1477 664
addValue 1 1477 664
assign 1 0 664
assign 1 1482 664
useDynMethodsGet 0 1482 664
assign 1 1482 664
not 0 1482 664
assign 1 0 664
assign 1 0 664
assign 1 1484 664
heldGet 0 1484 664
assign 1 1484 664
isLiteralGet 0 1484 664
assign 1 1485 664
npGet 0 1485 664
assign 1 1485 664
equals 1 1485 664
assign 1 1486 664
lintConstruct 2 1486 664
assign 1 1487 664
npGet 0 1487 664
assign 1 1487 664
equals 1 1487 664
assign 1 1488 664
lfloatConstruct 2 1488 664
assign 1 1489 664
npGet 0 1489 664
assign 1 1489 664
equals 1 1489 664
assign 1 1491 664
new 0 1491 664
assign 1 1491 664
heldGet 0 1491 664
assign 1 1491 664
belsCountGet 0 1491 664
assign 1 1491 664
toString 0 1491 664
assign 1 1491 664
add 1 1491 664
assign 1 1492 664
heldGet 0 1492 664
assign 1 1492 664
belsCountGet 0 1492 664
incrementValue 0 1492 664
assign 1 1493 664
new 0 1493 664
lstringStart 2 1494 664
assign 1 1496 664
heldGet 0 1496 664
assign 1 1496 664
literalValueGet 0 1496 664
assign 1 1498 664
wideStringGet 0 1498 664
assign 1 1499 664
assign 1 1501 664
new 0 1501 664
assign 1 1501 664
new 0 1501 664
assign 1 1501 664
new 0 1501 664
assign 1 1501 664
quoteGet 0 1501 664
assign 1 1501 664
add 1 1501 664
assign 1 1501 664
add 1 1501 664
assign 1 1501 664
new 0 1501 664
assign 1 1501 664
quoteGet 0 1501 664
assign 1 1501 664
add 1 1501 664
assign 1 1501 664
new 0 1501 664
assign 1 1501 664
add 1 1501 664
assign 1 1501 664
unmarshall 1 1501 664
assign 1 1501 664
firstGet 0 1501 664
assign 1 1504 664
sizeGet 0 1504 664
assign 1 1505 664
new 0 1505 664
assign 1 1506 664
new 0 1506 664
assign 1 1507 664
new 0 1507 664
assign 1 1507 664
new 1 1507 664
assign 1 1508 664
lesser 1 1508 664
assign 1 1509 664
new 0 1509 664
assign 1 1509 664
greater 1 1509 664
assign 1 1510 664
new 0 1510 664
assign 1 1510 664
once 0 1510 664
addValue 1 1510 664
lstringByte 5 1512 664
incrementValue 0 1513 664
lstringEnd 1 1515 664
addValue 1 1517 664
assign 1 1518 664
lstringConstruct 5 1518 664
assign 1 1519 664
npGet 0 1519 664
assign 1 1519 664
equals 1 1519 664
assign 1 1520 664
heldGet 0 1520 664
assign 1 1520 664
literalValueGet 0 1520 664
assign 1 1520 664
new 0 1520 664
assign 1 1520 664
equals 1 1520 664
assign 1 1521 664
assign 1 1523 664
assign 1 1527 664
new 0 1527 664
assign 1 1527 664
npGet 0 1527 664
assign 1 1527 664
toString 0 1527 664
assign 1 1527 664
add 1 1527 664
assign 1 1527 664
new 1 1527 664
throw 1 1527 664
assign 1 1530 664
new 0 1530 664
assign 1 1530 664
libNameGet 0 1530 664
assign 1 1530 664
relEmitName 1 1530 664
assign 1 1530 664
add 1 1530 664
assign 1 1530 664
new 0 1530 664
assign 1 1530 664
add 1 1530 664
assign 1 1532 664
new 0 1532 664
assign 1 1532 664
add 1 1532 664
assign 1 1532 664
new 0 1532 664
assign 1 1532 664
add 1 1532 664
assign 1 1534 664
getInitialInst 1 1534 664
assign 1 1536 664
heldGet 0 1536 664
assign 1 1536 664
isLiteralGet 0 1536 664
assign 1 1537 664
npGet 0 1537 664
assign 1 1537 664
equals 1 1537 664
assign 1 1539 664
new 0 1539 664
assign 1 1540 664
containerGet 0 1540 664
assign 1 1540 664
containedGet 0 1540 664
assign 1 1540 664
firstGet 0 1540 664
assign 1 1540 664
heldGet 0 1540 664
assign 1 1540 664
allCallsGet 0 1540 664
assign 1 1540 664
iteratorGet 0 0 664
assign 1 1540 664
hasNextGet 0 1540 664
assign 1 1540 664
nextGet 0 1540 664
assign 1 1541 664
keyGet 0 1541 664
assign 1 1541 664
heldGet 0 1541 664
assign 1 1541 664
nameGet 0 1541 664
assign 1 1541 664
addValue 1 1541 664
assign 1 1541 664
new 0 1541 664
addValue 1 1541 664
assign 1 1543 664
new 0 1543 664
assign 1 1543 664
add 1 1543 664
assign 1 1543 664
new 1 1543 664
throw 1 1543 664
assign 1 1546 664
heldGet 0 1546 664
assign 1 1546 664
literalValueGet 0 1546 664
assign 1 1546 664
new 0 1546 664
assign 1 1546 664
equals 1 1546 664
assign 1 1547 664
assign 1 1549 664
assign 1 1553 664
addValue 1 1553 664
assign 1 1553 664
addValue 1 1553 664
assign 1 1553 664
addValue 1 1553 664
assign 1 1553 664
new 0 1553 664
assign 1 1553 664
addValue 1 1553 664
addValue 1 1553 664
assign 1 1555 664
addValue 1 1555 664
assign 1 1555 664
addValue 1 1555 664
assign 1 1555 664
new 0 1555 664
assign 1 1555 664
addValue 1 1555 664
addValue 1 1555 664
assign 1 1558 664
npGet 0 1558 664
assign 1 1558 664
getSynNp 1 1558 664
assign 1 1559 664
hasDefaultGet 0 1559 664
assign 1 1560 664
assign 1 1563 664
assign 1 1566 664
mtdMapGet 0 1566 664
assign 1 1566 664
new 0 1566 664
assign 1 1566 664
get 1 1566 664
assign 1 1567 664
new 0 1567 664
assign 1 1567 664
notEmpty 1 1567 664
assign 1 1567 664
heldGet 0 1567 664
assign 1 1567 664
nameGet 0 1567 664
assign 1 1567 664
new 0 1567 664
assign 1 1567 664
equals 1 1567 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1567 664
originGet 0 1567 664
assign 1 1567 664
toString 0 1567 664
assign 1 1567 664
new 0 1567 664
assign 1 1567 664
equals 1 1567 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1569 664
addValue 1 1569 664
assign 1 1569 664
addValue 1 1569 664
assign 1 1569 664
new 0 1569 664
assign 1 1569 664
addValue 1 1569 664
addValue 1 1569 664
assign 1 1571 664
addValue 1 1571 664
assign 1 1571 664
addValue 1 1571 664
assign 1 1571 664
new 0 1571 664
assign 1 1571 664
addValue 1 1571 664
assign 1 1571 664
emitNameForCall 1 1571 664
assign 1 1571 664
addValue 1 1571 664
assign 1 1571 664
new 0 1571 664
assign 1 1571 664
addValue 1 1571 664
assign 1 1571 664
addValue 1 1571 664
assign 1 1571 664
new 0 1571 664
assign 1 1571 664
addValue 1 1571 664
addValue 1 1571 664
assign 1 1575 664
not 0 1575 664
assign 1 1576 664
addValue 1 1576 664
assign 1 1576 664
addValue 1 1576 664
assign 1 1576 664
new 0 1576 664
assign 1 1576 664
addValue 1 1576 664
assign 1 1576 664
emitNameForCall 1 1576 664
assign 1 1576 664
addValue 1 1576 664
assign 1 1576 664
new 0 1576 664
assign 1 1576 664
addValue 1 1576 664
assign 1 1576 664
addValue 1 1576 664
assign 1 1576 664
new 0 1576 664
assign 1 1576 664
addValue 1 1576 664
addValue 1 1576 664
assign 1 1578 664
addValue 1 1578 664
assign 1 1578 664
addValue 1 1578 664
assign 1 1578 664
new 0 1578 664
assign 1 1578 664
addValue 1 1578 664
assign 1 1578 664
emitNameForCall 1 1578 664
assign 1 1578 664
addValue 1 1578 664
assign 1 1578 664
new 0 1578 664
assign 1 1578 664
addValue 1 1578 664
assign 1 1578 664
addValue 1 1578 664
assign 1 1578 664
new 0 1578 664
assign 1 1578 664
addValue 1 1578 664
addValue 1 1578 664
assign 1 1582 664
lesser 1 1582 664
assign 1 1583 664
toString 0 1583 664
assign 1 1584 664
new 0 1584 664
assign 1 1586 664
new 0 1586 664
assign 1 1587 664
subtract 1 1587 664
assign 1 1587 664
new 0 1587 664
assign 1 1587 664
add 1 1587 664
assign 1 1588 664
greater 1 1588 664
assign 1 1589 664
addValue 1 1591 664
assign 1 1592 664
new 0 1592 664
assign 1 1594 664
new 0 1594 664
assign 1 1594 664
greater 1 1594 664
assign 1 1595 664
new 0 1595 664
assign 1 1597 664
new 0 1597 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
new 0 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
new 0 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
heldGet 0 1599 664
assign 1 1599 664
nameGet 0 1599 664
assign 1 1599 664
hashGet 0 1599 664
assign 1 1599 664
toString 0 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
new 0 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
new 0 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
heldGet 0 1599 664
assign 1 1599 664
nameGet 0 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
addValue 1 1599 664
assign 1 1599 664
new 0 1599 664
assign 1 1599 664
addValue 1 1599 664
addValue 1 1599 664
assign 1 1603 664
not 0 1603 664
assign 1 1605 664
new 0 1605 664
assign 1 1605 664
addValue 1 1605 664
addValue 1 1605 664
assign 1 1606 664
new 0 1606 664
assign 1 1606 664
emitting 1 1606 664
assign 1 0 664
assign 1 1606 664
new 0 1606 664
assign 1 1606 664
emitting 1 1606 664
assign 1 0 664
assign 1 0 664
assign 1 1608 664
new 0 1608 664
assign 1 1608 664
addValue 1 1608 664
addValue 1 1608 664
addValue 1 1611 664
assign 1 1612 664
not 0 1612 664
assign 1 1613 664
isEmptyGet 0 1613 664
assign 1 1613 664
not 0 1613 664
assign 1 1614 664
addValue 1 1614 664
assign 1 1614 664
addValue 1 1614 664
assign 1 1614 664
new 0 1614 664
assign 1 1614 664
addValue 1 1614 664
addValue 1 1614 664
assign 1 1622 664
new 0 1622 664
assign 1 1623 664
new 0 1623 664
assign 1 1623 664
emitting 1 1623 664
assign 1 1624 664
new 0 1624 664
assign 1 1624 664
addValue 1 1624 664
assign 1 1624 664
addValue 1 1624 664
assign 1 1624 664
new 0 1624 664
addValue 1 1624 664
assign 1 1626 664
new 0 1626 664
assign 1 1626 664
addValue 1 1626 664
assign 1 1626 664
addValue 1 1626 664
assign 1 1626 664
new 0 1626 664
addValue 1 1626 664
assign 1 1628 664
new 0 1628 664
addValue 1 1628 664
return 1 1629 664
assign 1 1633 664
libNameGet 0 1633 664
assign 1 1633 664
relEmitName 1 1633 664
assign 1 1633 664
new 0 1633 664
assign 1 1633 664
add 1 1633 664
return 1 1633 664
assign 1 1637 664
new 0 1637 664
assign 1 1637 664
libNameGet 0 1637 664
assign 1 1637 664
relEmitName 1 1637 664
assign 1 1637 664
add 1 1637 664
assign 1 1637 664
new 0 1637 664
assign 1 1637 664
add 1 1637 664
assign 1 1637 664
heldGet 0 1637 664
assign 1 1637 664
literalValueGet 0 1637 664
assign 1 1637 664
add 1 1637 664
assign 1 1637 664
new 0 1637 664
assign 1 1637 664
add 1 1637 664
return 1 1637 664
assign 1 1641 664
new 0 1641 664
assign 1 1641 664
libNameGet 0 1641 664
assign 1 1641 664
relEmitName 1 1641 664
assign 1 1641 664
add 1 1641 664
assign 1 1641 664
new 0 1641 664
assign 1 1641 664
add 1 1641 664
assign 1 1641 664
heldGet 0 1641 664
assign 1 1641 664
literalValueGet 0 1641 664
assign 1 1641 664
add 1 1641 664
assign 1 1641 664
new 0 1641 664
assign 1 1641 664
add 1 1641 664
return 1 1641 664
assign 1 1646 665
new 0 1646 665
assign 1 1646 665
libNameGet 0 1646 665
assign 1 1646 665
relEmitName 1 1646 665
assign 1 1646 665
add 1 1646 665
assign 1 1646 665
new 0 1646 665
assign 1 1646 665
add 1 1646 665
assign 1 1646 665
add 1 1646 665
assign 1 1646 665
new 0 1646 665
assign 1 1646 665
add 1 1646 665
assign 1 1646 665
add 1 1646 665
assign 1 1646 665
new 0 1646 665
assign 1 1646 665
add 1 1646 665
return 1 1646 665
assign 1 1648 665
new 0 1648 665
assign 1 1648 665
libNameGet 0 1648 665
assign 1 1648 665
relEmitName 1 1648 665
assign 1 1648 665
add 1 1648 665
assign 1 1648 665
new 0 1648 665
assign 1 1648 665
add 1 1648 665
assign 1 1648 665
add 1 1648 665
assign 1 1648 665
new 0 1648 665
assign 1 1648 665
add 1 1648 665
assign 1 1648 665
add 1 1648 665
assign 1 1648 665
new 0 1648 665
assign 1 1648 665
add 1 1648 665
return 1 1648 665
assign 1 1652 664
new 0 1652 664
assign 1 1652 664
addValue 1 1652 664
assign 1 1652 664
addValue 1 1652 664
assign 1 1652 664
new 0 1652 664
addValue 1 1652 664
assign 1 1663 664
new 0 1663 664
assign 1 1663 664
addValue 1 1663 664
addValue 1 1663 664
assign 1 1667 664
heldGet 0 1667 664
assign 1 1667 664
isManyGet 0 1667 664
assign 1 1668 664
new 0 1668 664
return 1 1668 664
assign 1 1670 664
heldGet 0 1670 664
assign 1 1670 664
isOnceGet 0 1670 664
assign 1 0 664
assign 1 1670 664
isLiteralOnceGet 0 1670 664
assign 1 0 664
assign 1 0 664
assign 1 1671 664
new 0 1671 664
return 1 1671 664
assign 1 1673 664
new 0 1673 664
return 1 1673 664
assign 1 1677 664
heldGet 0 1677 664
assign 1 1677 664
langsGet 0 1677 664
assign 1 1677 664
emitLangGet 0 1677 664
assign 1 1677 664
has 1 1677 664
assign 1 1678 664
heldGet 0 1678 664
assign 1 1678 664
textGet 0 1678 664
assign 1 1678 664
emitReplace 1 1678 664
addValue 1 1678 664
assign 1 1683 664
new 0 1683 664
assign 1 1684 664
new 0 1684 664
assign 1 1684 664
new 0 1684 664
assign 1 1684 664
new 2 1684 664
assign 1 1685 664
tokenize 1 1685 664
assign 1 1686 664
new 0 1686 664
assign 1 1686 664
has 1 1686 664
assign 1 0 664
assign 1 1686 664
new 0 1686 664
assign 1 1686 664
has 1 1686 664
assign 1 1686 664
not 0 1686 664
assign 1 0 664
assign 1 0 664
return 1 1687 664
assign 1 1689 664
new 0 1689 664
assign 1 1690 664
linkedListIteratorGet 0 0 664
assign 1 1690 664
hasNextGet 0 1690 664
assign 1 1690 664
nextGet 0 1690 664
assign 1 1691 664
new 0 1691 664
assign 1 1691 664
equals 1 1691 664
assign 1 1691 664
new 0 1691 664
assign 1 1691 664
equals 1 1691 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1693 664
new 0 1693 664
assign 1 1694 664
new 0 1694 664
assign 1 1694 664
equals 1 1694 664
assign 1 1695 664
new 0 1695 664
assign 1 1695 664
equals 1 1695 664
assign 1 1696 664
new 0 1696 664
assign 1 1697 664
new 0 1697 664
assign 1 1699 664
new 0 1699 664
assign 1 1699 664
equals 1 1699 664
assign 1 1701 664
new 0 1701 664
assign 1 1702 664
new 0 1702 664
assign 1 1702 664
equals 1 1702 664
assign 1 1703 664
assign 1 1704 664
new 0 1704 664
assign 1 1704 664
equals 1 1704 664
assign 1 1706 664
new 1 1706 664
assign 1 1707 664
getEmitName 1 1707 664
addValue 1 1709 664
assign 1 1711 664
new 0 1711 664
assign 1 1712 664
new 0 1712 664
assign 1 1712 664
equals 1 1712 664
assign 1 1714 664
new 0 1714 664
addValue 1 1716 664
return 1 1719 664
assign 1 1723 664
new 0 1723 664
assign 1 1724 664
heldGet 0 1724 664
assign 1 1724 664
valueGet 0 1724 664
assign 1 1724 664
new 0 1724 664
assign 1 1724 664
equals 1 1724 664
assign 1 1725 664
new 0 1725 664
assign 1 1727 664
new 0 1727 664
assign 1 1730 664
heldGet 0 1730 664
assign 1 1730 664
langsGet 0 1730 664
assign 1 1730 664
emitLangGet 0 1730 664
assign 1 1730 664
has 1 1730 664
assign 1 1731 664
new 0 1731 664
assign 1 1733 664
emitFlagsGet 0 1733 664
assign 1 1733 664
def 1 1733 664
assign 1 1734 664
emitFlagsGet 0 1734 664
assign 1 1734 664
iteratorGet 0 0 664
assign 1 1734 664
hasNextGet 0 1734 664
assign 1 1734 664
nextGet 0 1734 664
assign 1 1735 664
heldGet 0 1735 664
assign 1 1735 664
langsGet 0 1735 664
assign 1 1735 664
has 1 1735 664
assign 1 1736 664
new 0 1736 664
assign 1 1741 664
new 0 1741 664
assign 1 1742 664
emitFlagsGet 0 1742 664
assign 1 1742 664
def 1 1742 664
assign 1 1743 664
emitFlagsGet 0 1743 664
assign 1 1743 664
iteratorGet 0 0 664
assign 1 1743 664
hasNextGet 0 1743 664
assign 1 1743 664
nextGet 0 1743 664
assign 1 1744 664
heldGet 0 1744 664
assign 1 1744 664
langsGet 0 1744 664
assign 1 1744 664
has 1 1744 664
assign 1 1745 664
new 0 1745 664
assign 1 1749 664
not 0 1749 664
assign 1 1749 664
heldGet 0 1749 664
assign 1 1749 664
langsGet 0 1749 664
assign 1 1749 664
emitLangGet 0 1749 664
assign 1 1749 664
has 1 1749 664
assign 1 1749 664
not 0 1749 664
assign 1 0 664
assign 1 0 664
assign 1 0 664
assign 1 1750 664
new 0 1750 664
assign 1 1754 664
nextDescendGet 0 1754 664
return 1 1754 664
assign 1 1756 664
nextPeerGet 0 1756 664
return 1 1756 664
assign 1 1760 664
typenameGet 0 1760 664
assign 1 1760 664
CLASSGet 0 1760 664
assign 1 1760 664
equals 1 1760 664
acceptClass 1 1761 664
assign 1 1762 664
typenameGet 0 1762 664
assign 1 1762 664
METHODGet 0 1762 664
assign 1 1762 664
equals 1 1762 664
acceptMethod 1 1763 664
assign 1 1764 664
typenameGet 0 1764 664
assign 1 1764 664
RBRACESGet 0 1764 664
assign 1 1764 664
equals 1 1764 664
acceptRbraces 1 1765 664
assign 1 1766 664
typenameGet 0 1766 664
assign 1 1766 664
EMITGet 0 1766 664
assign 1 1766 664
equals 1 1766 664
acceptEmit 1 1767 664
assign 1 1768 664
typenameGet 0 1768 664
assign 1 1768 664
IFEMITGet 0 1768 664
assign 1 1768 664
equals 1 1768 664
addStackLines 1 1769 664
assign 1 1770 664
acceptIfEmit 1 1770 664
return 1 1770 664
assign 1 1771 664
typenameGet 0 1771 664
assign 1 1771 664
CALLGet 0 1771 664
assign 1 1771 664
equals 1 1771 664
acceptCall 1 1772 664
assign 1 1773 664
typenameGet 0 1773 664
assign 1 1773 664
BRACESGet 0 1773 664
assign 1 1773 664
equals 1 1773 664
acceptBraces 1 1774 664
assign 1 1775 664
typenameGet 0 1775 664
assign 1 1775 664
BREAKGet 0 1775 664
assign 1 1775 664
equals 1 1775 664
assign 1 1776 664
new 0 1776 664
assign 1 1776 664
addValue 1 1776 664
addValue 1 1776 664
assign 1 1777 664
typenameGet 0 1777 664
assign 1 1777 664
LOOPGet 0 1777 664
assign 1 1777 664
equals 1 1777 664
assign 1 1778 664
new 0 1778 664
assign 1 1778 664
addValue 1 1778 664
addValue 1 1778 664
assign 1 1779 664
typenameGet 0 1779 664
assign 1 1779 664
ELSEGet 0 1779 664
assign 1 1779 664
equals 1 1779 664
assign 1 1780 664
new 0 1780 664
addValue 1 1780 664
assign 1 1781 664
typenameGet 0 1781 664
assign 1 1781 664
TRYGet 0 1781 664
assign 1 1781 664
equals 1 1781 664
assign 1 1782 664
new 0 1782 664
addValue 1 1782 664
assign 1 1783 664
typenameGet 0 1783 664
assign 1 1783 664
CATCHGet 0 1783 664
assign 1 1783 664
equals 1 1783 664
acceptCatch 1 1784 664
assign 1 1785 664
typenameGet 0 1785 664
assign 1 1785 664
IFGet 0 1785 664
assign 1 1785 664
equals 1 1785 664
acceptIf 1 1786 664
addStackLines 1 1788 664
assign 1 1789 664
nextDescendGet 0 1789 664
return 1 1789 664
assign 1 1793 664
def 1 1793 664
assign 1 1802 664
typenameGet 0 1802 664
assign 1 1802 664
NULLGet 0 1802 664
assign 1 1802 664
equals 1 1802 664
assign 1 1803 664
new 0 1803 664
assign 1 1804 664
heldGet 0 1804 664
assign 1 1804 664
nameGet 0 1804 664
assign 1 1804 664
new 0 1804 664
assign 1 1804 664
equals 1 1804 664
assign 1 1805 664
new 0 1805 664
assign 1 1806 664
heldGet 0 1806 664
assign 1 1806 664
nameGet 0 1806 664
assign 1 1806 664
new 0 1806 664
assign 1 1806 664
equals 1 1806 664
assign 1 1807 664
superNameGet 0 1807 664
assign 1 1809 664
heldGet 0 1809 664
assign 1 1809 664
nameForVar 1 1809 664
return 1 1811 664
assign 1 1816 664
typenameGet 0 1816 664
assign 1 1816 664
NULLGet 0 1816 664
assign 1 1816 664
equals 1 1816 664
assign 1 1817 664
new 0 1817 664
assign 1 1818 664
heldGet 0 1818 664
assign 1 1818 664
nameGet 0 1818 664
assign 1 1818 664
new 0 1818 664
assign 1 1818 664
equals 1 1818 664
assign 1 1819 664
new 0 1819 664
assign 1 1820 664
heldGet 0 1820 664
assign 1 1820 664
nameGet 0 1820 664
assign 1 1820 664
new 0 1820 664
assign 1 1820 664
equals 1 1820 664
assign 1 1821 664
superNameGet 0 1821 664
assign 1 1823 664
heldGet 0 1823 664
assign 1 1823 664
nameForVar 1 1823 664
return 1 1825 664
end 1 1829 664
assign 1 1833 664
new 0 1833 664
return 1 1833 664
assign 1 1837 664
new 0 1837 664
return 1 1837 664
assign 1 1841 664
new 0 1841 664
return 1 1841 664
assign 1 1845 664
new 0 1845 664
return 1 1845 664
assign 1 1849 664
new 0 1849 664
return 1 1849 664
assign 1 1854 664
new 0 1854 664
return 1 1854 664
assign 1 1858 664
new 0 1858 664
assign 1 1859 664
new 0 1859 664
assign 1 1860 664
stepsGet 0 1860 664
assign 1 1860 664
iteratorGet 0 0 664
assign 1 1860 664
hasNextGet 0 1860 664
assign 1 1860 664
nextGet 0 1860 664
assign 1 1861 664
new 0 1861 664
assign 1 1861 664
notEquals 1 1861 664
assign 1 1861 664
new 0 1861 664
assign 1 1861 664
add 1 1861 664
assign 1 1863 664
stepsGet 0 1863 664
assign 1 1863 664
sizeGet 0 1863 664
assign 1 1863 664
toString 0 1863 664
assign 1 1863 664
new 0 1863 664
assign 1 1863 664
add 1 1863 664
assign 1 1863 664
new 0 1863 664
assign 1 1864 664
sizeGet 0 1864 664
assign 1 1864 664
add 1 1864 664
assign 1 1865 664
add 1 1865 664
assign 1 1867 664
add 1 1867 664
return 1 1867 664
assign 1 1871 664
new 0 1871 664
assign 1 1871 664
mangleName 1 1871 664
assign 1 1871 664
add 1 1871 664
return 1 1871 664
assign 1 1875 664
new 0 1875 664
assign 1 1875 664
add 1 1875 664
assign 1 1875 664
add 1 1875 664
return 1 1875 664
assign 1 1879 664
new 0 1879 664
assign 1 1879 664
libEmitName 1 1879 664
assign 1 1879 664
add 1 1879 664
return 1 1879 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
return 1 0 664
assign 1 0 664
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1109279973: return bem_spropDecGet_0();
case 397629001: return bem_maxSpillArgsLenGet_0();
case 229958684: return bem_constGet_0();
case 944442837: return bem_classConfGet_0();
case 362974009: return bem_parentConfGet_0();
case 1413054881: return bem_smnlcsGet_0();
case 103017121: return bem_runtimeInitGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1859739893: return bem_methodsGet_0();
case 1529527065: return bem_onceCountGet_0();
case 1947619572: return bem_msynGet_0();
case 89706405: return bem_ccCacheGet_0();
case 708434875: return bem_klassDecGet_0();
case 1967844855: return bem_initialDecGet_0();
case 1774940957: return bem_toString_0();
case 1566392515: return bem_covariantReturnsGet_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 4647121: return bem_doEmit_0();
case 2039613615: return bem_instanceNotEqualGet_0();
case 955058175: return bem_lastMethodBodyLinesGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2001798761: return bem_nlGet_0();
case 1711936384: return bem_baseSmtdDecGet_0();
case 1308786538: return bem_echo_0();
case 160277051: return bem_procStartGet_0();
case 1372235405: return bem_superCallsGet_0();
case 1786051763: return bem_methodCatchGet_0();
case 1081275759: return bem_classesInDepthOrderGet_0();
case 1380285640: return bem_objectCcGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 604504089: return bem_falseValueGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case 378762597: return bem_boolNpGet_0();
case 1727672536: return bem_propDecGet_0();
case 628036310: return bem_lastMethodsSizeGet_0();
case 1487140092: return bem_classEndGet_0();
case 104713553: return bem_new_0();
case 402158238: return bem_inFilePathedGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1177623581: return bem_callNamesGet_0();
case 991179882: return bem_qGet_0();
case 644675716: return bem_ntypesGet_0();
case 1081412016: return bem_many_0();
case 1638160588: return bem_lineCountGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 772789066: return bem_libEmitPathGet_0();
case 2055025483: return bem_serializeContents_0();
case 1312373307: return bem_buildCreate_0();
case 1703922349: return bem_fullLibEmitNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 36542021: return bem_mainEndGet_0();
case 916491491: return bem_emitLib_0();
case 1747980150: return bem_smnlecsGet_0();
case 1841706211: return bem_returnTypeGet_0();
case 1073009537: return bem_beginNs_0();
case 2085643372: return bem_stringNpGet_0();
case 1500143225: return bem_useDynMethodsGet_0();
case 1052944126: return bem_csynGet_0();
case 1607412815: return bem_endNs_0();
case 86482693: return bem_overrideSmtdDecGet_0();
case 1923547459: return bem_boolCcGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 498080472: return bem_mnodeGet_0();
case 1820417453: return bem_create_0();
case 946095539: return bem_mainInClassGet_0();
case 681402717: return bem_boolTypeGet_0();
case 101343106: return bem_nativeCSlotsGet_0();
case 493012039: return bem_buildGet_0();
case 1354714650: return bem_copy_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 361542143: return bem_classEmitsGet_0();
case 2019411446: return bem_classBeginGet_0();
case 902412214: return bem_classCallsGet_0();
case 294732055: return bem_floatNpGet_0();
case 729571811: return bem_serializeToString_0();
case 1831751774: return bem_cnodeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 622039562: return bem_intNpGet_0();
case 1240611285: return bem_onceDecsGet_0();
case 786424307: return bem_tagGet_0();
case 991255330: return bem_mainStartGet_0();
case 722876119: return bem_buildClassInfo_0();
case 1910715228: return bem_libEmitNameGet_0();
case 797225458: return bem_dynMethodsGet_0();
case 1181505319: return bem_buildInitial_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1755995201: return bem_transGet_0();
case 1449942744: return bem_instanceEqualGet_0();
case 1012494862: return bem_once_0();
case 1369896794: return bem_objectNpGet_0();
case 1498619679: return bem_getLibOutput_0();
case 287040793: return bem_hashGet_0();
case 1317806639: return bem_baseMtdDecGet_0();
case 483359873: return bem_superNameGet_0();
case 1241388883: return bem_lastMethodBodySizeGet_0();
case 1795655423: return bem_propertyDecsGet_0();
case 1152064310: return bem_instOfGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1102720804: return bem_classNameGet_0();
case 727049506: return bem_exceptDecGet_0();
case 57260628: return bem_getClassOutput_0();
case 388723214: return bem_preClassGet_0();
case 1327064356: return bem_methodBodyGet_0();
case 1064889660: return bem_trueValueGet_0();
case 314718434: return bem_print_0();
case 220901978: return bem_emitLangGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 1053807407: return bem_trueValueSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case 1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 610957309: return bem_intNpSet_1(bevd_0);
case 386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case 891329961: return bem_classCallsSet_1(bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1820669521: return bem_cnodeSet_1(bevd_0);
case 945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case 1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 90260853: return bem_nativeCSlotsSet_1(bevd_0);
case 1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case 1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case 1912465206: return bem_boolCcSet_1(bevd_0);
case 377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case 943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case 1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case 1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1936537319: return bem_msynSet_1(bevd_0);
case 551679723: return bem_formCast_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1438860491: return bem_instanceEqualSet_1(bevd_0);
case 1899632975: return bem_libEmitNameSet_1(bevd_0);
case 478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 391075985: return bem_inFilePathedSet_1(bevd_0);
case 36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1041861873: return bem_csynSet_1(bevd_0);
case 1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 715967253: return bem_exceptDecSet_1(bevd_0);
case 1830623958: return bem_returnTypeSet_1(bevd_0);
case 1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case 1774969510: return bem_methodCatchSet_1(bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case 1358814541: return bem_objectNpSet_1(bevd_0);
case 1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case 2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case 65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_5_8_BuildNamePath) bevd_1);
case 1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 722876117: return bem_buildClassInfo_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callHash) {
case 316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_10_BuildEmitCommon();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_10_BuildEmitCommon.bevs_inst = (BEC_2_5_10_BuildEmitCommon)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_10_BuildEmitCommon.bevs_inst;
}
}
}
