namespace be.BEL_4_Base {
/* IO:File: source/build/Pass5.be */
public class BEC_3_5_5_5_BuildVisitPass5 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass5() { }
static BEC_3_5_5_5_BuildVisitPass5() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x35};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x35,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_2 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x6F,0x66,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_3 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x61,0x6C,0x69,0x61,0x73,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x20,0x2D,0x61,0x73,0x2D,0x2E};
private static byte[] bels_4 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x6F,0x74,0x20,0x77,0x69,0x74,0x68,0x69,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x75,0x6E,0x69,0x74};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_5 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_6 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_7 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_10 = {0x4F,0x6E,0x6C,0x79,0x20,0x73,0x69,0x6E,0x67,0x6C,0x65,0x20,0x69,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x61,0x6C,0x6C,0x6F,0x77,0x65,0x64};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x62,0x72,0x61,0x63,0x65,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_14 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_16 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_17 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_18 = {0x4C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bels_19 = {0x46,0x69,0x72,0x73,0x74,0x20,0x63,0x68,0x61,0x72,0x61,0x63,0x74,0x65,0x72,0x20,0x6F,0x66,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x61,0x6E,0x64,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x6E,0x61,0x6D,0x65,0x73,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x6E,0x75,0x6D,0x65,0x72,0x69,0x63,0x20,0x64,0x69,0x67,0x69,0x74};
private static byte[] bels_20 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x31};
private static byte[] bels_21 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x32};
private static byte[] bels_22 = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] bels_23 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x63,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6F,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x2E};
private static byte[] bels_24 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x74,0x68,0x65,0x73,0x69,0x73,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x28,0x62,0x75,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x29,0x20,0x61,0x66,0x74,0x65,0x72,0x3A,0x20};
public static new BEC_3_5_5_5_BuildVisitPass5 bevs_inst;
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_err = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_5_4_BuildNode bevl_lun = null;
BEC_2_5_4_LogicBool bevl_isLocalUse = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_namepath = null;
BEC_2_4_6_TextString bevl_alias = null;
BEC_2_6_6_SystemObject bevl_mas = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_6_6_SystemObject bevl_tnode = null;
BEC_2_5_4_LogicBool bevl_isFinal = null;
BEC_2_5_4_LogicBool bevl_isLocal = null;
BEC_2_5_4_LogicBool bevl_isNotNull = null;
BEC_2_5_4_BuildNode bevl_prp = null;
BEC_2_4_3_MathInt bevl_prpi = null;
BEC_2_5_4_BuildNode bevl_prptmp = null;
BEC_2_6_6_SystemObject bevl_m = null;
BEC_2_6_6_SystemObject bevl_mx = null;
BEC_2_6_6_SystemObject bevl_nx = null;
BEC_2_6_6_SystemObject bevl_con = null;
BEC_2_6_6_SystemObject bevl_lpnode = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_5_9_BuildTransUnit bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_97_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_98_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_104_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_2_5_5_BuildClass bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_137_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_153_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_154_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_160_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_169_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_171_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_172_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_173_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_174_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_181_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_182_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_183_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_185_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_186_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_187_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_188_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_189_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_190_tmpvar_phold = null;
BEC_2_5_6_BuildMethod bevt_191_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_192_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_193_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_194_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_197_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_199_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_200_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_203_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_204_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_206_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_207_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_208_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_211_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_212_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_213_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_214_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_215_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_216_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_217_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_219_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_222_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_224_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_225_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_227_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_228_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_231_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_238_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_239_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_240_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_241_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_242_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_243_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_244_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_245_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_246_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_247_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_248_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_249_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_250_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_251_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_252_tmpvar_phold = null;
BEC_2_5_9_BuildConstants bevt_253_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_254_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_255_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_256_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_257_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_258_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_259_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_260_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_261_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_263_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_264_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_265_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_267_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_269_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_270_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_271_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_272_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_273_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_274_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_275_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_276_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_277_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_278_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_279_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_280_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_281_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_282_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_283_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_284_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_285_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_286_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_287_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_288_tmpvar_phold = null;
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_20_tmpvar_phold.bevi_int == bevt_21_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 23 */ {
bevt_22_tmpvar_phold = (BEC_2_5_9_BuildTransUnit) (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
beva_node.bem_heldSet_1(bevt_22_tmpvar_phold);
} /* Line: 24 */
bevt_24_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_24_tmpvar_phold.bevi_int == bevt_25_tmpvar_phold.bevi_int) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_27_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_27_tmpvar_phold == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_29_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_31_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_emptyGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 27 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 27 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 29 */
} /* Line: 27 */
bevl_ix = beva_node.bem_nextPeerGet_0();
if (bevl_ix == null) {
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 33 */ {
bevt_34_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_35_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_34_tmpvar_phold.bevi_int == bevt_35_tmpvar_phold.bevi_int) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 33 */ {
bevt_37_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_37_tmpvar_phold.bevi_int == bevt_38_tmpvar_phold.bevi_int) {
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 33 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 33 */
 else  /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 33 */ {
bevt_40_tmpvar_phold = bevl_ix.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_41_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpvar_phold);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 33 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 33 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 33 */
 else  /* Line: 33 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 33 */ {
bevt_43_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_43_tmpvar_phold.bevi_int == bevt_44_tmpvar_phold.bevi_int) {
bevt_42_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 35 */ {
bevl_vinp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_45_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_45_tmpvar_phold);
} /* Line: 37 */
 else  /* Line: 38 */ {
bevl_vinp = beva_node.bem_heldGet_0();
} /* Line: 39 */
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_46_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_46_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_47_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_47_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 46 */
bevt_49_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_50_tmpvar_phold = bevp_ntypes.bem_USEGet_0();
if (bevt_49_tmpvar_phold.bevi_int == bevt_50_tmpvar_phold.bevi_int) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevl_lun = beva_node.bem_priorPeerGet_0();
if (bevl_lun == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_53_tmpvar_phold = bevl_lun.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_53_tmpvar_phold.bevi_int == bevt_54_tmpvar_phold.bevi_int) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
 else  /* Line: 51 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevt_56_tmpvar_phold = bevl_lun.bem_heldGet_0();
bevt_57_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_0));
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_57_tmpvar_phold);
if (bevt_55_tmpvar_phold != null && bevt_55_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_55_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
 else  /* Line: 51 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevl_isLocalUse = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_lun.bem_delete_0();
} /* Line: 53 */
 else  /* Line: 54 */ {
bevl_isLocalUse = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 55 */
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 60 */ {
if (bevl_nnode == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_60_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_61_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevl_nnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 61 */
 else  /* Line: 60 */ {
break;
} /* Line: 60 */
} /* Line: 60 */
if (bevl_nnode == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 63 */ {
bevt_64_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_65_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_65_tmpvar_phold);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 63 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 63 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 63 */
 else  /* Line: 63 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 63 */ {
bevl_clnode = bevl_nnode;
bevt_66_tmpvar_phold = bevl_clnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nnode = bevt_66_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 65 */
 else  /* Line: 66 */ {
bevl_clnode = null;
} /* Line: 67 */
if (bevl_nnode == null) {
bevt_67_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_67_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_67_tmpvar_phold.bevi_bool) /* Line: 70 */ {
bevt_69_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(59, bels_1));
bevt_68_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_69_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_68_tmpvar_phold);
} /* Line: 71 */
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 74 */ {
bevl_namepath = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_73_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_73_tmpvar_phold);
} /* Line: 76 */
 else  /* Line: 74 */ {
bevt_75_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 77 */ {
bevl_namepath = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 78 */
 else  /* Line: 79 */ {
bevt_78_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bels_2));
bevt_77_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_78_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_77_tmpvar_phold);
} /* Line: 80 */
} /* Line: 74 */
bevl_alias = null;
bevl_mas = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_80_tmpvar_phold = bevl_mas.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_81_tmpvar_phold = bevp_ntypes.bem_ASGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 85 */ {
bevl_nnode = bevl_mas.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_83_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_84_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_84_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 87 */ {
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bels_3));
bevt_85_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_85_tmpvar_phold);
} /* Line: 88 */
bevl_alias = (BEC_2_4_6_TextString) bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 90 */
if (bevl_clnode == null) {
bevt_87_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_89_tmpvar_phold = bevl_gnext.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_90_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_90_tmpvar_phold);
if (bevt_88_tmpvar_phold != null && bevt_88_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_88_tmpvar_phold).bevi_bool) /* Line: 97 */ {
bevl_nnode = bevl_gnext;
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 100 */
} /* Line: 97 */
 else  /* Line: 102 */ {
bevl_gnext = bevl_clnode;
} /* Line: 103 */
beva_node.bem_heldSet_1(bevl_namepath);
bevl_tnode = beva_node.bem_transUnitGet_0();
if (bevl_tnode == null) {
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_93_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(53, bels_4));
bevt_92_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_93_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_92_tmpvar_phold);
} /* Line: 110 */
if (bevl_alias == null) {
bevt_94_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_94_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_94_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevl_alias = (BEC_2_4_6_TextString) bevl_namepath.bemd_0(1672091917, BEL_4_Base.bevn_labelGet_0);
} /* Line: 114 */
bevt_96_tmpvar_phold = bevl_tnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_95_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_alias, bevl_namepath);
if (bevl_isLocalUse.bevi_bool) /* Line: 117 */ {
bevt_98_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_aliasedGet_0();
bevt_97_tmpvar_phold.bem_put_2(bevl_alias, bevl_namepath);
} /* Line: 118 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 121 */
bevt_100_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_101_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_100_tmpvar_phold.bevi_int == bevt_101_tmpvar_phold.bevi_int) {
bevt_99_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_99_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_99_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevl_isFinal = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isLocal = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isNotNull = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 128 */ {
bevt_103_tmpvar_phold = bevo_0;
if (bevl_prpi.bevi_int < bevt_103_tmpvar_phold.bevi_int) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 128 */ {
if (bevl_prp == null) {
bevt_104_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_104_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_104_tmpvar_phold.bevi_bool) /* Line: 129 */ {
bevt_106_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_107_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_106_tmpvar_phold.bevi_int == bevt_107_tmpvar_phold.bevi_int) {
bevt_105_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_105_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_105_tmpvar_phold.bevi_bool) /* Line: 130 */ {
bevt_109_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_110_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_109_tmpvar_phold.bevi_int == bevt_110_tmpvar_phold.bevi_int) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevt_112_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_113_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_5));
bevt_111_tmpvar_phold = bevt_112_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_113_tmpvar_phold);
if (bevt_111_tmpvar_phold != null && bevt_111_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_111_tmpvar_phold).bevi_bool) /* Line: 131 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
 else  /* Line: 131 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 131 */ {
bevl_isFinal = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 132 */
 else  /* Line: 131 */ {
bevt_115_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_116_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_115_tmpvar_phold.bevi_int == bevt_116_tmpvar_phold.bevi_int) {
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpvar_phold.bevi_bool) /* Line: 133 */ {
bevt_118_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_119_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_6));
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_119_tmpvar_phold);
if (bevt_117_tmpvar_phold != null && bevt_117_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_117_tmpvar_phold).bevi_bool) /* Line: 133 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 133 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 133 */
 else  /* Line: 133 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 133 */ {
bevl_isLocal = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 134 */
 else  /* Line: 131 */ {
bevt_121_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_122_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_121_tmpvar_phold.bevi_int == bevt_122_tmpvar_phold.bevi_int) {
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_124_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_125_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_7));
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_125_tmpvar_phold);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 135 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 135 */ {
bevl_isNotNull = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 136 */
} /* Line: 131 */
} /* Line: 131 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 140 */
 else  /* Line: 141 */ {
bevl_prp = null;
} /* Line: 142 */
} /* Line: 130 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 128 */
 else  /* Line: 128 */ {
break;
} /* Line: 128 */
} /* Line: 128 */
bevt_126_tmpvar_phold = (BEC_2_5_5_BuildClass) (new BEC_2_5_5_BuildClass()).bem_new_0();
beva_node.bem_heldSet_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_128_tmpvar_phold = bevp_build.bem_fromFileGet_0();
bevt_127_tmpvar_phold.bemd_1(806119150, BEL_4_Base.bevn_fromFileSet_1, bevt_128_tmpvar_phold);
try  /* Line: 148 */ {
bevt_129_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_129_tmpvar_phold.bem_firstGet_0();
bevt_131_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_132_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_132_tmpvar_phold);
if (bevt_130_tmpvar_phold != null && bevt_130_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_130_tmpvar_phold).bevi_bool) /* Line: 150 */ {
bevl_namepath = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_133_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_133_tmpvar_phold);
} /* Line: 152 */
 else  /* Line: 150 */ {
bevt_135_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_136_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_134_tmpvar_phold != null && bevt_134_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_134_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevl_namepath = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 154 */
 else  /* Line: 155 */ {
bevt_138_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bels_8));
bevt_137_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_138_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_137_tmpvar_phold);
} /* Line: 156 */
} /* Line: 150 */
bevt_139_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_139_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_namepath);
bevt_140_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_140_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevl_isFinal);
bevt_141_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_141_tmpvar_phold.bemd_1(831500365, BEL_4_Base.bevn_isLocalSet_1, bevl_isLocal);
bevt_142_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_142_tmpvar_phold.bemd_1(374719236, BEL_4_Base.bevn_isNotNullSet_1, bevl_isNotNull);
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 162 */
 catch (System.Exception beve_0) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_144_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bels_9));
bevt_143_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_143_tmpvar_phold);
} /* Line: 165 */
try  /* Line: 167 */ {
bevt_145_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_nnode = bevt_145_tmpvar_phold.bem_firstGet_0();
bevt_147_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_148_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_148_tmpvar_phold);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 169 */ {
bevt_151_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_152_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_152_tmpvar_phold);
if (bevt_149_tmpvar_phold != null && bevt_149_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpvar_phold).bevi_bool) /* Line: 170 */ {
bevt_154_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_10));
bevt_153_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_154_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_153_tmpvar_phold);
} /* Line: 171 */
try  /* Line: 173 */ {
bevt_155_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_m = bevt_155_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_157_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_158_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_158_tmpvar_phold);
if (bevt_156_tmpvar_phold != null && bevt_156_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_156_tmpvar_phold).bevi_bool) /* Line: 175 */ {
bevt_159_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_160_tmpvar_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_159_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_160_tmpvar_phold);
bevt_162_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_161_tmpvar_phold = bevt_162_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_163_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_163_tmpvar_phold);
} /* Line: 177 */
 else  /* Line: 175 */ {
bevt_165_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_166_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_164_tmpvar_phold = bevt_165_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_166_tmpvar_phold);
if (bevt_164_tmpvar_phold != null && bevt_164_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_164_tmpvar_phold).bevi_bool) /* Line: 178 */ {
bevt_167_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_168_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_167_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_168_tmpvar_phold);
} /* Line: 179 */
 else  /* Line: 180 */ {
bevt_170_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bels_11));
bevt_169_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_170_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_169_tmpvar_phold);
} /* Line: 181 */
} /* Line: 175 */
} /* Line: 175 */
 catch (System.Exception beve_1) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_1));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_172_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(68, bels_12));
bevt_171_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_172_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_171_tmpvar_phold);
} /* Line: 186 */
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 188 */
} /* Line: 169 */
 catch (System.Exception beve_2) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_2));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_174_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(60, bels_13));
bevt_173_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_174_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_173_tmpvar_phold);
} /* Line: 192 */
bevt_177_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_176_tmpvar_phold = bevt_177_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_176_tmpvar_phold == null) {
bevt_175_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_175_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_175_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_181_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_179_tmpvar_phold = bevt_180_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_182_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_14));
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_182_tmpvar_phold);
if (bevt_178_tmpvar_phold != null && bevt_178_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_178_tmpvar_phold).bevi_bool) /* Line: 195 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 195 */ {
bevt_183_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_185_tmpvar_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_186_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_15));
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_fromString_1(bevt_186_tmpvar_phold);
bevt_183_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_184_tmpvar_phold);
} /* Line: 196 */
bevt_187_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_187_tmpvar_phold;
} /* Line: 199 */
bevt_189_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_190_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_189_tmpvar_phold.bevi_int == bevt_190_tmpvar_phold.bevi_int) {
bevt_188_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_188_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_188_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevt_191_tmpvar_phold = (BEC_2_5_6_BuildMethod) (new BEC_2_5_6_BuildMethod()).bem_new_0();
beva_node.bem_heldSet_1(bevt_191_tmpvar_phold);
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 204 */ {
bevt_193_tmpvar_phold = bevo_1;
if (bevl_prpi.bevi_int < bevt_193_tmpvar_phold.bevi_int) {
bevt_192_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_192_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_192_tmpvar_phold.bevi_bool) /* Line: 204 */ {
if (bevl_prp == null) {
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_194_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_196_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_197_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_196_tmpvar_phold.bevi_int == bevt_197_tmpvar_phold.bevi_int) {
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_195_tmpvar_phold.bevi_bool) /* Line: 206 */ {
bevt_199_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_200_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_199_tmpvar_phold.bevi_int == bevt_200_tmpvar_phold.bevi_int) {
bevt_198_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_198_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_198_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_202_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_203_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_16));
bevt_201_tmpvar_phold = bevt_202_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_203_tmpvar_phold);
if (bevt_201_tmpvar_phold != null && bevt_201_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_201_tmpvar_phold).bevi_bool) /* Line: 207 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 207 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 207 */
 else  /* Line: 207 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 207 */ {
bevt_204_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_205_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_204_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevt_205_tmpvar_phold);
} /* Line: 208 */
 else  /* Line: 207 */ {
bevt_207_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_208_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_207_tmpvar_phold.bevi_int == bevt_208_tmpvar_phold.bevi_int) {
bevt_206_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_206_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_206_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevt_210_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_211_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_17));
bevt_209_tmpvar_phold = bevt_210_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_211_tmpvar_phold);
if (bevt_209_tmpvar_phold != null && bevt_209_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_209_tmpvar_phold).bevi_bool) /* Line: 209 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 209 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 209 */
 else  /* Line: 209 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 209 */ {
bevt_213_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(27, bels_18));
bevt_212_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_213_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_212_tmpvar_phold);
} /* Line: 211 */
} /* Line: 207 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 215 */
 else  /* Line: 216 */ {
bevl_prp = null;
} /* Line: 217 */
} /* Line: 206 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 204 */
 else  /* Line: 204 */ {
break;
} /* Line: 204 */
} /* Line: 204 */
try  /* Line: 221 */ {
bevt_214_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_214_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_215_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_215_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_215_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevl_mx = bevl_m.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_mx == null) {
bevt_216_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_216_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_216_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevl_mx = bevl_mx.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_218_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_219_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_217_tmpvar_phold = bevt_218_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_219_tmpvar_phold);
if (bevt_217_tmpvar_phold != null && bevt_217_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_217_tmpvar_phold).bevi_bool) /* Line: 227 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_221_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_222_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_220_tmpvar_phold = bevt_221_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_222_tmpvar_phold);
if (bevt_220_tmpvar_phold != null && bevt_220_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_220_tmpvar_phold).bevi_bool) /* Line: 227 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 227 */ {
bevt_224_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_225_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_223_tmpvar_phold = bevt_224_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_225_tmpvar_phold);
if (bevt_223_tmpvar_phold != null && bevt_223_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_223_tmpvar_phold).bevi_bool) /* Line: 229 */ {
bevl_vinp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_226_tmpvar_phold = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_226_tmpvar_phold);
} /* Line: 231 */
 else  /* Line: 232 */ {
bevl_vinp = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 233 */
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_227_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_227_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_228_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_mx.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_228_tmpvar_phold);
bevl_mx.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
} /* Line: 239 */
} /* Line: 227 */
bevt_230_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_231_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_229_tmpvar_phold = bevt_230_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_231_tmpvar_phold);
if (bevt_229_tmpvar_phold != null && bevt_229_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_229_tmpvar_phold).bevi_bool) /* Line: 242 */ {
bevt_232_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_233_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_232_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_233_tmpvar_phold);
bevt_237_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_238_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_235_tmpvar_phold = bevt_236_tmpvar_phold.bemd_1(636254476, BEL_4_Base.bevn_getPoint_1, bevt_238_tmpvar_phold);
bevt_234_tmpvar_phold = bevt_235_tmpvar_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_234_tmpvar_phold != null && bevt_234_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_234_tmpvar_phold).bevi_bool) /* Line: 244 */ {
bevt_240_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(75, bels_19));
bevt_239_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_240_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_239_tmpvar_phold);
} /* Line: 245 */
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 247 */
 else  /* Line: 248 */ {
bevt_242_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bels_20));
bevt_241_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_242_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_241_tmpvar_phold);
} /* Line: 249 */
} /* Line: 242 */
 else  /* Line: 251 */ {
bevt_244_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bels_21));
bevt_243_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_244_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_243_tmpvar_phold);
} /* Line: 252 */
} /* Line: 223 */
 catch (System.Exception beve_3) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_3));
bevt_246_tmpvar_phold = bevl_err.bemd_0(1102720804, BEL_4_Base.bevn_classNameGet_0);
bevt_247_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_22));
bevt_245_tmpvar_phold = bevt_246_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_247_tmpvar_phold);
if (bevt_245_tmpvar_phold != null && bevt_245_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_245_tmpvar_phold).bevi_bool) /* Line: 255 */ {
throw new be.BELS_Base.BECS_ThrowBack(bevl_err);
} /* Line: 255 */
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_249_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, bels_23));
bevt_248_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_249_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_248_tmpvar_phold);
} /* Line: 257 */
bevt_250_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_250_tmpvar_phold;
} /* Line: 259 */
bevt_253_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevt_252_tmpvar_phold = bevt_253_tmpvar_phold.bem_parensReqGet_0();
bevt_254_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_251_tmpvar_phold = bevt_252_tmpvar_phold.bem_has_1(bevt_254_tmpvar_phold);
if (bevt_251_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevt_255_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_255_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_256_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_256_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_256_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_258_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_259_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_257_tmpvar_phold = bevt_258_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_259_tmpvar_phold);
if (bevt_257_tmpvar_phold != null && bevt_257_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_257_tmpvar_phold).bevi_bool) /* Line: 263 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 263 */ {
bevt_261_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bels_24));
bevt_260_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_261_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_260_tmpvar_phold);
} /* Line: 264 */
} /* Line: 263 */
bevt_263_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_264_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_263_tmpvar_phold.bevi_int == bevt_264_tmpvar_phold.bevi_int) {
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_262_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevl_m = beva_node.bem_containerGet_0();
if (bevl_m == null) {
bevt_265_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_265_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_265_tmpvar_phold.bevi_bool) /* Line: 270 */ {
bevt_267_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_268_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_266_tmpvar_phold = bevt_267_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_268_tmpvar_phold);
if (bevt_266_tmpvar_phold != null && bevt_266_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_266_tmpvar_phold).bevi_bool) /* Line: 270 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
 else  /* Line: 270 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 270 */ {
bevt_269_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
beva_node.bem_typenameSet_1(bevt_269_tmpvar_phold);
} /* Line: 271 */
} /* Line: 270 */
bevt_271_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_272_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
if (bevt_271_tmpvar_phold.bevi_int == bevt_272_tmpvar_phold.bevi_int) {
bevt_270_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_270_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_270_tmpvar_phold.bevi_bool) /* Line: 274 */ {
bevl_nx = beva_node.bem_priorPeerGet_0();
bevl_gnext = beva_node.bem_nextAscendGet_0();
while (true)
 /* Line: 280 */ {
if (bevl_nx == null) {
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_273_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_275_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_276_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_276_tmpvar_phold);
if (bevt_274_tmpvar_phold != null && bevt_274_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_274_tmpvar_phold).bevi_bool) /* Line: 280 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
 else  /* Line: 280 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
bevt_278_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_279_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_277_tmpvar_phold = bevt_278_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_279_tmpvar_phold);
if (bevt_277_tmpvar_phold != null && bevt_277_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_277_tmpvar_phold).bevi_bool) /* Line: 280 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
 else  /* Line: 280 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
bevt_281_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_282_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_280_tmpvar_phold = bevt_281_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_282_tmpvar_phold);
if (bevt_280_tmpvar_phold != null && bevt_280_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_280_tmpvar_phold).bevi_bool) /* Line: 280 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
 else  /* Line: 280 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
if (bevl_con == null) {
bevt_283_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_283_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_283_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevl_con = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 282 */
bevl_con.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_nx);
bevl_nx = bevl_nx.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
} /* Line: 285 */
 else  /* Line: 280 */ {
break;
} /* Line: 280 */
} /* Line: 280 */
if (bevl_con == null) {
bevt_284_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_284_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_284_tmpvar_phold.bevi_bool) /* Line: 287 */ {
bevt_285_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
beva_node.bem_typenameSet_1(bevt_285_tmpvar_phold);
beva_node.bem_heldSet_1(null);
bevl_lpnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_286_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_lpnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_286_tmpvar_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_lpnode);
bevl_lpnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_ii = bevl_con.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 294 */ {
bevt_287_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_287_tmpvar_phold != null && bevt_287_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_287_tmpvar_phold).bevi_bool) /* Line: 294 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lpnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 297 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
} /* Line: 294 */
 else  /* Line: 303 */ {
beva_node.bem_delete_0();
} /* Line: 304 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 306 */
bevt_288_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_288_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {23, 23, 23, 23, 24, 24, 26, 26, 26, 26, 27, 27, 27, 0, 27, 27, 27, 27, 0, 0, 28, 29, 32, 33, 33, 33, 33, 33, 33, 0, 33, 33, 33, 33, 0, 0, 0, 0, 0, 33, 33, 33, 0, 0, 0, 35, 35, 35, 35, 36, 37, 37, 39, 41, 42, 42, 44, 45, 45, 46, 48, 48, 48, 48, 50, 51, 51, 51, 51, 51, 51, 0, 0, 0, 51, 51, 51, 0, 0, 0, 52, 53, 55, 59, 60, 60, 60, 60, 60, 0, 0, 0, 61, 63, 63, 63, 63, 63, 0, 0, 0, 64, 65, 65, 67, 70, 70, 71, 71, 71, 74, 74, 74, 75, 76, 76, 77, 77, 77, 78, 80, 80, 80, 83, 84, 85, 85, 85, 86, 87, 87, 87, 88, 88, 88, 90, 93, 93, 94, 95, 97, 97, 97, 98, 99, 100, 103, 105, 107, 109, 109, 110, 110, 110, 113, 113, 114, 116, 116, 116, 118, 118, 118, 121, 123, 123, 123, 123, 124, 125, 126, 127, 128, 128, 128, 128, 129, 129, 130, 130, 130, 130, 131, 131, 131, 131, 131, 131, 131, 0, 0, 0, 132, 133, 133, 133, 133, 133, 133, 133, 0, 0, 0, 134, 135, 135, 135, 135, 135, 135, 135, 0, 0, 0, 136, 138, 139, 140, 142, 128, 146, 146, 147, 147, 147, 149, 149, 150, 150, 150, 151, 152, 152, 153, 153, 153, 154, 156, 156, 156, 158, 158, 159, 159, 160, 160, 161, 161, 162, 164, 165, 165, 165, 168, 168, 169, 169, 169, 170, 170, 170, 170, 171, 171, 171, 174, 174, 175, 175, 175, 176, 176, 176, 177, 177, 177, 177, 178, 178, 178, 179, 179, 179, 181, 181, 181, 185, 186, 186, 186, 188, 191, 192, 192, 192, 195, 195, 195, 195, 195, 195, 195, 195, 195, 0, 0, 0, 196, 196, 196, 196, 196, 199, 199, 201, 201, 201, 201, 202, 202, 203, 204, 204, 204, 204, 205, 205, 206, 206, 206, 206, 207, 207, 207, 207, 207, 207, 207, 0, 0, 0, 208, 208, 208, 209, 209, 209, 209, 209, 209, 209, 0, 0, 0, 211, 211, 211, 213, 214, 215, 217, 204, 222, 222, 223, 223, 224, 225, 225, 226, 227, 227, 227, 0, 227, 227, 227, 0, 0, 229, 229, 229, 230, 231, 231, 233, 235, 236, 236, 237, 238, 238, 239, 242, 242, 242, 243, 243, 243, 244, 244, 244, 244, 244, 245, 245, 245, 247, 249, 249, 249, 252, 252, 252, 255, 255, 255, 255, 256, 257, 257, 257, 259, 259, 261, 261, 261, 261, 262, 262, 263, 263, 0, 263, 263, 263, 0, 0, 264, 264, 264, 268, 268, 268, 268, 269, 270, 270, 270, 270, 270, 0, 0, 0, 271, 271, 274, 274, 274, 274, 275, 276, 280, 280, 280, 280, 280, 0, 0, 0, 280, 280, 280, 0, 0, 0, 280, 280, 280, 0, 0, 0, 281, 281, 282, 284, 285, 287, 287, 288, 288, 289, 290, 291, 291, 292, 293, 294, 294, 295, 296, 297, 304, 306, 309, 309};
public static new int[] bevs_smnlec
 = new int[] {352, 353, 354, 359, 360, 361, 363, 364, 365, 370, 371, 372, 377, 378, 381, 382, 383, 384, 386, 389, 393, 394, 397, 398, 403, 404, 405, 406, 411, 412, 415, 416, 417, 422, 423, 426, 430, 433, 437, 440, 441, 442, 444, 447, 451, 454, 455, 456, 461, 462, 463, 464, 467, 469, 470, 471, 472, 473, 474, 475, 477, 478, 479, 484, 485, 486, 491, 492, 493, 494, 499, 500, 503, 507, 510, 511, 512, 514, 517, 521, 524, 525, 528, 530, 533, 538, 539, 540, 541, 543, 546, 550, 553, 559, 564, 565, 566, 567, 569, 572, 576, 579, 580, 581, 584, 586, 591, 592, 593, 594, 596, 597, 598, 600, 601, 602, 605, 606, 607, 609, 612, 613, 614, 617, 618, 619, 620, 621, 623, 624, 625, 626, 628, 629, 630, 632, 634, 639, 640, 641, 642, 643, 644, 646, 647, 648, 652, 654, 655, 656, 661, 662, 663, 664, 666, 671, 672, 674, 675, 676, 678, 679, 680, 682, 684, 685, 686, 691, 692, 693, 694, 695, 696, 699, 700, 705, 706, 711, 712, 713, 714, 719, 720, 721, 722, 727, 728, 729, 730, 732, 735, 739, 742, 745, 746, 747, 752, 753, 754, 755, 757, 760, 764, 767, 770, 771, 772, 777, 778, 779, 780, 782, 785, 789, 792, 796, 797, 798, 801, 804, 810, 811, 812, 813, 814, 816, 817, 818, 819, 820, 822, 823, 824, 827, 828, 829, 831, 834, 835, 836, 839, 840, 841, 842, 843, 844, 845, 846, 847, 851, 852, 853, 854, 857, 858, 859, 860, 861, 863, 864, 865, 866, 868, 869, 870, 873, 874, 875, 876, 877, 879, 880, 881, 882, 883, 884, 885, 888, 889, 890, 892, 893, 894, 897, 898, 899, 905, 906, 907, 908, 910, 915, 916, 917, 918, 920, 921, 922, 927, 928, 929, 930, 931, 932, 934, 937, 941, 944, 945, 946, 947, 948, 950, 951, 953, 954, 955, 960, 961, 962, 963, 964, 967, 968, 973, 974, 979, 980, 981, 982, 987, 988, 989, 990, 995, 996, 997, 998, 1000, 1003, 1007, 1010, 1011, 1012, 1015, 1016, 1017, 1022, 1023, 1024, 1025, 1027, 1030, 1034, 1037, 1038, 1039, 1042, 1043, 1044, 1047, 1050, 1057, 1058, 1059, 1064, 1065, 1066, 1071, 1072, 1073, 1074, 1075, 1077, 1080, 1081, 1082, 1084, 1087, 1091, 1092, 1093, 1095, 1096, 1097, 1100, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1111, 1112, 1113, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1124, 1125, 1126, 1128, 1131, 1132, 1133, 1137, 1138, 1139, 1144, 1145, 1146, 1148, 1150, 1151, 1152, 1153, 1155, 1156, 1158, 1159, 1160, 1161, 1163, 1164, 1165, 1170, 1171, 1174, 1175, 1176, 1178, 1181, 1185, 1186, 1187, 1190, 1191, 1192, 1197, 1198, 1199, 1204, 1205, 1206, 1207, 1209, 1212, 1216, 1219, 1220, 1223, 1224, 1225, 1230, 1231, 1232, 1235, 1240, 1241, 1242, 1243, 1245, 1248, 1252, 1255, 1256, 1257, 1259, 1262, 1266, 1269, 1270, 1271, 1273, 1276, 1280, 1283, 1288, 1289, 1291, 1292, 1298, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1315, 1317, 1318, 1319, 1327, 1329, 1331, 1332};
/* BEGIN LINEINFO 
assign 1 23 352
typenameGet 0 23 352
assign 1 23 353
TRANSUNITGet 0 23 353
assign 1 23 354
equals 1 23 359
assign 1 24 360
new 0 24 360
heldSet 1 24 361
assign 1 26 363
typenameGet 0 26 363
assign 1 26 364
VARGet 0 26 364
assign 1 26 365
equals 1 26 370
assign 1 27 371
heldGet 0 27 371
assign 1 27 372
undef 1 27 377
assign 1 0 378
assign 1 27 381
heldGet 0 27 381
assign 1 27 382
new 0 27 382
assign 1 27 383
emptyGet 0 27 383
assign 1 27 384
sameType 1 27 384
assign 1 0 386
assign 1 0 389
assign 1 28 393
new 0 28 393
heldSet 1 29 394
assign 1 32 397
nextPeerGet 0 32 397
assign 1 33 398
def 1 33 403
assign 1 33 404
typenameGet 0 33 404
assign 1 33 405
IDGet 0 33 405
assign 1 33 406
equals 1 33 411
assign 1 0 412
assign 1 33 415
typenameGet 0 33 415
assign 1 33 416
NAMEPATHGet 0 33 416
assign 1 33 417
equals 1 33 422
assign 1 0 423
assign 1 0 426
assign 1 0 430
assign 1 0 433
assign 1 0 437
assign 1 33 440
typenameGet 0 33 440
assign 1 33 441
IDGet 0 33 441
assign 1 33 442
equals 1 33 442
assign 1 0 444
assign 1 0 447
assign 1 0 451
assign 1 35 454
typenameGet 0 35 454
assign 1 35 455
IDGet 0 35 455
assign 1 35 456
equals 1 35 461
assign 1 36 462
new 0 36 462
assign 1 37 463
heldGet 0 37 463
addStep 1 37 464
assign 1 39 467
heldGet 0 39 467
assign 1 41 469
new 0 41 469
assign 1 42 470
new 0 42 470
isTypedSet 1 42 471
namepathSet 1 44 472
assign 1 45 473
VARGet 0 45 473
typenameSet 1 45 474
heldSet 1 46 475
assign 1 48 477
typenameGet 0 48 477
assign 1 48 478
USEGet 0 48 478
assign 1 48 479
equals 1 48 484
assign 1 50 485
priorPeerGet 0 50 485
assign 1 51 486
def 1 51 491
assign 1 51 492
typenameGet 0 51 492
assign 1 51 493
DEFMODGet 0 51 493
assign 1 51 494
equals 1 51 499
assign 1 0 500
assign 1 0 503
assign 1 0 507
assign 1 51 510
heldGet 0 51 510
assign 1 51 511
new 0 51 511
assign 1 51 512
equals 1 51 512
assign 1 0 514
assign 1 0 517
assign 1 0 521
assign 1 52 524
new 0 52 524
delete 0 53 525
assign 1 55 528
new 0 55 528
assign 1 59 530
nextPeerGet 0 59 530
assign 1 60 533
def 1 60 538
assign 1 60 539
typenameGet 0 60 539
assign 1 60 540
DEFMODGet 0 60 540
assign 1 60 541
equals 1 60 541
assign 1 0 543
assign 1 0 546
assign 1 0 550
assign 1 61 553
nextPeerGet 0 61 553
assign 1 63 559
def 1 63 564
assign 1 63 565
typenameGet 0 63 565
assign 1 63 566
CLASSGet 0 63 566
assign 1 63 567
equals 1 63 567
assign 1 0 569
assign 1 0 572
assign 1 0 576
assign 1 64 579
assign 1 65 580
containedGet 0 65 580
assign 1 65 581
firstGet 0 65 581
assign 1 67 584
assign 1 70 586
undef 1 70 591
assign 1 71 592
new 0 71 592
assign 1 71 593
new 2 71 593
throw 1 71 594
assign 1 74 596
typenameGet 0 74 596
assign 1 74 597
IDGet 0 74 597
assign 1 74 598
equals 1 74 598
assign 1 75 600
new 0 75 600
assign 1 76 601
heldGet 0 76 601
addStep 1 76 602
assign 1 77 605
typenameGet 0 77 605
assign 1 77 606
NAMEPATHGet 0 77 606
assign 1 77 607
equals 1 77 607
assign 1 78 609
heldGet 0 78 609
assign 1 80 612
new 0 80 612
assign 1 80 613
new 2 80 613
throw 1 80 614
assign 1 83 617
assign 1 84 618
nextPeerGet 0 84 618
assign 1 85 619
typenameGet 0 85 619
assign 1 85 620
ASGet 0 85 620
assign 1 85 621
equals 1 85 621
assign 1 86 623
nextPeerGet 0 86 623
assign 1 87 624
typenameGet 0 87 624
assign 1 87 625
IDGet 0 87 625
assign 1 87 626
notEquals 1 87 626
assign 1 88 628
new 0 88 628
assign 1 88 629
new 2 88 629
throw 1 88 630
assign 1 90 632
heldGet 0 90 632
assign 1 93 634
undef 1 93 639
assign 1 94 640
nextPeerGet 0 94 640
delete 0 95 641
assign 1 97 642
typenameGet 0 97 642
assign 1 97 643
SEMIGet 0 97 643
assign 1 97 644
equals 1 97 644
assign 1 98 646
assign 1 99 647
nextPeerGet 0 99 647
delete 0 100 648
assign 1 103 652
heldSet 1 105 654
assign 1 107 655
transUnitGet 0 107 655
assign 1 109 656
undef 1 109 661
assign 1 110 662
new 0 110 662
assign 1 110 663
new 2 110 663
throw 1 110 664
assign 1 113 666
undef 1 113 671
assign 1 114 672
labelGet 0 114 672
assign 1 116 674
heldGet 0 116 674
assign 1 116 675
aliasedGet 0 116 675
put 2 116 676
assign 1 118 678
emitDataGet 0 118 678
assign 1 118 679
aliasedGet 0 118 679
put 2 118 680
return 1 121 682
assign 1 123 684
typenameGet 0 123 684
assign 1 123 685
CLASSGet 0 123 685
assign 1 123 686
equals 1 123 691
assign 1 124 692
new 0 124 692
assign 1 125 693
new 0 125 693
assign 1 126 694
new 0 126 694
assign 1 127 695
priorPeerGet 0 127 695
assign 1 128 696
new 0 128 696
assign 1 128 699
new 0 128 699
assign 1 128 700
lesser 1 128 705
assign 1 129 706
def 1 129 711
assign 1 130 712
typenameGet 0 130 712
assign 1 130 713
DEFMODGet 0 130 713
assign 1 130 714
equals 1 130 719
assign 1 131 720
typenameGet 0 131 720
assign 1 131 721
DEFMODGet 0 131 721
assign 1 131 722
equals 1 131 727
assign 1 131 728
heldGet 0 131 728
assign 1 131 729
new 0 131 729
assign 1 131 730
equals 1 131 730
assign 1 0 732
assign 1 0 735
assign 1 0 739
assign 1 132 742
new 0 132 742
assign 1 133 745
typenameGet 0 133 745
assign 1 133 746
DEFMODGet 0 133 746
assign 1 133 747
equals 1 133 752
assign 1 133 753
heldGet 0 133 753
assign 1 133 754
new 0 133 754
assign 1 133 755
equals 1 133 755
assign 1 0 757
assign 1 0 760
assign 1 0 764
assign 1 134 767
new 0 134 767
assign 1 135 770
typenameGet 0 135 770
assign 1 135 771
DEFMODGet 0 135 771
assign 1 135 772
equals 1 135 777
assign 1 135 778
heldGet 0 135 778
assign 1 135 779
new 0 135 779
assign 1 135 780
equals 1 135 780
assign 1 0 782
assign 1 0 785
assign 1 0 789
assign 1 136 792
new 0 136 792
assign 1 138 796
priorPeerGet 0 138 796
delete 0 139 797
assign 1 140 798
assign 1 142 801
assign 1 128 804
increment 0 128 804
assign 1 146 810
new 0 146 810
heldSet 1 146 811
assign 1 147 812
heldGet 0 147 812
assign 1 147 813
fromFileGet 0 147 813
fromFileSet 1 147 814
assign 1 149 816
containedGet 0 149 816
assign 1 149 817
firstGet 0 149 817
assign 1 150 818
typenameGet 0 150 818
assign 1 150 819
IDGet 0 150 819
assign 1 150 820
equals 1 150 820
assign 1 151 822
new 0 151 822
assign 1 152 823
heldGet 0 152 823
addStep 1 152 824
assign 1 153 827
typenameGet 0 153 827
assign 1 153 828
NAMEPATHGet 0 153 828
assign 1 153 829
equals 1 153 829
assign 1 154 831
heldGet 0 154 831
assign 1 156 834
new 0 156 834
assign 1 156 835
new 2 156 835
throw 1 156 836
assign 1 158 839
heldGet 0 158 839
namepathSet 1 158 840
assign 1 159 841
heldGet 0 159 841
isFinalSet 1 159 842
assign 1 160 843
heldGet 0 160 843
isLocalSet 1 160 844
assign 1 161 845
heldGet 0 161 845
isNotNullSet 1 161 846
delete 0 162 847
print 0 164 851
assign 1 165 852
new 0 165 852
assign 1 165 853
new 2 165 853
throw 1 165 854
assign 1 168 857
containedGet 0 168 857
assign 1 168 858
firstGet 0 168 858
assign 1 169 859
typenameGet 0 169 859
assign 1 169 860
PARENSGet 0 169 860
assign 1 169 861
equals 1 169 861
assign 1 170 863
containedGet 0 170 863
assign 1 170 864
lengthGet 0 170 864
assign 1 170 865
new 0 170 865
assign 1 170 866
greater 1 170 866
assign 1 171 868
new 0 171 868
assign 1 171 869
new 2 171 869
throw 1 171 870
assign 1 174 873
containedGet 0 174 873
assign 1 174 874
firstGet 0 174 874
assign 1 175 875
typenameGet 0 175 875
assign 1 175 876
IDGet 0 175 876
assign 1 175 877
equals 1 175 877
assign 1 176 879
heldGet 0 176 879
assign 1 176 880
new 0 176 880
extendsSet 1 176 881
assign 1 177 882
heldGet 0 177 882
assign 1 177 883
extendsGet 0 177 883
assign 1 177 884
heldGet 0 177 884
addStep 1 177 885
assign 1 178 888
typenameGet 0 178 888
assign 1 178 889
NAMEPATHGet 0 178 889
assign 1 178 890
equals 1 178 890
assign 1 179 892
heldGet 0 179 892
assign 1 179 893
heldGet 0 179 893
extendsSet 1 179 894
assign 1 181 897
new 0 181 897
assign 1 181 898
new 2 181 898
throw 1 181 899
print 0 185 905
assign 1 186 906
new 0 186 906
assign 1 186 907
new 2 186 907
throw 1 186 908
delete 0 188 910
print 0 191 915
assign 1 192 916
new 0 192 916
assign 1 192 917
new 2 192 917
throw 1 192 918
assign 1 195 920
heldGet 0 195 920
assign 1 195 921
extendsGet 0 195 921
assign 1 195 922
undef 1 195 927
assign 1 195 928
heldGet 0 195 928
assign 1 195 929
namepathGet 0 195 929
assign 1 195 930
toString 0 195 930
assign 1 195 931
new 0 195 931
assign 1 195 932
notEquals 1 195 932
assign 1 0 934
assign 1 0 937
assign 1 0 941
assign 1 196 944
heldGet 0 196 944
assign 1 196 945
new 0 196 945
assign 1 196 946
new 0 196 946
assign 1 196 947
fromString 1 196 947
extendsSet 1 196 948
assign 1 199 950
nextDescendGet 0 199 950
return 1 199 951
assign 1 201 953
typenameGet 0 201 953
assign 1 201 954
METHODGet 0 201 954
assign 1 201 955
equals 1 201 960
assign 1 202 961
new 0 202 961
heldSet 1 202 962
assign 1 203 963
priorPeerGet 0 203 963
assign 1 204 964
new 0 204 964
assign 1 204 967
new 0 204 967
assign 1 204 968
lesser 1 204 973
assign 1 205 974
def 1 205 979
assign 1 206 980
typenameGet 0 206 980
assign 1 206 981
DEFMODGet 0 206 981
assign 1 206 982
equals 1 206 987
assign 1 207 988
typenameGet 0 207 988
assign 1 207 989
DEFMODGet 0 207 989
assign 1 207 990
equals 1 207 995
assign 1 207 996
heldGet 0 207 996
assign 1 207 997
new 0 207 997
assign 1 207 998
equals 1 207 998
assign 1 0 1000
assign 1 0 1003
assign 1 0 1007
assign 1 208 1010
heldGet 0 208 1010
assign 1 208 1011
new 0 208 1011
isFinalSet 1 208 1012
assign 1 209 1015
typenameGet 0 209 1015
assign 1 209 1016
DEFMODGet 0 209 1016
assign 1 209 1017
equals 1 209 1022
assign 1 209 1023
heldGet 0 209 1023
assign 1 209 1024
new 0 209 1024
assign 1 209 1025
equals 1 209 1025
assign 1 0 1027
assign 1 0 1030
assign 1 0 1034
assign 1 211 1037
new 0 211 1037
assign 1 211 1038
new 2 211 1038
throw 1 211 1039
assign 1 213 1042
priorPeerGet 0 213 1042
delete 0 214 1043
assign 1 215 1044
assign 1 217 1047
assign 1 204 1050
increment 0 204 1050
assign 1 222 1057
containedGet 0 222 1057
assign 1 222 1058
firstGet 0 222 1058
assign 1 223 1059
def 1 223 1064
assign 1 224 1065
nextPeerGet 0 224 1065
assign 1 225 1066
def 1 225 1071
assign 1 226 1072
nextPeerGet 0 226 1072
assign 1 227 1073
typenameGet 0 227 1073
assign 1 227 1074
IDGet 0 227 1074
assign 1 227 1075
equals 1 227 1075
assign 1 0 1077
assign 1 227 1080
typenameGet 0 227 1080
assign 1 227 1081
NAMEPATHGet 0 227 1081
assign 1 227 1082
equals 1 227 1082
assign 1 0 1084
assign 1 0 1087
assign 1 229 1091
typenameGet 0 229 1091
assign 1 229 1092
IDGet 0 229 1092
assign 1 229 1093
equals 1 229 1093
assign 1 230 1095
new 0 230 1095
assign 1 231 1096
heldGet 0 231 1096
addStep 1 231 1097
assign 1 233 1100
heldGet 0 233 1100
assign 1 235 1102
new 0 235 1102
assign 1 236 1103
new 0 236 1103
isTypedSet 1 236 1104
namepathSet 1 237 1105
assign 1 238 1106
VARGet 0 238 1106
typenameSet 1 238 1107
heldSet 1 239 1108
assign 1 242 1111
typenameGet 0 242 1111
assign 1 242 1112
IDGet 0 242 1112
assign 1 242 1113
equals 1 242 1113
assign 1 243 1115
heldGet 0 243 1115
assign 1 243 1116
heldGet 0 243 1116
nameSet 1 243 1117
assign 1 244 1118
heldGet 0 244 1118
assign 1 244 1119
nameGet 0 244 1119
assign 1 244 1120
new 0 244 1120
assign 1 244 1121
getPoint 1 244 1121
assign 1 244 1122
isInteger 0 244 1122
assign 1 245 1124
new 0 245 1124
assign 1 245 1125
new 2 245 1125
throw 1 245 1126
delete 0 247 1128
assign 1 249 1131
new 0 249 1131
assign 1 249 1132
new 2 249 1132
throw 1 249 1133
assign 1 252 1137
new 0 252 1137
assign 1 252 1138
new 2 252 1138
throw 1 252 1139
assign 1 255 1144
classNameGet 0 255 1144
assign 1 255 1145
new 0 255 1145
assign 1 255 1146
equals 1 255 1146
throw 1 255 1148
print 0 256 1150
assign 1 257 1151
new 0 257 1151
assign 1 257 1152
new 2 257 1152
throw 1 257 1153
assign 1 259 1155
nextDescendGet 0 259 1155
return 1 259 1156
assign 1 261 1158
constantsGet 0 261 1158
assign 1 261 1159
parensReqGet 0 261 1159
assign 1 261 1160
typenameGet 0 261 1160
assign 1 261 1161
has 1 261 1161
assign 1 262 1163
containedGet 0 262 1163
assign 1 262 1164
firstGet 0 262 1164
assign 1 263 1165
undef 1 263 1170
assign 1 0 1171
assign 1 263 1174
typenameGet 0 263 1174
assign 1 263 1175
PARENSGet 0 263 1175
assign 1 263 1176
notEquals 1 263 1176
assign 1 0 1178
assign 1 0 1181
assign 1 264 1185
new 0 264 1185
assign 1 264 1186
new 2 264 1186
throw 1 264 1187
assign 1 268 1190
typenameGet 0 268 1190
assign 1 268 1191
BRACESGet 0 268 1191
assign 1 268 1192
equals 1 268 1197
assign 1 269 1198
containerGet 0 269 1198
assign 1 270 1199
def 1 270 1204
assign 1 270 1205
typenameGet 0 270 1205
assign 1 270 1206
EXPRGet 0 270 1206
assign 1 270 1207
equals 1 270 1207
assign 1 0 1209
assign 1 0 1212
assign 1 0 1216
assign 1 271 1219
PARENSGet 0 271 1219
typenameSet 1 271 1220
assign 1 274 1223
typenameGet 0 274 1223
assign 1 274 1224
SEMIGet 0 274 1224
assign 1 274 1225
equals 1 274 1230
assign 1 275 1231
priorPeerGet 0 275 1231
assign 1 276 1232
nextAscendGet 0 276 1232
assign 1 280 1235
def 1 280 1240
assign 1 280 1241
typenameGet 0 280 1241
assign 1 280 1242
SEMIGet 0 280 1242
assign 1 280 1243
notEquals 1 280 1243
assign 1 0 1245
assign 1 0 1248
assign 1 0 1252
assign 1 280 1255
typenameGet 0 280 1255
assign 1 280 1256
BRACESGet 0 280 1256
assign 1 280 1257
notEquals 1 280 1257
assign 1 0 1259
assign 1 0 1262
assign 1 0 1266
assign 1 280 1269
typenameGet 0 280 1269
assign 1 280 1270
EXPRGet 0 280 1270
assign 1 280 1271
notEquals 1 280 1271
assign 1 0 1273
assign 1 0 1276
assign 1 0 1280
assign 1 281 1283
undef 1 281 1288
assign 1 282 1289
new 0 282 1289
prepend 1 284 1291
assign 1 285 1292
priorPeerGet 0 285 1292
assign 1 287 1298
def 1 287 1303
assign 1 288 1304
EXPRGet 0 288 1304
typenameSet 1 288 1305
heldSet 1 289 1306
assign 1 290 1307
new 1 290 1307
assign 1 291 1308
PARENSGet 0 291 1308
typenameSet 1 291 1309
addValue 1 292 1310
copyLoc 1 293 1311
assign 1 294 1312
iteratorGet 0 294 1312
assign 1 294 1315
hasNextGet 0 294 1315
assign 1 295 1317
nextGet 0 295 1317
delete 0 296 1318
addValue 1 297 1319
delete 0 304 1327
return 1 306 1329
assign 1 309 1331
nextDescendGet 0 309 1331
return 1 309 1332
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass5();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass5.bevs_inst = (BEC_3_5_5_5_BuildVisitPass5)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass5.bevs_inst;
}
}
}
