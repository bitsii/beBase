namespace be {
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException : BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
static BEC_2_6_9_SystemException() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 2));
private static byte[] bels_12 = {0x0D,0x0A};
private static byte[] bels_13 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 3));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_15 = {0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 1));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_16 = {0x69,0x6E};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 2));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_17 = {0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_18 = {0x3A};
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_19 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_19, 5));
private static byte[] bels_20 = {0x28};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_20, 1));
private static byte[] bels_21 = {0x29};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_21, 1));
private static BEC_2_4_3_MathInt bevo_18 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_22 = {0x3A};
private static BEC_2_4_3_MathInt bevo_20 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_23 = {0x3A};
private static BEC_2_4_3_MathInt bevo_21 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_22 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_24 = {0x28};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_24, 1));
private static BEC_2_4_3_MathInt bevo_24 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_25 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_26 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_25 = {0x2E};
private static byte[] bels_26 = {0x2E};
private static BEC_2_4_3_MathInt bevo_27 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_27 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_27, 4));
private static BEC_2_4_3_MathInt bevo_29 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_28 = {0x5F};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_28, 1));
private static BEC_2_4_3_MathInt bevo_31 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_32 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_29 = {0x62,0x65};
private static byte[] bels_30 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_30, 2));
private static byte[] bels_31 = {0x62,0x65};
private static byte[] bels_32 = {0x2E};
private static byte[] bels_33 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_33, 4));
private static byte[] bels_34 = {0x5F};
private static BEC_2_4_3_MathInt bevo_35 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_36 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_35 = {0x3A};
private static byte[] bels_36 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x5F};
private static BEC_2_4_3_MathInt bevo_38 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_39 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_38 = {0x5F};
private static byte[] bels_39 = {0x0A};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_39, 1));
public static new BEC_2_6_9_SystemException bevs_inst;
public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public virtual BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bels_0));
if (bevp_lang == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_1));
bevt_1_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpany_phold);
bevl_toRet = bevt_1_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_lang);
} /* Line: 37 */
if (bevp_emitLang == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_2));
bevt_4_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpany_phold);
bevl_toRet = bevt_4_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_emitLang);
} /* Line: 40 */
if (bevp_methodName == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_3));
bevt_7_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpany_phold);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_methodName);
} /* Line: 43 */
if (bevp_klassName == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_4));
bevt_10_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpany_phold);
bevl_toRet = bevt_10_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_klassName);
} /* Line: 46 */
if (bevp_description == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_5));
bevt_13_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpany_phold);
bevl_toRet = bevt_13_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_description);
} /* Line: 49 */
if (bevp_fileName == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_6));
bevt_16_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_17_tmpany_phold);
bevl_toRet = bevt_16_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_fileName);
} /* Line: 52 */
if (bevp_lineNumber == null) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 54 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_7));
bevt_19_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_20_tmpany_phold);
bevt_21_tmpany_phold = bevp_lineNumber.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_19_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpany_phold);
} /* Line: 55 */
if (bevp_framesText == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
bevt_23_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpany_phold);
bevl_toRet = bevt_23_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_framesText);
} /* Line: 58 */
if (bevp_frames == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_26_tmpany_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpany_phold);
} /* Line: 61 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translateEmittedException_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 67 */ {
this.bem_translateEmittedExceptionInner_0();
} /* Line: 68 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpany_phold = bevo_0;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 70 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translateEmittedExceptionInner_0() {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
if (bevp_translated == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 78 */ {
if (bevp_translated.bevi_bool) /* Line: 78 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
 else  /* Line: 78 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 78 */ {
return this;
} /* Line: 79 */
bevp_translated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 82 */ {
if (bevp_lang == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
 else  /* Line: 82 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_16_tmpany_phold = bevo_1;
bevt_15_tmpany_phold = bevp_lang.bem_equals_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_18_tmpany_phold = bevo_2;
bevt_17_tmpany_phold = bevp_lang.bem_equals_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
 else  /* Line: 82 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_12));
bevl_ltok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_19_tmpany_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_21_tmpany_phold = bevo_3;
bevt_20_tmpany_phold = bevp_lang.bem_equals_1(bevt_21_tmpany_phold);
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 88 */
bevt_0_tmpany_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 90 */ {
bevt_22_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold != null && bevt_22_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_22_tmpany_phold).bevi_bool) /* Line: 90 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_23_tmpany_phold = bevo_4;
bevl_start = bevl_line.bem_find_1(bevt_23_tmpany_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_26_tmpany_phold = bevo_5;
if (bevl_start.bevi_int >= bevt_26_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 95 */ {
bevt_27_tmpany_phold = bevo_6;
bevt_29_tmpany_phold = bevo_7;
bevt_28_tmpany_phold = bevl_start.bem_add_1(bevt_29_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_27_tmpany_phold, bevt_28_tmpany_phold);
if (bevl_end == null) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 98 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_33_tmpany_phold = bevo_8;
bevt_32_tmpany_phold = bevl_start.bem_add_1(bevt_33_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_32_tmpany_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 102 */ {
bevt_34_tmpany_phold = bevo_9;
bevl_start = bevl_line.bem_find_2(bevt_34_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_37_tmpany_phold = bevo_10;
bevt_36_tmpany_phold = bevl_start.bem_add_1(bevt_37_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_36_tmpany_phold);
bevt_39_tmpany_phold = bevo_11;
bevt_38_tmpany_phold = bevl_inPart.bem_ends_1(bevt_39_tmpany_phold);
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 107 */ {
bevt_41_tmpany_phold = bevl_inPart.bem_sizeGet_0();
bevt_42_tmpany_phold = bevo_12;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_subtract_1(bevt_42_tmpany_phold);
bevl_inPart.bem_sizeSet_1(bevt_40_tmpany_phold);
} /* Line: 108 */
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_18));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_43_tmpany_phold);
if (bevl_pdelim == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_45_tmpany_phold = bevo_13;
bevl_efile = bevl_inPart.bem_substring_2(bevt_45_tmpany_phold, bevl_pdelim);
bevt_47_tmpany_phold = bevo_14;
bevt_46_tmpany_phold = bevl_pdelim.bem_add_1(bevt_47_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_46_tmpany_phold);
bevt_49_tmpany_phold = bevo_15;
bevt_48_tmpany_phold = bevl_iv.bem_begins_1(bevt_49_tmpany_phold);
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_50_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_50_tmpany_phold);
} /* Line: 117 */
bevt_51_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 121 */
} /* Line: 120 */
} /* Line: 112 */
} /* Line: 104 */
 else  /* Line: 125 */ {
bevt_52_tmpany_phold = bevo_16;
bevl_start = bevl_line.bem_find_2(bevt_52_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_53_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevt_54_tmpany_phold = bevo_17;
bevt_56_tmpany_phold = bevo_18;
bevt_55_tmpany_phold = bevl_start.bem_add_1(bevt_56_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_54_tmpany_phold, bevt_55_tmpany_phold);
if (bevl_end == null) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_59_tmpany_phold = bevo_19;
bevt_58_tmpany_phold = bevl_start.bem_add_1(bevt_59_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_58_tmpany_phold, bevl_end);
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_22));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_60_tmpany_phold);
if (bevl_pdelim == null) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_62_tmpany_phold = bevo_20;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_62_tmpany_phold, bevl_pdelim);
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_23));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_63_tmpany_phold);
if (bevl_pdelim == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 140 */ {
bevt_65_tmpany_phold = bevo_21;
bevl_efile = bevl_inPart.bem_substring_2(bevt_65_tmpany_phold, bevl_pdelim);
} /* Line: 141 */
bevt_67_tmpany_phold = bevo_22;
bevt_66_tmpany_phold = bevl_pdelim.bem_add_1(bevt_67_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_66_tmpany_phold);
bevt_68_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 145 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 146 */
} /* Line: 145 */
} /* Line: 136 */
} /* Line: 131 */
} /* Line: 127 */
} /* Line: 102 */
 else  /* Line: 152 */ {
bevt_69_tmpany_phold = bevo_23;
bevt_71_tmpany_phold = bevo_24;
bevt_70_tmpany_phold = bevl_start.bem_add_1(bevt_71_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_69_tmpany_phold, bevt_70_tmpany_phold);
if (bevl_end == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 154 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 154 */ {
bevt_75_tmpany_phold = bevo_25;
bevt_74_tmpany_phold = bevl_start.bem_add_1(bevt_75_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_74_tmpany_phold, bevl_end);
} /* Line: 155 */
 else  /* Line: 156 */ {
bevt_77_tmpany_phold = bevo_26;
bevt_76_tmpany_phold = bevl_start.bem_add_1(bevt_77_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_76_tmpany_phold);
} /* Line: 157 */
} /* Line: 154 */
if (bevl_callPart == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 160 */ {
if (bevl_isCs.bevi_bool) /* Line: 161 */ {
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_25));
bevl_parts = bevl_callPart.bem_split_1(bevt_79_tmpany_phold);
bevt_80_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_81_tmpany_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_83_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_82_tmpany_phold = this.bem_getSourceFileName_1(bevt_83_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_82_tmpany_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 174 */
 else  /* Line: 175 */ {
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_26));
bevl_parts = bevl_callPart.bem_split_1(bevt_84_tmpany_phold);
bevt_86_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_87_tmpany_phold = bevo_27;
if (bevt_86_tmpany_phold.bevi_int > bevt_87_tmpany_phold.bevi_int) {
bevt_85_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_85_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_85_tmpany_phold.bevi_bool) /* Line: 179 */ {
bevt_88_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_88_tmpany_phold);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevt_89_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = bevo_28;
bevl_start = bevl_klass.bem_find_1(bevt_90_tmpany_phold);
if (bevl_start == null) {
bevt_91_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_91_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_91_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevt_93_tmpany_phold = bevo_29;
if (bevl_start.bevi_int > bevt_93_tmpany_phold.bevi_int) {
bevt_92_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 185 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 185 */
 else  /* Line: 185 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 185 */ {
bevt_94_tmpany_phold = bevo_30;
bevt_96_tmpany_phold = bevo_31;
bevt_95_tmpany_phold = bevl_start.bem_add_1(bevt_96_tmpany_phold);
bevl_end = bevl_klass.bem_find_2(bevt_94_tmpany_phold, bevt_95_tmpany_phold);
if (bevl_end == null) {
bevt_97_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_97_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_97_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_99_tmpany_phold = bevo_32;
if (bevl_end.bevi_int > bevt_99_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 187 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 187 */
 else  /* Line: 187 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 187 */ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_101_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_100_tmpany_phold = this.bem_getSourceFileName_1(bevt_101_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_100_tmpany_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 197 */
} /* Line: 187 */
} /* Line: 185 */
} /* Line: 179 */
} /* Line: 161 */
} /* Line: 160 */
} /* Line: 95 */
 else  /* Line: 90 */ {
break;
} /* Line: 90 */
} /* Line: 90 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_29));
bevp_framesText = null;
} /* Line: 207 */
 else  /* Line: 82 */ {
if (bevp_frames == null) {
bevt_102_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpany_phold.bevi_bool) /* Line: 208 */ {
if (bevp_lang == null) {
bevt_103_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 208 */
 else  /* Line: 208 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 208 */ {
bevt_105_tmpany_phold = bevo_33;
bevt_104_tmpany_phold = bevp_lang.bem_equals_1(bevt_105_tmpany_phold);
if (bevt_104_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 208 */
 else  /* Line: 208 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 208 */ {
bevt_1_tmpany_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 209 */ {
bevt_106_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_106_tmpany_phold != null && bevt_106_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_106_tmpany_phold).bevi_bool) /* Line: 209 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpany_loop.bem_nextGet_0();
bevt_108_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_107_tmpany_phold = this.bem_extractKlassLib_1(bevt_108_tmpany_phold);
bevl_fr.bem_klassNameSet_1(bevt_107_tmpany_phold);
bevt_110_tmpany_phold = bevl_fr.bem_methodNameGet_0();
bevt_109_tmpany_phold = this.bem_extractMethod_1(bevt_110_tmpany_phold);
bevl_fr.bem_methodNameSet_1(bevt_109_tmpany_phold);
bevt_112_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_111_tmpany_phold = this.bem_getSourceFileName_1(bevt_112_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_111_tmpany_phold);
} /* Line: 213 */
 else  /* Line: 209 */ {
break;
} /* Line: 209 */
} /* Line: 209 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_31));
} /* Line: 218 */
 else  /* Line: 219 */ {
} /* Line: 219 */
} /* Line: 82 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = this.bem_createInstance_2(beva_klassName, bevt_0_tmpany_phold);
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(478622533, BEL_4_Base.bevn_sourceFileNameGet_0);
return (BEC_2_4_6_TextString) bevt_2_tmpany_phold;
} /* Line: 229 */
return null;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_32));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_2_tmpany_phold = bevl_parts.bem_get_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = this.bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpany_phold);
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 243 */ {
bevt_0_tmpany_phold = this.bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpany_phold;
} /* Line: 244 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 245 */
return beva_klass;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 252 */ {
bevt_4_tmpany_phold = bevo_34;
bevt_3_tmpany_phold = beva_klass.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 252 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 252 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 252 */ {
return beva_klass;
} /* Line: 253 */
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_5_tmpany_phold = beva_klass.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_34));
bevl_kparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bevo_35;
bevl_kps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 260 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevt_11_tmpany_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpany_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpany_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_16_tmpany_phold = bevo_36;
bevt_15_tmpany_phold = bevl_i.bem_add_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_35));
bevl_bec.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 264 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 260 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
return bevl_bec;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
if (beva_mtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_4_tmpany_phold = bevo_37;
bevt_3_tmpany_phold = beva_mtd.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 272 */ {
return beva_mtd;
} /* Line: 273 */
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_5_tmpany_phold = beva_mtd.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_37));
bevl_mparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bevo_38;
bevl_mps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_bem = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 278 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 278 */ {
bevt_11_tmpany_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = bevo_39;
bevt_13_tmpany_phold = bevl_i.bem_add_1(bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 280 */ {
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_38));
bevl_bem.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 280 */
bevl_i.bevi_int++;
} /* Line: 278 */
 else  /* Line: 278 */ {
break;
} /* Line: 278 */
} /* Line: 278 */
return bevl_bem;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_framesGet_0() {
this.bem_translateEmittedException_0();
return bevp_frames;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFrameText_0() {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = this.bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_2_tmpany_phold = bevo_40;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 299 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 299 */ {
bevl_ft = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 300 */
 else  /* Line: 299 */ {
break;
} /* Line: 299 */
} /* Line: 299 */
} /* Line: 299 */
return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassNameGet_0() {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_frames == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 312 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) {
BEC_2_9_5_ExceptionFrame bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
this.bem_addFrame_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionGet_0() {
return bevp_description;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberGet_0() {
return bevp_lineNumber;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_langGet_0() {
return bevp_lang;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_framesTextGet_0() {
return bevp_framesText;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_translatedGet_0() {
return bevp_translated;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {28, 32, 35, 36, 36, 37, 37, 37, 39, 39, 40, 40, 40, 42, 42, 43, 43, 43, 45, 45, 46, 46, 46, 48, 48, 49, 49, 49, 51, 51, 52, 52, 52, 54, 54, 55, 55, 55, 55, 57, 57, 58, 58, 58, 60, 60, 61, 61, 63, 68, 70, 70, 78, 78, 0, 0, 0, 79, 81, 82, 82, 82, 82, 0, 0, 0, 82, 82, 0, 82, 82, 0, 0, 0, 0, 0, 83, 83, 84, 85, 85, 86, 88, 90, 0, 90, 90, 92, 92, 93, 94, 95, 95, 95, 95, 95, 0, 0, 0, 97, 97, 97, 97, 98, 98, 98, 98, 0, 0, 0, 100, 100, 100, 103, 103, 104, 104, 106, 106, 106, 107, 107, 108, 108, 108, 108, 111, 111, 112, 112, 113, 113, 115, 115, 115, 116, 116, 117, 117, 120, 121, 126, 126, 127, 127, 130, 130, 130, 130, 131, 131, 133, 133, 133, 135, 135, 136, 136, 137, 137, 139, 139, 140, 140, 141, 141, 143, 143, 143, 145, 146, 153, 153, 153, 153, 154, 154, 154, 154, 0, 0, 0, 155, 155, 155, 157, 157, 157, 160, 160, 163, 163, 165, 165, 166, 166, 168, 170, 172, 173, 173, 173, 174, 178, 178, 179, 179, 179, 179, 180, 180, 181, 183, 183, 184, 184, 185, 185, 185, 185, 185, 0, 0, 0, 186, 186, 186, 186, 187, 187, 187, 187, 187, 0, 0, 0, 191, 193, 195, 196, 196, 196, 197, 205, 206, 207, 208, 208, 208, 208, 0, 0, 0, 208, 208, 0, 0, 0, 209, 0, 209, 209, 210, 210, 210, 211, 211, 211, 212, 212, 212, 217, 218, 226, 226, 227, 227, 229, 229, 232, 237, 237, 239, 239, 239, 239, 244, 244, 248, 252, 252, 0, 252, 252, 252, 252, 0, 0, 253, 255, 255, 255, 255, 256, 256, 256, 257, 258, 259, 260, 260, 260, 261, 261, 263, 263, 263, 264, 264, 264, 264, 264, 264, 265, 260, 268, 272, 272, 0, 272, 272, 272, 272, 0, 0, 273, 275, 275, 275, 275, 276, 276, 276, 277, 278, 278, 278, 279, 279, 280, 280, 280, 280, 280, 280, 278, 283, 289, 290, 294, 295, 296, 297, 297, 298, 298, 299, 0, 299, 299, 300, 303, 307, 311, 311, 312, 314, 318, 318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {101, 133, 134, 135, 140, 141, 142, 143, 145, 150, 151, 152, 153, 155, 160, 161, 162, 163, 165, 170, 171, 172, 173, 175, 180, 181, 182, 183, 185, 190, 191, 192, 193, 195, 200, 201, 202, 203, 204, 206, 211, 212, 213, 214, 216, 221, 222, 223, 225, 231, 235, 236, 370, 375, 377, 380, 384, 387, 389, 390, 395, 396, 401, 402, 405, 409, 412, 413, 415, 418, 419, 421, 424, 428, 431, 435, 438, 439, 440, 441, 442, 444, 447, 449, 449, 452, 454, 455, 456, 457, 458, 459, 464, 465, 466, 471, 472, 475, 479, 482, 483, 484, 485, 486, 491, 492, 497, 498, 501, 505, 508, 509, 510, 512, 513, 514, 519, 520, 521, 522, 523, 524, 526, 527, 528, 529, 531, 532, 533, 538, 539, 540, 541, 542, 543, 544, 545, 547, 548, 550, 552, 558, 559, 560, 565, 566, 567, 568, 569, 570, 575, 576, 577, 578, 579, 580, 581, 586, 587, 588, 589, 590, 591, 596, 597, 598, 600, 601, 602, 603, 605, 613, 614, 615, 616, 617, 622, 623, 628, 629, 632, 636, 639, 640, 641, 644, 645, 646, 649, 654, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 671, 672, 673, 674, 675, 680, 681, 682, 683, 684, 685, 686, 687, 688, 693, 694, 695, 700, 701, 704, 708, 711, 712, 713, 714, 715, 720, 721, 722, 727, 728, 731, 735, 738, 739, 740, 741, 742, 743, 744, 756, 757, 758, 761, 766, 767, 772, 773, 776, 780, 783, 784, 786, 789, 793, 796, 796, 799, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 816, 817, 829, 830, 831, 836, 837, 838, 840, 848, 849, 850, 851, 852, 853, 859, 860, 865, 893, 898, 899, 902, 903, 904, 909, 910, 913, 917, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 932, 937, 938, 939, 940, 941, 942, 943, 944, 945, 950, 951, 952, 954, 955, 961, 984, 989, 990, 993, 994, 995, 1000, 1001, 1004, 1008, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1021, 1026, 1027, 1028, 1029, 1030, 1031, 1036, 1037, 1038, 1040, 1046, 1049, 1050, 1060, 1061, 1062, 1063, 1068, 1069, 1070, 1071, 1071, 1074, 1076, 1077, 1084, 1087, 1091, 1096, 1097, 1099, 1104, 1105, 1109, 1112, 1116, 1120, 1123, 1127, 1130, 1134, 1137, 1141, 1144, 1148, 1151, 1155, 1159, 1162, 1166, 1169};
/* BEGIN LINEINFO 
assign 1 28 101
translateEmittedException 0 32 133
assign 1 35 134
new 0 35 134
assign 1 36 135
def 1 36 140
assign 1 37 141
new 0 37 141
assign 1 37 142
add 1 37 142
assign 1 37 143
add 1 37 143
assign 1 39 145
def 1 39 150
assign 1 40 151
new 0 40 151
assign 1 40 152
add 1 40 152
assign 1 40 153
add 1 40 153
assign 1 42 155
def 1 42 160
assign 1 43 161
new 0 43 161
assign 1 43 162
add 1 43 162
assign 1 43 163
add 1 43 163
assign 1 45 165
def 1 45 170
assign 1 46 171
new 0 46 171
assign 1 46 172
add 1 46 172
assign 1 46 173
add 1 46 173
assign 1 48 175
def 1 48 180
assign 1 49 181
new 0 49 181
assign 1 49 182
add 1 49 182
assign 1 49 183
add 1 49 183
assign 1 51 185
def 1 51 190
assign 1 52 191
new 0 52 191
assign 1 52 192
add 1 52 192
assign 1 52 193
add 1 52 193
assign 1 54 195
def 1 54 200
assign 1 55 201
new 0 55 201
assign 1 55 202
add 1 55 202
assign 1 55 203
toString 0 55 203
assign 1 55 204
add 1 55 204
assign 1 57 206
def 1 57 211
assign 1 58 212
new 0 58 212
assign 1 58 213
add 1 58 213
assign 1 58 214
add 1 58 214
assign 1 60 216
def 1 60 221
assign 1 61 222
getFrameText 0 61 222
assign 1 61 223
add 1 61 223
return 1 63 225
translateEmittedExceptionInner 0 68 231
assign 1 70 235
new 0 70 235
print 0 70 236
assign 1 78 370
def 1 78 375
assign 1 0 377
assign 1 0 380
assign 1 0 384
return 1 79 387
assign 1 81 389
new 0 81 389
assign 1 82 390
def 1 82 395
assign 1 82 396
def 1 82 401
assign 1 0 402
assign 1 0 405
assign 1 0 409
assign 1 82 412
new 0 82 412
assign 1 82 413
equals 1 82 413
assign 1 0 415
assign 1 82 418
new 0 82 418
assign 1 82 419
equals 1 82 419
assign 1 0 421
assign 1 0 424
assign 1 0 428
assign 1 0 431
assign 1 0 435
assign 1 83 438
new 0 83 438
assign 1 83 439
new 1 83 439
assign 1 84 440
tokenize 1 84 440
assign 1 85 441
new 0 85 441
assign 1 85 442
equals 1 85 442
assign 1 86 444
new 0 86 444
assign 1 88 447
new 0 88 447
assign 1 90 449
linkedListIteratorGet 0 0 449
assign 1 90 452
hasNextGet 0 90 452
assign 1 90 454
nextGet 0 90 454
assign 1 92 455
new 0 92 455
assign 1 92 456
find 1 92 456
assign 1 93 457
assign 1 94 458
assign 1 95 459
def 1 95 464
assign 1 95 465
new 0 95 465
assign 1 95 466
greaterEquals 1 95 471
assign 1 0 472
assign 1 0 475
assign 1 0 479
assign 1 97 482
new 0 97 482
assign 1 97 483
new 0 97 483
assign 1 97 484
add 1 97 484
assign 1 97 485
find 2 97 485
assign 1 98 486
def 1 98 491
assign 1 98 492
greater 1 98 497
assign 1 0 498
assign 1 0 501
assign 1 0 505
assign 1 100 508
new 0 100 508
assign 1 100 509
add 1 100 509
assign 1 100 510
substring 2 100 510
assign 1 103 512
new 0 103 512
assign 1 103 513
find 2 103 513
assign 1 104 514
def 1 104 519
assign 1 106 520
new 0 106 520
assign 1 106 521
add 1 106 521
assign 1 106 522
substring 1 106 522
assign 1 107 523
new 0 107 523
assign 1 107 524
ends 1 107 524
assign 1 108 526
sizeGet 0 108 526
assign 1 108 527
new 0 108 527
assign 1 108 528
subtract 1 108 528
sizeSet 1 108 529
assign 1 111 531
new 0 111 531
assign 1 111 532
rfind 1 111 532
assign 1 112 533
def 1 112 538
assign 1 113 539
new 0 113 539
assign 1 113 540
substring 2 113 540
assign 1 115 541
new 0 115 541
assign 1 115 542
add 1 115 542
assign 1 115 543
substring 1 115 543
assign 1 116 544
new 0 116 544
assign 1 116 545
begins 1 116 545
assign 1 117 547
new 0 117 547
assign 1 117 548
substring 1 117 548
assign 1 120 550
isInteger 0 120 550
assign 1 121 552
new 1 121 552
assign 1 126 558
new 0 126 558
assign 1 126 559
find 2 126 559
assign 1 127 560
def 1 127 565
assign 1 130 566
new 0 130 566
assign 1 130 567
new 0 130 567
assign 1 130 568
add 1 130 568
assign 1 130 569
find 2 130 569
assign 1 131 570
def 1 131 575
assign 1 133 576
new 0 133 576
assign 1 133 577
add 1 133 577
assign 1 133 578
substring 2 133 578
assign 1 135 579
new 0 135 579
assign 1 135 580
rfind 1 135 580
assign 1 136 581
def 1 136 586
assign 1 137 587
new 0 137 587
assign 1 137 588
substring 2 137 588
assign 1 139 589
new 0 139 589
assign 1 139 590
rfind 1 139 590
assign 1 140 591
def 1 140 596
assign 1 141 597
new 0 141 597
assign 1 141 598
substring 2 141 598
assign 1 143 600
new 0 143 600
assign 1 143 601
add 1 143 601
assign 1 143 602
substring 1 143 602
assign 1 145 603
isInteger 0 145 603
assign 1 146 605
new 1 146 605
assign 1 153 613
new 0 153 613
assign 1 153 614
new 0 153 614
assign 1 153 615
add 1 153 615
assign 1 153 616
find 2 153 616
assign 1 154 617
def 1 154 622
assign 1 154 623
greater 1 154 628
assign 1 0 629
assign 1 0 632
assign 1 0 636
assign 1 155 639
new 0 155 639
assign 1 155 640
add 1 155 640
assign 1 155 641
substring 2 155 641
assign 1 157 644
new 0 157 644
assign 1 157 645
add 1 157 645
assign 1 157 646
substring 1 157 646
assign 1 160 649
def 1 160 654
assign 1 163 656
new 0 163 656
assign 1 163 657
split 1 163 657
assign 1 165 658
new 0 165 658
assign 1 165 659
get 1 165 659
assign 1 166 660
new 0 166 660
assign 1 166 661
get 1 166 661
assign 1 168 662
extractKlass 1 168 662
assign 1 170 663
extractMethod 1 170 663
assign 1 172 664
new 4 172 664
assign 1 173 665
klassNameGet 0 173 665
assign 1 173 666
getSourceFileName 1 173 666
fileNameSet 1 173 667
addFrame 1 174 668
assign 1 178 671
new 0 178 671
assign 1 178 672
split 1 178 672
assign 1 179 673
sizeGet 0 179 673
assign 1 179 674
new 0 179 674
assign 1 179 675
greater 1 179 680
assign 1 180 681
new 0 180 681
assign 1 180 682
get 1 180 682
assign 1 181 683
extractMethod 1 181 683
assign 1 183 684
new 0 183 684
assign 1 183 685
get 1 183 685
assign 1 184 686
new 0 184 686
assign 1 184 687
find 1 184 687
assign 1 185 688
def 1 185 693
assign 1 185 694
new 0 185 694
assign 1 185 695
greater 1 185 700
assign 1 0 701
assign 1 0 704
assign 1 0 708
assign 1 186 711
new 0 186 711
assign 1 186 712
new 0 186 712
assign 1 186 713
add 1 186 713
assign 1 186 714
find 2 186 714
assign 1 187 715
def 1 187 720
assign 1 187 721
new 0 187 721
assign 1 187 722
greater 1 187 727
assign 1 0 728
assign 1 0 731
assign 1 0 735
assign 1 191 738
substring 1 191 738
assign 1 193 739
extractKlass 1 193 739
assign 1 195 740
new 4 195 740
assign 1 196 741
klassNameGet 0 196 741
assign 1 196 742
getSourceFileName 1 196 742
fileNameSet 1 196 743
addFrame 1 197 744
assign 1 205 756
assign 1 206 757
new 0 206 757
assign 1 207 758
assign 1 208 761
def 1 208 766
assign 1 208 767
def 1 208 772
assign 1 0 773
assign 1 0 776
assign 1 0 780
assign 1 208 783
new 0 208 783
assign 1 208 784
equals 1 208 784
assign 1 0 786
assign 1 0 789
assign 1 0 793
assign 1 209 796
linkedListIteratorGet 0 0 796
assign 1 209 799
hasNextGet 0 209 799
assign 1 209 801
nextGet 0 209 801
assign 1 210 802
klassNameGet 0 210 802
assign 1 210 803
extractKlassLib 1 210 803
klassNameSet 1 210 804
assign 1 211 805
methodNameGet 0 211 805
assign 1 211 806
extractMethod 1 211 806
methodNameSet 1 211 807
assign 1 212 808
klassNameGet 0 212 808
assign 1 212 809
getSourceFileName 1 212 809
fileNameSet 1 212 810
assign 1 217 816
assign 1 218 817
new 0 218 817
assign 1 226 829
new 0 226 829
assign 1 226 830
createInstance 2 226 830
assign 1 227 831
def 1 227 836
assign 1 229 837
sourceFileNameGet 0 229 837
return 1 229 838
return 1 232 840
assign 1 237 848
new 0 237 848
assign 1 237 849
split 1 237 849
assign 1 239 850
new 0 239 850
assign 1 239 851
get 1 239 851
assign 1 239 852
extractKlass 1 239 852
return 1 239 853
assign 1 244 859
extractKlassInner 1 244 859
return 1 244 860
return 1 248 865
assign 1 252 893
undef 1 252 898
assign 1 0 899
assign 1 252 902
new 0 252 902
assign 1 252 903
begins 1 252 903
assign 1 252 904
not 0 252 909
assign 1 0 910
assign 1 0 913
return 1 253 917
assign 1 255 919
new 0 255 919
assign 1 255 920
substring 1 255 920
assign 1 255 921
new 0 255 921
assign 1 255 922
split 1 255 922
assign 1 256 923
sizeGet 0 256 923
assign 1 256 924
new 0 256 924
assign 1 256 925
subtract 1 256 925
assign 1 257 926
get 1 257 926
assign 1 258 927
new 0 258 927
assign 1 259 928
new 0 259 928
assign 1 260 929
new 0 260 929
assign 1 260 932
lesser 1 260 937
assign 1 261 938
get 1 261 938
assign 1 261 939
new 1 261 939
assign 1 263 940
add 1 263 940
assign 1 263 941
substring 2 263 941
addValue 1 263 942
assign 1 264 943
new 0 264 943
assign 1 264 944
add 1 264 944
assign 1 264 945
lesser 1 264 950
assign 1 264 951
new 0 264 951
addValue 1 264 952
addValue 1 265 954
incrementValue 0 260 955
return 1 268 961
assign 1 272 984
undef 1 272 989
assign 1 0 990
assign 1 272 993
new 0 272 993
assign 1 272 994
begins 1 272 994
assign 1 272 995
not 0 272 1000
assign 1 0 1001
assign 1 0 1004
return 1 273 1008
assign 1 275 1010
new 0 275 1010
assign 1 275 1011
substring 1 275 1011
assign 1 275 1012
new 0 275 1012
assign 1 275 1013
split 1 275 1013
assign 1 276 1014
sizeGet 0 276 1014
assign 1 276 1015
new 0 276 1015
assign 1 276 1016
subtract 1 276 1016
assign 1 277 1017
new 0 277 1017
assign 1 278 1018
new 0 278 1018
assign 1 278 1021
lesser 1 278 1026
assign 1 279 1027
get 1 279 1027
addValue 1 279 1028
assign 1 280 1029
new 0 280 1029
assign 1 280 1030
add 1 280 1030
assign 1 280 1031
lesser 1 280 1036
assign 1 280 1037
new 0 280 1037
addValue 1 280 1038
incrementValue 0 278 1040
return 1 283 1046
translateEmittedException 0 289 1049
return 1 290 1050
translateEmittedException 0 294 1060
assign 1 295 1061
new 0 295 1061
assign 1 296 1062
framesGet 0 296 1062
assign 1 297 1063
def 1 297 1068
assign 1 298 1069
new 0 298 1069
assign 1 298 1070
add 1 298 1070
assign 1 299 1071
linkedListIteratorGet 0 0 1071
assign 1 299 1074
hasNextGet 0 299 1074
assign 1 299 1076
nextGet 0 299 1076
assign 1 300 1077
add 1 300 1077
return 1 303 1084
return 1 307 1087
assign 1 311 1091
undef 1 311 1096
assign 1 312 1097
new 0 312 1097
addValue 1 314 1099
assign 1 318 1104
new 4 318 1104
addFrame 1 318 1105
return 1 0 1109
assign 1 0 1112
assign 1 0 1116
return 1 0 1120
assign 1 0 1123
return 1 0 1127
assign 1 0 1130
return 1 0 1134
assign 1 0 1137
return 1 0 1141
assign 1 0 1144
return 1 0 1148
assign 1 0 1151
assign 1 0 1155
return 1 0 1159
assign 1 0 1162
return 1 0 1166
assign 1 0 1169
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case 734830721: return bem_framesGet_0();
case 1475977273: return bem_langGet_0();
case -1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case -1184167343: return bem_translatedGet_0();
case -764669899: return bem_getFrameText_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 484558571: return bem_descriptionGet_0();
case -1611190486: return bem_lineNumberGet_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 154290862: return bem_translateEmittedException_0();
case -1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 970476426: return bem_translateEmittedExceptionInner_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case -845792839: return bem_iteratorGet_0();
case -1141730732: return bem_framesTextGet_0();
case -314718434: return bem_print_0();
case -220901978: return bem_emitLangGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1286797640: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2124977673: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case -813541388: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1173085090: return bem_translatedSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -205231606: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -371136143: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1130648479: return bem_framesTextSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_9_SystemException();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_9_SystemException.bevs_inst = (BEC_2_6_9_SystemException)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_9_SystemException.bevs_inst;
}
}
}
