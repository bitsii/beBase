namespace be {
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException : BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
static BEC_2_6_9_SystemException() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 2));
private static byte[] bels_12 = {0x0D,0x0A};
private static byte[] bels_13 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 3));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_15 = {0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 1));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_16 = {0x69,0x6E};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 2));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_17 = {0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_18 = {0x3A};
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_19 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_19, 5));
private static byte[] bels_20 = {0x28};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_20, 1));
private static byte[] bels_21 = {0x29};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_21, 1));
private static BEC_2_4_3_MathInt bevo_18 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_22 = {0x3A};
private static BEC_2_4_3_MathInt bevo_20 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_23 = {0x3A};
private static BEC_2_4_3_MathInt bevo_21 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_22 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_24 = {0x28};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_24, 1));
private static BEC_2_4_3_MathInt bevo_24 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_25 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_26 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_25 = {0x2E};
private static byte[] bels_26 = {0x2E};
private static BEC_2_4_3_MathInt bevo_27 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_27 = {0x42,0x45,0x4C,0x5F};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_27, 4));
private static BEC_2_4_3_MathInt bevo_29 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_28 = {0x5F};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_28, 1));
private static BEC_2_4_3_MathInt bevo_31 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_32 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_33 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_34 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static byte[] bels_29 = {0x62,0x65};
private static byte[] bels_30 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_30, 2));
private static byte[] bels_31 = {0x62,0x65};
private static byte[] bels_32 = {0x2E};
private static byte[] bels_33 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_33, 4));
private static byte[] bels_34 = {0x5F};
private static BEC_2_4_3_MathInt bevo_37 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_38 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_35 = {0x3A};
private static byte[] bels_36 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x5F};
private static BEC_2_4_3_MathInt bevo_40 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_41 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_38 = {0x5F};
private static byte[] bels_39 = {0x0A};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_39, 1));
public static new BEC_2_6_9_SystemException bevs_inst;
public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public virtual BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bels_0));
if (bevp_lang == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_1));
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevl_toRet = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_lang);
} /* Line: 37 */
if (bevp_emitLang == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_2));
bevt_4_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_emitLang);
} /* Line: 40 */
if (bevp_methodName == null) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 42 */ {
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_3));
bevt_7_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpvar_phold);
bevl_toRet = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_methodName);
} /* Line: 43 */
if (bevp_klassName == null) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_4));
bevt_10_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_toRet = bevt_10_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_klassName);
} /* Line: 46 */
if (bevp_description == null) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_5));
bevt_13_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevl_toRet = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_description);
} /* Line: 49 */
if (bevp_fileName == null) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_6));
bevt_16_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_17_tmpvar_phold);
bevl_toRet = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_fileName);
} /* Line: 52 */
if (bevp_lineNumber == null) {
bevt_18_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_7));
bevt_19_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = bevp_lineNumber.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
} /* Line: 55 */
if (bevp_framesText == null) {
bevt_22_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevl_toRet = bevt_23_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_framesText);
} /* Line: 58 */
if (bevp_frames == null) {
bevt_25_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_26_tmpvar_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 61 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translateEmittedException_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
try  /* Line: 67 */ {
this.bem_translateEmittedExceptionInner_0();
} /* Line: 68 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold.bem_print_0();
} /* Line: 70 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translateEmittedExceptionInner_0() {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_4_6_TextString bevl_libLens = null;
BEC_2_4_3_MathInt bevl_libLen = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
if (bevp_translated == null) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 78 */ {
if (bevp_translated.bevi_bool) /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
 else  /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 78 */ {
return this;
} /* Line: 79 */
bevp_translated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 82 */ {
if (bevp_lang == null) {
bevt_14_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
 else  /* Line: 82 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevt_16_tmpvar_phold = bevo_1;
bevt_15_tmpvar_phold = bevp_lang.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_18_tmpvar_phold = bevo_2;
bevt_17_tmpvar_phold = bevp_lang.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_12));
bevl_ltok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_19_tmpvar_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_21_tmpvar_phold = bevo_3;
bevt_20_tmpvar_phold = bevp_lang.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 88 */
bevt_0_tmpvar_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 90 */ {
bevt_22_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 90 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_23_tmpvar_phold = bevo_4;
bevl_start = bevl_line.bem_find_1(bevt_23_tmpvar_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_24_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 95 */ {
bevt_26_tmpvar_phold = bevo_5;
if (bevl_start.bevi_int >= bevt_26_tmpvar_phold.bevi_int) {
bevt_25_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 95 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 95 */ {
bevt_27_tmpvar_phold = bevo_6;
bevt_29_tmpvar_phold = bevo_7;
bevt_28_tmpvar_phold = bevl_start.bem_add_1(bevt_29_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_27_tmpvar_phold, bevt_28_tmpvar_phold);
if (bevl_end == null) {
bevt_30_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 98 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_31_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 98 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 98 */ {
bevt_33_tmpvar_phold = bevo_8;
bevt_32_tmpvar_phold = bevl_start.bem_add_1(bevt_33_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_32_tmpvar_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 102 */ {
bevt_34_tmpvar_phold = bevo_9;
bevl_start = bevl_line.bem_find_2(bevt_34_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_35_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_37_tmpvar_phold = bevo_10;
bevt_36_tmpvar_phold = bevl_start.bem_add_1(bevt_37_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevo_11;
bevt_38_tmpvar_phold = bevl_inPart.bem_ends_1(bevt_39_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 107 */ {
bevt_41_tmpvar_phold = bevl_inPart.bem_sizeGet_0();
bevt_42_tmpvar_phold = bevo_12;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_subtract_1(bevt_42_tmpvar_phold);
bevl_inPart.bem_sizeSet_1(bevt_40_tmpvar_phold);
} /* Line: 108 */
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_18));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_43_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_44_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_45_tmpvar_phold = bevo_13;
bevl_efile = bevl_inPart.bem_substring_2(bevt_45_tmpvar_phold, bevl_pdelim);
bevt_47_tmpvar_phold = bevo_14;
bevt_46_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_47_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_46_tmpvar_phold);
bevt_49_tmpvar_phold = bevo_15;
bevt_48_tmpvar_phold = bevl_iv.bem_begins_1(bevt_49_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_50_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_50_tmpvar_phold);
} /* Line: 117 */
bevt_51_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 121 */
} /* Line: 120 */
} /* Line: 112 */
} /* Line: 104 */
 else  /* Line: 125 */ {
bevt_52_tmpvar_phold = bevo_16;
bevl_start = bevl_line.bem_find_2(bevt_52_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_53_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevt_54_tmpvar_phold = bevo_17;
bevt_56_tmpvar_phold = bevo_18;
bevt_55_tmpvar_phold = bevl_start.bem_add_1(bevt_56_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
if (bevl_end == null) {
bevt_57_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_57_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevt_59_tmpvar_phold = bevo_19;
bevt_58_tmpvar_phold = bevl_start.bem_add_1(bevt_59_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_58_tmpvar_phold, bevl_end);
bevt_60_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_22));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_60_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_61_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_62_tmpvar_phold = bevo_20;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_62_tmpvar_phold, bevl_pdelim);
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_23));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_63_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_64_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_64_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 140 */ {
bevt_65_tmpvar_phold = bevo_21;
bevl_efile = bevl_inPart.bem_substring_2(bevt_65_tmpvar_phold, bevl_pdelim);
} /* Line: 141 */
bevt_67_tmpvar_phold = bevo_22;
bevt_66_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_67_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 146 */
} /* Line: 145 */
} /* Line: 136 */
} /* Line: 131 */
} /* Line: 127 */
} /* Line: 102 */
 else  /* Line: 152 */ {
bevt_69_tmpvar_phold = bevo_23;
bevt_71_tmpvar_phold = bevo_24;
bevt_70_tmpvar_phold = bevl_start.bem_add_1(bevt_71_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_69_tmpvar_phold, bevt_70_tmpvar_phold);
if (bevl_end == null) {
bevt_72_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 154 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_73_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 154 */ {
bevt_75_tmpvar_phold = bevo_25;
bevt_74_tmpvar_phold = bevl_start.bem_add_1(bevt_75_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_74_tmpvar_phold, bevl_end);
} /* Line: 155 */
 else  /* Line: 156 */ {
bevt_77_tmpvar_phold = bevo_26;
bevt_76_tmpvar_phold = bevl_start.bem_add_1(bevt_77_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_76_tmpvar_phold);
} /* Line: 157 */
} /* Line: 154 */
if (bevl_callPart == null) {
bevt_78_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 160 */ {
if (bevl_isCs.bevi_bool) /* Line: 161 */ {
bevt_79_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_25));
bevl_parts = bevl_callPart.bem_split_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_80_tmpvar_phold);
bevt_81_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_81_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_83_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_82_tmpvar_phold = this.bem_getSourceFileName_1(bevt_83_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_82_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 174 */
 else  /* Line: 175 */ {
bevt_84_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_26));
bevl_parts = bevl_callPart.bem_split_1(bevt_84_tmpvar_phold);
bevt_86_tmpvar_phold = bevl_parts.bem_sizeGet_0();
bevt_87_tmpvar_phold = bevo_27;
if (bevt_86_tmpvar_phold.bevi_int > bevt_87_tmpvar_phold.bevi_int) {
bevt_85_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_85_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 179 */ {
bevt_88_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_88_tmpvar_phold);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevt_89_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = bevo_28;
bevl_start = bevl_klass.bem_find_1(bevt_90_tmpvar_phold);
if (bevl_start == null) {
bevt_91_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_91_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevt_93_tmpvar_phold = bevo_29;
if (bevl_start.bevi_int > bevt_93_tmpvar_phold.bevi_int) {
bevt_92_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevt_8_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 185 */ {
bevt_8_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 185 */
 else  /* Line: 185 */ {
bevt_8_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 185 */ {
bevt_94_tmpvar_phold = bevo_30;
bevt_96_tmpvar_phold = bevo_31;
bevt_95_tmpvar_phold = bevl_start.bem_add_1(bevt_96_tmpvar_phold);
bevl_end = bevl_klass.bem_find_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
if (bevl_end == null) {
bevt_97_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_97_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 187 */ {
bevt_99_tmpvar_phold = bevo_32;
if (bevl_end.bevi_int > bevt_99_tmpvar_phold.bevi_int) {
bevt_98_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpvar_phold.bevi_bool) /* Line: 187 */ {
bevt_9_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 187 */ {
bevt_9_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 187 */
 else  /* Line: 187 */ {
bevt_9_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 187 */ {
bevt_101_tmpvar_phold = bevo_33;
bevt_100_tmpvar_phold = bevl_start.bem_add_1(bevt_101_tmpvar_phold);
bevl_libLens = bevl_klass.bem_substring_2(bevt_100_tmpvar_phold, bevl_end);
bevl_libLen = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_libLens);
bevt_104_tmpvar_phold = bevo_34;
bevt_103_tmpvar_phold = bevl_start.bem_add_1(bevt_104_tmpvar_phold);
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_add_1(bevl_libLen);
bevl_klass = bevl_klass.bem_substring_1(bevt_102_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_106_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_105_tmpvar_phold = this.bem_getSourceFileName_1(bevt_106_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_105_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 197 */
} /* Line: 187 */
} /* Line: 185 */
} /* Line: 179 */
} /* Line: 161 */
} /* Line: 160 */
} /* Line: 95 */
 else  /* Line: 90 */ {
break;
} /* Line: 90 */
} /* Line: 90 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_29));
bevp_framesText = null;
} /* Line: 207 */
 else  /* Line: 82 */ {
if (bevp_frames == null) {
bevt_107_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 208 */ {
if (bevp_lang == null) {
bevt_108_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_11_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_11_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 208 */
 else  /* Line: 208 */ {
bevt_11_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 208 */ {
bevt_110_tmpvar_phold = bevo_35;
bevt_109_tmpvar_phold = bevp_lang.bem_equals_1(bevt_110_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_10_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_10_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 208 */
 else  /* Line: 208 */ {
bevt_10_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 208 */ {
bevt_1_tmpvar_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 209 */ {
bevt_111_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_111_tmpvar_phold != null && bevt_111_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_111_tmpvar_phold).bevi_bool) /* Line: 209 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpvar_loop.bem_nextGet_0();
bevt_113_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_112_tmpvar_phold = this.bem_extractKlassLib_1(bevt_113_tmpvar_phold);
bevl_fr.bem_klassNameSet_1(bevt_112_tmpvar_phold);
bevt_115_tmpvar_phold = bevl_fr.bem_methodNameGet_0();
bevt_114_tmpvar_phold = this.bem_extractMethod_1(bevt_115_tmpvar_phold);
bevl_fr.bem_methodNameSet_1(bevt_114_tmpvar_phold);
bevt_117_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_116_tmpvar_phold = this.bem_getSourceFileName_1(bevt_117_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_116_tmpvar_phold);
} /* Line: 213 */
 else  /* Line: 209 */ {
break;
} /* Line: 209 */
} /* Line: 209 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_31));
} /* Line: 218 */
 else  /* Line: 219 */ {
} /* Line: 219 */
} /* Line: 82 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = this.bem_createInstance_2(beva_klassName, bevt_0_tmpvar_phold);
if (bevl_i == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_2_tmpvar_phold = bevl_i.bemd_0(478622533, BEL_4_Base.bevn_sourceFileNameGet_0);
return (BEC_2_4_6_TextString) bevt_2_tmpvar_phold;
} /* Line: 229 */
return null;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_32));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_2_tmpvar_phold = bevl_parts.bem_get_1(bevt_3_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
try  /* Line: 243 */ {
bevt_0_tmpvar_phold = this.bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpvar_phold;
} /* Line: 244 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 245 */
return beva_klass;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
if (beva_klass == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 252 */ {
bevt_4_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = beva_klass.bem_begins_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 252 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 252 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 252 */ {
return beva_klass;
} /* Line: 253 */
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_5_tmpvar_phold = beva_klass.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_34));
bevl_kparts = bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_37;
bevl_kps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 260 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevt_11_tmpvar_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpvar_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpvar_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_16_tmpvar_phold = bevo_38;
bevt_15_tmpvar_phold = bevl_i.bem_add_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_35));
bevl_bec.bem_addValue_1(bevt_17_tmpvar_phold);
} /* Line: 264 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 260 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
return bevl_bec;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
if (beva_mtd == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_4_tmpvar_phold = bevo_39;
bevt_3_tmpvar_phold = beva_mtd.bem_begins_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
return beva_mtd;
} /* Line: 273 */
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_mtd.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_37));
bevl_mparts = bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_40;
bevl_mps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_bem = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 278 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_11_tmpvar_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_41;
bevt_13_tmpvar_phold = bevl_i.bem_add_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_38));
bevl_bem.bem_addValue_1(bevt_15_tmpvar_phold);
} /* Line: 280 */
bevl_i.bevi_int++;
} /* Line: 278 */
 else  /* Line: 278 */ {
break;
} /* Line: 278 */
} /* Line: 278 */
return bevl_bem;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_framesGet_0() {
this.bem_translateEmittedException_0();
return bevp_frames;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFrameText_0() {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = this.bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_2_tmpvar_phold = bevo_42;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 299 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 299 */ {
bevl_ft = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 300 */
 else  /* Line: 299 */ {
break;
} /* Line: 299 */
} /* Line: 299 */
} /* Line: 299 */
return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassNameGet_0() {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_frames == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 312 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) {
BEC_2_9_5_ExceptionFrame bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
this.bem_addFrame_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_klassName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionGet_0() {
return bevp_description;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_description = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fileName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberGet_0() {
return bevp_lineNumber;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lineNumber = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_langGet_0() {
return bevp_lang;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_framesTextGet_0() {
return bevp_framesText;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_translatedGet_0() {
return bevp_translated;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {28, 32, 35, 36, 36, 37, 37, 37, 39, 39, 40, 40, 40, 42, 42, 43, 43, 43, 45, 45, 46, 46, 46, 48, 48, 49, 49, 49, 51, 51, 52, 52, 52, 54, 54, 55, 55, 55, 55, 57, 57, 58, 58, 58, 60, 60, 61, 61, 63, 68, 70, 70, 78, 78, 0, 0, 0, 79, 81, 82, 82, 82, 82, 0, 0, 0, 82, 82, 0, 82, 82, 0, 0, 0, 0, 0, 83, 83, 84, 85, 85, 86, 88, 90, 0, 90, 90, 92, 92, 93, 94, 95, 95, 95, 95, 95, 0, 0, 0, 97, 97, 97, 97, 98, 98, 98, 98, 0, 0, 0, 100, 100, 100, 103, 103, 104, 104, 106, 106, 106, 107, 107, 108, 108, 108, 108, 111, 111, 112, 112, 113, 113, 115, 115, 115, 116, 116, 117, 117, 120, 121, 126, 126, 127, 127, 130, 130, 130, 130, 131, 131, 133, 133, 133, 135, 135, 136, 136, 137, 137, 139, 139, 140, 140, 141, 141, 143, 143, 143, 145, 146, 153, 153, 153, 153, 154, 154, 154, 154, 0, 0, 0, 155, 155, 155, 157, 157, 157, 160, 160, 163, 163, 165, 165, 166, 166, 168, 170, 172, 173, 173, 173, 174, 178, 178, 179, 179, 179, 179, 180, 180, 181, 183, 183, 184, 184, 185, 185, 185, 185, 185, 0, 0, 0, 186, 186, 186, 186, 187, 187, 187, 187, 187, 0, 0, 0, 188, 188, 188, 190, 191, 191, 191, 191, 193, 195, 196, 196, 196, 197, 205, 206, 207, 208, 208, 208, 208, 0, 0, 0, 208, 208, 0, 0, 0, 209, 0, 209, 209, 210, 210, 210, 211, 211, 211, 212, 212, 212, 217, 218, 226, 226, 227, 227, 229, 229, 232, 237, 237, 239, 239, 239, 239, 244, 244, 248, 252, 252, 0, 252, 252, 252, 252, 0, 0, 253, 255, 255, 255, 255, 256, 256, 256, 257, 258, 259, 260, 260, 260, 261, 261, 263, 263, 263, 264, 264, 264, 264, 264, 264, 265, 260, 268, 272, 272, 0, 272, 272, 272, 272, 0, 0, 273, 275, 275, 275, 275, 276, 276, 276, 277, 278, 278, 278, 279, 279, 280, 280, 280, 280, 280, 280, 278, 283, 289, 290, 294, 295, 296, 297, 297, 298, 298, 299, 0, 299, 299, 300, 303, 307, 311, 311, 312, 314, 318, 318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {103, 135, 136, 137, 142, 143, 144, 145, 147, 152, 153, 154, 155, 157, 162, 163, 164, 165, 167, 172, 173, 174, 175, 177, 182, 183, 184, 185, 187, 192, 193, 194, 195, 197, 202, 203, 204, 205, 206, 208, 213, 214, 215, 216, 218, 223, 224, 225, 227, 233, 237, 238, 379, 384, 386, 389, 393, 396, 398, 399, 404, 405, 410, 411, 414, 418, 421, 422, 424, 427, 428, 430, 433, 437, 440, 444, 447, 448, 449, 450, 451, 453, 456, 458, 458, 461, 463, 464, 465, 466, 467, 468, 473, 474, 475, 480, 481, 484, 488, 491, 492, 493, 494, 495, 500, 501, 506, 507, 510, 514, 517, 518, 519, 521, 522, 523, 528, 529, 530, 531, 532, 533, 535, 536, 537, 538, 540, 541, 542, 547, 548, 549, 550, 551, 552, 553, 554, 556, 557, 559, 561, 567, 568, 569, 574, 575, 576, 577, 578, 579, 584, 585, 586, 587, 588, 589, 590, 595, 596, 597, 598, 599, 600, 605, 606, 607, 609, 610, 611, 612, 614, 622, 623, 624, 625, 626, 631, 632, 637, 638, 641, 645, 648, 649, 650, 653, 654, 655, 658, 663, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 680, 681, 682, 683, 684, 689, 690, 691, 692, 693, 694, 695, 696, 697, 702, 703, 704, 709, 710, 713, 717, 720, 721, 722, 723, 724, 729, 730, 731, 736, 737, 740, 744, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 772, 773, 774, 777, 782, 783, 788, 789, 792, 796, 799, 800, 802, 805, 809, 812, 812, 815, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 832, 833, 845, 846, 847, 852, 853, 854, 856, 864, 865, 866, 867, 868, 869, 875, 876, 881, 909, 914, 915, 918, 919, 920, 925, 926, 929, 933, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 948, 953, 954, 955, 956, 957, 958, 959, 960, 961, 966, 967, 968, 970, 971, 977, 1000, 1005, 1006, 1009, 1010, 1011, 1016, 1017, 1020, 1024, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1037, 1042, 1043, 1044, 1045, 1046, 1047, 1052, 1053, 1054, 1056, 1062, 1065, 1066, 1076, 1077, 1078, 1079, 1084, 1085, 1086, 1087, 1087, 1090, 1092, 1093, 1100, 1103, 1107, 1112, 1113, 1115, 1120, 1121, 1125, 1128, 1132, 1136, 1139, 1143, 1146, 1150, 1153, 1157, 1160, 1164, 1167, 1171, 1175, 1178, 1182, 1185};
/* BEGIN LINEINFO 
assign 1 28 103
translateEmittedException 0 32 135
assign 1 35 136
new 0 35 136
assign 1 36 137
def 1 36 142
assign 1 37 143
new 0 37 143
assign 1 37 144
add 1 37 144
assign 1 37 145
add 1 37 145
assign 1 39 147
def 1 39 152
assign 1 40 153
new 0 40 153
assign 1 40 154
add 1 40 154
assign 1 40 155
add 1 40 155
assign 1 42 157
def 1 42 162
assign 1 43 163
new 0 43 163
assign 1 43 164
add 1 43 164
assign 1 43 165
add 1 43 165
assign 1 45 167
def 1 45 172
assign 1 46 173
new 0 46 173
assign 1 46 174
add 1 46 174
assign 1 46 175
add 1 46 175
assign 1 48 177
def 1 48 182
assign 1 49 183
new 0 49 183
assign 1 49 184
add 1 49 184
assign 1 49 185
add 1 49 185
assign 1 51 187
def 1 51 192
assign 1 52 193
new 0 52 193
assign 1 52 194
add 1 52 194
assign 1 52 195
add 1 52 195
assign 1 54 197
def 1 54 202
assign 1 55 203
new 0 55 203
assign 1 55 204
add 1 55 204
assign 1 55 205
toString 0 55 205
assign 1 55 206
add 1 55 206
assign 1 57 208
def 1 57 213
assign 1 58 214
new 0 58 214
assign 1 58 215
add 1 58 215
assign 1 58 216
add 1 58 216
assign 1 60 218
def 1 60 223
assign 1 61 224
getFrameText 0 61 224
assign 1 61 225
add 1 61 225
return 1 63 227
translateEmittedExceptionInner 0 68 233
assign 1 70 237
new 0 70 237
print 0 70 238
assign 1 78 379
def 1 78 384
assign 1 0 386
assign 1 0 389
assign 1 0 393
return 1 79 396
assign 1 81 398
new 0 81 398
assign 1 82 399
def 1 82 404
assign 1 82 405
def 1 82 410
assign 1 0 411
assign 1 0 414
assign 1 0 418
assign 1 82 421
new 0 82 421
assign 1 82 422
equals 1 82 422
assign 1 0 424
assign 1 82 427
new 0 82 427
assign 1 82 428
equals 1 82 428
assign 1 0 430
assign 1 0 433
assign 1 0 437
assign 1 0 440
assign 1 0 444
assign 1 83 447
new 0 83 447
assign 1 83 448
new 1 83 448
assign 1 84 449
tokenize 1 84 449
assign 1 85 450
new 0 85 450
assign 1 85 451
equals 1 85 451
assign 1 86 453
new 0 86 453
assign 1 88 456
new 0 88 456
assign 1 90 458
linkedListIteratorGet 0 0 458
assign 1 90 461
hasNextGet 0 90 461
assign 1 90 463
nextGet 0 90 463
assign 1 92 464
new 0 92 464
assign 1 92 465
find 1 92 465
assign 1 93 466
assign 1 94 467
assign 1 95 468
def 1 95 473
assign 1 95 474
new 0 95 474
assign 1 95 475
greaterEquals 1 95 480
assign 1 0 481
assign 1 0 484
assign 1 0 488
assign 1 97 491
new 0 97 491
assign 1 97 492
new 0 97 492
assign 1 97 493
add 1 97 493
assign 1 97 494
find 2 97 494
assign 1 98 495
def 1 98 500
assign 1 98 501
greater 1 98 506
assign 1 0 507
assign 1 0 510
assign 1 0 514
assign 1 100 517
new 0 100 517
assign 1 100 518
add 1 100 518
assign 1 100 519
substring 2 100 519
assign 1 103 521
new 0 103 521
assign 1 103 522
find 2 103 522
assign 1 104 523
def 1 104 528
assign 1 106 529
new 0 106 529
assign 1 106 530
add 1 106 530
assign 1 106 531
substring 1 106 531
assign 1 107 532
new 0 107 532
assign 1 107 533
ends 1 107 533
assign 1 108 535
sizeGet 0 108 535
assign 1 108 536
new 0 108 536
assign 1 108 537
subtract 1 108 537
sizeSet 1 108 538
assign 1 111 540
new 0 111 540
assign 1 111 541
rfind 1 111 541
assign 1 112 542
def 1 112 547
assign 1 113 548
new 0 113 548
assign 1 113 549
substring 2 113 549
assign 1 115 550
new 0 115 550
assign 1 115 551
add 1 115 551
assign 1 115 552
substring 1 115 552
assign 1 116 553
new 0 116 553
assign 1 116 554
begins 1 116 554
assign 1 117 556
new 0 117 556
assign 1 117 557
substring 1 117 557
assign 1 120 559
isInteger 0 120 559
assign 1 121 561
new 1 121 561
assign 1 126 567
new 0 126 567
assign 1 126 568
find 2 126 568
assign 1 127 569
def 1 127 574
assign 1 130 575
new 0 130 575
assign 1 130 576
new 0 130 576
assign 1 130 577
add 1 130 577
assign 1 130 578
find 2 130 578
assign 1 131 579
def 1 131 584
assign 1 133 585
new 0 133 585
assign 1 133 586
add 1 133 586
assign 1 133 587
substring 2 133 587
assign 1 135 588
new 0 135 588
assign 1 135 589
rfind 1 135 589
assign 1 136 590
def 1 136 595
assign 1 137 596
new 0 137 596
assign 1 137 597
substring 2 137 597
assign 1 139 598
new 0 139 598
assign 1 139 599
rfind 1 139 599
assign 1 140 600
def 1 140 605
assign 1 141 606
new 0 141 606
assign 1 141 607
substring 2 141 607
assign 1 143 609
new 0 143 609
assign 1 143 610
add 1 143 610
assign 1 143 611
substring 1 143 611
assign 1 145 612
isInteger 0 145 612
assign 1 146 614
new 1 146 614
assign 1 153 622
new 0 153 622
assign 1 153 623
new 0 153 623
assign 1 153 624
add 1 153 624
assign 1 153 625
find 2 153 625
assign 1 154 626
def 1 154 631
assign 1 154 632
greater 1 154 637
assign 1 0 638
assign 1 0 641
assign 1 0 645
assign 1 155 648
new 0 155 648
assign 1 155 649
add 1 155 649
assign 1 155 650
substring 2 155 650
assign 1 157 653
new 0 157 653
assign 1 157 654
add 1 157 654
assign 1 157 655
substring 1 157 655
assign 1 160 658
def 1 160 663
assign 1 163 665
new 0 163 665
assign 1 163 666
split 1 163 666
assign 1 165 667
new 0 165 667
assign 1 165 668
get 1 165 668
assign 1 166 669
new 0 166 669
assign 1 166 670
get 1 166 670
assign 1 168 671
extractKlass 1 168 671
assign 1 170 672
extractMethod 1 170 672
assign 1 172 673
new 4 172 673
assign 1 173 674
klassNameGet 0 173 674
assign 1 173 675
getSourceFileName 1 173 675
fileNameSet 1 173 676
addFrame 1 174 677
assign 1 178 680
new 0 178 680
assign 1 178 681
split 1 178 681
assign 1 179 682
sizeGet 0 179 682
assign 1 179 683
new 0 179 683
assign 1 179 684
greater 1 179 689
assign 1 180 690
new 0 180 690
assign 1 180 691
get 1 180 691
assign 1 181 692
extractMethod 1 181 692
assign 1 183 693
new 0 183 693
assign 1 183 694
get 1 183 694
assign 1 184 695
new 0 184 695
assign 1 184 696
find 1 184 696
assign 1 185 697
def 1 185 702
assign 1 185 703
new 0 185 703
assign 1 185 704
greater 1 185 709
assign 1 0 710
assign 1 0 713
assign 1 0 717
assign 1 186 720
new 0 186 720
assign 1 186 721
new 0 186 721
assign 1 186 722
add 1 186 722
assign 1 186 723
find 2 186 723
assign 1 187 724
def 1 187 729
assign 1 187 730
new 0 187 730
assign 1 187 731
greater 1 187 736
assign 1 0 737
assign 1 0 740
assign 1 0 744
assign 1 188 747
new 0 188 747
assign 1 188 748
add 1 188 748
assign 1 188 749
substring 2 188 749
assign 1 190 750
new 1 190 750
assign 1 191 751
new 0 191 751
assign 1 191 752
add 1 191 752
assign 1 191 753
add 1 191 753
assign 1 191 754
substring 1 191 754
assign 1 193 755
extractKlass 1 193 755
assign 1 195 756
new 4 195 756
assign 1 196 757
klassNameGet 0 196 757
assign 1 196 758
getSourceFileName 1 196 758
fileNameSet 1 196 759
addFrame 1 197 760
assign 1 205 772
assign 1 206 773
new 0 206 773
assign 1 207 774
assign 1 208 777
def 1 208 782
assign 1 208 783
def 1 208 788
assign 1 0 789
assign 1 0 792
assign 1 0 796
assign 1 208 799
new 0 208 799
assign 1 208 800
equals 1 208 800
assign 1 0 802
assign 1 0 805
assign 1 0 809
assign 1 209 812
linkedListIteratorGet 0 0 812
assign 1 209 815
hasNextGet 0 209 815
assign 1 209 817
nextGet 0 209 817
assign 1 210 818
klassNameGet 0 210 818
assign 1 210 819
extractKlassLib 1 210 819
klassNameSet 1 210 820
assign 1 211 821
methodNameGet 0 211 821
assign 1 211 822
extractMethod 1 211 822
methodNameSet 1 211 823
assign 1 212 824
klassNameGet 0 212 824
assign 1 212 825
getSourceFileName 1 212 825
fileNameSet 1 212 826
assign 1 217 832
assign 1 218 833
new 0 218 833
assign 1 226 845
new 0 226 845
assign 1 226 846
createInstance 2 226 846
assign 1 227 847
def 1 227 852
assign 1 229 853
sourceFileNameGet 0 229 853
return 1 229 854
return 1 232 856
assign 1 237 864
new 0 237 864
assign 1 237 865
split 1 237 865
assign 1 239 866
new 0 239 866
assign 1 239 867
get 1 239 867
assign 1 239 868
extractKlass 1 239 868
return 1 239 869
assign 1 244 875
extractKlassInner 1 244 875
return 1 244 876
return 1 248 881
assign 1 252 909
undef 1 252 914
assign 1 0 915
assign 1 252 918
new 0 252 918
assign 1 252 919
begins 1 252 919
assign 1 252 920
not 0 252 925
assign 1 0 926
assign 1 0 929
return 1 253 933
assign 1 255 935
new 0 255 935
assign 1 255 936
substring 1 255 936
assign 1 255 937
new 0 255 937
assign 1 255 938
split 1 255 938
assign 1 256 939
sizeGet 0 256 939
assign 1 256 940
new 0 256 940
assign 1 256 941
subtract 1 256 941
assign 1 257 942
get 1 257 942
assign 1 258 943
new 0 258 943
assign 1 259 944
new 0 259 944
assign 1 260 945
new 0 260 945
assign 1 260 948
lesser 1 260 953
assign 1 261 954
get 1 261 954
assign 1 261 955
new 1 261 955
assign 1 263 956
add 1 263 956
assign 1 263 957
substring 2 263 957
addValue 1 263 958
assign 1 264 959
new 0 264 959
assign 1 264 960
add 1 264 960
assign 1 264 961
lesser 1 264 966
assign 1 264 967
new 0 264 967
addValue 1 264 968
addValue 1 265 970
incrementValue 0 260 971
return 1 268 977
assign 1 272 1000
undef 1 272 1005
assign 1 0 1006
assign 1 272 1009
new 0 272 1009
assign 1 272 1010
begins 1 272 1010
assign 1 272 1011
not 0 272 1016
assign 1 0 1017
assign 1 0 1020
return 1 273 1024
assign 1 275 1026
new 0 275 1026
assign 1 275 1027
substring 1 275 1027
assign 1 275 1028
new 0 275 1028
assign 1 275 1029
split 1 275 1029
assign 1 276 1030
sizeGet 0 276 1030
assign 1 276 1031
new 0 276 1031
assign 1 276 1032
subtract 1 276 1032
assign 1 277 1033
new 0 277 1033
assign 1 278 1034
new 0 278 1034
assign 1 278 1037
lesser 1 278 1042
assign 1 279 1043
get 1 279 1043
addValue 1 279 1044
assign 1 280 1045
new 0 280 1045
assign 1 280 1046
add 1 280 1046
assign 1 280 1047
lesser 1 280 1052
assign 1 280 1053
new 0 280 1053
addValue 1 280 1054
incrementValue 0 278 1056
return 1 283 1062
translateEmittedException 0 289 1065
return 1 290 1066
translateEmittedException 0 294 1076
assign 1 295 1077
new 0 295 1077
assign 1 296 1078
framesGet 0 296 1078
assign 1 297 1079
def 1 297 1084
assign 1 298 1085
new 0 298 1085
assign 1 298 1086
add 1 298 1086
assign 1 299 1087
linkedListIteratorGet 0 0 1087
assign 1 299 1090
hasNextGet 0 299 1090
assign 1 299 1092
nextGet 0 299 1092
assign 1 300 1093
add 1 300 1093
return 1 303 1100
return 1 307 1103
assign 1 311 1107
undef 1 311 1112
assign 1 312 1113
new 0 312 1113
addValue 1 314 1115
assign 1 318 1120
new 4 318 1120
addFrame 1 318 1121
return 1 0 1125
assign 1 0 1128
assign 1 0 1132
return 1 0 1136
assign 1 0 1139
return 1 0 1143
assign 1 0 1146
return 1 0 1150
assign 1 0 1153
return 1 0 1157
assign 1 0 1160
return 1 0 1164
assign 1 0 1167
assign 1 0 1171
return 1 0 1175
assign 1 0 1178
return 1 0 1182
assign 1 0 1185
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case 734830721: return bem_framesGet_0();
case 1475977273: return bem_langGet_0();
case -1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case -1184167343: return bem_translatedGet_0();
case -764669899: return bem_getFrameText_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 484558571: return bem_descriptionGet_0();
case -1611190486: return bem_lineNumberGet_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 154290862: return bem_translateEmittedException_0();
case -1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 970476426: return bem_translateEmittedExceptionInner_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case -845792839: return bem_iteratorGet_0();
case -1141730732: return bem_framesTextGet_0();
case -314718434: return bem_print_0();
case -220901978: return bem_emitLangGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1286797640: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2124977673: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case -813541388: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1173085090: return bem_translatedSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -205231606: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -371136143: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1130648479: return bem_framesTextSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_9_SystemException();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_9_SystemException.bevs_inst = (BEC_2_6_9_SystemException)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_9_SystemException.bevs_inst;
}
}
}
