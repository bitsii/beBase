namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator : BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
static BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3C};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x3C};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_2, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x3C};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3E};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_4, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3E};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_5, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_7, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x3E};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3E};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_9, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_10, 2));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x3C};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_11, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_13, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_14 = {0x3F};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_14, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_15 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_16 = {0x21};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_16, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_17 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_18 = {0x2F};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_18, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_19 = {0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_19, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_20 = {0x3E};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_20, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_21 = {0x2F};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_21, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_22 = {0x3E};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_22, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_23 = {0x2F};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_23, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_24 = {0x20};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_24, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_25 = {0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_25, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_26 = {0x3E};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_26, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_27 = {0x2F};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_27, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_28 = {0x3D};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_28, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_29 = {0x3E};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_29, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_30 = {0x2F};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_30, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_31 = {0x20};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_31, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_32 = {0x3D};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_32, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_33 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_33, 51));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_34 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_34, 51));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_35 = {0x20};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_35, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_36 = {0x3C};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_36, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_37 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_38 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_38, 35));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_39 = {0x3A};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_39, 1));
public static new BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_started = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_debug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) {
this.bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_restart_0() {
this.bem_new_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_start_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 168 */ {
if (bevl_nxt == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_5_tmpany_phold = bevo_0;
bevt_4_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 168 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 169 */
 else  /* Line: 168 */ {
break;
} /* Line: 168 */
} /* Line: 168 */
if (bevl_nxt == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_8_tmpany_phold = bevo_1;
bevt_7_tmpany_phold = bevl_nxt.bem_equals_1(bevt_8_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
 else  /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 171 */ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 172 */
return this;
} /*method end*/
public virtual BEC_2_3_3_XmlTag bem_nextGet_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_3_8_XmlTextNode bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_3_7_XmlComment bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_116_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_tmpany_phold = null;
BEC_2_4_6_TextString bevt_134_tmpany_phold = null;
BEC_2_4_6_TextString bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
if (bevp_started.bevi_bool) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 177 */ {
this.bem_start_0();
} /* Line: 178 */
bevt_21_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_tmpany_phold.bem_quoteGet_0();
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_tmpany_phold.bem_newlineGet_0();
if (bevp_skip.bevi_bool) /* Line: 183 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1446310798, BEL_4_Base.bevn_currentGet_0);
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 185 */
 else  /* Line: 186 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 187 */
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 190 */ {
if (bevp_textNode.bevi_bool) /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 190 */
 else  /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 190 */ {
while (true)
 /* Line: 191 */ {
bevt_25_tmpany_phold = bevo_2;
bevt_24_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_25_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 193 */
 else  /* Line: 191 */ {
break;
} /* Line: 191 */
} /* Line: 191 */
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_27_tmpany_phold = bevl_accum.bem_extractString_0();
bevt_26_tmpany_phold = (BEC_2_3_8_XmlTextNode) (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_tmpany_phold);
return bevt_26_tmpany_phold;
} /* Line: 197 */
 else  /* Line: 190 */ {
if (bevl_nxt == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_30_tmpany_phold = bevo_3;
bevt_29_tmpany_phold = bevl_nxt.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevl_tagName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 206 */ {
bevt_32_tmpany_phold = bevo_4;
bevt_31_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_32_tmpany_phold);
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 206 */ {
if (bevl_pinstruct.bevi_bool) /* Line: 207 */ {
bevl_instr = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 209 */ {
if (bevl_instr.bevi_bool) /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 209 */ {
bevt_34_tmpany_phold = bevo_5;
bevt_33_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_34_tmpany_phold);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 209 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 209 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_tmpany_phold = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 211 */ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 212 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 214 */
 else  /* Line: 209 */ {
break;
} /* Line: 209 */
} /* Line: 209 */
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_6));
bevl_accum.bem_addValue_1(bevt_36_tmpany_phold);
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 218 */ {
if (bevl_nxt == null) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_39_tmpany_phold = bevo_6;
bevt_38_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_39_tmpany_phold);
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
 else  /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 218 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 219 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_41_tmpany_phold = bevl_accum.bem_toString_0();
bevt_40_tmpany_phold = (BEC_2_3_21_XmlProcessingInstruction) (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_tmpany_phold);
return bevt_40_tmpany_phold;
} /* Line: 222 */
if (bevl_comment.bevi_bool) /* Line: 224 */ {
while (true)
 /* Line: 225 */ {
bevt_43_tmpany_phold = bevo_7;
bevt_42_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_43_tmpany_phold);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_45_tmpany_phold = bevo_8;
bevt_44_tmpany_phold = bevl_nxt.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_48_tmpany_phold = bevl_accum.bem_toString_0();
bevt_49_tmpany_phold = bevo_9;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_ends_1(bevt_49_tmpany_phold);
if (bevt_47_tmpany_phold.bevi_bool) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 228 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 230 */
} /* Line: 228 */
 else  /* Line: 225 */ {
break;
} /* Line: 225 */
} /* Line: 225 */
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 234 */ {
if (bevl_nxt == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_52_tmpany_phold = bevo_10;
bevt_51_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_52_tmpany_phold);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 234 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 235 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_12));
bevl_accum.bem_addValue_1(bevt_53_tmpany_phold);
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_55_tmpany_phold = bevl_accum.bem_extractString_0();
bevt_54_tmpany_phold = (BEC_2_3_7_XmlComment) (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_tmpany_phold);
return bevt_54_tmpany_phold;
} /* Line: 239 */
if (bevl_tagName.bevi_bool) /* Line: 241 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 243 */ {
bevt_57_tmpany_phold = bevo_11;
bevt_56_tmpany_phold = bevl_nxt.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_58_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevt_59_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 244 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 244 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 245 */
 else  /* Line: 243 */ {
break;
} /* Line: 243 */
} /* Line: 243 */
bevt_61_tmpany_phold = bevo_12;
bevt_60_tmpany_phold = bevl_nxt.bem_equals_1(bevt_61_tmpany_phold);
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_accum.bem_extractString_0();
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_15));
bevl_accum.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 252 */
 else  /* Line: 247 */ {
bevt_64_tmpany_phold = bevo_13;
bevt_63_tmpany_phold = bevl_nxt.bem_equals_1(bevt_64_tmpany_phold);
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_accum.bem_extractString_0();
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_17));
bevl_accum.bem_addValue_1(bevt_65_tmpany_phold);
} /* Line: 258 */
 else  /* Line: 259 */ {
bevt_67_tmpany_phold = bevo_14;
bevt_66_tmpany_phold = bevl_nxt.bem_equals_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 262 */
while (true)
 /* Line: 264 */ {
bevt_69_tmpany_phold = bevo_15;
bevt_68_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_69_tmpany_phold);
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_70_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevt_72_tmpany_phold = bevo_16;
bevt_71_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevt_74_tmpany_phold = bevo_17;
bevt_73_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_74_tmpany_phold);
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 266 */
 else  /* Line: 264 */ {
break;
} /* Line: 264 */
} /* Line: 264 */
bevt_75_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 268 */
bevl_tagName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 270 */ {
bevl_myElement = (BEC_2_3_12_XmlStartElement) (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_tmpany_phold);
} /* Line: 273 */
 else  /* Line: 274 */ {
bevl_myEndElement = (BEC_2_3_10_XmlEndElement) (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_tmpany_phold);
bevl_myTag = bevl_myEndElement;
} /* Line: 277 */
bevt_79_tmpany_phold = bevo_18;
bevt_78_tmpany_phold = bevl_nxt.bem_equals_1(bevt_79_tmpany_phold);
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 279 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 281 */ {
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 282 */
} /* Line: 281 */
 else  /* Line: 279 */ {
bevt_81_tmpany_phold = bevo_19;
bevt_80_tmpany_phold = bevl_nxt.bem_equals_1(bevt_81_tmpany_phold);
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 284 */ {
if (bevl_isStart.bevi_bool) /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_82_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_tmpany_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 287 */
 else  /* Line: 279 */ {
if (bevl_isStart.bevi_bool) /* Line: 288 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 289 */
 else  /* Line: 290 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 291 */
} /* Line: 279 */
} /* Line: 279 */
} /* Line: 279 */
} /* Line: 247 */
} /* Line: 247 */
if (bevl_attributeName.bevi_bool) /* Line: 295 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 297 */ {
bevt_84_tmpany_phold = bevo_20;
bevt_83_tmpany_phold = bevl_nxt.bem_equals_1(bevt_84_tmpany_phold);
if (bevt_83_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_85_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 297 */ {
bevt_86_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 298 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 299 */
 else  /* Line: 297 */ {
break;
} /* Line: 297 */
} /* Line: 297 */
while (true)
 /* Line: 301 */ {
bevt_88_tmpany_phold = bevo_21;
bevt_87_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_88_tmpany_phold);
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_89_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_91_tmpany_phold = bevo_22;
bevt_90_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_91_tmpany_phold);
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_93_tmpany_phold = bevo_23;
bevt_92_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_93_tmpany_phold);
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_95_tmpany_phold = bevo_24;
bevt_94_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_95_tmpany_phold);
if (bevt_94_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 303 */
 else  /* Line: 301 */ {
break;
} /* Line: 301 */
} /* Line: 301 */
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_96_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 306 */
bevt_98_tmpany_phold = bevo_25;
bevt_97_tmpany_phold = bevl_nxt.bem_equals_1(bevt_98_tmpany_phold);
if (bevt_97_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 309 */
 else  /* Line: 307 */ {
bevt_100_tmpany_phold = bevo_26;
bevt_99_tmpany_phold = bevl_nxt.bem_equals_1(bevt_100_tmpany_phold);
if (bevt_99_tmpany_phold.bevi_bool) /* Line: 310 */ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_101_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_tmpany_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 313 */
 else  /* Line: 314 */ {
bevt_102_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_tmpany_phold);
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 316 */
} /* Line: 307 */
} /* Line: 307 */
if (bevl_attributeValue.bevi_bool) /* Line: 319 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 321 */ {
bevt_104_tmpany_phold = bevo_27;
bevt_103_tmpany_phold = bevl_nxt.bem_equals_1(bevt_104_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_105_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 321 */
if (bevt_16_tmpany_anchor.bevi_bool) /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_107_tmpany_phold = bevo_28;
bevt_106_tmpany_phold = bevl_nxt.bem_equals_1(bevt_107_tmpany_phold);
if (bevt_106_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 321 */
if (bevt_15_tmpany_anchor.bevi_bool) /* Line: 321 */ {
bevt_108_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 323 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 324 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
bevt_109_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 326 */ {
bevt_112_tmpany_phold = bevo_29;
bevt_113_tmpany_phold = bevp_line.bem_toString_0();
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_113_tmpany_phold);
bevt_110_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_110_tmpany_phold);
} /* Line: 327 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 330 */ {
bevt_114_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_115_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 331 */
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 333 */
 else  /* Line: 330 */ {
break;
} /* Line: 330 */
} /* Line: 330 */
bevt_116_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_tmpany_phold.bevi_bool) /* Line: 335 */ {
bevt_119_tmpany_phold = bevo_30;
bevt_120_tmpany_phold = bevp_line.bem_toString_0();
bevt_118_tmpany_phold = bevt_119_tmpany_phold.bem_add_1(bevt_120_tmpany_phold);
bevt_117_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 336 */
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_121_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_tmpany_phold);
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 340 */
} /* Line: 319 */
 else  /* Line: 206 */ {
break;
} /* Line: 206 */
} /* Line: 206 */
if (bevl_myEndElement == null) {
bevt_122_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_122_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
if (bevl_myElement == null) {
bevt_123_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_124_tmpany_phold = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 343 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 343 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 343 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
while (true)
 /* Line: 345 */ {
if (bevl_nxt == null) {
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_125_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_127_tmpany_phold = bevo_31;
bevt_126_tmpany_phold = bevl_nxt.bem_equals_1(bevt_127_tmpany_phold);
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_128_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 345 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 345 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 345 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 345 */
 else  /* Line: 345 */ {
break;
} /* Line: 345 */
} /* Line: 345 */
if (bevl_nxt == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_131_tmpany_phold = bevo_32;
bevt_130_tmpany_phold = bevl_nxt.bem_equals_1(bevt_131_tmpany_phold);
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 346 */
 else  /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_19_tmpany_anchor.bevi_bool) /* Line: 346 */ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 346 */
} /* Line: 346 */
} /* Line: 343 */
 else  /* Line: 348 */ {
if (bevl_nxt == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevl_nxt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_37));
} /* Line: 349 */
bevt_136_tmpany_phold = bevo_33;
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bem_add_1(bevl_nxt);
bevt_137_tmpany_phold = bevo_34;
bevt_134_tmpany_phold = bevt_135_tmpany_phold.bem_add_1(bevt_137_tmpany_phold);
bevt_133_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_133_tmpany_phold);
} /* Line: 350 */
} /* Line: 199 */
} /* Line: 190 */
return bevl_myTag;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_started.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 357 */
bevt_2_tmpany_phold = bevp_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
return (BEC_2_5_4_LogicBool) bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_xmlStringGet_0() {
return bevp_xmlString;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_startedGet_0() {
return bevp_started;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_3_10_XmlXTokenizer bem_xtGet_0() {
return bevp_xt;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_resGet_0() {
return bevp_res;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iterGet_0() {
return bevp_iter;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_textNodeGet_0() {
return bevp_textNode;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lineGet_0() {
return bevp_line;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_skipGet_0() {
return bevp_skip;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {138, 139, 140, 141, 142, 143, 144, 145, 150, 151, 155, 159, 163, 163, 164, 165, 167, 168, 168, 168, 168, 0, 0, 0, 169, 171, 171, 171, 171, 0, 0, 0, 172, 177, 177, 178, 181, 181, 182, 182, 184, 185, 187, 189, 190, 190, 0, 0, 0, 191, 191, 192, 193, 195, 196, 197, 197, 197, 198, 198, 199, 199, 200, 201, 202, 203, 204, 205, 206, 206, 208, 0, 209, 209, 0, 0, 210, 211, 212, 212, 214, 216, 216, 217, 218, 218, 218, 218, 0, 0, 0, 219, 221, 222, 222, 222, 225, 225, 226, 227, 228, 228, 228, 228, 228, 228, 228, 0, 0, 0, 229, 230, 233, 234, 234, 234, 234, 0, 0, 0, 235, 237, 237, 238, 239, 239, 239, 242, 243, 243, 0, 243, 0, 0, 244, 244, 245, 247, 247, 248, 249, 250, 251, 252, 252, 253, 253, 254, 255, 256, 257, 258, 258, 260, 260, 261, 262, 264, 264, 264, 0, 0, 0, 264, 264, 0, 0, 0, 264, 264, 0, 0, 0, 265, 266, 268, 268, 269, 271, 272, 273, 273, 275, 276, 276, 277, 279, 279, 280, 282, 284, 284, 0, 0, 0, 285, 286, 286, 287, 289, 291, 296, 297, 297, 0, 297, 0, 0, 298, 298, 299, 301, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 302, 303, 305, 306, 306, 307, 307, 308, 309, 310, 310, 311, 312, 312, 313, 315, 315, 316, 320, 321, 321, 0, 321, 0, 0, 0, 321, 321, 0, 0, 323, 323, 324, 326, 327, 327, 327, 327, 327, 329, 330, 331, 331, 332, 333, 335, 336, 336, 336, 336, 336, 338, 339, 339, 340, 343, 343, 0, 343, 343, 343, 0, 0, 0, 0, 0, 344, 345, 345, 345, 345, 0, 345, 0, 0, 0, 0, 0, 345, 346, 346, 346, 346, 0, 0, 0, 346, 349, 349, 349, 350, 350, 350, 350, 350, 350, 353, 357, 357, 357, 357, 358, 358, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {94, 95, 96, 97, 98, 99, 100, 101, 105, 106, 110, 114, 127, 128, 129, 130, 131, 134, 139, 140, 141, 143, 146, 150, 153, 159, 164, 165, 166, 168, 171, 175, 178, 335, 340, 341, 343, 344, 345, 346, 348, 349, 352, 354, 355, 360, 362, 365, 369, 374, 375, 377, 378, 384, 385, 386, 387, 388, 391, 396, 397, 398, 400, 401, 402, 403, 404, 405, 408, 409, 412, 416, 419, 420, 422, 425, 429, 430, 432, 437, 438, 444, 445, 446, 449, 454, 455, 456, 458, 461, 465, 468, 474, 475, 476, 477, 482, 483, 485, 486, 487, 488, 490, 491, 492, 493, 498, 499, 502, 506, 509, 510, 517, 520, 525, 526, 527, 529, 532, 536, 539, 545, 546, 547, 548, 549, 550, 553, 556, 557, 559, 562, 564, 567, 571, 573, 575, 581, 582, 584, 585, 586, 587, 588, 589, 592, 593, 595, 596, 597, 598, 599, 600, 603, 604, 606, 607, 611, 612, 614, 616, 619, 623, 626, 627, 629, 632, 636, 639, 640, 642, 645, 649, 652, 653, 659, 661, 663, 665, 666, 667, 668, 671, 672, 673, 674, 676, 677, 679, 681, 685, 686, 689, 692, 696, 699, 700, 701, 702, 706, 709, 717, 720, 721, 723, 726, 728, 731, 735, 737, 739, 747, 748, 750, 752, 755, 759, 762, 763, 765, 768, 772, 775, 776, 778, 781, 785, 788, 789, 791, 794, 798, 801, 802, 808, 809, 811, 813, 814, 816, 817, 820, 821, 823, 824, 825, 826, 829, 830, 831, 836, 839, 840, 842, 845, 847, 850, 854, 857, 858, 860, 863, 867, 869, 871, 877, 879, 880, 881, 882, 883, 885, 888, 890, 892, 894, 895, 901, 903, 904, 905, 906, 907, 909, 910, 911, 912, 919, 924, 925, 928, 933, 934, 936, 939, 943, 946, 949, 953, 956, 961, 962, 963, 965, 968, 970, 973, 977, 980, 984, 987, 993, 998, 999, 1000, 1002, 1005, 1009, 1012, 1017, 1022, 1023, 1025, 1026, 1027, 1028, 1029, 1030, 1034, 1040, 1045, 1046, 1047, 1049, 1050, 1053, 1056, 1060, 1063, 1067, 1070, 1074, 1077, 1081, 1084, 1088, 1091, 1095, 1098, 1102, 1105, 1109, 1112};
/* BEGIN LINEINFO 
assign 1 138 94
new 0 138 94
assign 1 139 95
new 0 139 95
assign 1 140 96
assign 1 141 97
assign 1 142 98
new 0 142 98
assign 1 143 99
new 0 143 99
assign 1 144 100
new 0 144 100
assign 1 145 101
new 0 145 101
new 0 150 105
assign 1 151 106
new 0 155 110
return 1 159 114
assign 1 163 127
tokGet 0 163 127
assign 1 163 128
tokenize 1 163 128
assign 1 164 129
iteratorGet 0 164 129
assign 1 165 130
new 0 165 130
assign 1 167 131
nextGet 0 167 131
assign 1 168 134
def 1 168 139
assign 1 168 140
new 0 168 140
assign 1 168 141
notEquals 1 168 141
assign 1 0 143
assign 1 0 146
assign 1 0 150
assign 1 169 153
nextGet 0 169 153
assign 1 171 159
def 1 171 164
assign 1 171 165
new 0 171 165
assign 1 171 166
equals 1 171 166
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 172 178
new 0 172 178
assign 1 177 335
not 0 177 340
start 0 178 341
assign 1 181 343
new 0 181 343
assign 1 181 344
quoteGet 0 181 344
assign 1 182 345
new 0 182 345
assign 1 182 346
newlineGet 0 182 346
assign 1 184 348
currentGet 0 184 348
assign 1 185 349
new 0 185 349
assign 1 187 352
nextGet 0 187 352
assign 1 189 354
new 0 189 354
assign 1 190 355
def 1 190 360
assign 1 0 362
assign 1 0 365
assign 1 0 369
assign 1 191 374
new 0 191 374
assign 1 191 375
notEquals 1 191 375
addValue 1 192 377
assign 1 193 378
nextGet 0 193 378
assign 1 195 384
new 0 195 384
assign 1 196 385
new 0 196 385
assign 1 197 386
extractString 0 197 386
assign 1 197 387
new 1 197 387
return 1 197 388
assign 1 198 391
def 1 198 396
assign 1 199 397
new 0 199 397
assign 1 199 398
equals 1 199 398
assign 1 200 400
new 0 200 400
assign 1 201 401
new 0 201 401
assign 1 202 402
new 0 202 402
assign 1 203 403
new 0 203 403
assign 1 204 404
new 0 204 404
assign 1 205 405
new 0 205 405
assign 1 206 408
new 0 206 408
assign 1 206 409
notEquals 1 206 409
assign 1 208 412
new 0 208 412
assign 1 0 416
assign 1 209 419
new 0 209 419
assign 1 209 420
notEquals 1 209 420
assign 1 0 422
assign 1 0 425
addValue 1 210 429
assign 1 211 430
equals 1 211 430
assign 1 212 432
not 0 212 437
assign 1 214 438
nextGet 0 214 438
assign 1 216 444
new 0 216 444
addValue 1 216 445
assign 1 217 446
new 0 217 446
assign 1 218 449
def 1 218 454
assign 1 218 455
new 0 218 455
assign 1 218 456
notEquals 1 218 456
assign 1 0 458
assign 1 0 461
assign 1 0 465
assign 1 219 468
nextGet 0 219 468
assign 1 221 474
new 0 221 474
assign 1 222 475
toString 0 222 475
assign 1 222 476
new 1 222 476
return 1 222 477
assign 1 225 482
new 0 225 482
assign 1 225 483
notEquals 1 225 483
addValue 1 226 485
assign 1 227 486
nextGet 0 227 486
assign 1 228 487
new 0 228 487
assign 1 228 488
equals 1 228 488
assign 1 228 490
toString 0 228 490
assign 1 228 491
new 0 228 491
assign 1 228 492
ends 1 228 492
assign 1 228 493
not 0 228 498
assign 1 0 499
assign 1 0 502
assign 1 0 506
addValue 1 229 509
assign 1 230 510
nextGet 0 230 510
assign 1 233 517
new 0 233 517
assign 1 234 520
def 1 234 525
assign 1 234 526
new 0 234 526
assign 1 234 527
notEquals 1 234 527
assign 1 0 529
assign 1 0 532
assign 1 0 536
assign 1 235 539
nextGet 0 235 539
assign 1 237 545
new 0 237 545
addValue 1 237 546
assign 1 238 547
new 0 238 547
assign 1 239 548
extractString 0 239 548
assign 1 239 549
new 1 239 549
return 1 239 550
assign 1 242 553
nextGet 0 242 553
assign 1 243 556
new 0 243 556
assign 1 243 557
equals 1 243 557
assign 1 0 559
assign 1 243 562
equals 1 243 562
assign 1 0 564
assign 1 0 567
assign 1 244 571
equals 1 244 571
assign 1 244 573
increment 0 244 573
assign 1 245 575
nextGet 0 245 575
assign 1 247 581
new 0 247 581
assign 1 247 582
equals 1 247 582
assign 1 248 584
new 0 248 584
assign 1 249 585
new 0 249 585
assign 1 250 586
nextGet 0 250 586
extractString 0 251 587
assign 1 252 588
new 0 252 588
addValue 1 252 589
assign 1 253 592
new 0 253 592
assign 1 253 593
equals 1 253 593
assign 1 254 595
new 0 254 595
assign 1 255 596
new 0 255 596
assign 1 256 597
nextGet 0 256 597
extractString 0 257 598
assign 1 258 599
new 0 258 599
addValue 1 258 600
assign 1 260 603
new 0 260 603
assign 1 260 604
equals 1 260 604
assign 1 261 606
new 0 261 606
assign 1 262 607
nextGet 0 262 607
assign 1 264 611
new 0 264 611
assign 1 264 612
notEquals 1 264 612
assign 1 264 614
notEquals 1 264 614
assign 1 0 616
assign 1 0 619
assign 1 0 623
assign 1 264 626
new 0 264 626
assign 1 264 627
notEquals 1 264 627
assign 1 0 629
assign 1 0 632
assign 1 0 636
assign 1 264 639
new 0 264 639
assign 1 264 640
notEquals 1 264 640
assign 1 0 642
assign 1 0 645
assign 1 0 649
addValue 1 265 652
assign 1 266 653
nextGet 0 266 653
assign 1 268 659
equals 1 268 659
assign 1 268 661
increment 0 268 661
assign 1 269 663
new 0 269 663
assign 1 271 665
new 0 271 665
assign 1 272 666
assign 1 273 667
extractString 0 273 667
nameSet 1 273 668
assign 1 275 671
new 0 275 671
assign 1 276 672
extractString 0 276 672
nameSet 1 276 673
assign 1 277 674
assign 1 279 676
new 0 279 676
assign 1 279 677
equals 1 279 677
assign 1 280 679
new 0 280 679
assign 1 282 681
new 0 282 681
assign 1 284 685
new 0 284 685
assign 1 284 686
equals 1 284 686
assign 1 0 689
assign 1 0 692
assign 1 0 696
assign 1 285 699
new 0 285 699
assign 1 286 700
new 0 286 700
isClosedSet 1 286 701
assign 1 287 702
nextGet 0 287 702
assign 1 289 706
new 0 289 706
assign 1 291 709
new 0 291 709
assign 1 296 717
nextGet 0 296 717
assign 1 297 720
new 0 297 720
assign 1 297 721
equals 1 297 721
assign 1 0 723
assign 1 297 726
equals 1 297 726
assign 1 0 728
assign 1 0 731
assign 1 298 735
equals 1 298 735
assign 1 298 737
increment 0 298 737
assign 1 299 739
nextGet 0 299 739
assign 1 301 747
new 0 301 747
assign 1 301 748
notEquals 1 301 748
assign 1 301 750
notEquals 1 301 750
assign 1 0 752
assign 1 0 755
assign 1 0 759
assign 1 301 762
new 0 301 762
assign 1 301 763
notEquals 1 301 763
assign 1 0 765
assign 1 0 768
assign 1 0 772
assign 1 301 775
new 0 301 775
assign 1 301 776
notEquals 1 301 776
assign 1 0 778
assign 1 0 781
assign 1 0 785
assign 1 301 788
new 0 301 788
assign 1 301 789
notEquals 1 301 789
assign 1 0 791
assign 1 0 794
assign 1 0 798
addValue 1 302 801
assign 1 303 802
nextGet 0 303 802
assign 1 305 808
new 0 305 808
assign 1 306 809
equals 1 306 809
assign 1 306 811
increment 0 306 811
assign 1 307 813
new 0 307 813
assign 1 307 814
equals 1 307 814
assign 1 308 816
new 0 308 816
assign 1 309 817
new 0 309 817
assign 1 310 820
new 0 310 820
assign 1 310 821
equals 1 310 821
assign 1 311 823
new 0 311 823
assign 1 312 824
new 0 312 824
isClosedSet 1 312 825
assign 1 313 826
nextGet 0 313 826
assign 1 315 829
extractString 0 315 829
addAttributeName 1 315 830
assign 1 316 831
new 0 316 831
assign 1 320 836
nextGet 0 320 836
assign 1 321 839
new 0 321 839
assign 1 321 840
equals 1 321 840
assign 1 0 842
assign 1 321 845
equals 1 321 845
assign 1 0 847
assign 1 0 850
assign 1 0 854
assign 1 321 857
new 0 321 857
assign 1 321 858
equals 1 321 858
assign 1 0 860
assign 1 0 863
assign 1 323 867
equals 1 323 867
assign 1 323 869
increment 0 323 869
assign 1 324 871
nextGet 0 324 871
assign 1 326 877
notEquals 1 326 877
assign 1 327 879
new 0 327 879
assign 1 327 880
toString 0 327 880
assign 1 327 881
add 1 327 881
assign 1 327 882
new 1 327 882
throw 1 327 883
assign 1 329 885
nextGet 0 329 885
assign 1 330 888
notEquals 1 330 888
assign 1 331 890
equals 1 331 890
assign 1 331 892
increment 0 331 892
addValue 1 332 894
assign 1 333 895
nextGet 0 333 895
assign 1 335 901
notEquals 1 335 901
assign 1 336 903
new 0 336 903
assign 1 336 904
toString 0 336 904
assign 1 336 905
add 1 336 905
assign 1 336 906
new 1 336 906
throw 1 336 907
assign 1 338 909
new 0 338 909
assign 1 339 910
extractString 0 339 910
addAttributeValue 1 339 911
assign 1 340 912
new 0 340 912
assign 1 343 919
def 1 343 924
assign 1 0 925
assign 1 343 928
def 1 343 933
assign 1 343 934
isClosedGet 0 343 934
assign 1 0 936
assign 1 0 939
assign 1 0 943
assign 1 0 946
assign 1 0 949
assign 1 344 953
nextGet 0 344 953
assign 1 345 956
def 1 345 961
assign 1 345 962
new 0 345 962
assign 1 345 963
equals 1 345 963
assign 1 0 965
assign 1 345 968
equals 1 345 968
assign 1 0 970
assign 1 0 973
assign 1 0 977
assign 1 0 980
assign 1 0 984
assign 1 345 987
nextGet 0 345 987
assign 1 346 993
def 1 346 998
assign 1 346 999
new 0 346 999
assign 1 346 1000
equals 1 346 1000
assign 1 0 1002
assign 1 0 1005
assign 1 0 1009
assign 1 346 1012
new 0 346 1012
assign 1 349 1017
undef 1 349 1022
assign 1 349 1023
new 0 349 1023
assign 1 350 1025
new 0 350 1025
assign 1 350 1026
add 1 350 1026
assign 1 350 1027
new 0 350 1027
assign 1 350 1028
add 1 350 1028
assign 1 350 1029
new 1 350 1029
throw 1 350 1030
return 1 353 1034
assign 1 357 1040
not 0 357 1045
assign 1 357 1046
new 0 357 1046
return 1 357 1047
assign 1 358 1049
hasNextGet 0 358 1049
return 1 358 1050
return 1 0 1053
assign 1 0 1056
return 1 0 1060
assign 1 0 1063
return 1 0 1067
assign 1 0 1070
return 1 0 1074
assign 1 0 1077
return 1 0 1081
assign 1 0 1084
return 1 0 1088
assign 1 0 1091
return 1 0 1095
assign 1 0 1098
return 1 0 1102
assign 1 0 1105
return 1 0 1109
assign 1 0 1112
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1262689441: return bem_xmlStringGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1862823180: return bem_debugGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -1858379264: return bem_restart_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 576066950: return bem_startedGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1818667533: return bem_lineGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -2020613809: return bem_iterGet_0();
case 1194623572: return bem_nextGet_0();
case 718097912: return bem_textNodeGet_0();
case -378480441: return bem_resGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 2072043336: return bem_skipGet_0();
case 1820417453: return bem_create_0();
case -1897185389: return bem_start_0();
case -786424307: return bem_tagGet_0();
case -1779033109: return bem_xtGet_0();
case -1354714650: return bem_copy_0();
case 108485850: return bem_hasNextGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2009531556: return bem_iterSet_1(bevd_0);
case -367398188: return bem_resSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 729180165: return bem_textNodeSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1767950856: return bem_xtSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2083125589: return bem_skipSet_1(bevd_0);
case 587149203: return bem_startedSet_1(bevd_0);
case -1526472767: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1851740927: return bem_debugSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1807585280: return bem_lineSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1251607188: return bem_xmlStringSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_11_XmlTagIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
}
}
