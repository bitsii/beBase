namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
static BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_6_8_SystemBasePath bevs_inst;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_2_6_8_SystemBasePath_bels_0));
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_firstStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lastStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 378 */ {
bevt_4_tmpany_phold = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 379 */
bevt_5_tmpany_phold = beva_other.bemd_0(1359432006, BEL_4_Base.bevn_isAbsoluteGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 381 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 382 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(-2001811380, BEL_4_Base.bevn_split_1, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 386 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 386 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 388 */
 else  /* Line: 386 */ {
break;
} /* Line: 386 */
} /* Line: 386 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
bevl_rpath = (BEC_2_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 404 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 404 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 406 */
 else  /* Line: 407 */ {
bevl_i.bem_nextGet_0();
} /* Line: 408 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 410 */
 else  /* Line: 404 */ {
break;
} /* Line: 404 */
} /* Line: 404 */
bevt_4_tmpany_phold = this.bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 413 */
return bevl_rpath;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 419 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 419 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 419 */
bevt_9_tmpany_phold = bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 420 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 421 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 427 */ {
bevt_1_tmpany_phold = bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 428 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 433 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 434 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 439 */ {
this.bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 444 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 444 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 445 */ {
break;
} /* Line: 445 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 444 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 450 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 463 */
 else  /* Line: 464 */ {
bevt_3_tmpany_phold = bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 465 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 471 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 472 */
 else  /* Line: 471 */ {
break;
} /* Line: 471 */
} /* Line: 471 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_8_SystemBasePath) this.bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 511 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(-1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 511 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 511 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 511 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 511 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 511 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 511 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 511 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 511 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 512 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = this.bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 523 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 524 */
 else  /* Line: 525 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 526 */
bevl_res = this.bem_create_0();
bevl_res.bemd_1(410741679, BEL_4_Base.bevn_separatorSet_1, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-389107089, BEL_4_Base.bevn_pathSet_1, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {339, 339, 343, 344, 348, 352, 356, 356, 360, 361, 361, 362, 366, 366, 370, 370, 370, 374, 374, 374, 378, 378, 378, 378, 379, 379, 381, 382, 382, 384, 385, 385, 386, 386, 387, 388, 390, 390, 391, 392, 394, 398, 399, 400, 400, 401, 402, 403, 404, 404, 405, 405, 406, 406, 408, 410, 412, 413, 415, 419, 419, 0, 419, 419, 419, 419, 419, 0, 0, 419, 419, 420, 420, 420, 421, 421, 423, 423, 427, 428, 428, 428, 433, 433, 433, 434, 439, 439, 439, 440, 441, 443, 444, 444, 444, 445, 445, 446, 447, 448, 444, 450, 455, 456, 457, 461, 462, 462, 463, 463, 465, 465, 465, 465, 470, 471, 471, 472, 472, 474, 478, 478, 482, 483, 484, 485, 489, 490, 491, 491, 492, 496, 496, 500, 500, 504, 504, 504, 511, 511, 0, 511, 0, 0, 0, 511, 511, 0, 0, 512, 512, 514, 514, 518, 518, 522, 523, 523, 524, 526, 528, 529, 530, 530, 530, 531, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 29, 30, 34, 38, 42, 43, 49, 50, 51, 52, 56, 57, 62, 63, 64, 69, 70, 71, 90, 91, 92, 93, 95, 96, 98, 100, 101, 103, 104, 105, 106, 109, 111, 112, 118, 119, 120, 121, 122, 135, 136, 137, 138, 139, 140, 141, 142, 145, 147, 152, 153, 154, 157, 159, 165, 167, 169, 184, 189, 190, 193, 194, 195, 196, 201, 202, 205, 209, 210, 212, 213, 214, 216, 217, 219, 220, 226, 228, 229, 230, 237, 238, 243, 244, 257, 258, 263, 264, 265, 266, 267, 270, 275, 276, 281, 284, 285, 286, 287, 293, 299, 300, 301, 311, 312, 317, 318, 319, 322, 323, 324, 325, 334, 335, 338, 340, 341, 347, 352, 353, 357, 358, 359, 360, 366, 367, 368, 369, 370, 374, 375, 379, 380, 385, 386, 391, 402, 407, 408, 411, 413, 416, 420, 423, 424, 426, 429, 433, 434, 436, 437, 441, 442, 451, 452, 457, 458, 461, 463, 464, 465, 466, 467, 468, 471, 474, 478, 481};
/* BEGIN LINEINFO 
assign 1 339 24
new 0 339 24
new 1 339 25
assign 1 343 29
new 0 343 29
fromString 1 344 30
assign 1 348 34
return 1 352 38
assign 1 356 42
toStringWithSeparator 1 356 42
return 1 356 43
assign 1 360 49
split 1 360 49
assign 1 361 50
new 0 361 50
assign 1 361 51
join 2 361 51
return 1 362 52
assign 1 366 56
split 1 366 56
return 1 366 57
assign 1 370 62
split 1 370 62
assign 1 370 63
firstGet 0 370 63
return 1 370 64
assign 1 374 69
split 1 374 69
assign 1 374 70
lastGet 0 374 70
return 1 374 71
assign 1 378 90
pathGet 0 378 90
assign 1 378 91
new 0 378 91
assign 1 378 92
emptyGet 0 378 92
assign 1 378 93
equals 1 378 93
assign 1 379 95
copy 0 379 95
return 1 379 96
assign 1 381 98
isAbsoluteGet 0 381 98
assign 1 382 100
copy 0 382 100
return 1 382 101
assign 1 384 103
split 1 384 103
assign 1 385 104
pathGet 0 385 104
assign 1 385 105
split 1 385 105
assign 1 386 106
linkedListIteratorGet 0 386 106
assign 1 386 109
hasNextGet 0 386 109
assign 1 387 111
nextGet 0 387 111
addValue 1 388 112
assign 1 390 118
new 0 390 118
assign 1 390 119
join 2 390 119
assign 1 391 120
copy 0 391 120
assign 1 392 121
fromString 1 392 121
return 1 394 122
assign 1 398 135
split 1 398 135
assign 1 399 136
copy 0 399 136
assign 1 400 137
new 0 400 137
pathSet 1 400 138
assign 1 401 139
lengthGet 0 401 139
assign 1 402 140
decrement 0 402 140
assign 1 403 141
new 0 403 141
assign 1 404 142
linkedListIteratorGet 0 404 142
assign 1 404 145
hasNextGet 0 404 145
assign 1 405 147
lesser 1 405 152
assign 1 406 153
nextGet 0 406 153
addStep 1 406 154
nextGet 0 408 157
assign 1 410 159
increment 0 410 159
assign 1 412 165
isAbsoluteGet 0 412 165
makeAbsolute 0 413 167
return 1 415 169
assign 1 419 184
undef 1 419 189
assign 1 0 190
assign 1 419 193
toString 0 419 193
assign 1 419 194
sizeGet 0 419 194
assign 1 419 195
new 0 419 195
assign 1 419 196
lesser 1 419 201
assign 1 0 202
assign 1 0 205
assign 1 419 209
new 0 419 209
return 1 419 210
assign 1 420 212
new 0 420 212
assign 1 420 213
getPoint 1 420 213
assign 1 420 214
equals 1 420 214
assign 1 421 216
new 0 421 216
return 1 421 217
assign 1 423 219
new 0 423 219
return 1 423 220
assign 1 427 226
isAbsoluteGet 0 427 226
assign 1 428 228
new 0 428 228
assign 1 428 229
sizeGet 0 428 229
assign 1 428 230
substring 2 428 230
assign 1 433 237
isAbsoluteGet 0 433 237
assign 1 433 238
not 0 433 243
assign 1 434 244
add 1 434 244
assign 1 439 257
new 0 439 257
assign 1 439 258
greater 1 439 263
makeNonAbsolute 0 440 264
assign 1 441 265
split 1 441 265
assign 1 443 266
firstNodeGet 0 443 266
assign 1 444 267
new 0 444 267
assign 1 444 270
lesser 1 444 275
assign 1 445 276
undef 1 445 281
assign 1 446 284
assign 1 447 285
nextGet 0 447 285
delete 0 448 286
assign 1 444 287
increment 0 444 287
assign 1 450 293
join 2 450 293
assign 1 455 299
split 1 455 299
addValue 1 456 300
assign 1 457 301
join 2 457 301
assign 1 461 311
find 1 461 311
assign 1 462 312
undef 1 462 317
assign 1 463 318
new 0 463 318
assign 1 463 319
emptyGet 0 463 319
assign 1 465 322
new 0 465 322
assign 1 465 323
add 1 465 323
assign 1 465 324
sizeGet 0 465 324
assign 1 465 325
substring 2 465 325
assign 1 470 334
split 1 470 334
assign 1 471 335
linkedListIteratorGet 0 471 335
assign 1 471 338
hasNextGet 0 471 338
assign 1 472 340
nextGet 0 472 340
addValue 1 472 341
assign 1 474 347
join 2 474 347
assign 1 478 352
addStep 1 478 352
return 1 478 353
assign 1 482 357
split 1 482 357
addValue 1 483 358
addValue 1 484 359
assign 1 485 360
join 2 485 360
assign 1 489 366
create 0 489 366
copyTo 1 490 367
assign 1 491 368
copy 0 491 368
pathSet 1 491 369
return 1 492 370
assign 1 496 374
split 1 496 374
return 1 496 375
assign 1 500 379
hashGet 0 500 379
return 1 500 380
assign 1 504 385
equals 1 504 385
assign 1 504 386
not 0 504 391
return 1 504 391
assign 1 511 402
undef 1 511 407
assign 1 0 408
assign 1 511 411
otherType 1 511 411
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 511 423
pathGet 0 511 423
assign 1 511 424
notEquals 1 511 424
assign 1 0 426
assign 1 0 429
assign 1 512 433
new 0 512 433
return 1 512 434
assign 1 514 436
new 0 514 436
return 1 514 437
assign 1 518 441
subPath 2 518 441
return 1 518 442
assign 1 522 451
stepsGet 0 522 451
assign 1 523 452
undef 1 523 457
assign 1 524 458
subList 1 524 458
assign 1 526 461
subList 2 526 461
assign 1 528 463
create 0 528 463
separatorSet 1 529 464
assign 1 530 465
new 0 530 465
assign 1 530 466
join 2 530 466
pathSet 1 530 467
return 1 531 468
return 1 0 471
assign 1 0 474
return 1 0 478
assign 1 0 481
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case -1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -471950299: return bem_lastStepGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case -935459934: return bem_deleteFirstStep_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -1719674549: return bem_firstStepGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -723109216: return bem_stepsGet_0();
case -1354714650: return bem_copy_0();
case -400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case -1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -630006451: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -488966921: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1787791811: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case -2006569863: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -488966920: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemBasePath.bevs_inst = (BEC_2_6_8_SystemBasePath)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemBasePath.bevs_inst;
}
}
}
