namespace be {
/* IO:File: source/build/Pass6.be */
public sealed class BEC_3_5_5_5_BuildVisitPass6 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
static BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_0 = {0x2C};
private static byte[] bels_1 = {0x2C};
private static byte[] bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_3 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_4 = {0x5F};
private static byte[] bels_5 = {0x74,0x68,0x69,0x73};
private static byte[] bels_6 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_8 = {0x73,0x65,0x6C,0x66};
public static new BEC_3_5_5_5_BuildVisitPass6 bevs_inst;
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_38_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_5_4_BuildEmit bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_6_BuildIfEmit bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_4_6_TextString bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_4_6_TextString bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_5_3_BuildVar bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_168_tmpany_phold = null;
BEC_2_4_6_TextString bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_175_tmpany_phold = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_12_tmpany_phold == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_15_tmpany_phold = beva_node.bem_containedGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_lengthGet_0();
bevt_16_tmpany_phold = bevo_0;
if (bevt_14_tmpany_phold.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
 else  /* Line: 27 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 27 */ {
bevt_20_tmpany_phold = beva_node.bem_containedGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_18_tmpany_phold == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
 else  /* Line: 27 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 27 */ {
bevt_25_tmpany_phold = beva_node.bem_containedGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_firstGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpany_phold);
if (bevt_21_tmpany_phold != null && bevt_21_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpany_phold).bevi_bool) /* Line: 27 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
 else  /* Line: 27 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 27 */ {
bevt_30_tmpany_phold = beva_node.bem_secondGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_containedGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_lengthGet_0();
bevt_31_tmpany_phold = bevo_1;
if (bevt_28_tmpany_phold.bevi_int > bevt_31_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
 else  /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 27 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_0_tmpany_loop = bevt_32_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 30 */ {
bevt_35_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_35_tmpany_phold != null && bevt_35_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpany_phold).bevi_bool) /* Line: 30 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_36_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_tmpany_phold);
} /* Line: 32 */
 else  /* Line: 30 */ {
break;
} /* Line: 30 */
} /* Line: 30 */
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevl_langs.bem_delete_1(bevt_37_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
if (bevl_doit != null && bevl_doit is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_doit).bevi_bool) /* Line: 36 */ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_39_tmpany_phold = beva_node.bem_secondGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_containedGet_0();
bevl_i = bevt_38_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_40_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_si = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_42_tmpany_phold = bevl_si.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_43_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpany_phold);
if (bevt_41_tmpany_phold != null && bevt_41_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpany_phold).bevi_bool) /* Line: 40 */ {
bevt_44_tmpany_phold = bevl_si.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_44_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 44 */
} /* Line: 40 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
} /* Line: 38 */
bevt_45_tmpany_phold = bevl_doit.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpany_phold).bevi_bool) /* Line: 48 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 50 */
beva_node.bem_containedSet_1(null);
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = (BEC_2_5_4_BuildEmit) (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_tmpany_phold, bevl_langs);
beva_node.bem_heldSet_1(bevt_46_tmpany_phold);
} /* Line: 53 */
 else  /* Line: 54 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 56 */
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_tmpany_phold = bevl_snode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_50_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_50_tmpany_phold);
if (bevt_48_tmpany_phold != null && bevt_48_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpany_phold).bevi_bool) /* Line: 60 */ {
bevl_snode = null;
} /* Line: 61 */
if (bevl_snode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 64 */ {
beva_node.bem_delete_0();
bevt_52_tmpany_phold = bevl_snode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_52_tmpany_phold.bemd_1(-406676794, BEL_4_Base.bevn_addEmit_1, beva_node);
} /* Line: 66 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 69 */
 else  /* Line: 25 */ {
bevt_54_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_tmpany_phold.bevi_int == bevt_55_tmpany_phold.bevi_int) {
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpany_phold.bevi_bool) /* Line: 70 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_tmpany_phold = beva_node.bem_containedGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_firstGet_0();
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_1_tmpany_loop = bevt_56_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 73 */ {
bevt_59_tmpany_phold = bevt_1_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpany_phold != null && bevt_59_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_60_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_tmpany_phold);
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lang);
} /* Line: 76 */
 else  /* Line: 73 */ {
break;
} /* Line: 73 */
} /* Line: 73 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevl_langs.bem_delete_1(bevt_61_tmpany_phold);
bevt_63_tmpany_phold = beva_node.bem_heldGet_0();
bevt_62_tmpany_phold = (BEC_2_5_6_BuildIfEmit) (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_tmpany_phold);
beva_node.bem_heldSet_1(bevt_62_tmpany_phold);
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 80 */ {
bevt_64_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_64_tmpany_phold != null && bevt_64_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_64_tmpany_phold).bevi_bool) /* Line: 80 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 82 */
 else  /* Line: 80 */ {
break;
} /* Line: 80 */
} /* Line: 80 */
} /* Line: 80 */
 else  /* Line: 25 */ {
bevt_66_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_67_tmpany_phold = bevp_ntypes.bem_IFGet_0();
if (bevt_66_tmpany_phold.bevi_int == bevt_67_tmpany_phold.bevi_int) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 84 */ {
if (bevl_nnode == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevl_lnode = beva_node;
while (true)
 /* Line: 87 */ {
if (bevl_nnode == null) {
bevt_69_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpany_phold);
if (bevt_70_tmpany_phold != null && bevt_70_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpany_phold).bevi_bool) /* Line: 87 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_73_tmpany_phold);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_74_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_74_tmpany_phold);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_75_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_75_tmpany_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevt_77_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevt_78_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = bevt_78_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 100 */ {
bevt_79_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_79_tmpany_phold != null && bevt_79_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpany_phold).bevi_bool) /* Line: 100 */ {
bevt_80_tmpany_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_80_tmpany_phold);
} /* Line: 101 */
 else  /* Line: 100 */ {
break;
} /* Line: 100 */
} /* Line: 100 */
} /* Line: 100 */
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_nnode = bevl_nxnode;
} /* Line: 112 */
 else  /* Line: 87 */ {
break;
} /* Line: 87 */
} /* Line: 87 */
if (bevl_nnode == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_83_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_84_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_84_tmpany_phold);
if (bevt_82_tmpany_phold != null && bevt_82_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_82_tmpany_phold).bevi_bool) /* Line: 114 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 114 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 114 */
 else  /* Line: 114 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 114 */ {
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nnode);
} /* Line: 116 */
} /* Line: 114 */
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 119 */
 else  /* Line: 25 */ {
bevt_87_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_89_tmpany_phold = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_tmpany_phold.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_90_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_2));
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_91_tmpany_phold);
bevl_parens.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_tmpany_phold = bevl_parens.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_92_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 129 */ {
bevt_93_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_93_tmpany_phold != null && bevt_93_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_93_tmpany_phold).bevi_bool) /* Line: 129 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_ix = bevl_i.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_95_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_96_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_96_tmpany_phold);
if (bevt_94_tmpany_phold != null && bevt_94_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_94_tmpany_phold).bevi_bool) /* Line: 134 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 135 */
 else  /* Line: 134 */ {
bevt_98_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_99_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_99_tmpany_phold);
if (bevt_97_tmpany_phold != null && bevt_97_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_97_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevt_100_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_100_tmpany_phold);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_tmpany_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_102_tmpany_phold);
bevl_i.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
bevt_103_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_103_tmpany_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
} /* Line: 143 */
 else  /* Line: 134 */ {
bevt_105_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_106_tmpany_phold);
if (bevt_104_tmpany_phold != null && bevt_104_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpany_phold).bevi_bool) /* Line: 144 */ {
bevt_108_tmpany_phold = bevl_ix.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_109_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_109_tmpany_phold);
if (bevt_107_tmpany_phold != null && bevt_107_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_107_tmpany_phold).bevi_bool) /* Line: 145 */ {
bevt_110_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_110_tmpany_phold);
bevt_111_tmpany_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_112_tmpany_phold = bevl_ix.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_111_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_114_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_113_tmpany_phold.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_114_tmpany_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevt_115_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_115_tmpany_phold);
} /* Line: 150 */
 else  /* Line: 151 */ {
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bels_3));
bevt_116_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_tmpany_phold, bevl_i);
throw new be.BECS_ThrowBack(bevt_116_tmpany_phold);
} /* Line: 152 */
} /* Line: 145 */
} /* Line: 134 */
} /* Line: 134 */
} /* Line: 134 */
 else  /* Line: 129 */ {
break;
} /* Line: 129 */
} /* Line: 129 */
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 156 */ {
bevt_118_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_118_tmpany_phold != null && bevt_118_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_118_tmpany_phold).bevi_bool) /* Line: 156 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 158 */
 else  /* Line: 156 */ {
break;
} /* Line: 156 */
} /* Line: 156 */
bevl_s = beva_node.bem_heldGet_0();
bevt_120_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_119_tmpany_phold = bevl_numargs.bemd_1(81310150, BEL_4_Base.bevn_subtract_1, bevt_120_tmpany_phold);
bevl_s.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_119_tmpany_phold);
bevt_121_tmpany_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_s.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_121_tmpany_phold);
bevt_124_tmpany_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_125_tmpany_phold);
bevt_127_tmpany_phold = bevl_s.bemd_0(-548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_126_tmpany_phold);
bevl_s.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_122_tmpany_phold);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_130_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_128_tmpany_phold = bevt_129_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_130_tmpany_phold);
if (bevt_128_tmpany_phold != null && bevt_128_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_128_tmpany_phold).bevi_bool) /* Line: 165 */ {
bevl_i.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_131_tmpany_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_s.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_131_tmpany_phold);
bevt_134_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_133_tmpany_phold = bevt_134_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_133_tmpany_phold == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevl_s.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, null);
} /* Line: 171 */
 else  /* Line: 169 */ {
bevt_138_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_139_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_5));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_139_tmpany_phold);
if (bevt_135_tmpany_phold != null && bevt_135_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_135_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevt_140_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_141_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_140_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_143_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_142_tmpany_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_145_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_144_tmpany_phold.bemd_1(606514572, BEL_4_Base.bevn_isThisSet_1, bevt_145_tmpany_phold);
bevt_147_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_148_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_6));
bevt_146_tmpany_phold.bemd_1(-389107089, BEL_4_Base.bevn_pathSet_1, bevt_148_tmpany_phold);
} /* Line: 177 */
 else  /* Line: 169 */ {
bevt_152_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_153_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_153_tmpany_phold);
if (bevt_149_tmpany_phold != null && bevt_149_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpany_phold).bevi_bool) /* Line: 178 */ {
bevt_154_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_155_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_154_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_157_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_156_tmpany_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_157_tmpany_phold);
} /* Line: 180 */
} /* Line: 169 */
} /* Line: 169 */
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 182 */
 else  /* Line: 183 */ {
bevt_158_tmpany_phold = (BEC_2_5_3_BuildVar) (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_158_tmpany_phold);
bevt_159_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_160_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_159_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_160_tmpany_phold);
bevt_161_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_162_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_161_tmpany_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_162_tmpany_phold);
bevt_163_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_164_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_163_tmpany_phold.bemd_1(606514572, BEL_4_Base.bevn_isThisSet_1, bevt_164_tmpany_phold);
bevt_165_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_166_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_165_tmpany_phold.bemd_1(601092044, BEL_4_Base.bevn_impliedSet_1, bevt_166_tmpany_phold);
bevt_167_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_169_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_8));
bevt_168_tmpany_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_169_tmpany_phold);
bevt_167_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_168_tmpany_phold);
} /* Line: 189 */
bevl_clnode = beva_node.bem_classGet_0();
bevt_171_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_172_tmpany_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_170_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_172_tmpany_phold, beva_node);
bevt_174_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_173_tmpany_phold = bevt_174_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_173_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 193 */
} /* Line: 25 */
} /* Line: 25 */
} /* Line: 25 */
bevt_175_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_175_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {21, 24, 25, 25, 25, 25, 26, 27, 27, 27, 27, 27, 27, 27, 27, 0, 0, 0, 27, 27, 27, 27, 27, 0, 0, 0, 27, 27, 27, 27, 27, 27, 0, 0, 0, 27, 27, 27, 27, 27, 27, 0, 0, 0, 29, 30, 30, 30, 30, 0, 30, 30, 32, 32, 34, 34, 35, 37, 38, 38, 38, 38, 39, 40, 40, 40, 41, 41, 44, 48, 49, 50, 52, 53, 53, 53, 55, 56, 59, 60, 60, 60, 61, 64, 64, 65, 66, 66, 69, 70, 70, 70, 70, 71, 72, 73, 73, 73, 73, 0, 73, 73, 75, 75, 76, 78, 78, 79, 79, 79, 80, 80, 81, 82, 84, 84, 84, 84, 85, 85, 86, 87, 87, 87, 87, 87, 0, 0, 0, 88, 89, 89, 90, 91, 92, 93, 93, 94, 95, 96, 96, 97, 98, 99, 99, 99, 100, 100, 100, 101, 101, 108, 109, 110, 111, 112, 114, 114, 114, 114, 114, 0, 0, 0, 115, 116, 119, 119, 120, 120, 120, 120, 121, 121, 122, 123, 124, 124, 125, 125, 126, 127, 128, 129, 129, 129, 130, 131, 134, 134, 134, 135, 136, 136, 136, 137, 137, 138, 139, 139, 140, 140, 141, 142, 142, 143, 144, 144, 144, 145, 145, 145, 146, 146, 147, 147, 147, 148, 148, 148, 149, 150, 150, 152, 152, 152, 156, 156, 157, 158, 160, 161, 161, 161, 162, 162, 163, 163, 163, 163, 163, 163, 163, 164, 165, 165, 165, 166, 168, 168, 169, 169, 169, 169, 171, 172, 172, 172, 172, 172, 174, 174, 174, 175, 175, 175, 176, 176, 176, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 180, 180, 180, 182, 184, 184, 185, 185, 185, 186, 186, 186, 187, 187, 187, 188, 188, 188, 189, 189, 189, 189, 191, 192, 192, 192, 192, 193, 193, 193, 195, 195};
public static new int[] bevs_smnlec
 = new int[] {221, 222, 223, 224, 225, 230, 231, 232, 233, 238, 239, 240, 241, 242, 247, 248, 251, 255, 258, 259, 260, 261, 266, 267, 270, 274, 277, 278, 279, 280, 281, 282, 284, 287, 291, 294, 295, 296, 297, 298, 303, 304, 307, 311, 314, 315, 316, 317, 318, 318, 321, 323, 324, 325, 331, 332, 333, 335, 336, 337, 338, 341, 343, 344, 345, 346, 348, 349, 350, 358, 360, 361, 363, 364, 365, 366, 369, 370, 372, 373, 374, 375, 377, 379, 384, 385, 386, 387, 389, 392, 393, 394, 399, 400, 401, 402, 403, 404, 405, 405, 408, 410, 411, 412, 413, 419, 420, 421, 422, 423, 424, 427, 429, 430, 438, 439, 440, 445, 446, 451, 452, 455, 460, 461, 462, 463, 465, 468, 472, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 495, 496, 497, 500, 502, 503, 510, 511, 512, 513, 514, 520, 525, 526, 527, 528, 530, 533, 537, 540, 541, 544, 545, 548, 549, 550, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 571, 573, 574, 575, 576, 577, 579, 582, 583, 584, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 599, 600, 601, 603, 604, 605, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 620, 621, 622, 632, 635, 637, 638, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 662, 663, 664, 665, 666, 667, 672, 673, 676, 677, 678, 679, 680, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 697, 698, 699, 700, 701, 703, 704, 705, 706, 707, 708, 712, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 734, 735, 736, 737, 738, 739, 740, 741, 746, 747};
/* BEGIN LINEINFO 
resolveNp 0 21 221
assign 1 24 222
nextPeerGet 0 24 222
assign 1 25 223
typenameGet 0 25 223
assign 1 25 224
EMITGet 0 25 224
assign 1 25 225
equals 1 25 230
assign 1 26 231
nextAscendGet 0 26 231
assign 1 27 232
containedGet 0 27 232
assign 1 27 233
def 1 27 238
assign 1 27 239
containedGet 0 27 239
assign 1 27 240
lengthGet 0 27 240
assign 1 27 241
new 0 27 241
assign 1 27 242
greater 1 27 247
assign 1 0 248
assign 1 0 251
assign 1 0 255
assign 1 27 258
containedGet 0 27 258
assign 1 27 259
firstGet 0 27 259
assign 1 27 260
containedGet 0 27 260
assign 1 27 261
def 1 27 266
assign 1 0 267
assign 1 0 270
assign 1 0 274
assign 1 27 277
containedGet 0 27 277
assign 1 27 278
firstGet 0 27 278
assign 1 27 279
containedGet 0 27 279
assign 1 27 280
lengthGet 0 27 280
assign 1 27 281
new 0 27 281
assign 1 27 282
greater 1 27 282
assign 1 0 284
assign 1 0 287
assign 1 0 291
assign 1 27 294
secondGet 0 27 294
assign 1 27 295
containedGet 0 27 295
assign 1 27 296
lengthGet 0 27 296
assign 1 27 297
new 0 27 297
assign 1 27 298
greater 1 27 303
assign 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 29 314
new 0 29 314
assign 1 30 315
containedGet 0 30 315
assign 1 30 316
firstGet 0 30 316
assign 1 30 317
containedGet 0 30 317
assign 1 30 318
iteratorGet 0 0 318
assign 1 30 321
hasNextGet 0 30 321
assign 1 30 323
nextGet 0 30 323
assign 1 32 324
heldGet 0 32 324
addValue 1 32 325
assign 1 34 331
new 0 34 331
delete 1 34 332
assign 1 35 333
new 0 35 333
assign 1 37 335
new 0 37 335
assign 1 38 336
secondGet 0 38 336
assign 1 38 337
containedGet 0 38 337
assign 1 38 338
iteratorGet 0 38 338
assign 1 38 341
hasNextGet 0 38 341
assign 1 39 343
nextGet 0 39 343
assign 1 40 344
typenameGet 0 40 344
assign 1 40 345
STRINGLGet 0 40 345
assign 1 40 346
equals 1 40 346
assign 1 41 348
heldGet 0 41 348
heldSet 1 41 349
assign 1 44 350
new 0 44 350
assign 1 48 358
not 0 48 358
delete 0 49 360
return 1 50 361
containedSet 1 52 363
assign 1 53 364
heldGet 0 53 364
assign 1 53 365
new 2 53 365
heldSet 1 53 366
delete 0 55 369
return 1 56 370
assign 1 59 372
scopeGet 0 59 372
assign 1 60 373
typenameGet 0 60 373
assign 1 60 374
METHODGet 0 60 374
assign 1 60 375
equals 1 60 375
assign 1 61 377
assign 1 64 379
def 1 64 384
delete 0 65 385
assign 1 66 386
heldGet 0 66 386
addEmit 1 66 387
return 1 69 389
assign 1 70 392
typenameGet 0 70 392
assign 1 70 393
IFEMITGet 0 70 393
assign 1 70 394
equals 1 70 399
assign 1 71 400
new 0 71 400
assign 1 72 401
new 0 72 401
assign 1 73 402
containedGet 0 73 402
assign 1 73 403
firstGet 0 73 403
assign 1 73 404
containedGet 0 73 404
assign 1 73 405
iteratorGet 0 0 405
assign 1 73 408
hasNextGet 0 73 408
assign 1 73 410
nextGet 0 73 410
assign 1 75 411
heldGet 0 75 411
addValue 1 75 412
addValue 1 76 413
assign 1 78 419
new 0 78 419
delete 1 78 420
assign 1 79 421
heldGet 0 79 421
assign 1 79 422
new 2 79 422
heldSet 1 79 423
assign 1 80 424
iteratorGet 0 80 424
assign 1 80 427
hasNextGet 0 80 427
assign 1 81 429
nextGet 0 81 429
delete 0 82 430
assign 1 84 438
typenameGet 0 84 438
assign 1 84 439
IFGet 0 84 439
assign 1 84 440
equals 1 84 445
assign 1 85 446
def 1 85 451
assign 1 86 452
assign 1 87 455
def 1 87 460
assign 1 87 461
typenameGet 0 87 461
assign 1 87 462
ELIFGet 0 87 462
assign 1 87 463
equals 1 87 463
assign 1 0 465
assign 1 0 468
assign 1 0 472
assign 1 88 475
new 1 88 475
assign 1 89 476
ELSEGet 0 89 476
typenameSet 1 89 477
copyLoc 1 90 478
assign 1 91 479
new 1 91 479
copyLoc 1 92 480
assign 1 93 481
BRACESGet 0 93 481
typenameSet 1 93 482
assign 1 94 483
new 1 94 483
copyLoc 1 95 484
assign 1 96 485
IFGet 0 96 485
typenameSet 1 96 486
addValue 1 97 487
addValue 1 98 488
assign 1 99 489
containedGet 0 99 489
assign 1 99 490
def 1 99 495
assign 1 100 496
containedGet 0 100 496
assign 1 100 497
iteratorGet 0 100 497
assign 1 100 500
hasNextGet 0 100 500
assign 1 101 502
nextGet 0 101 502
addValue 1 101 503
addValue 1 108 510
assign 1 109 511
assign 1 110 512
nextPeerGet 0 110 512
delete 0 111 513
assign 1 112 514
assign 1 114 520
def 1 114 525
assign 1 114 526
typenameGet 0 114 526
assign 1 114 527
ELSEGet 0 114 527
assign 1 114 528
equals 1 114 528
assign 1 0 530
assign 1 0 533
assign 1 0 537
delete 0 115 540
addValue 1 116 541
assign 1 119 544
nextDescendGet 0 119 544
return 1 119 545
assign 1 120 548
typenameGet 0 120 548
assign 1 120 549
METHODGet 0 120 549
assign 1 120 550
equals 1 120 555
assign 1 121 556
containedGet 0 121 556
assign 1 121 557
firstGet 0 121 557
assign 1 122 558
new 1 122 558
copyLoc 1 123 559
assign 1 124 560
IDGet 0 124 560
typenameSet 1 124 561
assign 1 125 562
new 0 125 562
heldSet 1 125 563
prepend 1 126 564
assign 1 127 565
new 0 127 565
assign 1 128 566
new 0 128 566
assign 1 129 567
containedGet 0 129 567
assign 1 129 568
iteratorGet 0 129 568
assign 1 129 571
hasNextGet 0 129 571
assign 1 130 573
nextGet 0 130 573
assign 1 131 574
nextPeerGet 0 131 574
assign 1 134 575
typenameGet 0 134 575
assign 1 134 576
COMMAGet 0 134 576
assign 1 134 577
equals 1 134 577
addValue 1 135 579
assign 1 136 582
typenameGet 0 136 582
assign 1 136 583
IDGet 0 136 583
assign 1 136 584
equals 1 136 584
assign 1 137 586
new 0 137 586
assign 1 137 587
add 1 137 587
assign 1 138 588
new 0 138 588
assign 1 139 589
heldGet 0 139 589
nameSet 1 139 590
assign 1 140 591
new 0 140 591
isArgSet 1 140 592
heldSet 1 141 593
assign 1 142 594
VARGet 0 142 594
typenameSet 1 142 595
addVariable 0 143 596
assign 1 144 599
typenameGet 0 144 599
assign 1 144 600
VARGet 0 144 600
assign 1 144 601
equals 1 144 601
assign 1 145 603
typenameGet 0 145 603
assign 1 145 604
IDGet 0 145 604
assign 1 145 605
equals 1 145 605
assign 1 146 607
new 0 146 607
assign 1 146 608
add 1 146 608
assign 1 147 609
heldGet 0 147 609
assign 1 147 610
heldGet 0 147 610
nameSet 1 147 611
assign 1 148 612
heldGet 0 148 612
assign 1 148 613
new 0 148 613
isArgSet 1 148 614
addVariable 0 149 615
assign 1 150 616
COMMAGet 0 150 616
typenameSet 1 150 617
assign 1 152 620
new 0 152 620
assign 1 152 621
new 2 152 621
throw 1 152 622
assign 1 156 632
iteratorGet 0 156 632
assign 1 156 635
hasNextGet 0 156 635
assign 1 157 637
nextGet 0 157 637
delete 0 158 638
assign 1 160 644
heldGet 0 160 644
assign 1 161 645
new 0 161 645
assign 1 161 646
subtract 1 161 646
numargsSet 1 161 647
assign 1 162 648
nameGet 0 162 648
orgNameSet 1 162 649
assign 1 163 650
nameGet 0 163 650
assign 1 163 651
new 0 163 651
assign 1 163 652
add 1 163 652
assign 1 163 653
numargsGet 0 163 653
assign 1 163 654
toString 0 163 654
assign 1 163 655
add 1 163 655
nameSet 1 163 656
assign 1 164 657
secondGet 0 164 657
assign 1 165 658
typenameGet 0 165 658
assign 1 165 659
VARGet 0 165 659
assign 1 165 660
equals 1 165 660
resolveNp 0 166 662
assign 1 168 663
heldGet 0 168 663
rtypeSet 1 168 664
assign 1 169 665
rtypeGet 0 169 665
assign 1 169 666
namepathGet 0 169 666
assign 1 169 667
undef 1 169 672
rtypeSet 1 171 673
assign 1 172 676
rtypeGet 0 172 676
assign 1 172 677
namepathGet 0 172 677
assign 1 172 678
toString 0 172 678
assign 1 172 679
new 0 172 679
assign 1 172 680
equals 1 172 680
assign 1 174 682
rtypeGet 0 174 682
assign 1 174 683
new 0 174 683
isTypedSet 1 174 684
assign 1 175 685
rtypeGet 0 175 685
assign 1 175 686
new 0 175 686
isSelfSet 1 175 687
assign 1 176 688
rtypeGet 0 176 688
assign 1 176 689
new 0 176 689
isThisSet 1 176 690
assign 1 177 691
rtypeGet 0 177 691
assign 1 177 692
namepathGet 0 177 692
assign 1 177 693
new 0 177 693
pathSet 1 177 694
assign 1 178 697
rtypeGet 0 178 697
assign 1 178 698
namepathGet 0 178 698
assign 1 178 699
toString 0 178 699
assign 1 178 700
new 0 178 700
assign 1 178 701
equals 1 178 701
assign 1 179 703
rtypeGet 0 179 703
assign 1 179 704
new 0 179 704
isTypedSet 1 179 705
assign 1 180 706
rtypeGet 0 180 706
assign 1 180 707
new 0 180 707
isSelfSet 1 180 708
delete 0 182 712
assign 1 184 715
new 0 184 715
rtypeSet 1 184 716
assign 1 185 717
rtypeGet 0 185 717
assign 1 185 718
new 0 185 718
isTypedSet 1 185 719
assign 1 186 720
rtypeGet 0 186 720
assign 1 186 721
new 0 186 721
isSelfSet 1 186 722
assign 1 187 723
rtypeGet 0 187 723
assign 1 187 724
new 0 187 724
isThisSet 1 187 725
assign 1 188 726
rtypeGet 0 188 726
assign 1 188 727
new 0 188 727
impliedSet 1 188 728
assign 1 189 729
rtypeGet 0 189 729
assign 1 189 730
new 0 189 730
assign 1 189 731
new 1 189 731
namepathSet 1 189 732
assign 1 191 734
classGet 0 191 734
assign 1 192 735
heldGet 0 192 735
assign 1 192 736
methodsGet 0 192 736
assign 1 192 737
nameGet 0 192 737
put 2 192 738
assign 1 193 739
heldGet 0 193 739
assign 1 193 740
orderedMethodsGet 0 193 740
addValue 1 193 741
assign 1 195 746
nextDescendGet 0 195 746
return 1 195 747
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass6.bevs_inst = (BEC_3_5_5_5_BuildVisitPass6)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass6.bevs_inst;
}
}
}
