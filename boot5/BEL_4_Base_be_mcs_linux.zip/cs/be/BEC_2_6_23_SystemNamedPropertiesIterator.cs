namespace be {
/* IO:File: source/extended/Serialize.be */
public sealed class BEC_2_6_23_SystemNamedPropertiesIterator : BEC_2_6_6_SystemObject {
public BEC_2_6_23_SystemNamedPropertiesIterator() { }
static BEC_2_6_23_SystemNamedPropertiesIterator() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x47,0x65,0x74};
private static byte[] bels_1 = {0x53,0x65,0x74};
public static new BEC_2_6_23_SystemNamedPropertiesIterator bevs_inst;
public BEC_2_9_4_ContainerList bevp_propNames;
public BEC_3_9_4_8_ContainerListIterator bevp_subIter;
public BEC_2_6_6_SystemObject bevp_inst;
public BEC_2_9_4_ContainerList bevp_setArgs;
public BEC_2_9_4_ContainerList bevp_getArgs;
public BEC_2_6_23_SystemNamedPropertiesIterator bem_new_2(BEC_2_6_6_SystemObject beva__inst, BEC_2_9_4_ContainerList beva__propNames) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_propNames = beva__propNames;
bevp_inst = beva__inst;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_setArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_getArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_subIterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_subIter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 446 */ {
bevp_subIter = bevp_propNames.bem_arrayIteratorGet_0();
} /* Line: 447 */
return bevp_subIter;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hasNextGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_nextGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevl_name = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = bevp_inst.bemd_2(94427011, BEL_4_Base.bevn_can_2, bevl_name, bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 458 */ {
bevt_5_tmpany_phold = bevp_inst.bemd_2(636686891, BEL_4_Base.bevn_invoke_2, bevl_name, bevp_getArgs);
return bevt_5_tmpany_phold;
} /* Line: 459 */
return null;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_nextGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_1));
bevl_name = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_3_tmpany_phold = bevp_inst.bemd_2(94427011, BEL_4_Base.bevn_can_2, bevl_name, bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 466 */ {
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_setArgs.bem_put_2(bevt_5_tmpany_phold, beva_value);
bevp_inst.bemd_2(636686891, BEL_4_Base.bevn_invoke_2, bevl_name, bevp_setArgs);
} /* Line: 468 */
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 473 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 473 */ {
this.bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 473 */
 else  /* Line: 473 */ {
break;
} /* Line: 473 */
} /* Line: 473 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_propNamesGet_0() {
return bevp_propNames;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_propNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_subIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instGet_0() {
return bevp_inst;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_instSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inst = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_setArgsGet_0() {
return bevp_setArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_setArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_getArgsGet_0() {
return bevp_getArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_getArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_getArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {437, 439, 440, 440, 441, 441, 446, 446, 447, 449, 453, 453, 453, 457, 457, 457, 457, 458, 458, 459, 459, 461, 465, 465, 465, 465, 466, 466, 467, 467, 468, 473, 473, 473, 474, 473, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 21, 22, 23, 24, 29, 34, 35, 37, 42, 43, 44, 54, 55, 56, 57, 58, 59, 61, 62, 64, 74, 75, 76, 77, 78, 79, 81, 82, 83, 90, 93, 98, 99, 100, 109, 112, 116, 120, 123, 127, 130, 134, 137};
/* BEGIN LINEINFO 
assign 1 437 19
assign 1 439 20
assign 1 440 21
new 0 440 21
assign 1 440 22
new 1 440 22
assign 1 441 23
new 0 441 23
assign 1 441 24
new 1 441 24
assign 1 446 29
undef 1 446 34
assign 1 447 35
arrayIteratorGet 0 447 35
return 1 449 37
assign 1 453 42
subIterGet 0 453 42
assign 1 453 43
hasNextGet 0 453 43
return 1 453 44
assign 1 457 54
subIterGet 0 457 54
assign 1 457 55
nextGet 0 457 55
assign 1 457 56
new 0 457 56
assign 1 457 57
add 1 457 57
assign 1 458 58
new 0 458 58
assign 1 458 59
can 2 458 59
assign 1 459 61
invoke 2 459 61
return 1 459 62
return 1 461 64
assign 1 465 74
subIterGet 0 465 74
assign 1 465 75
nextGet 0 465 75
assign 1 465 76
new 0 465 76
assign 1 465 77
add 1 465 77
assign 1 466 78
new 0 466 78
assign 1 466 79
can 2 466 79
assign 1 467 81
new 0 467 81
put 2 467 82
invoke 2 468 83
assign 1 473 90
new 0 473 90
assign 1 473 93
lesser 1 473 98
nextSet 1 474 99
assign 1 473 100
increment 0 473 100
return 1 0 109
assign 1 0 112
assign 1 0 116
return 1 0 120
assign 1 0 123
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 4834017: return bem_instGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -2137468940: return bem_getArgsGet_0();
case -1012494862: return bem_once_0();
case 74599151: return bem_subIterGet_0();
case -1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case -588476312: return bem_setArgsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -3177758: return bem_propNamesGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case 108485850: return bem_hasNextGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -577394059: return bem_setArgsSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -2126386687: return bem_getArgsSet_1(bevd_0);
case 15916270: return bem_instSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 85681404: return bem_subIterSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 7904495: return bem_propNamesSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 104713555: return bem_new_2(bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_23_SystemNamedPropertiesIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_23_SystemNamedPropertiesIterator.bevs_inst = (BEC_2_6_23_SystemNamedPropertiesIterator)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_23_SystemNamedPropertiesIterator.bevs_inst;
}
}
}
