namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_6_SystemThread : BEC_2_6_10_SystemThinThread {
public BEC_2_6_6_SystemThread() { }
static BEC_2_6_6_SystemThread() { }
private static byte[] becc_BEC_2_6_6_SystemThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_6_SystemThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_inst;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_started;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_finished;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_threwException;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_returned;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_exception;
public override BEC_2_6_10_SystemThinThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_1_tmpany_phold);
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
base.bem_new_1(beva__toRun);
return this;
} /*method end*/
public override BEC_2_6_10_SystemThinThread bem_main_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
try  /* Line: 751 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_started.bem_oSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_toRun.bemd_0(-1081571542, BEL_4_Base.bevn_main_0);
bevp_returned.bem_oSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_threwException.bem_oSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_3_tmpany_phold);
} /* Line: 755 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_threwException.bem_oSet_1(bevt_4_tmpany_phold);
bevp_exception.bem_oSet_1(bevl_e);
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_5_tmpany_phold);
} /* Line: 759 */
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGet_0() {
return bevp_started;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGet_0() {
return bevp_finished;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGet_0() {
return bevp_threwException;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGet_0() {
return bevp_returned;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGet_0() {
return bevp_exception;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {740, 740, 741, 741, 742, 743, 744, 746, 752, 752, 753, 753, 754, 754, 755, 755, 757, 757, 758, 759, 759, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 26, 27, 28, 29, 41, 42, 43, 44, 45, 46, 47, 48, 52, 53, 54, 55, 56, 61, 64, 68, 71, 75, 78, 82, 85, 89, 92};
/* BEGIN LINEINFO 
assign 1 740 22
new 0 740 22
assign 1 740 23
new 1 740 23
assign 1 741 24
new 0 741 24
assign 1 741 25
new 1 741 25
assign 1 742 26
new 0 742 26
assign 1 743 27
new 0 743 27
assign 1 744 28
new 0 744 28
new 1 746 29
assign 1 752 41
new 0 752 41
oSet 1 752 42
assign 1 753 43
main 0 753 43
oSet 1 753 44
assign 1 754 45
new 0 754 45
oSet 1 754 46
assign 1 755 47
new 0 755 47
oSet 1 755 48
assign 1 757 52
new 0 757 52
oSet 1 757 53
oSet 1 758 54
assign 1 759 55
new 0 759 55
oSet 1 759 56
return 1 0 61
assign 1 0 64
return 1 0 68
assign 1 0 71
return 1 0 75
assign 1 0 78
return 1 0 82
assign 1 0 85
return 1 0 89
assign 1 0 92
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -67553672: return bem_exceptionGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case -1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 576066950: return bem_startedGet_0();
case 2078798920: return bem_threwExceptionGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1203772363: return bem_finishedGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 773462359: return bem_toRunGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1821525768: return bem_returnedGet_0();
case 1820417453: return bem_create_0();
case -1897185389: return bem_start_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -795274266: return bem_wait_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 587149203: return bem_startedSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1192690110: return bem_finishedSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 784544612: return bem_toRunSet_1(bevd_0);
case -56471419: return bem_exceptionSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1810443515: return bem_returnedSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 2089881173: return bem_threwExceptionSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemThread_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemThread_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemThread();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst = (BEC_2_6_6_SystemThread)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst;
}
}
}
