namespace be {
/* IO:File: source/base/Tokenize.be */
public sealed class BEC_2_4_9_TextTokenizer : BEC_2_6_6_SystemObject {
public BEC_2_4_9_TextTokenizer() { }
static BEC_2_4_9_TextTokenizer() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_9_TextTokenizer bevs_inst;
public BEC_2_9_3_ContainerMap bevp_tmap;
public BEC_2_5_4_LogicBool bevp_includeTokens;
public BEC_2_4_9_TextTokenizer bem_new_1(BEC_2_4_6_TextString beva_delims) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
this.bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_new_2(BEC_2_4_6_TextString beva_delims, BEC_2_5_4_LogicBool beva__includeTokens) {
bevp_includeTokens = beva__includeTokens;
this.bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokensStringSet_1(BEC_2_4_6_TextString beva_delims) {
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevp_tmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpvar_loop = beva_delims.bem_stringIteratorGet_0();
while (true)
 /* Line: 27 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevl_chi = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_2_tmpvar_phold = bevl_chi.bem_toString_0();
bevp_tmap.bem_put_2(bevl_chi, bevt_2_tmpvar_phold);
} /* Line: 28 */
 else  /* Line: 27 */ {
break;
} /* Line: 27 */
} /* Line: 27 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addToken_1(BEC_2_4_6_TextString beva__delim) {
BEC_2_4_6_TextString bevl_delim = null;
bevl_delim = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_delim.bem_addValue_1(beva__delim);
bevp_tmap.bem_put_2(bevl_delim, beva__delim);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str);
bevt_0_tmpvar_phold = this.bem_tokenizeIterator_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_2(BEC_2_6_6_SystemObject beva_str, BEC_2_6_6_SystemObject beva_tokenAcceptor) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str);
bevt_0_tmpvar_phold = this.bem_tokenizeIterator_2(bevt_1_tmpvar_phold, beva_tokenAcceptor);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_2(BEC_2_6_6_SystemObject beva_i, BEC_2_6_6_SystemObject beva_acceptor) {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 49 */ {
bevt_0_tmpvar_phold = beva_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 49 */ {
beva_i.bemd_1(-1048795675, BEL_4_Base.bevn_next_1, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_3_tmpvar_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevo_0;
if (bevt_3_tmpvar_phold.bevi_int > bevt_4_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_5_tmpvar_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(1573180739, BEL_4_Base.bevn_acceptToken_1, bevt_5_tmpvar_phold);
} /* Line: 54 */
if (bevp_includeTokens.bevi_bool) /* Line: 56 */ {
beva_acceptor.bemd_1(1573180739, BEL_4_Base.bevn_acceptToken_1, bevl_cc);
} /* Line: 57 */
} /* Line: 56 */
 else  /* Line: 59 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 60 */
} /* Line: 52 */
 else  /* Line: 49 */ {
break;
} /* Line: 49 */
} /* Line: 49 */
bevt_7_tmpvar_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpvar_phold = bevo_1;
if (bevt_7_tmpvar_phold.bevi_int > bevt_8_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 63 */ {
bevt_9_tmpvar_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(1573180739, BEL_4_Base.bevn_acceptToken_1, bevt_9_tmpvar_phold);
} /* Line: 64 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_1(BEC_2_6_6_SystemObject beva_i) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 72 */ {
bevt_0_tmpvar_phold = beva_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 72 */ {
beva_i.bemd_1(-1048795675, BEL_4_Base.bevn_next_1, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_3_tmpvar_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevo_2;
if (bevt_3_tmpvar_phold.bevi_int > bevt_4_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevt_5_tmpvar_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 77 */
if (bevp_includeTokens.bevi_bool) /* Line: 79 */ {
bevl_splits.bem_addValue_1(bevl_cc);
} /* Line: 80 */
} /* Line: 79 */
 else  /* Line: 82 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 83 */
} /* Line: 75 */
 else  /* Line: 72 */ {
break;
} /* Line: 72 */
} /* Line: 72 */
bevt_7_tmpvar_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpvar_phold = bevo_3;
if (bevt_7_tmpvar_phold.bevi_int > bevt_8_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevt_9_tmpvar_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_9_tmpvar_phold);
} /* Line: 87 */
return bevl_splits;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGet_0() {
return bevp_tmap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGet_0() {
return bevp_includeTokens;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includeTokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 21, 22, 26, 27, 0, 27, 27, 28, 28, 33, 34, 35, 39, 39, 39, 43, 43, 43, 47, 48, 49, 50, 51, 52, 52, 53, 53, 53, 53, 54, 54, 57, 60, 63, 63, 63, 63, 64, 64, 69, 70, 71, 72, 73, 74, 75, 75, 76, 76, 76, 76, 77, 77, 80, 83, 86, 86, 86, 86, 87, 87, 89, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 21, 22, 30, 31, 31, 34, 36, 37, 38, 48, 49, 50, 56, 57, 58, 63, 64, 65, 81, 82, 85, 87, 88, 89, 94, 95, 96, 97, 102, 103, 104, 107, 111, 118, 119, 120, 125, 126, 127, 146, 147, 148, 151, 153, 154, 155, 160, 161, 162, 163, 168, 169, 170, 173, 177, 184, 185, 186, 191, 192, 193, 195, 198, 201, 205, 208};
/* BEGIN LINEINFO 
assign 1 16 16
new 0 16 16
tokensStringSet 1 17 17
assign 1 21 21
tokensStringSet 1 22 22
assign 1 26 30
new 0 26 30
assign 1 27 31
stringIteratorGet 0 0 31
assign 1 27 34
hasNextGet 0 27 34
assign 1 27 36
nextGet 0 27 36
assign 1 28 37
toString 0 28 37
put 2 28 38
assign 1 33 48
new 0 33 48
addValue 1 34 49
put 2 35 50
assign 1 39 56
new 1 39 56
assign 1 39 57
tokenizeIterator 1 39 57
return 1 39 58
assign 1 43 63
new 1 43 63
assign 1 43 64
tokenizeIterator 2 43 64
return 1 43 65
assign 1 47 81
new 0 47 81
assign 1 48 82
new 0 48 82
assign 1 49 85
hasNextGet 0 49 85
next 1 50 87
assign 1 51 88
get 1 51 88
assign 1 52 89
def 1 52 94
assign 1 53 95
sizeGet 0 53 95
assign 1 53 96
new 0 53 96
assign 1 53 97
greater 1 53 102
assign 1 54 103
extractString 0 54 103
acceptToken 1 54 104
acceptToken 1 57 107
addValue 1 60 111
assign 1 63 118
sizeGet 0 63 118
assign 1 63 119
new 0 63 119
assign 1 63 120
greater 1 63 125
assign 1 64 126
extractString 0 64 126
acceptToken 1 64 127
assign 1 69 146
new 0 69 146
assign 1 70 147
new 0 70 147
assign 1 71 148
new 0 71 148
assign 1 72 151
hasNextGet 0 72 151
next 1 73 153
assign 1 74 154
get 1 74 154
assign 1 75 155
def 1 75 160
assign 1 76 161
sizeGet 0 76 161
assign 1 76 162
new 0 76 162
assign 1 76 163
greater 1 76 168
assign 1 77 169
extractString 0 77 169
addValue 1 77 170
addValue 1 80 173
addValue 1 83 177
assign 1 86 184
sizeGet 0 86 184
assign 1 86 185
new 0 86 185
assign 1 86 186
greater 1 86 191
assign 1 87 192
extractString 0 87 192
addValue 1 87 193
return 1 89 195
return 1 0 198
assign 1 0 201
return 1 0 205
assign 1 0 208
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 436564549: return bem_includeTokensGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case 945147391: return bem_tmapGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 3917833: return bem_tokensStringSet_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 110901677: return bem_tokenize_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 764248970: return bem_addToken_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 447646802: return bem_includeTokensSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 956229644: return bem_tmapSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 530943931: return bem_tokenizeIterator_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 530943932: return bem_tokenizeIterator_2(bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 110901678: return bem_tokenize_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_9_TextTokenizer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_9_TextTokenizer.bevs_inst = (BEC_2_4_9_TextTokenizer)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_9_TextTokenizer.bevs_inst;
}
}
}
