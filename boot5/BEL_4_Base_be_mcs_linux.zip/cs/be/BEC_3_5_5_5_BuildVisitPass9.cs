namespace be {
/* IO:File: source/build/Pass9.be */
public sealed class BEC_3_5_5_5_BuildVisitPass9 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
static BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 44));
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x53,0x45,0x54};
private static byte[] bels_3 = {0x47,0x45,0x54};
private static byte[] bels_4 = {0x53,0x45,0x54};
private static byte[] bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_6 = {0x70,0x75,0x74};
private static byte[] bels_7 = {0x67,0x65,0x74};
private static byte[] bels_8 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bels_9 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_11 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_12 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_13 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_14 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bels_15 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_16 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static new BEC_3_5_5_5_BuildVisitPass9 bevs_inst;
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_5_4_BuildNode bevl_linn = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lany = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_23_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_45_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_50_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_68_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_73_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_74_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_145_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_153_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_154_tmpany_phold = null;
bevt_7_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_8_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_7_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 31 */ {
beva_node.bem_initContained_0();
bevt_9_tmpany_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_9_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 36 */ {
bevt_10_tmpany_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 36 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_13_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 39 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_15_tmpany_phold == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_i.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevt_17_tmpany_phold);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 42 */
 else  /* Line: 43 */ {
bevt_19_tmpany_phold = bevo_0;
bevt_22_tmpany_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_estr = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BECS_ThrowBack(bevt_23_tmpany_phold);
} /* Line: 45 */
} /* Line: 40 */
} /* Line: 39 */
 else  /* Line: 36 */ {
break;
} /* Line: 36 */
} /* Line: 36 */
bevt_24_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_24_tmpany_phold;
} /* Line: 49 */
 else  /* Line: 31 */ {
bevt_26_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
if (bevt_26_tmpany_phold.bevi_int == bevt_27_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_c.bemd_1(-671626972, BEL_4_Base.bevn_wasAccessorSet_1, bevt_28_tmpany_phold);
bevt_31_tmpany_phold = beva_node.bem_containerGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_typenameGet_0();
bevt_32_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_tmpany_phold.bevi_int == bevt_32_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_36_tmpany_phold = beva_node.bem_containerGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_heldGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_37_tmpany_phold);
if (bevt_33_tmpany_phold != null && bevt_33_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_38_tmpany_phold = beva_node.bem_isFirstGet_0();
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_2));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_39_tmpany_phold);
} /* Line: 58 */
 else  /* Line: 59 */ {
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_3));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_40_tmpany_phold);
} /* Line: 60 */
bevt_41_tmpany_phold = bevl_ac.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_41_tmpany_phold);
bevl_c.bemd_0(-173192194, BEL_4_Base.bevn_toAccessorName_0);
bevt_43_tmpany_phold = bevl_c.bemd_0(783669222, BEL_4_Base.bevn_accessorTypeGet_0);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_4));
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_44_tmpany_phold);
if (bevt_42_tmpany_phold != null && bevt_42_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_42_tmpany_phold).bevi_bool) /* Line: 64 */ {
bevt_45_tmpany_phold = beva_node.bem_containerGet_0();
bevt_45_tmpany_phold.bem_heldSet_1(bevl_c);
bevt_46_tmpany_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_46_tmpany_phold.bem_firstGet_0();
bevt_47_tmpany_phold = bevl_ntarg.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_47_tmpany_phold);
bevt_48_tmpany_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_49_tmpany_phold);
bevt_51_tmpany_phold = beva_node.bem_containerGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_nextDescendGet_0();
return bevt_50_tmpany_phold;
} /* Line: 71 */
 else  /* Line: 72 */ {
bevt_52_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_52_tmpany_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 74 */
bevt_53_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_53_tmpany_phold;
} /* Line: 76 */
 else  /* Line: 31 */ {
bevt_55_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_56_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
if (bevt_55_tmpany_phold.bevi_int == bevt_56_tmpany_phold.bevi_int) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_59_tmpany_phold = beva_node.bem_containerGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bem_typenameGet_0();
bevt_60_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_60_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_64_tmpany_phold = beva_node.bem_containerGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_heldGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_5));
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_65_tmpany_phold);
if (bevt_61_tmpany_phold != null && bevt_61_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpany_phold).bevi_bool) /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_66_tmpany_phold = beva_node.bem_isFirstGet_0();
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevl_isPut = be.BECS_Runtime.boolTrue;
} /* Line: 83 */
 else  /* Line: 84 */ {
bevl_isPut = be.BECS_Runtime.boolFalse;
} /* Line: 86 */
if (bevl_isPut != null && bevl_isPut is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_isPut).bevi_bool) /* Line: 88 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_6));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = beva_node.bem_containerGet_0();
bevt_68_tmpany_phold.bem_heldSet_1(bevl_c);
bevt_69_tmpany_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_69_tmpany_phold.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_70_tmpany_phold = bevl_ntarg.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_70_tmpany_phold);
bevt_71_tmpany_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = beva_node.bem_containerGet_0();
bevt_73_tmpany_phold.bem_addValue_1(bevl_narg2);
bevt_74_tmpany_phold = beva_node.bem_containerGet_0();
bevt_74_tmpany_phold.bem_addValue_1(bevl_narg3);
bevt_76_tmpany_phold = beva_node.bem_containerGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_nextDescendGet_0();
return bevt_75_tmpany_phold;
} /* Line: 106 */
 else  /* Line: 107 */ {
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_7));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_78_tmpany_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 114 */
bevt_79_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_79_tmpany_phold;
} /* Line: 116 */
} /* Line: 31 */
} /* Line: 31 */
bevt_81_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_82_tmpany_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_81_tmpany_phold.bevi_int == bevt_82_tmpany_phold.bevi_int) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_85_tmpany_phold = beva_node.bem_containedGet_0();
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bem_firstGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_linn = (BEC_2_5_4_BuildNode) bevt_83_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_87_tmpany_phold = bevl_linn.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevt_90_tmpany_phold = bevl_linn.bem_heldGet_0();
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_0(-1806609680, BEL_4_Base.bevn_wasOperGet_0);
if (bevt_89_tmpany_phold != null && bevt_89_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_89_tmpany_phold).bevi_bool) /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 121 */ {
bevt_91_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
beva_node.bem_typenameSet_1(bevt_91_tmpany_phold);
} /* Line: 123 */
} /* Line: 121 */
bevt_93_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_94_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
if (bevt_93_tmpany_phold.bevi_int == bevt_94_tmpany_phold.bevi_int) {
bevt_92_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_95_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_96_tmpany_phold.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_97_tmpany_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lin = bevt_97_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_98_tmpany_phold = bevl_lin.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lany = bevt_98_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_toit = bevl_lin.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_pnode.bemd_1(443337441, BEL_4_Base.bevn_containedSet_1, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_99_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_8));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_100_tmpany_phold, bevp_build);
bevl_tmpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_101_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_101_tmpany_phold);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gic);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_9));
bevl_gic.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_102_tmpany_phold);
bevt_103_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(666017654, BEL_4_Base.bevn_wasForeachGennedSet_1, bevt_103_tmpany_phold);
bevl_gin.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_104_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_104_tmpany_phold);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asc);
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_10));
bevl_asc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_105_tmpany_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpn);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn);
bevl_tmpn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_106_tmpany_phold);
bevl_tmpnt.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_107_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_107_tmpany_phold);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tcc);
bevt_108_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_11));
bevl_tcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_108_tmpany_phold);
bevl_tcn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpnt);
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_109_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_109_tmpany_phold);
bevl_tmpng.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_110_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_110_tmpany_phold);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iagc);
bevt_111_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_12));
bevl_iagc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_111_tmpany_phold);
bevl_iagn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_112_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_112_tmpany_phold);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iasc);
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_13));
bevl_iasc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_113_tmpany_phold);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lany);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_iagn);
bevl_brnode.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 216 */
bevt_115_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_116_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
if (bevt_115_tmpany_phold.bevi_int == bevt_116_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_117_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_117_tmpany_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_118_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_118_tmpany_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_119_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_119_tmpany_phold);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevt_121_tmpany_phold = beva_node.bem_heldGet_0();
if (bevt_121_tmpany_phold == null) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_123_tmpany_phold = beva_node.bem_heldGet_0();
bevt_124_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_14));
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_124_tmpany_phold);
if (bevt_122_tmpany_phold != null && bevt_122_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_122_tmpany_phold).bevi_bool) /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 230 */
 else  /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 230 */ {
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_15));
bevl_loopif.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_125_tmpany_phold);
} /* Line: 231 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_126_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_126_tmpany_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_127_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_127_tmpany_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_128_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_128_tmpany_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_129_tmpany_phold = bevl_lnode.bemd_0(-1779180144, BEL_4_Base.bevn_nextDescendGet_0);
return (BEC_2_5_4_BuildNode) bevt_129_tmpany_phold;
} /* Line: 245 */
 else  /* Line: 218 */ {
bevt_131_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_132_tmpany_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_131_tmpany_phold.bevi_int == bevt_132_tmpany_phold.bevi_int) {
bevt_130_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_130_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_133_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_133_tmpany_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevt_134_tmpany_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_134_tmpany_phold.bem_firstGet_0();
bevl_pnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_137_tmpany_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_138_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_138_tmpany_phold);
if (bevt_135_tmpany_phold != null && bevt_135_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_135_tmpany_phold).bevi_bool) /* Line: 253 */ {
bevt_140_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bels_16));
bevt_139_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_140_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_139_tmpany_phold);
} /* Line: 254 */
bevt_141_tmpany_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_init = bevt_141_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_cond = bevl_pnode.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_atStep = null;
bevt_144_tmpany_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_143_tmpany_phold = bevt_144_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_145_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_145_tmpany_phold);
if (bevt_142_tmpany_phold != null && bevt_142_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_142_tmpany_phold).bevi_bool) /* Line: 259 */ {
bevl_atStep = bevl_pnode.bemd_0(-978128800, BEL_4_Base.bevn_thirdGet_0);
bevl_atStep.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 261 */
bevl_init.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevl_lnode.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_146_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_146_tmpany_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_147_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_147_tmpany_phold);
bevl_loopif.bemd_1(875977779, BEL_4_Base.bevn_takeContents_1, beva_node);
if (bevl_atStep == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_150_tmpany_phold = bevl_loopif.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_149_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_atStep);
} /* Line: 277 */
bevl_loopif.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_pnode);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_151_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_151_tmpany_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_152_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_152_tmpany_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_153_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_153_tmpany_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 294 */
} /* Line: 218 */
bevt_154_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_154_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {31, 31, 31, 31, 35, 36, 36, 36, 38, 39, 39, 39, 40, 40, 40, 40, 41, 41, 41, 42, 44, 44, 44, 44, 44, 45, 45, 49, 49, 50, 50, 50, 50, 54, 55, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 0, 0, 0, 57, 0, 0, 0, 58, 58, 60, 60, 62, 62, 63, 64, 64, 64, 65, 65, 66, 66, 68, 68, 69, 69, 70, 70, 71, 71, 71, 73, 73, 74, 76, 76, 77, 77, 77, 77, 79, 80, 81, 81, 81, 81, 81, 81, 81, 81, 81, 81, 0, 0, 0, 81, 0, 0, 0, 83, 86, 89, 89, 90, 90, 91, 91, 94, 95, 97, 98, 100, 100, 101, 101, 102, 102, 104, 104, 105, 105, 106, 106, 106, 112, 112, 113, 113, 114, 116, 116, 118, 118, 118, 118, 120, 120, 120, 120, 121, 121, 121, 121, 121, 121, 0, 0, 0, 123, 123, 126, 126, 126, 126, 127, 127, 128, 128, 129, 130, 130, 131, 131, 132, 133, 152, 153, 154, 154, 155, 155, 156, 158, 159, 159, 160, 161, 162, 162, 163, 163, 164, 166, 167, 168, 168, 169, 170, 171, 171, 172, 173, 175, 176, 178, 179, 180, 180, 181, 183, 184, 185, 185, 186, 187, 188, 188, 189, 191, 193, 194, 195, 195, 196, 198, 199, 200, 200, 201, 202, 203, 203, 204, 206, 207, 208, 208, 209, 210, 211, 211, 212, 213, 215, 216, 218, 218, 218, 218, 219, 220, 221, 221, 222, 223, 224, 225, 225, 226, 227, 228, 228, 229, 230, 230, 230, 230, 230, 230, 0, 0, 0, 231, 231, 233, 234, 235, 235, 236, 237, 238, 239, 239, 240, 241, 242, 243, 243, 244, 245, 245, 246, 246, 246, 246, 247, 248, 249, 249, 250, 251, 251, 252, 253, 253, 253, 253, 254, 254, 254, 256, 256, 257, 258, 259, 259, 259, 259, 260, 261, 263, 265, 266, 268, 269, 270, 270, 271, 272, 273, 274, 274, 275, 276, 276, 277, 277, 277, 279, 280, 281, 282, 283, 283, 284, 285, 286, 287, 287, 288, 289, 290, 291, 291, 292, 294, 296, 296};
public static new int[] bevs_smnlec
 = new int[] {221, 222, 223, 228, 229, 230, 231, 234, 236, 237, 238, 239, 241, 242, 243, 248, 249, 250, 251, 252, 255, 256, 257, 258, 259, 260, 261, 269, 270, 273, 274, 275, 280, 281, 282, 283, 284, 285, 286, 287, 288, 293, 294, 295, 296, 297, 298, 300, 303, 307, 310, 312, 315, 319, 322, 323, 326, 327, 329, 330, 331, 332, 333, 334, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 351, 352, 353, 355, 356, 359, 360, 361, 366, 367, 368, 369, 370, 371, 372, 377, 378, 379, 380, 381, 382, 384, 387, 391, 394, 396, 399, 403, 406, 409, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 437, 438, 439, 440, 441, 443, 444, 448, 449, 450, 455, 456, 457, 458, 459, 460, 461, 462, 467, 468, 469, 471, 474, 478, 481, 482, 485, 486, 487, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 575, 576, 577, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 603, 604, 605, 606, 608, 611, 615, 618, 619, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 640, 641, 642, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 661, 662, 663, 665, 666, 667, 668, 669, 670, 671, 672, 674, 675, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 695, 696, 697, 698, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 720, 721};
/* BEGIN LINEINFO 
assign 1 31 221
typenameGet 0 31 221
assign 1 31 222
CALLGet 0 31 222
assign 1 31 223
equals 1 31 228
initContained 0 35 229
assign 1 36 230
containedGet 0 36 230
assign 1 36 231
iteratorGet 0 36 231
assign 1 36 234
hasNextGet 0 36 234
assign 1 38 236
nextGet 0 38 236
assign 1 39 237
typenameGet 0 39 237
assign 1 39 238
PARENSGet 0 39 238
assign 1 39 239
equals 1 39 239
assign 1 40 241
containedGet 0 40 241
assign 1 40 242
firstNodeGet 0 40 242
assign 1 40 243
def 1 40 248
assign 1 41 249
containedGet 0 41 249
assign 1 41 250
firstGet 0 41 250
beforeInsert 1 41 251
delete 0 42 252
assign 1 44 255
new 0 44 255
assign 1 44 256
containedGet 0 44 256
assign 1 44 257
lengthGet 0 44 257
assign 1 44 258
toString 0 44 258
assign 1 44 259
add 1 44 259
assign 1 45 260
new 2 45 260
throw 1 45 261
assign 1 49 269
nextDescendGet 0 49 269
return 1 49 270
assign 1 50 273
typenameGet 0 50 273
assign 1 50 274
ACCESSORGet 0 50 274
assign 1 50 275
equals 1 50 280
assign 1 54 281
heldGet 0 54 281
assign 1 55 282
new 0 55 282
assign 1 56 283
new 0 56 283
wasAccessorSet 1 56 284
assign 1 57 285
containerGet 0 57 285
assign 1 57 286
typenameGet 0 57 286
assign 1 57 287
CALLGet 0 57 287
assign 1 57 288
equals 1 57 293
assign 1 57 294
containerGet 0 57 294
assign 1 57 295
heldGet 0 57 295
assign 1 57 296
nameGet 0 57 296
assign 1 57 297
new 0 57 297
assign 1 57 298
equals 1 57 298
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 57 310
isFirstGet 0 57 310
assign 1 0 312
assign 1 0 315
assign 1 0 319
assign 1 58 322
new 0 58 322
accessorTypeSet 1 58 323
assign 1 60 326
new 0 60 326
accessorTypeSet 1 60 327
assign 1 62 329
nameGet 0 62 329
nameSet 1 62 330
toAccessorName 0 63 331
assign 1 64 332
accessorTypeGet 0 64 332
assign 1 64 333
new 0 64 333
assign 1 64 334
equals 1 64 334
assign 1 65 336
containerGet 0 65 336
heldSet 1 65 337
assign 1 66 338
containedGet 0 66 338
assign 1 66 339
firstGet 0 66 339
assign 1 68 340
typenameGet 0 68 340
typenameSet 1 68 341
assign 1 69 342
heldGet 0 69 342
heldSet 1 69 343
assign 1 70 344
containedGet 0 70 344
containedSet 1 70 345
assign 1 71 346
containerGet 0 71 346
assign 1 71 347
nextDescendGet 0 71 347
return 1 71 348
assign 1 73 351
CALLGet 0 73 351
typenameSet 1 73 352
heldSet 1 74 353
assign 1 76 355
nextDescendGet 0 76 355
return 1 76 356
assign 1 77 359
typenameGet 0 77 359
assign 1 77 360
IDXACCGet 0 77 360
assign 1 77 361
equals 1 77 366
assign 1 79 367
heldGet 0 79 367
assign 1 80 368
new 0 80 368
assign 1 81 369
containerGet 0 81 369
assign 1 81 370
typenameGet 0 81 370
assign 1 81 371
CALLGet 0 81 371
assign 1 81 372
equals 1 81 377
assign 1 81 378
containerGet 0 81 378
assign 1 81 379
heldGet 0 81 379
assign 1 81 380
nameGet 0 81 380
assign 1 81 381
new 0 81 381
assign 1 81 382
equals 1 81 382
assign 1 0 384
assign 1 0 387
assign 1 0 391
assign 1 81 394
isFirstGet 0 81 394
assign 1 0 396
assign 1 0 399
assign 1 0 403
assign 1 83 406
new 0 83 406
assign 1 86 409
new 0 86 409
assign 1 89 412
new 0 89 412
nameSet 1 89 413
assign 1 90 414
containerGet 0 90 414
heldSet 1 90 415
assign 1 91 416
containedGet 0 91 416
assign 1 91 417
firstGet 0 91 417
assign 1 94 418
nextPeerGet 0 94 418
assign 1 95 419
nextPeerGet 0 95 419
delete 0 97 420
delete 0 98 421
assign 1 100 422
typenameGet 0 100 422
typenameSet 1 100 423
assign 1 101 424
heldGet 0 101 424
heldSet 1 101 425
assign 1 102 426
containedGet 0 102 426
containedSet 1 102 427
assign 1 104 428
containerGet 0 104 428
addValue 1 104 429
assign 1 105 430
containerGet 0 105 430
addValue 1 105 431
assign 1 106 432
containerGet 0 106 432
assign 1 106 433
nextDescendGet 0 106 433
return 1 106 434
assign 1 112 437
new 0 112 437
nameSet 1 112 438
assign 1 113 439
CALLGet 0 113 439
typenameSet 1 113 440
heldSet 1 114 441
assign 1 116 443
nextDescendGet 0 116 443
return 1 116 444
assign 1 118 448
typenameGet 0 118 448
assign 1 118 449
FORGet 0 118 449
assign 1 118 450
equals 1 118 455
assign 1 120 456
containedGet 0 120 456
assign 1 120 457
firstGet 0 120 457
assign 1 120 458
containedGet 0 120 458
assign 1 120 459
firstGet 0 120 459
assign 1 121 460
typenameGet 0 121 460
assign 1 121 461
CALLGet 0 121 461
assign 1 121 462
equals 1 121 467
assign 1 121 468
heldGet 0 121 468
assign 1 121 469
wasOperGet 0 121 469
assign 1 0 471
assign 1 0 474
assign 1 0 478
assign 1 123 481
FOREACHGet 0 123 481
typenameSet 1 123 482
assign 1 126 485
typenameGet 0 126 485
assign 1 126 486
FOREACHGet 0 126 486
assign 1 126 487
equals 1 126 492
assign 1 127 493
WHILEGet 0 127 493
typenameSet 1 127 494
assign 1 128 495
containedGet 0 128 495
assign 1 128 496
firstGet 0 128 496
assign 1 129 497
secondGet 0 129 497
assign 1 130 498
containedGet 0 130 498
assign 1 130 499
firstGet 0 130 499
assign 1 131 500
containedGet 0 131 500
assign 1 131 501
firstGet 0 131 501
assign 1 132 502
secondGet 0 132 502
containedSet 1 133 503
assign 1 152 504
new 1 152 504
copyLoc 1 153 505
assign 1 154 506
VARGet 0 154 506
typenameSet 1 154 507
assign 1 155 508
new 0 155 508
assign 1 155 509
tmpVar 2 155 509
heldSet 1 156 510
assign 1 158 511
new 1 158 511
assign 1 159 512
CALLGet 0 159 512
typenameSet 1 159 513
assign 1 160 514
new 0 160 514
heldSet 1 161 515
assign 1 162 516
new 0 162 516
nameSet 1 162 517
assign 1 163 518
new 0 163 518
wasForeachGennedSet 1 163 519
addValue 1 164 520
assign 1 166 521
new 1 166 521
copyLoc 1 167 522
assign 1 168 523
CALLGet 0 168 523
typenameSet 1 168 524
assign 1 169 525
new 0 169 525
heldSet 1 170 526
assign 1 171 527
new 0 171 527
nameSet 1 171 528
addValue 1 172 529
addValue 1 173 530
beforeInsert 1 175 531
addVariable 0 176 532
assign 1 178 533
new 1 178 533
copyLoc 1 179 534
assign 1 180 535
VARGet 0 180 535
typenameSet 1 180 536
heldSet 1 181 537
assign 1 183 538
new 1 183 538
copyLoc 1 184 539
assign 1 185 540
CALLGet 0 185 540
typenameSet 1 185 541
assign 1 186 542
new 0 186 542
heldSet 1 187 543
assign 1 188 544
new 0 188 544
nameSet 1 188 545
addValue 1 189 546
addValue 1 191 547
assign 1 193 548
new 1 193 548
copyLoc 1 194 549
assign 1 195 550
VARGet 0 195 550
typenameSet 1 195 551
heldSet 1 196 552
assign 1 198 553
new 1 198 553
copyLoc 1 199 554
assign 1 200 555
CALLGet 0 200 555
typenameSet 1 200 556
assign 1 201 557
new 0 201 557
heldSet 1 202 558
assign 1 203 559
new 0 203 559
nameSet 1 203 560
addValue 1 204 561
assign 1 206 562
new 1 206 562
copyLoc 1 207 563
assign 1 208 564
CALLGet 0 208 564
typenameSet 1 208 565
assign 1 209 566
new 0 209 566
heldSet 1 210 567
assign 1 211 568
new 0 211 568
nameSet 1 211 569
addValue 1 212 570
addValue 1 213 571
prepend 1 215 572
return 1 216 573
assign 1 218 575
typenameGet 0 218 575
assign 1 218 576
WHILEGet 0 218 576
assign 1 218 577
equals 1 218 582
assign 1 219 583
new 1 219 583
copyLoc 1 220 584
assign 1 221 585
LOOPGet 0 221 585
typenameSet 1 221 586
replaceWith 1 222 587
assign 1 223 588
new 1 223 588
copyLoc 1 224 589
assign 1 225 590
BRACESGet 0 225 590
typenameSet 1 225 591
addValue 1 226 592
assign 1 227 593
assign 1 228 594
IFGet 0 228 594
typenameSet 1 228 595
addValue 1 229 596
assign 1 230 597
heldGet 0 230 597
assign 1 230 598
def 1 230 603
assign 1 230 604
heldGet 0 230 604
assign 1 230 605
new 0 230 605
assign 1 230 606
equals 1 230 606
assign 1 0 608
assign 1 0 611
assign 1 0 615
assign 1 231 618
new 0 231 618
heldSet 1 231 619
assign 1 233 621
new 1 233 621
copyLoc 1 234 622
assign 1 235 623
ELSEGet 0 235 623
typenameSet 1 235 624
addValue 1 236 625
assign 1 237 626
new 1 237 626
copyLoc 1 238 627
assign 1 239 628
BRACESGet 0 239 628
typenameSet 1 239 629
addValue 1 240 630
assign 1 241 631
new 1 241 631
copyLoc 1 242 632
assign 1 243 633
BREAKGet 0 243 633
typenameSet 1 243 634
addValue 1 244 635
assign 1 245 636
nextDescendGet 0 245 636
return 1 245 637
assign 1 246 640
typenameGet 0 246 640
assign 1 246 641
FORGet 0 246 641
assign 1 246 642
equals 1 246 647
assign 1 247 648
new 1 247 648
copyLoc 1 248 649
assign 1 249 650
LOOPGet 0 249 650
typenameSet 1 249 651
replaceWith 1 250 652
assign 1 251 653
containedGet 0 251 653
assign 1 251 654
firstGet 0 251 654
delete 0 252 655
assign 1 253 656
containedGet 0 253 656
assign 1 253 657
lengthGet 0 253 657
assign 1 253 658
new 0 253 658
assign 1 253 659
lesser 1 253 659
assign 1 254 661
new 0 254 661
assign 1 254 662
new 2 254 662
throw 1 254 663
assign 1 256 665
containedGet 0 256 665
assign 1 256 666
firstGet 0 256 666
assign 1 257 667
secondGet 0 257 667
assign 1 258 668
assign 1 259 669
containedGet 0 259 669
assign 1 259 670
lengthGet 0 259 670
assign 1 259 671
new 0 259 671
assign 1 259 672
greater 1 259 672
assign 1 260 674
thirdGet 0 260 674
delete 0 261 675
delete 0 263 677
replaceWith 1 265 678
beforeInsert 1 266 679
assign 1 268 680
new 1 268 680
copyLoc 1 269 681
assign 1 270 682
BRACESGet 0 270 682
typenameSet 1 270 683
addValue 1 271 684
assign 1 272 685
new 1 272 685
copyLoc 1 273 686
assign 1 274 687
IFGet 0 274 687
typenameSet 1 274 688
takeContents 1 275 689
assign 1 276 690
def 1 276 695
assign 1 277 696
containedGet 0 277 696
assign 1 277 697
firstGet 0 277 697
addValue 1 277 698
prepend 1 279 700
addValue 1 280 701
assign 1 281 702
new 1 281 702
copyLoc 1 282 703
assign 1 283 704
ELSEGet 0 283 704
typenameSet 1 283 705
addValue 1 284 706
assign 1 285 707
new 1 285 707
copyLoc 1 286 708
assign 1 287 709
BRACESGet 0 287 709
typenameSet 1 287 710
addValue 1 288 711
assign 1 289 712
new 1 289 712
copyLoc 1 290 713
assign 1 291 714
BREAKGet 0 291 714
typenameSet 1 291 715
addValue 1 292 716
return 1 294 717
assign 1 296 720
nextDescendGet 0 296 720
return 1 296 721
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass9.bevs_inst = (BEC_3_5_5_5_BuildVisitPass9)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass9.bevs_inst;
}
}
}
