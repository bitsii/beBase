namespace be {

using System;
using System.Diagnostics;
/* IO:File: source/extended/Command.be */
public sealed class BEC_2_6_7_SystemCommand : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }
static BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_0 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_7_SystemCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_7_SystemCommand_bels_0, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemCommand_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemCommand_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_1 = {};
public static new BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;
public BEC_2_4_6_TextString bevp_command;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
this.bem_new_1(beva__command);
bevt_0_tmpany_phold = this.bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
 /* Line: 50 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_0;
bevl_sp = bevp_command.bem_find_1(bevt_0_tmpany_phold);
if (bevl_sp == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_1;
bevl_cmdRun = bevp_command.bem_substring_2(bevt_2_tmpany_phold, bevl_sp);
bevt_4_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_2;
bevt_3_tmpany_phold = bevl_sp.bem_add_1(bevt_4_tmpany_phold);
bevl_cmdArgs = bevp_command.bem_substring_1(bevt_3_tmpany_phold);
} /* Line: 54 */
 else  /* Line: 55 */ {
bevl_cmdRun = bevp_command;
bevl_cmdArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_1));
} /* Line: 57 */

          bevi_p = new Process();
          bevi_p.StartInfo.FileName = bevl_cmdRun.bems_toCsString();
          bevi_p.StartInfo.Arguments = bevl_cmdArgs.bems_toCsString();
          bevi_p.StartInfo.CreateNoWindow = true;
          bevi_p.StartInfo.UseShellExecute = false;
          bevi_p.StartInfo.RedirectStandardOutput = true;   
          //bevi_p.StartInfo.WorkingDirectory = strWorkingDirectory;
          bevi_p.Start();
          //bevi_p.StandardOutput.ReadToEnd();
          //bevi_p.WaitForExit();
          } /* Line: 61 */
return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() {
this.bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 93 */ {
return bevp_outputReader;
} /* Line: 94 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.StandardOutput.BaseStream;
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 114 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() {
this.bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {38, 43, 44, 44, 51, 51, 52, 52, 53, 53, 54, 54, 54, 56, 57, 82, 86, 93, 93, 94, 96, 107, 108, 112, 112, 113, 114, 119, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 27, 28, 29, 42, 43, 44, 49, 50, 51, 52, 53, 54, 57, 58, 72, 75, 80, 85, 86, 88, 91, 92, 96, 101, 102, 103, 108, 114, 117, 121, 124};
/* BEGIN LINEINFO 
assign 1 38 22
new 1 43 27
assign 1 44 28
run 0 44 28
return 1 44 29
assign 1 51 42
new 0 51 42
assign 1 51 43
find 1 51 43
assign 1 52 44
def 1 52 49
assign 1 53 50
new 0 53 50
assign 1 53 51
substring 2 53 51
assign 1 54 52
new 0 54 52
assign 1 54 53
add 1 54 53
assign 1 54 54
substring 1 54 54
assign 1 56 57
assign 1 57 58
new 0 57 58
return 1 82 72
run 0 86 75
assign 1 93 80
def 1 93 85
return 1 94 86
assign 1 96 88
new 0 96 88
extOpen 0 107 91
return 1 108 92
assign 1 112 96
def 1 112 101
close 0 113 102
assign 1 114 103
closeOutput 0 119 108
return 1 0 114
assign 1 0 117
return 1 0 121
assign 1 0 124
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 108875644: return bem_run_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 866536361: return bem_close_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -847016698: return bem_outputGet_0();
case 1933649148: return bem_commandGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1849988413: return bem_outputReaderGet_0();
case -1010579589: return bem_open_0();
case 1322103434: return bem_closeOutput_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 108875645: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case 1944731401: return bem_commandSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1838906160: return bem_outputReaderSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
}
}
