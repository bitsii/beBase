namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_6_BuildMethod : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
static BEC_2_5_6_BuildMethod() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 1));
private static byte[] bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 7));
private static byte[] bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 10));
public static new BEC_2_5_6_BuildMethod bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_tryDepth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_amax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_hmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_mmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_classNameGet_0();
bevt_1_tmpany_phold = bevo_0;
bevl_ret = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
if (bevp_name == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevt_4_tmpany_phold = bevo_1;
bevt_3_tmpany_phold = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 186 */
if (bevp_numargs == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevt_8_tmpany_phold = bevo_2;
bevt_7_tmpany_phold = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
} /* Line: 189 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() {
return bevp_property;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() {
return bevp_rtype;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() {
return bevp_tmpVars;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_6_6_SystemObject bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() {
return bevp_tryDepth;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() {
return bevp_amax;
} /*method end*/
public BEC_2_6_6_SystemObject bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() {
return bevp_hmax;
} /*method end*/
public BEC_2_6_6_SystemObject bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() {
return bevp_mmax;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {169, 170, 171, 172, 173, 174, 176, 177, 178, 184, 184, 184, 185, 185, 186, 186, 186, 186, 188, 188, 189, 189, 189, 189, 191, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {31, 32, 33, 34, 35, 36, 37, 38, 39, 54, 55, 56, 57, 62, 63, 64, 65, 66, 68, 73, 74, 75, 76, 77, 79, 82, 85, 89, 92, 96, 99, 103, 106, 110, 113, 117, 120, 124, 127, 131, 134, 138, 141, 145, 148, 152, 155, 159, 162, 166, 169, 173, 176, 180, 183};
/* BEGIN LINEINFO 
assign 1 169 31
new 0 169 31
assign 1 170 32
new 0 170 32
assign 1 171 33
new 0 171 33
assign 1 172 34
new 0 172 34
assign 1 173 35
new 0 173 35
assign 1 174 36
new 0 174 36
assign 1 176 37
new 0 176 37
assign 1 177 38
new 0 177 38
assign 1 178 39
new 0 178 39
assign 1 184 54
classNameGet 0 184 54
assign 1 184 55
new 0 184 55
assign 1 184 56
add 1 184 56
assign 1 185 57
def 1 185 62
assign 1 186 63
new 0 186 63
assign 1 186 64
add 1 186 64
assign 1 186 65
toString 0 186 65
assign 1 186 66
add 1 186 66
assign 1 188 68
def 1 188 73
assign 1 189 74
new 0 189 74
assign 1 189 75
add 1 189 75
assign 1 189 76
toString 0 189 76
assign 1 189 77
add 1 189 77
return 1 191 79
return 1 0 82
assign 1 0 85
return 1 0 89
assign 1 0 92
return 1 0 96
assign 1 0 99
return 1 0 103
assign 1 0 106
return 1 0 110
assign 1 0 113
return 1 0 117
assign 1 0 120
return 1 0 124
assign 1 0 127
return 1 0 131
assign 1 0 134
return 1 0 138
assign 1 0 141
return 1 0 145
assign 1 0 148
return 1 0 152
assign 1 0 155
return 1 0 159
assign 1 0 162
return 1 0 166
assign 1 0 169
return 1 0 173
assign 1 0 176
return 1 0 180
assign 1 0 183
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1669043359: return bem_tryDepthGet_0();
case -1081412016: return bem_many_0();
case 1714571098: return bem_isGenAccessorGet_0();
case 1081760974: return bem_orderedVarsGet_0();
case -2084785257: return bem_anyMapGet_0();
case 230507477: return bem_tmpCntGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 1211273660: return bem_nameGet_0();
case -786424307: return bem_tagGet_0();
case 287367803: return bem_isFinalGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -430935493: return bem_rtypeGet_0();
case -1308786538: return bem_echo_0();
case 1156077028: return bem_amaxGet_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -1391492296: return bem_orgNameGet_0();
case 1143714660: return bem_tmpVarsGet_0();
case -1041978190: return bem_propertyGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -548714012: return bem_numargsGet_0();
case -729571811: return bem_serializeToString_0();
case 941459952: return bem_mmaxGet_0();
case 1388797675: return bem_hmaxGet_0();
case -1354714650: return bem_copy_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1092843227: return bem_orderedVarsSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1030895937: return bem_propertySet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case -1380410043: return bem_orgNameSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -537631759: return bem_numargsSet_1(bevd_0);
case -2073703004: return bem_anyMapSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1680125612: return bem_tryDepthSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 1725653351: return bem_isGenAccessorSet_1(bevd_0);
case 952542205: return bem_mmaxSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 241589730: return bem_tmpCntSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1154796913: return bem_tmpVarsSet_1(bevd_0);
case 1399879928: return bem_hmaxSet_1(bevd_0);
case 1167159281: return bem_amaxSet_1(bevd_0);
case -419853240: return bem_rtypeSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildMethod.bevs_inst = (BEC_2_5_6_BuildMethod)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildMethod.bevs_inst;
}
}
}
