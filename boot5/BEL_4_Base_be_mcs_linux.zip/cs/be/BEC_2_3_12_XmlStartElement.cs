namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_12_XmlStartElement : BEC_2_3_3_XmlTag {
public BEC_2_3_12_XmlStartElement() { }
static BEC_2_3_12_XmlStartElement() { }
private static byte[] becc_BEC_2_3_12_XmlStartElement_clname = {0x58,0x6D,0x6C,0x3A,0x53,0x74,0x61,0x72,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_12_XmlStartElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_1 = {0x20};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_2 = {0x3D};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_3 = {0x2F,0x3E};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_4 = {0x3E};
public static new BEC_2_3_12_XmlStartElement bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_6_TextString bevp_attName;
public BEC_2_9_3_ContainerMap bevp_attributes;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_addAttributeName_1(BEC_2_4_6_TextString beva_pname) {
bevp_attName = beva_pname;
return this;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_addAttributeValue_1(BEC_2_4_6_TextString beva_pval) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_attributes == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevp_attributes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 45 */
bevp_attributes.bem_put_2(bevp_attName, beva_pval);
bevp_attName = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_6_6_SystemObject bevl_entry = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_0));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevl_accum.bem_addValue_1(bevt_2_tmpany_phold);
bevt_1_tmpany_phold.bem_addValue_1(bevp_name);
if (bevp_attributes == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 54 */ {
bevt_4_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_q = bevt_4_tmpany_phold.bem_quoteGet_0();
bevt_0_tmpany_loop = bevp_attributes.bem_mapIteratorGet_0();
while (true)
 /* Line: 56 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevl_entry = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_1));
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevl_accum.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevl_entry.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_2));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevl_q);
bevt_14_tmpany_phold = bevl_entry.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevl_q);
} /* Line: 57 */
 else  /* Line: 56 */ {
break;
} /* Line: 56 */
} /* Line: 56 */
} /* Line: 56 */
if (bevp_isClosed.bevi_bool) /* Line: 60 */ {
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_12_XmlStartElement_bels_3));
bevl_accum.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_4));
bevl_accum.bem_addValue_1(bevt_16_tmpany_phold);
} /* Line: 63 */
bevt_17_tmpany_phold = bevl_accum.bem_extractString_0();
return bevt_17_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isClosedGet_0() {
return bevp_isClosed;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_attNameGet_0() {
return bevp_attName;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_attNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_attName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_attributesGet_0() {
return bevp_attributes;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_attributesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_attributes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {39, 44, 44, 45, 47, 48, 52, 53, 53, 53, 54, 54, 55, 55, 56, 0, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 61, 61, 63, 63, 65, 65, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 27, 32, 33, 35, 36, 61, 62, 63, 64, 65, 70, 71, 72, 73, 73, 76, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 96, 97, 100, 101, 103, 104, 107, 110, 114, 117, 121, 124, 128, 131};
/* BEGIN LINEINFO 
assign 1 39 22
assign 1 44 27
undef 1 44 32
assign 1 45 33
new 0 45 33
put 2 47 35
assign 1 48 36
assign 1 52 61
new 0 52 61
assign 1 53 62
new 0 53 62
assign 1 53 63
addValue 1 53 63
addValue 1 53 64
assign 1 54 65
def 1 54 70
assign 1 55 71
new 0 55 71
assign 1 55 72
quoteGet 0 55 72
assign 1 56 73
mapIteratorGet 0 0 73
assign 1 56 76
hasNextGet 0 56 76
assign 1 56 78
nextGet 0 56 78
assign 1 57 79
new 0 57 79
assign 1 57 80
addValue 1 57 80
assign 1 57 81
keyGet 0 57 81
assign 1 57 82
addValue 1 57 82
assign 1 57 83
new 0 57 83
assign 1 57 84
addValue 1 57 84
assign 1 57 85
addValue 1 57 85
assign 1 57 86
valueGet 0 57 86
assign 1 57 87
addValue 1 57 87
addValue 1 57 88
assign 1 61 96
new 0 61 96
addValue 1 61 97
assign 1 63 100
new 0 63 100
addValue 1 63 101
assign 1 65 103
extractString 0 65 103
return 1 65 104
return 1 0 107
assign 1 0 110
return 1 0 114
assign 1 0 117
return 1 0 121
assign 1 0 124
return 1 0 128
assign 1 0 131
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -142491024: return bem_attributesGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -757294053: return bem_attNameGet_0();
case 1820417453: return bem_create_0();
case -792269839: return bem_isClosedGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case 1211273660: return bem_nameGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -746211800: return bem_attNameSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1728116136: return bem_addAttributeName_1((BEC_2_4_6_TextString) bevd_0);
case -781187586: return bem_isClosedSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 772629864: return bem_addAttributeValue_1((BEC_2_4_6_TextString) bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -131408771: return bem_attributesSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_3_12_XmlStartElement_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_12_XmlStartElement_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_12_XmlStartElement();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_12_XmlStartElement.bevs_inst = (BEC_2_3_12_XmlStartElement)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_12_XmlStartElement.bevs_inst;
}
}
}
