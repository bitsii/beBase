namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_4_BuildCall : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildCall() { }
static BEC_2_5_4_BuildCall() { }
private static byte[] becc_BEC_2_5_4_BuildCall_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C};
private static byte[] becc_BEC_2_5_4_BuildCall_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_0, 7));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_1 = {0x20,0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_1, 10));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_2, 10));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_3 = {0x20,0x6E,0x6F,0x74,0x42,0x6F,0x75,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_3, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_4 = {0x20,0x77,0x61,0x73,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_4, 12));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_5 = {0x47,0x45,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_5, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_6 = {0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_6, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_7 = {0x53,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_7, 3));
public static new BEC_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_6_TextString bevp_accessorType;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_literalValue;
public BEC_2_5_8_BuildNamePath bevp_newNp;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_2_5_4_LogicBool bevp_isConstruct;
public BEC_2_5_4_LogicBool bevp_bound;
public BEC_2_5_4_LogicBool bevp_wasBound;
public BEC_2_5_4_LogicBool bevp_wasAccessor;
public BEC_2_5_4_LogicBool bevp_wasOper;
public BEC_2_5_4_LogicBool bevp_isLiteral;
public BEC_2_5_4_LogicBool bevp_isOnce;
public BEC_2_5_4_LogicBool bevp_isMany;
public BEC_2_5_4_LogicBool bevp_checkTypes;
public BEC_2_5_4_LogicBool bevp_superCall;
public BEC_2_5_4_LogicBool bevp_wasImpliedConstruct;
public BEC_2_5_4_LogicBool bevp_wasForeachGenned;
public BEC_2_5_4_LogicBool bevp_untyped;
public BEC_2_5_4_LogicBool bevp_isForward;
public BEC_2_9_4_ContainerList bevp_argCasts;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isConstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_bound = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_wasBound = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_wasAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasOper = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isLiteral = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isOnce = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isMany = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_checkTypes = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_superCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_untyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isForward = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_argCasts = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevl_ret = this.bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 324 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 325 */
if (bevp_orgName == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_orgName.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 328 */
if (bevp_numargs == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_2;
bevt_9_tmpany_phold = bevl_ret.bem_add_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
} /* Line: 331 */
if (bevp_bound.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 333 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_13_tmpany_phold);
} /* Line: 334 */
if (bevp_wasAccessor.bevi_bool) /* Line: 336 */ {
bevt_14_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_14_tmpany_phold);
} /* Line: 337 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildCall bem_toAccessorName_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_5;
bevt_0_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_6;
bevp_name = bevp_name.bem_add_1(bevt_2_tmpany_phold);
} /* Line: 344 */
 else  /* Line: 345 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_7;
bevp_name = bevp_name.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 346 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGet_0() {
return bevp_accessorType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGet_0() {
return bevp_literalValue;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGet_0() {
return bevp_newNp;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGet_0() {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGet_0() {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGet_0() {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGet_0() {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGet_0() {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGet_0() {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOnceGet_0() {
return bevp_isOnce;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isOnceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isManyGet_0() {
return bevp_isMany;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isManySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGet_0() {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGet_0() {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGet_0() {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGet_0() {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGet_0() {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGet_0() {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGet_0() {
return bevp_argCasts;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 316, 323, 324, 324, 325, 325, 325, 325, 327, 327, 328, 328, 328, 328, 330, 330, 331, 331, 331, 331, 333, 333, 334, 334, 337, 337, 339, 343, 343, 344, 344, 346, 346, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 82, 83, 88, 89, 90, 91, 92, 94, 99, 100, 101, 102, 103, 105, 110, 111, 112, 113, 114, 116, 121, 122, 123, 126, 127, 129, 136, 137, 139, 140, 143, 144, 149, 152, 156, 159, 163, 166, 170, 173, 177, 180, 184, 187, 191, 194, 198, 201, 205, 208, 212, 215, 219, 222, 226, 229, 233, 236, 240, 243, 247, 250, 254, 257, 261, 264, 268, 271, 275, 278, 282, 285, 289, 292, 296, 299};
/* BEGIN LINEINFO 
assign 1 301 48
new 0 301 48
assign 1 302 49
new 0 302 49
assign 1 303 50
new 0 303 50
assign 1 304 51
new 0 304 51
assign 1 305 52
new 0 305 52
assign 1 306 53
new 0 306 53
assign 1 307 54
new 0 307 54
assign 1 308 55
new 0 308 55
assign 1 309 56
new 0 309 56
assign 1 310 57
new 0 310 57
assign 1 311 58
new 0 311 58
assign 1 312 59
new 0 312 59
assign 1 313 60
new 0 313 60
assign 1 314 61
new 0 314 61
assign 1 316 62
new 0 316 62
assign 1 323 82
classNameGet 0 323 82
assign 1 324 83
def 1 324 88
assign 1 325 89
new 0 325 89
assign 1 325 90
add 1 325 90
assign 1 325 91
toString 0 325 91
assign 1 325 92
add 1 325 92
assign 1 327 94
def 1 327 99
assign 1 328 100
new 0 328 100
assign 1 328 101
add 1 328 101
assign 1 328 102
toString 0 328 102
assign 1 328 103
add 1 328 103
assign 1 330 105
def 1 330 110
assign 1 331 111
new 0 331 111
assign 1 331 112
add 1 331 112
assign 1 331 113
toString 0 331 113
assign 1 331 114
add 1 331 114
assign 1 333 116
not 0 333 121
assign 1 334 122
new 0 334 122
assign 1 334 123
add 1 334 123
assign 1 337 126
new 0 337 126
assign 1 337 127
add 1 337 127
return 1 339 129
assign 1 343 136
new 0 343 136
assign 1 343 137
equals 1 343 137
assign 1 344 139
new 0 344 139
assign 1 344 140
add 1 344 140
assign 1 346 143
new 0 346 143
assign 1 346 144
add 1 346 144
return 1 0 149
assign 1 0 152
return 1 0 156
assign 1 0 159
return 1 0 163
assign 1 0 166
return 1 0 170
assign 1 0 173
return 1 0 177
assign 1 0 180
return 1 0 184
assign 1 0 187
return 1 0 191
assign 1 0 194
return 1 0 198
assign 1 0 201
return 1 0 205
assign 1 0 208
return 1 0 212
assign 1 0 215
return 1 0 219
assign 1 0 222
return 1 0 226
assign 1 0 229
return 1 0 233
assign 1 0 236
return 1 0 240
assign 1 0 243
return 1 0 247
assign 1 0 250
return 1 0 254
assign 1 0 257
return 1 0 261
assign 1 0 264
return 1 0 268
assign 1 0 271
return 1 0 275
assign 1 0 278
return 1 0 282
assign 1 0 285
return 1 0 289
assign 1 0 292
return 1 0 296
assign 1 0 299
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 202317754: return bem_isConstructGet_0();
case -1806609680: return bem_wasOperGet_0();
case 1362267230: return bem_isManyGet_0();
case 1018900425: return bem_argCastsGet_0();
case -1062633460: return bem_isForwardGet_0();
case 783669222: return bem_accessorTypeGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1087506597: return bem_literalValueGet_0();
case 1820417453: return bem_create_0();
case 1569395810: return bem_isLiteralGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case -173192194: return bem_toAccessorName_0();
case -1308786538: return bem_echo_0();
case 1143663254: return bem_untypedGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1583922395: return bem_newNpGet_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case -735901070: return bem_wasBoundGet_0();
case 650919759: return bem_wasImpliedConstructGet_0();
case -1319292247: return bem_boundGet_0();
case 1478834556: return bem_isOnceGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1211273660: return bem_nameGet_0();
case 654935401: return bem_wasForeachGennedGet_0();
case -1012494862: return bem_once_0();
case -1391492296: return bem_orgNameGet_0();
case 655314870: return bem_checkTypesGet_0();
case 287040793: return bem_hashGet_0();
case -682709225: return bem_wasAccessorGet_0();
case -1081412016: return bem_many_0();
case -548714012: return bem_numargsGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case -1796577138: return bem_superCallGet_0();
case -845792839: return bem_iteratorGet_0();
case -314718434: return bem_print_0();
case -2128364298: return bem_cposGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -1279784069: return bem_defined_1(bevd_0);
case 1029982678: return bem_argCastsSet_1(bevd_0);
case -1795527427: return bem_wasOperSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2117282045: return bem_cposSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 794751475: return bem_accessorTypeSet_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case 666017654: return bem_wasForeachGennedSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1098588850: return bem_literalValueSet_1(bevd_0);
case -671626972: return bem_wasAccessorSet_1(bevd_0);
case 662002012: return bem_wasImpliedConstructSet_1(bevd_0);
case 213400007: return bem_isConstructSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1308209994: return bem_boundSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1580478063: return bem_isLiteralSet_1(bevd_0);
case -724818817: return bem_wasBoundSet_1(bevd_0);
case 1154745507: return bem_untypedSet_1(bevd_0);
case -537631759: return bem_numargsSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1380410043: return bem_orgNameSet_1(bevd_0);
case -1572840142: return bem_newNpSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1051551207: return bem_isForwardSet_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1489916809: return bem_isOnceSet_1(bevd_0);
case 1373349483: return bem_isManySet_1(bevd_0);
case 666397123: return bem_checkTypesSet_1(bevd_0);
case -1785494885: return bem_superCallSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildCall_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildCall_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildCall();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst = (BEC_2_5_4_BuildCall) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst;
}
}
}
