namespace be {
/* IO:File: source/build/Nodes.be */
public sealed class BEC_2_5_4_BuildNode : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
static BEC_2_5_4_BuildNode() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C};
private static byte[] bels_1 = {0x3E};
private static byte[] bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_5 = {0x20};
private static byte[] bels_6 = {0x3C};
private static byte[] bels_7 = {0x3E};
private static byte[] bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 7));
private static byte[] bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 8));
private static byte[] bels_10 = {0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 1));
private static byte[] bels_11 = {0x20,0x20};
private static byte[] bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bels_13 = {0x5F,0x74,0x6D,0x70,0x76,0x61,0x72,0x5F};
private static byte[] bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 18));
private static byte[] bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_2_9_3_ContainerSet bevo_4;
private static BEC_2_9_3_ContainerSet bevo_5;
private static BEC_2_9_3_ContainerSet bevo_6;
private static BEC_2_9_3_ContainerSet bevo_7;
private static BEC_2_9_3_ContainerSet bevo_8;
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_2_5_4_BuildNode bevs_inst;
public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_6_6_SystemObject bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condvar;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_nlec = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_wideString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpvar_phold.bem_copy_0();
bevt_1_tmpvar_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 47 */ {
bevt_4_tmpvar_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 47 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 47 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 47 */
 else  /* Line: 47 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 47 */ {
bevt_5_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_tmpvar_phold;
} /* Line: 48 */
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 52 */ {
if (bevl_ret == null) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 52 */ {
if (bevl_con == null) {
bevt_7_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 54 */
 else  /* Line: 52 */ {
break;
} /* Line: 52 */
} /* Line: 52 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 62 */ {
if (bevl_ret == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 62 */ {
if (bevl_con == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 62 */
 else  /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 62 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 64 */
 else  /* Line: 62 */ {
break;
} /* Line: 62 */
} /* Line: 62 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 70 */ {
return null;
} /* Line: 71 */
bevl_hh = bevp_heldBy.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 74 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 75 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_2_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 81 */ {
return null;
} /* Line: 82 */
bevl_hh = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 85 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 86 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_2_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 105 */
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 111 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 112 */
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 118 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_4_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 118 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 118 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 118 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 118 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 118 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 118 */ {
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 119 */
bevt_12_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_10_tmpvar_phold == null) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delayDelete_0() {
bevp_delayDelete = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 129 */ {
return null;
} /* Line: 130 */
bevp_heldBy.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 138 */ {
return null;
} /* Line: 139 */
bevt_2_tmpvar_phold = bevp_heldBy.bemd_0(-1849179299, BEL_4_Base.bevn_mylistGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(-743891212, BEL_4_Base.bevn_newNode_1, beva_x);
bevp_heldBy.bemd_1(-1505376950, BEL_4_Base.bevn_insertBefore_1, bevt_1_tmpvar_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepend_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 146 */ {
this.bem_initContained_0();
} /* Line: 147 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addValue_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 154 */ {
this.bem_initContained_0();
} /* Line: 155 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_reInitContained_0() {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initContained_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 167 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try  /* Line: 173 */ {
bevl_res = this.bem_toStringCompact_0();
} /* Line: 174 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 177 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_2_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevl_ret = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_newlineGet_0();
bevt_8_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_2));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_12_tmpvar_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 186 */ {
if (bevp_inFile == null) {
bevt_14_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 186 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 186 */
 else  /* Line: 186 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 186 */ {
bevt_22_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_newlineGet_0();
bevt_20_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_23_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_3));
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_4));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_25_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_inFile);
bevt_27_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 187 */
if (bevp_held == null) {
bevt_28_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevt_32_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_newlineGet_0();
bevt_30_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_31_tmpvar_phold);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_5));
bevl_ret = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_34_tmpvar_phold);
} /* Line: 191 */
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_7));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
if (bevp_nlc == null) {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_7_tmpvar_phold = bevo_0;
bevt_6_tmpvar_phold = bevl_ret.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
} /* Line: 200 */
if (bevp_inClassNp == null) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = bevl_ret.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
} /* Line: 203 */
if (bevp_held == null) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_15_tmpvar_phold = bevo_2;
bevt_14_tmpvar_phold = bevl_ret.bem_add_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevt_14_tmpvar_phold.bem_add_1(bevt_16_tmpvar_phold);
} /* Line: 206 */
return bevl_ret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_depthGet_0() {
BEC_2_6_6_SystemObject bevl_d = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_d = (new BEC_2_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 214 */ {
if (bevl_c == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 214 */ {
bevl_d = bevl_d.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_c = bevl_c.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 216 */
 else  /* Line: 214 */ {
break;
} /* Line: 214 */
} /* Line: 214 */
return bevl_d;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prefixGet_0() {
BEC_2_6_6_SystemObject bevl_d = null;
BEC_2_6_6_SystemObject bevl_p = null;
BEC_2_6_6_SystemObject bevl_q = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_d = this.bem_depthGet_0();
bevl_p = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_2_4_6_TextString(2, bels_11));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 225 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_d);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 225 */ {
bevl_p = bevl_p.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_q);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 225 */
 else  /* Line: 225 */ {
break;
} /* Line: 225 */
} /* Line: 225 */
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 233 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 233 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 233 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 233 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 233 */
 else  /* Line: 233 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 233 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 234 */
 else  /* Line: 233 */ {
break;
} /* Line: 233 */
} /* Line: 233 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpvarn = null;
BEC_2_6_6_SystemObject bevl_tmpvar = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
bevl_clnode = this.bem_scopeGet_0();
bevt_1_tmpvar_phold = bevl_clnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_2_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 241 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bels_12));
bevt_3_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpvar_phold, this);
throw new be.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 242 */
bevt_6_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevl_tmpvarn = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_7_tmpvar_phold.bemd_1(241589730, BEL_4_Base.bevn_tmpCntSet_1, bevt_8_tmpvar_phold);
bevl_tmpvar = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_11_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tmpvar.bemd_1(-1124689062, BEL_4_Base.bevn_isTmpVarSet_1, bevt_11_tmpvar_phold);
bevl_tmpvar.bemd_1(-2093073725, BEL_4_Base.bevn_suffixSet_1, beva_suffix);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_13));
bevt_13_tmpvar_phold = bevl_tmpvarn.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, beva_suffix);
bevl_tmpvar.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_12_tmpvar_phold);
return bevl_tmpvar;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 255 */ {
if (bevl_con == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 255 */ {
bevt_2_tmpvar_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_tmpvar_phold.bevi_int == bevt_3_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 256 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 257 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 259 */
 else  /* Line: 255 */ {
break;
} /* Line: 255 */
} /* Line: 255 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addVariable_0() {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_2_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 266 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_3_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevt_5_tmpvar_phold = bevl_sco.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 269 */ {
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(54, bels_14));
bevt_7_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpvar_phold, this);
throw new be.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 270 */
bevt_9_tmpvar_phold = this.bem_inPropertiesGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_11_tmpvar_phold = bevl_v.bemd_0(-1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
bevl_sco = this.bem_classGet_0();
bevt_12_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_12_tmpvar_phold);
} /* Line: 274 */
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_15_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 277 */ {
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bels_15));
bevt_16_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpvar_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpvar_phold);
} /* Line: 278 */
bevt_18_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_19_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_18_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_19_tmpvar_phold, this);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_20_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 281 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_syncAddVariable_0() {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_1_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 287 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_2_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_5_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 291 */ {
bevt_6_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_7_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
} /* Line: 292 */
 else  /* Line: 293 */ {
bevt_8_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_11_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 295 */ {
bevt_12_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_13_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_12_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_13_tmpvar_phold);
} /* Line: 296 */
 else  /* Line: 297 */ {
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_15_tmpvar_phold, this);
bevt_16_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_16_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
bevt_18_tmpvar_phold = bevl_sco.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_19_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 300 */ {
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bels_16));
bevt_20_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, this);
throw new be.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 301 */
} /* Line: 300 */
} /* Line: 295 */
} /* Line: 291 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_13_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpvar_phold = this.bem_scopeGet_0();
bevl_sc = bevt_0_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 312 */ {
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 313 */
 else  /* Line: 314 */ {
bevt_5_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_5_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 316 */ {
bevt_9_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 317 */
 else  /* Line: 318 */ {
bevl_tunode = this.bem_transUnitGet_0();
bevt_11_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_np = bevt_10_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevt_14_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_aliasedGet_0();
bevl_np = bevt_13_tmpvar_phold.bem_get_1(bevl_vname);
} /* Line: 322 */
if (bevl_np == null) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevt_18_tmpvar_phold = bevo_3;
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(bevl_np);
bevt_16_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpvar_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpvar_phold);
} /* Line: 325 */
 else  /* Line: 326 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevl_vname);
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_18));
bevt_19_tmpvar_phold = bevl_vname.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold != null && bevt_19_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_19_tmpvar_phold).bevi_bool) /* Line: 330 */ {
bevp_held = bevl_v;
bevt_21_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = bevl_cl.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_23_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_24_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_24_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 335 */
 else  /* Line: 336 */ {
bevt_25_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(1465928304, BEL_4_Base.bevn_isDeclaredSet_1, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_26_tmpvar_phold);
bevp_held = bevl_v;
bevt_27_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_27_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_28_tmpvar_phold = bevl_cl.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_28_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 341 */
} /* Line: 330 */
} /* Line: 324 */
} /* Line: 316 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
bevl_node = this;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 350 */ {
while (true)
 /* Line: 351 */ {
bevt_2_tmpvar_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpvar_phold = bevl_node.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_has_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 352 */ {
return bevl_node;
} /* Line: 353 */
 else  /* Line: 354 */ {
bevl_node = bevl_node.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
if (bevl_node == null) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_19));
bevt_5_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpvar_phold, this);
throw new be.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 357 */
} /* Line: 356 */
} /* Line: 352 */
} /* Line: 351 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 366 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 366 */
 else  /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 366 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 367 */
 else  /* Line: 366 */ {
break;
} /* Line: 366 */
} /* Line: 366 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 374 */ {
if (bevl_targ == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 374 */ {
bevt_5_tmpvar_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 374 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 374 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 374 */
 else  /* Line: 374 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 374 */ {
bevt_8_tmpvar_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_9_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 374 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 374 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 374 */
 else  /* Line: 374 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 374 */ {
bevt_11_tmpvar_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 374 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 374 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 374 */
 else  /* Line: 374 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 374 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 375 */
 else  /* Line: 374 */ {
break;
} /* Line: 374 */
} /* Line: 374 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 381 */ {
return null;
} /* Line: 382 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_other);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) {
beva_other.bem_delete_0();
this.bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 395 */ {
bevt_0_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 395 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, this);
} /* Line: 397 */
 else  /* Line: 395 */ {
break;
} /* Line: 395 */
} /* Line: 395 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_resolveNp_0() {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 405 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 406 */
} /* Line: 405 */
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 411 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 412 */
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevl_np == null) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 415 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 416 */
bevt_8_tmpvar_phold = bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_held.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_7_tmpvar_phold);
} /* Line: 418 */
bevt_10_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_11_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 423 */
} /* Line: 422 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_callIsSafe_1(BEC_2_5_4_BuildNode beva_call) {
BEC_2_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses = null;
BEC_2_9_3_ContainerSet bevl_okCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses2 = null;
BEC_2_9_3_ContainerSet bevl_okCalls2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_54_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 433 */ {
bevt_6_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_20));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_7_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 433 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 433 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 433 */
 else  /* Line: 433 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 433 */ {
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 434 */
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_4 == null) {
bevo_4 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bevo_4;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_5 == null) {
bevo_5 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bevo_5;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_6 == null) {
bevo_6 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bevo_6;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_7 == null) {
bevo_7 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bevo_7;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_8 == null) {
bevo_8 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bevo_8;
bevt_10_tmpvar_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevo_9;
if (bevt_10_tmpvar_phold.bevi_int == bevt_11_tmpvar_phold.bevi_int) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpvar_phold);
bevt_45_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpvar_phold);
} /* Line: 492 */
bevt_48_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpvar_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 496 */ {
bevt_49_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_49_tmpvar_phold;
} /* Line: 498 */
bevt_54_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 502 */ {
bevt_55_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_55_tmpvar_phold;
} /* Line: 504 */
bevt_61_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_firstGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_56_tmpvar_phold = bevl_okClasses.bem_has_1(bevt_57_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 512 */ {
bevt_64_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = bevl_okCalls.bem_has_1(bevt_63_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 513 */ {
bevt_65_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_65_tmpvar_phold;
} /* Line: 515 */
 else  /* Line: 516 */ {
} /* Line: 516 */
} /* Line: 513 */
bevt_71_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_firstGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_66_tmpvar_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpvar_phold);
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 520 */ {
bevt_74_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_72_tmpvar_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpvar_phold);
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 521 */ {
bevt_75_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_75_tmpvar_phold;
} /* Line: 523 */
 else  /* Line: 524 */ {
} /* Line: 524 */
} /* Line: 521 */
bevt_76_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_76_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralOnceGet_0() {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_BuildNode bevl_c0 = null;
BEC_2_5_4_BuildNode bevl_c1 = null;
BEC_2_5_4_BuildNode bevl_call = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_4_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevp_typename.bevi_int != bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 545 */ {
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 545 */
bevt_7_tmpvar_phold = bevp_held.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_55));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 546 */ {
bevl_c0 = (BEC_2_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_2_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 549 */ {
bevt_11_tmpvar_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_11_tmpvar_phold.bevi_int == bevt_12_tmpvar_phold.bevi_int) {
bevt_10_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 549 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 549 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 549 */
 else  /* Line: 549 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 549 */ {
bevt_14_tmpvar_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 550 */ {
bevt_17_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1126433704, BEL_4_Base.bevn_isPropertyGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 550 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 550 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 550 */
 else  /* Line: 550 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 550 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_19_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_18_tmpvar_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 552 */ {
bevt_20_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 552 */ {
bevl_call = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_21_tmpvar_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 553 */ {
bevt_23_tmpvar_phold = this.bem_callIsSafe_1(bevl_call);
if (bevt_23_tmpvar_phold.bevi_bool) {
bevt_22_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 554 */ {
bevt_24_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_24_tmpvar_phold;
} /* Line: 555 */
} /* Line: 554 */
} /* Line: 553 */
 else  /* Line: 552 */ {
break;
} /* Line: 552 */
} /* Line: 552 */
} /* Line: 552 */
} /* Line: 550 */
} /* Line: 549 */
return bevl_result;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() {
return bevp_contained;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() {
return bevp_held;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_held = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldByGet_0() {
return bevp_heldBy;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_heldBy = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condvarGet_0() {
return bevp_condvar;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condvarSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_condvar = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() {
return bevp_typeDetail;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_typeDetail = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() {
return bevp_delayDelete;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() {
return bevp_nlc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() {
return bevp_nlec;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() {
return bevp_wideString;
} /*method end*/
public BEC_2_6_6_SystemObject bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() {
return bevp_typename;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() {
return bevp_inlined;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {26, 27, 28, 29, 31, 32, 33, 34, 35, 40, 40, 41, 41, 42, 43, 47, 47, 47, 47, 47, 0, 0, 0, 48, 48, 50, 51, 52, 52, 52, 52, 0, 0, 0, 53, 54, 56, 60, 61, 62, 62, 62, 62, 0, 0, 0, 63, 64, 66, 70, 70, 71, 73, 74, 74, 75, 77, 77, 81, 81, 82, 84, 85, 85, 86, 88, 88, 92, 92, 96, 96, 100, 100, 104, 104, 105, 105, 107, 107, 107, 111, 111, 0, 111, 111, 111, 0, 0, 112, 112, 114, 114, 114, 114, 118, 118, 0, 118, 118, 118, 0, 0, 0, 118, 118, 118, 118, 0, 0, 119, 119, 121, 121, 121, 121, 121, 125, 129, 129, 130, 132, 133, 134, 138, 138, 139, 141, 141, 141, 142, 146, 146, 147, 149, 150, 154, 154, 155, 157, 158, 162, 166, 166, 167, 174, 176, 177, 179, 183, 184, 184, 184, 184, 184, 184, 185, 185, 185, 185, 185, 185, 185, 185, 186, 186, 186, 186, 0, 0, 0, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 189, 189, 190, 190, 190, 190, 190, 190, 191, 191, 193, 197, 198, 198, 198, 198, 198, 198, 199, 199, 200, 200, 200, 200, 202, 202, 203, 203, 203, 203, 205, 205, 206, 206, 206, 206, 208, 212, 213, 214, 214, 215, 216, 218, 222, 223, 224, 225, 225, 226, 225, 228, 232, 233, 233, 233, 233, 233, 0, 0, 0, 234, 236, 240, 241, 241, 241, 242, 242, 242, 244, 244, 244, 245, 245, 245, 245, 245, 246, 247, 247, 248, 249, 249, 249, 249, 250, 254, 255, 255, 256, 256, 256, 256, 257, 257, 259, 261, 261, 265, 266, 266, 267, 267, 268, 269, 269, 269, 270, 270, 270, 272, 272, 272, 0, 0, 0, 273, 274, 274, 276, 277, 277, 277, 278, 278, 278, 280, 280, 280, 281, 281, 286, 287, 287, 288, 288, 289, 290, 291, 291, 291, 292, 292, 292, 294, 294, 295, 295, 295, 296, 296, 296, 298, 298, 298, 299, 299, 300, 300, 300, 301, 301, 301, 310, 311, 311, 312, 312, 313, 313, 313, 315, 315, 316, 316, 317, 317, 317, 319, 320, 320, 320, 321, 321, 322, 322, 322, 324, 324, 325, 325, 325, 325, 328, 329, 330, 330, 331, 332, 332, 333, 333, 334, 334, 335, 335, 337, 337, 338, 338, 339, 340, 340, 341, 341, 349, 350, 352, 352, 352, 353, 355, 356, 356, 357, 357, 357, 365, 366, 366, 366, 366, 366, 0, 0, 0, 367, 369, 373, 374, 374, 374, 374, 374, 0, 0, 0, 374, 374, 374, 0, 0, 0, 374, 374, 374, 0, 0, 0, 375, 377, 381, 381, 382, 384, 385, 389, 390, 394, 395, 395, 396, 397, 403, 403, 403, 404, 405, 405, 406, 409, 409, 409, 410, 411, 411, 412, 414, 415, 415, 416, 418, 418, 418, 420, 420, 420, 421, 422, 422, 423, 433, 433, 433, 433, 433, 433, 433, 0, 0, 0, 434, 434, 437, 438, 439, 440, 441, 442, 442, 442, 442, 449, 449, 452, 452, 453, 453, 455, 455, 456, 456, 457, 457, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 473, 473, 474, 474, 475, 475, 476, 476, 477, 477, 478, 478, 479, 479, 483, 483, 484, 484, 485, 485, 486, 486, 491, 491, 492, 492, 496, 496, 496, 498, 498, 502, 502, 502, 502, 502, 504, 504, 512, 512, 512, 512, 512, 512, 513, 513, 513, 515, 515, 520, 520, 520, 520, 520, 520, 521, 521, 521, 523, 523, 529, 529, 540, 545, 545, 545, 545, 545, 546, 546, 546, 547, 548, 549, 549, 549, 549, 549, 549, 0, 0, 0, 550, 550, 550, 550, 550, 0, 0, 0, 551, 552, 552, 552, 0, 552, 552, 553, 554, 554, 554, 555, 555, 566, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {93, 94, 95, 96, 97, 98, 99, 100, 101, 107, 108, 109, 110, 111, 112, 126, 131, 132, 133, 138, 139, 142, 146, 149, 150, 152, 153, 156, 161, 162, 167, 168, 171, 175, 178, 179, 185, 193, 194, 197, 202, 203, 208, 209, 212, 216, 219, 220, 226, 233, 238, 239, 241, 242, 247, 248, 250, 251, 258, 263, 264, 266, 267, 272, 273, 275, 276, 280, 281, 285, 286, 290, 291, 298, 303, 304, 305, 307, 308, 313, 324, 329, 330, 333, 334, 339, 340, 343, 347, 348, 350, 351, 352, 357, 373, 378, 379, 382, 383, 388, 389, 392, 396, 399, 400, 401, 406, 407, 410, 414, 415, 417, 418, 419, 420, 425, 428, 433, 438, 439, 441, 442, 443, 450, 455, 456, 458, 459, 460, 461, 466, 471, 472, 474, 475, 480, 485, 486, 488, 489, 493, 498, 503, 504, 512, 516, 517, 519, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 579, 580, 585, 586, 589, 593, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 611, 616, 617, 618, 619, 620, 621, 622, 623, 624, 626, 648, 649, 650, 651, 652, 653, 654, 655, 660, 661, 662, 663, 664, 666, 671, 672, 673, 674, 675, 677, 682, 683, 684, 685, 686, 688, 694, 695, 698, 703, 704, 705, 711, 719, 720, 721, 722, 725, 727, 728, 734, 743, 746, 751, 752, 753, 754, 756, 759, 763, 766, 772, 793, 794, 795, 796, 798, 799, 800, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 828, 831, 836, 837, 838, 839, 844, 845, 846, 848, 854, 855, 882, 883, 884, 886, 887, 888, 889, 890, 891, 893, 894, 895, 897, 899, 900, 902, 905, 909, 912, 913, 914, 916, 917, 918, 919, 921, 922, 923, 925, 926, 927, 928, 929, 960, 961, 962, 964, 965, 966, 967, 968, 969, 970, 972, 973, 974, 977, 978, 979, 980, 981, 983, 984, 985, 988, 989, 990, 991, 992, 993, 994, 995, 997, 998, 999, 1042, 1043, 1044, 1045, 1046, 1048, 1049, 1050, 1053, 1054, 1055, 1056, 1058, 1059, 1060, 1063, 1064, 1065, 1066, 1067, 1072, 1073, 1074, 1075, 1077, 1082, 1083, 1084, 1085, 1086, 1089, 1090, 1091, 1092, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1129, 1130, 1134, 1135, 1136, 1138, 1141, 1142, 1147, 1148, 1149, 1150, 1164, 1167, 1172, 1173, 1174, 1175, 1177, 1180, 1184, 1187, 1193, 1210, 1213, 1218, 1219, 1220, 1221, 1223, 1226, 1230, 1233, 1234, 1235, 1237, 1240, 1244, 1247, 1248, 1249, 1251, 1254, 1258, 1261, 1267, 1271, 1276, 1277, 1279, 1280, 1284, 1285, 1292, 1293, 1296, 1298, 1299, 1321, 1322, 1327, 1328, 1329, 1334, 1335, 1338, 1339, 1344, 1345, 1346, 1351, 1352, 1354, 1355, 1360, 1361, 1363, 1364, 1365, 1367, 1368, 1373, 1374, 1375, 1380, 1381, 1469, 1470, 1472, 1473, 1474, 1475, 1476, 1478, 1481, 1485, 1488, 1489, 1491, 1497, 1503, 1509, 1515, 1521, 1522, 1523, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1598, 1599, 1600, 1602, 1603, 1605, 1606, 1607, 1608, 1609, 1611, 1612, 1614, 1615, 1616, 1617, 1618, 1619, 1621, 1622, 1623, 1625, 1626, 1631, 1632, 1633, 1634, 1635, 1636, 1638, 1639, 1640, 1642, 1643, 1648, 1649, 1681, 1682, 1683, 1688, 1689, 1690, 1692, 1693, 1694, 1696, 1697, 1698, 1703, 1704, 1705, 1706, 1711, 1712, 1715, 1719, 1722, 1723, 1725, 1726, 1727, 1729, 1732, 1736, 1739, 1740, 1741, 1742, 1742, 1745, 1747, 1748, 1750, 1751, 1756, 1757, 1758, 1769, 1772, 1775, 1779, 1782, 1786, 1789, 1793, 1796, 1800, 1803, 1807, 1810, 1814, 1817, 1821, 1824, 1828, 1831, 1835, 1838, 1842, 1845, 1849, 1852, 1856, 1859, 1863, 1866, 1870, 1873, 1877, 1880, 1884, 1887};
/* BEGIN LINEINFO 
assign 1 26 93
new 0 26 93
assign 1 27 94
new 0 27 94
assign 1 28 95
new 0 28 95
assign 1 29 96
new 0 29 96
assign 1 31 97
assign 1 32 98
constantsGet 0 32 98
assign 1 33 99
ntypesGet 0 33 99
assign 1 34 100
TOKENGet 0 34 100
assign 1 35 101
new 0 35 101
assign 1 40 107
nlcGet 0 40 107
assign 1 40 108
copy 0 40 108
assign 1 41 109
nlecGet 0 41 109
assign 1 41 110
copy 0 41 110
assign 1 42 111
inClassNpGet 0 42 111
assign 1 43 112
inFileGet 0 43 112
assign 1 47 126
def 1 47 131
assign 1 47 132
firstGet 0 47 132
assign 1 47 133
def 1 47 138
assign 1 0 139
assign 1 0 142
assign 1 0 146
assign 1 48 149
firstGet 0 48 149
return 1 48 150
assign 1 50 152
nextPeerGet 0 50 152
assign 1 51 153
assign 1 52 156
undef 1 52 161
assign 1 52 162
def 1 52 167
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 53 178
nextPeerGet 0 53 178
assign 1 54 179
containerGet 0 54 179
return 1 56 185
assign 1 60 193
nextPeerGet 0 60 193
assign 1 61 194
assign 1 62 197
undef 1 62 202
assign 1 62 203
def 1 62 208
assign 1 0 209
assign 1 0 212
assign 1 0 216
assign 1 63 219
nextPeerGet 0 63 219
assign 1 64 220
containerGet 0 64 220
return 1 66 226
assign 1 70 233
undef 1 70 238
return 1 71 239
assign 1 73 241
nextGet 0 73 241
assign 1 74 242
undef 1 74 247
return 1 75 248
assign 1 77 250
heldGet 0 77 250
return 1 77 251
assign 1 81 258
undef 1 81 263
return 1 82 264
assign 1 84 266
priorGet 0 84 266
assign 1 85 267
undef 1 85 272
return 1 86 273
assign 1 88 275
heldGet 0 88 275
return 1 88 276
assign 1 92 280
firstGet 0 92 280
return 1 92 281
assign 1 96 285
secondGet 0 96 285
return 1 96 286
assign 1 100 290
thirdGet 0 100 290
return 1 100 291
assign 1 104 298
undef 1 104 303
assign 1 105 304
new 0 105 304
return 1 105 305
assign 1 107 307
priorGet 0 107 307
assign 1 107 308
undef 1 107 313
return 1 107 313
assign 1 111 324
undef 1 111 329
assign 1 0 330
assign 1 111 333
priorGet 0 111 333
assign 1 111 334
undef 1 111 339
assign 1 0 340
assign 1 0 343
assign 1 112 347
new 0 112 347
return 1 112 348
assign 1 114 350
priorGet 0 114 350
assign 1 114 351
priorGet 0 114 351
assign 1 114 352
undef 1 114 357
return 1 114 357
assign 1 118 373
undef 1 118 378
assign 1 0 379
assign 1 118 382
priorGet 0 118 382
assign 1 118 383
undef 1 118 388
assign 1 0 389
assign 1 0 392
assign 1 0 396
assign 1 118 399
priorGet 0 118 399
assign 1 118 400
priorGet 0 118 400
assign 1 118 401
undef 1 118 406
assign 1 0 407
assign 1 0 410
assign 1 119 414
new 0 119 414
return 1 119 415
assign 1 121 417
priorGet 0 121 417
assign 1 121 418
priorGet 0 121 418
assign 1 121 419
priorGet 0 121 419
assign 1 121 420
undef 1 121 425
return 1 121 425
assign 1 125 428
new 0 125 428
assign 1 129 433
undef 1 129 438
return 1 130 439
delete 0 132 441
assign 1 133 442
assign 1 134 443
assign 1 138 450
undef 1 138 455
return 1 139 456
assign 1 141 458
mylistGet 0 141 458
assign 1 141 459
newNode 1 141 459
insertBefore 1 141 460
containerSet 1 142 461
assign 1 146 466
undef 1 146 471
initContained 0 147 472
prepend 1 149 474
containerSet 1 150 475
assign 1 154 480
undef 1 154 485
initContained 0 155 486
addValue 1 157 488
containerSet 1 158 489
assign 1 162 493
new 0 162 493
assign 1 166 498
undef 1 166 503
assign 1 167 504
new 0 167 504
assign 1 174 512
toStringCompact 0 174 512
print 0 176 516
throw 1 177 517
return 1 179 519
assign 1 183 559
prefixGet 0 183 559
assign 1 184 560
new 0 184 560
assign 1 184 561
add 1 184 561
assign 1 184 562
toString 0 184 562
assign 1 184 563
add 1 184 563
assign 1 184 564
new 0 184 564
assign 1 184 565
add 1 184 565
assign 1 185 566
new 0 185 566
assign 1 185 567
newlineGet 0 185 567
assign 1 185 568
add 1 185 568
assign 1 185 569
add 1 185 569
assign 1 185 570
new 0 185 570
assign 1 185 571
add 1 185 571
assign 1 185 572
toString 0 185 572
assign 1 185 573
add 1 185 573
assign 1 186 574
def 1 186 579
assign 1 186 580
def 1 186 585
assign 1 0 586
assign 1 0 589
assign 1 0 593
assign 1 187 596
new 0 187 596
assign 1 187 597
newlineGet 0 187 597
assign 1 187 598
add 1 187 598
assign 1 187 599
add 1 187 599
assign 1 187 600
new 0 187 600
assign 1 187 601
add 1 187 601
assign 1 187 602
toString 0 187 602
assign 1 187 603
add 1 187 603
assign 1 187 604
new 0 187 604
assign 1 187 605
add 1 187 605
assign 1 187 606
add 1 187 606
assign 1 187 607
new 0 187 607
assign 1 187 608
newlineGet 0 187 608
assign 1 187 609
add 1 187 609
assign 1 189 611
def 1 189 616
assign 1 190 617
new 0 190 617
assign 1 190 618
newlineGet 0 190 618
assign 1 190 619
add 1 190 619
assign 1 190 620
add 1 190 620
assign 1 190 621
new 0 190 621
assign 1 190 622
add 1 190 622
assign 1 191 623
toString 0 191 623
assign 1 191 624
add 1 191 624
return 1 193 626
assign 1 197 648
prefixGet 0 197 648
assign 1 198 649
new 0 198 649
assign 1 198 650
add 1 198 650
assign 1 198 651
toString 0 198 651
assign 1 198 652
add 1 198 652
assign 1 198 653
new 0 198 653
assign 1 198 654
add 1 198 654
assign 1 199 655
def 1 199 660
assign 1 200 661
new 0 200 661
assign 1 200 662
add 1 200 662
assign 1 200 663
toString 0 200 663
assign 1 200 664
add 1 200 664
assign 1 202 666
def 1 202 671
assign 1 203 672
new 0 203 672
assign 1 203 673
add 1 203 673
assign 1 203 674
toString 0 203 674
assign 1 203 675
add 1 203 675
assign 1 205 677
def 1 205 682
assign 1 206 683
new 0 206 683
assign 1 206 684
add 1 206 684
assign 1 206 685
toString 0 206 685
assign 1 206 686
add 1 206 686
return 1 208 688
assign 1 212 694
new 0 212 694
assign 1 213 695
assign 1 214 698
def 1 214 703
assign 1 215 704
increment 0 215 704
assign 1 216 705
containerGet 0 216 705
return 1 218 711
assign 1 222 719
depthGet 0 222 719
assign 1 223 720
new 0 223 720
assign 1 224 721
new 0 224 721
assign 1 225 722
new 0 225 722
assign 1 225 725
lesser 1 225 725
assign 1 226 727
add 1 226 727
assign 1 225 728
increment 0 225 728
return 1 228 734
assign 1 232 743
assign 1 233 746
def 1 233 751
assign 1 233 752
typenameGet 0 233 752
assign 1 233 753
TRANSUNITGet 0 233 753
assign 1 233 754
notEquals 1 233 754
assign 1 0 756
assign 1 0 759
assign 1 0 763
assign 1 234 766
containerGet 0 234 766
return 1 236 772
assign 1 240 793
scopeGet 0 240 793
assign 1 241 794
typenameGet 0 241 794
assign 1 241 795
METHODGet 0 241 795
assign 1 241 796
notEquals 1 241 796
assign 1 242 798
new 0 242 798
assign 1 242 799
new 2 242 799
throw 1 242 800
assign 1 244 802
heldGet 0 244 802
assign 1 244 803
tmpCntGet 0 244 803
assign 1 244 804
toString 0 244 804
assign 1 245 805
heldGet 0 245 805
assign 1 245 806
heldGet 0 245 806
assign 1 245 807
tmpCntGet 0 245 807
assign 1 245 808
increment 0 245 808
tmpCntSet 1 245 809
assign 1 246 810
new 0 246 810
assign 1 247 811
new 0 247 811
isTmpVarSet 1 247 812
suffixSet 1 248 813
assign 1 249 814
new 0 249 814
assign 1 249 815
add 1 249 815
assign 1 249 816
add 1 249 816
nameSet 1 249 817
return 1 250 818
assign 1 254 828
assign 1 255 831
def 1 255 836
assign 1 256 837
typenameGet 0 256 837
assign 1 256 838
PROPERTIESGet 0 256 838
assign 1 256 839
equals 1 256 844
assign 1 257 845
new 0 257 845
return 1 257 846
assign 1 259 848
containerGet 0 259 848
assign 1 261 854
new 0 261 854
return 1 261 855
assign 1 265 882
assign 1 266 883
isAddedGet 0 266 883
assign 1 266 884
not 0 266 884
assign 1 267 886
new 0 267 886
isAddedSet 1 267 887
assign 1 268 888
scopeGet 0 268 888
assign 1 269 889
typenameGet 0 269 889
assign 1 269 890
CLASSGet 0 269 890
assign 1 269 891
equals 1 269 891
assign 1 270 893
new 0 270 893
assign 1 270 894
new 2 270 894
throw 1 270 895
assign 1 272 897
inPropertiesGet 0 272 897
assign 1 272 899
isTmpVarGet 0 272 899
assign 1 272 900
not 0 272 900
assign 1 0 902
assign 1 0 905
assign 1 0 909
assign 1 273 912
classGet 0 273 912
assign 1 274 913
new 0 274 913
isPropertySet 1 274 914
assign 1 276 916
heldGet 0 276 916
assign 1 277 917
varMapGet 0 277 917
assign 1 277 918
nameGet 0 277 918
assign 1 277 919
has 1 277 919
assign 1 278 921
new 0 278 921
assign 1 278 922
new 2 278 922
throw 1 278 923
assign 1 280 925
varMapGet 0 280 925
assign 1 280 926
nameGet 0 280 926
put 2 280 927
assign 1 281 928
orderedVarsGet 0 281 928
addValue 1 281 929
assign 1 286 960
assign 1 287 961
isAddedGet 0 287 961
assign 1 287 962
not 0 287 962
assign 1 288 964
new 0 288 964
isAddedSet 1 288 965
assign 1 289 966
scopeGet 0 289 966
assign 1 290 967
heldGet 0 290 967
assign 1 291 968
varMapGet 0 291 968
assign 1 291 969
nameGet 0 291 969
assign 1 291 970
has 1 291 970
assign 1 292 972
varMapGet 0 292 972
assign 1 292 973
nameGet 0 292 973
assign 1 292 974
get 1 292 974
assign 1 294 977
classGet 0 294 977
assign 1 294 978
heldGet 0 294 978
assign 1 295 979
varMapGet 0 295 979
assign 1 295 980
nameGet 0 295 980
assign 1 295 981
has 1 295 981
assign 1 296 983
varMapGet 0 296 983
assign 1 296 984
nameGet 0 296 984
assign 1 296 985
get 1 296 985
assign 1 298 988
varMapGet 0 298 988
assign 1 298 989
nameGet 0 298 989
put 2 298 990
assign 1 299 991
orderedVarsGet 0 299 991
addValue 1 299 992
assign 1 300 993
typenameGet 0 300 993
assign 1 300 994
CLASSGet 0 300 994
assign 1 300 995
equals 1 300 995
assign 1 301 997
new 0 301 997
assign 1 301 998
new 2 301 998
throw 1 301 999
assign 1 310 1042
assign 1 311 1043
scopeGet 0 311 1043
assign 1 311 1044
heldGet 0 311 1044
assign 1 312 1045
varMapGet 0 312 1045
assign 1 312 1046
has 1 312 1046
assign 1 313 1048
varMapGet 0 313 1048
assign 1 313 1049
get 1 313 1049
assign 1 313 1050
heldGet 0 313 1050
assign 1 315 1053
classGet 0 315 1053
assign 1 315 1054
heldGet 0 315 1054
assign 1 316 1055
varMapGet 0 316 1055
assign 1 316 1056
has 1 316 1056
assign 1 317 1058
varMapGet 0 317 1058
assign 1 317 1059
get 1 317 1059
assign 1 317 1060
heldGet 0 317 1060
assign 1 319 1063
transUnitGet 0 319 1063
assign 1 320 1064
heldGet 0 320 1064
assign 1 320 1065
aliasedGet 0 320 1065
assign 1 320 1066
get 1 320 1066
assign 1 321 1067
undef 1 321 1072
assign 1 322 1073
emitDataGet 0 322 1073
assign 1 322 1074
aliasedGet 0 322 1074
assign 1 322 1075
get 1 322 1075
assign 1 324 1077
def 1 324 1082
assign 1 325 1083
new 0 325 1083
assign 1 325 1084
add 1 325 1084
assign 1 325 1085
new 2 325 1085
throw 1 325 1086
assign 1 328 1089
new 0 328 1089
nameSet 1 329 1090
assign 1 330 1091
new 0 330 1091
assign 1 330 1092
equals 1 330 1092
assign 1 331 1094
assign 1 332 1095
new 0 332 1095
isTypedSet 1 332 1096
assign 1 333 1097
extendsGet 0 333 1097
namepathSet 1 333 1098
assign 1 334 1099
varMapGet 0 334 1099
put 2 334 1100
assign 1 335 1101
orderedVarsGet 0 335 1101
addValue 1 335 1102
assign 1 337 1105
new 0 337 1105
isDeclaredSet 1 337 1106
assign 1 338 1107
new 0 338 1107
isPropertySet 1 338 1108
assign 1 339 1109
assign 1 340 1110
varMapGet 0 340 1110
put 2 340 1111
assign 1 341 1112
orderedVarsGet 0 341 1112
addValue 1 341 1113
assign 1 349 1129
assign 1 350 1130
new 0 350 1130
assign 1 352 1134
anchorTypesGet 0 352 1134
assign 1 352 1135
typenameGet 0 352 1135
assign 1 352 1136
has 1 352 1136
return 1 353 1138
assign 1 355 1141
containerGet 0 355 1141
assign 1 356 1142
undef 1 356 1147
assign 1 357 1148
new 0 357 1148
assign 1 357 1149
new 2 357 1149
throw 1 357 1150
assign 1 365 1164
assign 1 366 1167
def 1 366 1172
assign 1 366 1173
typenameGet 0 366 1173
assign 1 366 1174
CLASSGet 0 366 1174
assign 1 366 1175
notEquals 1 366 1175
assign 1 0 1177
assign 1 0 1180
assign 1 0 1184
assign 1 367 1187
containerGet 0 367 1187
return 1 369 1193
assign 1 373 1210
assign 1 374 1213
def 1 374 1218
assign 1 374 1219
typenameGet 0 374 1219
assign 1 374 1220
CLASSGet 0 374 1220
assign 1 374 1221
notEquals 1 374 1221
assign 1 0 1223
assign 1 0 1226
assign 1 0 1230
assign 1 374 1233
typenameGet 0 374 1233
assign 1 374 1234
METHODGet 0 374 1234
assign 1 374 1235
notEquals 1 374 1235
assign 1 0 1237
assign 1 0 1240
assign 1 0 1244
assign 1 374 1247
typenameGet 0 374 1247
assign 1 374 1248
TRANSUNITGet 0 374 1248
assign 1 374 1249
notEquals 1 374 1249
assign 1 0 1251
assign 1 0 1254
assign 1 0 1258
assign 1 375 1261
containerGet 0 375 1261
return 1 377 1267
assign 1 381 1271
undef 1 381 1276
return 1 382 1277
containerSet 1 384 1279
heldSet 1 385 1280
delete 0 389 1284
addValue 1 390 1285
assign 1 394 1292
containedGet 0 394 1292
assign 1 395 1293
iteratorGet 0 395 1293
assign 1 395 1296
hasNextGet 0 395 1296
assign 1 396 1298
nextGet 0 396 1298
containerSet 1 397 1299
assign 1 403 1321
NAMEPATHGet 0 403 1321
assign 1 403 1322
equals 1 403 1327
assign 1 404 1328
assign 1 405 1329
def 1 405 1334
resolve 1 406 1335
assign 1 409 1338
CLASSGet 0 409 1338
assign 1 409 1339
equals 1 409 1344
assign 1 410 1345
namepathGet 0 410 1345
assign 1 411 1346
def 1 411 1351
resolve 1 412 1352
assign 1 414 1354
extendsGet 0 414 1354
assign 1 415 1355
def 1 415 1360
resolve 1 416 1361
assign 1 418 1363
namepathGet 0 418 1363
assign 1 418 1364
toString 0 418 1364
nameSet 1 418 1365
assign 1 420 1367
VARGet 0 420 1367
assign 1 420 1368
equals 1 420 1373
assign 1 421 1374
namepathGet 0 421 1374
assign 1 422 1375
def 1 422 1380
resolve 1 423 1381
assign 1 433 1469
heldGet 0 433 1469
assign 1 433 1470
isConstructGet 0 433 1470
assign 1 433 1472
heldGet 0 433 1472
assign 1 433 1473
newNpGet 0 433 1473
assign 1 433 1474
toString 0 433 1474
assign 1 433 1475
new 0 433 1475
assign 1 433 1476
equals 1 433 1476
assign 1 0 1478
assign 1 0 1481
assign 1 0 1485
assign 1 434 1488
new 0 434 1488
return 1 434 1489
assign 1 437 1491
new 0 437 1491
assign 1 438 1497
new 0 438 1497
assign 1 439 1503
new 0 439 1503
assign 1 440 1509
new 0 440 1509
assign 1 441 1515
new 0 441 1515
assign 1 442 1521
sizeGet 0 442 1521
assign 1 442 1522
new 0 442 1522
assign 1 442 1523
equals 1 442 1528
assign 1 449 1529
new 0 449 1529
put 1 449 1530
assign 1 452 1531
new 0 452 1531
put 1 452 1532
assign 1 453 1533
new 0 453 1533
put 1 453 1534
assign 1 455 1535
new 0 455 1535
put 1 455 1536
assign 1 456 1537
new 0 456 1537
put 1 456 1538
assign 1 457 1539
new 0 457 1539
put 1 457 1540
assign 1 458 1541
new 0 458 1541
put 1 458 1542
assign 1 459 1543
new 0 459 1543
put 1 459 1544
assign 1 460 1545
new 0 460 1545
put 1 460 1546
assign 1 461 1547
new 0 461 1547
put 1 461 1548
assign 1 462 1549
new 0 462 1549
put 1 462 1550
assign 1 463 1551
new 0 463 1551
put 1 463 1552
assign 1 464 1553
new 0 464 1553
put 1 464 1554
assign 1 465 1555
new 0 465 1555
put 1 465 1556
assign 1 466 1557
new 0 466 1557
put 1 466 1558
assign 1 467 1559
new 0 467 1559
put 1 467 1560
assign 1 468 1561
new 0 468 1561
put 1 468 1562
assign 1 469 1563
new 0 469 1563
put 1 469 1564
assign 1 470 1565
new 0 470 1565
put 1 470 1566
assign 1 471 1567
new 0 471 1567
put 1 471 1568
assign 1 472 1569
new 0 472 1569
put 1 472 1570
assign 1 473 1571
new 0 473 1571
put 1 473 1572
assign 1 474 1573
new 0 474 1573
put 1 474 1574
assign 1 475 1575
new 0 475 1575
put 1 475 1576
assign 1 476 1577
new 0 476 1577
put 1 476 1578
assign 1 477 1579
new 0 477 1579
put 1 477 1580
assign 1 478 1581
new 0 478 1581
put 1 478 1582
assign 1 479 1583
new 0 479 1583
put 1 479 1584
assign 1 483 1585
new 0 483 1585
put 1 483 1586
assign 1 484 1587
new 0 484 1587
put 1 484 1588
assign 1 485 1589
new 0 485 1589
put 1 485 1590
assign 1 486 1591
new 0 486 1591
put 1 486 1592
assign 1 491 1593
new 0 491 1593
put 1 491 1594
assign 1 492 1595
new 0 492 1595
put 1 492 1596
assign 1 496 1598
heldGet 0 496 1598
assign 1 496 1599
nameGet 0 496 1599
assign 1 496 1600
has 1 496 1600
assign 1 498 1602
new 0 498 1602
return 1 498 1603
assign 1 502 1605
containedGet 0 502 1605
assign 1 502 1606
firstGet 0 502 1606
assign 1 502 1607
heldGet 0 502 1607
assign 1 502 1608
isTypedGet 0 502 1608
assign 1 502 1609
not 0 502 1609
assign 1 504 1611
new 0 504 1611
return 1 504 1612
assign 1 512 1614
containedGet 0 512 1614
assign 1 512 1615
firstGet 0 512 1615
assign 1 512 1616
heldGet 0 512 1616
assign 1 512 1617
namepathGet 0 512 1617
assign 1 512 1618
toString 0 512 1618
assign 1 512 1619
has 1 512 1619
assign 1 513 1621
heldGet 0 513 1621
assign 1 513 1622
nameGet 0 513 1622
assign 1 513 1623
has 1 513 1623
assign 1 515 1625
new 0 515 1625
return 1 515 1626
assign 1 520 1631
containedGet 0 520 1631
assign 1 520 1632
firstGet 0 520 1632
assign 1 520 1633
heldGet 0 520 1633
assign 1 520 1634
namepathGet 0 520 1634
assign 1 520 1635
toString 0 520 1635
assign 1 520 1636
has 1 520 1636
assign 1 521 1638
heldGet 0 521 1638
assign 1 521 1639
nameGet 0 521 1639
assign 1 521 1640
has 1 521 1640
assign 1 523 1642
new 0 523 1642
return 1 523 1643
assign 1 529 1648
new 0 529 1648
return 1 529 1649
assign 1 540 1681
new 0 540 1681
assign 1 545 1682
CALLGet 0 545 1682
assign 1 545 1683
notEquals 1 545 1688
assign 1 545 1689
new 0 545 1689
return 1 545 1690
assign 1 546 1692
orgNameGet 0 546 1692
assign 1 546 1693
new 0 546 1693
assign 1 546 1694
equals 1 546 1694
assign 1 547 1696
firstGet 0 547 1696
assign 1 548 1697
secondGet 0 548 1697
assign 1 549 1698
def 1 549 1703
assign 1 549 1704
typenameGet 0 549 1704
assign 1 549 1705
CALLGet 0 549 1705
assign 1 549 1706
equals 1 549 1711
assign 1 0 1712
assign 1 0 1715
assign 1 0 1719
assign 1 550 1722
heldGet 0 550 1722
assign 1 550 1723
isLiteralGet 0 550 1723
assign 1 550 1725
heldGet 0 550 1725
assign 1 550 1726
isPropertyGet 0 550 1726
assign 1 550 1727
not 0 550 1727
assign 1 0 1729
assign 1 0 1732
assign 1 0 1736
assign 1 551 1739
new 0 551 1739
assign 1 552 1740
heldGet 0 552 1740
assign 1 552 1741
allCallsGet 0 552 1741
assign 1 552 1742
iteratorGet 0 0 1742
assign 1 552 1745
hasNextGet 0 552 1745
assign 1 552 1747
nextGet 0 552 1747
assign 1 553 1748
notEquals 1 553 1748
assign 1 554 1750
callIsSafe 1 554 1750
assign 1 554 1751
not 0 554 1756
assign 1 555 1757
new 0 555 1757
return 1 555 1758
return 1 566 1769
return 1 0 1772
assign 1 0 1775
return 1 0 1779
assign 1 0 1782
return 1 0 1786
assign 1 0 1789
return 1 0 1793
assign 1 0 1796
return 1 0 1800
assign 1 0 1803
return 1 0 1807
assign 1 0 1810
return 1 0 1814
assign 1 0 1817
return 1 0 1821
assign 1 0 1824
return 1 0 1828
assign 1 0 1831
return 1 0 1835
assign 1 0 1838
return 1 0 1842
assign 1 0 1845
return 1 0 1849
assign 1 0 1852
return 1 0 1856
assign 1 0 1859
return 1 0 1863
assign 1 0 1866
return 1 0 1870
assign 1 0 1873
return 1 0 1877
assign 1 0 1880
return 1 0 1884
assign 1 0 1887
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 339997707: return bem_nlecGet_0();
case 1820417453: return bem_create_0();
case 822104518: return bem_inFileGet_0();
case 443668840: return bem_methodNotDefined_0();
case 202810500: return bem_depthGet_0();
case -1595262430: return bem_nlcGet_0();
case -786424307: return bem_tagGet_0();
case 1740134355: return bem_syncAddVariable_0();
case -845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1522157789: return bem_wideStringGet_0();
case -68392679: return bem_delayDeleteGet_0();
case -1973596005: return bem_transUnitGet_0();
case 2110470555: return bem_priorPeerGet_0();
case -1081412016: return bem_many_0();
case 931239762: return bem_heldGet_0();
case -312889617: return bem_classGet_0();
case 1236878826: return bem_nextAscendGet_0();
case 1823343663: return bem_inPropertiesGet_0();
case -1014444004: return bem_typeDetailGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -1167184407: return bem_isSecondGet_0();
case 1193143594: return bem_isThirdGet_0();
case -1692872440: return bem_toStringCompact_0();
case -1437330926: return bem_inClassNpGet_0();
case 516830146: return bem_condvarGet_0();
case -576537281: return bem_delayDelete_0();
case 830625628: return bem_inlinedGet_0();
case 432255188: return bem_containedGet_0();
case 287040793: return bem_hashGet_0();
case -729571811: return bem_serializeToString_0();
case 1987872129: return bem_isFirstGet_0();
case -183400265: return bem_firstGet_0();
case 1758195374: return bem_addVariable_0();
case 242848115: return bem_secondGet_0();
case 1952633087: return bem_resolveNp_0();
case -1471053772: return bem_initContained_0();
case -1866790687: return bem_isLiteralOnceGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 819712668: return bem_delete_0();
case -978128800: return bem_thirdGet_0();
case 1461034369: return bem_reInitContained_0();
case -1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 1898686885: return bem_toStringBig_0();
case -1566845998: return bem_anchorGet_0();
case -213728365: return bem_scopeGet_0();
case 1956934267: return bem_heldByGet_0();
case 1388725781: return bem_prefixGet_0();
case -1779180144: return bem_nextDescendGet_0();
case -644675716: return bem_ntypesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -2087681086: return bem_typenameGet_0();
case 927274360: return bem_constantsGet_0();
case -1012494862: return bem_once_0();
case -493012039: return bem_buildGet_0();
case -314718434: return bem_print_0();
case -124944494: return bem_nextPeerGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -1279784069: return bem_defined_1(bevd_0);
case -57310426: return bem_delayDeleteSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 875977779: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case 443337441: return bem_containedSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case -205397975: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 351079960: return bem_nlecSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1170500300: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case -1671186230: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case 1487970429: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case 841707881: return bem_inlinedSet_1(bevd_0);
case -1003361751: return bem_typeDetailSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case -2076598833: return bem_typenameSet_1(bevd_0);
case 527912399: return bem_condvarSet_1(bevd_0);
case -1668215656: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1968016520: return bem_heldBySet_1(bevd_0);
case -167727545: return bem_callIsSafe_1((BEC_2_5_4_BuildNode) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1584180177: return bem_nlcSet_1(bevd_0);
case -1007846464: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 2139839746: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1511075536: return bem_wideStringSet_1(bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1545079363: return bem_tmpVar_2(bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildNode.bevs_inst = (BEC_2_5_4_BuildNode)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildNode.bevs_inst;
}
}
}
