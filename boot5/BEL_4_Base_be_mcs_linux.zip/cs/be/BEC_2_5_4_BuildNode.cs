namespace be {
/* IO:File: source/build/Nodes.be */
public sealed class BEC_2_5_4_BuildNode : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
static BEC_2_5_4_BuildNode() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C};
private static byte[] bels_1 = {0x3E};
private static byte[] bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_5 = {0x20};
private static byte[] bels_6 = {0x3C};
private static byte[] bels_7 = {0x3E};
private static byte[] bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 7));
private static byte[] bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 8));
private static byte[] bels_10 = {0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 1));
private static byte[] bels_11 = {0x20,0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 2));
private static byte[] bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bels_13 = {0x5F,0x74,0x6D,0x70,0x61,0x6E,0x79,0x5F};
private static byte[] bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 18));
private static byte[] bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_2_9_3_ContainerSet bevo_5;
private static BEC_2_9_3_ContainerSet bevo_6;
private static BEC_2_9_3_ContainerSet bevo_7;
private static BEC_2_9_3_ContainerSet bevo_8;
private static BEC_2_9_3_ContainerSet bevo_9;
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_2_5_4_BuildNode bevs_inst;
public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_6_6_SystemObject bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_nlec = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_wideString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_phold.bem_copy_0();
bevt_1_tmpany_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (bevp_contained == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_4_tmpany_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 47 */
 else  /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 47 */ {
bevt_5_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_tmpany_phold;
} /* Line: 48 */
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 52 */ {
if (bevl_ret == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 52 */ {
if (bevl_con == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 52 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 54 */
 else  /* Line: 52 */ {
break;
} /* Line: 52 */
} /* Line: 52 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 62 */ {
if (bevl_ret == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 62 */ {
if (bevl_con == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 62 */
 else  /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 62 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 64 */
 else  /* Line: 62 */ {
break;
} /* Line: 62 */
} /* Line: 62 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 70 */ {
return null;
} /* Line: 71 */
bevl_hh = bevp_heldBy.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 74 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 75 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 81 */ {
return null;
} /* Line: 82 */
bevl_hh = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 85 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 86 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 105 */
bevt_3_tmpany_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_3_tmpany_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 111 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 112 */
bevt_7_tmpany_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_4_tmpany_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 118 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 118 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_7_tmpany_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 118 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 118 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 118 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 119 */
bevt_12_tmpany_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_10_tmpany_phold == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() {
bevp_delayDelete = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 129 */ {
return null;
} /* Line: 130 */
bevp_heldBy.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 138 */ {
return null;
} /* Line: 139 */
bevt_2_tmpany_phold = bevp_heldBy.bemd_0(-1849179299, BEL_4_Base.bevn_mylistGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(-743891212, BEL_4_Base.bevn_newNode_1, beva_x);
bevp_heldBy.bemd_1(-1505376950, BEL_4_Base.bevn_insertBefore_1, bevt_1_tmpany_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 146 */ {
this.bem_initContained_0();
} /* Line: 147 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 154 */ {
this.bem_initContained_0();
} /* Line: 155 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 167 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try  /* Line: 173 */ {
bevl_res = this.bem_toStringCompact_0();
} /* Line: 174 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 177 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_2_tmpany_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_typename.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevl_ret = bevt_1_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_newlineGet_0();
bevt_8_tmpany_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_2));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_12_tmpany_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 186 */ {
if (bevp_inFile == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 186 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 186 */
 else  /* Line: 186 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 186 */ {
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_newlineGet_0();
bevt_20_tmpany_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_3));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_4));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_25_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_inFile);
bevt_27_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpany_phold);
} /* Line: 187 */
if (bevp_held == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_32_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_newlineGet_0();
bevt_30_tmpany_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_31_tmpany_phold);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_5));
bevl_ret = bevt_29_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_34_tmpany_phold);
} /* Line: 191 */
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpany_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_typename.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_7));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpany_phold);
if (bevp_nlc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_7_tmpany_phold = bevo_0;
bevt_6_tmpany_phold = bevl_ret.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 200 */
if (bevp_inClassNp == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevt_11_tmpany_phold = bevo_1;
bevt_10_tmpany_phold = bevl_ret.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
} /* Line: 203 */
if (bevp_held == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevt_15_tmpany_phold = bevo_2;
bevt_14_tmpany_phold = bevl_ret.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevt_14_tmpany_phold.bem_add_1(bevt_16_tmpany_phold);
} /* Line: 206 */
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 214 */ {
if (bevl_c == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 216 */
 else  /* Line: 214 */ {
break;
} /* Line: 214 */
} /* Line: 214 */
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = this.bem_depthGet_0();
bevl_p = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = bevo_3;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 225 */ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 225 */
 else  /* Line: 225 */ {
break;
} /* Line: 225 */
} /* Line: 225 */
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 233 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 233 */
 else  /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 233 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 234 */
 else  /* Line: 233 */ {
break;
} /* Line: 233 */
} /* Line: 233 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
bevl_clnode = this.bem_scopeGet_0();
bevt_1_tmpany_phold = bevl_clnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_2_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 241 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bels_12));
bevt_3_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 242 */
bevt_6_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevl_tmpanyn = bevt_5_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_8_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevt_7_tmpany_phold.bemd_0(-1205852557, BEL_4_Base.bevn_incrementValue_0);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(-1124689062, BEL_4_Base.bevn_isTmpVarSet_1, bevt_9_tmpany_phold);
bevl_tmpany.bemd_1(-2093073725, BEL_4_Base.bevn_suffixSet_1, beva_suffix);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_13));
bevt_11_tmpany_phold = bevl_tmpanyn.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_12_tmpany_phold);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, beva_suffix);
bevl_tmpany.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_10_tmpany_phold);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 255 */ {
if (bevl_con == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_2_tmpany_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 256 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 257 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 259 */
 else  /* Line: 255 */ {
break;
} /* Line: 255 */
} /* Line: 255 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevl_v = bevp_held;
bevt_2_tmpany_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 266 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_3_tmpany_phold);
bevl_sco = this.bem_scopeGet_0();
bevt_5_tmpany_phold = bevl_sco.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 269 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(54, bels_14));
bevt_7_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 270 */
bevt_9_tmpany_phold = this.bem_inPropertiesGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_11_tmpany_phold = bevl_v.bemd_0(-1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 272 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 272 */ {
bevl_sco = this.bem_classGet_0();
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_12_tmpany_phold);
} /* Line: 274 */
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpany_phold = bevl_sc.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_15_tmpany_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_15_tmpany_phold);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bels_15));
bevt_16_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 278 */
bevt_18_tmpany_phold = bevl_sc.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_19_tmpany_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_18_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_19_tmpany_phold, this);
bevt_20_tmpany_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_20_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 281 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevl_v = bevp_held;
bevt_1_tmpany_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_2_tmpany_phold);
bevl_sco = this.bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpany_phold = bevl_sc.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_5_tmpany_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_5_tmpany_phold);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 291 */ {
bevt_6_tmpany_phold = bevl_sc.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_7_tmpany_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_6_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpany_phold);
} /* Line: 292 */
 else  /* Line: 293 */ {
bevt_8_tmpany_phold = this.bem_classGet_0();
bevl_cl = bevt_8_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevl_cl.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_11_tmpany_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_11_tmpany_phold);
if (bevt_9_tmpany_phold != null && bevt_9_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_12_tmpany_phold = bevl_cl.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_13_tmpany_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_12_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_13_tmpany_phold);
} /* Line: 296 */
 else  /* Line: 297 */ {
bevt_14_tmpany_phold = bevl_sc.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_15_tmpany_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_15_tmpany_phold, this);
bevt_16_tmpany_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_16_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
bevt_18_tmpany_phold = bevl_sco.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_19_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_19_tmpany_phold);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpany_phold).bevi_bool) /* Line: 300 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bels_16));
bevt_20_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 301 */
} /* Line: 300 */
} /* Line: 295 */
} /* Line: 291 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_13_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpany_phold = this.bem_scopeGet_0();
bevl_sc = bevt_0_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpany_phold = bevl_sc.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 312 */ {
bevt_4_tmpany_phold = bevl_sc.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_3_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 313 */
 else  /* Line: 314 */ {
bevt_5_tmpany_phold = this.bem_classGet_0();
bevl_cl = bevt_5_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpany_phold = bevl_cl.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 316 */ {
bevt_9_tmpany_phold = bevl_cl.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_8_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 317 */
 else  /* Line: 318 */ {
bevl_tunode = this.bem_transUnitGet_0();
bevt_11_tmpany_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_np = bevt_10_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_14_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_aliasedGet_0();
bevl_np = bevt_13_tmpany_phold.bem_get_1(bevl_vname);
} /* Line: 322 */
if (bevl_np == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 324 */ {
bevt_18_tmpany_phold = bevo_4;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevl_np);
bevt_16_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 325 */
 else  /* Line: 326 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevl_vname);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_18));
bevt_19_tmpany_phold = bevl_vname.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpany_phold);
if (bevt_19_tmpany_phold != null && bevt_19_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_19_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevp_held = bevl_v;
bevt_21_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevl_cl.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_22_tmpany_phold);
bevt_23_tmpany_phold = bevl_sc.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_23_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_24_tmpany_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_24_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 335 */
 else  /* Line: 336 */ {
bevt_25_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(1465928304, BEL_4_Base.bevn_isDeclaredSet_1, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_26_tmpany_phold);
bevp_held = bevl_v;
bevt_27_tmpany_phold = bevl_cl.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_27_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_28_tmpany_phold = bevl_cl.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_28_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 341 */
} /* Line: 330 */
} /* Line: 324 */
} /* Line: 316 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_node = this;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 350 */ {
while (true)
 /* Line: 351 */ {
bevt_2_tmpany_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpany_phold = bevl_node.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_has_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 352 */ {
return bevl_node;
} /* Line: 353 */
 else  /* Line: 354 */ {
bevl_node = bevl_node.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
if (bevl_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 356 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_19));
bevt_5_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 357 */
} /* Line: 356 */
} /* Line: 352 */
} /* Line: 351 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 366 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 366 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 366 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 366 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 366 */
 else  /* Line: 366 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 366 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 367 */
 else  /* Line: 366 */ {
break;
} /* Line: 366 */
} /* Line: 366 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 374 */ {
if (bevl_targ == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 374 */ {
bevt_5_tmpany_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 374 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 374 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 374 */
 else  /* Line: 374 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 374 */ {
bevt_8_tmpany_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_9_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_9_tmpany_phold);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 374 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 374 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 374 */
 else  /* Line: 374 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 374 */ {
bevt_11_tmpany_phold = bevl_targ.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 374 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 374 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 374 */
 else  /* Line: 374 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 374 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 375 */
 else  /* Line: 374 */ {
break;
} /* Line: 374 */
} /* Line: 374 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 381 */ {
return null;
} /* Line: 382 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) {
beva_other.bem_delete_0();
this.bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 395 */ {
bevt_0_tmpany_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 395 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, this);
} /* Line: 397 */
 else  /* Line: 395 */ {
break;
} /* Line: 395 */
} /* Line: 395 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 403 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 406 */
} /* Line: 405 */
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 411 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 412 */
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevl_np == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 416 */
bevt_8_tmpany_phold = bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_held.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_7_tmpany_phold);
} /* Line: 418 */
bevt_10_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 420 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 422 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 423 */
} /* Line: 422 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_callIsSafe_1(BEC_2_5_4_BuildNode beva_call) {
BEC_2_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses = null;
BEC_2_9_3_ContainerSet bevl_okCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses2 = null;
BEC_2_9_3_ContainerSet bevl_okCalls2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
bevt_2_tmpany_phold = beva_call.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 433 */ {
bevt_6_tmpany_phold = beva_call.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_20));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_7_tmpany_phold);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 433 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 433 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 433 */
 else  /* Line: 433 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 433 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 434 */
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_5 == null) {
bevo_5 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bevo_5;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_6 == null) {
bevo_6 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bevo_6;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_7 == null) {
bevo_7 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bevo_7;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_8 == null) {
bevo_8 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bevo_8;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bevo_9 == null) {
bevo_9 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bevo_9;
bevt_10_tmpany_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpany_phold = bevo_10;
if (bevt_10_tmpany_phold.bevi_int == bevt_11_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 442 */ {
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpany_phold);
} /* Line: 492 */
bevt_48_tmpany_phold = beva_call.bem_heldGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpany_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpany_phold);
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 496 */ {
bevt_49_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_49_tmpany_phold;
} /* Line: 498 */
bevt_54_tmpany_phold = beva_call.bem_containedGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_firstGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpany_phold != null && bevt_50_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpany_phold).bevi_bool) /* Line: 502 */ {
bevt_55_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_55_tmpany_phold;
} /* Line: 504 */
bevt_61_tmpany_phold = beva_call.bem_containedGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_56_tmpany_phold = bevl_okClasses.bem_has_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 512 */ {
bevt_64_tmpany_phold = beva_call.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpany_phold = bevl_okCalls.bem_has_1(bevt_63_tmpany_phold);
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 513 */ {
bevt_65_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_65_tmpany_phold;
} /* Line: 515 */
 else  /* Line: 516 */ {
} /* Line: 516 */
} /* Line: 513 */
bevt_71_tmpany_phold = beva_call.bem_containedGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_firstGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_66_tmpany_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 520 */ {
bevt_74_tmpany_phold = beva_call.bem_heldGet_0();
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_72_tmpany_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpany_phold);
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 521 */ {
bevt_75_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_75_tmpany_phold;
} /* Line: 523 */
 else  /* Line: 524 */ {
} /* Line: 524 */
} /* Line: 521 */
bevt_76_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_76_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralOnceGet_0() {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_BuildNode bevl_c0 = null;
BEC_2_5_4_BuildNode bevl_c1 = null;
BEC_2_5_4_BuildNode bevl_call = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_4_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevp_typename.bevi_int != bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 545 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 545 */
bevt_7_tmpany_phold = bevp_held.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_55));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpany_phold);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 546 */ {
bevl_c0 = (BEC_2_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_2_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 549 */ {
bevt_11_tmpany_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_11_tmpany_phold.bevi_int == bevt_12_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 549 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 549 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 549 */
 else  /* Line: 549 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 549 */ {
bevt_14_tmpany_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 550 */ {
bevt_17_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(1126433704, BEL_4_Base.bevn_isPropertyGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 550 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 550 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 550 */
 else  /* Line: 550 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 550 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_19_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpany_loop = bevt_18_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 552 */ {
bevt_20_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpany_phold != null && bevt_20_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpany_phold).bevi_bool) /* Line: 552 */ {
bevl_call = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_21_tmpany_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 553 */ {
bevt_23_tmpany_phold = this.bem_callIsSafe_1(bevl_call);
if (bevt_23_tmpany_phold.bevi_bool) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 554 */ {
bevt_24_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_24_tmpany_phold;
} /* Line: 555 */
} /* Line: 554 */
} /* Line: 553 */
 else  /* Line: 552 */ {
break;
} /* Line: 552 */
} /* Line: 552 */
} /* Line: 552 */
} /* Line: 550 */
} /* Line: 549 */
return bevl_result;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldByGet_0() {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heldBy = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_condany = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeDetail = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {26, 27, 28, 29, 31, 32, 33, 34, 35, 40, 40, 41, 41, 42, 43, 47, 47, 47, 47, 47, 0, 0, 0, 48, 48, 50, 51, 52, 52, 52, 52, 0, 0, 0, 53, 54, 56, 60, 61, 62, 62, 62, 62, 0, 0, 0, 63, 64, 66, 70, 70, 71, 73, 74, 74, 75, 77, 77, 81, 81, 82, 84, 85, 85, 86, 88, 88, 92, 92, 96, 96, 100, 100, 104, 104, 105, 105, 107, 107, 107, 111, 111, 0, 111, 111, 111, 0, 0, 112, 112, 114, 114, 114, 114, 118, 118, 0, 118, 118, 118, 0, 0, 0, 118, 118, 118, 118, 0, 0, 119, 119, 121, 121, 121, 121, 121, 125, 129, 129, 130, 132, 133, 134, 138, 138, 139, 141, 141, 141, 142, 146, 146, 147, 149, 150, 154, 154, 155, 157, 158, 162, 166, 166, 167, 174, 176, 177, 179, 183, 184, 184, 184, 184, 184, 184, 185, 185, 185, 185, 185, 185, 185, 185, 186, 186, 186, 186, 0, 0, 0, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 189, 189, 190, 190, 190, 190, 190, 190, 191, 191, 193, 197, 198, 198, 198, 198, 198, 198, 199, 199, 200, 200, 200, 200, 202, 202, 203, 203, 203, 203, 205, 205, 206, 206, 206, 206, 208, 212, 213, 214, 214, 215, 216, 218, 222, 223, 224, 225, 225, 225, 226, 225, 228, 232, 233, 233, 233, 233, 233, 0, 0, 0, 234, 236, 240, 241, 241, 241, 242, 242, 242, 244, 244, 244, 245, 245, 245, 246, 247, 247, 248, 249, 249, 249, 249, 250, 254, 255, 255, 256, 256, 256, 256, 257, 257, 259, 261, 261, 265, 266, 266, 267, 267, 268, 269, 269, 269, 270, 270, 270, 272, 272, 272, 0, 0, 0, 273, 274, 274, 276, 277, 277, 277, 278, 278, 278, 280, 280, 280, 281, 281, 286, 287, 287, 288, 288, 289, 290, 291, 291, 291, 292, 292, 292, 294, 294, 295, 295, 295, 296, 296, 296, 298, 298, 298, 299, 299, 300, 300, 300, 301, 301, 301, 310, 311, 311, 312, 312, 313, 313, 313, 315, 315, 316, 316, 317, 317, 317, 319, 320, 320, 320, 321, 321, 322, 322, 322, 324, 324, 325, 325, 325, 325, 328, 329, 330, 330, 331, 332, 332, 333, 333, 334, 334, 335, 335, 337, 337, 338, 338, 339, 340, 340, 341, 341, 349, 350, 352, 352, 352, 353, 355, 356, 356, 357, 357, 357, 365, 366, 366, 366, 366, 366, 0, 0, 0, 367, 369, 373, 374, 374, 374, 374, 374, 0, 0, 0, 374, 374, 374, 0, 0, 0, 374, 374, 374, 0, 0, 0, 375, 377, 381, 381, 382, 384, 385, 389, 390, 394, 395, 395, 396, 397, 403, 403, 403, 404, 405, 405, 406, 409, 409, 409, 410, 411, 411, 412, 414, 415, 415, 416, 418, 418, 418, 420, 420, 420, 421, 422, 422, 423, 433, 433, 433, 433, 433, 433, 433, 0, 0, 0, 434, 434, 437, 438, 439, 440, 441, 442, 442, 442, 442, 449, 449, 452, 452, 453, 453, 455, 455, 456, 456, 457, 457, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 473, 473, 474, 474, 475, 475, 476, 476, 477, 477, 478, 478, 479, 479, 483, 483, 484, 484, 485, 485, 486, 486, 491, 491, 492, 492, 496, 496, 496, 498, 498, 502, 502, 502, 502, 502, 504, 504, 512, 512, 512, 512, 512, 512, 513, 513, 513, 515, 515, 520, 520, 520, 520, 520, 520, 521, 521, 521, 523, 523, 529, 529, 540, 545, 545, 545, 545, 545, 546, 546, 546, 547, 548, 549, 549, 549, 549, 549, 549, 0, 0, 0, 550, 550, 550, 550, 550, 0, 0, 0, 551, 552, 552, 552, 0, 552, 552, 553, 554, 554, 554, 555, 555, 566, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {94, 95, 96, 97, 98, 99, 100, 101, 102, 108, 109, 110, 111, 112, 113, 127, 132, 133, 134, 139, 140, 143, 147, 150, 151, 153, 154, 157, 162, 163, 168, 169, 172, 176, 179, 180, 186, 194, 195, 198, 203, 204, 209, 210, 213, 217, 220, 221, 227, 234, 239, 240, 242, 243, 248, 249, 251, 252, 259, 264, 265, 267, 268, 273, 274, 276, 277, 281, 282, 286, 287, 291, 292, 299, 304, 305, 306, 308, 309, 314, 325, 330, 331, 334, 335, 340, 341, 344, 348, 349, 351, 352, 353, 358, 374, 379, 380, 383, 384, 389, 390, 393, 397, 400, 401, 402, 407, 408, 411, 415, 416, 418, 419, 420, 421, 426, 429, 434, 439, 440, 442, 443, 444, 451, 456, 457, 459, 460, 461, 462, 467, 472, 473, 475, 476, 481, 486, 487, 489, 490, 494, 499, 504, 505, 513, 517, 518, 520, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 580, 581, 586, 587, 590, 594, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 612, 617, 618, 619, 620, 621, 622, 623, 624, 625, 627, 649, 650, 651, 652, 653, 654, 655, 656, 661, 662, 663, 664, 665, 667, 672, 673, 674, 675, 676, 678, 683, 684, 685, 686, 687, 689, 695, 696, 699, 704, 705, 706, 712, 720, 721, 722, 723, 726, 731, 732, 733, 739, 748, 751, 756, 757, 758, 759, 761, 764, 768, 771, 777, 796, 797, 798, 799, 801, 802, 803, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 829, 832, 837, 838, 839, 840, 845, 846, 847, 849, 855, 856, 883, 884, 885, 887, 888, 889, 890, 891, 892, 894, 895, 896, 898, 900, 901, 903, 906, 910, 913, 914, 915, 917, 918, 919, 920, 922, 923, 924, 926, 927, 928, 929, 930, 961, 962, 963, 965, 966, 967, 968, 969, 970, 971, 973, 974, 975, 978, 979, 980, 981, 982, 984, 985, 986, 989, 990, 991, 992, 993, 994, 995, 996, 998, 999, 1000, 1043, 1044, 1045, 1046, 1047, 1049, 1050, 1051, 1054, 1055, 1056, 1057, 1059, 1060, 1061, 1064, 1065, 1066, 1067, 1068, 1073, 1074, 1075, 1076, 1078, 1083, 1084, 1085, 1086, 1087, 1090, 1091, 1092, 1093, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1130, 1131, 1135, 1136, 1137, 1139, 1142, 1143, 1148, 1149, 1150, 1151, 1165, 1168, 1173, 1174, 1175, 1176, 1178, 1181, 1185, 1188, 1194, 1211, 1214, 1219, 1220, 1221, 1222, 1224, 1227, 1231, 1234, 1235, 1236, 1238, 1241, 1245, 1248, 1249, 1250, 1252, 1255, 1259, 1262, 1268, 1272, 1277, 1278, 1280, 1281, 1285, 1286, 1293, 1294, 1297, 1299, 1300, 1322, 1323, 1328, 1329, 1330, 1335, 1336, 1339, 1340, 1345, 1346, 1347, 1352, 1353, 1355, 1356, 1361, 1362, 1364, 1365, 1366, 1368, 1369, 1374, 1375, 1376, 1381, 1382, 1470, 1471, 1473, 1474, 1475, 1476, 1477, 1479, 1482, 1486, 1489, 1490, 1492, 1498, 1504, 1510, 1516, 1522, 1523, 1524, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1597, 1599, 1600, 1601, 1603, 1604, 1606, 1607, 1608, 1609, 1610, 1612, 1613, 1615, 1616, 1617, 1618, 1619, 1620, 1622, 1623, 1624, 1626, 1627, 1632, 1633, 1634, 1635, 1636, 1637, 1639, 1640, 1641, 1643, 1644, 1649, 1650, 1682, 1683, 1684, 1689, 1690, 1691, 1693, 1694, 1695, 1697, 1698, 1699, 1704, 1705, 1706, 1707, 1712, 1713, 1716, 1720, 1723, 1724, 1726, 1727, 1728, 1730, 1733, 1737, 1740, 1741, 1742, 1743, 1743, 1746, 1748, 1749, 1751, 1752, 1757, 1758, 1759, 1770, 1773, 1776, 1780, 1783, 1787, 1790, 1794, 1797, 1801, 1804, 1808, 1811, 1815, 1818, 1822, 1825, 1829, 1832, 1836, 1839, 1843, 1846, 1850, 1853, 1857, 1860, 1864, 1867, 1871, 1874, 1878, 1881, 1885, 1888};
/* BEGIN LINEINFO 
assign 1 26 94
new 0 26 94
assign 1 27 95
new 0 27 95
assign 1 28 96
new 0 28 96
assign 1 29 97
new 0 29 97
assign 1 31 98
assign 1 32 99
constantsGet 0 32 99
assign 1 33 100
ntypesGet 0 33 100
assign 1 34 101
TOKENGet 0 34 101
assign 1 35 102
new 0 35 102
assign 1 40 108
nlcGet 0 40 108
assign 1 40 109
copy 0 40 109
assign 1 41 110
nlecGet 0 41 110
assign 1 41 111
copy 0 41 111
assign 1 42 112
inClassNpGet 0 42 112
assign 1 43 113
inFileGet 0 43 113
assign 1 47 127
def 1 47 132
assign 1 47 133
firstGet 0 47 133
assign 1 47 134
def 1 47 139
assign 1 0 140
assign 1 0 143
assign 1 0 147
assign 1 48 150
firstGet 0 48 150
return 1 48 151
assign 1 50 153
nextPeerGet 0 50 153
assign 1 51 154
assign 1 52 157
undef 1 52 162
assign 1 52 163
def 1 52 168
assign 1 0 169
assign 1 0 172
assign 1 0 176
assign 1 53 179
nextPeerGet 0 53 179
assign 1 54 180
containerGet 0 54 180
return 1 56 186
assign 1 60 194
nextPeerGet 0 60 194
assign 1 61 195
assign 1 62 198
undef 1 62 203
assign 1 62 204
def 1 62 209
assign 1 0 210
assign 1 0 213
assign 1 0 217
assign 1 63 220
nextPeerGet 0 63 220
assign 1 64 221
containerGet 0 64 221
return 1 66 227
assign 1 70 234
undef 1 70 239
return 1 71 240
assign 1 73 242
nextGet 0 73 242
assign 1 74 243
undef 1 74 248
return 1 75 249
assign 1 77 251
heldGet 0 77 251
return 1 77 252
assign 1 81 259
undef 1 81 264
return 1 82 265
assign 1 84 267
priorGet 0 84 267
assign 1 85 268
undef 1 85 273
return 1 86 274
assign 1 88 276
heldGet 0 88 276
return 1 88 277
assign 1 92 281
firstGet 0 92 281
return 1 92 282
assign 1 96 286
secondGet 0 96 286
return 1 96 287
assign 1 100 291
thirdGet 0 100 291
return 1 100 292
assign 1 104 299
undef 1 104 304
assign 1 105 305
new 0 105 305
return 1 105 306
assign 1 107 308
priorGet 0 107 308
assign 1 107 309
undef 1 107 314
return 1 107 314
assign 1 111 325
undef 1 111 330
assign 1 0 331
assign 1 111 334
priorGet 0 111 334
assign 1 111 335
undef 1 111 340
assign 1 0 341
assign 1 0 344
assign 1 112 348
new 0 112 348
return 1 112 349
assign 1 114 351
priorGet 0 114 351
assign 1 114 352
priorGet 0 114 352
assign 1 114 353
undef 1 114 358
return 1 114 358
assign 1 118 374
undef 1 118 379
assign 1 0 380
assign 1 118 383
priorGet 0 118 383
assign 1 118 384
undef 1 118 389
assign 1 0 390
assign 1 0 393
assign 1 0 397
assign 1 118 400
priorGet 0 118 400
assign 1 118 401
priorGet 0 118 401
assign 1 118 402
undef 1 118 407
assign 1 0 408
assign 1 0 411
assign 1 119 415
new 0 119 415
return 1 119 416
assign 1 121 418
priorGet 0 121 418
assign 1 121 419
priorGet 0 121 419
assign 1 121 420
priorGet 0 121 420
assign 1 121 421
undef 1 121 426
return 1 121 426
assign 1 125 429
new 0 125 429
assign 1 129 434
undef 1 129 439
return 1 130 440
delete 0 132 442
assign 1 133 443
assign 1 134 444
assign 1 138 451
undef 1 138 456
return 1 139 457
assign 1 141 459
mylistGet 0 141 459
assign 1 141 460
newNode 1 141 460
insertBefore 1 141 461
containerSet 1 142 462
assign 1 146 467
undef 1 146 472
initContained 0 147 473
prepend 1 149 475
containerSet 1 150 476
assign 1 154 481
undef 1 154 486
initContained 0 155 487
addValue 1 157 489
containerSet 1 158 490
assign 1 162 494
new 0 162 494
assign 1 166 499
undef 1 166 504
assign 1 167 505
new 0 167 505
assign 1 174 513
toStringCompact 0 174 513
print 0 176 517
throw 1 177 518
return 1 179 520
assign 1 183 560
prefixGet 0 183 560
assign 1 184 561
new 0 184 561
assign 1 184 562
add 1 184 562
assign 1 184 563
toString 0 184 563
assign 1 184 564
add 1 184 564
assign 1 184 565
new 0 184 565
assign 1 184 566
add 1 184 566
assign 1 185 567
new 0 185 567
assign 1 185 568
newlineGet 0 185 568
assign 1 185 569
add 1 185 569
assign 1 185 570
add 1 185 570
assign 1 185 571
new 0 185 571
assign 1 185 572
add 1 185 572
assign 1 185 573
toString 0 185 573
assign 1 185 574
add 1 185 574
assign 1 186 575
def 1 186 580
assign 1 186 581
def 1 186 586
assign 1 0 587
assign 1 0 590
assign 1 0 594
assign 1 187 597
new 0 187 597
assign 1 187 598
newlineGet 0 187 598
assign 1 187 599
add 1 187 599
assign 1 187 600
add 1 187 600
assign 1 187 601
new 0 187 601
assign 1 187 602
add 1 187 602
assign 1 187 603
toString 0 187 603
assign 1 187 604
add 1 187 604
assign 1 187 605
new 0 187 605
assign 1 187 606
add 1 187 606
assign 1 187 607
add 1 187 607
assign 1 187 608
new 0 187 608
assign 1 187 609
newlineGet 0 187 609
assign 1 187 610
add 1 187 610
assign 1 189 612
def 1 189 617
assign 1 190 618
new 0 190 618
assign 1 190 619
newlineGet 0 190 619
assign 1 190 620
add 1 190 620
assign 1 190 621
add 1 190 621
assign 1 190 622
new 0 190 622
assign 1 190 623
add 1 190 623
assign 1 191 624
toString 0 191 624
assign 1 191 625
add 1 191 625
return 1 193 627
assign 1 197 649
prefixGet 0 197 649
assign 1 198 650
new 0 198 650
assign 1 198 651
add 1 198 651
assign 1 198 652
toString 0 198 652
assign 1 198 653
add 1 198 653
assign 1 198 654
new 0 198 654
assign 1 198 655
add 1 198 655
assign 1 199 656
def 1 199 661
assign 1 200 662
new 0 200 662
assign 1 200 663
add 1 200 663
assign 1 200 664
toString 0 200 664
assign 1 200 665
add 1 200 665
assign 1 202 667
def 1 202 672
assign 1 203 673
new 0 203 673
assign 1 203 674
add 1 203 674
assign 1 203 675
toString 0 203 675
assign 1 203 676
add 1 203 676
assign 1 205 678
def 1 205 683
assign 1 206 684
new 0 206 684
assign 1 206 685
add 1 206 685
assign 1 206 686
toString 0 206 686
assign 1 206 687
add 1 206 687
return 1 208 689
assign 1 212 695
new 0 212 695
assign 1 213 696
assign 1 214 699
def 1 214 704
incrementValue 0 215 705
assign 1 216 706
containerGet 0 216 706
return 1 218 712
assign 1 222 720
depthGet 0 222 720
assign 1 223 721
new 0 223 721
assign 1 224 722
new 0 224 722
assign 1 225 723
new 0 225 723
assign 1 225 726
lesser 1 225 731
assign 1 226 732
add 1 226 732
incrementValue 0 225 733
return 1 228 739
assign 1 232 748
assign 1 233 751
def 1 233 756
assign 1 233 757
typenameGet 0 233 757
assign 1 233 758
TRANSUNITGet 0 233 758
assign 1 233 759
notEquals 1 233 759
assign 1 0 761
assign 1 0 764
assign 1 0 768
assign 1 234 771
containerGet 0 234 771
return 1 236 777
assign 1 240 796
scopeGet 0 240 796
assign 1 241 797
typenameGet 0 241 797
assign 1 241 798
METHODGet 0 241 798
assign 1 241 799
notEquals 1 241 799
assign 1 242 801
new 0 242 801
assign 1 242 802
new 2 242 802
throw 1 242 803
assign 1 244 805
heldGet 0 244 805
assign 1 244 806
tmpCntGet 0 244 806
assign 1 244 807
toString 0 244 807
assign 1 245 808
heldGet 0 245 808
assign 1 245 809
tmpCntGet 0 245 809
incrementValue 0 245 810
assign 1 246 811
new 0 246 811
assign 1 247 812
new 0 247 812
isTmpVarSet 1 247 813
suffixSet 1 248 814
assign 1 249 815
new 0 249 815
assign 1 249 816
add 1 249 816
assign 1 249 817
add 1 249 817
nameSet 1 249 818
return 1 250 819
assign 1 254 829
assign 1 255 832
def 1 255 837
assign 1 256 838
typenameGet 0 256 838
assign 1 256 839
PROPERTIESGet 0 256 839
assign 1 256 840
equals 1 256 845
assign 1 257 846
new 0 257 846
return 1 257 847
assign 1 259 849
containerGet 0 259 849
assign 1 261 855
new 0 261 855
return 1 261 856
assign 1 265 883
assign 1 266 884
isAddedGet 0 266 884
assign 1 266 885
not 0 266 885
assign 1 267 887
new 0 267 887
isAddedSet 1 267 888
assign 1 268 889
scopeGet 0 268 889
assign 1 269 890
typenameGet 0 269 890
assign 1 269 891
CLASSGet 0 269 891
assign 1 269 892
equals 1 269 892
assign 1 270 894
new 0 270 894
assign 1 270 895
new 2 270 895
throw 1 270 896
assign 1 272 898
inPropertiesGet 0 272 898
assign 1 272 900
isTmpVarGet 0 272 900
assign 1 272 901
not 0 272 901
assign 1 0 903
assign 1 0 906
assign 1 0 910
assign 1 273 913
classGet 0 273 913
assign 1 274 914
new 0 274 914
isPropertySet 1 274 915
assign 1 276 917
heldGet 0 276 917
assign 1 277 918
anyMapGet 0 277 918
assign 1 277 919
nameGet 0 277 919
assign 1 277 920
has 1 277 920
assign 1 278 922
new 0 278 922
assign 1 278 923
new 2 278 923
throw 1 278 924
assign 1 280 926
anyMapGet 0 280 926
assign 1 280 927
nameGet 0 280 927
put 2 280 928
assign 1 281 929
orderedVarsGet 0 281 929
addValue 1 281 930
assign 1 286 961
assign 1 287 962
isAddedGet 0 287 962
assign 1 287 963
not 0 287 963
assign 1 288 965
new 0 288 965
isAddedSet 1 288 966
assign 1 289 967
scopeGet 0 289 967
assign 1 290 968
heldGet 0 290 968
assign 1 291 969
anyMapGet 0 291 969
assign 1 291 970
nameGet 0 291 970
assign 1 291 971
has 1 291 971
assign 1 292 973
anyMapGet 0 292 973
assign 1 292 974
nameGet 0 292 974
assign 1 292 975
get 1 292 975
assign 1 294 978
classGet 0 294 978
assign 1 294 979
heldGet 0 294 979
assign 1 295 980
anyMapGet 0 295 980
assign 1 295 981
nameGet 0 295 981
assign 1 295 982
has 1 295 982
assign 1 296 984
anyMapGet 0 296 984
assign 1 296 985
nameGet 0 296 985
assign 1 296 986
get 1 296 986
assign 1 298 989
anyMapGet 0 298 989
assign 1 298 990
nameGet 0 298 990
put 2 298 991
assign 1 299 992
orderedVarsGet 0 299 992
addValue 1 299 993
assign 1 300 994
typenameGet 0 300 994
assign 1 300 995
CLASSGet 0 300 995
assign 1 300 996
equals 1 300 996
assign 1 301 998
new 0 301 998
assign 1 301 999
new 2 301 999
throw 1 301 1000
assign 1 310 1043
assign 1 311 1044
scopeGet 0 311 1044
assign 1 311 1045
heldGet 0 311 1045
assign 1 312 1046
anyMapGet 0 312 1046
assign 1 312 1047
has 1 312 1047
assign 1 313 1049
anyMapGet 0 313 1049
assign 1 313 1050
get 1 313 1050
assign 1 313 1051
heldGet 0 313 1051
assign 1 315 1054
classGet 0 315 1054
assign 1 315 1055
heldGet 0 315 1055
assign 1 316 1056
anyMapGet 0 316 1056
assign 1 316 1057
has 1 316 1057
assign 1 317 1059
anyMapGet 0 317 1059
assign 1 317 1060
get 1 317 1060
assign 1 317 1061
heldGet 0 317 1061
assign 1 319 1064
transUnitGet 0 319 1064
assign 1 320 1065
heldGet 0 320 1065
assign 1 320 1066
aliasedGet 0 320 1066
assign 1 320 1067
get 1 320 1067
assign 1 321 1068
undef 1 321 1073
assign 1 322 1074
emitDataGet 0 322 1074
assign 1 322 1075
aliasedGet 0 322 1075
assign 1 322 1076
get 1 322 1076
assign 1 324 1078
def 1 324 1083
assign 1 325 1084
new 0 325 1084
assign 1 325 1085
add 1 325 1085
assign 1 325 1086
new 2 325 1086
throw 1 325 1087
assign 1 328 1090
new 0 328 1090
nameSet 1 329 1091
assign 1 330 1092
new 0 330 1092
assign 1 330 1093
equals 1 330 1093
assign 1 331 1095
assign 1 332 1096
new 0 332 1096
isTypedSet 1 332 1097
assign 1 333 1098
extendsGet 0 333 1098
namepathSet 1 333 1099
assign 1 334 1100
anyMapGet 0 334 1100
put 2 334 1101
assign 1 335 1102
orderedVarsGet 0 335 1102
addValue 1 335 1103
assign 1 337 1106
new 0 337 1106
isDeclaredSet 1 337 1107
assign 1 338 1108
new 0 338 1108
isPropertySet 1 338 1109
assign 1 339 1110
assign 1 340 1111
anyMapGet 0 340 1111
put 2 340 1112
assign 1 341 1113
orderedVarsGet 0 341 1113
addValue 1 341 1114
assign 1 349 1130
assign 1 350 1131
new 0 350 1131
assign 1 352 1135
anchorTypesGet 0 352 1135
assign 1 352 1136
typenameGet 0 352 1136
assign 1 352 1137
has 1 352 1137
return 1 353 1139
assign 1 355 1142
containerGet 0 355 1142
assign 1 356 1143
undef 1 356 1148
assign 1 357 1149
new 0 357 1149
assign 1 357 1150
new 2 357 1150
throw 1 357 1151
assign 1 365 1165
assign 1 366 1168
def 1 366 1173
assign 1 366 1174
typenameGet 0 366 1174
assign 1 366 1175
CLASSGet 0 366 1175
assign 1 366 1176
notEquals 1 366 1176
assign 1 0 1178
assign 1 0 1181
assign 1 0 1185
assign 1 367 1188
containerGet 0 367 1188
return 1 369 1194
assign 1 373 1211
assign 1 374 1214
def 1 374 1219
assign 1 374 1220
typenameGet 0 374 1220
assign 1 374 1221
CLASSGet 0 374 1221
assign 1 374 1222
notEquals 1 374 1222
assign 1 0 1224
assign 1 0 1227
assign 1 0 1231
assign 1 374 1234
typenameGet 0 374 1234
assign 1 374 1235
METHODGet 0 374 1235
assign 1 374 1236
notEquals 1 374 1236
assign 1 0 1238
assign 1 0 1241
assign 1 0 1245
assign 1 374 1248
typenameGet 0 374 1248
assign 1 374 1249
TRANSUNITGet 0 374 1249
assign 1 374 1250
notEquals 1 374 1250
assign 1 0 1252
assign 1 0 1255
assign 1 0 1259
assign 1 375 1262
containerGet 0 375 1262
return 1 377 1268
assign 1 381 1272
undef 1 381 1277
return 1 382 1278
containerSet 1 384 1280
heldSet 1 385 1281
delete 0 389 1285
addValue 1 390 1286
assign 1 394 1293
containedGet 0 394 1293
assign 1 395 1294
iteratorGet 0 395 1294
assign 1 395 1297
hasNextGet 0 395 1297
assign 1 396 1299
nextGet 0 396 1299
containerSet 1 397 1300
assign 1 403 1322
NAMEPATHGet 0 403 1322
assign 1 403 1323
equals 1 403 1328
assign 1 404 1329
assign 1 405 1330
def 1 405 1335
resolve 1 406 1336
assign 1 409 1339
CLASSGet 0 409 1339
assign 1 409 1340
equals 1 409 1345
assign 1 410 1346
namepathGet 0 410 1346
assign 1 411 1347
def 1 411 1352
resolve 1 412 1353
assign 1 414 1355
extendsGet 0 414 1355
assign 1 415 1356
def 1 415 1361
resolve 1 416 1362
assign 1 418 1364
namepathGet 0 418 1364
assign 1 418 1365
toString 0 418 1365
nameSet 1 418 1366
assign 1 420 1368
VARGet 0 420 1368
assign 1 420 1369
equals 1 420 1374
assign 1 421 1375
namepathGet 0 421 1375
assign 1 422 1376
def 1 422 1381
resolve 1 423 1382
assign 1 433 1470
heldGet 0 433 1470
assign 1 433 1471
isConstructGet 0 433 1471
assign 1 433 1473
heldGet 0 433 1473
assign 1 433 1474
newNpGet 0 433 1474
assign 1 433 1475
toString 0 433 1475
assign 1 433 1476
new 0 433 1476
assign 1 433 1477
equals 1 433 1477
assign 1 0 1479
assign 1 0 1482
assign 1 0 1486
assign 1 434 1489
new 0 434 1489
return 1 434 1490
assign 1 437 1492
new 0 437 1492
assign 1 438 1498
new 0 438 1498
assign 1 439 1504
new 0 439 1504
assign 1 440 1510
new 0 440 1510
assign 1 441 1516
new 0 441 1516
assign 1 442 1522
sizeGet 0 442 1522
assign 1 442 1523
new 0 442 1523
assign 1 442 1524
equals 1 442 1529
assign 1 449 1530
new 0 449 1530
put 1 449 1531
assign 1 452 1532
new 0 452 1532
put 1 452 1533
assign 1 453 1534
new 0 453 1534
put 1 453 1535
assign 1 455 1536
new 0 455 1536
put 1 455 1537
assign 1 456 1538
new 0 456 1538
put 1 456 1539
assign 1 457 1540
new 0 457 1540
put 1 457 1541
assign 1 458 1542
new 0 458 1542
put 1 458 1543
assign 1 459 1544
new 0 459 1544
put 1 459 1545
assign 1 460 1546
new 0 460 1546
put 1 460 1547
assign 1 461 1548
new 0 461 1548
put 1 461 1549
assign 1 462 1550
new 0 462 1550
put 1 462 1551
assign 1 463 1552
new 0 463 1552
put 1 463 1553
assign 1 464 1554
new 0 464 1554
put 1 464 1555
assign 1 465 1556
new 0 465 1556
put 1 465 1557
assign 1 466 1558
new 0 466 1558
put 1 466 1559
assign 1 467 1560
new 0 467 1560
put 1 467 1561
assign 1 468 1562
new 0 468 1562
put 1 468 1563
assign 1 469 1564
new 0 469 1564
put 1 469 1565
assign 1 470 1566
new 0 470 1566
put 1 470 1567
assign 1 471 1568
new 0 471 1568
put 1 471 1569
assign 1 472 1570
new 0 472 1570
put 1 472 1571
assign 1 473 1572
new 0 473 1572
put 1 473 1573
assign 1 474 1574
new 0 474 1574
put 1 474 1575
assign 1 475 1576
new 0 475 1576
put 1 475 1577
assign 1 476 1578
new 0 476 1578
put 1 476 1579
assign 1 477 1580
new 0 477 1580
put 1 477 1581
assign 1 478 1582
new 0 478 1582
put 1 478 1583
assign 1 479 1584
new 0 479 1584
put 1 479 1585
assign 1 483 1586
new 0 483 1586
put 1 483 1587
assign 1 484 1588
new 0 484 1588
put 1 484 1589
assign 1 485 1590
new 0 485 1590
put 1 485 1591
assign 1 486 1592
new 0 486 1592
put 1 486 1593
assign 1 491 1594
new 0 491 1594
put 1 491 1595
assign 1 492 1596
new 0 492 1596
put 1 492 1597
assign 1 496 1599
heldGet 0 496 1599
assign 1 496 1600
nameGet 0 496 1600
assign 1 496 1601
has 1 496 1601
assign 1 498 1603
new 0 498 1603
return 1 498 1604
assign 1 502 1606
containedGet 0 502 1606
assign 1 502 1607
firstGet 0 502 1607
assign 1 502 1608
heldGet 0 502 1608
assign 1 502 1609
isTypedGet 0 502 1609
assign 1 502 1610
not 0 502 1610
assign 1 504 1612
new 0 504 1612
return 1 504 1613
assign 1 512 1615
containedGet 0 512 1615
assign 1 512 1616
firstGet 0 512 1616
assign 1 512 1617
heldGet 0 512 1617
assign 1 512 1618
namepathGet 0 512 1618
assign 1 512 1619
toString 0 512 1619
assign 1 512 1620
has 1 512 1620
assign 1 513 1622
heldGet 0 513 1622
assign 1 513 1623
nameGet 0 513 1623
assign 1 513 1624
has 1 513 1624
assign 1 515 1626
new 0 515 1626
return 1 515 1627
assign 1 520 1632
containedGet 0 520 1632
assign 1 520 1633
firstGet 0 520 1633
assign 1 520 1634
heldGet 0 520 1634
assign 1 520 1635
namepathGet 0 520 1635
assign 1 520 1636
toString 0 520 1636
assign 1 520 1637
has 1 520 1637
assign 1 521 1639
heldGet 0 521 1639
assign 1 521 1640
nameGet 0 521 1640
assign 1 521 1641
has 1 521 1641
assign 1 523 1643
new 0 523 1643
return 1 523 1644
assign 1 529 1649
new 0 529 1649
return 1 529 1650
assign 1 540 1682
new 0 540 1682
assign 1 545 1683
CALLGet 0 545 1683
assign 1 545 1684
notEquals 1 545 1689
assign 1 545 1690
new 0 545 1690
return 1 545 1691
assign 1 546 1693
orgNameGet 0 546 1693
assign 1 546 1694
new 0 546 1694
assign 1 546 1695
equals 1 546 1695
assign 1 547 1697
firstGet 0 547 1697
assign 1 548 1698
secondGet 0 548 1698
assign 1 549 1699
def 1 549 1704
assign 1 549 1705
typenameGet 0 549 1705
assign 1 549 1706
CALLGet 0 549 1706
assign 1 549 1707
equals 1 549 1712
assign 1 0 1713
assign 1 0 1716
assign 1 0 1720
assign 1 550 1723
heldGet 0 550 1723
assign 1 550 1724
isLiteralGet 0 550 1724
assign 1 550 1726
heldGet 0 550 1726
assign 1 550 1727
isPropertyGet 0 550 1727
assign 1 550 1728
not 0 550 1728
assign 1 0 1730
assign 1 0 1733
assign 1 0 1737
assign 1 551 1740
new 0 551 1740
assign 1 552 1741
heldGet 0 552 1741
assign 1 552 1742
allCallsGet 0 552 1742
assign 1 552 1743
iteratorGet 0 0 1743
assign 1 552 1746
hasNextGet 0 552 1746
assign 1 552 1748
nextGet 0 552 1748
assign 1 553 1749
notEquals 1 553 1749
assign 1 554 1751
callIsSafe 1 554 1751
assign 1 554 1752
not 0 554 1757
assign 1 555 1758
new 0 555 1758
return 1 555 1759
return 1 566 1770
return 1 0 1773
assign 1 0 1776
return 1 0 1780
assign 1 0 1783
return 1 0 1787
assign 1 0 1790
return 1 0 1794
assign 1 0 1797
return 1 0 1801
assign 1 0 1804
return 1 0 1808
assign 1 0 1811
return 1 0 1815
assign 1 0 1818
return 1 0 1822
assign 1 0 1825
return 1 0 1829
assign 1 0 1832
return 1 0 1836
assign 1 0 1839
return 1 0 1843
assign 1 0 1846
return 1 0 1850
assign 1 0 1853
return 1 0 1857
assign 1 0 1860
return 1 0 1864
assign 1 0 1867
return 1 0 1871
assign 1 0 1874
return 1 0 1878
assign 1 0 1881
return 1 0 1885
assign 1 0 1888
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 339997707: return bem_nlecGet_0();
case 1820417453: return bem_create_0();
case 822104518: return bem_inFileGet_0();
case 443668840: return bem_methodNotDefined_0();
case 202810500: return bem_depthGet_0();
case -1595262430: return bem_nlcGet_0();
case -786424307: return bem_tagGet_0();
case 1740134355: return bem_syncAddVariable_0();
case -845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1522157789: return bem_wideStringGet_0();
case -68392679: return bem_delayDeleteGet_0();
case -1973596005: return bem_transUnitGet_0();
case 2110470555: return bem_priorPeerGet_0();
case -1081412016: return bem_many_0();
case 931239762: return bem_heldGet_0();
case -312889617: return bem_classGet_0();
case 1425568797: return bem_condanyGet_0();
case 1236878826: return bem_nextAscendGet_0();
case -1182494494: return bem_toAny_0();
case 1823343663: return bem_inPropertiesGet_0();
case -1014444004: return bem_typeDetailGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -1167184407: return bem_isSecondGet_0();
case 1193143594: return bem_isThirdGet_0();
case -1692872440: return bem_toStringCompact_0();
case -1437330926: return bem_inClassNpGet_0();
case -576537281: return bem_delayDelete_0();
case 830625628: return bem_inlinedGet_0();
case 432255188: return bem_containedGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 287040793: return bem_hashGet_0();
case -729571811: return bem_serializeToString_0();
case 1987872129: return bem_isFirstGet_0();
case -183400265: return bem_firstGet_0();
case 1758195374: return bem_addVariable_0();
case 242848115: return bem_secondGet_0();
case 1952633087: return bem_resolveNp_0();
case -1471053772: return bem_initContained_0();
case -1866790687: return bem_isLiteralOnceGet_0();
case 819712668: return bem_delete_0();
case -978128800: return bem_thirdGet_0();
case 1461034369: return bem_reInitContained_0();
case -1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 1898686885: return bem_toStringBig_0();
case -1566845998: return bem_anchorGet_0();
case -213728365: return bem_scopeGet_0();
case 1956934267: return bem_heldByGet_0();
case 1388725781: return bem_prefixGet_0();
case -1779180144: return bem_nextDescendGet_0();
case -644675716: return bem_ntypesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -2087681086: return bem_typenameGet_0();
case 927274360: return bem_constantsGet_0();
case -1012494862: return bem_once_0();
case -493012039: return bem_buildGet_0();
case -314718434: return bem_print_0();
case -124944494: return bem_nextPeerGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -2076598833: return bem_typenameSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1511075536: return bem_wideStringSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -57310426: return bem_delayDeleteSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 351079960: return bem_nlecSet_1(bevd_0);
case 1436651050: return bem_condanySet_1(bevd_0);
case 1170500300: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case -1671186230: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case -1668215656: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case 875977779: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1003361751: return bem_typeDetailSet_1(bevd_0);
case 1968016520: return bem_heldBySet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 443337441: return bem_containedSet_1(bevd_0);
case 2139839746: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -167727545: return bem_callIsSafe_1((BEC_2_5_4_BuildNode) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1007846464: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -205397975: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1487970429: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case -1584180177: return bem_nlcSet_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case 841707881: return bem_inlinedSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1545079363: return bem_tmpVar_2(bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildNode.bevs_inst = (BEC_2_5_4_BuildNode)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildNode.bevs_inst;
}
}
}
