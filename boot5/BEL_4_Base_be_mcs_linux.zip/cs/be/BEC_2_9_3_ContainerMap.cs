namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap : BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
static BEC_2_9_3_ContainerMap() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_3_ContainerMap bevs_inst;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_21_ContainerMapSerializationIterator) (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
bevt_6_tmpany_phold = bevl_other.bem_sizeGet_0();
bevt_7_tmpany_phold = this.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 129 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 129 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 130 */
bevt_0_tmpany_loop = this.bem_mapIteratorGet_0();
while (true)
 /* Line: 132 */ {
bevt_9_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevl_v = bevl_other.bem_get_1(bevt_10_tmpany_phold);
if (bevl_v == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_13_tmpany_phold = bevl_i.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
if (bevt_13_tmpany_phold == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 134 */ {
if (bevl_v == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 134 */
 else  /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 134 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 134 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_v);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 134 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 134 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 134 */ {
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_17_tmpany_phold;
} /* Line: 134 */
} /* Line: 134 */
 else  /* Line: 132 */ {
break;
} /* Line: 132 */
} /* Line: 132 */
bevt_18_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_18_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 143 */ {
bevt_3_tmpany_phold = this.bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
} /* Line: 144 */
 else  /* Line: 143 */ {
break;
} /* Line: 143 */
} /* Line: 143 */
bevp_slots = bevl_slt;
} /* Line: 146 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 148 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 149 */
return this;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_valueIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_16_ContainerMapKeyValueIterator) (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_tmpany_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
 /* Line: 177 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 177 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_4_tmpany_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_5_tmpany_phold = bevl_x.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 178 */
 else  /* Line: 177 */ {
break;
} /* Line: 177 */
} /* Line: 177 */
} /* Line: 177 */
 else  /* Line: 175 */ {
bevt_6_tmpany_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 180 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_8_tmpany_phold = beva_other.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
} /* Line: 181 */
 else  /* Line: 182 */ {
this.bem_put_2(beva_other, beva_other);
} /* Line: 183 */
} /* Line: 175 */
} /* Line: 175 */
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_toRet = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = this.bem_mapIteratorGet_0();
while (true)
 /* Line: 190 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, beva_prefix);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 191 */ {
bevt_4_tmpany_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_5_tmpany_phold = bevl_x.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevl_toRet.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 192 */
} /* Line: 191 */
 else  /* Line: 190 */ {
break;
} /* Line: 190 */
} /* Line: 190 */
return bevl_toRet;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {111, 111, 115, 116, 117, 118, 119, 120, 124, 124, 128, 129, 129, 0, 129, 129, 129, 129, 0, 0, 130, 130, 132, 0, 132, 132, 133, 133, 134, 134, 0, 134, 134, 134, 134, 134, 0, 0, 0, 0, 0, 0, 134, 134, 0, 0, 134, 134, 136, 136, 140, 140, 141, 142, 143, 143, 144, 146, 149, 154, 154, 158, 158, 162, 162, 166, 166, 170, 170, 174, 174, 175, 176, 177, 0, 177, 177, 178, 178, 178, 180, 181, 181, 181, 183, 189, 190, 0, 190, 190, 191, 191, 192, 192, 192, 195};
public static new int[] bevs_smnlec
 = new int[] {11, 12, 16, 17, 18, 19, 20, 21, 26, 27, 52, 53, 58, 59, 62, 63, 64, 69, 70, 73, 77, 78, 80, 80, 83, 85, 86, 87, 88, 93, 94, 97, 98, 103, 104, 109, 110, 113, 117, 120, 123, 127, 130, 131, 133, 136, 140, 141, 148, 149, 157, 158, 160, 161, 164, 165, 167, 173, 176, 182, 183, 187, 188, 192, 193, 197, 198, 202, 203, 217, 222, 223, 225, 226, 226, 229, 231, 232, 233, 234, 242, 244, 245, 246, 249, 264, 265, 265, 268, 270, 271, 272, 274, 275, 276, 283};
/* BEGIN LINEINFO 
assign 1 111 11
new 0 111 11
new 1 111 12
assign 1 115 16
new 1 115 16
assign 1 116 17
assign 1 117 18
new 0 117 18
assign 1 118 19
new 0 118 19
assign 1 119 20
new 0 119 20
assign 1 120 21
new 0 120 21
assign 1 124 26
new 1 124 26
return 1 124 27
assign 1 128 52
assign 1 129 53
undef 1 129 58
assign 1 0 59
assign 1 129 62
sizeGet 0 129 62
assign 1 129 63
sizeGet 0 129 63
assign 1 129 64
notEquals 1 129 69
assign 1 0 70
assign 1 0 73
assign 1 130 77
new 0 130 77
return 1 130 78
assign 1 132 80
mapIteratorGet 0 0 80
assign 1 132 83
hasNextGet 0 132 83
assign 1 132 85
nextGet 0 132 85
assign 1 133 86
keyGet 0 133 86
assign 1 133 87
get 1 133 87
assign 1 134 88
undef 1 134 93
assign 1 0 94
assign 1 134 97
valueGet 0 134 97
assign 1 134 98
undef 1 134 103
assign 1 134 104
def 1 134 109
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 0 120
assign 1 0 123
assign 1 0 127
assign 1 134 130
valueGet 0 134 130
assign 1 134 131
notEquals 1 134 131
assign 1 0 133
assign 1 0 136
assign 1 134 140
new 0 134 140
return 1 134 141
assign 1 136 148
new 0 136 148
return 1 136 149
assign 1 140 157
innerPut 4 140 157
assign 1 140 158
not 0 140 158
assign 1 141 160
assign 1 142 161
rehash 1 142 161
assign 1 143 164
innerPut 4 143 164
assign 1 143 165
not 0 143 165
assign 1 144 167
rehash 1 144 167
assign 1 146 173
assign 1 149 176
increment 0 149 176
assign 1 154 182
new 1 154 182
return 1 154 183
assign 1 158 187
valueIteratorGet 0 158 187
return 1 158 188
assign 1 162 192
new 1 162 192
return 1 162 193
assign 1 166 197
new 1 166 197
return 1 166 198
assign 1 170 202
new 1 170 202
return 1 170 203
assign 1 174 217
def 1 174 222
assign 1 175 223
sameType 1 175 223
assign 1 176 225
assign 1 177 226
mapIteratorGet 0 0 226
assign 1 177 229
hasNextGet 0 177 229
assign 1 177 231
nextGet 0 177 231
assign 1 178 232
keyGet 0 178 232
assign 1 178 233
valueGet 0 178 233
put 2 178 234
assign 1 180 242
sameType 1 180 242
assign 1 181 244
keyGet 0 181 244
assign 1 181 245
valueGet 0 181 245
put 2 181 246
put 2 183 249
assign 1 189 264
new 0 189 264
assign 1 190 265
mapIteratorGet 0 0 265
assign 1 190 268
hasNextGet 0 190 268
assign 1 190 270
nextGet 0 190 270
assign 1 191 271
keyGet 0 191 271
assign 1 191 272
begins 1 191 272
assign 1 192 274
keyGet 0 192 274
assign 1 192 275
valueGet 0 192 275
put 2 192 276
return 1 195 283
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1227011022: return bem_multiGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -1431826729: return bem_nodeIteratorGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case -1586230380: return bem_moduGet_0();
case -550406779: return bem_valuesGet_0();
case -1308786538: return bem_echo_0();
case 354906194: return bem_slotsGet_0();
case 856777406: return bem_clear_0();
case -712928736: return bem_innerPutAddedGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2086347094: return bem_nodesGet_0();
case -902391673: return bem_keyValueIteratorGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case -2145224760: return bem_valueIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1012494862: return bem_once_0();
case -578884498: return bem_relGet_0();
case 287040793: return bem_hashGet_0();
case -1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 2056412570: return bem_keyIteratorGet_0();
case -1114073101: return bem_keysGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1089531140: return bem_isEmptyGet_0();
case -845792839: return bem_iteratorGet_0();
case -2142483603: return bem_notEmptyGet_0();
case -444835395: return bem_mapIteratorGet_0();
case -314718434: return bem_print_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -1575148127: return bem_moduSet_1(bevd_0);
case 1959489624: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case -567802245: return bem_relSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case -286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -668984013: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 107034370: return bem_put_2(bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -131089957: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerMap.bevs_inst = (BEC_2_9_3_ContainerMap)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerMap.bevs_inst;
}
}
}
