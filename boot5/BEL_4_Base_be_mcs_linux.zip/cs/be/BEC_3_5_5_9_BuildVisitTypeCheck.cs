namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_9_BuildVisitTypeCheck : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
static BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x61,0x6E,0x79,0x29};
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 13));
private static byte[] bels_3 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 13));
private static byte[] bels_4 = {0x28,0x42,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 17));
private static byte[] bels_5 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 10));
private static byte[] bels_6 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x61,0x6E,0x79,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_7 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_7, 30));
private static byte[] bels_8 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 19));
private static byte[] bels_9 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_10 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] bels_11 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] bels_13 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 67));
private static byte[] bels_14 = {0x20};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 1));
private static byte[] bels_15 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bels_16 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_17 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_18 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 13));
private static byte[] bels_19 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_19, 13));
private static byte[] bels_20 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_20, 13));
private static byte[] bels_21 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_21, 10));
private static byte[] bels_22 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bels_23 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x61,0x6E,0x79,0x20};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_23, 19));
private static byte[] bels_24 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_24, 52));
private static byte[] bels_25 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_25, 5));
public static new BEC_3_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cany = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_4_ContainerList bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_18_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_131_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_136_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_137_tmpany_phold = null;
BEC_2_4_6_TextString bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_4_6_TextString bevt_142_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_4_6_TextString bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_157_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_181_tmpany_phold = null;
BEC_2_4_6_TextString bevt_182_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_183_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_184_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_185_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_186_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpany_phold = null;
BEC_2_4_6_TextString bevt_190_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_191_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_192_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_193_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_194_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_196_tmpany_phold = null;
BEC_2_4_6_TextString bevt_197_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_198_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_200_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_204_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_205_tmpany_phold = null;
BEC_2_4_6_TextString bevt_206_tmpany_phold = null;
BEC_2_4_6_TextString bevt_207_tmpany_phold = null;
BEC_2_4_6_TextString bevt_208_tmpany_phold = null;
BEC_2_4_6_TextString bevt_209_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpany_phold = null;
BEC_2_4_6_TextString bevt_211_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_212_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_216_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_217_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_219_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_224_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_226_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_227_tmpany_phold = null;
BEC_2_4_6_TextString bevt_228_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_230_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_231_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_232_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_233_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_238_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_239_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_240_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_241_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_242_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_243_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_244_tmpany_phold = null;
BEC_2_4_6_TextString bevt_245_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_246_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_247_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_248_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_249_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_250_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_251_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_252_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_253_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_254_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_255_tmpany_phold = null;
BEC_2_4_6_TextString bevt_256_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_257_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_258_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_259_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_260_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_261_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_262_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_263_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_264_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_265_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_266_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_267_tmpany_phold = null;
BEC_2_4_6_TextString bevt_268_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_269_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_270_tmpany_phold = null;
BEC_2_4_6_TextString bevt_271_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_272_tmpany_phold = null;
BEC_2_4_6_TextString bevt_273_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_274_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_275_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_276_tmpany_phold = null;
BEC_2_4_6_TextString bevt_277_tmpany_phold = null;
BEC_2_4_6_TextString bevt_278_tmpany_phold = null;
BEC_2_4_6_TextString bevt_279_tmpany_phold = null;
BEC_2_4_6_TextString bevt_280_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_281_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_282_tmpany_phold = null;
BEC_2_4_6_TextString bevt_283_tmpany_phold = null;
BEC_2_4_6_TextString bevt_284_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_285_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_286_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_287_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_288_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_289_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_290_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_291_tmpany_phold = null;
BEC_2_4_6_TextString bevt_292_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_293_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_294_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_295_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_296_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_297_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_298_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_299_tmpany_phold = null;
BEC_2_4_6_TextString bevt_300_tmpany_phold = null;
BEC_2_4_6_TextString bevt_301_tmpany_phold = null;
BEC_2_4_6_TextString bevt_302_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_303_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_304_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_305_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_306_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_307_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_308_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_309_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_310_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_311_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_312_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_313_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_314_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_315_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_316_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_317_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_318_tmpany_phold = null;
BEC_2_4_6_TextString bevt_319_tmpany_phold = null;
BEC_2_4_6_TextString bevt_320_tmpany_phold = null;
BEC_2_4_6_TextString bevt_321_tmpany_phold = null;
BEC_2_4_6_TextString bevt_322_tmpany_phold = null;
BEC_2_4_6_TextString bevt_323_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_324_tmpany_phold = null;
BEC_2_4_6_TextString bevt_325_tmpany_phold = null;
BEC_2_4_6_TextString bevt_326_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_327_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_328_tmpany_phold = null;
bevt_11_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_12_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
if (bevt_11_tmpany_phold.bevi_int == bevt_12_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevt_18_tmpany_phold = beva_node.bem_containedGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_firstGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 394 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bels_0));
bevt_19_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_20_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 395 */
} /* Line: 394 */
bevt_22_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevp_inClass = beva_node;
bevt_24_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_24_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_25_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 401 */
bevt_27_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_28_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_27_tmpany_phold.bevi_int == bevt_28_tmpany_phold.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 403 */ {
bevp_cpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 404 */
bevt_30_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_31_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_tmpany_phold.bevi_int == bevt_31_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_32_tmpany_phold = beva_node.bem_heldGet_0();
bevt_32_tmpany_phold.bemd_1(-2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_33_tmpany_phold = beva_node.bem_containedGet_0();
bevt_0_tmpany_loop = bevt_33_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 409 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpany_phold).bevi_bool) /* Line: 409 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_36_tmpany_phold = bevl_cci.bem_typenameGet_0();
bevt_37_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_36_tmpany_phold.bevi_int == bevt_37_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevt_38_tmpany_phold = bevl_cci.bem_heldGet_0();
bevt_38_tmpany_phold.bemd_1(-474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 411 */
} /* Line: 410 */
 else  /* Line: 409 */ {
break;
} /* Line: 409 */
} /* Line: 409 */
bevt_41_tmpany_phold = beva_node.bem_heldGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_42_tmpany_phold);
if (bevt_39_tmpany_phold != null && bevt_39_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_39_tmpany_phold).bevi_bool) /* Line: 422 */ {
bevt_43_tmpany_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_43_tmpany_phold.bem_firstGet_0();
bevt_45_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_44_tmpany_phold != null && bevt_44_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_44_tmpany_phold).bevi_bool) /* Line: 425 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 426 */
 else  /* Line: 427 */ {
bevt_47_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_49_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_48_tmpany_phold);
bevl_tany = bevt_46_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 428 */
bevt_51_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpany_phold != null && bevt_50_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpany_phold).bevi_bool) /* Line: 431 */ {
bevt_52_tmpany_phold = beva_node.bem_heldGet_0();
bevt_53_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_52_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_53_tmpany_phold);
} /* Line: 432 */
 else  /* Line: 433 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_55_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_56_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_55_tmpany_phold.bevi_int == bevt_56_tmpany_phold.bevi_int) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 435 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 435 */ {
bevt_58_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_59_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_59_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 435 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 435 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 435 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 435 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_60_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_61_tmpany_phold);
} /* Line: 437 */
 else  /* Line: 438 */ {
bevt_63_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_64_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_63_tmpany_phold.bevi_int == bevt_64_tmpany_phold.bevi_int) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevt_66_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_65_tmpany_phold != null && bevt_65_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_65_tmpany_phold).bevi_bool) /* Line: 440 */ {
bevl_oany = bevl_org.bem_heldGet_0();
} /* Line: 441 */
 else  /* Line: 442 */ {
bevt_68_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_70_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_69_tmpany_phold);
bevl_oany = bevt_67_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 444 */
} /* Line: 440 */
 else  /* Line: 439 */ {
bevt_72_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_73_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_72_tmpany_phold.bevi_int == bevt_73_tmpany_phold.bevi_int) {
bevt_71_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_71_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 447 */ {
bevt_74_tmpany_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_74_tmpany_phold.bem_firstGet_0();
bevt_76_tmpany_phold = bevl_ctarg.bem_heldGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_75_tmpany_phold != null && bevt_75_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_75_tmpany_phold).bevi_bool) /* Line: 450 */ {
bevl_cany = bevl_ctarg.bem_heldGet_0();
} /* Line: 452 */
 else  /* Line: 453 */ {
bevt_78_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_80_tmpany_phold = bevl_ctarg.bem_heldGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_79_tmpany_phold);
bevl_cany = bevt_77_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 455 */
bevl_syn = null;
bevt_83_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_82_tmpany_phold == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 459 */ {
bevt_85_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_84_tmpany_phold);
} /* Line: 460 */
 else  /* Line: 459 */ {
bevt_86_tmpany_phold = bevl_cany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_86_tmpany_phold != null && bevt_86_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_86_tmpany_phold).bevi_bool) /* Line: 461 */ {
bevt_87_tmpany_phold = bevl_cany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_87_tmpany_phold);
} /* Line: 463 */
} /* Line: 459 */
if (bevl_syn == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 465 */ {
bevt_89_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_91_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_90_tmpany_phold = bevt_91_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_89_tmpany_phold.bem_get_1(bevt_90_tmpany_phold);
if (bevl_mtdc == null) {
bevt_92_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 467 */ {
bevt_93_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_94_tmpany_phold = bevo_0;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_93_tmpany_phold.bem_get_1(bevt_94_tmpany_phold);
if (bevl_fcms == null) {
bevt_95_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_95_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_95_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevt_98_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_toString_0();
bevt_99_tmpany_phold = bevo_1;
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_notEquals_1(bevt_99_tmpany_phold);
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 469 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 469 */
 else  /* Line: 469 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 469 */ {
bevt_100_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_101_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_100_tmpany_phold.bemd_1(-1051551207, BEL_4_Base.bevn_isForwardSet_1, bevt_101_tmpany_phold);
} /* Line: 470 */
 else  /* Line: 471 */ {
bevt_106_tmpany_phold = bevo_2;
bevt_108_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_105_tmpany_phold = bevt_106_tmpany_phold.bem_add_1(bevt_107_tmpany_phold);
bevt_109_tmpany_phold = bevo_3;
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_add_1(bevt_109_tmpany_phold);
bevt_110_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_103_tmpany_phold = bevt_104_tmpany_phold.bem_add_1(bevt_110_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_103_tmpany_phold, bevl_org);
throw new be.BECS_ThrowBack(bevt_102_tmpany_phold);
} /* Line: 472 */
} /* Line: 469 */
 else  /* Line: 474 */ {
bevl_oany = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 475 */
} /* Line: 467 */
} /* Line: 465 */
} /* Line: 439 */
if (bevl_oany == null) {
bevt_111_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_111_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_111_tmpany_phold.bevi_bool) /* Line: 479 */ {
bevt_112_tmpany_phold = bevl_oany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_112_tmpany_phold != null && bevt_112_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_112_tmpany_phold).bevi_bool) /* Line: 479 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 479 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 479 */
 else  /* Line: 479 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 479 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_113_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_113_tmpany_phold != null && bevt_113_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_113_tmpany_phold).bevi_bool) /* Line: 482 */ {
if (bevl_syn == null) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevt_116_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bels_6));
bevt_115_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_116_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_115_tmpany_phold);
} /* Line: 485 */
bevt_118_tmpany_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_119_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_117_tmpany_phold = bevt_118_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_119_tmpany_phold);
if (bevt_117_tmpany_phold != null && bevt_117_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_117_tmpany_phold).bevi_bool) /* Line: 490 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 492 */
 else  /* Line: 490 */ {
bevt_121_tmpany_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_121_tmpany_phold == null) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 493 */ {
bevt_124_tmpany_phold = bevp_build.bem_emitCommonGet_0();
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bem_coanyiantReturnsGet_0();
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_122_tmpany_phold != null && bevt_122_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_122_tmpany_phold).bevi_bool) /* Line: 493 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 493 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 493 */
 else  /* Line: 493 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 493 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 494 */
} /* Line: 490 */
} /* Line: 490 */
 else  /* Line: 482 */ {
if (bevl_mtdc == null) {
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_125_tmpany_phold.bevi_bool) /* Line: 496 */ {
bevt_126_tmpany_phold = bevl_mtdc.bemd_2(-583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_126_tmpany_phold);
} /* Line: 497 */
 else  /* Line: 498 */ {
bevt_127_tmpany_phold = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_127_tmpany_phold);
} /* Line: 499 */
} /* Line: 482 */
bevt_129_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_128_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_129_tmpany_phold);
if (bevt_128_tmpany_phold != null && bevt_128_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_128_tmpany_phold).bevi_bool) /* Line: 503 */ {
bevt_130_tmpany_phold = beva_node.bem_heldGet_0();
bevt_131_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_130_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_131_tmpany_phold);
} /* Line: 505 */
 else  /* Line: 506 */ {
bevt_132_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_132_tmpany_phold != null && bevt_132_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_132_tmpany_phold).bevi_bool) /* Line: 507 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 508 */
 else  /* Line: 509 */ {
bevl_ovnp = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 510 */
bevt_133_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_133_tmpany_phold);
bevt_134_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp);
if (bevt_134_tmpany_phold != null && bevt_134_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_134_tmpany_phold).bevi_bool) /* Line: 513 */ {
bevt_135_tmpany_phold = beva_node.bem_heldGet_0();
bevt_136_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_135_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_136_tmpany_phold);
} /* Line: 515 */
 else  /* Line: 516 */ {
bevt_141_tmpany_phold = bevo_4;
bevt_143_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bem_toString_0();
bevt_140_tmpany_phold = bevt_141_tmpany_phold.bem_add_1(bevt_142_tmpany_phold);
bevt_144_tmpany_phold = bevo_5;
bevt_139_tmpany_phold = bevt_140_tmpany_phold.bem_add_1(bevt_144_tmpany_phold);
bevt_145_tmpany_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_138_tmpany_phold = bevt_139_tmpany_phold.bem_add_1(bevt_145_tmpany_phold);
bevt_137_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_138_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_137_tmpany_phold);
} /* Line: 517 */
} /* Line: 513 */
if (bevl_castForSelf.bevi_bool) /* Line: 521 */ {
bevt_146_tmpany_phold = beva_node.bem_heldGet_0();
bevt_147_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_146_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_147_tmpany_phold);
} /* Line: 523 */
} /* Line: 521 */
bevt_150_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_149_tmpany_phold == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 526 */ {
} /* Line: 526 */
} /* Line: 526 */
} /* Line: 435 */
} /* Line: 431 */
 else  /* Line: 422 */ {
bevt_153_tmpany_phold = beva_node.bem_heldGet_0();
bevt_152_tmpany_phold = bevt_153_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_154_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_9));
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_154_tmpany_phold);
if (bevt_151_tmpany_phold != null && bevt_151_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_151_tmpany_phold).bevi_bool) /* Line: 531 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_156_tmpany_phold = bevl_targ.bem_typenameGet_0();
bevt_157_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_156_tmpany_phold.bevi_int == bevt_157_tmpany_phold.bevi_int) {
bevt_155_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_155_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_155_tmpany_phold.bevi_bool) /* Line: 533 */ {
bevt_159_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_158_tmpany_phold = bevt_159_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_158_tmpany_phold != null && bevt_158_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpany_phold).bevi_bool) /* Line: 534 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 535 */
 else  /* Line: 536 */ {
bevt_161_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_163_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_162_tmpany_phold);
bevl_tany = bevt_160_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 537 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_165_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_164_tmpany_phold = bevt_165_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_164_tmpany_phold != null && bevt_164_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_164_tmpany_phold).bevi_bool) /* Line: 541 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 542 */
 else  /* Line: 543 */ {
bevt_167_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_169_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_168_tmpany_phold = bevt_169_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_168_tmpany_phold);
bevl_tany = bevt_166_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 544 */
bevt_172_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_171_tmpany_phold = bevt_172_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_171_tmpany_phold == null) {
bevt_170_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_170_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_170_tmpany_phold.bevi_bool) /* Line: 547 */ {
bevt_175_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_174_tmpany_phold = bevt_175_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_173_tmpany_phold = bevt_174_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_173_tmpany_phold != null && bevt_173_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_173_tmpany_phold).bevi_bool) /* Line: 547 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 547 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 547 */
 else  /* Line: 547 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 547 */ {
bevt_177_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_176_tmpany_phold = bevt_177_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_176_tmpany_phold != null && bevt_176_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_176_tmpany_phold).bevi_bool) /* Line: 548 */ {
bevt_180_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_179_tmpany_phold = bevt_180_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_178_tmpany_phold = bevt_179_tmpany_phold.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_178_tmpany_phold != null && bevt_178_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_178_tmpany_phold).bevi_bool) /* Line: 549 */ {
bevt_182_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, bels_10));
bevt_181_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_182_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_181_tmpany_phold);
} /* Line: 550 */
bevt_183_tmpany_phold = beva_node.bem_heldGet_0();
bevt_184_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_183_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_184_tmpany_phold);
} /* Line: 553 */
 else  /* Line: 554 */ {
bevt_187_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_186_tmpany_phold = bevt_187_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_185_tmpany_phold = bevt_186_tmpany_phold.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_185_tmpany_phold != null && bevt_185_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_185_tmpany_phold).bevi_bool) /* Line: 557 */ {
bevt_189_tmpany_phold = bevl_tany.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_190_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_11));
bevt_188_tmpany_phold = bevt_189_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_190_tmpany_phold);
if (bevt_188_tmpany_phold != null && bevt_188_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_188_tmpany_phold).bevi_bool) /* Line: 558 */ {
bevt_191_tmpany_phold = beva_node.bem_heldGet_0();
bevt_192_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_191_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_192_tmpany_phold);
} /* Line: 560 */
 else  /* Line: 561 */ {
bevt_195_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_194_tmpany_phold = bevt_195_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_193_tmpany_phold = bevt_194_tmpany_phold.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_193_tmpany_phold != null && bevt_193_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_193_tmpany_phold).bevi_bool) /* Line: 562 */ {
bevt_197_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, bels_12));
bevt_196_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_197_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_196_tmpany_phold);
} /* Line: 563 */
bevt_198_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_198_tmpany_phold);
bevt_200_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_199_tmpany_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_200_tmpany_phold);
if (bevt_199_tmpany_phold != null && bevt_199_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_199_tmpany_phold).bevi_bool) /* Line: 566 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 566 */ {
bevt_202_tmpany_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_201_tmpany_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_202_tmpany_phold);
if (bevt_201_tmpany_phold != null && bevt_201_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_201_tmpany_phold).bevi_bool) /* Line: 566 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 566 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 566 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 566 */ {
bevt_203_tmpany_phold = beva_node.bem_heldGet_0();
bevt_204_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_203_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_204_tmpany_phold);
} /* Line: 568 */
 else  /* Line: 569 */ {
bevt_209_tmpany_phold = bevo_6;
bevt_210_tmpany_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_208_tmpany_phold = bevt_209_tmpany_phold.bem_add_1(bevt_210_tmpany_phold);
bevt_211_tmpany_phold = bevo_7;
bevt_207_tmpany_phold = bevt_208_tmpany_phold.bem_add_1(bevt_211_tmpany_phold);
bevt_212_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_206_tmpany_phold = bevt_207_tmpany_phold.bem_add_1(bevt_212_tmpany_phold);
bevt_205_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_206_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_205_tmpany_phold);
} /* Line: 570 */
} /* Line: 566 */
} /* Line: 558 */
 else  /* Line: 573 */ {
bevt_213_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_213_tmpany_phold);
bevt_217_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_216_tmpany_phold = bevt_217_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_215_tmpany_phold = bevt_216_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_214_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_215_tmpany_phold);
if (bevt_214_tmpany_phold != null && bevt_214_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_214_tmpany_phold).bevi_bool) /* Line: 575 */ {
bevt_218_tmpany_phold = beva_node.bem_heldGet_0();
bevt_219_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_218_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_219_tmpany_phold);
} /* Line: 577 */
 else  /* Line: 578 */ {
bevt_222_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_221_tmpany_phold = bevt_222_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_220_tmpany_phold = bevt_221_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_220_tmpany_phold);
bevt_224_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_223_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_224_tmpany_phold);
if (bevt_223_tmpany_phold != null && bevt_223_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_223_tmpany_phold).bevi_bool) /* Line: 580 */ {
bevt_225_tmpany_phold = beva_node.bem_heldGet_0();
bevt_226_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_225_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_226_tmpany_phold);
} /* Line: 582 */
 else  /* Line: 583 */ {
bevt_228_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bels_15));
bevt_227_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_228_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_227_tmpany_phold);
} /* Line: 584 */
} /* Line: 580 */
} /* Line: 575 */
} /* Line: 557 */
} /* Line: 548 */
 else  /* Line: 589 */ {
bevt_229_tmpany_phold = beva_node.bem_heldGet_0();
bevt_230_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_229_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_230_tmpany_phold);
} /* Line: 591 */
} /* Line: 547 */
 else  /* Line: 593 */ {
bevt_231_tmpany_phold = beva_node.bem_heldGet_0();
bevt_232_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_231_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_232_tmpany_phold);
} /* Line: 594 */
} /* Line: 533 */
 else  /* Line: 596 */ {
bevt_233_tmpany_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_233_tmpany_phold.bem_firstGet_0();
bevt_235_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_234_tmpany_phold = bevt_235_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_234_tmpany_phold != null && bevt_234_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_234_tmpany_phold).bevi_bool) /* Line: 599 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 600 */
 else  /* Line: 601 */ {
bevt_237_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_239_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_238_tmpany_phold = bevt_239_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_236_tmpany_phold = bevt_237_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_238_tmpany_phold);
bevl_tany = bevt_236_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 602 */
bevt_241_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_240_tmpany_phold = bevt_241_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_240_tmpany_phold != null && bevt_240_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_240_tmpany_phold).bevi_bool) /* Line: 605 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 605 */ {
bevt_244_tmpany_phold = beva_node.bem_heldGet_0();
bevt_243_tmpany_phold = bevt_244_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_245_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_16));
bevt_242_tmpany_phold = bevt_243_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_245_tmpany_phold);
if (bevt_242_tmpany_phold != null && bevt_242_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_242_tmpany_phold).bevi_bool) /* Line: 605 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 605 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 605 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 605 */ {
bevt_246_tmpany_phold = beva_node.bem_heldGet_0();
bevt_247_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_246_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_247_tmpany_phold);
} /* Line: 606 */
 else  /* Line: 607 */ {
bevt_248_tmpany_phold = beva_node.bem_heldGet_0();
bevt_249_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_248_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_249_tmpany_phold);
bevt_251_tmpany_phold = beva_node.bem_heldGet_0();
bevt_250_tmpany_phold = bevt_251_tmpany_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_250_tmpany_phold != null && bevt_250_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_250_tmpany_phold).bevi_bool) /* Line: 609 */ {
bevt_254_tmpany_phold = beva_node.bem_heldGet_0();
bevt_253_tmpany_phold = bevt_254_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_253_tmpany_phold == null) {
bevt_252_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_252_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_252_tmpany_phold.bevi_bool) /* Line: 610 */ {
bevt_256_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_17));
bevt_255_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_256_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_255_tmpany_phold);
} /* Line: 611 */
bevt_258_tmpany_phold = beva_node.bem_heldGet_0();
bevt_257_tmpany_phold = bevt_258_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_257_tmpany_phold);
bevt_259_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_261_tmpany_phold = beva_node.bem_heldGet_0();
bevt_260_tmpany_phold = bevt_261_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_259_tmpany_phold.bem_get_1(bevt_260_tmpany_phold);
} /* Line: 614 */
 else  /* Line: 615 */ {
bevt_262_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_262_tmpany_phold);
bevt_263_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_265_tmpany_phold = beva_node.bem_heldGet_0();
bevt_264_tmpany_phold = bevt_265_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_263_tmpany_phold.bem_get_1(bevt_264_tmpany_phold);
} /* Line: 617 */
if (bevl_mtdc == null) {
bevt_266_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_266_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_266_tmpany_phold.bevi_bool) /* Line: 619 */ {
bevt_267_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_268_tmpany_phold = bevo_8;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_267_tmpany_phold.bem_get_1(bevt_268_tmpany_phold);
if (bevl_fcms == null) {
bevt_269_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_269_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_269_tmpany_phold.bevi_bool) /* Line: 621 */ {
bevt_272_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_271_tmpany_phold = bevt_272_tmpany_phold.bem_toString_0();
bevt_273_tmpany_phold = bevo_9;
bevt_270_tmpany_phold = bevt_271_tmpany_phold.bem_notEquals_1(bevt_273_tmpany_phold);
if (bevt_270_tmpany_phold.bevi_bool) /* Line: 621 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 621 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 621 */
 else  /* Line: 621 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 621 */ {
bevt_274_tmpany_phold = beva_node.bem_heldGet_0();
bevt_275_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_274_tmpany_phold.bemd_1(-1051551207, BEL_4_Base.bevn_isForwardSet_1, bevt_275_tmpany_phold);
} /* Line: 622 */
 else  /* Line: 623 */ {
bevt_280_tmpany_phold = bevo_10;
bevt_282_tmpany_phold = beva_node.bem_heldGet_0();
bevt_281_tmpany_phold = bevt_282_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_279_tmpany_phold = bevt_280_tmpany_phold.bem_add_1(bevt_281_tmpany_phold);
bevt_283_tmpany_phold = bevo_11;
bevt_278_tmpany_phold = bevt_279_tmpany_phold.bem_add_1(bevt_283_tmpany_phold);
bevt_285_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_284_tmpany_phold = bevt_285_tmpany_phold.bem_toString_0();
bevt_277_tmpany_phold = bevt_278_tmpany_phold.bem_add_1(bevt_284_tmpany_phold);
bevt_276_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_277_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_276_tmpany_phold);
} /* Line: 624 */
} /* Line: 621 */
if (bevl_mtdc == null) {
bevt_286_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_286_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_286_tmpany_phold.bevi_bool) /* Line: 627 */ {
bevl_argSyns = (BEC_2_9_4_ContainerList) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 630 */ {
bevt_288_tmpany_phold = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_288_tmpany_phold.bevi_int) {
bevt_287_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_287_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_287_tmpany_phold.bevi_bool) /* Line: 630 */ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_289_tmpany_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_289_tmpany_phold.bevi_bool) /* Line: 632 */ {
if (bevl_nnode == null) {
bevt_290_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_290_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_290_tmpany_phold.bevi_bool) /* Line: 633 */ {
bevt_292_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_22));
bevt_291_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_292_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_291_tmpany_phold);
} /* Line: 634 */
 else  /* Line: 633 */ {
bevt_294_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_295_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_294_tmpany_phold.bevi_int != bevt_295_tmpany_phold.bevi_int) {
bevt_293_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_293_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_293_tmpany_phold.bevi_bool) /* Line: 635 */ {
bevt_297_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_298_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_297_tmpany_phold.bevi_int != bevt_298_tmpany_phold.bevi_int) {
bevt_296_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_296_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_296_tmpany_phold.bevi_bool) /* Line: 635 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 635 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 635 */
 else  /* Line: 635 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 635 */ {
bevt_301_tmpany_phold = bevo_12;
bevt_303_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_302_tmpany_phold = bevt_303_tmpany_phold.bem_toString_0();
bevt_300_tmpany_phold = bevt_301_tmpany_phold.bem_add_1(bevt_302_tmpany_phold);
bevt_299_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_300_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_299_tmpany_phold);
} /* Line: 636 */
} /* Line: 633 */
bevt_305_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_306_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_305_tmpany_phold.bevi_int == bevt_306_tmpany_phold.bevi_int) {
bevt_304_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_304_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_304_tmpany_phold.bevi_bool) /* Line: 638 */ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_308_tmpany_phold = bevl_carg.bem_isTypedGet_0();
if (bevt_308_tmpany_phold.bevi_bool) {
bevt_307_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_307_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_307_tmpany_phold.bevi_bool) /* Line: 640 */ {
bevt_309_tmpany_phold = beva_node.bem_heldGet_0();
bevt_310_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_309_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_310_tmpany_phold);
bevt_312_tmpany_phold = beva_node.bem_heldGet_0();
bevt_311_tmpany_phold = bevt_312_tmpany_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_313_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_311_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_313_tmpany_phold);
} /* Line: 642 */
 else  /* Line: 644 */ {
bevt_314_tmpany_phold = bevl_carg.bem_namepathGet_0();
bevl_syn = bevp_build.bem_getSynNp_1(bevt_314_tmpany_phold);
bevt_317_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_316_tmpany_phold = bevl_syn.bem_castsTo_1(bevt_317_tmpany_phold);
bevt_315_tmpany_phold = bevt_316_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_315_tmpany_phold != null && bevt_315_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_315_tmpany_phold).bevi_bool) /* Line: 646 */ {
bevt_322_tmpany_phold = bevo_13;
bevt_324_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_323_tmpany_phold = bevt_324_tmpany_phold.bem_toString_0();
bevt_321_tmpany_phold = bevt_322_tmpany_phold.bem_add_1(bevt_323_tmpany_phold);
bevt_325_tmpany_phold = bevo_14;
bevt_320_tmpany_phold = bevt_321_tmpany_phold.bem_add_1(bevt_325_tmpany_phold);
bevt_327_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_326_tmpany_phold = bevt_327_tmpany_phold.bem_toString_0();
bevt_319_tmpany_phold = bevt_320_tmpany_phold.bem_add_1(bevt_326_tmpany_phold);
bevt_318_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_319_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_318_tmpany_phold);
} /* Line: 647 */
} /* Line: 646 */
} /* Line: 640 */
} /* Line: 638 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 630 */
 else  /* Line: 630 */ {
break;
} /* Line: 630 */
} /* Line: 630 */
} /* Line: 630 */
} /* Line: 627 */
} /* Line: 605 */
} /* Line: 422 */
} /* Line: 422 */
bevt_328_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_328_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {393, 393, 393, 393, 394, 394, 394, 394, 394, 394, 395, 395, 395, 398, 398, 398, 398, 399, 400, 400, 401, 401, 403, 403, 403, 403, 404, 406, 406, 406, 406, 407, 407, 408, 409, 409, 0, 409, 409, 410, 410, 410, 410, 411, 411, 422, 422, 422, 422, 423, 423, 425, 425, 426, 428, 428, 428, 428, 428, 431, 431, 432, 432, 432, 434, 435, 435, 435, 435, 0, 435, 435, 435, 435, 0, 0, 437, 437, 437, 439, 439, 439, 439, 440, 440, 441, 444, 444, 444, 444, 444, 447, 447, 447, 447, 448, 448, 450, 450, 452, 455, 455, 455, 455, 455, 458, 459, 459, 459, 459, 460, 460, 460, 461, 463, 463, 465, 465, 466, 466, 466, 466, 467, 467, 468, 468, 468, 469, 469, 469, 469, 469, 469, 0, 0, 0, 470, 470, 470, 472, 472, 472, 472, 472, 472, 472, 472, 472, 472, 475, 479, 479, 479, 0, 0, 0, 481, 482, 484, 484, 485, 485, 485, 490, 490, 490, 492, 493, 493, 493, 493, 493, 493, 0, 0, 0, 494, 496, 496, 497, 497, 499, 499, 503, 503, 505, 505, 505, 507, 508, 510, 512, 512, 513, 515, 515, 515, 517, 517, 517, 517, 517, 517, 517, 517, 517, 517, 523, 523, 523, 526, 526, 526, 526, 531, 531, 531, 531, 532, 533, 533, 533, 533, 534, 534, 535, 537, 537, 537, 537, 537, 540, 541, 541, 542, 544, 544, 544, 544, 544, 547, 547, 547, 547, 547, 547, 547, 0, 0, 0, 548, 548, 549, 549, 549, 550, 550, 550, 553, 553, 553, 557, 557, 557, 558, 558, 558, 560, 560, 560, 562, 562, 562, 563, 563, 563, 565, 565, 566, 566, 0, 566, 566, 0, 0, 568, 568, 568, 570, 570, 570, 570, 570, 570, 570, 570, 570, 574, 574, 575, 575, 575, 575, 577, 577, 577, 579, 579, 579, 579, 580, 580, 582, 582, 582, 584, 584, 584, 591, 591, 591, 594, 594, 594, 597, 597, 599, 599, 600, 602, 602, 602, 602, 602, 605, 605, 0, 605, 605, 605, 605, 0, 0, 606, 606, 606, 608, 608, 608, 609, 609, 610, 610, 610, 610, 611, 611, 611, 613, 613, 613, 614, 614, 614, 614, 616, 616, 617, 617, 617, 617, 619, 619, 620, 620, 620, 621, 621, 621, 621, 621, 621, 0, 0, 0, 622, 622, 622, 624, 624, 624, 624, 624, 624, 624, 624, 624, 624, 624, 627, 627, 628, 629, 630, 630, 630, 630, 631, 632, 633, 633, 634, 634, 634, 635, 635, 635, 635, 635, 635, 635, 635, 0, 0, 0, 636, 636, 636, 636, 636, 636, 638, 638, 638, 638, 639, 640, 640, 640, 641, 641, 641, 642, 642, 642, 642, 645, 645, 646, 646, 646, 647, 647, 647, 647, 647, 647, 647, 647, 647, 647, 647, 656, 630, 662, 662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {407, 408, 409, 414, 415, 416, 417, 418, 419, 420, 422, 423, 424, 427, 428, 429, 434, 435, 436, 437, 438, 439, 441, 442, 443, 448, 449, 451, 452, 453, 458, 459, 460, 461, 462, 463, 463, 466, 468, 469, 470, 471, 476, 477, 478, 485, 486, 487, 488, 490, 491, 492, 493, 495, 498, 499, 500, 501, 502, 504, 505, 507, 508, 509, 512, 513, 514, 515, 520, 521, 524, 525, 526, 531, 532, 535, 539, 540, 541, 544, 545, 546, 551, 552, 553, 555, 558, 559, 560, 561, 562, 566, 567, 568, 573, 574, 575, 576, 577, 579, 582, 583, 584, 585, 586, 588, 589, 590, 591, 596, 597, 598, 599, 602, 604, 605, 608, 613, 614, 615, 616, 617, 618, 623, 624, 625, 626, 627, 632, 633, 634, 635, 636, 638, 641, 645, 648, 649, 650, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 666, 671, 676, 677, 679, 682, 686, 689, 690, 692, 697, 698, 699, 700, 702, 703, 704, 706, 709, 710, 715, 716, 717, 718, 720, 723, 727, 730, 735, 740, 741, 742, 745, 746, 749, 750, 752, 753, 754, 757, 759, 762, 764, 765, 766, 768, 769, 770, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 786, 787, 788, 791, 792, 793, 798, 804, 805, 806, 807, 809, 810, 811, 812, 817, 818, 819, 821, 824, 825, 826, 827, 828, 830, 831, 832, 834, 837, 838, 839, 840, 841, 843, 844, 845, 850, 851, 852, 853, 855, 858, 862, 865, 866, 868, 869, 870, 872, 873, 874, 876, 877, 878, 881, 882, 883, 885, 886, 887, 889, 890, 891, 894, 895, 896, 898, 899, 900, 902, 903, 904, 905, 907, 910, 911, 913, 916, 920, 921, 922, 925, 926, 927, 928, 929, 930, 931, 932, 933, 938, 939, 940, 941, 942, 943, 945, 946, 947, 950, 951, 952, 953, 954, 955, 957, 958, 959, 962, 963, 964, 971, 972, 973, 977, 978, 979, 983, 984, 985, 986, 988, 991, 992, 993, 994, 995, 997, 998, 1000, 1003, 1004, 1005, 1006, 1008, 1011, 1015, 1016, 1017, 1020, 1021, 1022, 1023, 1024, 1026, 1027, 1028, 1033, 1034, 1035, 1036, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1047, 1048, 1049, 1050, 1051, 1052, 1054, 1059, 1060, 1061, 1062, 1063, 1068, 1069, 1070, 1071, 1072, 1074, 1077, 1081, 1084, 1085, 1086, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1102, 1107, 1108, 1109, 1110, 1113, 1114, 1119, 1120, 1121, 1123, 1128, 1129, 1130, 1131, 1134, 1135, 1136, 1141, 1142, 1143, 1144, 1149, 1150, 1153, 1157, 1160, 1161, 1162, 1163, 1164, 1165, 1168, 1169, 1170, 1175, 1176, 1177, 1178, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1193, 1194, 1195, 1196, 1197, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1214, 1215, 1226, 1227, 1230, 1233, 1237, 1240, 1244, 1247, 1251, 1254, 1258, 1261};
/* BEGIN LINEINFO 
assign 1 393 407
typenameGet 0 393 407
assign 1 393 408
CATCHGet 0 393 408
assign 1 393 409
equals 1 393 414
assign 1 394 415
containedGet 0 394 415
assign 1 394 416
firstGet 0 394 416
assign 1 394 417
containedGet 0 394 417
assign 1 394 418
firstGet 0 394 418
assign 1 394 419
heldGet 0 394 419
assign 1 394 420
isTypedGet 0 394 420
assign 1 395 422
new 0 395 422
assign 1 395 423
new 1 395 423
throw 1 395 424
assign 1 398 427
typenameGet 0 398 427
assign 1 398 428
CLASSGet 0 398 428
assign 1 398 429
equals 1 398 434
assign 1 399 435
assign 1 400 436
heldGet 0 400 436
assign 1 400 437
namepathGet 0 400 437
assign 1 401 438
heldGet 0 401 438
assign 1 401 439
synGet 0 401 439
assign 1 403 441
typenameGet 0 403 441
assign 1 403 442
METHODGet 0 403 442
assign 1 403 443
equals 1 403 448
assign 1 404 449
new 0 404 449
assign 1 406 451
typenameGet 0 406 451
assign 1 406 452
CALLGet 0 406 452
assign 1 406 453
equals 1 406 458
assign 1 407 459
heldGet 0 407 459
cposSet 1 407 460
assign 1 408 461
increment 0 408 461
assign 1 409 462
containedGet 0 409 462
assign 1 409 463
iteratorGet 0 0 463
assign 1 409 466
hasNextGet 0 409 466
assign 1 409 468
nextGet 0 409 468
assign 1 410 469
typenameGet 0 410 469
assign 1 410 470
VARGet 0 410 470
assign 1 410 471
equals 1 410 476
assign 1 411 477
heldGet 0 411 477
addCall 1 411 478
assign 1 422 485
heldGet 0 422 485
assign 1 422 486
orgNameGet 0 422 486
assign 1 422 487
new 0 422 487
assign 1 422 488
equals 1 422 488
assign 1 423 490
containedGet 0 423 490
assign 1 423 491
firstGet 0 423 491
assign 1 425 492
heldGet 0 425 492
assign 1 425 493
isDeclaredGet 0 425 493
assign 1 426 495
heldGet 0 426 495
assign 1 428 498
ptyMapGet 0 428 498
assign 1 428 499
heldGet 0 428 499
assign 1 428 500
nameGet 0 428 500
assign 1 428 501
get 1 428 501
assign 1 428 502
memSynGet 0 428 502
assign 1 431 504
isTypedGet 0 431 504
assign 1 431 505
not 0 431 505
assign 1 432 507
heldGet 0 432 507
assign 1 432 508
new 0 432 508
checkTypesSet 1 432 509
assign 1 434 512
secondGet 0 434 512
assign 1 435 513
typenameGet 0 435 513
assign 1 435 514
TRUEGet 0 435 514
assign 1 435 515
equals 1 435 520
assign 1 0 521
assign 1 435 524
typenameGet 0 435 524
assign 1 435 525
FALSEGet 0 435 525
assign 1 435 526
equals 1 435 531
assign 1 0 532
assign 1 0 535
assign 1 437 539
heldGet 0 437 539
assign 1 437 540
new 0 437 540
checkTypesSet 1 437 541
assign 1 439 544
typenameGet 0 439 544
assign 1 439 545
VARGet 0 439 545
assign 1 439 546
equals 1 439 551
assign 1 440 552
heldGet 0 440 552
assign 1 440 553
isDeclaredGet 0 440 553
assign 1 441 555
heldGet 0 441 555
assign 1 444 558
ptyMapGet 0 444 558
assign 1 444 559
heldGet 0 444 559
assign 1 444 560
nameGet 0 444 560
assign 1 444 561
get 1 444 561
assign 1 444 562
memSynGet 0 444 562
assign 1 447 566
typenameGet 0 447 566
assign 1 447 567
CALLGet 0 447 567
assign 1 447 568
equals 1 447 573
assign 1 448 574
containedGet 0 448 574
assign 1 448 575
firstGet 0 448 575
assign 1 450 576
heldGet 0 450 576
assign 1 450 577
isDeclaredGet 0 450 577
assign 1 452 579
heldGet 0 452 579
assign 1 455 582
ptyMapGet 0 455 582
assign 1 455 583
heldGet 0 455 583
assign 1 455 584
nameGet 0 455 584
assign 1 455 585
get 1 455 585
assign 1 455 586
memSynGet 0 455 586
assign 1 458 588
assign 1 459 589
heldGet 0 459 589
assign 1 459 590
newNpGet 0 459 590
assign 1 459 591
def 1 459 596
assign 1 460 597
heldGet 0 460 597
assign 1 460 598
newNpGet 0 460 598
assign 1 460 599
getSynNp 1 460 599
assign 1 461 602
isTypedGet 0 461 602
assign 1 463 604
namepathGet 0 463 604
assign 1 463 605
getSynNp 1 463 605
assign 1 465 608
def 1 465 613
assign 1 466 614
mtdMapGet 0 466 614
assign 1 466 615
heldGet 0 466 615
assign 1 466 616
nameGet 0 466 616
assign 1 466 617
get 1 466 617
assign 1 467 618
undef 1 467 623
assign 1 468 624
mtdMapGet 0 468 624
assign 1 468 625
new 0 468 625
assign 1 468 626
get 1 468 626
assign 1 469 627
def 1 469 632
assign 1 469 633
originGet 0 469 633
assign 1 469 634
toString 0 469 634
assign 1 469 635
new 0 469 635
assign 1 469 636
notEquals 1 469 636
assign 1 0 638
assign 1 0 641
assign 1 0 645
assign 1 470 648
heldGet 0 470 648
assign 1 470 649
new 0 470 649
isForwardSet 1 470 650
assign 1 472 653
new 0 472 653
assign 1 472 654
heldGet 0 472 654
assign 1 472 655
nameGet 0 472 655
assign 1 472 656
add 1 472 656
assign 1 472 657
new 0 472 657
assign 1 472 658
add 1 472 658
assign 1 472 659
namepathGet 0 472 659
assign 1 472 660
add 1 472 660
assign 1 472 661
new 2 472 661
throw 1 472 662
assign 1 475 666
rsynGet 0 475 666
assign 1 479 671
def 1 479 676
assign 1 479 677
isTypedGet 0 479 677
assign 1 0 679
assign 1 0 682
assign 1 0 686
assign 1 481 689
new 0 481 689
assign 1 482 690
isSelfGet 0 482 690
assign 1 484 692
undef 1 484 697
assign 1 485 698
new 0 485 698
assign 1 485 699
new 1 485 699
throw 1 485 700
assign 1 490 702
originGet 0 490 702
assign 1 490 703
namepathGet 0 490 703
assign 1 490 704
notEquals 1 490 704
assign 1 492 706
new 0 492 706
assign 1 493 709
emitCommonGet 0 493 709
assign 1 493 710
def 1 493 715
assign 1 493 716
emitCommonGet 0 493 716
assign 1 493 717
coanyiantReturnsGet 0 493 717
assign 1 493 718
not 0 493 718
assign 1 0 720
assign 1 0 723
assign 1 0 727
assign 1 494 730
new 0 494 730
assign 1 496 735
def 1 496 740
assign 1 497 741
getEmitReturnType 2 497 741
assign 1 497 742
getSynNp 1 497 742
assign 1 499 745
namepathGet 0 499 745
assign 1 499 746
getSynNp 1 499 746
assign 1 503 749
namepathGet 0 503 749
assign 1 503 750
castsTo 1 503 750
assign 1 505 752
heldGet 0 505 752
assign 1 505 753
new 0 505 753
checkTypesSet 1 505 754
assign 1 507 757
isSelfGet 0 507 757
assign 1 508 759
namepathGet 0 508 759
assign 1 510 762
namepathGet 0 510 762
assign 1 512 764
namepathGet 0 512 764
assign 1 512 765
getSynNp 1 512 765
assign 1 513 766
castsTo 1 513 766
assign 1 515 768
heldGet 0 515 768
assign 1 515 769
new 0 515 769
checkTypesSet 1 515 770
assign 1 517 773
new 0 517 773
assign 1 517 774
namepathGet 0 517 774
assign 1 517 775
toString 0 517 775
assign 1 517 776
add 1 517 776
assign 1 517 777
new 0 517 777
assign 1 517 778
add 1 517 778
assign 1 517 779
toString 0 517 779
assign 1 517 780
add 1 517 780
assign 1 517 781
new 2 517 781
throw 1 517 782
assign 1 523 786
heldGet 0 523 786
assign 1 523 787
new 0 523 787
checkTypesSet 1 523 788
assign 1 526 791
heldGet 0 526 791
assign 1 526 792
namepathGet 0 526 792
assign 1 526 793
def 1 526 798
assign 1 531 804
heldGet 0 531 804
assign 1 531 805
orgNameGet 0 531 805
assign 1 531 806
new 0 531 806
assign 1 531 807
equals 1 531 807
assign 1 532 809
secondGet 0 532 809
assign 1 533 810
typenameGet 0 533 810
assign 1 533 811
VARGet 0 533 811
assign 1 533 812
equals 1 533 817
assign 1 534 818
heldGet 0 534 818
assign 1 534 819
isDeclaredGet 0 534 819
assign 1 535 821
heldGet 0 535 821
assign 1 537 824
ptyMapGet 0 537 824
assign 1 537 825
heldGet 0 537 825
assign 1 537 826
nameGet 0 537 826
assign 1 537 827
get 1 537 827
assign 1 537 828
memSynGet 0 537 828
assign 1 540 830
scopeGet 0 540 830
assign 1 541 831
heldGet 0 541 831
assign 1 541 832
isDeclaredGet 0 541 832
assign 1 542 834
heldGet 0 542 834
assign 1 544 837
ptyMapGet 0 544 837
assign 1 544 838
heldGet 0 544 838
assign 1 544 839
nameGet 0 544 839
assign 1 544 840
get 1 544 840
assign 1 544 841
memSynGet 0 544 841
assign 1 547 843
heldGet 0 547 843
assign 1 547 844
rtypeGet 0 547 844
assign 1 547 845
def 1 547 850
assign 1 547 851
heldGet 0 547 851
assign 1 547 852
rtypeGet 0 547 852
assign 1 547 853
isTypedGet 0 547 853
assign 1 0 855
assign 1 0 858
assign 1 0 862
assign 1 548 865
isTypedGet 0 548 865
assign 1 548 866
not 0 548 866
assign 1 549 868
heldGet 0 549 868
assign 1 549 869
rtypeGet 0 549 869
assign 1 549 870
isThisGet 0 549 870
assign 1 550 872
new 0 550 872
assign 1 550 873
new 2 550 873
throw 1 550 874
assign 1 553 876
heldGet 0 553 876
assign 1 553 877
new 0 553 877
checkTypesSet 1 553 878
assign 1 557 881
heldGet 0 557 881
assign 1 557 882
rtypeGet 0 557 882
assign 1 557 883
isSelfGet 0 557 883
assign 1 558 885
nameGet 0 558 885
assign 1 558 886
new 0 558 886
assign 1 558 887
equals 1 558 887
assign 1 560 889
heldGet 0 560 889
assign 1 560 890
new 0 560 890
checkTypesSet 1 560 891
assign 1 562 894
heldGet 0 562 894
assign 1 562 895
rtypeGet 0 562 895
assign 1 562 896
isThisGet 0 562 896
assign 1 563 898
new 0 563 898
assign 1 563 899
new 2 563 899
throw 1 563 900
assign 1 565 902
namepathGet 0 565 902
assign 1 565 903
getSynNp 1 565 903
assign 1 566 904
namepathGet 0 566 904
assign 1 566 905
castsTo 1 566 905
assign 1 0 907
assign 1 566 910
namepathGet 0 566 910
assign 1 566 911
castsTo 1 566 911
assign 1 0 913
assign 1 0 916
assign 1 568 920
heldGet 0 568 920
assign 1 568 921
new 0 568 921
checkTypesSet 1 568 922
assign 1 570 925
new 0 570 925
assign 1 570 926
namepathGet 0 570 926
assign 1 570 927
add 1 570 927
assign 1 570 928
new 0 570 928
assign 1 570 929
add 1 570 929
assign 1 570 930
namepathGet 0 570 930
assign 1 570 931
add 1 570 931
assign 1 570 932
new 2 570 932
throw 1 570 933
assign 1 574 938
namepathGet 0 574 938
assign 1 574 939
getSynNp 1 574 939
assign 1 575 940
heldGet 0 575 940
assign 1 575 941
rtypeGet 0 575 941
assign 1 575 942
namepathGet 0 575 942
assign 1 575 943
castsTo 1 575 943
assign 1 577 945
heldGet 0 577 945
assign 1 577 946
new 0 577 946
checkTypesSet 1 577 947
assign 1 579 950
heldGet 0 579 950
assign 1 579 951
rtypeGet 0 579 951
assign 1 579 952
namepathGet 0 579 952
assign 1 579 953
getSynNp 1 579 953
assign 1 580 954
namepathGet 0 580 954
assign 1 580 955
castsTo 1 580 955
assign 1 582 957
heldGet 0 582 957
assign 1 582 958
new 0 582 958
checkTypesSet 1 582 959
assign 1 584 962
new 0 584 962
assign 1 584 963
new 2 584 963
throw 1 584 964
assign 1 591 971
heldGet 0 591 971
assign 1 591 972
new 0 591 972
checkTypesSet 1 591 973
assign 1 594 977
heldGet 0 594 977
assign 1 594 978
new 0 594 978
checkTypesSet 1 594 979
assign 1 597 983
containedGet 0 597 983
assign 1 597 984
firstGet 0 597 984
assign 1 599 985
heldGet 0 599 985
assign 1 599 986
isDeclaredGet 0 599 986
assign 1 600 988
heldGet 0 600 988
assign 1 602 991
ptyMapGet 0 602 991
assign 1 602 992
heldGet 0 602 992
assign 1 602 993
nameGet 0 602 993
assign 1 602 994
get 1 602 994
assign 1 602 995
memSynGet 0 602 995
assign 1 605 997
isTypedGet 0 605 997
assign 1 605 998
not 0 605 998
assign 1 0 1000
assign 1 605 1003
heldGet 0 605 1003
assign 1 605 1004
orgNameGet 0 605 1004
assign 1 605 1005
new 0 605 1005
assign 1 605 1006
equals 1 605 1006
assign 1 0 1008
assign 1 0 1011
assign 1 606 1015
heldGet 0 606 1015
assign 1 606 1016
new 0 606 1016
checkTypesSet 1 606 1017
assign 1 608 1020
heldGet 0 608 1020
assign 1 608 1021
new 0 608 1021
checkTypesSet 1 608 1022
assign 1 609 1023
heldGet 0 609 1023
assign 1 609 1024
isConstructGet 0 609 1024
assign 1 610 1026
heldGet 0 610 1026
assign 1 610 1027
newNpGet 0 610 1027
assign 1 610 1028
undef 1 610 1033
assign 1 611 1034
new 0 611 1034
assign 1 611 1035
new 1 611 1035
throw 1 611 1036
assign 1 613 1038
heldGet 0 613 1038
assign 1 613 1039
newNpGet 0 613 1039
assign 1 613 1040
getSynNp 1 613 1040
assign 1 614 1041
mtdMapGet 0 614 1041
assign 1 614 1042
heldGet 0 614 1042
assign 1 614 1043
nameGet 0 614 1043
assign 1 614 1044
get 1 614 1044
assign 1 616 1047
namepathGet 0 616 1047
assign 1 616 1048
getSynNp 1 616 1048
assign 1 617 1049
mtdMapGet 0 617 1049
assign 1 617 1050
heldGet 0 617 1050
assign 1 617 1051
nameGet 0 617 1051
assign 1 617 1052
get 1 617 1052
assign 1 619 1054
undef 1 619 1059
assign 1 620 1060
mtdMapGet 0 620 1060
assign 1 620 1061
new 0 620 1061
assign 1 620 1062
get 1 620 1062
assign 1 621 1063
def 1 621 1068
assign 1 621 1069
originGet 0 621 1069
assign 1 621 1070
toString 0 621 1070
assign 1 621 1071
new 0 621 1071
assign 1 621 1072
notEquals 1 621 1072
assign 1 0 1074
assign 1 0 1077
assign 1 0 1081
assign 1 622 1084
heldGet 0 622 1084
assign 1 622 1085
new 0 622 1085
isForwardSet 1 622 1086
assign 1 624 1089
new 0 624 1089
assign 1 624 1090
heldGet 0 624 1090
assign 1 624 1091
nameGet 0 624 1091
assign 1 624 1092
add 1 624 1092
assign 1 624 1093
new 0 624 1093
assign 1 624 1094
add 1 624 1094
assign 1 624 1095
namepathGet 0 624 1095
assign 1 624 1096
toString 0 624 1096
assign 1 624 1097
add 1 624 1097
assign 1 624 1098
new 2 624 1098
throw 1 624 1099
assign 1 627 1102
def 1 627 1107
assign 1 628 1108
argSynsGet 0 628 1108
assign 1 629 1109
nextPeerGet 0 629 1109
assign 1 630 1110
new 0 630 1110
assign 1 630 1113
lengthGet 0 630 1113
assign 1 630 1114
lesser 1 630 1119
assign 1 631 1120
get 1 631 1120
assign 1 632 1121
isTypedGet 0 632 1121
assign 1 633 1123
undef 1 633 1128
assign 1 634 1129
new 0 634 1129
assign 1 634 1130
new 2 634 1130
throw 1 634 1131
assign 1 635 1134
typenameGet 0 635 1134
assign 1 635 1135
VARGet 0 635 1135
assign 1 635 1136
notEquals 1 635 1141
assign 1 635 1142
typenameGet 0 635 1142
assign 1 635 1143
NULLGet 0 635 1143
assign 1 635 1144
notEquals 1 635 1149
assign 1 0 1150
assign 1 0 1153
assign 1 0 1157
assign 1 636 1160
new 0 636 1160
assign 1 636 1161
typenameGet 0 636 1161
assign 1 636 1162
toString 0 636 1162
assign 1 636 1163
add 1 636 1163
assign 1 636 1164
new 2 636 1164
throw 1 636 1165
assign 1 638 1168
typenameGet 0 638 1168
assign 1 638 1169
VARGet 0 638 1169
assign 1 638 1170
equals 1 638 1175
assign 1 639 1176
heldGet 0 639 1176
assign 1 640 1177
isTypedGet 0 640 1177
assign 1 640 1178
not 0 640 1183
assign 1 641 1184
heldGet 0 641 1184
assign 1 641 1185
new 0 641 1185
checkTypesSet 1 641 1186
assign 1 642 1187
heldGet 0 642 1187
assign 1 642 1188
argCastsGet 0 642 1188
assign 1 642 1189
namepathGet 0 642 1189
put 2 642 1190
assign 1 645 1193
namepathGet 0 645 1193
assign 1 645 1194
getSynNp 1 645 1194
assign 1 646 1195
namepathGet 0 646 1195
assign 1 646 1196
castsTo 1 646 1196
assign 1 646 1197
not 0 646 1197
assign 1 647 1199
new 0 647 1199
assign 1 647 1200
namepathGet 0 647 1200
assign 1 647 1201
toString 0 647 1201
assign 1 647 1202
add 1 647 1202
assign 1 647 1203
new 0 647 1203
assign 1 647 1204
add 1 647 1204
assign 1 647 1205
namepathGet 0 647 1205
assign 1 647 1206
toString 0 647 1206
assign 1 647 1207
add 1 647 1207
assign 1 647 1208
new 2 647 1208
throw 1 647 1209
assign 1 656 1214
nextPeerGet 0 656 1214
assign 1 630 1215
increment 0 630 1215
assign 1 662 1226
nextDescendGet 0 662 1226
return 1 662 1227
return 1 0 1230
assign 1 0 1233
return 1 0 1237
assign 1 0 1240
return 1 0 1244
assign 1 0 1247
return 1 0 1251
assign 1 0 1254
return 1 0 1258
assign 1 0 1261
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -2028575047: return bem_emitterGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case -2041762316: return bem_inClassGet_0();
case -1012494862: return bem_once_0();
case -997464046: return bem_inClassSynGet_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -2030680063: return bem_inClassSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2117282045: return bem_cposSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
}
