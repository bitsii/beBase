namespace be {
/* IO:File: source/build/Pass2.be */
public sealed class BEC_3_5_5_5_BuildVisitPass2 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass2() { }
static BEC_3_5_5_5_BuildVisitPass2() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x32};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2E};
public static new BEC_3_5_5_5_BuildVisitPass2 bevs_inst;
public BEC_2_4_3_MathInt bevp_idType;
public BEC_2_4_3_MathInt bevp_intType;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
BEC_2_5_9_BuildConstants bevt_1_tmpany_phold = null;
base.bem_begin_1(beva_transi);
bevp_idType = bevp_ntypes.bem_IDGet_0();
bevp_intType = bevp_ntypes.bem_INTLGet_0();
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_matchMap = bevt_0_tmpany_phold.bem_matchMapGet_0();
bevt_1_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_rwords = bevt_1_tmpany_phold.bem_rwordsGet_0();
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_held = null;
BEC_2_6_6_SystemObject bevl_type = null;
BEC_2_5_4_BuildNode bevl_nxp = null;
BEC_2_5_4_BuildNode bevl_nxp2 = null;
BEC_2_5_4_BuildNode bevl_nxp3 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_27_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_3_tmpany_phold.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevt_5_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpany_phold;
} /* Line: 31 */
bevl_held = beva_node.bem_heldGet_0();
if (bevl_held == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevl_type = bevp_matchMap.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 36 */ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 38 */
 else  /* Line: 39 */ {
bevt_8_tmpany_phold = bevl_held.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 41 */ {
bevl_nxp = beva_node.bem_nextPeerGet_0();
if (bevl_nxp == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_11_tmpany_phold = bevl_nxp.bem_heldGet_0();
if (bevt_11_tmpany_phold == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 43 */
 else  /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 43 */ {
bevt_13_tmpany_phold = bevl_nxp.bem_heldGet_0();
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpany_phold);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 44 */ {
bevl_nxp2 = bevl_nxp.bem_nextPeerGet_0();
if (bevl_nxp2 == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_17_tmpany_phold = bevl_nxp2.bem_heldGet_0();
if (bevt_17_tmpany_phold == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
 else  /* Line: 46 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 46 */ {
bevl_nxp3 = bevl_nxp2.bem_nextDescendGet_0();
bevt_19_tmpany_phold = bevl_nxp2.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_22_tmpany_phold = beva_node.bem_heldGet_0();
bevt_23_tmpany_phold = bevl_nxp.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevl_nxp2.bem_heldGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpany_phold);
beva_node.bem_heldSet_1(bevt_20_tmpany_phold);
bevt_25_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
beva_node.bem_typenameSet_1(bevt_25_tmpany_phold);
bevl_nxp2.bem_delete_0();
bevl_nxp.bem_delete_0();
return bevl_nxp3;
} /* Line: 53 */
} /* Line: 48 */
} /* Line: 46 */
} /* Line: 44 */
beva_node.bem_typenameSet_1(bevp_intType);
} /* Line: 58 */
 else  /* Line: 59 */ {
bevl_type = bevp_rwords.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 61 */ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 62 */
 else  /* Line: 63 */ {
beva_node.bem_typenameSet_1(bevp_idType);
} /* Line: 64 */
} /* Line: 61 */
} /* Line: 41 */
} /* Line: 36 */
bevt_27_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_27_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_idTypeGet_0() {
return bevp_idType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_idTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intTypeGet_0() {
return bevp_intType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_intTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 19, 20, 21, 21, 22, 22, 30, 30, 30, 30, 31, 31, 33, 34, 34, 35, 36, 36, 38, 41, 42, 43, 43, 43, 43, 43, 0, 0, 0, 44, 44, 44, 45, 46, 46, 46, 46, 46, 0, 0, 0, 47, 48, 48, 49, 49, 49, 49, 49, 49, 50, 50, 51, 52, 53, 58, 60, 61, 61, 62, 64, 69, 69, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 20, 21, 22, 23, 60, 61, 62, 67, 68, 69, 71, 72, 77, 78, 79, 84, 85, 88, 90, 91, 96, 97, 98, 103, 104, 107, 111, 114, 115, 116, 118, 119, 124, 125, 126, 131, 132, 135, 139, 142, 143, 144, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 161, 164, 165, 170, 171, 174, 179, 180, 183, 186, 190, 193, 197, 200, 204, 207};
/* BEGIN LINEINFO 
begin 1 16 17
assign 1 19 18
IDGet 0 19 18
assign 1 20 19
INTLGet 0 20 19
assign 1 21 20
constantsGet 0 21 20
assign 1 21 21
matchMapGet 0 21 21
assign 1 22 22
constantsGet 0 22 22
assign 1 22 23
rwordsGet 0 22 23
assign 1 30 60
typenameGet 0 30 60
assign 1 30 61
TRANSUNITGet 0 30 61
assign 1 30 62
equals 1 30 67
assign 1 31 68
nextDescendGet 0 31 68
return 1 31 69
assign 1 33 71
heldGet 0 33 71
assign 1 34 72
def 1 34 77
assign 1 35 78
get 1 35 78
assign 1 36 79
def 1 36 84
typenameSet 1 38 85
assign 1 41 88
isInteger 0 41 88
assign 1 42 90
nextPeerGet 0 42 90
assign 1 43 91
def 1 43 96
assign 1 43 97
heldGet 0 43 97
assign 1 43 98
def 1 43 103
assign 1 0 104
assign 1 0 107
assign 1 0 111
assign 1 44 114
heldGet 0 44 114
assign 1 44 115
new 0 44 115
assign 1 44 116
equals 1 44 116
assign 1 45 118
nextPeerGet 0 45 118
assign 1 46 119
def 1 46 124
assign 1 46 125
heldGet 0 46 125
assign 1 46 126
def 1 46 131
assign 1 0 132
assign 1 0 135
assign 1 0 139
assign 1 47 142
nextDescendGet 0 47 142
assign 1 48 143
heldGet 0 48 143
assign 1 48 144
isInteger 0 48 144
assign 1 49 146
heldGet 0 49 146
assign 1 49 147
heldGet 0 49 147
assign 1 49 148
add 1 49 148
assign 1 49 149
heldGet 0 49 149
assign 1 49 150
add 1 49 150
heldSet 1 49 151
assign 1 50 152
FLOATLGet 0 50 152
typenameSet 1 50 153
delete 0 51 154
delete 0 52 155
return 1 53 156
typenameSet 1 58 161
assign 1 60 164
get 1 60 164
assign 1 61 165
def 1 61 170
typenameSet 1 62 171
typenameSet 1 64 174
assign 1 69 179
nextDescendGet 0 69 179
return 1 69 180
return 1 0 183
assign 1 0 186
return 1 0 190
assign 1 0 193
return 1 0 197
assign 1 0 200
return 1 0 204
assign 1 0 207
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 327922578: return bem_idTypeGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -1323554192: return bem_matchMapGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case 1752635198: return bem_intTypeGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -634261936: return bem_rwordsGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -623179683: return bem_rwordsSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 339004831: return bem_idTypeSet_1(bevd_0);
case -1312471939: return bem_matchMapSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1763717451: return bem_intTypeSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass2();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass2.bevs_inst = (BEC_3_5_5_5_BuildVisitPass2)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass2.bevs_inst;
}
}
}
