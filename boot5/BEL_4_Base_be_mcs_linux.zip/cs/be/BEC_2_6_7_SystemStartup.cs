namespace be {
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_7_SystemStartup : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemStartup() { }
static BEC_2_6_7_SystemStartup() { }
private static byte[] becc_BEC_2_6_7_SystemStartup_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70};
private static byte[] becc_BEC_2_6_7_SystemStartup_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemStartup_bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_7_SystemStartup_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemStartup_bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
public static new BEC_2_6_7_SystemStartup bece_BEC_2_6_7_SystemStartup_bevs_inst;
public BEC_2_9_4_ContainerList bevp_args;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_7_SystemStartup bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_2_tmpany_phold = bevp_args.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_6_7_SystemStartup_bevo_0;
if (bevt_2_tmpany_phold.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 32 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(136, bece_BEC_2_6_7_SystemStartup_bels_0));
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 33 */
bevt_8_tmpany_phold = bece_BEC_2_6_7_SystemStartup_bevo_1;
bevt_7_tmpany_phold = bevp_args.bem_get_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = this.bem_createInstance_1((BEC_2_4_6_TextString) bevt_7_tmpany_phold );
bevl_x = bevt_6_tmpany_phold.bemd_0(104713553, BEL_4_Base.bevn_new_0);
bevt_9_tmpany_phold = bevl_x.bemd_0(-1081571542, BEL_4_Base.bevn_main_0);
return bevt_9_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_7_SystemStartup bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {31, 31, 32, 32, 32, 32, 33, 33, 33, 35, 35, 35, 35, 36, 36, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {31, 32, 33, 34, 35, 40, 41, 42, 43, 45, 46, 47, 48, 49, 50, 53, 56};
/* BEGIN LINEINFO 
assign 1 31 31
new 0 31 31
assign 1 31 32
argsGet 0 31 32
assign 1 32 33
sizeGet 0 32 33
assign 1 32 34
new 0 32 34
assign 1 32 35
lesser 1 32 40
assign 1 33 41
new 0 33 41
assign 1 33 42
new 1 33 42
throw 1 33 43
assign 1 35 45
new 0 35 45
assign 1 35 46
get 1 35 46
assign 1 35 47
createInstance 1 35 47
assign 1 35 48
new 0 35 48
assign 1 36 49
main 0 36 49
return 1 36 50
return 1 0 53
assign 1 0 56
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case -2127864150: return bem_argsGet_0();
case 2055025483: return bem_serializeContents_0();
case -1081571542: return bem_main_0();
case -729571811: return bem_serializeToString_0();
case -1502128718: return bem_default_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemStartup_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemStartup_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemStartup();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_inst = (BEC_2_6_7_SystemStartup) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_inst;
}
}
}
