namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bevo_18 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_20 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bevo_21 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_22 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_23 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_24 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_25 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_26 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_27 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_28 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_29 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_30 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_31 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_32 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_33 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_34 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_35 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_36 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bevo_37 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_38 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bevo_39 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_40 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_4_6_TextString bevs_inst;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
this.bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 187 */
 else  /* Line: 186 */ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 188 */ {
return this;
} /* Line: 189 */
} /* Line: 186 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 221 */
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_1;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = bevo_2;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevt_5_tmpany_phold = bevo_3;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
this.bem_setHex_2(bevt_4_tmpany_phold, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_1_tmpany_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_toString_3(bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
if (bevp_leni == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 245 */
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 250 */ {
bevt_5_tmpany_phold = bevo_4;
bevt_4_tmpany_phold = bevp_sizi.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevo_5;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevo_6;
bevl_nsize = bevt_3_tmpany_phold.bem_divide_1(bevt_7_tmpany_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 252 */
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_tmpany_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_8_tmpany_phold, bevt_9_tmpany_phold, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_7;
if (bevp_size.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_3_tmpany_phold = bevo_8;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_9;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
this.bem_setIntUnchecked_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
bevt_7_tmpany_phold = bevo_10;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_6_tmpany_phold.bevi_int;
} /* Line: 288 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bevo_11;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = bevo_12;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
this.bem_setCodeUnchecked_2(bevt_3_tmpany_phold, (BEC_2_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_1_tmpany_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_3_tmpany_phold = bevo_13;
bevt_5_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpany_phold = bevp_size.bem_subtract_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold = this.bem_substring_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 301 */
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_6_tmpany_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevt_8_tmpany_phold = bevo_14;
bevt_10_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpany_phold = bevp_size.bem_subtract_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = this.bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return bevt_7_tmpany_phold;
} /* Line: 305 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_15;
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_3_tmpany_phold = bevo_16;
if (bevl_found.bevi_int != bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 318 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 318 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 319 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 325 */
bevt_3_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bevp_size.bem_subtract_1(bevt_3_tmpany_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpany_phold);
if (bevl_found == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 328 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_3_tmpany_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 334 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 334 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 335 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 342 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 342 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_3_tmpany_phold = bevo_17;
if (bevl_ic.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_5_tmpany_phold = bevo_18;
if (bevl_ic.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 344 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 345 */
bevl_j.bevi_int++;
} /* Line: 342 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 353 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 353 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bevo_19;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevt_5_tmpany_phold = bevo_20;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 355 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_tmpany_phold.bevi_int;
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 357 */
bevl_j.bevi_int++;
} /* Line: 353 */
 else  /* Line: 353 */ {
break;
} /* Line: 353 */
} /* Line: 353 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lowerValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 368 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 368 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bevo_21;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevt_5_tmpany_phold = bevo_22;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 370 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 370 */
 else  /* Line: 370 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 370 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpany_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 372 */
bevl_j.bevi_int++;
} /* Line: 368 */
 else  /* Line: 368 */ {
break;
} /* Line: 368 */
} /* Line: 368 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_upperValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpany_phold = this.bem_split_1(beva_from);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_to, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 391 */ {
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevl_nxt = this.bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevt_2_tmpany_phold = this.bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_3_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 396 */
 else  /* Line: 398 */ {
bevt_5_tmpany_phold = this.bem_sizeGet_0();
bevt_4_tmpany_phold = this.bem_substring_2(bevl_last, bevt_5_tmpany_phold);
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 399 */
} /* Line: 393 */
 else  /* Line: 391 */ {
break;
} /* Line: 391 */
} /* Line: 391 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 410 */ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 410 */
 else  /* Line: 410 */ {
break;
} /* Line: 410 */
} /* Line: 410 */
bevt_2_tmpany_phold = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_tmpany_phold.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_tmpany_phold.bevi_int;
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 420 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 420 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpany_phold);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 420 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
return beva_into;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = this.bem_hashValue_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_23;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 444 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 444 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 444 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 444 */
 else  /* Line: 444 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 444 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 464 */
 else  /* Line: 472 */ {
return null;
} /* Line: 473 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_24;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 486 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 486 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 486 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 486 */
 else  /* Line: 486 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 486 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 510 */
 else  /* Line: 515 */ {
return null;
} /* Line: 516 */
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_25;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 522 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 522 */
 else  /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 522 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 523 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_26;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 528 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 528 */
 else  /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 528 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 529 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_27;
if (bevp_size.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 534 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 535 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_reverseBytes_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpany_phold.bem_find_1(bevt_2_tmpany_phold);
if (bevl_rpos == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 628 */ {
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpany_phold;
} /* Line: 630 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_28;
bevt_0_tmpany_phold = this.bem_find_2(beva_str, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
if (beva_str == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 642 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
if (beva_start == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 642 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 642 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 642 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_9_tmpany_phold = bevo_29;
if (beva_start.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 642 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 642 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 642 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 642 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 642 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 642 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_12_tmpany_phold = beva_str.bem_sizeGet_0();
if (bevt_12_tmpany_phold.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 642 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 642 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 642 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_14_tmpany_phold = bevo_30;
if (bevp_size.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 642 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 642 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 642 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_16_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpany_phold = bevo_31;
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 642 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 642 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 642 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 642 */ {
return null;
} /* Line: 643 */
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpany_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpany_phold = bevo_32;
if (bevl_strsize.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 654 */ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 657 */
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 660 */ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 660 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 662 */ {
bevt_24_tmpany_phold = bevo_33;
if (bevl_strsize.bevi_int == bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 663 */ {
return bevl_current;
} /* Line: 664 */
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_tmpany_phold.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 670 */ {
return null;
} /* Line: 671 */
bevt_28_tmpany_phold = bevo_34;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_tmpany_phold.bevi_int;
while (true)
 /* Line: 674 */ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 674 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 677 */ {
break;
} /* Line: 678 */
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 681 */
 else  /* Line: 674 */ {
break;
} /* Line: 674 */
} /* Line: 674 */
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 683 */ {
return bevl_current;
} /* Line: 684 */
} /* Line: 683 */
bevl_current.bevi_int++;
} /* Line: 687 */
 else  /* Line: 660 */ {
break;
} /* Line: 660 */
} /* Line: 660 */
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 697 */ {
if (bevl_i == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 697 */ {
bevt_1_tmpany_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpany_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 700 */
 else  /* Line: 697 */ {
break;
} /* Line: 697 */
} /* Line: 697 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 702 */ {
bevt_3_tmpany_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 703 */
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lineSplitterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_stri == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 725 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 725 */ {
bevt_2_tmpany_phold = beva_stri.bemd_1(-1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 725 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 725 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 725 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 725 */ {
return null;
} /* Line: 726 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 730 */ {
bevl_maxsize = bevl_osize;
} /* Line: 731 */
 else  /* Line: 732 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 733 */
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 738 */ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 738 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 741 */ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 742 */ {
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpany_phold;
} /* Line: 743 */
 else  /* Line: 744 */ {
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpany_phold;
} /* Line: 745 */
} /* Line: 742 */
bevl_i.bevi_int++;
} /* Line: 738 */
 else  /* Line: 738 */ {
break;
} /* Line: 738 */
} /* Line: 738 */
bevt_10_tmpany_phold = bevo_35;
if (bevl_myret.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 749 */ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 750 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 751 */
 else  /* Line: 750 */ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 752 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 753 */
} /* Line: 750 */
} /* Line: 750 */
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 760 */ {
return null;
} /* Line: 760 */
bevt_2_tmpany_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bevo_36;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 761 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 762 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 768 */ {
return null;
} /* Line: 768 */
bevt_2_tmpany_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bevo_37;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 769 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 770 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
  //if (bevls_stri != null) {
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  //}
  bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_equals_1(beva_str);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpany_phold, bevp_size, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_38;
if (beva_starti.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 861 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 861 */ {
bevt_4_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 861 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 861 */ {
bevt_6_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 861 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 861 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 861 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 861 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 861 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 861 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 861 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bels_1));
bevt_7_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 862 */
 else  /* Line: 863 */ {
if (bevp_leni == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 866 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 868 */
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 877 */ {
this.bem_capacitySet_1(bevp_sizi);
} /* Line: 878 */

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 933 */ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 937 */
return this;
} /* Line: 939 */
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_sizeGet_0();
bevt_0_tmpany_phold = this.bem_substring_2(beva_starti, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
this.bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_snw == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1065 */ {
this.bem_new_0();
} /* Line: 1066 */
 else  /* Line: 1067 */ {
bevt_2_tmpany_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpany_phold = bevo_39;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
this.bem_new_1(bevt_1_tmpany_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1069 */
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_strip_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bevo_40;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpany_phold);
while (true)
 /* Line: 1086 */ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1086 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1092 */
 else  /* Line: 1086 */ {
break;
} /* Line: 1086 */
} /* Line: 1086 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {168, 169, 182, 182, 182, 186, 186, 187, 188, 188, 189, 220, 220, 221, 223, 227, 227, 227, 228, 228, 228, 229, 229, 229, 233, 233, 233, 233, 233, 233, 233, 237, 238, 242, 243, 243, 244, 245, 247, 247, 248, 250, 250, 251, 251, 251, 251, 251, 251, 252, 254, 254, 254, 258, 262, 266, 270, 280, 281, 282, 286, 286, 286, 287, 287, 287, 287, 287, 288, 288, 288, 293, 293, 294, 294, 294, 295, 295, 295, 299, 299, 300, 301, 301, 301, 301, 301, 303, 304, 305, 305, 305, 305, 305, 307, 311, 311, 311, 312, 313, 317, 318, 318, 0, 318, 318, 318, 0, 0, 319, 319, 321, 321, 325, 325, 325, 325, 326, 326, 326, 327, 327, 328, 328, 330, 330, 334, 334, 0, 334, 334, 334, 0, 0, 335, 335, 337, 337, 341, 342, 342, 342, 343, 344, 344, 344, 0, 344, 344, 344, 0, 0, 345, 345, 342, 348, 348, 352, 353, 353, 353, 354, 355, 355, 355, 355, 355, 355, 0, 0, 0, 356, 356, 357, 353, 363, 363, 363, 367, 368, 368, 368, 369, 370, 370, 370, 370, 370, 370, 0, 0, 0, 371, 371, 372, 368, 378, 378, 378, 382, 382, 382, 382, 388, 389, 390, 391, 391, 392, 393, 393, 394, 394, 395, 396, 396, 399, 399, 399, 403, 408, 408, 409, 410, 410, 410, 411, 410, 413, 413, 414, 418, 419, 419, 420, 420, 420, 421, 422, 422, 423, 420, 426, 430, 430, 430, 434, 434, 434, 444, 444, 444, 444, 444, 0, 0, 0, 473, 475, 486, 486, 486, 486, 486, 0, 0, 0, 516, 518, 522, 522, 522, 522, 522, 0, 0, 0, 523, 528, 528, 528, 528, 528, 0, 0, 0, 529, 534, 534, 534, 535, 535, 537, 537, 620, 620, 626, 626, 626, 626, 626, 628, 628, 629, 629, 630, 630, 632, 636, 636, 636, 642, 642, 0, 642, 642, 0, 0, 0, 642, 642, 642, 0, 0, 0, 642, 642, 0, 0, 0, 642, 642, 642, 0, 0, 0, 642, 642, 642, 0, 0, 0, 642, 642, 642, 642, 0, 0, 643, 646, 647, 648, 649, 650, 650, 652, 654, 654, 654, 655, 656, 657, 659, 660, 660, 661, 662, 662, 663, 663, 663, 664, 666, 667, 668, 669, 669, 670, 670, 671, 673, 673, 673, 674, 674, 675, 676, 677, 677, 680, 681, 683, 683, 684, 687, 689, 693, 694, 695, 696, 697, 697, 698, 698, 699, 700, 702, 702, 703, 703, 705, 709, 709, 709, 713, 713, 713, 713, 717, 725, 725, 0, 725, 0, 0, 726, 728, 729, 730, 730, 731, 733, 735, 736, 737, 738, 738, 738, 739, 740, 741, 741, 742, 742, 743, 743, 745, 745, 738, 749, 749, 749, 750, 750, 751, 752, 752, 753, 756, 760, 760, 760, 761, 761, 761, 761, 762, 762, 764, 764, 768, 768, 768, 769, 769, 769, 769, 770, 770, 772, 772, 821, 821, 825, 825, 825, 829, 830, 830, 830, 831, 831, 831, 832, 832, 832, 833, 836, 836, 861, 861, 861, 0, 861, 861, 861, 0, 861, 861, 861, 0, 0, 0, 0, 862, 862, 862, 866, 866, 867, 868, 870, 871, 872, 874, 875, 877, 877, 878, 933, 933, 937, 939, 944, 944, 944, 948, 948, 948, 948, 948, 1033, 1037, 1037, 1041, 1041, 1045, 1045, 1049, 1049, 1053, 1053, 1057, 1057, 1061, 1065, 1065, 1066, 1068, 1068, 1068, 1068, 1069, 1074, 1074, 1078, 1078, 1078, 1082, 1083, 1084, 1085, 1085, 1086, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {98, 99, 105, 106, 107, 114, 119, 120, 123, 128, 129, 140, 145, 146, 148, 158, 159, 160, 161, 162, 163, 164, 165, 166, 176, 177, 178, 179, 180, 181, 182, 186, 187, 203, 204, 209, 210, 211, 213, 214, 215, 216, 221, 222, 223, 224, 225, 226, 227, 228, 230, 231, 232, 236, 239, 242, 246, 257, 258, 259, 270, 271, 276, 277, 278, 279, 280, 281, 282, 283, 284, 294, 295, 296, 297, 298, 299, 300, 301, 317, 318, 319, 321, 322, 323, 324, 325, 327, 328, 330, 331, 332, 333, 334, 336, 342, 343, 344, 345, 346, 356, 357, 362, 363, 366, 367, 372, 373, 376, 380, 381, 383, 384, 395, 400, 401, 402, 404, 405, 406, 407, 412, 413, 414, 416, 417, 426, 431, 432, 435, 436, 441, 442, 445, 449, 450, 452, 453, 466, 467, 470, 475, 476, 477, 478, 483, 484, 487, 488, 493, 494, 497, 501, 502, 504, 510, 511, 523, 524, 527, 532, 533, 534, 535, 540, 541, 542, 547, 548, 551, 555, 558, 559, 560, 562, 573, 574, 575, 587, 588, 591, 596, 597, 598, 599, 604, 605, 606, 611, 612, 615, 619, 622, 623, 624, 626, 637, 638, 639, 645, 646, 647, 648, 660, 661, 662, 665, 670, 671, 672, 677, 678, 679, 680, 681, 682, 685, 686, 687, 694, 704, 705, 706, 707, 710, 715, 716, 717, 723, 724, 725, 733, 734, 735, 736, 739, 744, 745, 746, 747, 748, 749, 755, 760, 761, 762, 767, 768, 769, 776, 777, 782, 783, 788, 789, 792, 796, 806, 808, 815, 816, 821, 822, 827, 828, 831, 835, 842, 844, 851, 852, 857, 858, 863, 864, 867, 871, 874, 883, 884, 889, 890, 895, 896, 899, 903, 906, 915, 916, 921, 922, 923, 925, 926, 944, 945, 956, 957, 958, 959, 960, 961, 966, 967, 968, 969, 970, 972, 977, 978, 979, 1023, 1028, 1029, 1032, 1037, 1038, 1041, 1045, 1048, 1049, 1054, 1055, 1058, 1062, 1065, 1070, 1071, 1074, 1078, 1081, 1082, 1087, 1088, 1091, 1095, 1098, 1099, 1104, 1105, 1108, 1112, 1115, 1116, 1117, 1122, 1123, 1126, 1130, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1145, 1146, 1147, 1148, 1150, 1153, 1158, 1159, 1160, 1165, 1166, 1167, 1172, 1173, 1175, 1176, 1177, 1178, 1179, 1180, 1185, 1186, 1188, 1189, 1190, 1193, 1198, 1199, 1200, 1201, 1206, 1209, 1210, 1216, 1221, 1222, 1225, 1231, 1242, 1243, 1244, 1245, 1248, 1253, 1254, 1255, 1256, 1257, 1263, 1268, 1269, 1270, 1272, 1277, 1278, 1279, 1285, 1286, 1287, 1288, 1291, 1314, 1319, 1320, 1323, 1325, 1328, 1332, 1334, 1335, 1336, 1341, 1342, 1345, 1347, 1348, 1349, 1350, 1353, 1358, 1359, 1360, 1361, 1366, 1367, 1372, 1373, 1374, 1377, 1378, 1381, 1387, 1388, 1393, 1394, 1399, 1400, 1403, 1408, 1409, 1413, 1422, 1427, 1428, 1430, 1431, 1432, 1437, 1438, 1439, 1441, 1442, 1451, 1456, 1457, 1459, 1460, 1461, 1466, 1467, 1468, 1470, 1471, 1487, 1488, 1493, 1494, 1499, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1524, 1525, 1542, 1543, 1548, 1549, 1552, 1553, 1558, 1559, 1562, 1563, 1568, 1569, 1572, 1576, 1579, 1583, 1584, 1585, 1588, 1593, 1594, 1595, 1597, 1598, 1599, 1600, 1601, 1602, 1607, 1608, 1613, 1618, 1619, 1621, 1627, 1628, 1629, 1636, 1637, 1638, 1639, 1640, 1656, 1661, 1662, 1666, 1667, 1671, 1672, 1676, 1677, 1681, 1682, 1686, 1687, 1690, 1697, 1702, 1703, 1706, 1707, 1708, 1709, 1710, 1716, 1717, 1722, 1723, 1724, 1733, 1734, 1735, 1736, 1737, 1740, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1760, 1763, 1767, 1770, 1773, 1777, 1780};
/* BEGIN LINEINFO 
assign 1 168 98
new 0 168 98
capacitySet 1 169 99
assign 1 182 105
new 0 182 105
assign 1 182 106
once 0 182 106
new 1 182 107
assign 1 186 114
undef 1 186 119
assign 1 187 120
new 0 187 120
assign 1 188 123
equals 1 188 128
return 1 189 129
assign 1 220 140
greater 1 220 145
setValue 1 221 146
setValue 1 223 148
assign 1 227 158
new 0 227 158
assign 1 227 159
once 0 227 159
new 1 227 160
assign 1 228 161
new 0 228 161
assign 1 228 162
once 0 228 162
setValue 1 228 163
assign 1 229 164
new 0 229 164
assign 1 229 165
once 0 229 165
setHex 2 229 166
assign 1 233 176
new 0 233 176
assign 1 233 177
getCode 2 233 177
assign 1 233 178
new 0 233 178
assign 1 233 179
new 0 233 179
assign 1 233 180
new 0 233 180
assign 1 233 181
toString 3 233 181
return 1 233 182
assign 1 237 186
hexNew 1 237 186
setCode 2 238 187
assign 1 242 203
toString 0 242 203
assign 1 243 204
undef 1 243 209
assign 1 244 210
new 0 244 210
assign 1 245 211
new 0 245 211
assign 1 247 213
sizeGet 0 247 213
setValue 1 247 214
addValue 1 248 215
assign 1 250 216
lesser 1 250 221
assign 1 251 222
new 0 251 222
assign 1 251 223
add 1 251 223
assign 1 251 224
new 0 251 224
assign 1 251 225
multiply 1 251 225
assign 1 251 226
new 0 251 226
assign 1 251 227
divide 1 251 227
capacitySet 1 252 228
assign 1 254 230
new 0 254 230
assign 1 254 231
sizeGet 0 254 231
copyValue 4 254 232
return 1 258 236
return 1 262 239
addValue 1 266 242
write 1 270 246
assign 1 280 257
copy 0 280 257
clear 0 281 258
return 1 282 259
assign 1 286 270
new 0 286 270
assign 1 286 271
greater 1 286 276
assign 1 287 277
new 0 287 277
assign 1 287 278
once 0 287 278
assign 1 287 279
new 0 287 279
assign 1 287 280
once 0 287 280
setIntUnchecked 2 287 281
assign 1 288 282
new 0 288 282
assign 1 288 283
once 0 288 283
setValue 1 288 284
assign 1 293 294
new 0 293 294
new 1 293 295
assign 1 294 296
new 0 294 296
assign 1 294 297
once 0 294 297
setValue 1 294 298
assign 1 295 299
new 0 295 299
assign 1 295 300
once 0 295 300
setCodeUnchecked 2 295 301
assign 1 299 317
new 0 299 317
assign 1 299 318
newlineGet 0 299 318
assign 1 300 319
ends 1 300 319
assign 1 301 321
new 0 301 321
assign 1 301 322
sizeGet 0 301 322
assign 1 301 323
subtract 1 301 323
assign 1 301 324
substring 2 301 324
return 1 301 325
assign 1 303 327
new 0 303 327
assign 1 304 328
ends 1 304 328
assign 1 305 330
new 0 305 330
assign 1 305 331
sizeGet 0 305 331
assign 1 305 332
subtract 1 305 332
assign 1 305 333
substring 2 305 333
return 1 305 334
return 1 307 336
assign 1 311 342
new 0 311 342
assign 1 311 343
add 1 311 343
assign 1 311 344
new 1 311 344
addValue 1 312 345
return 1 313 346
assign 1 317 356
find 1 317 356
assign 1 318 357
undef 1 318 362
assign 1 0 363
assign 1 318 366
new 0 318 366
assign 1 318 367
notEquals 1 318 372
assign 1 0 373
assign 1 0 376
assign 1 319 380
new 0 319 380
return 1 319 381
assign 1 321 383
new 0 321 383
return 1 321 384
assign 1 325 395
undef 1 325 400
assign 1 325 401
new 0 325 401
return 1 325 402
assign 1 326 404
sizeGet 0 326 404
assign 1 326 405
subtract 1 326 405
assign 1 326 406
find 2 326 406
assign 1 327 407
undef 1 327 412
assign 1 328 413
new 0 328 413
return 1 328 414
assign 1 330 416
new 0 330 416
return 1 330 417
assign 1 334 426
undef 1 334 431
assign 1 0 432
assign 1 334 435
find 1 334 435
assign 1 334 436
undef 1 334 441
assign 1 0 442
assign 1 0 445
assign 1 335 449
new 0 335 449
return 1 335 450
assign 1 337 452
new 0 337 452
return 1 337 453
assign 1 341 466
new 0 341 466
assign 1 342 467
new 0 342 467
assign 1 342 470
lesser 1 342 475
getInt 2 343 476
assign 1 344 477
new 0 344 477
assign 1 344 478
greater 1 344 483
assign 1 0 484
assign 1 344 487
new 0 344 487
assign 1 344 488
lesser 1 344 493
assign 1 0 494
assign 1 0 497
assign 1 345 501
new 0 345 501
return 1 345 502
incrementValue 0 342 504
assign 1 348 510
new 0 348 510
return 1 348 511
assign 1 352 523
new 0 352 523
assign 1 353 524
new 0 353 524
assign 1 353 527
lesser 1 353 532
getInt 2 354 533
assign 1 355 534
new 0 355 534
assign 1 355 535
greater 1 355 540
assign 1 355 541
new 0 355 541
assign 1 355 542
lesser 1 355 547
assign 1 0 548
assign 1 0 551
assign 1 0 555
assign 1 356 558
new 0 356 558
addValue 1 356 559
setIntUnchecked 2 357 560
incrementValue 0 353 562
assign 1 363 573
copy 0 363 573
assign 1 363 574
lowerValue 0 363 574
return 1 363 575
assign 1 367 587
new 0 367 587
assign 1 368 588
new 0 368 588
assign 1 368 591
lesser 1 368 596
getInt 2 369 597
assign 1 370 598
new 0 370 598
assign 1 370 599
greater 1 370 604
assign 1 370 605
new 0 370 605
assign 1 370 606
lesser 1 370 611
assign 1 0 612
assign 1 0 615
assign 1 0 619
assign 1 371 622
new 0 371 622
subtractValue 1 371 623
setIntUnchecked 2 372 624
incrementValue 0 368 626
assign 1 378 637
copy 0 378 637
assign 1 378 638
upperValue 0 378 638
return 1 378 639
assign 1 382 645
new 0 382 645
assign 1 382 646
split 1 382 646
assign 1 382 647
join 2 382 647
return 1 382 648
assign 1 388 660
new 0 388 660
assign 1 389 661
new 0 389 661
assign 1 390 662
new 0 390 662
assign 1 391 665
def 1 391 670
assign 1 392 671
find 2 392 671
assign 1 393 672
def 1 393 677
assign 1 394 678
substring 2 394 678
addValue 1 394 679
addValue 1 395 680
assign 1 396 681
sizeGet 0 396 681
assign 1 396 682
add 1 396 682
assign 1 399 685
sizeGet 0 399 685
assign 1 399 686
substring 2 399 686
addValue 1 399 687
return 1 403 694
assign 1 408 704
new 0 408 704
assign 1 408 705
new 1 408 705
assign 1 409 706
mbiterGet 0 409 706
assign 1 410 707
new 0 410 707
assign 1 410 710
lesser 1 410 715
next 1 411 716
incrementValue 0 410 717
assign 1 413 723
next 1 413 723
assign 1 413 724
toString 0 413 724
return 1 414 725
assign 1 418 733
new 0 418 733
assign 1 419 734
new 0 419 734
setValue 1 419 735
assign 1 420 736
new 0 420 736
assign 1 420 739
lesser 1 420 744
getInt 2 421 745
assign 1 422 746
new 0 422 746
multiplyValue 1 422 747
addValue 1 423 748
incrementValue 0 420 749
return 1 426 755
assign 1 430 760
new 0 430 760
assign 1 430 761
hashValue 1 430 761
return 1 430 762
assign 1 434 767
new 0 434 767
assign 1 434 768
getCode 2 434 768
return 1 434 769
assign 1 444 776
new 0 444 776
assign 1 444 777
greaterEquals 1 444 782
assign 1 444 783
greater 1 444 788
assign 1 0 789
assign 1 0 792
assign 1 0 796
return 1 473 806
return 1 475 808
assign 1 486 815
new 0 486 815
assign 1 486 816
greaterEquals 1 486 821
assign 1 486 822
greater 1 486 827
assign 1 0 828
assign 1 0 831
assign 1 0 835
return 1 516 842
return 1 518 844
assign 1 522 851
new 0 522 851
assign 1 522 852
greaterEquals 1 522 857
assign 1 522 858
greater 1 522 863
assign 1 0 864
assign 1 0 867
assign 1 0 871
setIntUnchecked 2 523 874
assign 1 528 883
new 0 528 883
assign 1 528 884
greaterEquals 1 528 889
assign 1 528 890
greater 1 528 895
assign 1 0 896
assign 1 0 899
assign 1 0 903
setCodeUnchecked 2 529 906
assign 1 534 915
new 0 534 915
assign 1 534 916
lesserEquals 1 534 921
assign 1 535 922
new 0 535 922
return 1 535 923
assign 1 537 925
new 0 537 925
return 1 537 926
assign 1 620 944
rfind 1 620 944
return 1 620 945
assign 1 626 956
copy 0 626 956
assign 1 626 957
reverseBytes 0 626 957
assign 1 626 958
copy 0 626 958
assign 1 626 959
reverseBytes 0 626 959
assign 1 626 960
find 1 626 960
assign 1 628 961
def 1 628 966
assign 1 629 967
sizeGet 0 629 967
addValue 1 629 968
assign 1 630 969
subtract 1 630 969
return 1 630 970
return 1 632 972
assign 1 636 977
new 0 636 977
assign 1 636 978
find 2 636 978
return 1 636 979
assign 1 642 1023
undef 1 642 1028
assign 1 0 1029
assign 1 642 1032
undef 1 642 1037
assign 1 0 1038
assign 1 0 1041
assign 1 0 1045
assign 1 642 1048
new 0 642 1048
assign 1 642 1049
lesser 1 642 1054
assign 1 0 1055
assign 1 0 1058
assign 1 0 1062
assign 1 642 1065
greaterEquals 1 642 1070
assign 1 0 1071
assign 1 0 1074
assign 1 0 1078
assign 1 642 1081
sizeGet 0 642 1081
assign 1 642 1082
greater 1 642 1087
assign 1 0 1088
assign 1 0 1091
assign 1 0 1095
assign 1 642 1098
new 0 642 1098
assign 1 642 1099
equals 1 642 1104
assign 1 0 1105
assign 1 0 1108
assign 1 0 1112
assign 1 642 1115
sizeGet 0 642 1115
assign 1 642 1116
new 0 642 1116
assign 1 642 1117
equals 1 642 1122
assign 1 0 1123
assign 1 0 1126
return 1 643 1130
assign 1 646 1132
assign 1 647 1133
copy 0 647 1133
assign 1 648 1134
new 0 648 1134
assign 1 649 1135
new 0 649 1135
assign 1 650 1136
new 0 650 1136
getInt 2 650 1137
assign 1 652 1138
sizeGet 0 652 1138
assign 1 654 1139
new 0 654 1139
assign 1 654 1140
greater 1 654 1145
assign 1 655 1146
new 0 655 1146
assign 1 656 1147
new 0 656 1147
assign 1 657 1148
new 0 657 1148
assign 1 659 1150
new 0 659 1150
assign 1 660 1153
lesser 1 660 1158
getInt 2 661 1159
assign 1 662 1160
equals 1 662 1165
assign 1 663 1166
new 0 663 1166
assign 1 663 1167
equals 1 663 1172
return 1 664 1173
setValue 1 666 1175
incrementValue 0 667 1176
setValue 1 668 1177
assign 1 669 1178
sizeGet 0 669 1178
addValue 1 669 1179
assign 1 670 1180
greater 1 670 1185
return 1 671 1186
assign 1 673 1188
new 0 673 1188
assign 1 673 1189
once 0 673 1189
setValue 1 673 1190
assign 1 674 1193
lesser 1 674 1198
getInt 2 675 1199
getInt 2 676 1200
assign 1 677 1201
notEquals 1 677 1206
incrementValue 0 680 1209
incrementValue 0 681 1210
assign 1 683 1216
equals 1 683 1221
return 1 684 1222
incrementValue 0 687 1225
return 1 689 1231
assign 1 693 1242
new 0 693 1242
assign 1 694 1243
new 0 694 1243
assign 1 695 1244
find 2 695 1244
assign 1 696 1245
sizeGet 0 696 1245
assign 1 697 1248
def 1 697 1253
assign 1 698 1254
substring 2 698 1254
addValue 1 698 1255
assign 1 699 1256
add 1 699 1256
assign 1 700 1257
find 2 700 1257
assign 1 702 1263
lesser 1 702 1268
assign 1 703 1269
substring 2 703 1269
addValue 1 703 1270
return 1 705 1272
assign 1 709 1277
new 0 709 1277
assign 1 709 1278
join 2 709 1278
return 1 709 1279
assign 1 713 1285
new 0 713 1285
assign 1 713 1286
lineSplitterGet 0 713 1286
assign 1 713 1287
tokenize 1 713 1287
return 1 713 1288
return 1 717 1291
assign 1 725 1314
undef 1 725 1319
assign 1 0 1320
assign 1 725 1323
otherType 1 725 1323
assign 1 0 1325
assign 1 0 1328
return 1 726 1332
assign 1 728 1334
assign 1 729 1335
sizeGet 0 729 1335
assign 1 730 1336
greater 1 730 1341
assign 1 731 1342
assign 1 733 1345
assign 1 735 1347
new 0 735 1347
assign 1 736 1348
new 0 736 1348
assign 1 737 1349
new 0 737 1349
assign 1 738 1350
new 0 738 1350
assign 1 738 1353
lesser 1 738 1358
getCode 2 739 1359
getCode 2 740 1360
assign 1 741 1361
notEquals 1 741 1366
assign 1 742 1367
greater 1 742 1372
assign 1 743 1373
new 0 743 1373
return 1 743 1374
assign 1 745 1377
new 0 745 1377
return 1 745 1378
incrementValue 0 738 1381
assign 1 749 1387
new 0 749 1387
assign 1 749 1388
equals 1 749 1393
assign 1 750 1394
greater 1 750 1399
assign 1 751 1400
new 0 751 1400
assign 1 752 1403
greater 1 752 1408
assign 1 753 1409
new 0 753 1409
return 1 756 1413
assign 1 760 1422
undef 1 760 1427
return 1 760 1428
assign 1 761 1430
compare 1 761 1430
assign 1 761 1431
new 0 761 1431
assign 1 761 1432
equals 1 761 1437
assign 1 762 1438
new 0 762 1438
return 1 762 1439
assign 1 764 1441
new 0 764 1441
return 1 764 1442
assign 1 768 1451
undef 1 768 1456
return 1 768 1457
assign 1 769 1459
compare 1 769 1459
assign 1 769 1460
new 0 769 1460
assign 1 769 1461
equals 1 769 1466
assign 1 770 1467
new 0 770 1467
return 1 770 1468
assign 1 772 1470
new 0 772 1470
return 1 772 1471
assign 1 821 1487
new 0 821 1487
return 1 821 1488
assign 1 825 1493
equals 1 825 1493
assign 1 825 1494
not 0 825 1499
return 1 825 1499
assign 1 829 1510
toString 0 829 1510
assign 1 830 1511
sizeGet 0 830 1511
assign 1 830 1512
add 1 830 1512
assign 1 830 1513
new 1 830 1513
assign 1 831 1514
new 0 831 1514
assign 1 831 1515
new 0 831 1515
copyValue 4 831 1516
assign 1 832 1517
new 0 832 1517
assign 1 832 1518
sizeGet 0 832 1518
copyValue 4 832 1519
return 1 833 1520
assign 1 836 1524
new 0 836 1524
return 1 836 1525
assign 1 861 1542
new 0 861 1542
assign 1 861 1543
lesser 1 861 1548
assign 1 0 1549
assign 1 861 1552
sizeGet 0 861 1552
assign 1 861 1553
greater 1 861 1558
assign 1 0 1559
assign 1 861 1562
sizeGet 0 861 1562
assign 1 861 1563
greater 1 861 1568
assign 1 0 1569
assign 1 0 1572
assign 1 0 1576
assign 1 0 1579
assign 1 862 1583
new 0 862 1583
assign 1 862 1584
new 1 862 1584
throw 1 862 1585
assign 1 866 1588
undef 1 866 1593
assign 1 867 1594
new 0 867 1594
assign 1 868 1595
new 0 868 1595
setValue 1 870 1597
subtractValue 1 871 1598
assign 1 872 1599
setValue 1 874 1600
addValue 1 875 1601
assign 1 877 1602
greater 1 877 1607
capacitySet 1 878 1608
assign 1 933 1613
greater 1 933 1618
setValue 1 937 1619
return 1 939 1621
assign 1 944 1627
sizeGet 0 944 1627
assign 1 944 1628
substring 2 944 1628
return 1 944 1629
assign 1 948 1636
subtract 1 948 1636
assign 1 948 1637
new 1 948 1637
assign 1 948 1638
new 0 948 1638
assign 1 948 1639
copyValue 4 948 1639
return 1 948 1640
output 0 1033 1656
assign 1 1037 1661
new 1 1037 1661
return 1 1037 1662
assign 1 1041 1666
new 1 1041 1666
return 1 1041 1667
assign 1 1045 1671
new 1 1045 1671
return 1 1045 1672
assign 1 1049 1676
new 1 1049 1676
return 1 1049 1677
assign 1 1053 1681
new 1 1053 1681
return 1 1053 1682
assign 1 1057 1686
new 1 1057 1686
return 1 1057 1687
return 1 1061 1690
assign 1 1065 1697
undef 1 1065 1702
new 0 1066 1703
assign 1 1068 1706
sizeGet 0 1068 1706
assign 1 1068 1707
new 0 1068 1707
assign 1 1068 1708
add 1 1068 1708
new 1 1068 1709
addValue 1 1069 1710
assign 1 1074 1716
new 0 1074 1716
return 1 1074 1717
assign 1 1078 1722
new 0 1078 1722
assign 1 1078 1723
strip 1 1078 1723
return 1 1078 1724
assign 1 1082 1733
new 0 1082 1733
assign 1 1083 1734
new 0 1083 1734
assign 1 1084 1735
new 0 1084 1735
assign 1 1085 1736
new 0 1085 1736
assign 1 1085 1737
subtract 1 1085 1737
assign 1 1086 1740
greater 1 1086 1745
getInt 2 1087 1746
getInt 2 1088 1747
setInt 2 1089 1748
setInt 2 1090 1749
incrementValue 0 1091 1750
decrementValue 0 1092 1751
return 1 0 1760
assign 1 0 1763
return 1 0 1767
return 1 0 1770
assign 1 0 1773
return 1 0 1777
assign 1 0 1780
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case -1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case -1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case -223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case -855090856: return bem_multiByteIteratorGet_0();
case -1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 195899181: return bem_biterGet_0();
case -1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1607888168: return bem_stringIteratorGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case -729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case -1881757495: return bem_strip_0();
case -139115914: return bem_splitLines_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case -800915430: return bem_reverseBytes_0();
case -1354714650: return bem_copy_0();
case -85457677: return bem_leniGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 599761551: return bem_siziSet_1(bevd_0);
case -1274448085: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1143153819: return bem_codeNew_1(bevd_0);
case -1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1954998871: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1406325780: return bem_writeTo_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -2001811380: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case 636254476: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case -1250088509: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case -74375424: return bem_leniSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case -1298743126: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 340923733: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1412717737: return bem_compare_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1395074208: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1154529699: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -889715578: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1393886412: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1811422864: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -761715532: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1250088508: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1274448084: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 340923734: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1956186668: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case -391213135: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bevs_inst = (BEC_2_4_6_TextString)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bevs_inst;
}
}
}
