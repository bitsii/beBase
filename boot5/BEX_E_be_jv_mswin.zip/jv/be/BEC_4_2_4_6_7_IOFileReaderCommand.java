package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_7_IOFileReaderCommand extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
public static BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_1(BEC_2_6_6_SystemObject beva__command) throws Throwable {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) throws Throwable {
super.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool)/* Line: 832*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_command);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_ta_ph);
throw new be.BECS_ThrowBack(bevt_0_ta_ph);
} /* Line: 833*/
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_close_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {795, 799, 803, 805, 816, 831, 833, 833, 833, 833, 833, 833, 846, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 23, 24, 35, 36, 38, 39, 40, 41, 42, 43, 48, 52, 55};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 795 15
commandNew 1 799 19
new 0 803 23
assign 1 805 24
assign 1 816 35
assign 1 831 36
assign 1 833 38
new 0 833 38
assign 1 833 39
add 1 833 39
assign 1 833 40
new 0 833 40
assign 1 833 41
add 1 833 41
assign 1 833 42
new 1 833 42
throw 1 833 43
assign 1 846 48
new 0 846 48
return 1 0 52
assign 1 0 55
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 135466177: return bem_hashGet_0();
case 1653976958: return bem_iteratorGet_0();
case -121648978: return bem_commandGet_0();
case -1202199849: return bem_new_0();
case -1168285636: return bem_readStringClose_0();
case -753678241: return bem_toString_0();
case 1517255897: return bem_pathGet_0();
case -1735500821: return bem_open_0();
case 1883105734: return bem_create_0();
case 2031684907: return bem_readBufferLine_0();
case -443228076: return bem_isClosedGet_0();
case 2006813550: return bem_print_0();
case 617328299: return bem_readBuffer_0();
case 142227109: return bem_copy_0();
case 7486711: return bem_readString_0();
case -463096299: return bem_readDiscardClose_0();
case 275749271: return bem_readDiscard_0();
case -885275023: return bem_vfileGet_0();
case 895116919: return bem_byteReaderGet_0();
case -2108362466: return bem_extOpen_0();
case -849538484: return bem_close_0();
case -572414313: return bem_blockSizeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 388121757: return bem_copyTo_1(bevd_0);
case 595179209: return bem_new_1(bevd_0);
case -2104029535: return bem_undef_1(bevd_0);
case 1981775088: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1714367854: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1627310614: return bem_pathSet_1(bevd_0);
case -241328359: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 31898586: return bem_commandSet_1(bevd_0);
case 1752525195: return bem_vfileSet_1(bevd_0);
case -967064150: return bem_isClosedSet_1(bevd_0);
case 922325899: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 482599590: return bem_def_1(bevd_0);
case -1388448247: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 72201968: return bem_equals_1(bevd_0);
case -1191333891: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -795355377: return bem_blockSizeSet_1(bevd_0);
case 794407854: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 413616696: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1862124034: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -938062108: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -771677452: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -544842910: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 844231596: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1239023512: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -526316456: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
