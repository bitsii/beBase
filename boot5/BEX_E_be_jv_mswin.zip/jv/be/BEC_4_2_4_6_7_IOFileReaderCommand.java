package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_7_IOFileReaderCommand extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0, 8));
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1, 30));
public static BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_1(BEC_2_6_6_SystemObject beva__command) throws Throwable {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) throws Throwable {
super.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool) /* Line: 832 */ {
bevt_3_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_command);
bevt_4_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 833 */
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_close_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public final BEC_2_4_6_TextString bem_commandGetDirect_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {795, 799, 803, 805, 816, 831, 833, 833, 833, 833, 833, 833, 846, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 21, 25, 26, 37, 38, 40, 41, 42, 43, 44, 45, 50, 54, 57, 60, 64};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 795 17
commandNew 1 799 21
new 0 803 25
assign 1 805 26
assign 1 816 37
assign 1 831 38
assign 1 833 40
new 0 833 40
assign 1 833 41
add 1 833 41
assign 1 833 42
new 0 833 42
assign 1 833 43
add 1 833 43
assign 1 833 44
new 1 833 44
throw 1 833 45
assign 1 846 50
new 0 846 50
return 1 0 54
return 1 0 57
assign 1 0 60
assign 1 0 64
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1030758049: return bem_readDiscard_0();
case 2142572680: return bem_close_0();
case -224465120: return bem_sourceFileNameGet_0();
case 369845534: return bem_commandGet_0();
case 945358915: return bem_readStringClose_0();
case 39594325: return bem_vfileGet_0();
case -2007275567: return bem_many_0();
case -718845534: return bem_open_0();
case 2138976948: return bem_commandGetDirect_0();
case 1782351683: return bem_serializeContents_0();
case 1099447992: return bem_fieldNamesGet_0();
case 1415730627: return bem_byteReaderGet_0();
case -881577546: return bem_classNameGet_0();
case 569361306: return bem_iteratorGet_0();
case 1126147730: return bem_isClosedGetDirect_0();
case -498203147: return bem_readDiscardClose_0();
case 406264345: return bem_extOpen_0();
case 393738758: return bem_serializeToString_0();
case 40029875: return bem_pathGetDirect_0();
case 25163966: return bem_blockSizeGetDirect_0();
case -2031839191: return bem_serializationIteratorGet_0();
case 2144693643: return bem_deserializeClassNameGet_0();
case 361898879: return bem_readBufferLine_0();
case 641839943: return bem_toAny_0();
case 1950749962: return bem_blockSizeGet_0();
case -1092510954: return bem_copy_0();
case -634018133: return bem_tagGet_0();
case -333184732: return bem_vfileGetDirect_0();
case -124285366: return bem_once_0();
case -1750720088: return bem_hashGet_0();
case 472302085: return bem_pathGet_0();
case 2146604653: return bem_new_0();
case 971841201: return bem_fieldIteratorGet_0();
case -1041002500: return bem_readBuffer_0();
case -653750385: return bem_create_0();
case -1018795891: return bem_readString_0();
case 148544119: return bem_toString_0();
case 908678857: return bem_print_0();
case 1634958850: return bem_isClosedGet_0();
case -212742483: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1928510621: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -448360789: return bem_otherClass_1(bevd_0);
case -872115670: return bem_defined_1(bevd_0);
case -13056198: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 213891793: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case -1565662060: return bem_sameObject_1(bevd_0);
case -1721682328: return bem_isClosedSetDirect_1(bevd_0);
case 404686503: return bem_commandSetDirect_1(bevd_0);
case -548688194: return bem_commandSet_1(bevd_0);
case -1854757243: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 326949551: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1236734559: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1367146792: return bem_sameClass_1(bevd_0);
case 389340449: return bem_otherType_1(bevd_0);
case -1713280339: return bem_blockSizeSet_1(bevd_0);
case -1300513923: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1085112155: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 823788707: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1519516879: return bem_equals_1(bevd_0);
case 1446250233: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1118568526: return bem_pathSetDirect_1(bevd_0);
case -359346681: return bem_sameType_1(bevd_0);
case -1586811529: return bem_undefined_1(bevd_0);
case 202650326: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -2043991996: return bem_isClosedSet_1(bevd_0);
case 338229476: return bem_new_1(bevd_0);
case -2009745520: return bem_blockSizeSetDirect_1(bevd_0);
case 1703616583: return bem_notEquals_1(bevd_0);
case -884607798: return bem_def_1(bevd_0);
case 1730397553: return bem_undef_1(bevd_0);
case 890945493: return bem_vfileSetDirect_1(bevd_0);
case -680043600: return bem_pathSet_1(bevd_0);
case -249326151: return bem_copyTo_1(bevd_0);
case -1093769410: return bem_vfileSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 89286143: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 29395685: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 827793836: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1899980628: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1061986002: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1194360433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -454033656: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 696322560: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 382658112: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1104463589: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
