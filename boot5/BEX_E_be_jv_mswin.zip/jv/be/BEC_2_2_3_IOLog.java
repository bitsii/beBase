package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog extends BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x6C,0x6F,0x67,0x67,0x65,0x64,0x20};
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 1));
private static byte[] bece_BEC_2_2_3_IOLog_bels_3 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_3, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_2 = (new BEC_2_4_3_MathInt(400));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_3 = (new BEC_2_4_3_MathInt(300));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_4 = (new BEC_2_4_3_MathInt(200));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_5 = (new BEC_2_4_3_MathInt(100));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_6 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public BEC_2_6_6_SystemObject bevp_sink;
public BEC_2_2_3_IOLog bem_new_3(BEC_2_6_6_SystemObject beva__sink, BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
bevp_sink = beva__sink;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 146 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 147 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 154 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_3_IOLog bem_out_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 160 */ {
beva_msg = (new BEC_2_4_6_TextString(4, bece_BEC_2_2_3_IOLog_bels_0));
} /* Line: 161 */
if (bevp_sink == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_sink.bemd_1(-754522664, beva_msg);
} /* Line: 164 */
 else  /* Line: 165 */ {
beva_msg.bem_print_0();
} /* Line: 166 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_1(BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_2_3_IOLog_bels_1));
bem_elog_2(bevt_0_tmpany_phold, beva_e);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_2(BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_10_SystemExceptions bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_0;
bevt_1_tmpany_phold = beva_msg.bem_add_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_tS_1(beva_e);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bem_log_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 179 */ {
bem_out_1(beva_msg);
} /* Line: 180 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_3(BEC_2_4_3_MathInt beva_level, BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_10_SystemExceptions bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_1;
bevt_1_tmpany_phold = beva_msg.bem_add_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_tS_1(beva_e);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bem_log_2(beva_level, bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 189 */ {
bem_out_1(beva_msg);
} /* Line: 190 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_debug_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_2;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_info_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_3;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_warn_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_4;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_error_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_5;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_fatal_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_6;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
bem_out_1(beva_msg);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGet_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public final BEC_2_4_3_MathInt bem_outputLevelGetDirect_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_outputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGet_0() throws Throwable {
return bevp_level;
} /*method end*/
public final BEC_2_4_3_MathInt bem_levelGetDirect_0() throws Throwable {
return bevp_level;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_levelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGet_0() throws Throwable {
return bevp_sink;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_sinkGetDirect_0() throws Throwable {
return bevp_sink;
} /*method end*/
public BEC_2_2_3_IOLog bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sink = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_sinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sink = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {139, 140, 141, 146, 146, 147, 147, 149, 149, 153, 153, 154, 154, 156, 156, 160, 160, 161, 163, 163, 164, 166, 171, 171, 175, 175, 175, 175, 175, 175, 179, 179, 180, 185, 185, 185, 185, 185, 185, 189, 189, 190, 195, 196, 200, 201, 205, 206, 210, 211, 215, 216, 220, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 35, 40, 41, 42, 44, 45, 51, 56, 57, 58, 60, 61, 66, 71, 72, 74, 79, 80, 83, 89, 90, 99, 100, 101, 102, 103, 104, 109, 114, 115, 125, 126, 127, 128, 129, 130, 135, 140, 141, 147, 148, 153, 154, 159, 160, 165, 166, 171, 172, 176, 180, 183, 186, 190, 194, 197, 200, 204, 208, 211, 214, 218};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 139 26
assign 1 140 27
assign 1 141 28
assign 1 146 35
lesserEquals 1 146 40
assign 1 147 41
new 0 147 41
return 1 147 42
assign 1 149 44
new 0 149 44
return 1 149 45
assign 1 153 51
lesserEquals 1 153 56
assign 1 154 57
new 0 154 57
return 1 154 58
assign 1 156 60
new 0 156 60
return 1 156 61
assign 1 160 66
undef 1 160 71
assign 1 161 72
new 0 161 72
assign 1 163 74
def 1 163 79
out 1 164 80
print 0 166 83
assign 1 171 89
new 0 171 89
elog 2 171 90
assign 1 175 99
new 0 175 99
assign 1 175 100
add 1 175 100
assign 1 175 101
new 0 175 101
assign 1 175 102
tS 1 175 102
assign 1 175 103
add 1 175 103
log 1 175 104
assign 1 179 109
lesserEquals 1 179 114
out 1 180 115
assign 1 185 125
new 0 185 125
assign 1 185 126
add 1 185 126
assign 1 185 127
new 0 185 127
assign 1 185 128
tS 1 185 128
assign 1 185 129
add 1 185 129
log 2 185 130
assign 1 189 135
lesserEquals 1 189 140
out 1 190 141
assign 1 195 147
new 0 195 147
log 2 196 148
assign 1 200 153
new 0 200 153
log 2 201 154
assign 1 205 159
new 0 205 159
log 2 206 160
assign 1 210 165
new 0 210 165
log 2 211 166
assign 1 215 171
new 0 215 171
log 2 216 172
out 1 220 176
return 1 0 180
return 1 0 183
assign 1 0 186
assign 1 0 190
return 1 0 194
return 1 0 197
assign 1 0 200
assign 1 0 204
return 1 0 208
return 1 0 211
assign 1 0 214
assign 1 0 218
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1515347213: return bem_hashGet_0();
case 507602572: return bem_once_0();
case 329161204: return bem_sinkGet_0();
case 631342118: return bem_deserializeClassNameGet_0();
case -862155694: return bem_copy_0();
case -1370019545: return bem_serializeToString_0();
case 127818010: return bem_sinkGetDirect_0();
case -647428547: return bem_fieldIteratorGet_0();
case 1379664484: return bem_toAny_0();
case -688295882: return bem_tagGet_0();
case 1785279934: return bem_outputLevelGetDirect_0();
case -1814630541: return bem_classNameGet_0();
case -476664273: return bem_will_0();
case 562477328: return bem_serializationIteratorGet_0();
case 1044270443: return bem_levelGet_0();
case -2024176085: return bem_levelGetDirect_0();
case 886168102: return bem_many_0();
case 899271096: return bem_new_0();
case -542639344: return bem_toString_0();
case 1884909798: return bem_create_0();
case -1906660880: return bem_print_0();
case 1410376238: return bem_outputLevelGet_0();
case -973290132: return bem_iteratorGet_0();
case 1688744619: return bem_serializeContents_0();
case -1067099981: return bem_fieldNamesGet_0();
case -21012660: return bem_sourceFileNameGet_0();
case -1648627766: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2120701530: return bem_equals_1(bevd_0);
case 1797739059: return bem_outputLevelSet_1(bevd_0);
case -241199401: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1400603721: return bem_fatal_1((BEC_2_4_6_TextString) bevd_0);
case -1715866358: return bem_notEquals_1(bevd_0);
case -924523484: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case -345992202: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 216018244: return bem_copyTo_1(bevd_0);
case -734789597: return bem_undefined_1(bevd_0);
case 1116925492: return bem_sameType_1(bevd_0);
case 1018959795: return bem_levelSetDirect_1(bevd_0);
case 1280914604: return bem_otherClass_1(bevd_0);
case 1744917313: return bem_defined_1(bevd_0);
case 1142143738: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 79696421: return bem_warn_1((BEC_2_4_6_TextString) bevd_0);
case -151124072: return bem_elog_1(bevd_0);
case 321389057: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case -1810367474: return bem_debug_1((BEC_2_4_6_TextString) bevd_0);
case 616312476: return bem_info_1((BEC_2_4_6_TextString) bevd_0);
case 243622729: return bem_sinkSetDirect_1(bevd_0);
case 898034411: return bem_sameClass_1(bevd_0);
case -1598303826: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case 1958742283: return bem_outputLevelSetDirect_1(bevd_0);
case -754522664: return bem_out_1((BEC_2_4_6_TextString) bevd_0);
case 2001300007: return bem_sameObject_1(bevd_0);
case -914794223: return bem_undef_1(bevd_0);
case 1402754792: return bem_def_1(bevd_0);
case 704626299: return bem_levelSet_1(bevd_0);
case 1854750640: return bem_error_1((BEC_2_4_6_TextString) bevd_0);
case 1820085236: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1968914612: return bem_sinkSet_1(bevd_0);
case 1349849963: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1506940745: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2011759429: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -281457536: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1630879145: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -603725496: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 857383044: return bem_elog_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -2028721987: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1784313817: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1485133109: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1684785177: return bem_new_3(bevd_0, bevd_1, bevd_2);
case -691028777: return bem_elog_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_3_IOLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
