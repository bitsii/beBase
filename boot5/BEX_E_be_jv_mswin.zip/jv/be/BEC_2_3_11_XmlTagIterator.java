package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator extends BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_2, 2));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_4, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x21};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_6, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_9, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_9, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_10, 51));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_10, 51));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_12, 35));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_13, 1));
public static BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;

public static BET_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_type;

public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public BEC_2_3_11_XmlTagIterator bem_new_0() throws Throwable {
bevp_started = be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_line = (new BEC_2_4_3_MathInt(1));
bevp_skip = be.BECS_Runtime.boolFalse;
bevp_debug = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) throws Throwable {
bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_restart_0() throws Throwable {
bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_start_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
while (true)
 /* Line: 167 */ {
if (bevl_nxt == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_5_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_0;
bevt_4_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 167 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 167 */
 else  /* Line: 167 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 167 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 168 */
 else  /* Line: 167 */ {
break;
} /* Line: 167 */
} /* Line: 167 */
if (bevl_nxt == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_8_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_1;
bevt_7_tmpany_phold = bevl_nxt.bem_equals_1(bevt_8_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 170 */
 else  /* Line: 170 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 170 */ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 171 */
return this;
} /*method end*/
public BEC_2_3_3_XmlTag bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_3_8_XmlTextNode bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_3_7_XmlComment bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_116_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_tmpany_phold = null;
BEC_2_4_6_TextString bevt_134_tmpany_phold = null;
BEC_2_4_6_TextString bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
if (bevp_started.bevi_bool) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 176 */ {
bem_start_0();
} /* Line: 177 */
bevt_21_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_tmpany_phold.bem_quoteGet_0();
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_tmpany_phold.bem_newlineGet_0();
if (bevp_skip.bevi_bool) /* Line: 182 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-958181001);
bevp_skip = be.BECS_Runtime.boolFalse;
} /* Line: 184 */
 else  /* Line: 185 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 186 */
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 189 */ {
if (bevp_textNode.bevi_bool) /* Line: 189 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
 else  /* Line: 189 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 189 */ {
while (true)
 /* Line: 190 */ {
bevt_25_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_2;
bevt_24_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_25_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 192 */
 else  /* Line: 190 */ {
break;
} /* Line: 190 */
} /* Line: 190 */
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_27_tmpany_phold = bevl_accum.bem_extractString_0();
bevt_26_tmpany_phold = (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_tmpany_phold);
return bevt_26_tmpany_phold;
} /* Line: 196 */
 else  /* Line: 189 */ {
if (bevl_nxt == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_30_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_3;
bevt_29_tmpany_phold = bevl_nxt.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevl_tagName = be.BECS_Runtime.boolTrue;
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolFalse;
bevl_isStart = be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 205 */ {
bevt_32_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_4;
bevt_31_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_32_tmpany_phold);
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 205 */ {
if (bevl_pinstruct.bevi_bool) /* Line: 206 */ {
bevl_instr = be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 208 */ {
if (bevl_instr.bevi_bool) /* Line: 208 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_34_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_5;
bevt_33_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_34_tmpany_phold);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 208 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 208 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_tmpany_phold = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 210 */ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 211 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 213 */
 else  /* Line: 208 */ {
break;
} /* Line: 208 */
} /* Line: 208 */
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_36_tmpany_phold);
bevl_pinstruct = be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 217 */ {
if (bevl_nxt == null) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevt_39_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_6;
bevt_38_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_39_tmpany_phold);
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 217 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 217 */
 else  /* Line: 217 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 217 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 218 */
 else  /* Line: 217 */ {
break;
} /* Line: 217 */
} /* Line: 217 */
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_41_tmpany_phold = bevl_accum.bem_toString_0();
bevt_40_tmpany_phold = (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_tmpany_phold);
return bevt_40_tmpany_phold;
} /* Line: 221 */
if (bevl_comment.bevi_bool) /* Line: 223 */ {
while (true)
 /* Line: 224 */ {
bevt_43_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_7;
bevt_42_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_43_tmpany_phold);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
bevt_45_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_8;
bevt_44_tmpany_phold = bevl_nxt.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevt_48_tmpany_phold = bevl_accum.bem_toString_0();
bevt_49_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_9;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_ends_1(bevt_49_tmpany_phold);
if (bevt_47_tmpany_phold.bevi_bool) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
 else  /* Line: 227 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 227 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 229 */
} /* Line: 227 */
 else  /* Line: 224 */ {
break;
} /* Line: 224 */
} /* Line: 224 */
bevl_comment = be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 233 */ {
if (bevl_nxt == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_52_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_10;
bevt_51_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_52_tmpany_phold);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 233 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 233 */
 else  /* Line: 233 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 233 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 234 */
 else  /* Line: 233 */ {
break;
} /* Line: 233 */
} /* Line: 233 */
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_53_tmpany_phold);
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_55_tmpany_phold = bevl_accum.bem_extractString_0();
bevt_54_tmpany_phold = (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_tmpany_phold);
return bevt_54_tmpany_phold;
} /* Line: 238 */
if (bevl_tagName.bevi_bool) /* Line: 240 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
while (true)
 /* Line: 242 */ {
bevt_57_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_11;
bevt_56_tmpany_phold = bevl_nxt.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_58_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_59_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 243 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 244 */
 else  /* Line: 242 */ {
break;
} /* Line: 242 */
} /* Line: 242 */
bevt_61_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_12;
bevt_60_tmpany_phold = bevl_nxt.bem_equals_1(bevt_61_tmpany_phold);
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
bevl_accum.bem_extractString_0();
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_5));
bevl_accum.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 251 */
 else  /* Line: 246 */ {
bevt_64_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_13;
bevt_63_tmpany_phold = bevl_nxt.bem_equals_1(bevt_64_tmpany_phold);
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
bevl_accum.bem_extractString_0();
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_7));
bevl_accum.bem_addValue_1(bevt_65_tmpany_phold);
} /* Line: 257 */
 else  /* Line: 258 */ {
bevt_67_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_14;
bevt_66_tmpany_phold = bevl_nxt.bem_equals_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 261 */
while (true)
 /* Line: 263 */ {
bevt_69_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_15;
bevt_68_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_69_tmpany_phold);
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_70_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
 else  /* Line: 263 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_72_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_16;
bevt_71_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
 else  /* Line: 263 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_74_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_17;
bevt_73_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_74_tmpany_phold);
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
 else  /* Line: 263 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 265 */
 else  /* Line: 263 */ {
break;
} /* Line: 263 */
} /* Line: 263 */
bevt_75_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 267 */
bevl_tagName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 269 */ {
bevl_myElement = (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_tmpany_phold);
} /* Line: 272 */
 else  /* Line: 273 */ {
bevl_myEndElement = (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_tmpany_phold);
bevl_myTag = bevl_myEndElement;
} /* Line: 276 */
bevt_79_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_18;
bevt_78_tmpany_phold = bevl_nxt.bem_equals_1(bevt_79_tmpany_phold);
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 278 */ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 280 */ {
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 281 */
} /* Line: 280 */
 else  /* Line: 278 */ {
bevt_81_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_19;
bevt_80_tmpany_phold = bevl_nxt.bem_equals_1(bevt_81_tmpany_phold);
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 283 */ {
if (bevl_isStart.bevi_bool) /* Line: 283 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 283 */
 else  /* Line: 283 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 283 */ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_tmpany_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 286 */
 else  /* Line: 278 */ {
if (bevl_isStart.bevi_bool) /* Line: 287 */ {
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 288 */
 else  /* Line: 289 */ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
} /* Line: 290 */
} /* Line: 278 */
} /* Line: 278 */
} /* Line: 278 */
} /* Line: 246 */
} /* Line: 246 */
if (bevl_attributeName.bevi_bool) /* Line: 294 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
while (true)
 /* Line: 296 */ {
bevt_84_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_20;
bevt_83_tmpany_phold = bevl_nxt.bem_equals_1(bevt_84_tmpany_phold);
if (bevt_83_tmpany_phold.bevi_bool) /* Line: 296 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 296 */ {
bevt_85_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_tmpany_phold.bevi_bool) /* Line: 296 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 296 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 296 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 296 */ {
bevt_86_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 297 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 298 */
 else  /* Line: 296 */ {
break;
} /* Line: 296 */
} /* Line: 296 */
while (true)
 /* Line: 300 */ {
bevt_88_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_21;
bevt_87_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_88_tmpany_phold);
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_89_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpany_anchor.bevi_bool) /* Line: 300 */ {
bevt_91_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_22;
bevt_90_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_91_tmpany_phold);
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpany_anchor.bevi_bool) /* Line: 300 */ {
bevt_93_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_23;
bevt_92_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_93_tmpany_phold);
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpany_anchor.bevi_bool) /* Line: 300 */ {
bevt_95_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_24;
bevt_94_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_95_tmpany_phold);
if (bevt_94_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 300 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 302 */
 else  /* Line: 300 */ {
break;
} /* Line: 300 */
} /* Line: 300 */
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_96_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 305 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 305 */
bevt_98_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_25;
bevt_97_tmpany_phold = bevl_nxt.bem_equals_1(bevt_98_tmpany_phold);
if (bevt_97_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 308 */
 else  /* Line: 306 */ {
bevt_100_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_26;
bevt_99_tmpany_phold = bevl_nxt.bem_equals_1(bevt_100_tmpany_phold);
if (bevt_99_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_tmpany_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 312 */
 else  /* Line: 313 */ {
bevt_102_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_tmpany_phold);
bevl_attributeValue = be.BECS_Runtime.boolTrue;
} /* Line: 315 */
} /* Line: 306 */
} /* Line: 306 */
if (bevl_attributeValue.bevi_bool) /* Line: 318 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
while (true)
 /* Line: 320 */ {
bevt_104_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_27;
bevt_103_tmpany_phold = bevl_nxt.bem_equals_1(bevt_104_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 320 */ {
bevt_105_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 320 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 320 */
if (bevt_16_tmpany_anchor.bevi_bool) /* Line: 320 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 320 */ {
bevt_107_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_28;
bevt_106_tmpany_phold = bevl_nxt.bem_equals_1(bevt_107_tmpany_phold);
if (bevt_106_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 320 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 320 */
if (bevt_15_tmpany_anchor.bevi_bool) /* Line: 320 */ {
bevt_108_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 322 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 323 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
bevt_109_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_112_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_29;
bevt_113_tmpany_phold = bevp_line.bem_toString_0();
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_113_tmpany_phold);
bevt_110_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_110_tmpany_phold);
} /* Line: 326 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
while (true)
 /* Line: 329 */ {
bevt_114_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevt_115_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 330 */
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 332 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
bevt_116_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_119_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_30;
bevt_120_tmpany_phold = bevp_line.bem_toString_0();
bevt_118_tmpany_phold = bevt_119_tmpany_phold.bem_add_1(bevt_120_tmpany_phold);
bevt_117_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 335 */
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_121_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_tmpany_phold);
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 339 */
} /* Line: 318 */
 else  /* Line: 205 */ {
break;
} /* Line: 205 */
} /* Line: 205 */
if (bevl_myEndElement == null) {
bevt_122_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_122_tmpany_phold.bevi_bool) /* Line: 342 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 342 */ {
if (bevl_myElement == null) {
bevt_123_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpany_phold.bevi_bool) /* Line: 342 */ {
bevt_124_tmpany_phold = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 342 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 342 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 342 */
 else  /* Line: 342 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 342 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 342 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 342 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 342 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
while (true)
 /* Line: 344 */ {
if (bevl_nxt == null) {
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_125_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_127_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_31;
bevt_126_tmpany_phold = bevl_nxt.bem_equals_1(bevt_127_tmpany_phold);
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_128_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 344 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
 else  /* Line: 344 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 344 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1292021236);
} /* Line: 344 */
 else  /* Line: 344 */ {
break;
} /* Line: 344 */
} /* Line: 344 */
if (bevl_nxt == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_131_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_32;
bevt_130_tmpany_phold = bevl_nxt.bem_equals_1(bevt_131_tmpany_phold);
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 345 */
 else  /* Line: 345 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_19_tmpany_anchor.bevi_bool) /* Line: 345 */ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 345 */
} /* Line: 345 */
} /* Line: 342 */
 else  /* Line: 347 */ {
if (bevl_nxt == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevl_nxt = (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_11));
} /* Line: 348 */
bevt_136_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_33;
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bem_add_1(bevl_nxt);
bevt_137_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_34;
bevt_134_tmpany_phold = bevt_135_tmpany_phold.bem_add_1(bevt_137_tmpany_phold);
bevt_133_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_133_tmpany_phold);
} /* Line: 349 */
} /* Line: 198 */
} /* Line: 189 */
return bevl_myTag;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_started.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 356 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 356 */
bevt_2_tmpany_phold = bevp_iter.bemd_0(606484116);
return (BEC_2_5_4_LogicBool) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_xmlStringGet_0() throws Throwable {
return bevp_xmlString;
} /*method end*/
public final BEC_2_4_6_TextString bem_xmlStringGetDirect_0() throws Throwable {
return bevp_xmlString;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_xmlStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startedGet_0() throws Throwable {
return bevp_started;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_startedGetDirect_0() throws Throwable {
return bevp_started;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_startedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_xtGet_0() throws Throwable {
return bevp_xt;
} /*method end*/
public final BEC_2_3_10_XmlXTokenizer bem_xtGetDirect_0() throws Throwable {
return bevp_xt;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_xtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_resGet_0() throws Throwable {
return bevp_res;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_resGetDirect_0() throws Throwable {
return bevp_res;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_resSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_iterGetDirect_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_textNodeGet_0() throws Throwable {
return bevp_textNode;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_textNodeGetDirect_0() throws Throwable {
return bevp_textNode;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_textNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public final BEC_2_4_3_MathInt bem_lineGetDirect_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_lineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipGet_0() throws Throwable {
return bevp_skip;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_skipGetDirect_0() throws Throwable {
return bevp_skip;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_skipSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_debugGetDirect_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_11_XmlTagIterator bem_debugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {137, 138, 139, 140, 141, 142, 143, 144, 149, 150, 154, 158, 162, 162, 163, 164, 166, 167, 167, 167, 167, 0, 0, 0, 168, 170, 170, 170, 170, 0, 0, 0, 171, 176, 176, 177, 180, 180, 181, 181, 183, 184, 186, 188, 189, 189, 0, 0, 0, 190, 190, 191, 192, 194, 195, 196, 196, 196, 197, 197, 198, 198, 199, 200, 201, 202, 203, 204, 205, 205, 207, 0, 208, 208, 0, 0, 209, 210, 211, 211, 213, 215, 215, 216, 217, 217, 217, 217, 0, 0, 0, 218, 220, 221, 221, 221, 224, 224, 225, 226, 227, 227, 227, 227, 227, 227, 227, 0, 0, 0, 228, 229, 232, 233, 233, 233, 233, 0, 0, 0, 234, 236, 236, 237, 238, 238, 238, 241, 242, 242, 0, 242, 0, 0, 243, 243, 244, 246, 246, 247, 248, 249, 250, 251, 251, 252, 252, 253, 254, 255, 256, 257, 257, 259, 259, 260, 261, 263, 263, 263, 0, 0, 0, 263, 263, 0, 0, 0, 263, 263, 0, 0, 0, 264, 265, 267, 267, 268, 270, 271, 272, 272, 274, 275, 275, 276, 278, 278, 279, 281, 283, 283, 0, 0, 0, 284, 285, 285, 286, 288, 290, 295, 296, 296, 0, 296, 0, 0, 297, 297, 298, 300, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 301, 302, 304, 305, 305, 306, 306, 307, 308, 309, 309, 310, 311, 311, 312, 314, 314, 315, 319, 320, 320, 0, 320, 0, 0, 0, 320, 320, 0, 0, 322, 322, 323, 325, 326, 326, 326, 326, 326, 328, 329, 330, 330, 331, 332, 334, 335, 335, 335, 335, 335, 337, 338, 338, 339, 342, 342, 0, 342, 342, 342, 0, 0, 0, 0, 0, 343, 344, 344, 344, 344, 0, 344, 0, 0, 0, 0, 0, 344, 345, 345, 345, 345, 0, 0, 0, 345, 348, 348, 348, 349, 349, 349, 349, 349, 349, 352, 356, 356, 356, 356, 357, 357, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {70, 71, 72, 73, 74, 75, 76, 77, 81, 82, 86, 90, 103, 104, 105, 106, 107, 110, 115, 116, 117, 119, 122, 126, 129, 135, 140, 141, 142, 144, 147, 151, 154, 311, 316, 317, 319, 320, 321, 322, 324, 325, 328, 330, 331, 336, 338, 341, 345, 350, 351, 353, 354, 360, 361, 362, 363, 364, 367, 372, 373, 374, 376, 377, 378, 379, 380, 381, 384, 385, 388, 392, 395, 396, 398, 401, 405, 406, 408, 413, 414, 420, 421, 422, 425, 430, 431, 432, 434, 437, 441, 444, 450, 451, 452, 453, 458, 459, 461, 462, 463, 464, 466, 467, 468, 469, 474, 475, 478, 482, 485, 486, 493, 496, 501, 502, 503, 505, 508, 512, 515, 521, 522, 523, 524, 525, 526, 529, 532, 533, 535, 538, 540, 543, 547, 549, 551, 557, 558, 560, 561, 562, 563, 564, 565, 568, 569, 571, 572, 573, 574, 575, 576, 579, 580, 582, 583, 587, 588, 590, 592, 595, 599, 602, 603, 605, 608, 612, 615, 616, 618, 621, 625, 628, 629, 635, 637, 639, 641, 642, 643, 644, 647, 648, 649, 650, 652, 653, 655, 657, 661, 662, 665, 668, 672, 675, 676, 677, 678, 682, 685, 693, 696, 697, 699, 702, 704, 707, 711, 713, 715, 723, 724, 726, 728, 731, 735, 738, 739, 741, 744, 748, 751, 752, 754, 757, 761, 764, 765, 767, 770, 774, 777, 778, 784, 785, 787, 789, 790, 792, 793, 796, 797, 799, 800, 801, 802, 805, 806, 807, 812, 815, 816, 818, 821, 823, 826, 830, 833, 834, 836, 839, 843, 845, 847, 853, 855, 856, 857, 858, 859, 861, 864, 866, 868, 870, 871, 877, 879, 880, 881, 882, 883, 885, 886, 887, 888, 895, 900, 901, 904, 909, 910, 912, 915, 919, 922, 925, 929, 932, 937, 938, 939, 941, 944, 946, 949, 953, 956, 960, 963, 969, 974, 975, 976, 978, 981, 985, 988, 993, 998, 999, 1001, 1002, 1003, 1004, 1005, 1006, 1010, 1016, 1021, 1022, 1023, 1025, 1026, 1029, 1032, 1035, 1039, 1043, 1046, 1049, 1053, 1057, 1060, 1063, 1067, 1071, 1074, 1077, 1081, 1085, 1088, 1091, 1095, 1099, 1102, 1105, 1109, 1113, 1116, 1119, 1123, 1127, 1130, 1133, 1137, 1141, 1144, 1147, 1151};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 137 70
new 0 137 70
assign 1 138 71
new 0 138 71
assign 1 139 72
assign 1 140 73
assign 1 141 74
new 0 141 74
assign 1 142 75
new 0 142 75
assign 1 143 76
new 0 143 76
assign 1 144 77
new 0 144 77
new 0 149 81
assign 1 150 82
new 0 154 86
return 1 158 90
assign 1 162 103
tokGet 0 162 103
assign 1 162 104
tokenize 1 162 104
assign 1 163 105
iteratorGet 0 163 105
assign 1 164 106
new 0 164 106
assign 1 166 107
nextGet 0 166 107
assign 1 167 110
def 1 167 115
assign 1 167 116
new 0 167 116
assign 1 167 117
notEquals 1 167 117
assign 1 0 119
assign 1 0 122
assign 1 0 126
assign 1 168 129
nextGet 0 168 129
assign 1 170 135
def 1 170 140
assign 1 170 141
new 0 170 141
assign 1 170 142
equals 1 170 142
assign 1 0 144
assign 1 0 147
assign 1 0 151
assign 1 171 154
new 0 171 154
assign 1 176 311
not 0 176 316
start 0 177 317
assign 1 180 319
new 0 180 319
assign 1 180 320
quoteGet 0 180 320
assign 1 181 321
new 0 181 321
assign 1 181 322
newlineGet 0 181 322
assign 1 183 324
currentGet 0 183 324
assign 1 184 325
new 0 184 325
assign 1 186 328
nextGet 0 186 328
assign 1 188 330
new 0 188 330
assign 1 189 331
def 1 189 336
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 190 350
new 0 190 350
assign 1 190 351
notEquals 1 190 351
addValue 1 191 353
assign 1 192 354
nextGet 0 192 354
assign 1 194 360
new 0 194 360
assign 1 195 361
new 0 195 361
assign 1 196 362
extractString 0 196 362
assign 1 196 363
new 1 196 363
return 1 196 364
assign 1 197 367
def 1 197 372
assign 1 198 373
new 0 198 373
assign 1 198 374
equals 1 198 374
assign 1 199 376
new 0 199 376
assign 1 200 377
new 0 200 377
assign 1 201 378
new 0 201 378
assign 1 202 379
new 0 202 379
assign 1 203 380
new 0 203 380
assign 1 204 381
new 0 204 381
assign 1 205 384
new 0 205 384
assign 1 205 385
notEquals 1 205 385
assign 1 207 388
new 0 207 388
assign 1 0 392
assign 1 208 395
new 0 208 395
assign 1 208 396
notEquals 1 208 396
assign 1 0 398
assign 1 0 401
addValue 1 209 405
assign 1 210 406
equals 1 210 406
assign 1 211 408
not 0 211 413
assign 1 213 414
nextGet 0 213 414
assign 1 215 420
new 0 215 420
addValue 1 215 421
assign 1 216 422
new 0 216 422
assign 1 217 425
def 1 217 430
assign 1 217 431
new 0 217 431
assign 1 217 432
notEquals 1 217 432
assign 1 0 434
assign 1 0 437
assign 1 0 441
assign 1 218 444
nextGet 0 218 444
assign 1 220 450
new 0 220 450
assign 1 221 451
toString 0 221 451
assign 1 221 452
new 1 221 452
return 1 221 453
assign 1 224 458
new 0 224 458
assign 1 224 459
notEquals 1 224 459
addValue 1 225 461
assign 1 226 462
nextGet 0 226 462
assign 1 227 463
new 0 227 463
assign 1 227 464
equals 1 227 464
assign 1 227 466
toString 0 227 466
assign 1 227 467
new 0 227 467
assign 1 227 468
ends 1 227 468
assign 1 227 469
not 0 227 474
assign 1 0 475
assign 1 0 478
assign 1 0 482
addValue 1 228 485
assign 1 229 486
nextGet 0 229 486
assign 1 232 493
new 0 232 493
assign 1 233 496
def 1 233 501
assign 1 233 502
new 0 233 502
assign 1 233 503
notEquals 1 233 503
assign 1 0 505
assign 1 0 508
assign 1 0 512
assign 1 234 515
nextGet 0 234 515
assign 1 236 521
new 0 236 521
addValue 1 236 522
assign 1 237 523
new 0 237 523
assign 1 238 524
extractString 0 238 524
assign 1 238 525
new 1 238 525
return 1 238 526
assign 1 241 529
nextGet 0 241 529
assign 1 242 532
new 0 242 532
assign 1 242 533
equals 1 242 533
assign 1 0 535
assign 1 242 538
equals 1 242 538
assign 1 0 540
assign 1 0 543
assign 1 243 547
equals 1 243 547
assign 1 243 549
increment 0 243 549
assign 1 244 551
nextGet 0 244 551
assign 1 246 557
new 0 246 557
assign 1 246 558
equals 1 246 558
assign 1 247 560
new 0 247 560
assign 1 248 561
new 0 248 561
assign 1 249 562
nextGet 0 249 562
extractString 0 250 563
assign 1 251 564
new 0 251 564
addValue 1 251 565
assign 1 252 568
new 0 252 568
assign 1 252 569
equals 1 252 569
assign 1 253 571
new 0 253 571
assign 1 254 572
new 0 254 572
assign 1 255 573
nextGet 0 255 573
extractString 0 256 574
assign 1 257 575
new 0 257 575
addValue 1 257 576
assign 1 259 579
new 0 259 579
assign 1 259 580
equals 1 259 580
assign 1 260 582
new 0 260 582
assign 1 261 583
nextGet 0 261 583
assign 1 263 587
new 0 263 587
assign 1 263 588
notEquals 1 263 588
assign 1 263 590
notEquals 1 263 590
assign 1 0 592
assign 1 0 595
assign 1 0 599
assign 1 263 602
new 0 263 602
assign 1 263 603
notEquals 1 263 603
assign 1 0 605
assign 1 0 608
assign 1 0 612
assign 1 263 615
new 0 263 615
assign 1 263 616
notEquals 1 263 616
assign 1 0 618
assign 1 0 621
assign 1 0 625
addValue 1 264 628
assign 1 265 629
nextGet 0 265 629
assign 1 267 635
equals 1 267 635
assign 1 267 637
increment 0 267 637
assign 1 268 639
new 0 268 639
assign 1 270 641
new 0 270 641
assign 1 271 642
assign 1 272 643
extractString 0 272 643
nameSet 1 272 644
assign 1 274 647
new 0 274 647
assign 1 275 648
extractString 0 275 648
nameSet 1 275 649
assign 1 276 650
assign 1 278 652
new 0 278 652
assign 1 278 653
equals 1 278 653
assign 1 279 655
new 0 279 655
assign 1 281 657
new 0 281 657
assign 1 283 661
new 0 283 661
assign 1 283 662
equals 1 283 662
assign 1 0 665
assign 1 0 668
assign 1 0 672
assign 1 284 675
new 0 284 675
assign 1 285 676
new 0 285 676
isClosedSet 1 285 677
assign 1 286 678
nextGet 0 286 678
assign 1 288 682
new 0 288 682
assign 1 290 685
new 0 290 685
assign 1 295 693
nextGet 0 295 693
assign 1 296 696
new 0 296 696
assign 1 296 697
equals 1 296 697
assign 1 0 699
assign 1 296 702
equals 1 296 702
assign 1 0 704
assign 1 0 707
assign 1 297 711
equals 1 297 711
assign 1 297 713
increment 0 297 713
assign 1 298 715
nextGet 0 298 715
assign 1 300 723
new 0 300 723
assign 1 300 724
notEquals 1 300 724
assign 1 300 726
notEquals 1 300 726
assign 1 0 728
assign 1 0 731
assign 1 0 735
assign 1 300 738
new 0 300 738
assign 1 300 739
notEquals 1 300 739
assign 1 0 741
assign 1 0 744
assign 1 0 748
assign 1 300 751
new 0 300 751
assign 1 300 752
notEquals 1 300 752
assign 1 0 754
assign 1 0 757
assign 1 0 761
assign 1 300 764
new 0 300 764
assign 1 300 765
notEquals 1 300 765
assign 1 0 767
assign 1 0 770
assign 1 0 774
addValue 1 301 777
assign 1 302 778
nextGet 0 302 778
assign 1 304 784
new 0 304 784
assign 1 305 785
equals 1 305 785
assign 1 305 787
increment 0 305 787
assign 1 306 789
new 0 306 789
assign 1 306 790
equals 1 306 790
assign 1 307 792
new 0 307 792
assign 1 308 793
new 0 308 793
assign 1 309 796
new 0 309 796
assign 1 309 797
equals 1 309 797
assign 1 310 799
new 0 310 799
assign 1 311 800
new 0 311 800
isClosedSet 1 311 801
assign 1 312 802
nextGet 0 312 802
assign 1 314 805
extractString 0 314 805
addAttributeName 1 314 806
assign 1 315 807
new 0 315 807
assign 1 319 812
nextGet 0 319 812
assign 1 320 815
new 0 320 815
assign 1 320 816
equals 1 320 816
assign 1 0 818
assign 1 320 821
equals 1 320 821
assign 1 0 823
assign 1 0 826
assign 1 0 830
assign 1 320 833
new 0 320 833
assign 1 320 834
equals 1 320 834
assign 1 0 836
assign 1 0 839
assign 1 322 843
equals 1 322 843
assign 1 322 845
increment 0 322 845
assign 1 323 847
nextGet 0 323 847
assign 1 325 853
notEquals 1 325 853
assign 1 326 855
new 0 326 855
assign 1 326 856
toString 0 326 856
assign 1 326 857
add 1 326 857
assign 1 326 858
new 1 326 858
throw 1 326 859
assign 1 328 861
nextGet 0 328 861
assign 1 329 864
notEquals 1 329 864
assign 1 330 866
equals 1 330 866
assign 1 330 868
increment 0 330 868
addValue 1 331 870
assign 1 332 871
nextGet 0 332 871
assign 1 334 877
notEquals 1 334 877
assign 1 335 879
new 0 335 879
assign 1 335 880
toString 0 335 880
assign 1 335 881
add 1 335 881
assign 1 335 882
new 1 335 882
throw 1 335 883
assign 1 337 885
new 0 337 885
assign 1 338 886
extractString 0 338 886
addAttributeValue 1 338 887
assign 1 339 888
new 0 339 888
assign 1 342 895
def 1 342 900
assign 1 0 901
assign 1 342 904
def 1 342 909
assign 1 342 910
isClosedGet 0 342 910
assign 1 0 912
assign 1 0 915
assign 1 0 919
assign 1 0 922
assign 1 0 925
assign 1 343 929
nextGet 0 343 929
assign 1 344 932
def 1 344 937
assign 1 344 938
new 0 344 938
assign 1 344 939
equals 1 344 939
assign 1 0 941
assign 1 344 944
equals 1 344 944
assign 1 0 946
assign 1 0 949
assign 1 0 953
assign 1 0 956
assign 1 0 960
assign 1 344 963
nextGet 0 344 963
assign 1 345 969
def 1 345 974
assign 1 345 975
new 0 345 975
assign 1 345 976
equals 1 345 976
assign 1 0 978
assign 1 0 981
assign 1 0 985
assign 1 345 988
new 0 345 988
assign 1 348 993
undef 1 348 998
assign 1 348 999
new 0 348 999
assign 1 349 1001
new 0 349 1001
assign 1 349 1002
add 1 349 1002
assign 1 349 1003
new 0 349 1003
assign 1 349 1004
add 1 349 1004
assign 1 349 1005
new 1 349 1005
throw 1 349 1006
return 1 352 1010
assign 1 356 1016
not 0 356 1021
assign 1 356 1022
new 0 356 1022
return 1 356 1023
assign 1 357 1025
hasNextGet 0 357 1025
return 1 357 1026
return 1 0 1029
return 1 0 1032
assign 1 0 1035
assign 1 0 1039
return 1 0 1043
return 1 0 1046
assign 1 0 1049
assign 1 0 1053
return 1 0 1057
return 1 0 1060
assign 1 0 1063
assign 1 0 1067
return 1 0 1071
return 1 0 1074
assign 1 0 1077
assign 1 0 1081
return 1 0 1085
return 1 0 1088
assign 1 0 1091
assign 1 0 1095
return 1 0 1099
return 1 0 1102
assign 1 0 1105
assign 1 0 1109
return 1 0 1113
return 1 0 1116
assign 1 0 1119
assign 1 0 1123
return 1 0 1127
return 1 0 1130
assign 1 0 1133
assign 1 0 1137
return 1 0 1141
return 1 0 1144
assign 1 0 1147
assign 1 0 1151
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -637662673: return bem_iterGetDirect_0();
case 101762581: return bem_serializeContents_0();
case 219704196: return bem_startedGet_0();
case -1313098664: return bem_toString_0();
case 484635838: return bem_tagGet_0();
case -840959995: return bem_skipGet_0();
case -753430171: return bem_fieldIteratorGet_0();
case -1478273123: return bem_xmlStringGetDirect_0();
case -390148658: return bem_xmlStringGet_0();
case -1966626789: return bem_hashGet_0();
case 1969080256: return bem_once_0();
case 668484700: return bem_lineGetDirect_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case 320622940: return bem_echo_0();
case 606484116: return bem_hasNextGet_0();
case -2005156683: return bem_classNameGet_0();
case 417116336: return bem_xtGetDirect_0();
case 49575500: return bem_debugGetDirect_0();
case -576502505: return bem_create_0();
case -1292021236: return bem_nextGet_0();
case 983736684: return bem_serializationIteratorGet_0();
case 648547564: return bem_lineGet_0();
case -1522610135: return bem_serializeToString_0();
case 1551415145: return bem_toAny_0();
case -357139526: return bem_many_0();
case -2114150799: return bem_skipGetDirect_0();
case 1284064428: return bem_textNodeGet_0();
case 535822132: return bem_resGet_0();
case 2049544359: return bem_start_0();
case -355650918: return bem_startedGetDirect_0();
case -738439163: return bem_copy_0();
case 690609043: return bem_print_0();
case 1415884529: return bem_resGetDirect_0();
case 133600280: return bem_xtGet_0();
case 247075507: return bem_fieldNamesGet_0();
case 837033716: return bem_debugGet_0();
case 2084331281: return bem_new_0();
case 645211302: return bem_iteratorGet_0();
case -1199996866: return bem_textNodeGetDirect_0();
case -890719598: return bem_sourceFileNameGet_0();
case -1556684521: return bem_restart_0();
case -1101565575: return bem_iterGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1154436290: return bem_defined_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case -704292478: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1710277451: return bem_textNodeSet_1(bevd_0);
case 283215796: return bem_debugSet_1(bevd_0);
case 1438875052: return bem_iterSet_1(bevd_0);
case 238408921: return bem_xtSetDirect_1(bevd_0);
case 758604875: return bem_def_1(bevd_0);
case -1864964931: return bem_lineSet_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -670773723: return bem_sameType_1(bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1674653302: return bem_xtSet_1(bevd_0);
case 2059499592: return bem_lineSetDirect_1(bevd_0);
case -49606403: return bem_xmlStringSetDirect_1(bevd_0);
case -559803890: return bem_notEquals_1(bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 155699093: return bem_textNodeSetDirect_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 2259068: return bem_resSetDirect_1(bevd_0);
case -1903601994: return bem_skipSetDirect_1(bevd_0);
case -1140033090: return bem_debugSetDirect_1(bevd_0);
case 1105748403: return bem_xmlStringSet_1(bevd_0);
case -1259324063: return bem_iterSetDirect_1(bevd_0);
case 1892148731: return bem_startedSetDirect_1(bevd_0);
case -1292545299: return bem_skipSet_1(bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case 1058777929: return bem_resSet_1(bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 396346962: return bem_startedSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_11_XmlTagIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_type;
}
}
