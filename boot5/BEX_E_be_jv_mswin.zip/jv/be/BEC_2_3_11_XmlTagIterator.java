package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator extends BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x2D,0x2D};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x20};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x2F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3D};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x3A};
public static BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;

public static BET_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_type;

public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public BEC_2_3_11_XmlTagIterator bem_new_0() throws Throwable {
bevp_started = be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_line = (new BEC_2_4_3_MathInt(1));
bevp_skip = be.BECS_Runtime.boolFalse;
bevp_debug = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) throws Throwable {
bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_restart_0() throws Throwable {
bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_start_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_2_ta_ph = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_ta_ph.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
while (true)
/* Line: 173*/ {
if (bevl_nxt == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_4_ta_ph = bevl_nxt.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 173*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 173*/
 else /* Line: 173*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 173*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 174*/
 else /* Line: 173*/ {
break;
} /* Line: 173*/
} /* Line: 173*/
if (bevl_nxt == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 176*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_7_ta_ph = bevl_nxt.bem_equals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 176*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 176*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 176*/
 else /* Line: 176*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 176*/ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 177*/
return this;
} /*method end*/
public BEC_2_3_3_XmlTag bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_12_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_13_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_14_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_15_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_16_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_17_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_18_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_19_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_4_7_TextStrings bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_3_8_XmlTextNode bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_3_7_XmlComment bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_5_4_LogicBool bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_5_4_LogicBool bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_5_4_LogicBool bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_5_4_LogicBool bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_5_4_LogicBool bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_5_4_LogicBool bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_5_4_LogicBool bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_5_4_LogicBool bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_5_4_LogicBool bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_5_4_LogicBool bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_4_3_MathInt bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_4_6_TextString bevt_118_ta_ph = null;
BEC_2_5_4_LogicBool bevt_119_ta_ph = null;
BEC_2_5_4_LogicBool bevt_120_ta_ph = null;
BEC_2_4_3_MathInt bevt_121_ta_ph = null;
BEC_2_5_4_LogicBool bevt_122_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_123_ta_ph = null;
BEC_2_4_6_TextString bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_4_6_TextString bevt_127_ta_ph = null;
BEC_2_5_4_LogicBool bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_5_4_LogicBool bevt_130_ta_ph = null;
BEC_2_5_4_LogicBool bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_4_6_TextString bevt_133_ta_ph = null;
BEC_2_5_4_LogicBool bevt_134_ta_ph = null;
BEC_2_5_4_LogicBool bevt_135_ta_ph = null;
BEC_2_5_4_LogicBool bevt_136_ta_ph = null;
BEC_2_4_6_TextString bevt_137_ta_ph = null;
BEC_2_5_4_LogicBool bevt_138_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_139_ta_ph = null;
BEC_2_4_6_TextString bevt_140_ta_ph = null;
BEC_2_4_6_TextString bevt_141_ta_ph = null;
BEC_2_4_6_TextString bevt_142_ta_ph = null;
BEC_2_4_6_TextString bevt_143_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 182*/ {
bem_start_0();
} /* Line: 183*/
bevt_21_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_ta_ph.bem_quoteGet_0();
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_ta_ph.bem_newlineGet_0();
if (bevp_skip.bevi_bool)/* Line: 188*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1466068749);
bevp_skip = be.BECS_Runtime.boolFalse;
} /* Line: 190*/
 else /* Line: 191*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 192*/
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 195*/ {
if (bevp_textNode.bevi_bool)/* Line: 195*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 195*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 195*/
 else /* Line: 195*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 195*/ {
while (true)
/* Line: 196*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_24_ta_ph = bevl_nxt.bem_notEquals_1(bevt_25_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 196*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 198*/
 else /* Line: 196*/ {
break;
} /* Line: 196*/
} /* Line: 196*/
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_27_ta_ph = bevl_accum.bem_extractString_0();
bevt_26_ta_ph = (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_ta_ph);
return bevt_26_ta_ph;
} /* Line: 202*/
 else /* Line: 195*/ {
if (bevl_nxt == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 203*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_29_ta_ph = bevl_nxt.bem_equals_1(bevt_30_ta_ph);
if (bevt_29_ta_ph.bevi_bool)/* Line: 204*/ {
bevl_tagName = be.BECS_Runtime.boolTrue;
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolFalse;
bevl_isStart = be.BECS_Runtime.boolTrue;
while (true)
/* Line: 211*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_31_ta_ph = bevl_nxt.bem_notEquals_1(bevt_32_ta_ph);
if (bevt_31_ta_ph.bevi_bool)/* Line: 211*/ {
if (bevl_pinstruct.bevi_bool)/* Line: 212*/ {
bevl_instr = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 214*/ {
if (bevl_instr.bevi_bool)/* Line: 214*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 214*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_33_ta_ph = bevl_nxt.bem_notEquals_1(bevt_34_ta_ph);
if (bevt_33_ta_ph.bevi_bool)/* Line: 214*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 214*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 214*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 214*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_ta_ph = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_ta_ph.bevi_bool)/* Line: 216*/ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 217*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 219*/
 else /* Line: 214*/ {
break;
} /* Line: 214*/
} /* Line: 214*/
bevt_36_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_36_ta_ph);
bevl_pinstruct = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 223*/ {
if (bevl_nxt == null) {
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 223*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_38_ta_ph = bevl_nxt.bem_notEquals_1(bevt_39_ta_ph);
if (bevt_38_ta_ph.bevi_bool)/* Line: 223*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 223*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 223*/
 else /* Line: 223*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 223*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 224*/
 else /* Line: 223*/ {
break;
} /* Line: 223*/
} /* Line: 223*/
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_41_ta_ph = bevl_accum.bem_toString_0();
bevt_40_ta_ph = (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_ta_ph);
return bevt_40_ta_ph;
} /* Line: 227*/
if (bevl_comment.bevi_bool)/* Line: 229*/ {
while (true)
/* Line: 230*/ {
bevt_43_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_42_ta_ph = bevl_nxt.bem_notEquals_1(bevt_43_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 230*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_44_ta_ph = bevl_nxt.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_48_ta_ph = bevl_accum.bem_toString_0();
bevt_49_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_2));
bevt_47_ta_ph = bevt_48_ta_ph.bem_ends_1(bevt_49_ta_ph);
if (bevt_47_ta_ph.bevi_bool) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 233*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 233*/
 else /* Line: 233*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 233*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 235*/
} /* Line: 233*/
 else /* Line: 230*/ {
break;
} /* Line: 230*/
} /* Line: 230*/
bevl_comment = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 239*/ {
if (bevl_nxt == null) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_51_ta_ph = bevl_nxt.bem_notEquals_1(bevt_52_ta_ph);
if (bevt_51_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 239*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 239*/
 else /* Line: 239*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 239*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 240*/
 else /* Line: 239*/ {
break;
} /* Line: 239*/
} /* Line: 239*/
bevt_53_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_53_ta_ph);
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_55_ta_ph = bevl_accum.bem_extractString_0();
bevt_54_ta_ph = (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_ta_ph);
return bevt_54_ta_ph;
} /* Line: 244*/
if (bevl_tagName.bevi_bool)/* Line: 246*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
while (true)
/* Line: 248*/ {
bevt_57_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_56_ta_ph = bevl_nxt.bem_equals_1(bevt_57_ta_ph);
if (bevt_56_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 248*/ {
bevt_58_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 248*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 248*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 248*/ {
bevt_59_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_ta_ph.bevi_bool)/* Line: 249*/ {
bevt_60_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_line = bevp_line.bem_add_1(bevt_60_ta_ph);
} /* Line: 249*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 250*/
 else /* Line: 248*/ {
break;
} /* Line: 248*/
} /* Line: 248*/
bevt_62_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_4));
bevt_61_ta_ph = bevl_nxt.bem_equals_1(bevt_62_ta_ph);
if (bevt_61_ta_ph.bevi_bool)/* Line: 252*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
bevl_accum.bem_extractString_0();
bevt_63_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_5));
bevl_accum.bem_addValue_1(bevt_63_ta_ph);
} /* Line: 257*/
 else /* Line: 252*/ {
bevt_65_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_6));
bevt_64_ta_ph = bevl_nxt.bem_equals_1(bevt_65_ta_ph);
if (bevt_64_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
bevl_accum.bem_extractString_0();
bevt_66_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_7));
bevl_accum.bem_addValue_1(bevt_66_ta_ph);
} /* Line: 263*/
 else /* Line: 264*/ {
bevt_68_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_67_ta_ph = bevl_nxt.bem_equals_1(bevt_68_ta_ph);
if (bevt_67_ta_ph.bevi_bool)/* Line: 265*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 267*/
while (true)
/* Line: 269*/ {
bevt_70_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_69_ta_ph = bevl_nxt.bem_notEquals_1(bevt_70_ta_ph);
if (bevt_69_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_71_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_71_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 269*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 269*/
 else /* Line: 269*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 269*/ {
bevt_73_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_72_ta_ph = bevl_nxt.bem_notEquals_1(bevt_73_ta_ph);
if (bevt_72_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 269*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 269*/
 else /* Line: 269*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 269*/ {
bevt_75_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_74_ta_ph = bevl_nxt.bem_notEquals_1(bevt_75_ta_ph);
if (bevt_74_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 269*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 269*/
 else /* Line: 269*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 269*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 271*/
 else /* Line: 269*/ {
break;
} /* Line: 269*/
} /* Line: 269*/
bevt_76_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_76_ta_ph.bevi_bool)/* Line: 273*/ {
bevt_77_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_line = bevp_line.bem_add_1(bevt_77_ta_ph);
} /* Line: 273*/
bevl_tagName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 275*/ {
bevl_myElement = (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_78_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_78_ta_ph);
} /* Line: 278*/
 else /* Line: 279*/ {
bevl_myEndElement = (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_79_ta_ph = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_79_ta_ph);
bevl_myTag = bevl_myEndElement;
} /* Line: 282*/
bevt_81_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_80_ta_ph = bevl_nxt.bem_equals_1(bevt_81_ta_ph);
if (bevt_80_ta_ph.bevi_bool)/* Line: 284*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 286*/ {
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 287*/
} /* Line: 286*/
 else /* Line: 284*/ {
bevt_83_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_82_ta_ph = bevl_nxt.bem_equals_1(bevt_83_ta_ph);
if (bevt_82_ta_ph.bevi_bool)/* Line: 289*/ {
if (bevl_isStart.bevi_bool)/* Line: 289*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 289*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 289*/
 else /* Line: 289*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 289*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_84_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 292*/
 else /* Line: 284*/ {
if (bevl_isStart.bevi_bool)/* Line: 293*/ {
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 294*/
 else /* Line: 295*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
} /* Line: 296*/
} /* Line: 284*/
} /* Line: 284*/
} /* Line: 284*/
} /* Line: 252*/
} /* Line: 252*/
if (bevl_attributeName.bevi_bool)/* Line: 300*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
while (true)
/* Line: 302*/ {
bevt_86_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_85_ta_ph = bevl_nxt.bem_equals_1(bevt_86_ta_ph);
if (bevt_85_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_87_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_87_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 302*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 302*/ {
bevt_88_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_88_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_89_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_line = bevp_line.bem_add_1(bevt_89_ta_ph);
} /* Line: 303*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 304*/
 else /* Line: 302*/ {
break;
} /* Line: 302*/
} /* Line: 302*/
while (true)
/* Line: 306*/ {
bevt_91_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_90_ta_ph = bevl_nxt.bem_notEquals_1(bevt_91_ta_ph);
if (bevt_90_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_92_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_92_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_14_ta_anchor.bevi_bool)/* Line: 306*/ {
bevt_94_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_93_ta_ph = bevl_nxt.bem_notEquals_1(bevt_94_ta_ph);
if (bevt_93_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_13_ta_anchor.bevi_bool)/* Line: 306*/ {
bevt_96_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_95_ta_ph = bevl_nxt.bem_notEquals_1(bevt_96_ta_ph);
if (bevt_95_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_12_ta_anchor.bevi_bool)/* Line: 306*/ {
bevt_98_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_9));
bevt_97_ta_ph = bevl_nxt.bem_notEquals_1(bevt_98_ta_ph);
if (bevt_97_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_11_ta_anchor.bevi_bool)/* Line: 306*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 308*/
 else /* Line: 306*/ {
break;
} /* Line: 306*/
} /* Line: 306*/
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_99_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_99_ta_ph.bevi_bool)/* Line: 311*/ {
bevt_100_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_line = bevp_line.bem_add_1(bevt_100_ta_ph);
} /* Line: 311*/
bevt_102_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_101_ta_ph = bevl_nxt.bem_equals_1(bevt_102_ta_ph);
if (bevt_101_ta_ph.bevi_bool)/* Line: 312*/ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 314*/
 else /* Line: 312*/ {
bevt_104_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_103_ta_ph = bevl_nxt.bem_equals_1(bevt_104_ta_ph);
if (bevt_103_ta_ph.bevi_bool)/* Line: 315*/ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_105_ta_ph = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_105_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 318*/
 else /* Line: 319*/ {
bevt_106_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_106_ta_ph);
bevl_attributeValue = be.BECS_Runtime.boolTrue;
} /* Line: 321*/
} /* Line: 312*/
} /* Line: 312*/
if (bevl_attributeValue.bevi_bool)/* Line: 324*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
while (true)
/* Line: 326*/ {
bevt_108_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_107_ta_ph = bevl_nxt.bem_equals_1(bevt_108_ta_ph);
if (bevt_107_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 326*/ {
bevt_109_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_109_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 326*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 326*/
if (bevt_16_ta_anchor.bevi_bool)/* Line: 326*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 326*/ {
bevt_111_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_9));
bevt_110_ta_ph = bevl_nxt.bem_equals_1(bevt_111_ta_ph);
if (bevt_110_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 326*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 326*/
if (bevt_15_ta_anchor.bevi_bool)/* Line: 326*/ {
bevt_112_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_112_ta_ph.bevi_bool)/* Line: 328*/ {
bevt_113_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_line = bevp_line.bem_add_1(bevt_113_ta_ph);
} /* Line: 328*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 329*/
 else /* Line: 326*/ {
break;
} /* Line: 326*/
} /* Line: 326*/
bevt_114_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_117_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_3_11_XmlTagIterator_bels_10));
bevt_118_ta_ph = bevp_line.bem_toString_0();
bevt_116_ta_ph = bevt_117_ta_ph.bem_add_1(bevt_118_ta_ph);
bevt_115_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_116_ta_ph);
throw new be.BECS_ThrowBack(bevt_115_ta_ph);
} /* Line: 332*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
while (true)
/* Line: 335*/ {
bevt_119_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_119_ta_ph.bevi_bool)/* Line: 335*/ {
bevt_120_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_120_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_121_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_line = bevp_line.bem_add_1(bevt_121_ta_ph);
} /* Line: 336*/
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 338*/
 else /* Line: 335*/ {
break;
} /* Line: 335*/
} /* Line: 335*/
bevt_122_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_122_ta_ph.bevi_bool)/* Line: 340*/ {
bevt_125_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_3_11_XmlTagIterator_bels_10));
bevt_126_ta_ph = bevp_line.bem_toString_0();
bevt_124_ta_ph = bevt_125_ta_ph.bem_add_1(bevt_126_ta_ph);
bevt_123_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_124_ta_ph);
throw new be.BECS_ThrowBack(bevt_123_ta_ph);
} /* Line: 341*/
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_127_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_127_ta_ph);
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 345*/
} /* Line: 324*/
 else /* Line: 211*/ {
break;
} /* Line: 211*/
} /* Line: 211*/
if (bevl_myEndElement == null) {
bevt_128_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_128_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_128_ta_ph.bevi_bool)/* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 348*/ {
if (bevl_myElement == null) {
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 348*/ {
bevt_130_ta_ph = bevl_myElement.bem_isClosedGet_0();
if (bevt_130_ta_ph.bevi_bool)/* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 348*/
 else /* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 348*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 348*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
while (true)
/* Line: 350*/ {
if (bevl_nxt == null) {
bevt_131_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_131_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_131_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_133_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_132_ta_ph = bevl_nxt.bem_equals_1(bevt_133_ta_ph);
if (bevt_132_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 350*/ {
bevt_134_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_134_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 350*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 350*/
 else /* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 350*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1077024860);
} /* Line: 350*/
 else /* Line: 350*/ {
break;
} /* Line: 350*/
} /* Line: 350*/
if (bevl_nxt == null) {
bevt_135_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_135_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_135_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_137_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_136_ta_ph = bevl_nxt.bem_equals_1(bevt_137_ta_ph);
if (bevt_136_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 351*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 351*/
 else /* Line: 351*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_19_ta_anchor.bevi_bool)/* Line: 351*/ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 351*/
} /* Line: 351*/
} /* Line: 348*/
 else /* Line: 353*/ {
if (bevl_nxt == null) {
bevt_138_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_138_ta_ph.bevi_bool)/* Line: 354*/ {
bevl_nxt = (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_11));
} /* Line: 354*/
bevt_142_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_3_11_XmlTagIterator_bels_12));
bevt_141_ta_ph = bevt_142_ta_ph.bem_add_1(bevl_nxt);
bevt_143_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_13));
bevt_140_ta_ph = bevt_141_ta_ph.bem_add_1(bevt_143_ta_ph);
bevt_139_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_140_ta_ph);
throw new be.BECS_ThrowBack(bevt_139_ta_ph);
} /* Line: 355*/
} /* Line: 204*/
} /* Line: 195*/
return bevl_myTag;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 362*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 362*/
bevt_2_ta_ph = bevp_iter.bemd_0(873159525);
return (BEC_2_5_4_LogicBool) bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_xmlStringGet_0() throws Throwable {
return bevp_xmlString;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startedGet_0() throws Throwable {
return bevp_started;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_xtGet_0() throws Throwable {
return bevp_xt;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_resGet_0() throws Throwable {
return bevp_res;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_iter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_textNodeGet_0() throws Throwable {
return bevp_textNode;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipGet_0() throws Throwable {
return bevp_skip;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {143, 144, 145, 146, 147, 148, 149, 150, 155, 156, 160, 164, 168, 168, 169, 170, 172, 173, 173, 173, 173, 0, 0, 0, 174, 176, 176, 176, 176, 0, 0, 0, 177, 182, 182, 183, 186, 186, 187, 187, 189, 190, 192, 194, 195, 195, 0, 0, 0, 196, 196, 197, 198, 200, 201, 202, 202, 202, 203, 203, 204, 204, 205, 206, 207, 208, 209, 210, 211, 211, 213, 0, 214, 214, 0, 0, 215, 216, 217, 217, 219, 221, 221, 222, 223, 223, 223, 223, 0, 0, 0, 224, 226, 227, 227, 227, 230, 230, 231, 232, 233, 233, 233, 233, 233, 233, 233, 0, 0, 0, 234, 235, 238, 239, 239, 239, 239, 0, 0, 0, 240, 242, 242, 243, 244, 244, 244, 247, 248, 248, 0, 248, 0, 0, 249, 249, 249, 250, 252, 252, 253, 254, 255, 256, 257, 257, 258, 258, 259, 260, 261, 262, 263, 263, 265, 265, 266, 267, 269, 269, 269, 0, 0, 0, 269, 269, 0, 0, 0, 269, 269, 0, 0, 0, 270, 271, 273, 273, 273, 274, 276, 277, 278, 278, 280, 281, 281, 282, 284, 284, 285, 287, 289, 289, 0, 0, 0, 290, 291, 291, 292, 294, 296, 301, 302, 302, 0, 302, 0, 0, 303, 303, 303, 304, 306, 306, 306, 0, 0, 0, 306, 306, 0, 0, 0, 306, 306, 0, 0, 0, 306, 306, 0, 0, 0, 307, 308, 310, 311, 311, 311, 312, 312, 313, 314, 315, 315, 316, 317, 317, 318, 320, 320, 321, 325, 326, 326, 0, 326, 0, 0, 0, 326, 326, 0, 0, 328, 328, 328, 329, 331, 332, 332, 332, 332, 332, 334, 335, 336, 336, 336, 337, 338, 340, 341, 341, 341, 341, 341, 343, 344, 344, 345, 348, 348, 0, 348, 348, 348, 0, 0, 0, 0, 0, 349, 350, 350, 350, 350, 0, 350, 0, 0, 0, 0, 0, 350, 351, 351, 351, 351, 0, 0, 0, 351, 354, 354, 354, 355, 355, 355, 355, 355, 355, 358, 362, 362, 362, 362, 363, 363, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 46, 47, 51, 55, 68, 69, 70, 71, 72, 75, 80, 81, 82, 84, 87, 91, 94, 100, 105, 106, 107, 109, 112, 116, 119, 282, 287, 288, 290, 291, 292, 293, 295, 296, 299, 301, 302, 307, 309, 312, 316, 321, 322, 324, 325, 331, 332, 333, 334, 335, 338, 343, 344, 345, 347, 348, 349, 350, 351, 352, 355, 356, 359, 363, 366, 367, 369, 372, 376, 377, 379, 384, 385, 391, 392, 393, 396, 401, 402, 403, 405, 408, 412, 415, 421, 422, 423, 424, 429, 430, 432, 433, 434, 435, 437, 438, 439, 440, 445, 446, 449, 453, 456, 457, 464, 467, 472, 473, 474, 476, 479, 483, 486, 492, 493, 494, 495, 496, 497, 500, 503, 504, 506, 509, 511, 514, 518, 520, 521, 523, 529, 530, 532, 533, 534, 535, 536, 537, 540, 541, 543, 544, 545, 546, 547, 548, 551, 552, 554, 555, 559, 560, 562, 564, 567, 571, 574, 575, 577, 580, 584, 587, 588, 590, 593, 597, 600, 601, 607, 609, 610, 612, 614, 615, 616, 617, 620, 621, 622, 623, 625, 626, 628, 630, 634, 635, 638, 641, 645, 648, 649, 650, 651, 655, 658, 666, 669, 670, 672, 675, 677, 680, 684, 686, 687, 689, 697, 698, 700, 702, 705, 709, 712, 713, 715, 718, 722, 725, 726, 728, 731, 735, 738, 739, 741, 744, 748, 751, 752, 758, 759, 761, 762, 764, 765, 767, 768, 771, 772, 774, 775, 776, 777, 780, 781, 782, 787, 790, 791, 793, 796, 798, 801, 805, 808, 809, 811, 814, 818, 820, 821, 823, 829, 831, 832, 833, 834, 835, 837, 840, 842, 844, 845, 847, 848, 854, 856, 857, 858, 859, 860, 862, 863, 864, 865, 872, 877, 878, 881, 886, 887, 889, 892, 896, 899, 902, 906, 909, 914, 915, 916, 918, 921, 923, 926, 930, 933, 937, 940, 946, 951, 952, 953, 955, 958, 962, 965, 970, 975, 976, 978, 979, 980, 981, 982, 983, 987, 993, 998, 999, 1000, 1002, 1003, 1006, 1009, 1013, 1016, 1020, 1023, 1027, 1030, 1034, 1037, 1041, 1044, 1048, 1051, 1055, 1058, 1062, 1065};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 143 35
new 0 143 35
assign 1 144 36
new 0 144 36
assign 1 145 37
assign 1 146 38
assign 1 147 39
new 0 147 39
assign 1 148 40
new 0 148 40
assign 1 149 41
new 0 149 41
assign 1 150 42
new 0 150 42
new 0 155 46
assign 1 156 47
new 0 160 51
return 1 164 55
assign 1 168 68
tokGet 0 168 68
assign 1 168 69
tokenize 1 168 69
assign 1 169 70
iteratorGet 0 169 70
assign 1 170 71
new 0 170 71
assign 1 172 72
nextGet 0 172 72
assign 1 173 75
def 1 173 80
assign 1 173 81
new 0 173 81
assign 1 173 82
notEquals 1 173 82
assign 1 0 84
assign 1 0 87
assign 1 0 91
assign 1 174 94
nextGet 0 174 94
assign 1 176 100
def 1 176 105
assign 1 176 106
new 0 176 106
assign 1 176 107
equals 1 176 107
assign 1 0 109
assign 1 0 112
assign 1 0 116
assign 1 177 119
new 0 177 119
assign 1 182 282
not 0 182 287
start 0 183 288
assign 1 186 290
new 0 186 290
assign 1 186 291
quoteGet 0 186 291
assign 1 187 292
new 0 187 292
assign 1 187 293
newlineGet 0 187 293
assign 1 189 295
currentGet 0 189 295
assign 1 190 296
new 0 190 296
assign 1 192 299
nextGet 0 192 299
assign 1 194 301
new 0 194 301
assign 1 195 302
def 1 195 307
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 196 321
new 0 196 321
assign 1 196 322
notEquals 1 196 322
addValue 1 197 324
assign 1 198 325
nextGet 0 198 325
assign 1 200 331
new 0 200 331
assign 1 201 332
new 0 201 332
assign 1 202 333
extractString 0 202 333
assign 1 202 334
new 1 202 334
return 1 202 335
assign 1 203 338
def 1 203 343
assign 1 204 344
new 0 204 344
assign 1 204 345
equals 1 204 345
assign 1 205 347
new 0 205 347
assign 1 206 348
new 0 206 348
assign 1 207 349
new 0 207 349
assign 1 208 350
new 0 208 350
assign 1 209 351
new 0 209 351
assign 1 210 352
new 0 210 352
assign 1 211 355
new 0 211 355
assign 1 211 356
notEquals 1 211 356
assign 1 213 359
new 0 213 359
assign 1 0 363
assign 1 214 366
new 0 214 366
assign 1 214 367
notEquals 1 214 367
assign 1 0 369
assign 1 0 372
addValue 1 215 376
assign 1 216 377
equals 1 216 377
assign 1 217 379
not 0 217 384
assign 1 219 385
nextGet 0 219 385
assign 1 221 391
new 0 221 391
addValue 1 221 392
assign 1 222 393
new 0 222 393
assign 1 223 396
def 1 223 401
assign 1 223 402
new 0 223 402
assign 1 223 403
notEquals 1 223 403
assign 1 0 405
assign 1 0 408
assign 1 0 412
assign 1 224 415
nextGet 0 224 415
assign 1 226 421
new 0 226 421
assign 1 227 422
toString 0 227 422
assign 1 227 423
new 1 227 423
return 1 227 424
assign 1 230 429
new 0 230 429
assign 1 230 430
notEquals 1 230 430
addValue 1 231 432
assign 1 232 433
nextGet 0 232 433
assign 1 233 434
new 0 233 434
assign 1 233 435
equals 1 233 435
assign 1 233 437
toString 0 233 437
assign 1 233 438
new 0 233 438
assign 1 233 439
ends 1 233 439
assign 1 233 440
not 0 233 445
assign 1 0 446
assign 1 0 449
assign 1 0 453
addValue 1 234 456
assign 1 235 457
nextGet 0 235 457
assign 1 238 464
new 0 238 464
assign 1 239 467
def 1 239 472
assign 1 239 473
new 0 239 473
assign 1 239 474
notEquals 1 239 474
assign 1 0 476
assign 1 0 479
assign 1 0 483
assign 1 240 486
nextGet 0 240 486
assign 1 242 492
new 0 242 492
addValue 1 242 493
assign 1 243 494
new 0 243 494
assign 1 244 495
extractString 0 244 495
assign 1 244 496
new 1 244 496
return 1 244 497
assign 1 247 500
nextGet 0 247 500
assign 1 248 503
new 0 248 503
assign 1 248 504
equals 1 248 504
assign 1 0 506
assign 1 248 509
equals 1 248 509
assign 1 0 511
assign 1 0 514
assign 1 249 518
equals 1 249 518
assign 1 249 520
new 0 249 520
assign 1 249 521
add 1 249 521
assign 1 250 523
nextGet 0 250 523
assign 1 252 529
new 0 252 529
assign 1 252 530
equals 1 252 530
assign 1 253 532
new 0 253 532
assign 1 254 533
new 0 254 533
assign 1 255 534
nextGet 0 255 534
extractString 0 256 535
assign 1 257 536
new 0 257 536
addValue 1 257 537
assign 1 258 540
new 0 258 540
assign 1 258 541
equals 1 258 541
assign 1 259 543
new 0 259 543
assign 1 260 544
new 0 260 544
assign 1 261 545
nextGet 0 261 545
extractString 0 262 546
assign 1 263 547
new 0 263 547
addValue 1 263 548
assign 1 265 551
new 0 265 551
assign 1 265 552
equals 1 265 552
assign 1 266 554
new 0 266 554
assign 1 267 555
nextGet 0 267 555
assign 1 269 559
new 0 269 559
assign 1 269 560
notEquals 1 269 560
assign 1 269 562
notEquals 1 269 562
assign 1 0 564
assign 1 0 567
assign 1 0 571
assign 1 269 574
new 0 269 574
assign 1 269 575
notEquals 1 269 575
assign 1 0 577
assign 1 0 580
assign 1 0 584
assign 1 269 587
new 0 269 587
assign 1 269 588
notEquals 1 269 588
assign 1 0 590
assign 1 0 593
assign 1 0 597
addValue 1 270 600
assign 1 271 601
nextGet 0 271 601
assign 1 273 607
equals 1 273 607
assign 1 273 609
new 0 273 609
assign 1 273 610
add 1 273 610
assign 1 274 612
new 0 274 612
assign 1 276 614
new 0 276 614
assign 1 277 615
assign 1 278 616
extractString 0 278 616
nameSet 1 278 617
assign 1 280 620
new 0 280 620
assign 1 281 621
extractString 0 281 621
nameSet 1 281 622
assign 1 282 623
assign 1 284 625
new 0 284 625
assign 1 284 626
equals 1 284 626
assign 1 285 628
new 0 285 628
assign 1 287 630
new 0 287 630
assign 1 289 634
new 0 289 634
assign 1 289 635
equals 1 289 635
assign 1 0 638
assign 1 0 641
assign 1 0 645
assign 1 290 648
new 0 290 648
assign 1 291 649
new 0 291 649
isClosedSet 1 291 650
assign 1 292 651
nextGet 0 292 651
assign 1 294 655
new 0 294 655
assign 1 296 658
new 0 296 658
assign 1 301 666
nextGet 0 301 666
assign 1 302 669
new 0 302 669
assign 1 302 670
equals 1 302 670
assign 1 0 672
assign 1 302 675
equals 1 302 675
assign 1 0 677
assign 1 0 680
assign 1 303 684
equals 1 303 684
assign 1 303 686
new 0 303 686
assign 1 303 687
add 1 303 687
assign 1 304 689
nextGet 0 304 689
assign 1 306 697
new 0 306 697
assign 1 306 698
notEquals 1 306 698
assign 1 306 700
notEquals 1 306 700
assign 1 0 702
assign 1 0 705
assign 1 0 709
assign 1 306 712
new 0 306 712
assign 1 306 713
notEquals 1 306 713
assign 1 0 715
assign 1 0 718
assign 1 0 722
assign 1 306 725
new 0 306 725
assign 1 306 726
notEquals 1 306 726
assign 1 0 728
assign 1 0 731
assign 1 0 735
assign 1 306 738
new 0 306 738
assign 1 306 739
notEquals 1 306 739
assign 1 0 741
assign 1 0 744
assign 1 0 748
addValue 1 307 751
assign 1 308 752
nextGet 0 308 752
assign 1 310 758
new 0 310 758
assign 1 311 759
equals 1 311 759
assign 1 311 761
new 0 311 761
assign 1 311 762
add 1 311 762
assign 1 312 764
new 0 312 764
assign 1 312 765
equals 1 312 765
assign 1 313 767
new 0 313 767
assign 1 314 768
new 0 314 768
assign 1 315 771
new 0 315 771
assign 1 315 772
equals 1 315 772
assign 1 316 774
new 0 316 774
assign 1 317 775
new 0 317 775
isClosedSet 1 317 776
assign 1 318 777
nextGet 0 318 777
assign 1 320 780
extractString 0 320 780
addAttributeName 1 320 781
assign 1 321 782
new 0 321 782
assign 1 325 787
nextGet 0 325 787
assign 1 326 790
new 0 326 790
assign 1 326 791
equals 1 326 791
assign 1 0 793
assign 1 326 796
equals 1 326 796
assign 1 0 798
assign 1 0 801
assign 1 0 805
assign 1 326 808
new 0 326 808
assign 1 326 809
equals 1 326 809
assign 1 0 811
assign 1 0 814
assign 1 328 818
equals 1 328 818
assign 1 328 820
new 0 328 820
assign 1 328 821
add 1 328 821
assign 1 329 823
nextGet 0 329 823
assign 1 331 829
notEquals 1 331 829
assign 1 332 831
new 0 332 831
assign 1 332 832
toString 0 332 832
assign 1 332 833
add 1 332 833
assign 1 332 834
new 1 332 834
throw 1 332 835
assign 1 334 837
nextGet 0 334 837
assign 1 335 840
notEquals 1 335 840
assign 1 336 842
equals 1 336 842
assign 1 336 844
new 0 336 844
assign 1 336 845
add 1 336 845
addValue 1 337 847
assign 1 338 848
nextGet 0 338 848
assign 1 340 854
notEquals 1 340 854
assign 1 341 856
new 0 341 856
assign 1 341 857
toString 0 341 857
assign 1 341 858
add 1 341 858
assign 1 341 859
new 1 341 859
throw 1 341 860
assign 1 343 862
new 0 343 862
assign 1 344 863
extractString 0 344 863
addAttributeValue 1 344 864
assign 1 345 865
new 0 345 865
assign 1 348 872
def 1 348 877
assign 1 0 878
assign 1 348 881
def 1 348 886
assign 1 348 887
isClosedGet 0 348 887
assign 1 0 889
assign 1 0 892
assign 1 0 896
assign 1 0 899
assign 1 0 902
assign 1 349 906
nextGet 0 349 906
assign 1 350 909
def 1 350 914
assign 1 350 915
new 0 350 915
assign 1 350 916
equals 1 350 916
assign 1 0 918
assign 1 350 921
equals 1 350 921
assign 1 0 923
assign 1 0 926
assign 1 0 930
assign 1 0 933
assign 1 0 937
assign 1 350 940
nextGet 0 350 940
assign 1 351 946
def 1 351 951
assign 1 351 952
new 0 351 952
assign 1 351 953
equals 1 351 953
assign 1 0 955
assign 1 0 958
assign 1 0 962
assign 1 351 965
new 0 351 965
assign 1 354 970
undef 1 354 975
assign 1 354 976
new 0 354 976
assign 1 355 978
new 0 355 978
assign 1 355 979
add 1 355 979
assign 1 355 980
new 0 355 980
assign 1 355 981
add 1 355 981
assign 1 355 982
new 1 355 982
throw 1 355 983
return 1 358 987
assign 1 362 993
not 0 362 998
assign 1 362 999
new 0 362 999
return 1 362 1000
assign 1 363 1002
hasNextGet 0 363 1002
return 1 363 1003
return 1 0 1006
assign 1 0 1009
return 1 0 1013
assign 1 0 1016
return 1 0 1020
assign 1 0 1023
return 1 0 1027
assign 1 0 1030
return 1 0 1034
assign 1 0 1037
return 1 0 1041
assign 1 0 1044
return 1 0 1048
assign 1 0 1051
return 1 0 1055
assign 1 0 1058
return 1 0 1062
assign 1 0 1065
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1077482028: return bem_xmlStringGet_0();
case -777617664: return bem_iteratorGet_0();
case -52275850: return bem_debugGet_0();
case -355672893: return bem_hashGet_0();
case 1367427848: return bem_textNodeGet_0();
case 1630760726: return bem_toString_0();
case 1103672703: return bem_print_0();
case -363139345: return bem_startedGet_0();
case 826083187: return bem_restart_0();
case 1753426355: return bem_start_0();
case 1747323281: return bem_lineGet_0();
case -496842367: return bem_new_0();
case 1158203870: return bem_iterGet_0();
case 1100700182: return bem_resGet_0();
case 1077024860: return bem_nextGet_0();
case 1152967006: return bem_copy_0();
case 1439653353: return bem_create_0();
case 1043575652: return bem_xtGet_0();
case 873159525: return bem_hasNextGet_0();
case 594222996: return bem_skipGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1250946597: return bem_print_1(bevd_0);
case 1969130944: return bem_iterSet_1(bevd_0);
case 863284586: return bem_notEquals_1(bevd_0);
case -1368416291: return bem_startedSet_1(bevd_0);
case -1721047471: return bem_def_1(bevd_0);
case 1667912943: return bem_lineSet_1(bevd_0);
case -700356091: return bem_debugSet_1(bevd_0);
case -1918921005: return bem_resSet_1(bevd_0);
case 1591798610: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1258275617: return bem_textNodeSet_1(bevd_0);
case -1581819952: return bem_xtSet_1(bevd_0);
case 445187513: return bem_equals_1(bevd_0);
case -513429869: return bem_skipSet_1(bevd_0);
case -1146923319: return bem_xmlStringSet_1(bevd_0);
case -938105188: return bem_undef_1(bevd_0);
case -587753182: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -558969549: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2056786157: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2082389725: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1197567931: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_11_XmlTagIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_type;
}
}
