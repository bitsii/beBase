package be;
/* IO:File: source/build/Pass6.be */
public final class BEC_3_5_5_5_BuildVisitPass6 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_0 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_1 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_3 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_4 = {0x5F};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_5 = {0x74,0x68,0x69,0x73};
public static BEC_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;

public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_5_4_LogicBool bevl_include = null;
BEC_2_5_4_LogicBool bevl_negate = null;
BEC_2_4_6_TextString bevl_flag = null;
BEC_2_5_4_LogicBool bevl_foundFlag = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_6_6_SystemObject bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_32_ta_ph = null;
BEC_2_5_4_BuildNode bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_41_ta_ph = null;
BEC_2_5_4_BuildNode bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_5_4_BuildEmit bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_5_6_BuildIfEmit bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_76_ta_ph = null;
BEC_2_5_4_LogicBool bevt_77_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_78_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_85_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_86_ta_ph = null;
BEC_2_6_6_SystemObject bevt_87_ta_ph = null;
BEC_2_6_6_SystemObject bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_5_4_LogicBool bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_6_6_SystemObject bevt_96_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_97_ta_ph = null;
BEC_2_5_4_LogicBool bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_5_4_LogicBool bevt_101_ta_ph = null;
BEC_2_5_4_LogicBool bevt_102_ta_ph = null;
BEC_2_6_6_SystemObject bevt_103_ta_ph = null;
BEC_2_6_6_SystemObject bevt_104_ta_ph = null;
BEC_2_4_3_MathInt bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_4_3_MathInt bevt_107_ta_ph = null;
BEC_2_4_3_MathInt bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_6_6_SystemObject bevt_110_ta_ph = null;
BEC_2_6_6_SystemObject bevt_111_ta_ph = null;
BEC_2_6_6_SystemObject bevt_112_ta_ph = null;
BEC_2_6_6_SystemObject bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_6_6_SystemObject bevt_115_ta_ph = null;
BEC_2_6_6_SystemObject bevt_116_ta_ph = null;
BEC_2_4_3_MathInt bevt_117_ta_ph = null;
BEC_2_5_4_BuildNode bevt_118_ta_ph = null;
BEC_2_5_4_LogicBool bevt_119_ta_ph = null;
BEC_2_4_3_MathInt bevt_120_ta_ph = null;
BEC_2_4_3_MathInt bevt_121_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_122_ta_ph = null;
BEC_2_4_3_MathInt bevt_123_ta_ph = null;
BEC_2_4_6_TextString bevt_124_ta_ph = null;
BEC_2_6_6_SystemObject bevt_125_ta_ph = null;
BEC_2_6_6_SystemObject bevt_126_ta_ph = null;
BEC_2_6_6_SystemObject bevt_127_ta_ph = null;
BEC_2_6_6_SystemObject bevt_128_ta_ph = null;
BEC_2_4_3_MathInt bevt_129_ta_ph = null;
BEC_2_6_6_SystemObject bevt_130_ta_ph = null;
BEC_2_6_6_SystemObject bevt_131_ta_ph = null;
BEC_2_4_3_MathInt bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_6_6_SystemObject bevt_134_ta_ph = null;
BEC_2_5_4_LogicBool bevt_135_ta_ph = null;
BEC_2_4_3_MathInt bevt_136_ta_ph = null;
BEC_2_6_6_SystemObject bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
BEC_2_4_3_MathInt bevt_139_ta_ph = null;
BEC_2_6_6_SystemObject bevt_140_ta_ph = null;
BEC_2_6_6_SystemObject bevt_141_ta_ph = null;
BEC_2_4_3_MathInt bevt_142_ta_ph = null;
BEC_2_4_3_MathInt bevt_143_ta_ph = null;
BEC_2_6_6_SystemObject bevt_144_ta_ph = null;
BEC_2_6_6_SystemObject bevt_145_ta_ph = null;
BEC_2_6_6_SystemObject bevt_146_ta_ph = null;
BEC_2_5_4_LogicBool bevt_147_ta_ph = null;
BEC_2_4_3_MathInt bevt_148_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_149_ta_ph = null;
BEC_2_4_6_TextString bevt_150_ta_ph = null;
BEC_2_6_6_SystemObject bevt_151_ta_ph = null;
BEC_2_6_6_SystemObject bevt_152_ta_ph = null;
BEC_2_4_3_MathInt bevt_153_ta_ph = null;
BEC_2_6_6_SystemObject bevt_154_ta_ph = null;
BEC_2_6_6_SystemObject bevt_155_ta_ph = null;
BEC_2_6_6_SystemObject bevt_156_ta_ph = null;
BEC_2_6_6_SystemObject bevt_157_ta_ph = null;
BEC_2_4_6_TextString bevt_158_ta_ph = null;
BEC_2_6_6_SystemObject bevt_159_ta_ph = null;
BEC_2_6_6_SystemObject bevt_160_ta_ph = null;
BEC_2_6_6_SystemObject bevt_161_ta_ph = null;
BEC_2_6_6_SystemObject bevt_162_ta_ph = null;
BEC_2_4_3_MathInt bevt_163_ta_ph = null;
BEC_2_6_6_SystemObject bevt_164_ta_ph = null;
BEC_2_5_4_LogicBool bevt_165_ta_ph = null;
BEC_2_6_6_SystemObject bevt_166_ta_ph = null;
BEC_2_6_6_SystemObject bevt_167_ta_ph = null;
BEC_2_6_6_SystemObject bevt_168_ta_ph = null;
BEC_2_6_6_SystemObject bevt_169_ta_ph = null;
BEC_2_6_6_SystemObject bevt_170_ta_ph = null;
BEC_2_6_6_SystemObject bevt_171_ta_ph = null;
BEC_2_4_6_TextString bevt_172_ta_ph = null;
BEC_2_6_6_SystemObject bevt_173_ta_ph = null;
BEC_2_5_4_LogicBool bevt_174_ta_ph = null;
BEC_2_6_6_SystemObject bevt_175_ta_ph = null;
BEC_2_5_4_LogicBool bevt_176_ta_ph = null;
BEC_2_6_6_SystemObject bevt_177_ta_ph = null;
BEC_2_5_4_LogicBool bevt_178_ta_ph = null;
BEC_2_6_6_SystemObject bevt_179_ta_ph = null;
BEC_2_6_6_SystemObject bevt_180_ta_ph = null;
BEC_2_4_6_TextString bevt_181_ta_ph = null;
BEC_2_6_6_SystemObject bevt_182_ta_ph = null;
BEC_2_6_6_SystemObject bevt_183_ta_ph = null;
BEC_2_6_6_SystemObject bevt_184_ta_ph = null;
BEC_2_6_6_SystemObject bevt_185_ta_ph = null;
BEC_2_4_6_TextString bevt_186_ta_ph = null;
BEC_2_6_6_SystemObject bevt_187_ta_ph = null;
BEC_2_5_4_LogicBool bevt_188_ta_ph = null;
BEC_2_6_6_SystemObject bevt_189_ta_ph = null;
BEC_2_5_4_LogicBool bevt_190_ta_ph = null;
BEC_2_5_3_BuildVar bevt_191_ta_ph = null;
BEC_2_6_6_SystemObject bevt_192_ta_ph = null;
BEC_2_5_4_LogicBool bevt_193_ta_ph = null;
BEC_2_6_6_SystemObject bevt_194_ta_ph = null;
BEC_2_5_4_LogicBool bevt_195_ta_ph = null;
BEC_2_6_6_SystemObject bevt_196_ta_ph = null;
BEC_2_5_4_LogicBool bevt_197_ta_ph = null;
BEC_2_6_6_SystemObject bevt_198_ta_ph = null;
BEC_2_5_4_LogicBool bevt_199_ta_ph = null;
BEC_2_6_6_SystemObject bevt_200_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_201_ta_ph = null;
BEC_2_4_6_TextString bevt_202_ta_ph = null;
BEC_2_6_6_SystemObject bevt_203_ta_ph = null;
BEC_2_6_6_SystemObject bevt_204_ta_ph = null;
BEC_2_6_6_SystemObject bevt_205_ta_ph = null;
BEC_2_6_6_SystemObject bevt_206_ta_ph = null;
BEC_2_6_6_SystemObject bevt_207_ta_ph = null;
BEC_2_5_4_BuildNode bevt_208_ta_ph = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_12_ta_ph = beva_node.bem_typenameGet_0();
bevt_13_ta_ph = bevp_ntypes.bem_EMITGet_0();
if (bevt_12_ta_ph.bevi_int == bevt_13_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 21*/ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_15_ta_ph = beva_node.bem_containedGet_0();
if (bevt_15_ta_ph == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_18_ta_ph = beva_node.bem_containedGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_lengthGet_0();
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_17_ta_ph.bevi_int > bevt_19_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_23_ta_ph = beva_node.bem_containedGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_firstGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(253483747);
if (bevt_21_ta_ph == null) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_28_ta_ph = beva_node.bem_containedGet_0();
bevt_27_ta_ph = bevt_28_ta_ph.bem_firstGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bemd_0(253483747);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(-1974768952);
bevt_29_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(877832351, bevt_29_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_33_ta_ph = beva_node.bem_secondGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bem_containedGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bem_lengthGet_0();
bevt_34_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_31_ta_ph.bevi_int > bevt_34_ta_ph.bevi_int) {
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 23*/ {
bevl_langs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_37_ta_ph = beva_node.bem_containedGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_firstGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bemd_0(253483747);
bevt_0_ta_loop = bevt_35_ta_ph.bemd_0(1883051716);
while (true)
/* Line: 26*/ {
bevt_38_ta_ph = bevt_0_ta_loop.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_38_ta_ph).bevi_bool)/* Line: 26*/ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_ta_loop.bemd_0(-878437304);
bevt_39_ta_ph = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_39_ta_ph);
} /* Line: 28*/
 else /* Line: 26*/ {
break;
} /* Line: 26*/
} /* Line: 26*/
bevt_40_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_40_ta_ph);
bevl_doit = be.BECS_Runtime.boolTrue;
if (((BEC_2_5_4_LogicBool) bevl_doit).bevi_bool)/* Line: 32*/ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_42_ta_ph = beva_node.bem_secondGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bem_containedGet_0();
bevl_i = bevt_41_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 34*/ {
bevt_43_ta_ph = bevl_i.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_43_ta_ph).bevi_bool)/* Line: 34*/ {
bevl_si = bevl_i.bemd_0(-878437304);
bevt_45_ta_ph = bevl_si.bemd_0(1704801396);
bevt_46_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
bevt_44_ta_ph = bevt_45_ta_ph.bemd_1(1412041271, bevt_46_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_44_ta_ph).bevi_bool)/* Line: 36*/ {
bevt_47_ta_ph = bevl_si.bemd_0(718459716);
beva_node.bem_heldSet_1(bevt_47_ta_ph);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 40*/
} /* Line: 36*/
 else /* Line: 34*/ {
break;
} /* Line: 34*/
} /* Line: 34*/
} /* Line: 34*/
bevt_48_ta_ph = bevl_doit.bemd_0(-630880295);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 44*/ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 46*/
beva_node.bem_containedSet_1(null);
bevt_50_ta_ph = beva_node.bem_heldGet_0();
bevt_49_ta_ph = (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_50_ta_ph , bevl_langs);
beva_node.bem_heldSet_1(bevt_49_ta_ph);
} /* Line: 49*/
 else /* Line: 50*/ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 52*/
bevl_snode = beva_node.bem_scopeGet_0();
bevt_52_ta_ph = bevl_snode.bemd_0(1704801396);
bevt_53_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_51_ta_ph = bevt_52_ta_ph.bemd_1(1412041271, bevt_53_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 56*/ {
bevl_snode = null;
} /* Line: 57*/
if (bevl_snode == null) {
bevt_54_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_54_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_54_ta_ph.bevi_bool)/* Line: 60*/ {
beva_node.bem_delete_0();
bevt_55_ta_ph = bevl_snode.bemd_0(718459716);
bevt_55_ta_ph.bemd_1(1323112064, beva_node);
} /* Line: 62*/
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 65*/
 else /* Line: 21*/ {
bevt_57_ta_ph = beva_node.bem_typenameGet_0();
bevt_58_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_57_ta_ph.bevi_int == bevt_58_ta_ph.bevi_int) {
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 66*/ {
bevl_langs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_61_ta_ph = beva_node.bem_containedGet_0();
bevt_60_ta_ph = bevt_61_ta_ph.bem_firstGet_0();
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(253483747);
bevt_1_ta_loop = bevt_59_ta_ph.bemd_0(1883051716);
while (true)
/* Line: 69*/ {
bevt_62_ta_ph = bevt_1_ta_loop.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_62_ta_ph).bevi_bool)/* Line: 69*/ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_ta_loop.bemd_0(-878437304);
bevt_63_ta_ph = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_63_ta_ph);
bevl_toremove.bemd_1(1198774103, bevl_lang);
} /* Line: 72*/
 else /* Line: 69*/ {
break;
} /* Line: 69*/
} /* Line: 69*/
bevt_64_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_64_ta_ph);
bevt_66_ta_ph = beva_node.bem_heldGet_0();
bevt_65_ta_ph = (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_66_ta_ph );
beva_node.bem_heldSet_1(bevt_65_ta_ph);
bevl_ii = bevl_toremove.bemd_0(1883051716);
while (true)
/* Line: 76*/ {
bevt_67_ta_ph = bevl_ii.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_67_ta_ph).bevi_bool)/* Line: 76*/ {
bevl_i = bevl_ii.bemd_0(-878437304);
bevl_i.bemd_0(1078789767);
} /* Line: 78*/
 else /* Line: 76*/ {
break;
} /* Line: 76*/
} /* Line: 76*/
bevl_include = be.BECS_Runtime.boolTrue;
bevt_70_ta_ph = beva_node.bem_heldGet_0();
bevt_69_ta_ph = bevt_70_ta_ph.bemd_0(1703402206);
bevt_71_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_68_ta_ph = bevt_69_ta_ph.bemd_1(1412041271, bevt_71_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_68_ta_ph).bevi_bool)/* Line: 81*/ {
bevl_negate = be.BECS_Runtime.boolTrue;
} /* Line: 82*/
 else /* Line: 83*/ {
bevl_negate = be.BECS_Runtime.boolFalse;
} /* Line: 84*/
if (bevl_negate.bevi_bool)/* Line: 86*/ {
bevt_74_ta_ph = beva_node.bem_heldGet_0();
bevt_73_ta_ph = bevt_74_ta_ph.bemd_0(938134850);
bevt_76_ta_ph = bevp_build.bem_emitLangsGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bem_firstGet_0();
bevt_72_ta_ph = bevt_73_ta_ph.bemd_1(1551979448, bevt_75_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_72_ta_ph).bevi_bool)/* Line: 87*/ {
bevl_include = be.BECS_Runtime.boolFalse;
} /* Line: 88*/
bevt_78_ta_ph = bevp_build.bem_emitFlagsGet_0();
if (bevt_78_ta_ph == null) {
bevt_77_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_77_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_77_ta_ph.bevi_bool)/* Line: 90*/ {
bevt_79_ta_ph = bevp_build.bem_emitFlagsGet_0();
bevt_2_ta_loop = bevt_79_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 91*/ {
bevt_80_ta_ph = bevt_2_ta_loop.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_80_ta_ph).bevi_bool)/* Line: 91*/ {
bevl_flag = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(-878437304);
bevt_83_ta_ph = beva_node.bem_heldGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bemd_0(938134850);
bevt_81_ta_ph = bevt_82_ta_ph.bemd_1(1551979448, bevl_flag);
if (((BEC_2_5_4_LogicBool) bevt_81_ta_ph).bevi_bool)/* Line: 92*/ {
bevl_include = be.BECS_Runtime.boolFalse;
} /* Line: 93*/
} /* Line: 92*/
 else /* Line: 91*/ {
break;
} /* Line: 91*/
} /* Line: 91*/
} /* Line: 91*/
} /* Line: 90*/
 else /* Line: 97*/ {
bevl_foundFlag = be.BECS_Runtime.boolFalse;
bevt_85_ta_ph = bevp_build.bem_emitFlagsGet_0();
if (bevt_85_ta_ph == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_86_ta_ph = bevp_build.bem_emitFlagsGet_0();
bevt_3_ta_loop = bevt_86_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 100*/ {
bevt_87_ta_ph = bevt_3_ta_loop.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_87_ta_ph).bevi_bool)/* Line: 100*/ {
bevl_flag = (BEC_2_4_6_TextString) bevt_3_ta_loop.bemd_0(-878437304);
bevt_90_ta_ph = beva_node.bem_heldGet_0();
bevt_89_ta_ph = bevt_90_ta_ph.bemd_0(938134850);
bevt_88_ta_ph = bevt_89_ta_ph.bemd_1(1551979448, bevl_flag);
if (((BEC_2_5_4_LogicBool) bevt_88_ta_ph).bevi_bool)/* Line: 101*/ {
bevl_foundFlag = be.BECS_Runtime.boolTrue;
} /* Line: 102*/
} /* Line: 101*/
 else /* Line: 100*/ {
break;
} /* Line: 100*/
} /* Line: 100*/
} /* Line: 100*/
if (bevl_foundFlag.bevi_bool) {
bevt_91_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_91_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_91_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_95_ta_ph = beva_node.bem_heldGet_0();
bevt_94_ta_ph = bevt_95_ta_ph.bemd_0(938134850);
bevt_97_ta_ph = bevp_build.bem_emitLangsGet_0();
bevt_96_ta_ph = bevt_97_ta_ph.bem_firstGet_0();
bevt_93_ta_ph = bevt_94_ta_ph.bemd_1(1551979448, bevt_96_ta_ph);
bevt_92_ta_ph = bevt_93_ta_ph.bemd_0(-630880295);
if (((BEC_2_5_4_LogicBool) bevt_92_ta_ph).bevi_bool)/* Line: 106*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 106*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 106*/
 else /* Line: 106*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 106*/ {
bevl_include = be.BECS_Runtime.boolFalse;
} /* Line: 107*/
} /* Line: 106*/
if (!(bevl_include.bevi_bool))/* Line: 110*/ {
beva_node.bem_containedSet_1(null);
} /* Line: 111*/
} /* Line: 110*/
 else /* Line: 21*/ {
bevt_99_ta_ph = beva_node.bem_typenameGet_0();
bevt_100_ta_ph = bevp_ntypes.bem_IFGet_0();
if (bevt_99_ta_ph.bevi_int == bevt_100_ta_ph.bevi_int) {
bevt_98_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_98_ta_ph.bevi_bool)/* Line: 113*/ {
if (bevl_nnode == null) {
bevt_101_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_101_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_101_ta_ph.bevi_bool)/* Line: 114*/ {
bevl_lnode = beva_node;
while (true)
/* Line: 116*/ {
if (bevl_nnode == null) {
bevt_102_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_102_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_102_ta_ph.bevi_bool)/* Line: 116*/ {
bevt_104_ta_ph = bevl_nnode.bemd_0(1704801396);
bevt_105_ta_ph = bevp_ntypes.bem_ELIFGet_0();
bevt_103_ta_ph = bevt_104_ta_ph.bemd_1(1412041271, bevt_105_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_103_ta_ph).bevi_bool)/* Line: 116*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 116*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 116*/
 else /* Line: 116*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 116*/ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_106_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2124941201, bevt_106_ta_ph);
bevl_enode.bemd_1(872902220, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(872902220, beva_node);
bevt_107_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2124941201, bevt_107_ta_ph);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(872902220, beva_node);
bevt_108_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-2124941201, bevt_108_ta_ph);
bevl_brnode.bemd_1(1198774103, bevl_inode);
bevl_enode.bemd_1(1198774103, bevl_brnode);
bevt_110_ta_ph = bevl_nnode.bemd_0(253483747);
if (bevt_110_ta_ph == null) {
bevt_109_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_109_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_109_ta_ph.bevi_bool)/* Line: 128*/ {
bevt_111_ta_ph = bevl_nnode.bemd_0(253483747);
bevl_i = bevt_111_ta_ph.bemd_0(1883051716);
while (true)
/* Line: 129*/ {
bevt_112_ta_ph = bevl_i.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_112_ta_ph).bevi_bool)/* Line: 129*/ {
bevt_113_ta_ph = bevl_i.bemd_0(-878437304);
bevl_inode.bemd_1(1198774103, bevt_113_ta_ph);
} /* Line: 130*/
 else /* Line: 129*/ {
break;
} /* Line: 129*/
} /* Line: 129*/
} /* Line: 129*/
bevl_lnode.bemd_1(1198774103, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(-843316803);
bevl_nnode.bemd_0(1078789767);
bevl_nnode = bevl_nxnode;
} /* Line: 141*/
 else /* Line: 116*/ {
break;
} /* Line: 116*/
} /* Line: 116*/
if (bevl_nnode == null) {
bevt_114_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_114_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_114_ta_ph.bevi_bool)/* Line: 143*/ {
bevt_116_ta_ph = bevl_nnode.bemd_0(1704801396);
bevt_117_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevt_115_ta_ph = bevt_116_ta_ph.bemd_1(1412041271, bevt_117_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_115_ta_ph).bevi_bool)/* Line: 143*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 143*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 143*/
 else /* Line: 143*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 143*/ {
bevl_nnode.bemd_0(1078789767);
bevl_lnode.bemd_1(1198774103, bevl_nnode);
} /* Line: 145*/
} /* Line: 143*/
bevt_118_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_118_ta_ph;
} /* Line: 148*/
 else /* Line: 21*/ {
bevt_120_ta_ph = beva_node.bem_typenameGet_0();
bevt_121_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_120_ta_ph.bevi_int == bevt_121_ta_ph.bevi_int) {
bevt_119_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_119_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_119_ta_ph.bevi_bool)/* Line: 149*/ {
bevt_122_ta_ph = beva_node.bem_containedGet_0();
bevl_parens = bevt_122_ta_ph.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(872902220, beva_node);
bevt_123_ta_ph = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(-2124941201, bevt_123_ta_ph);
bevt_124_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevl_nd.bemd_1(1274032581, bevt_124_ta_ph);
bevl_parens.bemd_1(835937782, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_125_ta_ph = bevl_parens.bemd_0(253483747);
bevl_ii = bevt_125_ta_ph.bemd_0(1883051716);
while (true)
/* Line: 158*/ {
bevt_126_ta_ph = bevl_ii.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_126_ta_ph).bevi_bool)/* Line: 158*/ {
bevl_i = bevl_ii.bemd_0(-878437304);
bevl_ix = bevl_i.bemd_0(-843316803);
bevt_128_ta_ph = bevl_i.bemd_0(1704801396);
bevt_129_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_127_ta_ph = bevt_128_ta_ph.bemd_1(1412041271, bevt_129_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_127_ta_ph).bevi_bool)/* Line: 163*/ {
bevl_toremove.bemd_1(1198774103, bevl_i);
} /* Line: 164*/
 else /* Line: 163*/ {
bevt_131_ta_ph = bevl_i.bemd_0(1704801396);
bevt_132_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_130_ta_ph = bevt_131_ta_ph.bemd_1(1412041271, bevt_132_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_130_ta_ph).bevi_bool)/* Line: 165*/ {
bevt_133_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(-1378144132, bevt_133_ta_ph);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_134_ta_ph = bevl_i.bemd_0(718459716);
bevl_v.bemd_1(5224370, bevt_134_ta_ph);
bevt_135_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(441041855, bevt_135_ta_ph);
bevl_i.bemd_1(1274032581, bevl_v);
bevt_136_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(-2124941201, bevt_136_ta_ph);
bevl_i.bemd_0(1777615547);
} /* Line: 172*/
 else /* Line: 163*/ {
bevt_138_ta_ph = bevl_i.bemd_0(1704801396);
bevt_139_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_137_ta_ph = bevt_138_ta_ph.bemd_1(1412041271, bevt_139_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_137_ta_ph).bevi_bool)/* Line: 173*/ {
bevt_141_ta_ph = bevl_ix.bemd_0(1704801396);
bevt_142_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_140_ta_ph = bevt_141_ta_ph.bemd_1(1412041271, bevt_142_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_140_ta_ph).bevi_bool)/* Line: 174*/ {
bevt_143_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(-1378144132, bevt_143_ta_ph);
bevt_144_ta_ph = bevl_i.bemd_0(718459716);
bevt_145_ta_ph = bevl_ix.bemd_0(718459716);
bevt_144_ta_ph.bemd_1(5224370, bevt_145_ta_ph);
bevt_146_ta_ph = bevl_i.bemd_0(718459716);
bevt_147_ta_ph = be.BECS_Runtime.boolTrue;
bevt_146_ta_ph.bemd_1(441041855, bevt_147_ta_ph);
bevl_i.bemd_0(1777615547);
bevt_148_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(-2124941201, bevt_148_ta_ph);
} /* Line: 179*/
 else /* Line: 180*/ {
bevt_150_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_3_5_5_5_BuildVisitPass6_bels_3));
bevt_149_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_150_ta_ph, bevl_i);
throw new be.BECS_ThrowBack(bevt_149_ta_ph);
} /* Line: 181*/
} /* Line: 174*/
} /* Line: 163*/
} /* Line: 163*/
} /* Line: 163*/
 else /* Line: 158*/ {
break;
} /* Line: 158*/
} /* Line: 158*/
bevl_ii = bevl_toremove.bemd_0(1883051716);
while (true)
/* Line: 185*/ {
bevt_151_ta_ph = bevl_ii.bemd_0(-1844273282);
if (((BEC_2_5_4_LogicBool) bevt_151_ta_ph).bevi_bool)/* Line: 185*/ {
bevl_i = bevl_ii.bemd_0(-878437304);
bevl_i.bemd_0(1078789767);
} /* Line: 187*/
 else /* Line: 185*/ {
break;
} /* Line: 185*/
} /* Line: 185*/
bevl_s = beva_node.bem_heldGet_0();
bevt_153_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_152_ta_ph = bevl_numargs.bemd_1(1784381924, bevt_153_ta_ph);
bevl_s.bemd_1(-1415085159, bevt_152_ta_ph);
bevt_154_ta_ph = bevl_s.bemd_0(734887695);
bevl_s.bemd_1(-265602468, bevt_154_ta_ph);
bevt_157_ta_ph = bevl_s.bemd_0(734887695);
bevt_158_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_4));
bevt_156_ta_ph = bevt_157_ta_ph.bemd_1(-1378144132, bevt_158_ta_ph);
bevt_160_ta_ph = bevl_s.bemd_0(848157541);
bevt_159_ta_ph = bevt_160_ta_ph.bemd_0(1636456239);
bevt_155_ta_ph = bevt_156_ta_ph.bemd_1(-1378144132, bevt_159_ta_ph);
bevl_s.bemd_1(5224370, bevt_155_ta_ph);
bevl_i = beva_node.bem_secondGet_0();
bevt_162_ta_ph = bevl_i.bemd_0(1704801396);
bevt_163_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_161_ta_ph = bevt_162_ta_ph.bemd_1(1412041271, bevt_163_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_161_ta_ph).bevi_bool)/* Line: 194*/ {
bevl_i.bemd_0(-1586567310);
bevt_164_ta_ph = bevl_i.bemd_0(718459716);
bevl_s.bemd_1(-1370779945, bevt_164_ta_ph);
bevt_167_ta_ph = bevl_s.bemd_0(497263561);
bevt_166_ta_ph = bevt_167_ta_ph.bemd_0(-1081051571);
if (bevt_166_ta_ph == null) {
bevt_165_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_165_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_165_ta_ph.bevi_bool)/* Line: 198*/ {
bevl_s.bemd_1(-1370779945, null);
} /* Line: 200*/
 else /* Line: 198*/ {
bevt_171_ta_ph = bevl_s.bemd_0(497263561);
bevt_170_ta_ph = bevt_171_ta_ph.bemd_0(-1081051571);
bevt_169_ta_ph = bevt_170_ta_ph.bemd_0(1636456239);
bevt_172_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_5));
bevt_168_ta_ph = bevt_169_ta_ph.bemd_1(1412041271, bevt_172_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_168_ta_ph).bevi_bool)/* Line: 201*/ {
bevt_173_ta_ph = bevl_s.bemd_0(497263561);
bevt_174_ta_ph = be.BECS_Runtime.boolTrue;
bevt_173_ta_ph.bemd_1(-743702811, bevt_174_ta_ph);
bevt_175_ta_ph = bevl_s.bemd_0(497263561);
bevt_176_ta_ph = be.BECS_Runtime.boolTrue;
bevt_175_ta_ph.bemd_1(2129311825, bevt_176_ta_ph);
bevt_177_ta_ph = bevl_s.bemd_0(497263561);
bevt_178_ta_ph = be.BECS_Runtime.boolTrue;
bevt_177_ta_ph.bemd_1(1256223346, bevt_178_ta_ph);
bevt_180_ta_ph = bevl_s.bemd_0(497263561);
bevt_179_ta_ph = bevt_180_ta_ph.bemd_0(-1081051571);
bevt_181_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevt_179_ta_ph.bemd_1(-772939240, bevt_181_ta_ph);
} /* Line: 206*/
 else /* Line: 198*/ {
bevt_185_ta_ph = bevl_s.bemd_0(497263561);
bevt_184_ta_ph = bevt_185_ta_ph.bemd_0(-1081051571);
bevt_183_ta_ph = bevt_184_ta_ph.bemd_0(1636456239);
bevt_186_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevt_182_ta_ph = bevt_183_ta_ph.bemd_1(1412041271, bevt_186_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_182_ta_ph).bevi_bool)/* Line: 207*/ {
bevt_187_ta_ph = bevl_s.bemd_0(497263561);
bevt_188_ta_ph = be.BECS_Runtime.boolTrue;
bevt_187_ta_ph.bemd_1(-743702811, bevt_188_ta_ph);
bevt_189_ta_ph = bevl_s.bemd_0(497263561);
bevt_190_ta_ph = be.BECS_Runtime.boolTrue;
bevt_189_ta_ph.bemd_1(2129311825, bevt_190_ta_ph);
} /* Line: 209*/
} /* Line: 198*/
} /* Line: 198*/
bevl_i.bemd_0(1078789767);
} /* Line: 211*/
 else /* Line: 212*/ {
bevt_191_ta_ph = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(-1370779945, bevt_191_ta_ph);
bevt_192_ta_ph = bevl_s.bemd_0(497263561);
bevt_193_ta_ph = be.BECS_Runtime.boolTrue;
bevt_192_ta_ph.bemd_1(-743702811, bevt_193_ta_ph);
bevt_194_ta_ph = bevl_s.bemd_0(497263561);
bevt_195_ta_ph = be.BECS_Runtime.boolTrue;
bevt_194_ta_ph.bemd_1(2129311825, bevt_195_ta_ph);
bevt_196_ta_ph = bevl_s.bemd_0(497263561);
bevt_197_ta_ph = be.BECS_Runtime.boolTrue;
bevt_196_ta_ph.bemd_1(1256223346, bevt_197_ta_ph);
bevt_198_ta_ph = bevl_s.bemd_0(497263561);
bevt_199_ta_ph = be.BECS_Runtime.boolTrue;
bevt_198_ta_ph.bemd_1(-2141233511, bevt_199_ta_ph);
bevt_200_ta_ph = bevl_s.bemd_0(497263561);
bevt_202_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevt_201_ta_ph = (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_202_ta_ph);
bevt_200_ta_ph.bemd_1(312681262, bevt_201_ta_ph);
} /* Line: 218*/
bevl_clnode = beva_node.bem_classGet_0();
bevt_204_ta_ph = bevl_clnode.bemd_0(718459716);
bevt_203_ta_ph = bevt_204_ta_ph.bemd_0(2132215960);
bevt_205_ta_ph = bevl_s.bemd_0(734887695);
bevt_203_ta_ph.bemd_2(464368280, bevt_205_ta_ph, beva_node);
bevt_207_ta_ph = bevl_clnode.bemd_0(718459716);
bevt_206_ta_ph = bevt_207_ta_ph.bemd_0(-1340804726);
bevt_206_ta_ph.bemd_1(1198774103, beva_node);
} /* Line: 222*/
} /* Line: 21*/
} /* Line: 21*/
} /* Line: 21*/
bevt_208_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_208_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 20, 21, 21, 21, 21, 22, 23, 23, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 25, 26, 26, 26, 26, 0, 26, 26, 28, 28, 30, 30, 31, 33, 34, 34, 34, 34, 35, 36, 36, 36, 37, 37, 40, 44, 45, 46, 48, 49, 49, 49, 51, 52, 55, 56, 56, 56, 57, 60, 60, 61, 62, 62, 65, 66, 66, 66, 66, 67, 68, 69, 69, 69, 69, 0, 69, 69, 71, 71, 72, 74, 74, 75, 75, 75, 76, 76, 77, 78, 80, 81, 81, 81, 81, 82, 84, 87, 87, 87, 87, 87, 88, 90, 90, 90, 91, 91, 0, 91, 91, 92, 92, 92, 93, 98, 99, 99, 99, 100, 100, 0, 100, 100, 101, 101, 101, 102, 106, 106, 106, 106, 106, 106, 106, 106, 0, 0, 0, 107, 111, 113, 113, 113, 113, 114, 114, 115, 116, 116, 116, 116, 116, 0, 0, 0, 117, 118, 118, 119, 120, 121, 122, 122, 123, 124, 125, 125, 126, 127, 128, 128, 128, 129, 129, 129, 130, 130, 137, 138, 139, 140, 141, 143, 143, 143, 143, 143, 0, 0, 0, 144, 145, 148, 148, 149, 149, 149, 149, 150, 150, 151, 152, 153, 153, 154, 154, 155, 156, 157, 158, 158, 158, 159, 160, 163, 163, 163, 164, 165, 165, 165, 166, 166, 167, 168, 168, 169, 169, 170, 171, 171, 172, 173, 173, 173, 174, 174, 174, 175, 175, 176, 176, 176, 177, 177, 177, 178, 179, 179, 181, 181, 181, 185, 185, 186, 187, 189, 190, 190, 190, 191, 191, 192, 192, 192, 192, 192, 192, 192, 193, 194, 194, 194, 195, 197, 197, 198, 198, 198, 198, 200, 201, 201, 201, 201, 201, 203, 203, 203, 204, 204, 204, 205, 205, 205, 206, 206, 206, 206, 207, 207, 207, 207, 207, 208, 208, 208, 209, 209, 209, 211, 213, 213, 214, 214, 214, 215, 215, 215, 216, 216, 216, 217, 217, 217, 218, 218, 218, 218, 220, 221, 221, 221, 221, 222, 222, 222, 224, 224};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {255, 256, 257, 258, 259, 264, 265, 266, 267, 272, 273, 274, 275, 276, 281, 282, 285, 289, 292, 293, 294, 295, 300, 301, 304, 308, 311, 312, 313, 314, 315, 316, 318, 321, 325, 328, 329, 330, 331, 332, 337, 338, 341, 345, 348, 349, 350, 351, 352, 352, 355, 357, 358, 359, 365, 366, 367, 369, 370, 371, 372, 375, 377, 378, 379, 380, 382, 383, 384, 392, 394, 395, 397, 398, 399, 400, 403, 404, 406, 407, 408, 409, 411, 413, 418, 419, 420, 421, 423, 426, 427, 428, 433, 434, 435, 436, 437, 438, 439, 439, 442, 444, 445, 446, 447, 453, 454, 455, 456, 457, 458, 461, 463, 464, 470, 471, 472, 473, 474, 476, 479, 482, 483, 484, 485, 486, 488, 490, 491, 496, 497, 498, 498, 501, 503, 504, 505, 506, 508, 518, 519, 520, 525, 526, 527, 527, 530, 532, 533, 534, 535, 537, 545, 550, 551, 552, 553, 554, 555, 556, 558, 561, 565, 568, 572, 576, 577, 578, 583, 584, 589, 590, 593, 598, 599, 600, 601, 603, 606, 610, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 633, 634, 635, 638, 640, 641, 648, 649, 650, 651, 652, 658, 663, 664, 665, 666, 668, 671, 675, 678, 679, 682, 683, 686, 687, 688, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 709, 711, 712, 713, 714, 715, 717, 720, 721, 722, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 737, 738, 739, 741, 742, 743, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 758, 759, 760, 770, 773, 775, 776, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 800, 801, 802, 803, 804, 805, 810, 811, 814, 815, 816, 817, 818, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 835, 836, 837, 838, 839, 841, 842, 843, 844, 845, 846, 850, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 872, 873, 874, 875, 876, 877, 878, 879, 884, 885};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
resolveNp 0 17 255
assign 1 20 256
nextPeerGet 0 20 256
assign 1 21 257
typenameGet 0 21 257
assign 1 21 258
EMITGet 0 21 258
assign 1 21 259
equals 1 21 264
assign 1 22 265
nextAscendGet 0 22 265
assign 1 23 266
containedGet 0 23 266
assign 1 23 267
def 1 23 272
assign 1 23 273
containedGet 0 23 273
assign 1 23 274
lengthGet 0 23 274
assign 1 23 275
new 0 23 275
assign 1 23 276
greater 1 23 281
assign 1 0 282
assign 1 0 285
assign 1 0 289
assign 1 23 292
containedGet 0 23 292
assign 1 23 293
firstGet 0 23 293
assign 1 23 294
containedGet 0 23 294
assign 1 23 295
def 1 23 300
assign 1 0 301
assign 1 0 304
assign 1 0 308
assign 1 23 311
containedGet 0 23 311
assign 1 23 312
firstGet 0 23 312
assign 1 23 313
containedGet 0 23 313
assign 1 23 314
lengthGet 0 23 314
assign 1 23 315
new 0 23 315
assign 1 23 316
greater 1 23 316
assign 1 0 318
assign 1 0 321
assign 1 0 325
assign 1 23 328
secondGet 0 23 328
assign 1 23 329
containedGet 0 23 329
assign 1 23 330
lengthGet 0 23 330
assign 1 23 331
new 0 23 331
assign 1 23 332
greater 1 23 337
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 25 348
new 0 25 348
assign 1 26 349
containedGet 0 26 349
assign 1 26 350
firstGet 0 26 350
assign 1 26 351
containedGet 0 26 351
assign 1 26 352
iteratorGet 0 0 352
assign 1 26 355
hasNextGet 0 26 355
assign 1 26 357
nextGet 0 26 357
assign 1 28 358
heldGet 0 28 358
addValue 1 28 359
assign 1 30 365
new 0 30 365
delete 1 30 366
assign 1 31 367
new 0 31 367
assign 1 33 369
new 0 33 369
assign 1 34 370
secondGet 0 34 370
assign 1 34 371
containedGet 0 34 371
assign 1 34 372
iteratorGet 0 34 372
assign 1 34 375
hasNextGet 0 34 375
assign 1 35 377
nextGet 0 35 377
assign 1 36 378
typenameGet 0 36 378
assign 1 36 379
STRINGLGet 0 36 379
assign 1 36 380
equals 1 36 380
assign 1 37 382
heldGet 0 37 382
heldSet 1 37 383
assign 1 40 384
new 0 40 384
assign 1 44 392
not 0 44 392
delete 0 45 394
return 1 46 395
containedSet 1 48 397
assign 1 49 398
heldGet 0 49 398
assign 1 49 399
new 2 49 399
heldSet 1 49 400
delete 0 51 403
return 1 52 404
assign 1 55 406
scopeGet 0 55 406
assign 1 56 407
typenameGet 0 56 407
assign 1 56 408
METHODGet 0 56 408
assign 1 56 409
equals 1 56 409
assign 1 57 411
assign 1 60 413
def 1 60 418
delete 0 61 419
assign 1 62 420
heldGet 0 62 420
addEmit 1 62 421
return 1 65 423
assign 1 66 426
typenameGet 0 66 426
assign 1 66 427
IFEMITGet 0 66 427
assign 1 66 428
equals 1 66 433
assign 1 67 434
new 0 67 434
assign 1 68 435
new 0 68 435
assign 1 69 436
containedGet 0 69 436
assign 1 69 437
firstGet 0 69 437
assign 1 69 438
containedGet 0 69 438
assign 1 69 439
iteratorGet 0 0 439
assign 1 69 442
hasNextGet 0 69 442
assign 1 69 444
nextGet 0 69 444
assign 1 71 445
heldGet 0 71 445
addValue 1 71 446
addValue 1 72 447
assign 1 74 453
new 0 74 453
delete 1 74 454
assign 1 75 455
heldGet 0 75 455
assign 1 75 456
new 2 75 456
heldSet 1 75 457
assign 1 76 458
iteratorGet 0 76 458
assign 1 76 461
hasNextGet 0 76 461
assign 1 77 463
nextGet 0 77 463
delete 0 78 464
assign 1 80 470
new 0 80 470
assign 1 81 471
heldGet 0 81 471
assign 1 81 472
valueGet 0 81 472
assign 1 81 473
new 0 81 473
assign 1 81 474
equals 1 81 474
assign 1 82 476
new 0 82 476
assign 1 84 479
new 0 84 479
assign 1 87 482
heldGet 0 87 482
assign 1 87 483
langsGet 0 87 483
assign 1 87 484
emitLangsGet 0 87 484
assign 1 87 485
firstGet 0 87 485
assign 1 87 486
has 1 87 486
assign 1 88 488
new 0 88 488
assign 1 90 490
emitFlagsGet 0 90 490
assign 1 90 491
def 1 90 496
assign 1 91 497
emitFlagsGet 0 91 497
assign 1 91 498
iteratorGet 0 0 498
assign 1 91 501
hasNextGet 0 91 501
assign 1 91 503
nextGet 0 91 503
assign 1 92 504
heldGet 0 92 504
assign 1 92 505
langsGet 0 92 505
assign 1 92 506
has 1 92 506
assign 1 93 508
new 0 93 508
assign 1 98 518
new 0 98 518
assign 1 99 519
emitFlagsGet 0 99 519
assign 1 99 520
def 1 99 525
assign 1 100 526
emitFlagsGet 0 100 526
assign 1 100 527
iteratorGet 0 0 527
assign 1 100 530
hasNextGet 0 100 530
assign 1 100 532
nextGet 0 100 532
assign 1 101 533
heldGet 0 101 533
assign 1 101 534
langsGet 0 101 534
assign 1 101 535
has 1 101 535
assign 1 102 537
new 0 102 537
assign 1 106 545
not 0 106 550
assign 1 106 551
heldGet 0 106 551
assign 1 106 552
langsGet 0 106 552
assign 1 106 553
emitLangsGet 0 106 553
assign 1 106 554
firstGet 0 106 554
assign 1 106 555
has 1 106 555
assign 1 106 556
not 0 106 556
assign 1 0 558
assign 1 0 561
assign 1 0 565
assign 1 107 568
new 0 107 568
containedSet 1 111 572
assign 1 113 576
typenameGet 0 113 576
assign 1 113 577
IFGet 0 113 577
assign 1 113 578
equals 1 113 583
assign 1 114 584
def 1 114 589
assign 1 115 590
assign 1 116 593
def 1 116 598
assign 1 116 599
typenameGet 0 116 599
assign 1 116 600
ELIFGet 0 116 600
assign 1 116 601
equals 1 116 601
assign 1 0 603
assign 1 0 606
assign 1 0 610
assign 1 117 613
new 1 117 613
assign 1 118 614
ELSEGet 0 118 614
typenameSet 1 118 615
copyLoc 1 119 616
assign 1 120 617
new 1 120 617
copyLoc 1 121 618
assign 1 122 619
BRACESGet 0 122 619
typenameSet 1 122 620
assign 1 123 621
new 1 123 621
copyLoc 1 124 622
assign 1 125 623
IFGet 0 125 623
typenameSet 1 125 624
addValue 1 126 625
addValue 1 127 626
assign 1 128 627
containedGet 0 128 627
assign 1 128 628
def 1 128 633
assign 1 129 634
containedGet 0 129 634
assign 1 129 635
iteratorGet 0 129 635
assign 1 129 638
hasNextGet 0 129 638
assign 1 130 640
nextGet 0 130 640
addValue 1 130 641
addValue 1 137 648
assign 1 138 649
assign 1 139 650
nextPeerGet 0 139 650
delete 0 140 651
assign 1 141 652
assign 1 143 658
def 1 143 663
assign 1 143 664
typenameGet 0 143 664
assign 1 143 665
ELSEGet 0 143 665
assign 1 143 666
equals 1 143 666
assign 1 0 668
assign 1 0 671
assign 1 0 675
delete 0 144 678
addValue 1 145 679
assign 1 148 682
nextDescendGet 0 148 682
return 1 148 683
assign 1 149 686
typenameGet 0 149 686
assign 1 149 687
METHODGet 0 149 687
assign 1 149 688
equals 1 149 693
assign 1 150 694
containedGet 0 150 694
assign 1 150 695
firstGet 0 150 695
assign 1 151 696
new 1 151 696
copyLoc 1 152 697
assign 1 153 698
IDGet 0 153 698
typenameSet 1 153 699
assign 1 154 700
new 0 154 700
heldSet 1 154 701
prepend 1 155 702
assign 1 156 703
new 0 156 703
assign 1 157 704
new 0 157 704
assign 1 158 705
containedGet 0 158 705
assign 1 158 706
iteratorGet 0 158 706
assign 1 158 709
hasNextGet 0 158 709
assign 1 159 711
nextGet 0 159 711
assign 1 160 712
nextPeerGet 0 160 712
assign 1 163 713
typenameGet 0 163 713
assign 1 163 714
COMMAGet 0 163 714
assign 1 163 715
equals 1 163 715
addValue 1 164 717
assign 1 165 720
typenameGet 0 165 720
assign 1 165 721
IDGet 0 165 721
assign 1 165 722
equals 1 165 722
assign 1 166 724
new 0 166 724
assign 1 166 725
add 1 166 725
assign 1 167 726
new 0 167 726
assign 1 168 727
heldGet 0 168 727
nameSet 1 168 728
assign 1 169 729
new 0 169 729
isArgSet 1 169 730
heldSet 1 170 731
assign 1 171 732
VARGet 0 171 732
typenameSet 1 171 733
addVariable 0 172 734
assign 1 173 737
typenameGet 0 173 737
assign 1 173 738
VARGet 0 173 738
assign 1 173 739
equals 1 173 739
assign 1 174 741
typenameGet 0 174 741
assign 1 174 742
IDGet 0 174 742
assign 1 174 743
equals 1 174 743
assign 1 175 745
new 0 175 745
assign 1 175 746
add 1 175 746
assign 1 176 747
heldGet 0 176 747
assign 1 176 748
heldGet 0 176 748
nameSet 1 176 749
assign 1 177 750
heldGet 0 177 750
assign 1 177 751
new 0 177 751
isArgSet 1 177 752
addVariable 0 178 753
assign 1 179 754
COMMAGet 0 179 754
typenameSet 1 179 755
assign 1 181 758
new 0 181 758
assign 1 181 759
new 2 181 759
throw 1 181 760
assign 1 185 770
iteratorGet 0 185 770
assign 1 185 773
hasNextGet 0 185 773
assign 1 186 775
nextGet 0 186 775
delete 0 187 776
assign 1 189 782
heldGet 0 189 782
assign 1 190 783
new 0 190 783
assign 1 190 784
subtract 1 190 784
numargsSet 1 190 785
assign 1 191 786
nameGet 0 191 786
orgNameSet 1 191 787
assign 1 192 788
nameGet 0 192 788
assign 1 192 789
new 0 192 789
assign 1 192 790
add 1 192 790
assign 1 192 791
numargsGet 0 192 791
assign 1 192 792
toString 0 192 792
assign 1 192 793
add 1 192 793
nameSet 1 192 794
assign 1 193 795
secondGet 0 193 795
assign 1 194 796
typenameGet 0 194 796
assign 1 194 797
VARGet 0 194 797
assign 1 194 798
equals 1 194 798
resolveNp 0 195 800
assign 1 197 801
heldGet 0 197 801
rtypeSet 1 197 802
assign 1 198 803
rtypeGet 0 198 803
assign 1 198 804
namepathGet 0 198 804
assign 1 198 805
undef 1 198 810
rtypeSet 1 200 811
assign 1 201 814
rtypeGet 0 201 814
assign 1 201 815
namepathGet 0 201 815
assign 1 201 816
toString 0 201 816
assign 1 201 817
new 0 201 817
assign 1 201 818
equals 1 201 818
assign 1 203 820
rtypeGet 0 203 820
assign 1 203 821
new 0 203 821
isTypedSet 1 203 822
assign 1 204 823
rtypeGet 0 204 823
assign 1 204 824
new 0 204 824
isSelfSet 1 204 825
assign 1 205 826
rtypeGet 0 205 826
assign 1 205 827
new 0 205 827
isThisSet 1 205 828
assign 1 206 829
rtypeGet 0 206 829
assign 1 206 830
namepathGet 0 206 830
assign 1 206 831
new 0 206 831
pathSet 1 206 832
assign 1 207 835
rtypeGet 0 207 835
assign 1 207 836
namepathGet 0 207 836
assign 1 207 837
toString 0 207 837
assign 1 207 838
new 0 207 838
assign 1 207 839
equals 1 207 839
assign 1 208 841
rtypeGet 0 208 841
assign 1 208 842
new 0 208 842
isTypedSet 1 208 843
assign 1 209 844
rtypeGet 0 209 844
assign 1 209 845
new 0 209 845
isSelfSet 1 209 846
delete 0 211 850
assign 1 213 853
new 0 213 853
rtypeSet 1 213 854
assign 1 214 855
rtypeGet 0 214 855
assign 1 214 856
new 0 214 856
isTypedSet 1 214 857
assign 1 215 858
rtypeGet 0 215 858
assign 1 215 859
new 0 215 859
isSelfSet 1 215 860
assign 1 216 861
rtypeGet 0 216 861
assign 1 216 862
new 0 216 862
isThisSet 1 216 863
assign 1 217 864
rtypeGet 0 217 864
assign 1 217 865
new 0 217 865
impliedSet 1 217 866
assign 1 218 867
rtypeGet 0 218 867
assign 1 218 868
new 0 218 868
assign 1 218 869
new 1 218 869
namepathSet 1 218 870
assign 1 220 872
classGet 0 220 872
assign 1 221 873
heldGet 0 221 873
assign 1 221 874
methodsGet 0 221 874
assign 1 221 875
nameGet 0 221 875
put 2 221 876
assign 1 222 877
heldGet 0 222 877
assign 1 222 878
orderedMethodsGet 0 222 878
addValue 1 222 879
assign 1 224 884
nextDescendGet 0 224 884
return 1 224 885
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 875234157: return bem_constGet_0();
case -2077115399: return bem_buildGet_0();
case 1636456239: return bem_toString_0();
case 188603276: return bem_hashGet_0();
case -443724522: return bem_new_0();
case 1820870224: return bem_create_0();
case 1883051716: return bem_iteratorGet_0();
case -308273249: return bem_transGet_0();
case -112950834: return bem_print_0();
case -1164945535: return bem_copy_0();
case 1511840414: return bem_ntypesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 983693933: return bem_constSet_1(bevd_0);
case 1412041271: return bem_equals_1(bevd_0);
case -1417803331: return bem_def_1(bevd_0);
case 1741805165: return bem_begin_1(bevd_0);
case -1377528423: return bem_ntypesSet_1(bevd_0);
case 1176467171: return bem_copyTo_1(bevd_0);
case -1325814610: return bem_transSet_1(bevd_0);
case 548963783: return bem_notEquals_1(bevd_0);
case 2136370030: return bem_buildSet_1(bevd_0);
case 840742935: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1673375246: return bem_end_1(bevd_0);
case 1081226855: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1430289246: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1422268862: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -545467895: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1368412142: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass6_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass6_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst = (BEC_3_5_5_5_BuildVisitPass6) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;
}
}
