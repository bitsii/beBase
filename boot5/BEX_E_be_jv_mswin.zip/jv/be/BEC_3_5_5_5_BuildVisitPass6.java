package be;
/* IO:File: source/build/Pass6.be */
public final class BEC_3_5_5_5_BuildVisitPass6 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_0 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_1 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_2 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_3 = {0x5F};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_4 = {0x74,0x68,0x69,0x73};
public static BEC_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;

public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_38_ta_ph = null;
BEC_2_5_4_BuildNode bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_5_4_BuildEmit bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_5_6_BuildIfEmit bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_5_4_LogicBool bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_5_4_LogicBool bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_5_4_BuildNode bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
BEC_2_5_4_LogicBool bevt_102_ta_ph = null;
BEC_2_4_3_MathInt bevt_103_ta_ph = null;
BEC_2_6_6_SystemObject bevt_104_ta_ph = null;
BEC_2_6_6_SystemObject bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_6_6_SystemObject bevt_108_ta_ph = null;
BEC_2_4_3_MathInt bevt_109_ta_ph = null;
BEC_2_4_3_MathInt bevt_110_ta_ph = null;
BEC_2_6_6_SystemObject bevt_111_ta_ph = null;
BEC_2_6_6_SystemObject bevt_112_ta_ph = null;
BEC_2_6_6_SystemObject bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_4_3_MathInt bevt_115_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_6_6_SystemObject bevt_118_ta_ph = null;
BEC_2_6_6_SystemObject bevt_119_ta_ph = null;
BEC_2_4_3_MathInt bevt_120_ta_ph = null;
BEC_2_6_6_SystemObject bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_6_6_SystemObject bevt_123_ta_ph = null;
BEC_2_6_6_SystemObject bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_6_6_SystemObject bevt_126_ta_ph = null;
BEC_2_6_6_SystemObject bevt_127_ta_ph = null;
BEC_2_6_6_SystemObject bevt_128_ta_ph = null;
BEC_2_6_6_SystemObject bevt_129_ta_ph = null;
BEC_2_4_3_MathInt bevt_130_ta_ph = null;
BEC_2_6_6_SystemObject bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_6_6_SystemObject bevt_133_ta_ph = null;
BEC_2_6_6_SystemObject bevt_134_ta_ph = null;
BEC_2_6_6_SystemObject bevt_135_ta_ph = null;
BEC_2_6_6_SystemObject bevt_136_ta_ph = null;
BEC_2_6_6_SystemObject bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
BEC_2_4_6_TextString bevt_139_ta_ph = null;
BEC_2_6_6_SystemObject bevt_140_ta_ph = null;
BEC_2_5_4_LogicBool bevt_141_ta_ph = null;
BEC_2_6_6_SystemObject bevt_142_ta_ph = null;
BEC_2_5_4_LogicBool bevt_143_ta_ph = null;
BEC_2_6_6_SystemObject bevt_144_ta_ph = null;
BEC_2_5_4_LogicBool bevt_145_ta_ph = null;
BEC_2_6_6_SystemObject bevt_146_ta_ph = null;
BEC_2_6_6_SystemObject bevt_147_ta_ph = null;
BEC_2_4_6_TextString bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_6_6_SystemObject bevt_150_ta_ph = null;
BEC_2_6_6_SystemObject bevt_151_ta_ph = null;
BEC_2_6_6_SystemObject bevt_152_ta_ph = null;
BEC_2_4_6_TextString bevt_153_ta_ph = null;
BEC_2_6_6_SystemObject bevt_154_ta_ph = null;
BEC_2_5_4_LogicBool bevt_155_ta_ph = null;
BEC_2_6_6_SystemObject bevt_156_ta_ph = null;
BEC_2_5_4_LogicBool bevt_157_ta_ph = null;
BEC_2_5_3_BuildVar bevt_158_ta_ph = null;
BEC_2_6_6_SystemObject bevt_159_ta_ph = null;
BEC_2_5_4_LogicBool bevt_160_ta_ph = null;
BEC_2_6_6_SystemObject bevt_161_ta_ph = null;
BEC_2_5_4_LogicBool bevt_162_ta_ph = null;
BEC_2_6_6_SystemObject bevt_163_ta_ph = null;
BEC_2_5_4_LogicBool bevt_164_ta_ph = null;
BEC_2_6_6_SystemObject bevt_165_ta_ph = null;
BEC_2_5_4_LogicBool bevt_166_ta_ph = null;
BEC_2_6_6_SystemObject bevt_167_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_168_ta_ph = null;
BEC_2_4_6_TextString bevt_169_ta_ph = null;
BEC_2_6_6_SystemObject bevt_170_ta_ph = null;
BEC_2_6_6_SystemObject bevt_171_ta_ph = null;
BEC_2_6_6_SystemObject bevt_172_ta_ph = null;
BEC_2_6_6_SystemObject bevt_173_ta_ph = null;
BEC_2_6_6_SystemObject bevt_174_ta_ph = null;
BEC_2_5_4_BuildNode bevt_175_ta_ph = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 21*/ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_ta_ph = beva_node.bem_containedGet_0();
if (bevt_12_ta_ph == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_15_ta_ph = beva_node.bem_containedGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_lengthGet_0();
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_14_ta_ph.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_20_ta_ph = beva_node.bem_containedGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_firstGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-726958694);
if (bevt_18_ta_ph == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_25_ta_ph = beva_node.bem_containedGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_firstGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_0(-726958694);
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(1454675032);
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(788359522, bevt_26_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_30_ta_ph = beva_node.bem_secondGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bem_containedGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_lengthGet_0();
bevt_31_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_28_ta_ph.bevi_int > bevt_31_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 23*/ {
bevl_langs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_ta_ph = beva_node.bem_containedGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(-726958694);
bevt_0_ta_loop = bevt_32_ta_ph.bemd_0(455087168);
while (true)
/* Line: 26*/ {
bevt_35_ta_ph = bevt_0_ta_loop.bemd_0(764792202);
if (((BEC_2_5_4_LogicBool) bevt_35_ta_ph).bevi_bool)/* Line: 26*/ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_ta_loop.bemd_0(214487301);
bevt_36_ta_ph = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_ta_ph);
} /* Line: 28*/
 else /* Line: 26*/ {
break;
} /* Line: 26*/
} /* Line: 26*/
bevt_37_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_37_ta_ph);
bevl_doit = be.BECS_Runtime.boolTrue;
if (((BEC_2_5_4_LogicBool) bevl_doit).bevi_bool)/* Line: 32*/ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_39_ta_ph = beva_node.bem_secondGet_0();
bevt_38_ta_ph = bevt_39_ta_ph.bem_containedGet_0();
bevl_i = bevt_38_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 34*/ {
bevt_40_ta_ph = bevl_i.bemd_0(764792202);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 34*/ {
bevl_si = bevl_i.bemd_0(214487301);
bevt_42_ta_ph = bevl_si.bemd_0(281969055);
bevt_43_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(1276638363, bevt_43_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 36*/ {
bevt_44_ta_ph = bevl_si.bemd_0(-1521235777);
beva_node.bem_heldSet_1(bevt_44_ta_ph);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 40*/
} /* Line: 36*/
 else /* Line: 34*/ {
break;
} /* Line: 34*/
} /* Line: 34*/
} /* Line: 34*/
bevt_45_ta_ph = bevl_doit.bemd_0(-1545722674);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 44*/ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 46*/
beva_node.bem_containedSet_1(null);
bevt_47_ta_ph = beva_node.bem_heldGet_0();
bevt_46_ta_ph = (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_ta_ph , bevl_langs);
beva_node.bem_heldSet_1(bevt_46_ta_ph);
} /* Line: 49*/
 else /* Line: 50*/ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 52*/
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_ta_ph = bevl_snode.bemd_0(281969055);
bevt_50_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_48_ta_ph = bevt_49_ta_ph.bemd_1(1276638363, bevt_50_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 56*/ {
bevl_snode = null;
} /* Line: 57*/
if (bevl_snode == null) {
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 60*/ {
beva_node.bem_delete_0();
bevt_52_ta_ph = bevl_snode.bemd_0(-1521235777);
bevt_52_ta_ph.bemd_1(239129687, beva_node);
} /* Line: 62*/
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 65*/
 else /* Line: 21*/ {
bevt_54_ta_ph = beva_node.bem_typenameGet_0();
bevt_55_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_ta_ph.bevi_int == bevt_55_ta_ph.bevi_int) {
bevt_53_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_53_ta_ph.bevi_bool)/* Line: 66*/ {
bevl_langs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_ta_ph = beva_node.bem_containedGet_0();
bevt_57_ta_ph = bevt_58_ta_ph.bem_firstGet_0();
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(-726958694);
bevt_1_ta_loop = bevt_56_ta_ph.bemd_0(455087168);
while (true)
/* Line: 69*/ {
bevt_59_ta_ph = bevt_1_ta_loop.bemd_0(764792202);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 69*/ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_ta_loop.bemd_0(214487301);
bevt_60_ta_ph = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_ta_ph);
bevl_toremove.bemd_1(749348357, bevl_lang);
} /* Line: 72*/
 else /* Line: 69*/ {
break;
} /* Line: 69*/
} /* Line: 69*/
bevt_61_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_61_ta_ph);
bevt_63_ta_ph = beva_node.bem_heldGet_0();
bevt_62_ta_ph = (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_ta_ph );
beva_node.bem_heldSet_1(bevt_62_ta_ph);
bevl_ii = bevl_toremove.bemd_0(455087168);
while (true)
/* Line: 76*/ {
bevt_64_ta_ph = bevl_ii.bemd_0(764792202);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 76*/ {
bevl_i = bevl_ii.bemd_0(214487301);
bevl_i.bemd_0(-1549309530);
} /* Line: 78*/
 else /* Line: 76*/ {
break;
} /* Line: 76*/
} /* Line: 76*/
} /* Line: 76*/
 else /* Line: 21*/ {
bevt_66_ta_ph = beva_node.bem_typenameGet_0();
bevt_67_ta_ph = bevp_ntypes.bem_IFGet_0();
if (bevt_66_ta_ph.bevi_int == bevt_67_ta_ph.bevi_int) {
bevt_65_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_65_ta_ph.bevi_bool)/* Line: 80*/ {
if (bevl_nnode == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 81*/ {
bevl_lnode = beva_node;
while (true)
/* Line: 83*/ {
if (bevl_nnode == null) {
bevt_69_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_69_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_71_ta_ph = bevl_nnode.bemd_0(281969055);
bevt_72_ta_ph = bevp_ntypes.bem_ELIFGet_0();
bevt_70_ta_ph = bevt_71_ta_ph.bemd_1(1276638363, bevt_72_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_70_ta_ph).bevi_bool)/* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 83*/
 else /* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 83*/ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-748618041, bevt_73_ta_ph);
bevl_enode.bemd_1(852524033, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(852524033, beva_node);
bevt_74_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-748618041, bevt_74_ta_ph);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(852524033, beva_node);
bevt_75_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-748618041, bevt_75_ta_ph);
bevl_brnode.bemd_1(749348357, bevl_inode);
bevl_enode.bemd_1(749348357, bevl_brnode);
bevt_77_ta_ph = bevl_nnode.bemd_0(-726958694);
if (bevt_77_ta_ph == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_78_ta_ph = bevl_nnode.bemd_0(-726958694);
bevl_i = bevt_78_ta_ph.bemd_0(455087168);
while (true)
/* Line: 96*/ {
bevt_79_ta_ph = bevl_i.bemd_0(764792202);
if (((BEC_2_5_4_LogicBool) bevt_79_ta_ph).bevi_bool)/* Line: 96*/ {
bevt_80_ta_ph = bevl_i.bemd_0(214487301);
bevl_inode.bemd_1(749348357, bevt_80_ta_ph);
} /* Line: 97*/
 else /* Line: 96*/ {
break;
} /* Line: 96*/
} /* Line: 96*/
} /* Line: 96*/
bevl_lnode.bemd_1(749348357, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(1016967936);
bevl_nnode.bemd_0(-1549309530);
bevl_nnode = bevl_nxnode;
} /* Line: 108*/
 else /* Line: 83*/ {
break;
} /* Line: 83*/
} /* Line: 83*/
if (bevl_nnode == null) {
bevt_81_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_81_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_83_ta_ph = bevl_nnode.bemd_0(281969055);
bevt_84_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bemd_1(1276638363, bevt_84_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 110*/
 else /* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 110*/ {
bevl_nnode.bemd_0(-1549309530);
bevl_lnode.bemd_1(749348357, bevl_nnode);
} /* Line: 112*/
} /* Line: 110*/
bevt_85_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_85_ta_ph;
} /* Line: 115*/
 else /* Line: 21*/ {
bevt_87_ta_ph = beva_node.bem_typenameGet_0();
bevt_88_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_ta_ph.bevi_int == bevt_88_ta_ph.bevi_int) {
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 116*/ {
bevt_89_ta_ph = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_ta_ph.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(852524033, beva_node);
bevt_90_ta_ph = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(-748618041, bevt_90_ta_ph);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevl_nd.bemd_1(729991839, bevt_91_ta_ph);
bevl_parens.bemd_1(-1659691586, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_ta_ph = bevl_parens.bemd_0(-726958694);
bevl_ii = bevt_92_ta_ph.bemd_0(455087168);
while (true)
/* Line: 125*/ {
bevt_93_ta_ph = bevl_ii.bemd_0(764792202);
if (((BEC_2_5_4_LogicBool) bevt_93_ta_ph).bevi_bool)/* Line: 125*/ {
bevl_i = bevl_ii.bemd_0(214487301);
bevl_ix = bevl_i.bemd_0(1016967936);
bevt_95_ta_ph = bevl_i.bemd_0(281969055);
bevt_96_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_94_ta_ph = bevt_95_ta_ph.bemd_1(1276638363, bevt_96_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_94_ta_ph).bevi_bool)/* Line: 130*/ {
bevl_toremove.bemd_1(749348357, bevl_i);
} /* Line: 131*/
 else /* Line: 130*/ {
bevt_98_ta_ph = bevl_i.bemd_0(281969055);
bevt_99_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_97_ta_ph = bevt_98_ta_ph.bemd_1(1276638363, bevt_99_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 132*/ {
bevt_100_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(2036877966, bevt_100_ta_ph);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_ta_ph = bevl_i.bemd_0(-1521235777);
bevl_v.bemd_1(-1705091872, bevt_101_ta_ph);
bevt_102_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1226661305, bevt_102_ta_ph);
bevl_i.bemd_1(729991839, bevl_v);
bevt_103_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(-748618041, bevt_103_ta_ph);
bevl_i.bemd_0(615382753);
} /* Line: 139*/
 else /* Line: 130*/ {
bevt_105_ta_ph = bevl_i.bemd_0(281969055);
bevt_106_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_104_ta_ph = bevt_105_ta_ph.bemd_1(1276638363, bevt_106_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_104_ta_ph).bevi_bool)/* Line: 140*/ {
bevt_108_ta_ph = bevl_ix.bemd_0(281969055);
bevt_109_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_107_ta_ph = bevt_108_ta_ph.bemd_1(1276638363, bevt_109_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 141*/ {
bevt_110_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(2036877966, bevt_110_ta_ph);
bevt_111_ta_ph = bevl_i.bemd_0(-1521235777);
bevt_112_ta_ph = bevl_ix.bemd_0(-1521235777);
bevt_111_ta_ph.bemd_1(-1705091872, bevt_112_ta_ph);
bevt_113_ta_ph = bevl_i.bemd_0(-1521235777);
bevt_114_ta_ph = be.BECS_Runtime.boolTrue;
bevt_113_ta_ph.bemd_1(-1226661305, bevt_114_ta_ph);
bevl_i.bemd_0(615382753);
bevt_115_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(-748618041, bevt_115_ta_ph);
} /* Line: 146*/
 else /* Line: 147*/ {
bevt_117_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevt_116_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_ta_ph, bevl_i);
throw new be.BECS_ThrowBack(bevt_116_ta_ph);
} /* Line: 148*/
} /* Line: 141*/
} /* Line: 130*/
} /* Line: 130*/
} /* Line: 130*/
 else /* Line: 125*/ {
break;
} /* Line: 125*/
} /* Line: 125*/
bevl_ii = bevl_toremove.bemd_0(455087168);
while (true)
/* Line: 152*/ {
bevt_118_ta_ph = bevl_ii.bemd_0(764792202);
if (((BEC_2_5_4_LogicBool) bevt_118_ta_ph).bevi_bool)/* Line: 152*/ {
bevl_i = bevl_ii.bemd_0(214487301);
bevl_i.bemd_0(-1549309530);
} /* Line: 154*/
 else /* Line: 152*/ {
break;
} /* Line: 152*/
} /* Line: 152*/
bevl_s = beva_node.bem_heldGet_0();
bevt_120_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_119_ta_ph = bevl_numargs.bemd_1(-1686022071, bevt_120_ta_ph);
bevl_s.bemd_1(-1893948861, bevt_119_ta_ph);
bevt_121_ta_ph = bevl_s.bemd_0(-1779064974);
bevl_s.bemd_1(1147444926, bevt_121_ta_ph);
bevt_124_ta_ph = bevl_s.bemd_0(-1779064974);
bevt_125_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_3));
bevt_123_ta_ph = bevt_124_ta_ph.bemd_1(2036877966, bevt_125_ta_ph);
bevt_127_ta_ph = bevl_s.bemd_0(-599374414);
bevt_126_ta_ph = bevt_127_ta_ph.bemd_0(-1756046326);
bevt_122_ta_ph = bevt_123_ta_ph.bemd_1(2036877966, bevt_126_ta_ph);
bevl_s.bemd_1(-1705091872, bevt_122_ta_ph);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_ta_ph = bevl_i.bemd_0(281969055);
bevt_130_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_128_ta_ph = bevt_129_ta_ph.bemd_1(1276638363, bevt_130_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_128_ta_ph).bevi_bool)/* Line: 161*/ {
bevl_i.bemd_0(-472860422);
bevt_131_ta_ph = bevl_i.bemd_0(-1521235777);
bevl_s.bemd_1(-305058152, bevt_131_ta_ph);
bevt_134_ta_ph = bevl_s.bemd_0(343458285);
bevt_133_ta_ph = bevt_134_ta_ph.bemd_0(1070995294);
if (bevt_133_ta_ph == null) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 165*/ {
bevl_s.bemd_1(-305058152, null);
} /* Line: 167*/
 else /* Line: 165*/ {
bevt_138_ta_ph = bevl_s.bemd_0(343458285);
bevt_137_ta_ph = bevt_138_ta_ph.bemd_0(1070995294);
bevt_136_ta_ph = bevt_137_ta_ph.bemd_0(-1756046326);
bevt_139_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_4));
bevt_135_ta_ph = bevt_136_ta_ph.bemd_1(1276638363, bevt_139_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_135_ta_ph).bevi_bool)/* Line: 168*/ {
bevt_140_ta_ph = bevl_s.bemd_0(343458285);
bevt_141_ta_ph = be.BECS_Runtime.boolTrue;
bevt_140_ta_ph.bemd_1(1595692412, bevt_141_ta_ph);
bevt_142_ta_ph = bevl_s.bemd_0(343458285);
bevt_143_ta_ph = be.BECS_Runtime.boolTrue;
bevt_142_ta_ph.bemd_1(-855451884, bevt_143_ta_ph);
bevt_144_ta_ph = bevl_s.bemd_0(343458285);
bevt_145_ta_ph = be.BECS_Runtime.boolTrue;
bevt_144_ta_ph.bemd_1(-272095381, bevt_145_ta_ph);
bevt_147_ta_ph = bevl_s.bemd_0(343458285);
bevt_146_ta_ph = bevt_147_ta_ph.bemd_0(1070995294);
bevt_148_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_146_ta_ph.bemd_1(1596141260, bevt_148_ta_ph);
} /* Line: 173*/
 else /* Line: 165*/ {
bevt_152_ta_ph = bevl_s.bemd_0(343458285);
bevt_151_ta_ph = bevt_152_ta_ph.bemd_0(1070995294);
bevt_150_ta_ph = bevt_151_ta_ph.bemd_0(-1756046326);
bevt_153_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_149_ta_ph = bevt_150_ta_ph.bemd_1(1276638363, bevt_153_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_149_ta_ph).bevi_bool)/* Line: 174*/ {
bevt_154_ta_ph = bevl_s.bemd_0(343458285);
bevt_155_ta_ph = be.BECS_Runtime.boolTrue;
bevt_154_ta_ph.bemd_1(1595692412, bevt_155_ta_ph);
bevt_156_ta_ph = bevl_s.bemd_0(343458285);
bevt_157_ta_ph = be.BECS_Runtime.boolTrue;
bevt_156_ta_ph.bemd_1(-855451884, bevt_157_ta_ph);
} /* Line: 176*/
} /* Line: 165*/
} /* Line: 165*/
bevl_i.bemd_0(-1549309530);
} /* Line: 178*/
 else /* Line: 179*/ {
bevt_158_ta_ph = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(-305058152, bevt_158_ta_ph);
bevt_159_ta_ph = bevl_s.bemd_0(343458285);
bevt_160_ta_ph = be.BECS_Runtime.boolTrue;
bevt_159_ta_ph.bemd_1(1595692412, bevt_160_ta_ph);
bevt_161_ta_ph = bevl_s.bemd_0(343458285);
bevt_162_ta_ph = be.BECS_Runtime.boolTrue;
bevt_161_ta_ph.bemd_1(-855451884, bevt_162_ta_ph);
bevt_163_ta_ph = bevl_s.bemd_0(343458285);
bevt_164_ta_ph = be.BECS_Runtime.boolTrue;
bevt_163_ta_ph.bemd_1(-272095381, bevt_164_ta_ph);
bevt_165_ta_ph = bevl_s.bemd_0(343458285);
bevt_166_ta_ph = be.BECS_Runtime.boolTrue;
bevt_165_ta_ph.bemd_1(1032927441, bevt_166_ta_ph);
bevt_167_ta_ph = bevl_s.bemd_0(343458285);
bevt_169_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_168_ta_ph = (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_169_ta_ph);
bevt_167_ta_ph.bemd_1(470836286, bevt_168_ta_ph);
} /* Line: 185*/
bevl_clnode = beva_node.bem_classGet_0();
bevt_171_ta_ph = bevl_clnode.bemd_0(-1521235777);
bevt_170_ta_ph = bevt_171_ta_ph.bemd_0(750592425);
bevt_172_ta_ph = bevl_s.bemd_0(-1779064974);
bevt_170_ta_ph.bemd_2(-378086012, bevt_172_ta_ph, beva_node);
bevt_174_ta_ph = bevl_clnode.bemd_0(-1521235777);
bevt_173_ta_ph = bevt_174_ta_ph.bemd_0(2103284186);
bevt_173_ta_ph.bemd_1(749348357, beva_node);
} /* Line: 189*/
} /* Line: 21*/
} /* Line: 21*/
} /* Line: 21*/
bevt_175_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_175_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 20, 21, 21, 21, 21, 22, 23, 23, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 25, 26, 26, 26, 26, 0, 26, 26, 28, 28, 30, 30, 31, 33, 34, 34, 34, 34, 35, 36, 36, 36, 37, 37, 40, 44, 45, 46, 48, 49, 49, 49, 51, 52, 55, 56, 56, 56, 57, 60, 60, 61, 62, 62, 65, 66, 66, 66, 66, 67, 68, 69, 69, 69, 69, 0, 69, 69, 71, 71, 72, 74, 74, 75, 75, 75, 76, 76, 77, 78, 80, 80, 80, 80, 81, 81, 82, 83, 83, 83, 83, 83, 0, 0, 0, 84, 85, 85, 86, 87, 88, 89, 89, 90, 91, 92, 92, 93, 94, 95, 95, 95, 96, 96, 96, 97, 97, 104, 105, 106, 107, 108, 110, 110, 110, 110, 110, 0, 0, 0, 111, 112, 115, 115, 116, 116, 116, 116, 117, 117, 118, 119, 120, 120, 121, 121, 122, 123, 124, 125, 125, 125, 126, 127, 130, 130, 130, 131, 132, 132, 132, 133, 133, 134, 135, 135, 136, 136, 137, 138, 138, 139, 140, 140, 140, 141, 141, 141, 142, 142, 143, 143, 143, 144, 144, 144, 145, 146, 146, 148, 148, 148, 152, 152, 153, 154, 156, 157, 157, 157, 158, 158, 159, 159, 159, 159, 159, 159, 159, 160, 161, 161, 161, 162, 164, 164, 165, 165, 165, 165, 167, 168, 168, 168, 168, 168, 170, 170, 170, 171, 171, 171, 172, 172, 172, 173, 173, 173, 173, 174, 174, 174, 174, 174, 175, 175, 175, 176, 176, 176, 178, 180, 180, 181, 181, 181, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 185, 187, 188, 188, 188, 188, 189, 189, 189, 191, 191};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {217, 218, 219, 220, 221, 226, 227, 228, 229, 234, 235, 236, 237, 238, 243, 244, 247, 251, 254, 255, 256, 257, 262, 263, 266, 270, 273, 274, 275, 276, 277, 278, 280, 283, 287, 290, 291, 292, 293, 294, 299, 300, 303, 307, 310, 311, 312, 313, 314, 314, 317, 319, 320, 321, 327, 328, 329, 331, 332, 333, 334, 337, 339, 340, 341, 342, 344, 345, 346, 354, 356, 357, 359, 360, 361, 362, 365, 366, 368, 369, 370, 371, 373, 375, 380, 381, 382, 383, 385, 388, 389, 390, 395, 396, 397, 398, 399, 400, 401, 401, 404, 406, 407, 408, 409, 415, 416, 417, 418, 419, 420, 423, 425, 426, 434, 435, 436, 441, 442, 447, 448, 451, 456, 457, 458, 459, 461, 464, 468, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 491, 492, 493, 496, 498, 499, 506, 507, 508, 509, 510, 516, 521, 522, 523, 524, 526, 529, 533, 536, 537, 540, 541, 544, 545, 546, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 567, 569, 570, 571, 572, 573, 575, 578, 579, 580, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 595, 596, 597, 599, 600, 601, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 616, 617, 618, 628, 631, 633, 634, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 658, 659, 660, 661, 662, 663, 668, 669, 672, 673, 674, 675, 676, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 693, 694, 695, 696, 697, 699, 700, 701, 702, 703, 704, 708, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 730, 731, 732, 733, 734, 735, 736, 737, 742, 743};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
resolveNp 0 17 217
assign 1 20 218
nextPeerGet 0 20 218
assign 1 21 219
typenameGet 0 21 219
assign 1 21 220
EMITGet 0 21 220
assign 1 21 221
equals 1 21 226
assign 1 22 227
nextAscendGet 0 22 227
assign 1 23 228
containedGet 0 23 228
assign 1 23 229
def 1 23 234
assign 1 23 235
containedGet 0 23 235
assign 1 23 236
lengthGet 0 23 236
assign 1 23 237
new 0 23 237
assign 1 23 238
greater 1 23 243
assign 1 0 244
assign 1 0 247
assign 1 0 251
assign 1 23 254
containedGet 0 23 254
assign 1 23 255
firstGet 0 23 255
assign 1 23 256
containedGet 0 23 256
assign 1 23 257
def 1 23 262
assign 1 0 263
assign 1 0 266
assign 1 0 270
assign 1 23 273
containedGet 0 23 273
assign 1 23 274
firstGet 0 23 274
assign 1 23 275
containedGet 0 23 275
assign 1 23 276
lengthGet 0 23 276
assign 1 23 277
new 0 23 277
assign 1 23 278
greater 1 23 278
assign 1 0 280
assign 1 0 283
assign 1 0 287
assign 1 23 290
secondGet 0 23 290
assign 1 23 291
containedGet 0 23 291
assign 1 23 292
lengthGet 0 23 292
assign 1 23 293
new 0 23 293
assign 1 23 294
greater 1 23 299
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 25 310
new 0 25 310
assign 1 26 311
containedGet 0 26 311
assign 1 26 312
firstGet 0 26 312
assign 1 26 313
containedGet 0 26 313
assign 1 26 314
iteratorGet 0 0 314
assign 1 26 317
hasNextGet 0 26 317
assign 1 26 319
nextGet 0 26 319
assign 1 28 320
heldGet 0 28 320
addValue 1 28 321
assign 1 30 327
new 0 30 327
delete 1 30 328
assign 1 31 329
new 0 31 329
assign 1 33 331
new 0 33 331
assign 1 34 332
secondGet 0 34 332
assign 1 34 333
containedGet 0 34 333
assign 1 34 334
iteratorGet 0 34 334
assign 1 34 337
hasNextGet 0 34 337
assign 1 35 339
nextGet 0 35 339
assign 1 36 340
typenameGet 0 36 340
assign 1 36 341
STRINGLGet 0 36 341
assign 1 36 342
equals 1 36 342
assign 1 37 344
heldGet 0 37 344
heldSet 1 37 345
assign 1 40 346
new 0 40 346
assign 1 44 354
not 0 44 354
delete 0 45 356
return 1 46 357
containedSet 1 48 359
assign 1 49 360
heldGet 0 49 360
assign 1 49 361
new 2 49 361
heldSet 1 49 362
delete 0 51 365
return 1 52 366
assign 1 55 368
scopeGet 0 55 368
assign 1 56 369
typenameGet 0 56 369
assign 1 56 370
METHODGet 0 56 370
assign 1 56 371
equals 1 56 371
assign 1 57 373
assign 1 60 375
def 1 60 380
delete 0 61 381
assign 1 62 382
heldGet 0 62 382
addEmit 1 62 383
return 1 65 385
assign 1 66 388
typenameGet 0 66 388
assign 1 66 389
IFEMITGet 0 66 389
assign 1 66 390
equals 1 66 395
assign 1 67 396
new 0 67 396
assign 1 68 397
new 0 68 397
assign 1 69 398
containedGet 0 69 398
assign 1 69 399
firstGet 0 69 399
assign 1 69 400
containedGet 0 69 400
assign 1 69 401
iteratorGet 0 0 401
assign 1 69 404
hasNextGet 0 69 404
assign 1 69 406
nextGet 0 69 406
assign 1 71 407
heldGet 0 71 407
addValue 1 71 408
addValue 1 72 409
assign 1 74 415
new 0 74 415
delete 1 74 416
assign 1 75 417
heldGet 0 75 417
assign 1 75 418
new 2 75 418
heldSet 1 75 419
assign 1 76 420
iteratorGet 0 76 420
assign 1 76 423
hasNextGet 0 76 423
assign 1 77 425
nextGet 0 77 425
delete 0 78 426
assign 1 80 434
typenameGet 0 80 434
assign 1 80 435
IFGet 0 80 435
assign 1 80 436
equals 1 80 441
assign 1 81 442
def 1 81 447
assign 1 82 448
assign 1 83 451
def 1 83 456
assign 1 83 457
typenameGet 0 83 457
assign 1 83 458
ELIFGet 0 83 458
assign 1 83 459
equals 1 83 459
assign 1 0 461
assign 1 0 464
assign 1 0 468
assign 1 84 471
new 1 84 471
assign 1 85 472
ELSEGet 0 85 472
typenameSet 1 85 473
copyLoc 1 86 474
assign 1 87 475
new 1 87 475
copyLoc 1 88 476
assign 1 89 477
BRACESGet 0 89 477
typenameSet 1 89 478
assign 1 90 479
new 1 90 479
copyLoc 1 91 480
assign 1 92 481
IFGet 0 92 481
typenameSet 1 92 482
addValue 1 93 483
addValue 1 94 484
assign 1 95 485
containedGet 0 95 485
assign 1 95 486
def 1 95 491
assign 1 96 492
containedGet 0 96 492
assign 1 96 493
iteratorGet 0 96 493
assign 1 96 496
hasNextGet 0 96 496
assign 1 97 498
nextGet 0 97 498
addValue 1 97 499
addValue 1 104 506
assign 1 105 507
assign 1 106 508
nextPeerGet 0 106 508
delete 0 107 509
assign 1 108 510
assign 1 110 516
def 1 110 521
assign 1 110 522
typenameGet 0 110 522
assign 1 110 523
ELSEGet 0 110 523
assign 1 110 524
equals 1 110 524
assign 1 0 526
assign 1 0 529
assign 1 0 533
delete 0 111 536
addValue 1 112 537
assign 1 115 540
nextDescendGet 0 115 540
return 1 115 541
assign 1 116 544
typenameGet 0 116 544
assign 1 116 545
METHODGet 0 116 545
assign 1 116 546
equals 1 116 551
assign 1 117 552
containedGet 0 117 552
assign 1 117 553
firstGet 0 117 553
assign 1 118 554
new 1 118 554
copyLoc 1 119 555
assign 1 120 556
IDGet 0 120 556
typenameSet 1 120 557
assign 1 121 558
new 0 121 558
heldSet 1 121 559
prepend 1 122 560
assign 1 123 561
new 0 123 561
assign 1 124 562
new 0 124 562
assign 1 125 563
containedGet 0 125 563
assign 1 125 564
iteratorGet 0 125 564
assign 1 125 567
hasNextGet 0 125 567
assign 1 126 569
nextGet 0 126 569
assign 1 127 570
nextPeerGet 0 127 570
assign 1 130 571
typenameGet 0 130 571
assign 1 130 572
COMMAGet 0 130 572
assign 1 130 573
equals 1 130 573
addValue 1 131 575
assign 1 132 578
typenameGet 0 132 578
assign 1 132 579
IDGet 0 132 579
assign 1 132 580
equals 1 132 580
assign 1 133 582
new 0 133 582
assign 1 133 583
add 1 133 583
assign 1 134 584
new 0 134 584
assign 1 135 585
heldGet 0 135 585
nameSet 1 135 586
assign 1 136 587
new 0 136 587
isArgSet 1 136 588
heldSet 1 137 589
assign 1 138 590
VARGet 0 138 590
typenameSet 1 138 591
addVariable 0 139 592
assign 1 140 595
typenameGet 0 140 595
assign 1 140 596
VARGet 0 140 596
assign 1 140 597
equals 1 140 597
assign 1 141 599
typenameGet 0 141 599
assign 1 141 600
IDGet 0 141 600
assign 1 141 601
equals 1 141 601
assign 1 142 603
new 0 142 603
assign 1 142 604
add 1 142 604
assign 1 143 605
heldGet 0 143 605
assign 1 143 606
heldGet 0 143 606
nameSet 1 143 607
assign 1 144 608
heldGet 0 144 608
assign 1 144 609
new 0 144 609
isArgSet 1 144 610
addVariable 0 145 611
assign 1 146 612
COMMAGet 0 146 612
typenameSet 1 146 613
assign 1 148 616
new 0 148 616
assign 1 148 617
new 2 148 617
throw 1 148 618
assign 1 152 628
iteratorGet 0 152 628
assign 1 152 631
hasNextGet 0 152 631
assign 1 153 633
nextGet 0 153 633
delete 0 154 634
assign 1 156 640
heldGet 0 156 640
assign 1 157 641
new 0 157 641
assign 1 157 642
subtract 1 157 642
numargsSet 1 157 643
assign 1 158 644
nameGet 0 158 644
orgNameSet 1 158 645
assign 1 159 646
nameGet 0 159 646
assign 1 159 647
new 0 159 647
assign 1 159 648
add 1 159 648
assign 1 159 649
numargsGet 0 159 649
assign 1 159 650
toString 0 159 650
assign 1 159 651
add 1 159 651
nameSet 1 159 652
assign 1 160 653
secondGet 0 160 653
assign 1 161 654
typenameGet 0 161 654
assign 1 161 655
VARGet 0 161 655
assign 1 161 656
equals 1 161 656
resolveNp 0 162 658
assign 1 164 659
heldGet 0 164 659
rtypeSet 1 164 660
assign 1 165 661
rtypeGet 0 165 661
assign 1 165 662
namepathGet 0 165 662
assign 1 165 663
undef 1 165 668
rtypeSet 1 167 669
assign 1 168 672
rtypeGet 0 168 672
assign 1 168 673
namepathGet 0 168 673
assign 1 168 674
toString 0 168 674
assign 1 168 675
new 0 168 675
assign 1 168 676
equals 1 168 676
assign 1 170 678
rtypeGet 0 170 678
assign 1 170 679
new 0 170 679
isTypedSet 1 170 680
assign 1 171 681
rtypeGet 0 171 681
assign 1 171 682
new 0 171 682
isSelfSet 1 171 683
assign 1 172 684
rtypeGet 0 172 684
assign 1 172 685
new 0 172 685
isThisSet 1 172 686
assign 1 173 687
rtypeGet 0 173 687
assign 1 173 688
namepathGet 0 173 688
assign 1 173 689
new 0 173 689
pathSet 1 173 690
assign 1 174 693
rtypeGet 0 174 693
assign 1 174 694
namepathGet 0 174 694
assign 1 174 695
toString 0 174 695
assign 1 174 696
new 0 174 696
assign 1 174 697
equals 1 174 697
assign 1 175 699
rtypeGet 0 175 699
assign 1 175 700
new 0 175 700
isTypedSet 1 175 701
assign 1 176 702
rtypeGet 0 176 702
assign 1 176 703
new 0 176 703
isSelfSet 1 176 704
delete 0 178 708
assign 1 180 711
new 0 180 711
rtypeSet 1 180 712
assign 1 181 713
rtypeGet 0 181 713
assign 1 181 714
new 0 181 714
isTypedSet 1 181 715
assign 1 182 716
rtypeGet 0 182 716
assign 1 182 717
new 0 182 717
isSelfSet 1 182 718
assign 1 183 719
rtypeGet 0 183 719
assign 1 183 720
new 0 183 720
isThisSet 1 183 721
assign 1 184 722
rtypeGet 0 184 722
assign 1 184 723
new 0 184 723
impliedSet 1 184 724
assign 1 185 725
rtypeGet 0 185 725
assign 1 185 726
new 0 185 726
assign 1 185 727
new 1 185 727
namepathSet 1 185 728
assign 1 187 730
classGet 0 187 730
assign 1 188 731
heldGet 0 188 731
assign 1 188 732
methodsGet 0 188 732
assign 1 188 733
nameGet 0 188 733
put 2 188 734
assign 1 189 735
heldGet 0 189 735
assign 1 189 736
orderedMethodsGet 0 189 736
addValue 1 189 737
assign 1 191 742
nextDescendGet 0 191 742
return 1 191 743
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1012381645: return bem_create_0();
case 454522998: return bem_print_0();
case -178534499: return bem_ntypesGet_0();
case 1478255442: return bem_copy_0();
case -1423130981: return bem_hashGet_0();
case -2024723085: return bem_transGet_0();
case 455087168: return bem_iteratorGet_0();
case -1756046326: return bem_toString_0();
case 1788083312: return bem_buildGet_0();
case 530227489: return bem_new_0();
case 872815847: return bem_constGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -948186927: return bem_begin_1(bevd_0);
case 96657329: return bem_notEquals_1(bevd_0);
case 576934107: return bem_copyTo_1(bevd_0);
case -1595418159: return bem_ntypesSet_1(bevd_0);
case 1973529912: return bem_constSet_1(bevd_0);
case 1276638363: return bem_equals_1(bevd_0);
case -750238441: return bem_transSet_1(bevd_0);
case 498781741: return bem_buildSet_1(bevd_0);
case 889955668: return bem_undef_1(bevd_0);
case -951841069: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1342373171: return bem_def_1(bevd_0);
case 1436250347: return bem_end_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1465920918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1131482033: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 558464110: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 180847688: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass6_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass6_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst = (BEC_3_5_5_5_BuildVisitPass6) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;
}
}
