package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_21_SystemStartupWithParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_21_SystemStartupWithParameters() { }
private static byte[] becc_BEC_2_6_21_SystemStartupWithParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x57,0x69,0x74,0x68,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_21_SystemStartupWithParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_21_SystemStartupWithParameters_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_21_SystemStartupWithParameters_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x4C,0x69,0x73,0x74,0x20,0x61,0x72,0x67,0x73,0x2C,0x20,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73,0x20,0x70,0x61,0x72,0x61,0x6D,0x73,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_6_21_SystemStartupWithParameters_bevo_1 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_6_21_SystemStartupWithParameters bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst;

public static BET_2_6_21_SystemStartupWithParameters bece_BEC_2_6_21_SystemStartupWithParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_6_21_SystemStartupWithParameters bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_2_tmpany_phold = bevp_args.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_6_21_SystemStartupWithParameters_bevo_0;
if (bevt_2_tmpany_phold.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 93 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(164, bece_BEC_2_6_21_SystemStartupWithParameters_bels_0));
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 94 */
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_8_tmpany_phold = bece_BEC_2_6_21_SystemStartupWithParameters_bevo_1;
bevt_7_tmpany_phold = bevp_args.bem_get_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) bevt_7_tmpany_phold );
bevl_x = bevt_6_tmpany_phold.bemd_0(695019909);
bevt_9_tmpany_phold = bevl_x.bemd_2(-1283077458, bevp_args, bevp_params);
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_21_SystemStartupWithParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_21_SystemStartupWithParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {92, 92, 93, 93, 93, 93, 94, 94, 94, 96, 97, 97, 97, 97, 98, 98, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {34, 35, 36, 37, 38, 43, 44, 45, 46, 48, 49, 50, 51, 52, 53, 54, 57, 60, 63, 67, 71, 74, 77, 81};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 92 34
new 0 92 34
assign 1 92 35
argsGet 0 92 35
assign 1 93 36
sizeGet 0 93 36
assign 1 93 37
new 0 93 37
assign 1 93 38
lesser 1 93 43
assign 1 94 44
new 0 94 44
assign 1 94 45
new 1 94 45
throw 1 94 46
assign 1 96 48
new 1 96 48
assign 1 97 49
new 0 97 49
assign 1 97 50
get 1 97 50
assign 1 97 51
createInstance 1 97 51
assign 1 97 52
new 0 97 52
assign 1 98 53
main 2 98 53
return 1 98 54
return 1 0 57
return 1 0 60
assign 1 0 63
assign 1 0 67
return 1 0 71
return 1 0 74
assign 1 0 77
assign 1 0 81
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1254228006: return bem_argsGet_0();
case -1206807373: return bem_echo_0();
case 1639062936: return bem_create_0();
case 845843737: return bem_copy_0();
case 434703584: return bem_many_0();
case -2063692354: return bem_toAny_0();
case -1451555458: return bem_paramsGet_0();
case -2060052900: return bem_classNameGet_0();
case -653615460: return bem_fieldIteratorGet_0();
case 1495383112: return bem_argsGetDirect_0();
case 584319597: return bem_serializeContents_0();
case 936108049: return bem_fieldNamesGet_0();
case 1617808370: return bem_default_0();
case 866670678: return bem_paramsGetDirect_0();
case 542454679: return bem_tagGet_0();
case -1788326649: return bem_iteratorGet_0();
case 695019909: return bem_new_0();
case 1453828591: return bem_main_0();
case 1173227505: return bem_once_0();
case -45870993: return bem_hashGet_0();
case 1042227348: return bem_print_0();
case -867540373: return bem_sourceFileNameGet_0();
case -835256918: return bem_deserializeClassNameGet_0();
case 376367511: return bem_toString_0();
case 1154111609: return bem_serializeToString_0();
case 702386781: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1253472481: return bem_copyTo_1(bevd_0);
case -886160285: return bem_notEquals_1(bevd_0);
case 1738623736: return bem_sameType_1(bevd_0);
case 699166467: return bem_sameClass_1(bevd_0);
case -1569160884: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 471926371: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -671092537: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2031145791: return bem_def_1(bevd_0);
case -1438256358: return bem_otherType_1(bevd_0);
case 142440277: return bem_argsSetDirect_1(bevd_0);
case -670346435: return bem_sameObject_1(bevd_0);
case -1380509624: return bem_paramsSet_1(bevd_0);
case 585390927: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -226317721: return bem_paramsSetDirect_1(bevd_0);
case 301362299: return bem_undef_1(bevd_0);
case -1253948557: return bem_otherClass_1(bevd_0);
case 604219486: return bem_undefined_1(bevd_0);
case 1689281313: return bem_defined_1(bevd_0);
case 462588756: return bem_argsSet_1(bevd_0);
case -2130755695: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1353806938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1092172708: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1390495691: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1588508948: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 167635781: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1229766114: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 39825618: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_21_SystemStartupWithParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_21_SystemStartupWithParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_21_SystemStartupWithParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst = (BEC_2_6_21_SystemStartupWithParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_type;
}
}
