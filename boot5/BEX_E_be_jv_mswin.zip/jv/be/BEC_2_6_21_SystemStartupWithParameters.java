package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_21_SystemStartupWithParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_21_SystemStartupWithParameters() { }
private static byte[] becc_BEC_2_6_21_SystemStartupWithParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x57,0x69,0x74,0x68,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_21_SystemStartupWithParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_21_SystemStartupWithParameters_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_21_SystemStartupWithParameters_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x4C,0x69,0x73,0x74,0x20,0x61,0x72,0x67,0x73,0x2C,0x20,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73,0x20,0x70,0x61,0x72,0x61,0x6D,0x73,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_6_21_SystemStartupWithParameters_bevo_1 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_6_21_SystemStartupWithParameters bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst;

public static BET_2_6_21_SystemStartupWithParameters bece_BEC_2_6_21_SystemStartupWithParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_6_21_SystemStartupWithParameters bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_2_tmpany_phold = bevp_args.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_6_21_SystemStartupWithParameters_bevo_0;
if (bevt_2_tmpany_phold.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 93 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(164, bece_BEC_2_6_21_SystemStartupWithParameters_bels_0));
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 94 */
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_8_tmpany_phold = bece_BEC_2_6_21_SystemStartupWithParameters_bevo_1;
bevt_7_tmpany_phold = bevp_args.bem_get_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) bevt_7_tmpany_phold );
bevl_x = bevt_6_tmpany_phold.bemd_0(-181121720);
bevt_9_tmpany_phold = bevl_x.bemd_2(625979182, bevp_args, bevp_params);
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_21_SystemStartupWithParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_21_SystemStartupWithParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {92, 92, 93, 93, 93, 93, 94, 94, 94, 96, 97, 97, 97, 97, 98, 98, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {34, 35, 36, 37, 38, 43, 44, 45, 46, 48, 49, 50, 51, 52, 53, 54, 57, 60, 63, 67, 71, 74, 77, 81};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 92 34
new 0 92 34
assign 1 92 35
argsGet 0 92 35
assign 1 93 36
sizeGet 0 93 36
assign 1 93 37
new 0 93 37
assign 1 93 38
lesser 1 93 43
assign 1 94 44
new 0 94 44
assign 1 94 45
new 1 94 45
throw 1 94 46
assign 1 96 48
new 1 96 48
assign 1 97 49
new 0 97 49
assign 1 97 50
get 1 97 50
assign 1 97 51
createInstance 1 97 51
assign 1 97 52
new 0 97 52
assign 1 98 53
main 2 98 53
return 1 98 54
return 1 0 57
return 1 0 60
assign 1 0 63
assign 1 0 67
return 1 0 71
return 1 0 74
assign 1 0 77
assign 1 0 81
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1222234212: return bem_once_0();
case 667228902: return bem_create_0();
case -631740911: return bem_toAny_0();
case -675749221: return bem_deserializeClassNameGet_0();
case 1744405494: return bem_paramsGet_0();
case 2085621651: return bem_argsGet_0();
case 1532059915: return bem_hashGet_0();
case -372207069: return bem_echo_0();
case 1630815516: return bem_argsGetDirect_0();
case -1434554234: return bem_serializeToString_0();
case 903242673: return bem_serializeContents_0();
case -808119328: return bem_print_0();
case -181121720: return bem_new_0();
case 1731345338: return bem_tagGet_0();
case 68278359: return bem_default_0();
case 116064121: return bem_fieldIteratorGet_0();
case 207936271: return bem_paramsGetDirect_0();
case 201401408: return bem_iteratorGet_0();
case 1443369362: return bem_copy_0();
case 1497839510: return bem_classNameGet_0();
case 1437342193: return bem_many_0();
case 1365890250: return bem_serializationIteratorGet_0();
case -1249905321: return bem_main_0();
case -213179861: return bem_fieldNamesGet_0();
case 1218813014: return bem_sourceFileNameGet_0();
case 304904756: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1397213195: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1238349268: return bem_argsSet_1(bevd_0);
case 381288505: return bem_def_1(bevd_0);
case 1477350298: return bem_otherType_1(bevd_0);
case -1045546721: return bem_sameObject_1(bevd_0);
case -71227052: return bem_copyTo_1(bevd_0);
case 485277844: return bem_undef_1(bevd_0);
case -215035200: return bem_argsSetDirect_1(bevd_0);
case -118443119: return bem_paramsSet_1(bevd_0);
case -6903784: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1801074654: return bem_sameType_1(bevd_0);
case -1112415428: return bem_otherClass_1(bevd_0);
case -1186867352: return bem_sameClass_1(bevd_0);
case -304875198: return bem_paramsSetDirect_1(bevd_0);
case 48512687: return bem_equals_1(bevd_0);
case -1960916636: return bem_notEquals_1(bevd_0);
case -1464177031: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1883300982: return bem_defined_1(bevd_0);
case -1674224941: return bem_undefined_1(bevd_0);
case 1485967678: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2106641120: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 219701968: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 859481713: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1909968647: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -803774767: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -545558457: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116867693: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_21_SystemStartupWithParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_21_SystemStartupWithParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_21_SystemStartupWithParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst = (BEC_2_6_21_SystemStartupWithParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_type;
}
}
