package be;
public class BET_3_6_4_11_SystemTestInExtending extends BETS_Object {
public BET_3_6_4_11_SystemTestInExtending() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "acall_0", "bcall_0", "propaGet_0", "propaSet_1", "propbGet_0", "propbSet_1", "ccall_0", "prop2aGet_0", "prop2aSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "propa", "propb", "prop2a" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_6_4_11_SystemTestInExtending();
}
}
