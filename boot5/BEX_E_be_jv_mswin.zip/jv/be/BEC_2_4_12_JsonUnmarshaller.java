package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static BEC_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public BEC_2_4_12_JsonUnmarshaller bem_new_0() throws Throwable {
bevp_parser = (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) throws Throwable {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_first == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevp_first = beva_o;
} /* Line: 485 */
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 488 */ {
bevt_2_tmpany_phold = bevl_top.bemd_1(-994928324, bevp_pair);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_4_tmpany_phold = bevl_top.bemd_0(1052222382);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 490 */ {
bevt_5_tmpany_phold = bevl_top.bemd_0(728696369);
bevt_6_tmpany_phold = bevl_top.bemd_0(1052222382);
bevt_5_tmpany_phold.bemd_2(984218292, bevt_6_tmpany_phold, beva_o);
bevl_top.bemd_1(-1646549237, null);
} /* Line: 492 */
 else  /* Line: 493 */ {
bevl_top.bemd_1(-1646549237, beva_o);
} /* Line: 494 */
} /* Line: 490 */
 else  /* Line: 489 */ {
bevt_7_tmpany_phold = bevl_top.bemd_1(-994928324, bevp_list);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevl_top.bemd_1(1852517708, beva_o);
} /* Line: 497 */
 else  /* Line: 498 */ {
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_4_12_JsonUnmarshaller_bels_0));
bevt_8_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 499 */
} /* Line: 489 */
} /* Line: 489 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_tmpany_phold = null;
bevl_m = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bem_addIn_1(bevl_m);
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endMap_0() throws Throwable {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 513 */ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 514 */
 else  /* Line: 515 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_12_JsonUnmarshaller_bels_1));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 516 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_stack.bem_peek_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-994928324, bevp_pair);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(929464276);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_6_tmpany_phold = bevp_stack.bem_peek_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(1052222382);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 522 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 522 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_4_12_JsonUnmarshaller_bels_2));
bevt_7_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 523 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (new BEC_2_9_4_ContainerList()).bem_new_0();
bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 536 */ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 537 */
 else  /* Line: 538 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_4_12_JsonUnmarshaller_bels_3));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 539 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_addIn_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() throws Throwable {
bem_addIn_1(null);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
bem_addIn_1(beva_int);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parserGet_0() throws Throwable {
return bevp_parser;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_pairGet_0() throws Throwable {
return bevp_pair;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_stackGet_0() throws Throwable {
return bevp_stack;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {467, 468, 469, 470, 472, 473, 478, 479, 480, 484, 484, 485, 487, 488, 488, 489, 490, 490, 490, 491, 491, 491, 492, 494, 496, 497, 499, 499, 499, 506, 507, 508, 508, 513, 514, 516, 516, 516, 522, 522, 522, 0, 522, 522, 522, 522, 0, 0, 523, 523, 523, 529, 530, 531, 536, 537, 539, 539, 539, 546, 551, 551, 556, 556, 561, 566, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 22, 23, 24, 28, 29, 30, 44, 49, 50, 52, 53, 58, 59, 61, 62, 67, 68, 69, 70, 71, 74, 78, 80, 83, 84, 85, 94, 95, 96, 97, 105, 107, 110, 111, 112, 126, 127, 128, 130, 133, 134, 135, 140, 141, 144, 148, 149, 150, 156, 157, 158, 166, 168, 171, 172, 173, 178, 183, 184, 189, 190, 194, 198, 202, 205, 209, 212, 216, 219, 223, 226, 230, 233, 237, 240};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 467 19
new 0 467 19
assign 1 468 20
new 0 468 20
assign 1 469 21
new 0 469 21
assign 1 470 22
new 0 470 22
assign 1 472 23
assign 1 473 24
new 0 473 24
new 0 478 28
parse 2 479 29
return 1 480 30
assign 1 484 44
undef 1 484 49
assign 1 485 50
assign 1 487 52
peek 0 487 52
assign 1 488 53
def 1 488 58
assign 1 489 59
sameClass 1 489 59
assign 1 490 61
secondGet 0 490 61
assign 1 490 62
def 1 490 67
assign 1 491 68
firstGet 0 491 68
assign 1 491 69
secondGet 0 491 69
put 2 491 70
secondSet 1 492 71
secondSet 1 494 74
assign 1 496 78
sameClass 1 496 78
addValueWhole 1 497 80
assign 1 499 83
new 0 499 83
assign 1 499 84
new 1 499 84
throw 1 499 85
assign 1 506 94
new 0 506 94
addIn 1 507 95
assign 1 508 96
new 2 508 96
push 1 508 97
assign 1 513 105
isEmptyGet 0 513 105
assign 1 514 107
pop 0 514 107
assign 1 516 110
new 0 516 110
assign 1 516 111
new 1 516 111
throw 1 516 112
assign 1 522 126
peek 0 522 126
assign 1 522 127
sameClass 1 522 127
assign 1 522 128
not 0 522 128
assign 1 0 130
assign 1 522 133
peek 0 522 133
assign 1 522 134
secondGet 0 522 134
assign 1 522 135
undef 1 522 140
assign 1 0 141
assign 1 0 144
assign 1 523 148
new 0 523 148
assign 1 523 149
new 1 523 149
throw 1 523 150
assign 1 529 156
new 0 529 156
addIn 1 530 157
push 1 531 158
assign 1 536 166
isEmptyGet 0 536 166
assign 1 537 168
pop 0 537 168
assign 1 539 171
new 0 539 171
assign 1 539 172
new 1 539 172
throw 1 539 173
addIn 1 546 178
assign 1 551 183
new 0 551 183
addIn 1 551 184
assign 1 556 189
new 0 556 189
addIn 1 556 190
addIn 1 561 194
addIn 1 566 198
return 1 0 202
assign 1 0 205
return 1 0 209
assign 1 0 212
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
return 1 0 237
assign 1 0 240
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 386788561: return bem_new_0();
case -935771084: return bem_sourceFileNameGet_0();
case -261636586: return bem_classNameGet_0();
case -965166373: return bem_endMap_0();
case -1620819332: return bem_once_0();
case 1637405965: return bem_toString_0();
case -1231046229: return bem_listGet_0();
case -1846472489: return bem_parserGet_0();
case 728696369: return bem_firstGet_0();
case -221565968: return bem_endList_0();
case -1975952737: return bem_tagGet_0();
case -1197182710: return bem_serializeToString_0();
case -202088191: return bem_stackGet_0();
case 1526339327: return bem_mapGet_0();
case 582818432: return bem_create_0();
case -1515574193: return bem_handleFalse_0();
case 1342246094: return bem_print_0();
case 168705805: return bem_iteratorGet_0();
case -1300887535: return bem_beginList_0();
case 223659762: return bem_pairGet_0();
case -117420215: return bem_serializeContents_0();
case -1392419719: return bem_handleTrue_0();
case 65678538: return bem_echo_0();
case -1920494633: return bem_kvMid_0();
case 866679447: return bem_serializationIteratorGet_0();
case 1053098123: return bem_hashGet_0();
case 2092326455: return bem_many_0();
case -780112532: return bem_beginMap_0();
case 59808563: return bem_handleNull_0();
case 1449516553: return bem_copy_0();
case 845917022: return bem_fieldIteratorGet_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case -1712633963: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 689388815: return bem_pairSet_1(bevd_0);
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case -1921133350: return bem_defined_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case 800287127: return bem_stackSet_1(bevd_0);
case -1671106386: return bem_listSet_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 306862192: return bem_firstSet_1(bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case -1300755687: return bem_addIn_1(bevd_0);
case -1482637809: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2133678926: return bem_parserSet_1(bevd_0);
case -1192000312: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case -2078603435: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case -220752137: return bem_mapSet_1(bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_JsonUnmarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_12_JsonUnmarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_JsonUnmarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst = (BEC_2_4_12_JsonUnmarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
}
}
