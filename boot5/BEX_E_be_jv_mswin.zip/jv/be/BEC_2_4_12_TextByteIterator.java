package be;
/* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;
public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public BEC_2_4_12_TextByteIterator bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_emptyGet_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_containerGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_str = beva__str;
bevp_pos = (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1267 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 1268 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1278 */ {
bevt_3_tmpany_phold = beva_buf.bem_capacityGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1279 */ {
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 1280 */
bevt_7_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_1;
if (bevt_7_tmpany_phold.bevi_int != bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1282 */ {
bevt_9_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_2;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_9_tmpany_phold.bevi_int = bevt_10_tmpany_phold.bevi_int;
} /* Line: 1283 */
bevt_12_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_13_tmpany_phold = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevp_pos.bevi_int++;
} /* Line: 1289 */
return beva_buf;
} /*method end*/
public BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1295 */ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1297 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_3;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1303 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1303 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1303 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1303 */
 else  /* Line: 1303 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1303 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1306 */
return beva_into;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_4;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1312 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1312 */
 else  /* Line: 1312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1312 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1315 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGet_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1243, 1243, 1243, 1247, 1251, 1255, 1260, 1261, 1262, 1267, 1267, 1267, 1268, 1268, 1270, 1270, 1274, 1274, 1274, 1274, 1278, 1278, 1278, 1279, 1279, 1279, 1279, 1280, 1280, 1282, 1282, 1282, 1282, 1283, 1283, 1283, 1283, 1285, 1285, 1285, 1289, 1291, 1295, 1295, 1295, 1296, 1297, 1299, 1303, 1303, 1303, 1303, 1303, 1303, 0, 0, 0, 1304, 1305, 1306, 1308, 1312, 1312, 1312, 1312, 1312, 1312, 0, 0, 0, 1313, 1314, 1315, 1321, 1325, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 25, 28, 31, 35, 36, 37, 45, 46, 51, 52, 53, 55, 56, 62, 63, 64, 65, 84, 85, 90, 91, 92, 93, 98, 99, 100, 102, 103, 104, 109, 110, 111, 112, 113, 115, 116, 117, 118, 120, 125, 126, 131, 132, 133, 135, 143, 144, 149, 150, 151, 156, 157, 160, 164, 167, 168, 169, 171, 179, 180, 185, 186, 187, 192, 193, 196, 200, 203, 204, 205, 210, 213, 216, 219, 223, 226, 230, 233};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1243 19
new 0 1243 19
assign 1 1243 20
emptyGet 0 1243 20
new 1 1243 21
return 1 1247 25
return 1 1251 28
new 1 1255 31
assign 1 1260 35
assign 1 1261 36
new 0 1261 36
assign 1 1262 37
new 0 1262 37
assign 1 1267 45
sizeGet 0 1267 45
assign 1 1267 46
greater 1 1267 51
assign 1 1268 52
new 0 1268 52
return 1 1268 53
assign 1 1270 55
new 0 1270 55
return 1 1270 56
assign 1 1274 62
new 0 1274 62
assign 1 1274 63
new 1 1274 63
assign 1 1274 64
next 1 1274 64
return 1 1274 65
assign 1 1278 84
sizeGet 0 1278 84
assign 1 1278 85
greater 1 1278 90
assign 1 1279 91
capacityGet 0 1279 91
assign 1 1279 92
new 0 1279 92
assign 1 1279 93
lesser 1 1279 98
assign 1 1280 99
new 0 1280 99
capacitySet 1 1280 100
assign 1 1282 102
sizeGet 0 1282 102
assign 1 1282 103
new 0 1282 103
assign 1 1282 104
notEquals 1 1282 109
assign 1 1283 110
sizeGet 0 1283 110
assign 1 1283 111
new 0 1283 111
assign 1 1283 112
once 0 1283 112
setValue 1 1283 113
assign 1 1285 115
new 0 1285 115
assign 1 1285 116
getInt 2 1285 116
setIntUnchecked 2 1285 117
incrementValue 0 1289 118
return 1 1291 120
assign 1 1295 125
sizeGet 0 1295 125
assign 1 1295 126
greater 1 1295 131
getInt 2 1296 132
incrementValue 0 1297 133
return 1 1299 135
assign 1 1303 143
new 0 1303 143
assign 1 1303 144
greater 1 1303 149
assign 1 1303 150
sizeGet 0 1303 150
assign 1 1303 151
greaterEquals 1 1303 156
assign 1 0 157
assign 1 0 160
assign 1 0 164
decrementValue 0 1304 167
getInt 2 1305 168
incrementValue 0 1306 169
return 1 1308 171
assign 1 1312 179
new 0 1312 179
assign 1 1312 180
greater 1 1312 185
assign 1 1312 186
sizeGet 0 1312 186
assign 1 1312 187
greaterEquals 1 1312 192
assign 1 0 193
assign 1 0 196
assign 1 0 200
decrementValue 0 1313 203
setIntUnchecked 2 1314 204
incrementValue 0 1315 205
return 1 1321 210
return 1 1325 213
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1992252192: return bem_strGet_0();
case 1387595522: return bem_toAny_0();
case 144613256: return bem_serializeContents_0();
case 1359373450: return bem_echo_0();
case -961535531: return bem_hashGet_0();
case 627086221: return bem_once_0();
case -570363758: return bem_serializationIteratorGet_0();
case 1592147441: return bem_posGet_0();
case -1274688402: return bem_nextGet_0();
case 1234289396: return bem_tagGet_0();
case 49643355: return bem_containerGet_0();
case 1087786397: return bem_deserializeClassNameGet_0();
case -1604217257: return bem_byteIteratorIteratorGet_0();
case 758844426: return bem_vcopyGet_0();
case -1988392847: return bem_fieldIteratorGet_0();
case 305137971: return bem_classNameGet_0();
case -1601492406: return bem_new_0();
case -612311095: return bem_iteratorGet_0();
case 436412028: return bem_sourceFileNameGet_0();
case 901060004: return bem_copy_0();
case 1044268871: return bem_hasNextGet_0();
case -1550372712: return bem_serializeToString_0();
case -1194864649: return bem_toString_0();
case 741511465: return bem_print_0();
case 1278732754: return bem_create_0();
case 730619711: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 661372330: return bem_equals_1(bevd_0);
case -1903482804: return bem_otherClass_1(bevd_0);
case -1568064603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 648712272: return bem_posSet_1(bevd_0);
case -1633632376: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -309742024: return bem_def_1(bevd_0);
case 84150182: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1983057875: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 899845556: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case -2051941724: return bem_vcopySet_1(bevd_0);
case 385185820: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1334421073: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1001249520: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1067421305: return bem_notEquals_1(bevd_0);
case 266931166: return bem_undef_1(bevd_0);
case -596533003: return bem_otherType_1(bevd_0);
case 1717289899: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1718194680: return bem_undefined_1(bevd_0);
case -2049241562: return bem_sameObject_1(bevd_0);
case 457153382: return bem_copyTo_1(bevd_0);
case -582459902: return bem_strSet_1(bevd_0);
case 1420318580: return bem_sameType_1(bevd_0);
case -686450804: return bem_defined_1(bevd_0);
case -1023168427: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1461540614: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513720300: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 224164494: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2129126272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 88269440: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -366737409: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -666768572: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_TextByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
}
