package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_17_ContainerSetIdentityRelations extends BEC_3_9_3_9_ContainerSetRelations {
public BEC_3_9_3_17_ContainerSetIdentityRelations() { }
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
public BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_0(-801589503);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_1(-1474467614, beva_l);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {79, 79, 83, 83};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 11, 15, 16};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 79 10
tagGet 0 79 10
return 1 79 11
assign 1 83 15
sameObject 1 83 15
return 1 83 16
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -149632320: return bem_toAny_0();
case -93701646: return bem_fieldIteratorGet_0();
case -748319096: return bem_print_0();
case -29400896: return bem_create_0();
case -1052800757: return bem_echo_0();
case -801589503: return bem_tagGet_0();
case -794227383: return bem_copy_0();
case 861710738: return bem_many_0();
case -7634332: return bem_classNameGet_0();
case 900978335: return bem_serializeToString_0();
case 313469553: return bem_default_0();
case 1338975369: return bem_sourceFileNameGet_0();
case -14402816: return bem_serializeContents_0();
case -1674098047: return bem_once_0();
case -1701242685: return bem_serializationIteratorGet_0();
case -258597009: return bem_hashGet_0();
case -51803385: return bem_toString_0();
case -124916815: return bem_new_0();
case -1749103224: return bem_iteratorGet_0();
case -467186719: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 642489795: return bem_otherType_1(bevd_0);
case 1518481031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 550176080: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -983540661: return bem_undefined_1(bevd_0);
case -2092712540: return bem_def_1(bevd_0);
case 2036979549: return bem_notEquals_1(bevd_0);
case -1474467614: return bem_sameObject_1(bevd_0);
case -218714893: return bem_otherClass_1(bevd_0);
case 1970850163: return bem_sameType_1(bevd_0);
case -93273669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -20159434: return bem_sameClass_1(bevd_0);
case 616348580: return bem_undef_1(bevd_0);
case -271716565: return bem_copyTo_1(bevd_0);
case 226940097: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1668722975: return bem_getHash_1(bevd_0);
case -1391202250: return bem_defined_1(bevd_0);
case -73997568: return bem_equals_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 2093180987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 292502272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -66460559: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -234746039: return bem_isEqual_2(bevd_0, bevd_1);
case 1031466779: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2131321099: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1367679335: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -323049121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(31, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_17_ContainerSetIdentityRelations();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst = (BEC_3_9_3_17_ContainerSetIdentityRelations) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
}
}
