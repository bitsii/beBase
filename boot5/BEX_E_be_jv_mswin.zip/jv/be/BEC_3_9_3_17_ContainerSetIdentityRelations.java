package be;
/* IO:File: source/extended/IdentityMap.be */
public class BEC_3_9_3_17_ContainerSetIdentityRelations extends BEC_3_9_3_9_ContainerSetRelations {
public BEC_3_9_3_17_ContainerSetIdentityRelations() { }
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;

public static BET_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;

public BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_tag_1(beva_k);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_sameObject_2(beva_k, beva_l);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {25, 25, 25, 29, 29, 29};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 16, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 25 14
new 0 25 14
assign 1 25 15
tag 1 25 15
return 1 25 16
assign 1 29 21
new 0 29 21
assign 1 29 22
sameObject 2 29 22
return 1 29 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1485820769: return bem_hashGet_0();
case -841536904: return bem_create_0();
case -1411238004: return bem_copy_0();
case 952781905: return bem_toString_0();
case 1491897585: return bem_iteratorGet_0();
case 1104924426: return bem_print_0();
case 527172959: return bem_new_0();
case 411577133: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -942389906: return bem_undef_1(bevd_0);
case -570393359: return bem_equals_1(bevd_0);
case 2139946505: return bem_copyTo_1(bevd_0);
case -1095224362: return bem_def_1(bevd_0);
case -764236216: return bem_getHash_1(bevd_0);
case -661822576: return bem_notEquals_1(bevd_0);
case -2098067152: return bem_print_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1603596126: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 130165321: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 492015902: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2061117733: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 764999888: return bem_isEqual_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(31, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_17_ContainerSetIdentityRelations();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst = (BEC_3_9_3_17_ContainerSetIdentityRelations) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;
}
}
