package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_BEC_2_4_8_TimeInterval_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_BEC_2_4_8_TimeInterval_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_3 = {0x3A};
public static BEC_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_inst;

public static BET_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_type;

public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt());
bevp_millis = (new BEC_2_4_3_MathInt());

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(60));
bevt_0_ta_ph = bevp_secs.bem_modulus_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(60));
bevt_0_ta_ph = bevp_secs.bem_divide_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(3600));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(86400));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(3600));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(86400));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_ta_ph);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 256*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevt_4_ta_ph = bevp_millis.bem_divide_1(bevt_5_ta_ph);
bevp_secs = bevp_secs.bem_add_1(bevt_4_ta_ph);
bevp_millis = bevl_mmod;
} /* Line: 258*/
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_millis.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_secs.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 260*/
 else /* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 260*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevp_millis = bevt_11_ta_ph.bem_add_1(bevp_millis);
} /* Line: 262*/
 else /* Line: 260*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_millis.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_secs.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 263*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_secs = bevp_secs.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevt_17_ta_ph = bevt_18_ta_ph.bem_subtract_1(bevt_19_ta_ph);
bevp_millis = bevt_17_ta_ph.bem_add_1(bevp_millis);
} /* Line: 265*/
} /* Line: 260*/
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 295*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 295*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 295*/
 else /* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 295*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 295*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 296*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 302*/
 else /* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 302*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 302*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 303*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 309*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 309*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 309*/
 else /* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 309*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 309*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 310*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 316*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 316*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 316*/
 else /* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 316*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 316*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 317*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevt_3_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameClass_2(this, beva_other);
if (bevt_2_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_5_ta_ph = beva_other.bemd_0(-143445327);
bevt_4_ta_ph = bevp_secs.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 323*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 323*/
 else /* Line: 323*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 323*/ {
bevt_7_ta_ph = beva_other.bemd_0(-1044401742);
bevt_6_ta_ph = bevp_millis.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 323*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 323*/
 else /* Line: 323*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 323*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_8_ta_ph;
} /* Line: 324*/
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevt_4_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_3_ta_ph = bevt_4_ta_ph.bem_sameClass_2(this, beva_other);
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 330*/ {
bevt_6_ta_ph = beva_other.bemd_0(-143445327);
bevt_5_ta_ph = bevp_secs.bem_notEquals_1(bevt_6_ta_ph);
if (bevt_5_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 330*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 330*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 330*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 330*/ {
bevt_8_ta_ph = beva_other.bemd_0(-1044401742);
bevt_7_ta_ph = bevp_millis.bem_notEquals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 330*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 330*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 330*/ {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_9_ta_ph;
} /* Line: 331*/
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
if (beva_other == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 338*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 338*/
bevt_3_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 339*/ {
bevt_7_ta_ph = beva_other.bem_secsGet_0();
bevt_6_ta_ph = bevp_secs.bem_subtract_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_abs_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(3600));
if (bevt_5_ta_ph.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 340*/ {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_9_ta_ph;
} /* Line: 341*/
} /* Line: 340*/
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_6_ta_ph = bem_minutesGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_toString_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_4_8_TimeInterval_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bem_secondInMinuteGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_millis);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_2));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_2_ta_ph = bevp_secs.bem_toString_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_8_TimeInterval_bels_3));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_millis.bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_4_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_secs.bem_toString_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_millis);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_2));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {136, 137, 183, 184, 190, 191, 192, 196, 196, 200, 200, 200, 204, 208, 208, 208, 212, 216, 220, 224, 225, 229, 229, 229, 233, 233, 233, 237, 237, 237, 241, 241, 241, 246, 250, 251, 255, 255, 256, 256, 257, 257, 257, 258, 260, 260, 260, 260, 260, 260, 0, 0, 0, 261, 261, 262, 262, 263, 263, 263, 263, 263, 263, 0, 0, 0, 264, 264, 265, 265, 265, 265, 270, 274, 275, 279, 279, 280, 280, 281, 282, 283, 287, 287, 288, 288, 289, 290, 291, 295, 295, 295, 0, 295, 295, 295, 295, 295, 295, 0, 0, 0, 0, 0, 296, 296, 298, 298, 302, 302, 302, 0, 302, 302, 302, 302, 302, 302, 0, 0, 0, 0, 0, 303, 303, 305, 305, 309, 309, 309, 0, 309, 309, 309, 309, 309, 309, 0, 0, 0, 0, 0, 310, 310, 312, 312, 316, 316, 316, 0, 316, 316, 316, 316, 316, 316, 0, 0, 0, 0, 0, 317, 317, 319, 319, 323, 323, 323, 323, 0, 0, 0, 323, 323, 0, 0, 0, 324, 324, 326, 326, 330, 330, 330, 330, 0, 330, 330, 0, 0, 0, 330, 330, 0, 0, 331, 331, 333, 333, 338, 338, 338, 338, 339, 339, 339, 340, 340, 340, 340, 340, 340, 341, 341, 344, 344, 348, 348, 348, 348, 348, 348, 348, 348, 348, 348, 348, 348, 352, 352, 352, 352, 352, 352, 356, 356, 356, 356, 356, 356, 356, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 27, 28, 32, 33, 34, 39, 40, 45, 46, 47, 50, 55, 56, 57, 60, 63, 67, 70, 71, 77, 78, 79, 85, 86, 87, 93, 94, 95, 101, 102, 103, 107, 111, 112, 137, 138, 139, 144, 145, 146, 147, 148, 150, 151, 156, 157, 158, 163, 164, 167, 171, 174, 175, 176, 177, 180, 181, 186, 187, 188, 193, 194, 197, 201, 204, 205, 206, 207, 208, 209, 215, 219, 220, 229, 230, 231, 232, 233, 234, 235, 243, 244, 245, 246, 247, 248, 249, 261, 262, 267, 268, 271, 272, 277, 278, 279, 284, 285, 288, 292, 295, 298, 302, 303, 305, 306, 318, 319, 324, 325, 328, 329, 334, 335, 336, 341, 342, 345, 349, 352, 355, 359, 360, 362, 363, 375, 376, 381, 382, 385, 386, 391, 392, 393, 398, 399, 402, 406, 409, 412, 416, 417, 419, 420, 432, 433, 438, 439, 442, 443, 448, 449, 450, 455, 456, 459, 463, 466, 469, 473, 474, 476, 477, 490, 491, 493, 494, 496, 499, 503, 506, 507, 509, 512, 516, 519, 520, 522, 523, 537, 538, 539, 544, 545, 548, 549, 551, 554, 558, 561, 562, 564, 567, 571, 572, 574, 575, 589, 594, 595, 596, 598, 599, 604, 605, 606, 607, 608, 609, 614, 615, 616, 619, 620, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 653, 654, 655, 656, 657, 658, 667, 668, 669, 670, 671, 672, 673, 676, 679, 683, 686};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 136 18
new 0 136 18
assign 1 137 19
new 0 137 19
assign 1 183 27
new 0 183 27
assign 1 184 28
new 0 184 28
assign 1 190 32
assign 1 191 33
carryMillis 0 192 34
assign 1 196 39
new 2 196 39
return 1 196 40
assign 1 200 45
new 0 200 45
assign 1 200 46
modulus 1 200 46
return 1 200 47
return 1 204 50
assign 1 208 55
new 0 208 55
assign 1 208 56
divide 1 208 56
return 1 208 57
return 1 212 60
assign 1 216 63
return 1 220 67
assign 1 224 70
carryMillis 0 225 71
assign 1 229 77
new 0 229 77
assign 1 229 78
multiply 1 229 78
assign 1 229 79
add 1 229 79
assign 1 233 85
new 0 233 85
assign 1 233 86
multiply 1 233 86
assign 1 233 87
add 1 233 87
assign 1 237 93
new 0 237 93
assign 1 237 94
multiply 1 237 94
assign 1 237 95
subtract 1 237 95
assign 1 241 101
new 0 241 101
assign 1 241 102
multiply 1 241 102
assign 1 241 103
subtract 1 241 103
assign 1 246 107
add 1 246 107
assign 1 250 111
add 1 250 111
carryMillis 0 251 112
assign 1 255 137
new 0 255 137
assign 1 255 138
modulus 1 255 138
assign 1 256 139
notEquals 1 256 144
assign 1 257 145
new 0 257 145
assign 1 257 146
divide 1 257 146
assign 1 257 147
add 1 257 147
assign 1 258 148
assign 1 260 150
new 0 260 150
assign 1 260 151
lesser 1 260 156
assign 1 260 157
new 0 260 157
assign 1 260 158
greater 1 260 163
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 261 174
new 0 261 174
assign 1 261 175
subtract 1 261 175
assign 1 262 176
new 0 262 176
assign 1 262 177
add 1 262 177
assign 1 263 180
new 0 263 180
assign 1 263 181
greater 1 263 186
assign 1 263 187
new 0 263 187
assign 1 263 188
lesser 1 263 193
assign 1 0 194
assign 1 0 197
assign 1 0 201
assign 1 264 204
new 0 264 204
assign 1 264 205
add 1 264 205
assign 1 265 206
new 0 265 206
assign 1 265 207
new 0 265 207
assign 1 265 208
subtract 1 265 208
assign 1 265 209
add 1 265 209
assign 1 270 215
subtract 1 270 215
assign 1 274 219
subtract 1 274 219
carryMillis 0 275 220
assign 1 279 229
secsGet 0 279 229
assign 1 279 230
add 1 279 230
assign 1 280 231
millisGet 0 280 231
assign 1 280 232
add 1 280 232
assign 1 281 233
new 2 281 233
carryMillis 0 282 234
return 1 283 235
assign 1 287 243
secsGet 0 287 243
assign 1 287 244
subtract 1 287 244
assign 1 288 245
millisGet 0 288 245
assign 1 288 246
subtract 1 288 246
assign 1 289 247
new 2 289 247
carryMillis 0 290 248
return 1 291 249
assign 1 295 261
secsGet 0 295 261
assign 1 295 262
greater 1 295 267
assign 1 0 268
assign 1 295 271
secsGet 0 295 271
assign 1 295 272
equals 1 295 277
assign 1 295 278
millisGet 0 295 278
assign 1 295 279
greater 1 295 284
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 0 295
assign 1 0 298
assign 1 296 302
new 0 296 302
return 1 296 303
assign 1 298 305
new 0 298 305
return 1 298 306
assign 1 302 318
secsGet 0 302 318
assign 1 302 319
lesser 1 302 324
assign 1 0 325
assign 1 302 328
secsGet 0 302 328
assign 1 302 329
equals 1 302 334
assign 1 302 335
millisGet 0 302 335
assign 1 302 336
lesser 1 302 341
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 0 352
assign 1 0 355
assign 1 303 359
new 0 303 359
return 1 303 360
assign 1 305 362
new 0 305 362
return 1 305 363
assign 1 309 375
secsGet 0 309 375
assign 1 309 376
greaterEquals 1 309 381
assign 1 0 382
assign 1 309 385
secsGet 0 309 385
assign 1 309 386
equals 1 309 391
assign 1 309 392
millisGet 0 309 392
assign 1 309 393
greaterEquals 1 309 398
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 0 409
assign 1 0 412
assign 1 310 416
new 0 310 416
return 1 310 417
assign 1 312 419
new 0 312 419
return 1 312 420
assign 1 316 432
secsGet 0 316 432
assign 1 316 433
lesserEquals 1 316 438
assign 1 0 439
assign 1 316 442
secsGet 0 316 442
assign 1 316 443
equals 1 316 448
assign 1 316 449
millisGet 0 316 449
assign 1 316 450
lesserEquals 1 316 455
assign 1 0 456
assign 1 0 459
assign 1 0 463
assign 1 0 466
assign 1 0 469
assign 1 317 473
new 0 317 473
return 1 317 474
assign 1 319 476
new 0 319 476
return 1 319 477
assign 1 323 490
new 0 323 490
assign 1 323 491
sameClass 2 323 491
assign 1 323 493
secsGet 0 323 493
assign 1 323 494
equals 1 323 494
assign 1 0 496
assign 1 0 499
assign 1 0 503
assign 1 323 506
millisGet 0 323 506
assign 1 323 507
equals 1 323 507
assign 1 0 509
assign 1 0 512
assign 1 0 516
assign 1 324 519
new 0 324 519
return 1 324 520
assign 1 326 522
new 0 326 522
return 1 326 523
assign 1 330 537
new 0 330 537
assign 1 330 538
sameClass 2 330 538
assign 1 330 539
not 0 330 544
assign 1 0 545
assign 1 330 548
secsGet 0 330 548
assign 1 330 549
notEquals 1 330 549
assign 1 0 551
assign 1 0 554
assign 1 0 558
assign 1 330 561
millisGet 0 330 561
assign 1 330 562
notEquals 1 330 562
assign 1 0 564
assign 1 0 567
assign 1 331 571
new 0 331 571
return 1 331 572
assign 1 333 574
new 0 333 574
return 1 333 575
assign 1 338 589
undef 1 338 594
assign 1 338 595
new 0 338 595
return 1 338 596
assign 1 339 598
millisGet 0 339 598
assign 1 339 599
equals 1 339 604
assign 1 340 605
secsGet 0 340 605
assign 1 340 606
subtract 1 340 606
assign 1 340 607
abs 0 340 607
assign 1 340 608
new 0 340 608
assign 1 340 609
equals 1 340 614
assign 1 341 615
new 0 341 615
return 1 341 616
assign 1 344 619
new 0 344 619
return 1 344 620
assign 1 348 634
minutesGet 0 348 634
assign 1 348 635
toString 0 348 635
assign 1 348 636
new 0 348 636
assign 1 348 637
add 1 348 637
assign 1 348 638
secondInMinuteGet 0 348 638
assign 1 348 639
add 1 348 639
assign 1 348 640
new 0 348 640
assign 1 348 641
add 1 348 641
assign 1 348 642
add 1 348 642
assign 1 348 643
new 0 348 643
assign 1 348 644
add 1 348 644
return 1 348 645
assign 1 352 653
toString 0 352 653
assign 1 352 654
new 0 352 654
assign 1 352 655
add 1 352 655
assign 1 352 656
toString 0 352 656
assign 1 352 657
add 1 352 657
return 1 352 658
assign 1 356 667
toString 0 356 667
assign 1 356 668
new 0 356 668
assign 1 356 669
add 1 356 669
assign 1 356 670
add 1 356 670
assign 1 356 671
new 0 356 671
assign 1 356 672
add 1 356 672
return 1 356 673
return 1 0 676
assign 1 0 679
return 1 0 683
assign 1 0 686
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1894777661: return bem_toStringMinutes_0();
case -771773921: return bem_millisecondInSecondGet_0();
case -434987524: return bem_create_0();
case 1965570533: return bem_new_0();
case 844352133: return bem_print_0();
case 89136811: return bem_toString_0();
case 1606224499: return bem_copy_0();
case -1044401742: return bem_millisGet_0();
case 239401675: return bem_toShortString_0();
case 2002456993: return bem_now_0();
case 2052608635: return bem_secondInMinuteGet_0();
case 466983680: return bem_minutesGet_0();
case -2121873045: return bem_secondsGet_0();
case -143445327: return bem_secsGet_0();
case -1296037393: return bem_hashGet_0();
case 648209310: return bem_iteratorGet_0();
case -13915213: return bem_carryMillis_0();
case 756960852: return bem_millisecondsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1358314057: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1965477890: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1618008185: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1983365705: return bem_millisSet_1(bevd_0);
case 798861597: return bem_def_1(bevd_0);
case 1904207885: return bem_copyTo_1(bevd_0);
case 1285969815: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case -387985762: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1624268857: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1442099156: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1040749493: return bem_print_1(bevd_0);
case -1081509381: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case 280333967: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1931957804: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1472037761: return bem_equals_1(bevd_0);
case -1303238515: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1861427641: return bem_secsSet_1(bevd_0);
case 990150127: return bem_notEquals_1(bevd_0);
case 907676103: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1772322315: return bem_undef_1(bevd_0);
case 1654961083: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1636469384: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case 2009282999: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case -18475172: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1924907385: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 218003446: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -831105015: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 21939251: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1538258101: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1748717736: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_TimeInterval_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_8_TimeInterval_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst = (BEC_2_4_8_TimeInterval) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_type;
}
}
