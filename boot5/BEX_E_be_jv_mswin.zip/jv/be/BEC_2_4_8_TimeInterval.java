package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_BEC_2_4_8_TimeInterval_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_BEC_2_4_8_TimeInterval_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_0 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_1 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_2 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_3 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_4 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_5 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_6 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_7 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_11 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_14 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_15 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_16 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_17 = (new BEC_2_4_3_MathInt(3600));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_0, 10));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_1, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_2, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_3 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_3, 1));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_4 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_4, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_5 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_5, 13));
public static BEC_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_inst;

public static BET_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_type;

public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt());
bevp_millis = (new BEC_2_4_3_MathInt());

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_0;
bevt_0_tmpany_phold = bevp_secs.bem_modulus_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_1;
bevt_0_tmpany_phold = bevp_secs.bem_divide_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_2;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_3;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_5;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_6;
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_tmpany_phold);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_7;
bevt_4_tmpany_phold = bevp_millis.bem_divide_1(bevt_5_tmpany_phold);
bevp_secs = bevp_secs.bem_add_1(bevt_4_tmpany_phold);
bevp_millis = bevl_mmod;
} /* Line: 242 */
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_8;
if (bevp_millis.bevi_int < bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 244 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_9;
if (bevp_secs.bevi_int > bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 244 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 244 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 244 */
 else  /* Line: 244 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 244 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_10;
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_11;
bevp_millis = bevt_11_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 246 */
 else  /* Line: 244 */ {
bevt_13_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_12;
if (bevp_millis.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_13;
if (bevp_secs.bevi_int < bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 247 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 247 */
 else  /* Line: 247 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 247 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_14;
bevp_secs = bevp_secs.bem_add_1(bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_15;
bevt_19_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_16;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_subtract_1(bevt_19_tmpany_phold);
bevp_millis = bevt_17_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 249 */
} /* Line: 244 */
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 279 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 279 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 279 */
 else  /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 279 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 279 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 280 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 286 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 287 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 293 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 293 */
 else  /* Line: 293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 293 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 293 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 294 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 300 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 301 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevt_4_tmpany_phold = beva_other.bemd_0(-559462047);
bevt_3_tmpany_phold = bevp_secs.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 307 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 307 */
 else  /* Line: 307 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 307 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-42627929);
bevt_5_tmpany_phold = bevp_millis.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 307 */
 else  /* Line: 307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 307 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 308 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(-559462047);
bevt_4_tmpany_phold = bevp_secs.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 314 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(-42627929);
bevt_6_tmpany_phold = bevp_millis.bem_notEquals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 314 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_8_tmpany_phold;
} /* Line: 315 */
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
if (beva_other == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 322 */
bevt_3_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_7_tmpany_phold = beva_other.bem_secsGet_0();
bevt_6_tmpany_phold = bevp_secs.bem_subtract_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_abs_0();
bevt_8_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_17;
if (bevt_5_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 324 */ {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_9_tmpany_phold;
} /* Line: 325 */
} /* Line: 324 */
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_6_tmpany_phold = bem_minutesGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_toString_0();
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_18;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bem_secondInMinuteGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_19;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_20;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_secs.bem_toString_0();
bevt_3_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_21;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_millis.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_secs.bem_toString_0();
bevt_4_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_secsGetDirect_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_secsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public final BEC_2_4_3_MathInt bem_millisGetDirect_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_millisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {120, 121, 167, 168, 174, 175, 176, 180, 180, 184, 184, 184, 188, 192, 192, 192, 196, 200, 204, 208, 209, 213, 213, 213, 217, 217, 217, 221, 221, 221, 225, 225, 225, 230, 234, 235, 239, 239, 240, 240, 241, 241, 241, 242, 244, 244, 244, 244, 244, 244, 0, 0, 0, 245, 245, 246, 246, 247, 247, 247, 247, 247, 247, 0, 0, 0, 248, 248, 249, 249, 249, 249, 254, 258, 259, 263, 263, 264, 264, 265, 266, 267, 271, 271, 272, 272, 273, 274, 275, 279, 279, 279, 0, 279, 279, 279, 279, 279, 279, 0, 0, 0, 0, 0, 280, 280, 282, 282, 286, 286, 286, 0, 286, 286, 286, 286, 286, 286, 0, 0, 0, 0, 0, 287, 287, 289, 289, 293, 293, 293, 0, 293, 293, 293, 293, 293, 293, 0, 0, 0, 0, 0, 294, 294, 296, 296, 300, 300, 300, 0, 300, 300, 300, 300, 300, 300, 0, 0, 0, 0, 0, 301, 301, 303, 303, 307, 307, 307, 0, 0, 0, 307, 307, 0, 0, 0, 308, 308, 310, 310, 314, 314, 314, 0, 314, 314, 0, 0, 0, 314, 314, 0, 0, 315, 315, 317, 317, 322, 322, 322, 322, 323, 323, 323, 324, 324, 324, 324, 324, 324, 325, 325, 328, 328, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 336, 336, 336, 336, 336, 336, 340, 340, 340, 340, 340, 340, 340, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 53, 54, 58, 59, 60, 65, 66, 71, 72, 73, 76, 81, 82, 83, 86, 89, 93, 96, 97, 103, 104, 105, 111, 112, 113, 119, 120, 121, 127, 128, 129, 133, 137, 138, 163, 164, 165, 170, 171, 172, 173, 174, 176, 177, 182, 183, 184, 189, 190, 193, 197, 200, 201, 202, 203, 206, 207, 212, 213, 214, 219, 220, 223, 227, 230, 231, 232, 233, 234, 235, 241, 245, 246, 255, 256, 257, 258, 259, 260, 261, 269, 270, 271, 272, 273, 274, 275, 287, 288, 293, 294, 297, 298, 303, 304, 305, 310, 311, 314, 318, 321, 324, 328, 329, 331, 332, 344, 345, 350, 351, 354, 355, 360, 361, 362, 367, 368, 371, 375, 378, 381, 385, 386, 388, 389, 401, 402, 407, 408, 411, 412, 417, 418, 419, 424, 425, 428, 432, 435, 438, 442, 443, 445, 446, 458, 459, 464, 465, 468, 469, 474, 475, 476, 481, 482, 485, 489, 492, 495, 499, 500, 502, 503, 515, 517, 518, 520, 523, 527, 530, 531, 533, 536, 540, 543, 544, 546, 547, 560, 561, 566, 567, 570, 571, 573, 576, 580, 583, 584, 586, 589, 593, 594, 596, 597, 611, 616, 617, 618, 620, 621, 626, 627, 628, 629, 630, 631, 636, 637, 638, 641, 642, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 675, 676, 677, 678, 679, 680, 689, 690, 691, 692, 693, 694, 695, 698, 701, 704, 708, 712, 715, 718, 722};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 120 44
new 0 120 44
assign 1 121 45
new 0 121 45
assign 1 167 53
new 0 167 53
assign 1 168 54
new 0 168 54
assign 1 174 58
assign 1 175 59
carryMillis 0 176 60
assign 1 180 65
new 2 180 65
return 1 180 66
assign 1 184 71
new 0 184 71
assign 1 184 72
modulus 1 184 72
return 1 184 73
return 1 188 76
assign 1 192 81
new 0 192 81
assign 1 192 82
divide 1 192 82
return 1 192 83
return 1 196 86
assign 1 200 89
return 1 204 93
assign 1 208 96
carryMillis 0 209 97
assign 1 213 103
new 0 213 103
assign 1 213 104
multiply 1 213 104
assign 1 213 105
add 1 213 105
assign 1 217 111
new 0 217 111
assign 1 217 112
multiply 1 217 112
assign 1 217 113
add 1 217 113
assign 1 221 119
new 0 221 119
assign 1 221 120
multiply 1 221 120
assign 1 221 121
subtract 1 221 121
assign 1 225 127
new 0 225 127
assign 1 225 128
multiply 1 225 128
assign 1 225 129
subtract 1 225 129
assign 1 230 133
add 1 230 133
assign 1 234 137
add 1 234 137
carryMillis 0 235 138
assign 1 239 163
new 0 239 163
assign 1 239 164
modulus 1 239 164
assign 1 240 165
notEquals 1 240 170
assign 1 241 171
new 0 241 171
assign 1 241 172
divide 1 241 172
assign 1 241 173
add 1 241 173
assign 1 242 174
assign 1 244 176
new 0 244 176
assign 1 244 177
lesser 1 244 182
assign 1 244 183
new 0 244 183
assign 1 244 184
greater 1 244 189
assign 1 0 190
assign 1 0 193
assign 1 0 197
assign 1 245 200
new 0 245 200
assign 1 245 201
subtract 1 245 201
assign 1 246 202
new 0 246 202
assign 1 246 203
add 1 246 203
assign 1 247 206
new 0 247 206
assign 1 247 207
greater 1 247 212
assign 1 247 213
new 0 247 213
assign 1 247 214
lesser 1 247 219
assign 1 0 220
assign 1 0 223
assign 1 0 227
assign 1 248 230
new 0 248 230
assign 1 248 231
add 1 248 231
assign 1 249 232
new 0 249 232
assign 1 249 233
new 0 249 233
assign 1 249 234
subtract 1 249 234
assign 1 249 235
add 1 249 235
assign 1 254 241
subtract 1 254 241
assign 1 258 245
subtract 1 258 245
carryMillis 0 259 246
assign 1 263 255
secsGet 0 263 255
assign 1 263 256
add 1 263 256
assign 1 264 257
millisGet 0 264 257
assign 1 264 258
add 1 264 258
assign 1 265 259
new 2 265 259
carryMillis 0 266 260
return 1 267 261
assign 1 271 269
secsGet 0 271 269
assign 1 271 270
subtract 1 271 270
assign 1 272 271
millisGet 0 272 271
assign 1 272 272
subtract 1 272 272
assign 1 273 273
new 2 273 273
carryMillis 0 274 274
return 1 275 275
assign 1 279 287
secsGet 0 279 287
assign 1 279 288
greater 1 279 293
assign 1 0 294
assign 1 279 297
secsGet 0 279 297
assign 1 279 298
equals 1 279 303
assign 1 279 304
millisGet 0 279 304
assign 1 279 305
greater 1 279 310
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 0 321
assign 1 0 324
assign 1 280 328
new 0 280 328
return 1 280 329
assign 1 282 331
new 0 282 331
return 1 282 332
assign 1 286 344
secsGet 0 286 344
assign 1 286 345
lesser 1 286 350
assign 1 0 351
assign 1 286 354
secsGet 0 286 354
assign 1 286 355
equals 1 286 360
assign 1 286 361
millisGet 0 286 361
assign 1 286 362
lesser 1 286 367
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 0 378
assign 1 0 381
assign 1 287 385
new 0 287 385
return 1 287 386
assign 1 289 388
new 0 289 388
return 1 289 389
assign 1 293 401
secsGet 0 293 401
assign 1 293 402
greaterEquals 1 293 407
assign 1 0 408
assign 1 293 411
secsGet 0 293 411
assign 1 293 412
equals 1 293 417
assign 1 293 418
millisGet 0 293 418
assign 1 293 419
greaterEquals 1 293 424
assign 1 0 425
assign 1 0 428
assign 1 0 432
assign 1 0 435
assign 1 0 438
assign 1 294 442
new 0 294 442
return 1 294 443
assign 1 296 445
new 0 296 445
return 1 296 446
assign 1 300 458
secsGet 0 300 458
assign 1 300 459
lesserEquals 1 300 464
assign 1 0 465
assign 1 300 468
secsGet 0 300 468
assign 1 300 469
equals 1 300 474
assign 1 300 475
millisGet 0 300 475
assign 1 300 476
lesserEquals 1 300 481
assign 1 0 482
assign 1 0 485
assign 1 0 489
assign 1 0 492
assign 1 0 495
assign 1 301 499
new 0 301 499
return 1 301 500
assign 1 303 502
new 0 303 502
return 1 303 503
assign 1 307 515
sameClass 1 307 515
assign 1 307 517
secsGet 0 307 517
assign 1 307 518
equals 1 307 518
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 307 530
millisGet 0 307 530
assign 1 307 531
equals 1 307 531
assign 1 0 533
assign 1 0 536
assign 1 0 540
assign 1 308 543
new 0 308 543
return 1 308 544
assign 1 310 546
new 0 310 546
return 1 310 547
assign 1 314 560
sameClass 1 314 560
assign 1 314 561
not 0 314 566
assign 1 0 567
assign 1 314 570
secsGet 0 314 570
assign 1 314 571
notEquals 1 314 571
assign 1 0 573
assign 1 0 576
assign 1 0 580
assign 1 314 583
millisGet 0 314 583
assign 1 314 584
notEquals 1 314 584
assign 1 0 586
assign 1 0 589
assign 1 315 593
new 0 315 593
return 1 315 594
assign 1 317 596
new 0 317 596
return 1 317 597
assign 1 322 611
undef 1 322 616
assign 1 322 617
new 0 322 617
return 1 322 618
assign 1 323 620
millisGet 0 323 620
assign 1 323 621
equals 1 323 626
assign 1 324 627
secsGet 0 324 627
assign 1 324 628
subtract 1 324 628
assign 1 324 629
abs 0 324 629
assign 1 324 630
new 0 324 630
assign 1 324 631
equals 1 324 636
assign 1 325 637
new 0 325 637
return 1 325 638
assign 1 328 641
new 0 328 641
return 1 328 642
assign 1 332 656
minutesGet 0 332 656
assign 1 332 657
toString 0 332 657
assign 1 332 658
new 0 332 658
assign 1 332 659
add 1 332 659
assign 1 332 660
secondInMinuteGet 0 332 660
assign 1 332 661
add 1 332 661
assign 1 332 662
new 0 332 662
assign 1 332 663
add 1 332 663
assign 1 332 664
add 1 332 664
assign 1 332 665
new 0 332 665
assign 1 332 666
add 1 332 666
return 1 332 667
assign 1 336 675
toString 0 336 675
assign 1 336 676
new 0 336 676
assign 1 336 677
add 1 336 677
assign 1 336 678
toString 0 336 678
assign 1 336 679
add 1 336 679
return 1 336 680
assign 1 340 689
toString 0 340 689
assign 1 340 690
new 0 340 690
assign 1 340 691
add 1 340 691
assign 1 340 692
add 1 340 692
assign 1 340 693
new 0 340 693
assign 1 340 694
add 1 340 694
return 1 340 695
return 1 0 698
return 1 0 701
assign 1 0 704
assign 1 0 708
return 1 0 712
return 1 0 715
assign 1 0 718
assign 1 0 722
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1439777293: return bem_hashGet_0();
case 1897186389: return bem_minutesGet_0();
case -2139786: return bem_carryMillis_0();
case -1476019175: return bem_toString_0();
case 1935136194: return bem_classNameGet_0();
case 742371580: return bem_serializeToString_0();
case 1516161879: return bem_fieldNamesGet_0();
case -2021714064: return bem_millisGetDirect_0();
case -518161494: return bem_secsGetDirect_0();
case -1750213491: return bem_sourceFileNameGet_0();
case -2070113098: return bem_create_0();
case 543051864: return bem_secondInMinuteGet_0();
case 1644869182: return bem_millisecondsGet_0();
case 305815169: return bem_secondsGet_0();
case -61288189: return bem_serializationIteratorGet_0();
case 1660533487: return bem_serializeContents_0();
case -1985363564: return bem_millisecondInSecondGet_0();
case -559462047: return bem_secsGet_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case 1730802409: return bem_echo_0();
case 1326542704: return bem_tagGet_0();
case -948982310: return bem_many_0();
case 1070146794: return bem_toAny_0();
case 450230894: return bem_print_0();
case 413318617: return bem_toShortString_0();
case 623957818: return bem_once_0();
case -868772069: return bem_toStringMinutes_0();
case -42627929: return bem_millisGet_0();
case -2073027086: return bem_fieldIteratorGet_0();
case -897350462: return bem_iteratorGet_0();
case 1172450247: return bem_copy_0();
case -407684149: return bem_now_0();
case -1556712456: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -392766553: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case -1263371507: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case -1228260492: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1341444048: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -299391132: return bem_equals_1(bevd_0);
case -1429139495: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case -1992816904: return bem_millisSet_1(bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case 1302909926: return bem_secsSet_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case 542889232: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -63995573: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case 548118099: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case 1488950924: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1015783073: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case -69544724: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -250991806: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case -356807359: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case -1607946754: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -663888986: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case 226752160: return bem_secsSetDirect_1(bevd_0);
case 562467906: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case -957438933: return bem_undef_1(bevd_0);
case 1413659688: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case -847081537: return bem_millisSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 402557382: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_TimeInterval_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_8_TimeInterval_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst = (BEC_2_4_8_TimeInterval) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_type;
}
}
