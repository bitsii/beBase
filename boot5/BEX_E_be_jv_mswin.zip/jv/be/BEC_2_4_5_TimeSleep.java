package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeSleep extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_TimeSleep() { }
private static byte[] becc_BEC_2_4_5_TimeSleep_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x6C,0x65,0x65,0x70};
private static byte[] becc_BEC_2_4_5_TimeSleep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
public static BEC_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_inst;

public static BET_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_type;

public BEC_2_4_5_TimeSleep bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_sleep_1(BEC_2_4_8_TimeInterval beva_interval) throws Throwable {
BEC_2_4_3_MathInt bevl_secs = null;
BEC_2_4_3_MathInt bevl_millis = null;
BEC_2_4_3_MathInt bevl_sleepMillis = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
if (beva_interval == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 34*/ {
bevl_secs = beva_interval.bem_secsGet_0();
bevl_millis = beva_interval.bem_millisGet_0();
if (bevl_secs == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 37*/ {
if (bevl_millis == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 37*/
 else /* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 37*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevt_4_ta_ph = bevl_secs.bem_multiply_1(bevt_5_ta_ph);
bevl_sleepMillis = bevt_4_ta_ph.bem_add_1(bevl_millis);
bem_sleepMilliseconds_1(bevl_sleepMillis);
} /* Line: 39*/
} /* Line: 37*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sleepSeconds_1(BEC_2_4_3_MathInt beva_secs) throws Throwable {
BEC_2_4_5_TimeSleep bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevt_1_ta_ph = beva_secs.bem_multiply_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_sleepMilliseconds_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_sleepMilliseconds_1(BEC_2_4_3_MathInt beva_msecs) throws Throwable {
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;

      Thread.sleep(beva_msecs.bevi_int);
      /* Line: 86*/ {
} /* Line: 87*/
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {34, 34, 35, 36, 37, 37, 37, 37, 0, 0, 0, 38, 38, 38, 39, 45, 45, 45, 45};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {27, 32, 33, 34, 35, 40, 41, 46, 47, 50, 54, 57, 58, 59, 60, 69, 70, 71, 72};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 34 27
def 1 34 32
assign 1 35 33
secsGet 0 35 33
assign 1 36 34
millisGet 0 36 34
assign 1 37 35
def 1 37 40
assign 1 37 41
def 1 37 46
assign 1 0 47
assign 1 0 50
assign 1 0 54
assign 1 38 57
new 0 38 57
assign 1 38 58
multiply 1 38 58
assign 1 38 59
add 1 38 59
sleepMilliseconds 1 39 60
assign 1 45 69
new 0 45 69
assign 1 45 70
multiply 1 45 70
assign 1 45 71
sleepMilliseconds 1 45 71
return 1 45 72
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -568575955: return bem_hashGet_0();
case -1350802630: return bem_default_0();
case -220602072: return bem_echo_0();
case 774721401: return bem_serializeToString_0();
case 881754957: return bem_deserializeClassNameGet_0();
case -674491561: return bem_sourceFileNameGet_0();
case -829315536: return bem_classNameGet_0();
case -1111250456: return bem_fieldNamesGet_0();
case 234248288: return bem_copy_0();
case -437991849: return bem_toString_0();
case -763928014: return bem_create_0();
case -419834598: return bem_print_0();
case -1814783732: return bem_serializationIteratorGet_0();
case -18123974: return bem_new_0();
case 1087832621: return bem_tagGet_0();
case 2087607686: return bem_iteratorGet_0();
case 1126911928: return bem_serializeContents_0();
case -1454950260: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -643713889: return bem_notEquals_1(bevd_0);
case 1511182082: return bem_sleepMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
case -1945243281: return bem_sleep_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 760934725: return bem_sleepSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeSleep_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeSleep_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_TimeSleep();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst = (BEC_2_4_5_TimeSleep) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_type;
}
}
