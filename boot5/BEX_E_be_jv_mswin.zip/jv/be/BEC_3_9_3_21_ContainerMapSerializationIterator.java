package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerMapSerializationIterator extends BEC_3_9_3_16_ContainerMapKeyValueIterator {
public BEC_3_9_3_21_ContainerMapSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;

public static BET_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_contents;
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_contents = (new BEC_2_9_4_ContainerList()).bem_new_0();
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 543*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 543*/ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 543*/
 else /* Line: 543*/ {
break;
} /* Line: 543*/
} /* Line: 543*/
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_postDeserialize_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_key = null;
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevl_map = (BEC_2_9_3_ContainerMap) bevp_set;
bevl_iter = bevp_contents.bem_iteratorGet_0();
while (true)
/* Line: 551*/ {
bevt_0_ta_ph = bevl_iter.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 551*/ {
bevl_key = bevl_iter.bemd_0(900728463);
bevl_value = bevl_iter.bemd_0(900728463);
bevl_map.bem_put_2(bevl_key, bevl_value);
} /* Line: 554*/
 else /* Line: 551*/ {
break;
} /* Line: 551*/
} /* Line: 551*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {533, 535, 539, 543, 543, 543, 544, 543, 549, 550, 551, 552, 553, 554, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 24, 27, 32, 33, 34, 48, 49, 52, 54, 55, 56, 65, 68};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 533 13
new 0 533 13
new 1 535 14
addValue 1 539 18
assign 1 543 24
new 0 543 24
assign 1 543 27
lesser 1 543 32
nextSet 1 544 33
assign 1 543 34
increment 0 543 34
assign 1 549 48
assign 1 550 49
iteratorGet 0 550 49
assign 1 551 52
hasNextGet 0 551 52
assign 1 552 54
nextGet 0 552 54
assign 1 553 55
nextGet 0 553 55
put 2 554 56
return 1 0 65
assign 1 0 68
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 668645503: return bem_new_0();
case -642025972: return bem_hasNextGet_0();
case -928482332: return bem_delete_0();
case 900728463: return bem_nextGet_0();
case -1157114031: return bem_containerGet_0();
case -161809366: return bem_copy_0();
case 1869720044: return bem_nodeIteratorIteratorGet_0();
case -508717313: return bem_create_0();
case 1264820508: return bem_postDeserialize_0();
case 1401626610: return bem_print_0();
case 969005479: return bem_toString_0();
case -1877988678: return bem_hashGet_0();
case 326916018: return bem_iteratorGet_0();
case -10551358: return bem_contentsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 422058995: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 2003865090: return bem_nextSet_1(bevd_0);
case -737317282: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 759307103: return bem_contentsSet_1(bevd_0);
case 939305500: return bem_def_1(bevd_0);
case -1391871629: return bem_undef_1(bevd_0);
case 384220308: return bem_notEquals_1(bevd_0);
case 567335501: return bem_equals_1(bevd_0);
case -1581048634: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 163536847: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 72722300: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1961786723: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2046340809: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_21_ContainerMapSerializationIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerMapSerializationIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;
}
}
