package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerMapSerializationIterator extends BEC_3_9_3_16_ContainerMapKeyValueIterator {
public BEC_3_9_3_21_ContainerMapSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;

public static BET_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_contents;
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_contents = (new BEC_2_9_4_ContainerList()).bem_new_0();
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 533*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 533*/ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 533*/
 else /* Line: 533*/ {
break;
} /* Line: 533*/
} /* Line: 533*/
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_postDeserialize_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_key = null;
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevl_map = (BEC_2_9_3_ContainerMap) bevp_set;
bevl_iter = bevp_contents.bem_iteratorGet_0();
while (true)
/* Line: 541*/ {
bevt_0_ta_ph = bevl_iter.bemd_0(1757263953);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 541*/ {
bevl_key = bevl_iter.bemd_0(1982151412);
bevl_value = bevl_iter.bemd_0(1982151412);
bevl_map.bem_put_2(bevl_key, bevl_value);
} /* Line: 544*/
 else /* Line: 541*/ {
break;
} /* Line: 541*/
} /* Line: 541*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_contentsGetDirect_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {523, 525, 529, 533, 533, 533, 534, 533, 539, 540, 541, 542, 543, 544, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 24, 27, 32, 33, 34, 48, 49, 52, 54, 55, 56, 65, 68, 71, 75};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 523 13
new 0 523 13
new 1 525 14
addValue 1 529 18
assign 1 533 24
new 0 533 24
assign 1 533 27
lesser 1 533 32
nextSet 1 534 33
assign 1 533 34
increment 0 533 34
assign 1 539 48
assign 1 540 49
iteratorGet 0 540 49
assign 1 541 52
hasNextGet 0 541 52
assign 1 542 54
nextGet 0 542 54
assign 1 543 55
nextGet 0 543 55
put 2 544 56
return 1 0 65
return 1 0 68
assign 1 0 71
assign 1 0 75
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -388378458: return bem_onNodeGetDirect_0();
case 1982151412: return bem_nextGet_0();
case -1232819452: return bem_moduGetDirect_0();
case 2017511263: return bem_onNodeGet_0();
case -1313579429: return bem_contentsGet_0();
case -675209112: return bem_delete_0();
case -1740213654: return bem_currentGet_0();
case -22788464: return bem_hashGet_0();
case 1726896959: return bem_setGet_0();
case 38127485: return bem_iteratorGet_0();
case 1739213981: return bem_bucketsGetDirect_0();
case -1743185835: return bem_postDeserialize_0();
case 1800929528: return bem_nodeIteratorIteratorGet_0();
case 1847639727: return bem_new_0();
case -1302738888: return bem_moduGet_0();
case 854710191: return bem_create_0();
case -1331374769: return bem_toString_0();
case 793589441: return bem_classNameGet_0();
case -1621725343: return bem_bucketsGet_0();
case 636345: return bem_print_0();
case 2061432375: return bem_tagGet_0();
case 15786277: return bem_currentGetDirect_0();
case -852531685: return bem_setGetDirect_0();
case -1508036637: return bem_copy_0();
case 1314388618: return bem_containerGet_0();
case 1757263953: return bem_hasNextGet_0();
case -593469656: return bem_sourceFileNameGet_0();
case 1834636744: return bem_contentsGetDirect_0();
case -1818293830: return bem_fieldNamesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 70054218: return bem_currentSetDirect_1(bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
case -2070635974: return bem_setSet_1(bevd_0);
case -938687463: return bem_contentsSet_1(bevd_0);
case 2110536639: return bem_contentsSetDirect_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case 1318108394: return bem_moduSetDirect_1(bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
case -502376443: return bem_equals_1(bevd_0);
case -785087004: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1835589679: return bem_bucketsSetDirect_1(bevd_0);
case 882589836: return bem_sameObject_1(bevd_0);
case -404287636: return bem_moduSet_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case 1094539333: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -1833968334: return bem_onNodeSetDirect_1(bevd_0);
case 555154968: return bem_onNodeSet_1(bevd_0);
case -784981258: return bem_bucketsSet_1(bevd_0);
case 1281048000: return bem_notEquals_1(bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case 1790420379: return bem_setSetDirect_1(bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case -1636333278: return bem_nextSet_1(bevd_0);
case 400909945: return bem_currentSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_21_ContainerMapSerializationIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerMapSerializationIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;
}
}
