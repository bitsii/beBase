package be;
/* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject extends be.BECS_Object {
public BEC_2_6_6_SystemObject() { }

   public BEC_2_6_6_SystemObject bems_methodNotDefined(String name, BEC_2_6_6_SystemObject[] args) throws Throwable { 
     name = name.substring(0, name.lastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(name.getBytes("UTF-8")), new BEC_2_9_4_ContainerList(args));
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x5F};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67};
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public BEC_2_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_6_SystemObject_bels_0));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_name);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_6_6_SystemObject_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 45*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 50*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_6_SystemObject_bels_0));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_name);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_6_6_SystemObject_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 51*/
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_2));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 61*/
if (beva_args == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 63*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_3));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 64*/
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
/* Line: 72*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_numargs.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(7));
bevt_11_ta_ph = bevl_numargs.bem_subtract_1(bevt_12_ta_ph);
bevl_args2 = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(7));
while (true)
/* Line: 75*/ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 75*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(7));
bevt_14_ta_ph = bevl_i.bem_subtract_1(bevt_15_ta_ph);
bevt_16_ta_ph = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_ta_ph, bevt_16_ta_ph);
bevl_i.bevi_int++;
} /* Line: 75*/
 else /* Line: 75*/ {
break;
} /* Line: 75*/
} /* Line: 75*/
} /* Line: 75*/
} /* Line: 73*/

        int ci = be.BECS_Ids.callIds.get(bevl_cname.bems_toJvString());
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_17_ta_ph.bevi_bool)/* Line: 155*/ {
bevl_rval.bemd_0(593600550);
} /* Line: 157*/
return bevl_rval;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_5));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 168*/
if (beva_numargs == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 171*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);

      
      String name = "" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      
      BETS_Object bevs_cano = bemc_getType();
      
      if (bevs_cano.bevs_methodNames.containsKey(name)) {
        return be.BECS_Runtime.boolTrue;
      }
      
      bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_9_ta_ph.bevi_bool)/* Line: 221*/ {
bevl_rval.bemd_0(593600550);
} /* Line: 222*/
if (bevl_rval == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 224*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /* Line: 225*/
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_6_SystemObject_bels_7));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_print_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_create_0();
bevt_0_ta_ph = bem_copyTo_1(bevt_1_ta_ph);
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
if (beva_copy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 331*/ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 332*/
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_ta_ph);
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_ta_ph);
while (true)
/* Line: 336*/ {
bevt_3_ta_ph = bevl_siter.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_4_ta_ph = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_ta_ph);
} /* Line: 337*/
 else /* Line: 336*/ {
break;
} /* Line: 336*/
} /* Line: 336*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {29, 29, 40, 40, 44, 45, 45, 45, 45, 45, 45, 50, 51, 51, 51, 51, 51, 51, 60, 60, 61, 61, 61, 63, 63, 64, 64, 64, 66, 67, 67, 67, 67, 73, 73, 73, 74, 74, 74, 75, 75, 75, 76, 76, 76, 76, 75, 155, 157, 159, 167, 167, 168, 168, 168, 170, 170, 171, 171, 171, 173, 173, 173, 173, 221, 222, 224, 224, 225, 225, 227, 227, 266, 266, 277, 311, 315, 315, 315, 319, 319, 323, 323, 327, 327, 327, 331, 331, 332, 334, 334, 335, 335, 336, 337, 337, 342, 342, 369};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 30, 34, 35, 44, 46, 47, 48, 49, 50, 51, 62, 64, 65, 66, 67, 68, 69, 97, 102, 103, 104, 105, 107, 112, 113, 114, 115, 117, 118, 119, 120, 121, 123, 124, 129, 130, 131, 132, 133, 136, 141, 142, 143, 144, 145, 146, 176, 178, 180, 199, 204, 205, 206, 207, 209, 214, 215, 216, 217, 219, 220, 221, 222, 233, 235, 237, 242, 243, 244, 246, 247, 255, 256, 260, 263, 268, 269, 274, 278, 279, 283, 284, 290, 291, 292, 302, 307, 308, 310, 311, 312, 313, 316, 318, 319, 329, 330, 336};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 29 29
new 0 29 29
return 1 29 30
assign 1 40 34
new 0 40 34
return 1 40 35
assign 1 44 44
new 0 44 44
assign 1 45 46
new 0 45 46
assign 1 45 47
add 1 45 47
assign 1 45 48
new 0 45 48
assign 1 45 49
add 1 45 49
assign 1 45 50
new 1 45 50
throw 1 45 51
assign 1 50 62
new 0 50 62
assign 1 51 64
new 0 51 64
assign 1 51 65
add 1 51 65
assign 1 51 66
new 0 51 66
assign 1 51 67
add 1 51 67
assign 1 51 68
new 1 51 68
throw 1 51 69
assign 1 60 97
undef 1 60 102
assign 1 61 103
new 0 61 103
assign 1 61 104
new 1 61 104
throw 1 61 105
assign 1 63 107
undef 1 63 112
assign 1 64 113
new 0 64 113
assign 1 64 114
new 1 64 114
throw 1 64 115
assign 1 66 117
lengthGet 0 66 117
assign 1 67 118
new 0 67 118
assign 1 67 119
add 1 67 119
assign 1 67 120
toString 0 67 120
assign 1 67 121
add 1 67 121
assign 1 73 123
new 0 73 123
assign 1 73 124
greater 1 73 129
assign 1 74 130
new 0 74 130
assign 1 74 131
subtract 1 74 131
assign 1 74 132
new 1 74 132
assign 1 75 133
new 0 75 133
assign 1 75 136
lesser 1 75 141
assign 1 76 142
new 0 76 142
assign 1 76 143
subtract 1 76 143
assign 1 76 144
get 1 76 144
put 2 76 145
incrementValue 0 75 146
assign 1 155 176
new 0 155 176
toString 0 157 178
return 1 159 180
assign 1 167 199
undef 1 167 204
assign 1 168 205
new 0 168 205
assign 1 168 206
new 1 168 206
throw 1 168 207
assign 1 170 209
undef 1 170 214
assign 1 171 215
new 0 171 215
assign 1 171 216
new 1 171 216
throw 1 171 217
assign 1 173 219
new 0 173 219
assign 1 173 220
add 1 173 220
assign 1 173 221
toString 0 173 221
assign 1 173 222
add 1 173 222
assign 1 221 233
new 0 221 233
toString 0 222 235
assign 1 224 237
def 1 224 242
assign 1 225 243
new 0 225 243
return 1 225 244
assign 1 227 246
new 0 227 246
return 1 227 247
assign 1 266 255
new 0 266 255
return 1 266 256
assign 1 277 260
new 0 277 260
return 1 311 263
assign 1 315 268
equals 1 315 268
assign 1 315 269
not 0 315 274
return 1 315 274
assign 1 319 278
new 0 319 278
return 1 319 279
assign 1 323 283
toString 0 323 283
print 0 323 284
assign 1 327 290
create 0 327 290
assign 1 327 291
copyTo 1 327 291
return 1 327 292
assign 1 331 302
undef 1 331 307
return 1 332 308
assign 1 334 310
new 0 334 310
assign 1 334 311
new 2 334 311
assign 1 335 312
new 0 335 312
assign 1 335 313
new 2 335 313
assign 1 336 316
hasNextGet 0 336 316
assign 1 337 318
nextGet 0 337 318
nextSet 1 337 319
assign 1 342 329
new 1 342 329
return 1 342 330
return 1 369 336
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -593179039: return bem_hashGet_0();
case -509281348: return bem_new_0();
case 593600550: return bem_toString_0();
case 1377393171: return bem_iteratorGet_0();
case 572942595: return bem_create_0();
case 916511308: return bem_print_0();
case -1436588716: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 152454017: return bem_def_1(bevd_0);
case -1239385327: return bem_undef_1(bevd_0);
case 740081825: return bem_notEquals_1(bevd_0);
case -257664443: return bem_equals_1(bevd_0);
case -1490966740: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 376456972: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2087906856: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 426315431: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -840314986: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemObject();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
