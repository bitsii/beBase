package be;
/* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject extends be.BECS_Object {
public BEC_2_6_6_SystemObject() { }

   public BEC_2_6_6_SystemObject bems_methodNotDefined(String name, BEC_2_6_6_SystemObject[] args) throws Throwable { 
     name = name.substring(0, name.lastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(name.getBytes("UTF-8")), new BEC_2_9_4_ContainerList(args));
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x5F};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67};
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public BEC_2_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_6_SystemObject_bels_0));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_name);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_6_6_SystemObject_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 37*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_6_SystemObject_bels_0));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_name);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_6_6_SystemObject_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 43*/
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 52*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_2));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 53*/
if (beva_args == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_3));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 56*/
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_numargs.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 65*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(7));
bevt_11_ta_ph = bevl_numargs.bem_subtract_1(bevt_12_ta_ph);
bevl_args2 = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(7));
while (true)
/* Line: 67*/ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 67*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(7));
bevt_14_ta_ph = bevl_i.bem_subtract_1(bevt_15_ta_ph);
bevt_16_ta_ph = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_ta_ph, bevt_16_ta_ph);
bevl_i.bevi_int++;
} /* Line: 67*/
 else /* Line: 67*/ {
break;
} /* Line: 67*/
} /* Line: 67*/
} /* Line: 67*/

        int ci = be.BECS_Ids.callIds.get(bevl_cname.bems_toJvString());
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_17_ta_ph.bevi_bool)/* Line: 148*/ {
bevl_rval.bemd_0(969005479);
} /* Line: 150*/
return bevl_rval;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 160*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_5));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 161*/
if (beva_numargs == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 163*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 164*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);

      
      String name = "" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      
      BETS_Object bevs_cano = bemc_getType();
      
      if (bevs_cano.bevs_methodNames.containsKey(name)) {
        return be.BECS_Runtime.boolTrue;
      }
      
      bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_9_ta_ph.bevi_bool)/* Line: 216*/ {
bevl_rval.bemd_0(969005479);
} /* Line: 217*/
if (bevl_rval == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /* Line: 220*/
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_6_SystemObject_bels_7));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_print_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_create_0();
bevt_0_ta_ph = bem_copyTo_1(bevt_1_ta_ph);
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
if (beva_copy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 298*/ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 299*/
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_ta_ph);
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_ta_ph);
while (true)
/* Line: 303*/ {
bevt_3_ta_ph = bevl_siter.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_4_ta_ph = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_ta_ph);
} /* Line: 304*/
 else /* Line: 303*/ {
break;
} /* Line: 303*/
} /* Line: 303*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {28, 28, 32, 32, 36, 37, 37, 37, 37, 37, 37, 42, 43, 43, 43, 43, 43, 43, 52, 52, 53, 53, 53, 55, 55, 56, 56, 56, 58, 59, 59, 59, 59, 65, 65, 65, 66, 66, 66, 67, 67, 67, 68, 68, 68, 68, 67, 148, 150, 152, 160, 160, 161, 161, 161, 163, 163, 164, 164, 164, 166, 166, 166, 166, 216, 217, 219, 219, 220, 220, 222, 222, 247, 247, 251, 278, 282, 282, 282, 286, 286, 290, 290, 294, 294, 294, 298, 298, 299, 301, 301, 302, 302, 303, 304, 304, 309, 309, 324};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 30, 34, 35, 44, 46, 47, 48, 49, 50, 51, 62, 64, 65, 66, 67, 68, 69, 97, 102, 103, 104, 105, 107, 112, 113, 114, 115, 117, 118, 119, 120, 121, 122, 123, 128, 129, 130, 131, 132, 135, 140, 141, 142, 143, 144, 145, 174, 176, 178, 197, 202, 203, 204, 205, 207, 212, 213, 214, 215, 217, 218, 219, 220, 231, 233, 235, 240, 241, 242, 244, 245, 253, 254, 258, 261, 266, 267, 272, 276, 277, 281, 282, 288, 289, 290, 300, 305, 306, 308, 309, 310, 311, 314, 316, 317, 327, 328, 334};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 28 29
new 0 28 29
return 1 28 30
assign 1 32 34
new 0 32 34
return 1 32 35
assign 1 36 44
new 0 36 44
assign 1 37 46
new 0 37 46
assign 1 37 47
add 1 37 47
assign 1 37 48
new 0 37 48
assign 1 37 49
add 1 37 49
assign 1 37 50
new 1 37 50
throw 1 37 51
assign 1 42 62
new 0 42 62
assign 1 43 64
new 0 43 64
assign 1 43 65
add 1 43 65
assign 1 43 66
new 0 43 66
assign 1 43 67
add 1 43 67
assign 1 43 68
new 1 43 68
throw 1 43 69
assign 1 52 97
undef 1 52 102
assign 1 53 103
new 0 53 103
assign 1 53 104
new 1 53 104
throw 1 53 105
assign 1 55 107
undef 1 55 112
assign 1 56 113
new 0 56 113
assign 1 56 114
new 1 56 114
throw 1 56 115
assign 1 58 117
lengthGet 0 58 117
assign 1 59 118
new 0 59 118
assign 1 59 119
add 1 59 119
assign 1 59 120
toString 0 59 120
assign 1 59 121
add 1 59 121
assign 1 65 122
new 0 65 122
assign 1 65 123
greater 1 65 128
assign 1 66 129
new 0 66 129
assign 1 66 130
subtract 1 66 130
assign 1 66 131
new 1 66 131
assign 1 67 132
new 0 67 132
assign 1 67 135
lesser 1 67 140
assign 1 68 141
new 0 68 141
assign 1 68 142
subtract 1 68 142
assign 1 68 143
get 1 68 143
put 2 68 144
incrementValue 0 67 145
assign 1 148 174
new 0 148 174
toString 0 150 176
return 1 152 178
assign 1 160 197
undef 1 160 202
assign 1 161 203
new 0 161 203
assign 1 161 204
new 1 161 204
throw 1 161 205
assign 1 163 207
undef 1 163 212
assign 1 164 213
new 0 164 213
assign 1 164 214
new 1 164 214
throw 1 164 215
assign 1 166 217
new 0 166 217
assign 1 166 218
add 1 166 218
assign 1 166 219
toString 0 166 219
assign 1 166 220
add 1 166 220
assign 1 216 231
new 0 216 231
toString 0 217 233
assign 1 219 235
def 1 219 240
assign 1 220 241
new 0 220 241
return 1 220 242
assign 1 222 244
new 0 222 244
return 1 222 245
assign 1 247 253
new 0 247 253
return 1 247 254
assign 1 251 258
new 0 251 258
return 1 278 261
assign 1 282 266
equals 1 282 266
assign 1 282 267
not 0 282 272
return 1 282 272
assign 1 286 276
new 0 286 276
return 1 286 277
assign 1 290 281
toString 0 290 281
print 0 290 282
assign 1 294 288
create 0 294 288
assign 1 294 289
copyTo 1 294 289
return 1 294 290
assign 1 298 300
undef 1 298 305
return 1 299 306
assign 1 301 308
new 0 301 308
assign 1 301 309
new 2 301 309
assign 1 302 310
new 0 302 310
assign 1 302 311
new 2 302 311
assign 1 303 314
hasNextGet 0 303 314
assign 1 304 316
nextGet 0 304 316
nextSet 1 304 317
assign 1 309 327
new 1 309 327
return 1 309 328
return 1 324 334
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 326916018: return bem_iteratorGet_0();
case 969005479: return bem_toString_0();
case -161809366: return bem_copy_0();
case -1877988678: return bem_hashGet_0();
case -508717313: return bem_create_0();
case 668645503: return bem_new_0();
case 1401626610: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1581048634: return bem_copyTo_1(bevd_0);
case 939305500: return bem_def_1(bevd_0);
case -1391871629: return bem_undef_1(bevd_0);
case 567335501: return bem_equals_1(bevd_0);
case 384220308: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 163536847: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 72722300: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1961786723: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2046340809: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemObject();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
