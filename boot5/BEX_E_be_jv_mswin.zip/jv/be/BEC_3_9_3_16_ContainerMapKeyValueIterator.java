package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_16_ContainerMapKeyValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_16_ContainerMapKeyValueIterator() { }
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4B,0x65,0x79,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;
public BEC_2_6_6_SystemObject bevp_onNode;
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_onNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 606 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 607 */
bevt_2_tmpany_phold = super.bem_hasNextGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_onNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 613 */ {
bevl_toRet = bevp_onNode.bemd_0(-287021431);
bevp_onNode = null;
return bevl_toRet;
} /* Line: 616 */
bevp_onNode = super.bem_nextGet_0();
if (bevp_onNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 619 */ {
bevt_2_tmpany_phold = bevp_onNode.bemd_0(1879046512);
return bevt_2_tmpany_phold;
} /* Line: 620 */
return bevp_onNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onNodeGet_0() throws Throwable {
return bevp_onNode;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_onNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onNode = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {602, 606, 606, 607, 607, 609, 609, 613, 613, 614, 615, 616, 618, 619, 619, 620, 620, 622, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 17, 22, 23, 24, 26, 27, 34, 39, 40, 41, 42, 44, 45, 50, 51, 52, 54, 57, 60};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 602 10
assign 1 606 17
def 1 606 22
assign 1 607 23
new 0 607 23
return 1 607 24
assign 1 609 26
hasNextGet 0 609 26
return 1 609 27
assign 1 613 34
def 1 613 39
assign 1 614 40
valueGet 0 614 40
assign 1 615 41
return 1 616 42
assign 1 618 44
nextGet 0 618 44
assign 1 619 45
def 1 619 50
assign 1 620 51
keyGet 0 620 51
return 1 620 52
return 1 622 54
return 1 0 57
assign 1 0 60
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1387595522: return bem_toAny_0();
case -1601492406: return bem_new_0();
case -1274688402: return bem_nextGet_0();
case -700446239: return bem_onNodeGet_0();
case 1825207979: return bem_delete_0();
case 436412028: return bem_sourceFileNameGet_0();
case -1550372712: return bem_serializeToString_0();
case 1278732754: return bem_create_0();
case 741511465: return bem_print_0();
case -612311095: return bem_iteratorGet_0();
case 730619711: return bem_many_0();
case -961535531: return bem_hashGet_0();
case 118668440: return bem_setGet_0();
case 627086221: return bem_once_0();
case 49643355: return bem_containerGet_0();
case 144613256: return bem_serializeContents_0();
case -1909070982: return bem_slotsGet_0();
case 1044268871: return bem_hasNextGet_0();
case -1194864649: return bem_toString_0();
case -438958534: return bem_currentGet_0();
case -1988392847: return bem_fieldIteratorGet_0();
case -570363758: return bem_serializationIteratorGet_0();
case 901060004: return bem_copy_0();
case -1872600200: return bem_moduGet_0();
case 1359373450: return bem_echo_0();
case 305137971: return bem_classNameGet_0();
case 1826819267: return bem_nodeIteratorIteratorGet_0();
case 1234289396: return bem_tagGet_0();
case 1087786397: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 661372330: return bem_equals_1(bevd_0);
case -1903482804: return bem_otherClass_1(bevd_0);
case 155900047: return bem_moduSet_1(bevd_0);
case -1568064603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1633632376: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -309742024: return bem_def_1(bevd_0);
case 385185820: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 2989800: return bem_currentSet_1(bevd_0);
case -1001249520: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1779048441: return bem_slotsSet_1(bevd_0);
case 1067421305: return bem_notEquals_1(bevd_0);
case 266931166: return bem_undef_1(bevd_0);
case -596533003: return bem_otherType_1(bevd_0);
case 1717289899: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1718194680: return bem_undefined_1(bevd_0);
case -2049241562: return bem_sameObject_1(bevd_0);
case 457153382: return bem_copyTo_1(bevd_0);
case 1420318580: return bem_sameType_1(bevd_0);
case -686450804: return bem_defined_1(bevd_0);
case -1804667875: return bem_onNodeSet_1(bevd_0);
case 905402151: return bem_setSet_1(bevd_0);
case -1023168427: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1461540614: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513720300: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 224164494: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2129126272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 88269440: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -366737409: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -666768572: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_16_ContainerMapKeyValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst = (BEC_3_9_3_16_ContainerMapKeyValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;
}
}
