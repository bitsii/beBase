package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_3_2_4_12_IOFileNamedReaders extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedReaders() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x52,0x65,0x61,0x64,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;

public static BET_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_type;

public BEC_3_2_4_6_IOFileReader bevp_input;
public BEC_3_2_4_12_IOFileNamedReaders bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_default_0() throws Throwable {
BEC_4_2_4_6_5_IOFileReaderStdin bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst.bem_new_0();
bem_inputSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_inputSet_1(BEC_3_2_4_6_IOFileReader beva__input) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_input = beva__input;
bevt_0_tmpany_phold = bevp_input.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 553 */ {
bevp_input.bem_open_0();
} /* Line: 554 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_inputGet_0() throws Throwable {
return bevp_input;
} /*method end*/
public final BEC_3_2_4_6_IOFileReader bem_inputGetDirect_0() throws Throwable {
return bevp_input;
} /*method end*/
public final BEC_3_2_4_12_IOFileNamedReaders bem_inputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_input = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {548, 548, 552, 553, 554, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 23, 24, 26, 31, 34, 37};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 548 17
new 0 548 17
inputSet 1 548 18
assign 1 552 23
assign 1 553 24
isClosedGet 0 553 24
open 0 554 26
return 1 0 31
return 1 0 34
assign 1 0 37
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1649954317: return bem_serializeToString_0();
case -429437759: return bem_sourceFileNameGet_0();
case 57159682: return bem_new_0();
case 602097122: return bem_deserializeClassNameGet_0();
case 2117639469: return bem_echo_0();
case -284999675: return bem_toAny_0();
case -2069102102: return bem_toString_0();
case 55315205: return bem_many_0();
case -873805052: return bem_inputGet_0();
case -1232907801: return bem_iteratorGet_0();
case -1605431584: return bem_tagGet_0();
case 321704245: return bem_print_0();
case 1540891808: return bem_default_0();
case -1561145816: return bem_hashGet_0();
case -1437550559: return bem_serializeContents_0();
case -1055677288: return bem_fieldIteratorGet_0();
case 1644000934: return bem_copy_0();
case 1029860087: return bem_fieldNamesGet_0();
case -1677419910: return bem_create_0();
case 1215735159: return bem_classNameGet_0();
case -174774798: return bem_inputGetDirect_0();
case 1129503343: return bem_once_0();
case 444831026: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1371671937: return bem_undefined_1(bevd_0);
case 1366553936: return bem_undef_1(bevd_0);
case 1521573585: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 208310867: return bem_def_1(bevd_0);
case 1719096215: return bem_defined_1(bevd_0);
case -1422291148: return bem_sameClass_1(bevd_0);
case -2051646828: return bem_inputSetDirect_1(bevd_0);
case -1988005274: return bem_sameObject_1(bevd_0);
case -756536057: return bem_otherClass_1(bevd_0);
case 1484718882: return bem_copyTo_1(bevd_0);
case 493426545: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -962669917: return bem_otherType_1(bevd_0);
case 1602696702: return bem_equals_1(bevd_0);
case 1178220548: return bem_sameType_1(bevd_0);
case 1564668238: return bem_inputSet_1((BEC_3_2_4_6_IOFileReader) bevd_0);
case -740299402: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -97426471: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 650080222: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1950811501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959141176: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281973651: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -12510800: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220358760: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 36705687: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -533377424: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedReaders_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedReaders_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_12_IOFileNamedReaders();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst = (BEC_3_2_4_12_IOFileNamedReaders) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_type;
}
}
