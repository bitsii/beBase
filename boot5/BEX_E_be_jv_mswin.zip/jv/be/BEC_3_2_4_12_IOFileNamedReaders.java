package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_3_2_4_12_IOFileNamedReaders extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedReaders() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x52,0x65,0x61,0x64,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;

public static BET_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_type;

public BEC_3_2_4_6_IOFileReader bevp_input;
public BEC_3_2_4_12_IOFileNamedReaders bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_default_0() throws Throwable {
BEC_4_2_4_6_5_IOFileReaderStdin bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst.bem_new_0();
bem_inputSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_inputSet_1(BEC_3_2_4_6_IOFileReader beva__input) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_input = beva__input;
bevt_0_tmpany_phold = bevp_input.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 627 */ {
bevp_input.bem_open_0();
} /* Line: 628 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_inputGet_0() throws Throwable {
return bevp_input;
} /*method end*/
public final BEC_3_2_4_6_IOFileReader bem_inputGetDirect_0() throws Throwable {
return bevp_input;
} /*method end*/
public final BEC_3_2_4_12_IOFileNamedReaders bem_inputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_input = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {622, 622, 626, 627, 628, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 23, 24, 26, 31, 34, 37};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 622 17
new 0 622 17
inputSet 1 622 18
assign 1 626 23
assign 1 627 24
isClosedGet 0 627 24
open 0 628 26
return 1 0 31
return 1 0 34
assign 1 0 37
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1551415145: return bem_toAny_0();
case 690609043: return bem_print_0();
case -1522610135: return bem_serializeToString_0();
case -2005156683: return bem_classNameGet_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case -753430171: return bem_fieldIteratorGet_0();
case 2094183929: return bem_inputGetDirect_0();
case 983736684: return bem_serializationIteratorGet_0();
case 247075507: return bem_fieldNamesGet_0();
case -576502505: return bem_create_0();
case 2084331281: return bem_new_0();
case 320622940: return bem_echo_0();
case -738439163: return bem_copy_0();
case 1954228088: return bem_default_0();
case 1969080256: return bem_once_0();
case -1966626789: return bem_hashGet_0();
case -1313098664: return bem_toString_0();
case 101762581: return bem_serializeContents_0();
case 645211302: return bem_iteratorGet_0();
case -890719598: return bem_sourceFileNameGet_0();
case -1612939369: return bem_inputGet_0();
case 484635838: return bem_tagGet_0();
case -357139526: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -559803890: return bem_notEquals_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case 758604875: return bem_def_1(bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case -670773723: return bem_sameType_1(bevd_0);
case 1061858892: return bem_inputSet_1((BEC_3_2_4_6_IOFileReader) bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -720955322: return bem_inputSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedReaders_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedReaders_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_12_IOFileNamedReaders();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst = (BEC_3_2_4_12_IOFileNamedReaders) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_type;
}
}
