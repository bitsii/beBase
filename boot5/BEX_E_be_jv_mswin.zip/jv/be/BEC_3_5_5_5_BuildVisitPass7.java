package be;
/* IO:File: source/build/Pass7.be */
public final class BEC_3_5_5_5_BuildVisitPass7 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_2 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_3 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_5 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_6 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass7_bels_6, 41));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_7 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_8 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_10 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_15 = {0x6E,0x65,0x77};
public static BEC_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_3_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpany_phold.bemd_0(-1129539545);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-60422879);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bemd_0(148544119);
} /* Line: 40 */
if (bevp_inClassNp == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 42 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 44 */
bevt_16_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpany_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass7_bels_0));
bevp_build.bem_buildLiteral_2(beva_node, bevt_18_tmpany_phold);
} /* Line: 47 */
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_1));
bevp_build.bem_buildLiteral_2(beva_node, bevt_22_tmpany_phold);
} /* Line: 50 */
bevt_24_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpany_phold.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_26_tmpany_phold);
} /* Line: 53 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpany_phold);
} /* Line: 58 */
bevt_33_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpany_phold.bevi_int == bevt_34_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass7_bels_3));
beva_node.bem_heldSet_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
bevp_build.bem_buildLiteral_2(beva_node, bevt_36_tmpany_phold);
} /* Line: 62 */
bevt_38_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpany_phold.bevi_int == bevt_39_tmpany_phold.bevi_int) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 68 */ {
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_5));
beva_node.bem_heldSet_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
bevp_build.bem_buildLiteral_2(beva_node, bevt_41_tmpany_phold);
} /* Line: 70 */
 else  /* Line: 68 */ {
bevt_43_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpany_phold.bevi_int == bevt_44_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(2127488911);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(1830123495);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 72 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 72 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 72 */
 else  /* Line: 72 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 72 */ {
bevt_50_tmpany_phold = beva_node.bem_heldGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(1041262721);
if (bevt_49_tmpany_phold == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 73 */ {
if (bevl_nnode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_53_tmpany_phold = bevl_nnode.bemd_0(1693662423);
bevt_54_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(1703616583, bevt_54_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_52_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 73 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 73 */ {
bevt_57_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0;
bevt_59_tmpany_phold = beva_node.bem_heldGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1041262721);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_55_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_55_tmpany_phold);
} /* Line: 74 */
 else  /* Line: 75 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = bevl_nnode.bemd_0(436982975);
bevt_60_tmpany_phold.bemd_1(1543771902, bevt_61_tmpany_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(848259769);
bevt_62_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpany_phold;
} /* Line: 82 */
} /* Line: 73 */
 else  /* Line: 68 */ {
bevt_64_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 84 */ {
if (bevl_nnode == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_68_tmpany_phold = bevl_nnode.bemd_0(1693662423);
bevt_69_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(-1519516879, bevt_69_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_67_tmpany_phold).bevi_bool) /* Line: 85 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
 else  /* Line: 85 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(-2018649338);
if (bevt_71_tmpany_phold == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = bevl_nnode.bemd_0(-2018649338);
bevl_ii = bevt_72_tmpany_phold.bemd_0(569361306);
while (true)
 /* Line: 88 */ {
bevt_73_tmpany_phold = bevl_ii.bemd_0(-1664274967);
if (((BEC_2_5_4_LogicBool) bevt_73_tmpany_phold).bevi_bool) /* Line: 88 */ {
bevl_i = bevl_ii.bemd_0(396718224);
bevt_75_tmpany_phold = bevl_i.bemd_0(1693662423);
bevt_76_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(-1519516879, bevt_76_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 90 */ {
bevl_toremove.bemd_1(-1979724751, bevl_i);
} /* Line: 91 */
} /* Line: 90 */
 else  /* Line: 88 */ {
break;
} /* Line: 88 */
} /* Line: 88 */
bevl_ii = bevl_toremove.bemd_0(569361306);
while (true)
 /* Line: 94 */ {
bevt_77_tmpany_phold = bevl_ii.bemd_0(-1664274967);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevl_i = bevl_ii.bemd_0(396718224);
bevl_i.bemd_0(848259769);
} /* Line: 96 */
 else  /* Line: 94 */ {
break;
} /* Line: 94 */
} /* Line: 94 */
} /* Line: 94 */
bevl_pc = bevl_nnode;
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(-435657446, bevt_78_tmpany_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1543771902, bevt_79_tmpany_phold);
bevl_pc.bemd_1(-765819752, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 107 */ {
bevt_82_tmpany_phold = bevl_dnode.bemd_0(1693662423);
bevt_83_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(-1519516879, bevt_83_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_81_tmpany_phold).bevi_bool) /* Line: 107 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 107 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 107 */
 else  /* Line: 107 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 107 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(-2069337727);
if (bevl_onode == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(38, bece_BEC_3_5_5_5_BuildVisitPass7_bels_7));
bevt_85_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpany_phold);
} /* Line: 110 */
 else  /* Line: 109 */ {
bevt_88_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpany_phold.bevi_int == bevt_89_tmpany_phold.bevi_int) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_91_tmpany_phold = bevl_gc.bemd_0(1041262721);
bevt_90_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpany_phold );
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1725671743, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-919040918, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1280734287, bevt_94_tmpany_phold);
} /* Line: 115 */
 else  /* Line: 116 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 117 */
} /* Line: 112 */
 else  /* Line: 109 */ {
bevt_96_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpany_phold.bevi_int == bevt_97_tmpany_phold.bevi_int) {
bevt_95_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_101_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(436982975);
bevt_99_tmpany_phold = bevt_100_tmpany_phold.bemd_0(5043299);
bevt_102_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bemd_1(-1069040816, bevt_102_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_98_tmpany_phold).bevi_bool) /* Line: 119 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 119 */ {
bevt_105_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_aliasedGet_0();
bevt_106_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpany_phold = bevt_104_tmpany_phold.bem_has_1(bevt_106_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 119 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 119 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 119 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 119 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 119 */
 else  /* Line: 119 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 119 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpany_phold = bevl_gc.bemd_0(1041262721);
bevt_109_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpany_phold );
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_111_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1725671743, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-919040918, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1280734287, bevt_113_tmpany_phold);
} /* Line: 128 */
 else  /* Line: 129 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 130 */
} /* Line: 125 */
 else  /* Line: 109 */ {
bevt_115_tmpany_phold = bevl_gc.bemd_0(1041262721);
bevt_116_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass7_bels_8));
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(-1519516879, bevt_116_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_114_tmpany_phold).bevi_bool) /* Line: 132 */ {
bevt_118_tmpany_phold = (new BEC_2_4_6_TextString(70, bece_BEC_3_5_5_5_BuildVisitPass7_bels_9));
bevt_117_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 133 */
 else  /* Line: 109 */ {
bevt_120_tmpany_phold = bevl_gc.bemd_0(1041262721);
bevt_121_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_10));
bevt_119_tmpany_phold = bevt_120_tmpany_phold.bemd_1(-1519516879, bevt_121_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_119_tmpany_phold).bevi_bool) /* Line: 134 */ {
bevt_123_tmpany_phold = (new BEC_2_4_6_TextString(65, bece_BEC_3_5_5_5_BuildVisitPass7_bels_11));
bevt_122_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_122_tmpany_phold);
} /* Line: 135 */
} /* Line: 109 */
} /* Line: 109 */
} /* Line: 109 */
} /* Line: 109 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(-766368587, bevl_onode);
bevl_dnode.bemd_0(848259769);
} /* Line: 140 */
 else  /* Line: 141 */ {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-919040918, bevt_124_tmpany_phold);
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1725671743, bevt_125_tmpany_phold);
} /* Line: 143 */
} /* Line: 107 */
} /* Line: 85 */
 else  /* Line: 68 */ {
bevt_127_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpany_phold.bevi_int == bevt_128_tmpany_phold.bevi_int) {
bevt_126_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 147 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevt_131_tmpany_phold = (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_12));
bevt_130_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_130_tmpany_phold);
} /* Line: 152 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpany_phold.bevi_int == bevt_134_tmpany_phold.bevi_int) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_136_tmpany_phold = (new BEC_2_4_6_TextString(84, bece_BEC_3_5_5_5_BuildVisitPass7_bels_13));
bevt_135_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_135_tmpany_phold);
} /* Line: 157 */
bevt_137_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpany_phold);
} /* Line: 159 */
 else  /* Line: 68 */ {
bevt_139_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpany_phold.bevi_int == bevt_140_tmpany_phold.bevi_int) {
bevt_138_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpany_phold.bevi_bool) /* Line: 160 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 165 */ {
if (bevl_onode == null) {
bevt_142_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 165 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 165 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 165 */ {
bevt_144_tmpany_phold = (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_14));
bevt_143_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpany_phold);
} /* Line: 166 */
bevt_146_tmpany_phold = bevl_nnode.bemd_0(1693662423);
bevt_147_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(-1519516879, bevt_147_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_145_tmpany_phold).bevi_bool) /* Line: 168 */ {
bevl_pnode = bevl_nnode.bemd_0(-1719962269);
if (bevl_pnode == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_150_tmpany_phold = bevl_pnode.bemd_0(1693662423);
bevt_151_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(1703616583, bevt_151_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_149_tmpany_phold).bevi_bool) /* Line: 170 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 170 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 170 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpany_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpany_phold = bevl_nnode.bemd_0(436982975);
bevl_ga.bemd_1(1543771902, bevt_153_tmpany_phold);
bevl_nnode.bemd_0(848259769);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpany_phold.bevi_int == bevt_156_tmpany_phold.bevi_int) {
bevt_154_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpany_phold.bevi_bool) /* Line: 179 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 180 */
 else  /* Line: 179 */ {
bevt_158_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpany_phold.bevi_int == bevt_159_tmpany_phold.bevi_int) {
bevt_157_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpany_phold.bevi_bool) /* Line: 181 */ {
bevt_163_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(436982975);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(5043299);
bevt_164_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_1(-1069040816, bevt_164_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_160_tmpany_phold).bevi_bool) /* Line: 181 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 181 */ {
bevt_167_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bem_aliasedGet_0();
bevt_168_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bem_has_1(bevt_168_tmpany_phold);
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 181 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 181 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 181 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 181 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 181 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 181 */
 else  /* Line: 181 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 181 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 187 */
} /* Line: 179 */
} /* Line: 179 */
} /* Line: 170 */
} /* Line: 168 */
} /* Line: 68 */
} /* Line: 68 */
} /* Line: 68 */
} /* Line: 68 */
bevt_171_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpany_phold;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) throws Throwable {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpany_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass7_bels_15));
bevl_gnc.bem_nameSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpany_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public final BEC_2_4_6_TextString bem_inFileGetDirect_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass7 bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {35, 38, 38, 38, 38, 39, 39, 40, 40, 40, 42, 42, 43, 44, 46, 46, 46, 46, 47, 47, 49, 49, 49, 49, 50, 50, 52, 52, 52, 52, 53, 53, 55, 55, 55, 55, 57, 57, 58, 58, 60, 60, 60, 60, 61, 61, 62, 62, 68, 68, 68, 68, 69, 69, 70, 70, 72, 72, 72, 72, 72, 72, 72, 0, 0, 0, 73, 73, 73, 73, 73, 73, 0, 73, 73, 73, 0, 0, 0, 0, 0, 74, 74, 74, 74, 74, 74, 76, 76, 76, 77, 78, 82, 82, 84, 84, 84, 84, 85, 85, 85, 85, 85, 0, 0, 0, 86, 86, 86, 87, 88, 88, 88, 89, 90, 90, 90, 91, 94, 94, 95, 96, 99, 100, 100, 101, 102, 102, 103, 104, 105, 106, 107, 107, 107, 107, 107, 0, 0, 0, 108, 109, 109, 110, 110, 110, 111, 111, 111, 111, 112, 112, 113, 113, 114, 114, 115, 115, 117, 119, 119, 119, 119, 119, 119, 119, 119, 119, 0, 119, 119, 119, 119, 0, 0, 0, 0, 0, 120, 121, 121, 122, 123, 123, 124, 125, 125, 126, 126, 127, 127, 128, 128, 130, 132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 138, 139, 140, 142, 142, 143, 143, 147, 147, 147, 147, 150, 151, 151, 152, 152, 152, 154, 155, 156, 156, 156, 156, 157, 157, 157, 159, 159, 160, 160, 160, 160, 162, 165, 165, 0, 165, 165, 0, 0, 166, 166, 166, 168, 168, 168, 169, 170, 170, 0, 170, 170, 170, 0, 0, 171, 172, 172, 173, 174, 174, 175, 176, 177, 178, 179, 179, 179, 179, 180, 181, 181, 181, 181, 181, 181, 181, 181, 181, 0, 181, 181, 181, 181, 0, 0, 0, 0, 0, 182, 183, 183, 184, 185, 185, 186, 187, 192, 192, 196, 197, 198, 198, 199, 199, 200, 202, 203, 203, 204, 204, 205, 205, 206, 206, 207, 207, 208, 209, 209, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {220, 221, 222, 223, 228, 229, 230, 231, 232, 233, 235, 240, 241, 242, 244, 245, 246, 251, 252, 253, 255, 256, 257, 262, 263, 264, 266, 267, 268, 273, 274, 275, 277, 278, 279, 284, 285, 286, 287, 288, 290, 291, 292, 297, 298, 299, 300, 301, 303, 304, 305, 310, 311, 312, 313, 314, 317, 318, 319, 324, 325, 326, 327, 329, 332, 336, 339, 340, 341, 346, 347, 352, 353, 356, 357, 358, 360, 363, 367, 370, 374, 377, 378, 379, 380, 381, 382, 385, 386, 387, 388, 389, 390, 391, 395, 396, 397, 402, 403, 408, 409, 410, 411, 413, 416, 420, 423, 424, 429, 430, 431, 432, 435, 437, 438, 439, 440, 442, 449, 452, 454, 455, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 477, 478, 479, 480, 482, 485, 489, 492, 493, 498, 499, 500, 501, 504, 505, 506, 511, 512, 513, 515, 516, 517, 518, 519, 520, 523, 527, 528, 529, 534, 535, 536, 537, 538, 539, 541, 544, 545, 546, 547, 549, 552, 556, 559, 563, 566, 567, 568, 569, 570, 571, 572, 573, 574, 576, 577, 578, 579, 580, 581, 584, 588, 589, 590, 592, 593, 594, 597, 598, 599, 601, 602, 603, 609, 610, 611, 614, 615, 616, 617, 622, 623, 624, 629, 630, 631, 636, 637, 638, 639, 641, 642, 643, 644, 645, 650, 651, 652, 653, 655, 656, 659, 660, 661, 666, 667, 668, 673, 674, 677, 682, 683, 686, 690, 691, 692, 694, 695, 696, 698, 699, 704, 705, 708, 709, 710, 712, 715, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 736, 737, 740, 741, 742, 747, 748, 749, 750, 751, 752, 754, 757, 758, 759, 760, 762, 765, 769, 772, 776, 779, 780, 781, 782, 783, 784, 785, 786, 796, 797, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 834, 837, 840, 844, 848, 851, 854, 858};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 35 220
nextPeerGet 0 35 220
assign 1 38 221
typenameGet 0 38 221
assign 1 38 222
CLASSGet 0 38 222
assign 1 38 223
equals 1 38 228
assign 1 39 229
heldGet 0 39 229
assign 1 39 230
namepathGet 0 39 230
assign 1 40 231
heldGet 0 40 231
assign 1 40 232
fromFileGet 0 40 232
assign 1 40 233
toString 0 40 233
assign 1 42 235
def 1 42 240
inClassNpSet 1 43 241
inFileSet 1 44 242
assign 1 46 244
typenameGet 0 46 244
assign 1 46 245
INTLGet 0 46 245
assign 1 46 246
equals 1 46 251
assign 1 47 252
new 0 47 252
buildLiteral 2 47 253
assign 1 49 255
typenameGet 0 49 255
assign 1 49 256
FLOATLGet 0 49 256
assign 1 49 257
equals 1 49 262
assign 1 50 263
new 0 50 263
buildLiteral 2 50 264
assign 1 52 266
typenameGet 0 52 266
assign 1 52 267
STRINGLGet 0 52 267
assign 1 52 268
equals 1 52 273
assign 1 53 274
new 0 53 274
buildLiteral 2 53 275
assign 1 55 277
typenameGet 0 55 277
assign 1 55 278
WSTRINGLGet 0 55 278
assign 1 55 279
equals 1 55 284
assign 1 57 285
new 0 57 285
buildLiteral 2 57 286
assign 1 58 287
new 0 58 287
wideStringSet 1 58 288
assign 1 60 290
typenameGet 0 60 290
assign 1 60 291
TRUEGet 0 60 291
assign 1 60 292
equals 1 60 297
assign 1 61 298
new 0 61 298
heldSet 1 61 299
assign 1 62 300
new 0 62 300
buildLiteral 2 62 301
assign 1 68 303
typenameGet 0 68 303
assign 1 68 304
FALSEGet 0 68 304
assign 1 68 305
equals 1 68 310
assign 1 69 311
new 0 69 311
heldSet 1 69 312
assign 1 70 313
new 0 70 313
buildLiteral 2 70 314
assign 1 72 317
typenameGet 0 72 317
assign 1 72 318
VARGet 0 72 318
assign 1 72 319
equals 1 72 324
assign 1 72 325
heldGet 0 72 325
assign 1 72 326
isArgGet 0 72 326
assign 1 72 327
not 0 72 327
assign 1 0 329
assign 1 0 332
assign 1 0 336
assign 1 73 339
heldGet 0 73 339
assign 1 73 340
nameGet 0 73 340
assign 1 73 341
undef 1 73 346
assign 1 73 347
undef 1 73 352
assign 1 0 353
assign 1 73 356
typenameGet 0 73 356
assign 1 73 357
IDGet 0 73 357
assign 1 73 358
notEquals 1 73 358
assign 1 0 360
assign 1 0 363
assign 1 0 367
assign 1 0 370
assign 1 0 374
assign 1 74 377
new 0 74 377
assign 1 74 378
heldGet 0 74 378
assign 1 74 379
nameGet 0 74 379
assign 1 74 380
add 1 74 380
assign 1 74 381
new 2 74 381
throw 1 74 382
assign 1 76 385
heldGet 0 76 385
assign 1 76 386
heldGet 0 76 386
nameSet 1 76 387
addVariable 0 77 388
delete 0 78 389
assign 1 82 390
nextDescendGet 0 82 390
return 1 82 391
assign 1 84 395
typenameGet 0 84 395
assign 1 84 396
IDGet 0 84 396
assign 1 84 397
equals 1 84 402
assign 1 85 403
def 1 85 408
assign 1 85 409
typenameGet 0 85 409
assign 1 85 410
PARENSGet 0 85 410
assign 1 85 411
equals 1 85 411
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 86 423
containedGet 0 86 423
assign 1 86 424
def 1 86 429
assign 1 87 430
new 0 87 430
assign 1 88 431
containedGet 0 88 431
assign 1 88 432
iteratorGet 0 88 432
assign 1 88 435
hasNextGet 0 88 435
assign 1 89 437
nextGet 0 89 437
assign 1 90 438
typenameGet 0 90 438
assign 1 90 439
COMMAGet 0 90 439
assign 1 90 440
equals 1 90 440
addValue 1 91 442
assign 1 94 449
iteratorGet 0 94 449
assign 1 94 452
hasNextGet 0 94 452
assign 1 95 454
nextGet 0 95 454
delete 0 96 455
assign 1 99 462
assign 1 100 463
CALLGet 0 100 463
typenameSet 1 100 464
assign 1 101 465
new 0 101 465
assign 1 102 466
heldGet 0 102 466
nameSet 1 102 467
heldSet 1 103 468
delete 0 104 469
assign 1 105 470
assign 1 106 471
priorPeerGet 0 106 471
assign 1 107 472
def 1 107 477
assign 1 107 478
typenameGet 0 107 478
assign 1 107 479
DOTGet 0 107 479
assign 1 107 480
equals 1 107 480
assign 1 0 482
assign 1 0 485
assign 1 0 489
assign 1 108 492
priorPeerGet 0 108 492
assign 1 109 493
undef 1 109 498
assign 1 110 499
new 0 110 499
assign 1 110 500
new 2 110 500
throw 1 110 501
assign 1 111 504
typenameGet 0 111 504
assign 1 111 505
NAMEPATHGet 0 111 505
assign 1 111 506
equals 1 111 511
assign 1 112 512
nameGet 0 112 512
assign 1 112 513
isNewish 1 112 513
assign 1 113 515
new 0 113 515
wasBoundSet 1 113 516
assign 1 114 517
new 0 114 517
boundSet 1 114 518
assign 1 115 519
new 0 115 519
isConstructSet 1 115 520
createImpliedConstruct 2 117 523
assign 1 119 527
typenameGet 0 119 527
assign 1 119 528
IDGet 0 119 528
assign 1 119 529
equals 1 119 534
assign 1 119 535
transUnitGet 0 119 535
assign 1 119 536
heldGet 0 119 536
assign 1 119 537
aliasedGet 0 119 537
assign 1 119 538
heldGet 0 119 538
assign 1 119 539
has 1 119 539
assign 1 0 541
assign 1 119 544
emitDataGet 0 119 544
assign 1 119 545
aliasedGet 0 119 545
assign 1 119 546
heldGet 0 119 546
assign 1 119 547
has 1 119 547
assign 1 0 549
assign 1 0 552
assign 1 0 556
assign 1 0 559
assign 1 0 563
assign 1 120 566
new 0 120 566
assign 1 121 567
heldGet 0 121 567
addStep 1 121 568
heldSet 1 122 569
assign 1 123 570
NAMEPATHGet 0 123 570
typenameSet 1 123 571
resolveNp 0 124 572
assign 1 125 573
nameGet 0 125 573
assign 1 125 574
isNewish 1 125 574
assign 1 126 576
new 0 126 576
wasBoundSet 1 126 577
assign 1 127 578
new 0 127 578
boundSet 1 127 579
assign 1 128 580
new 0 128 580
isConstructSet 1 128 581
createImpliedConstruct 2 130 584
assign 1 132 588
nameGet 0 132 588
assign 1 132 589
new 0 132 589
assign 1 132 590
equals 1 132 590
assign 1 133 592
new 0 133 592
assign 1 133 593
new 2 133 593
throw 1 133 594
assign 1 134 597
nameGet 0 134 597
assign 1 134 598
new 0 134 598
assign 1 134 599
equals 1 134 599
assign 1 135 601
new 0 135 601
assign 1 135 602
new 2 135 602
throw 1 135 603
delete 0 138 609
prepend 1 139 610
delete 0 140 611
assign 1 142 614
new 0 142 614
boundSet 1 142 615
assign 1 143 616
new 0 143 616
wasBoundSet 1 143 617
assign 1 147 622
typenameGet 0 147 622
assign 1 147 623
IDXGet 0 147 623
assign 1 147 624
equals 1 147 629
assign 1 150 630
priorPeerGet 0 150 630
assign 1 151 631
undef 1 151 636
assign 1 152 637
new 0 152 637
assign 1 152 638
new 2 152 638
throw 1 152 639
delete 0 154 641
prepend 1 155 642
assign 1 156 643
typenameGet 0 156 643
assign 1 156 644
NAMEPATHGet 0 156 644
assign 1 156 645
equals 1 156 650
assign 1 157 651
new 0 157 651
assign 1 157 652
new 2 157 652
throw 1 157 653
assign 1 159 655
IDXACCGet 0 159 655
typenameSet 1 159 656
assign 1 160 659
typenameGet 0 160 659
assign 1 160 660
DOTGet 0 160 660
assign 1 160 661
equals 1 160 666
assign 1 162 667
priorPeerGet 0 162 667
assign 1 165 668
undef 1 165 673
assign 1 0 674
assign 1 165 677
undef 1 165 682
assign 1 0 683
assign 1 0 686
assign 1 166 690
new 0 166 690
assign 1 166 691
new 2 166 691
throw 1 166 692
assign 1 168 694
typenameGet 0 168 694
assign 1 168 695
IDGet 0 168 695
assign 1 168 696
equals 1 168 696
assign 1 169 698
nextPeerGet 0 169 698
assign 1 170 699
undef 1 170 704
assign 1 0 705
assign 1 170 708
typenameGet 0 170 708
assign 1 170 709
PARENSGet 0 170 709
assign 1 170 710
notEquals 1 170 710
assign 1 0 712
assign 1 0 715
assign 1 171 719
priorPeerGet 0 171 719
assign 1 172 720
ACCESSORGet 0 172 720
typenameSet 1 172 721
assign 1 173 722
new 0 173 722
assign 1 174 723
heldGet 0 174 723
nameSet 1 174 724
delete 0 175 725
delete 0 176 726
heldSet 1 177 727
addValue 1 178 728
assign 1 179 729
typenameGet 0 179 729
assign 1 179 730
NAMEPATHGet 0 179 730
assign 1 179 731
equals 1 179 736
createImpliedConstruct 2 180 737
assign 1 181 740
typenameGet 0 181 740
assign 1 181 741
IDGet 0 181 741
assign 1 181 742
equals 1 181 747
assign 1 181 748
transUnitGet 0 181 748
assign 1 181 749
heldGet 0 181 749
assign 1 181 750
aliasedGet 0 181 750
assign 1 181 751
heldGet 0 181 751
assign 1 181 752
has 1 181 752
assign 1 0 754
assign 1 181 757
emitDataGet 0 181 757
assign 1 181 758
aliasedGet 0 181 758
assign 1 181 759
heldGet 0 181 759
assign 1 181 760
has 1 181 760
assign 1 0 762
assign 1 0 765
assign 1 0 769
assign 1 0 772
assign 1 0 776
assign 1 182 779
new 0 182 779
assign 1 183 780
heldGet 0 183 780
addStep 1 183 781
heldSet 1 184 782
assign 1 185 783
NAMEPATHGet 0 185 783
typenameSet 1 185 784
resolveNp 0 186 785
createImpliedConstruct 2 187 786
assign 1 192 796
nextDescendGet 0 192 796
return 1 192 797
assign 1 196 810
new 0 196 810
heldSet 1 197 811
assign 1 198 812
NAMEPATHGet 0 198 812
typenameSet 1 198 813
assign 1 199 814
heldGet 0 199 814
heldSet 1 199 815
prepend 1 200 816
assign 1 202 817
new 0 202 817
assign 1 203 818
new 0 203 818
nameSet 1 203 819
assign 1 204 820
new 0 204 820
wasBoundSet 1 204 821
assign 1 205 822
new 0 205 822
boundSet 1 205 823
assign 1 206 824
new 0 206 824
isConstructSet 1 206 825
assign 1 207 826
new 0 207 826
wasImpliedConstructSet 1 207 827
heldSet 1 208 828
assign 1 209 829
CALLGet 0 209 829
typenameSet 1 209 830
return 1 0 834
return 1 0 837
assign 1 0 840
assign 1 0 844
return 1 0 848
return 1 0 851
assign 1 0 854
assign 1 0 858
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -653750385: return bem_create_0();
case -124285366: return bem_once_0();
case 267507275: return bem_transGetDirect_0();
case -1006837746: return bem_constGet_0();
case -634018133: return bem_tagGet_0();
case -1373657831: return bem_constGetDirect_0();
case 413395465: return bem_transGet_0();
case -1341034460: return bem_inFileGetDirect_0();
case 1612868412: return bem_ntypesGetDirect_0();
case 148544119: return bem_toString_0();
case -1092510954: return bem_copy_0();
case 971841201: return bem_fieldIteratorGet_0();
case 2146604653: return bem_new_0();
case -2007275567: return bem_many_0();
case 393738758: return bem_serializeToString_0();
case -1750720088: return bem_hashGet_0();
case 2144693643: return bem_deserializeClassNameGet_0();
case -212742483: return bem_echo_0();
case 908678857: return bem_print_0();
case -881577546: return bem_classNameGet_0();
case 1782351683: return bem_serializeContents_0();
case -224465120: return bem_sourceFileNameGet_0();
case 1099447992: return bem_fieldNamesGet_0();
case -77414626: return bem_inClassNpGet_0();
case -1639371095: return bem_ntypesGet_0();
case -855735856: return bem_buildGetDirect_0();
case 569361306: return bem_iteratorGet_0();
case 641839943: return bem_toAny_0();
case -2031839191: return bem_serializationIteratorGet_0();
case -1539689316: return bem_inFileGet_0();
case 1329238668: return bem_inClassNpGetDirect_0();
case -1385204784: return bem_buildGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1395946469: return bem_buildSetDirect_1(bevd_0);
case 1703616583: return bem_notEquals_1(bevd_0);
case -1965723084: return bem_end_1(bevd_0);
case 1597904464: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1872704661: return bem_inClassNpSet_1(bevd_0);
case -872115670: return bem_defined_1(bevd_0);
case 1022262742: return bem_ntypesSet_1(bevd_0);
case -1928510621: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 389856415: return bem_transSet_1(bevd_0);
case -249326151: return bem_copyTo_1(bevd_0);
case 1367146792: return bem_sameClass_1(bevd_0);
case 326949551: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 599273039: return bem_inFileSetDirect_1(bevd_0);
case 1730397553: return bem_undef_1(bevd_0);
case -884607798: return bem_def_1(bevd_0);
case -359346681: return bem_sameType_1(bevd_0);
case 1446250233: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -784006715: return bem_constSet_1(bevd_0);
case 307405501: return bem_inFileSet_1(bevd_0);
case 1236734559: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1098555327: return bem_begin_1(bevd_0);
case 389340449: return bem_otherType_1(bevd_0);
case -1586811529: return bem_undefined_1(bevd_0);
case 286558731: return bem_inClassNpSetDirect_1(bevd_0);
case -1565662060: return bem_sameObject_1(bevd_0);
case 1599409230: return bem_transSetDirect_1(bevd_0);
case -1519516879: return bem_equals_1(bevd_0);
case 403746227: return bem_buildSet_1(bevd_0);
case -448360789: return bem_otherClass_1(bevd_0);
case -493917687: return bem_constSetDirect_1(bevd_0);
case 1163482839: return bem_ntypesSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 29395685: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 827793836: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1899980628: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1061986002: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1194360433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -454033656: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 696322560: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 204885034: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass7_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass7_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst = (BEC_3_5_5_5_BuildVisitPass7) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;
}
}
