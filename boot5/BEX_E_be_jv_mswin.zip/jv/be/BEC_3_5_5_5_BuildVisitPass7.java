package be;
/* IO:File: source/build/Pass7.be */
public final class BEC_3_5_5_5_BuildVisitPass7 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_2 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_3 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_4 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_5 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_6 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_7 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass7_bels_8, 41));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_10 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_12 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_15 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_17 = {0x6E,0x65,0x77};
public static BEC_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_3_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpany_phold.bemd_0(1556587685);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(2041469865);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bemd_0(-507248646);
} /* Line: 41 */
if (bevp_inClassNp == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 43 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 45 */
bevt_16_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpany_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass7_bels_0));
bevp_build.bem_buildLiteral_2(beva_node, bevt_18_tmpany_phold);
} /* Line: 48 */
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_1));
bevp_build.bem_buildLiteral_2(beva_node, bevt_22_tmpany_phold);
} /* Line: 51 */
bevt_24_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpany_phold.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_26_tmpany_phold);
} /* Line: 54 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_3));
bevp_build.bem_buildLiteral_2(beva_node, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpany_phold);
} /* Line: 59 */
bevt_33_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpany_phold.bevi_int == bevt_34_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
beva_node.bem_heldSet_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_5));
bevp_build.bem_buildLiteral_2(beva_node, bevt_36_tmpany_phold);
} /* Line: 63 */
bevt_38_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpany_phold.bevi_int == bevt_39_tmpany_phold.bevi_int) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 69 */ {
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_6));
beva_node.bem_heldSet_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_7));
bevp_build.bem_buildLiteral_2(beva_node, bevt_41_tmpany_phold);
} /* Line: 71 */
 else  /* Line: 69 */ {
bevt_43_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpany_phold.bevi_int == bevt_44_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(-2113365927);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(-907968257);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 73 */ {
bevt_50_tmpany_phold = beva_node.bem_heldGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(1998078782);
if (bevt_49_tmpany_phold == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 74 */ {
if (bevl_nnode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_53_tmpany_phold = bevl_nnode.bemd_0(-1976602664);
bevt_54_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(-1890627721, bevt_54_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_52_tmpany_phold).bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_57_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0;
bevt_59_tmpany_phold = beva_node.bem_heldGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1998078782);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_55_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_55_tmpany_phold);
} /* Line: 75 */
 else  /* Line: 76 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = bevl_nnode.bemd_0(2134264229);
bevt_60_tmpany_phold.bemd_1(-1198421995, bevt_61_tmpany_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(-199981944);
bevt_62_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpany_phold;
} /* Line: 83 */
} /* Line: 74 */
 else  /* Line: 69 */ {
bevt_64_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 85 */ {
if (bevl_nnode == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_68_tmpany_phold = bevl_nnode.bemd_0(-1976602664);
bevt_69_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(-1328502463, bevt_69_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_67_tmpany_phold).bevi_bool) /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 86 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(906912307);
if (bevt_71_tmpany_phold == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = bevl_nnode.bemd_0(906912307);
bevl_ii = bevt_72_tmpany_phold.bemd_0(-1817966493);
while (true)
 /* Line: 89 */ {
bevt_73_tmpany_phold = bevl_ii.bemd_0(2096550402);
if (((BEC_2_5_4_LogicBool) bevt_73_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevl_i = bevl_ii.bemd_0(-2029555311);
bevt_75_tmpany_phold = bevl_i.bemd_0(-1976602664);
bevt_76_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(-1328502463, bevt_76_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_toremove.bemd_1(-101026126, bevl_i);
} /* Line: 92 */
} /* Line: 91 */
 else  /* Line: 89 */ {
break;
} /* Line: 89 */
} /* Line: 89 */
bevl_ii = bevl_toremove.bemd_0(-1817966493);
while (true)
 /* Line: 95 */ {
bevt_77_tmpany_phold = bevl_ii.bemd_0(2096550402);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 95 */ {
bevl_i = bevl_ii.bemd_0(-2029555311);
bevl_i.bemd_0(-199981944);
} /* Line: 97 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
} /* Line: 95 */
bevl_pc = bevl_nnode;
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(118348510, bevt_78_tmpany_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(-1198421995, bevt_79_tmpany_phold);
bevl_pc.bemd_1(-1056514080, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_82_tmpany_phold = bevl_dnode.bemd_0(-1976602664);
bevt_83_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(-1328502463, bevt_83_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_81_tmpany_phold).bevi_bool) /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(-481683394);
if (bevl_onode == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(38, bece_BEC_3_5_5_5_BuildVisitPass7_bels_9));
bevt_85_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpany_phold);
} /* Line: 111 */
 else  /* Line: 110 */ {
bevt_88_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpany_phold.bevi_int == bevt_89_tmpany_phold.bevi_int) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_91_tmpany_phold = bevl_gc.bemd_0(1998078782);
bevt_90_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpany_phold );
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-673473225, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1168367650, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1540062040, bevt_94_tmpany_phold);
} /* Line: 116 */
 else  /* Line: 117 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 118 */
} /* Line: 113 */
 else  /* Line: 110 */ {
bevt_96_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpany_phold.bevi_int == bevt_97_tmpany_phold.bevi_int) {
bevt_95_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_101_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(2134264229);
bevt_99_tmpany_phold = bevt_100_tmpany_phold.bemd_0(2107202263);
bevt_102_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bemd_1(-2022722079, bevt_102_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_98_tmpany_phold).bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_105_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_aliasedGet_0();
bevt_106_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpany_phold = bevt_104_tmpany_phold.bem_has_1(bevt_106_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpany_phold = bevl_gc.bemd_0(1998078782);
bevt_109_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpany_phold );
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_111_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-673473225, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1168367650, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1540062040, bevt_113_tmpany_phold);
} /* Line: 129 */
 else  /* Line: 130 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 131 */
} /* Line: 126 */
 else  /* Line: 110 */ {
bevt_115_tmpany_phold = bevl_gc.bemd_0(1998078782);
bevt_116_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass7_bels_10));
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(-1328502463, bevt_116_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_114_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_118_tmpany_phold = (new BEC_2_4_6_TextString(70, bece_BEC_3_5_5_5_BuildVisitPass7_bels_11));
bevt_117_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 134 */
 else  /* Line: 110 */ {
bevt_120_tmpany_phold = bevl_gc.bemd_0(1998078782);
bevt_121_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_12));
bevt_119_tmpany_phold = bevt_120_tmpany_phold.bemd_1(-1328502463, bevt_121_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_119_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_123_tmpany_phold = (new BEC_2_4_6_TextString(65, bece_BEC_3_5_5_5_BuildVisitPass7_bels_13));
bevt_122_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_122_tmpany_phold);
} /* Line: 136 */
} /* Line: 110 */
} /* Line: 110 */
} /* Line: 110 */
} /* Line: 110 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(-1622903671, bevl_onode);
bevl_dnode.bemd_0(-199981944);
} /* Line: 141 */
 else  /* Line: 142 */ {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1168367650, bevt_124_tmpany_phold);
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-673473225, bevt_125_tmpany_phold);
} /* Line: 144 */
} /* Line: 108 */
} /* Line: 86 */
 else  /* Line: 69 */ {
bevt_127_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpany_phold.bevi_int == bevt_128_tmpany_phold.bevi_int) {
bevt_126_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_131_tmpany_phold = (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_14));
bevt_130_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_130_tmpany_phold);
} /* Line: 153 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpany_phold.bevi_int == bevt_134_tmpany_phold.bevi_int) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevt_136_tmpany_phold = (new BEC_2_4_6_TextString(84, bece_BEC_3_5_5_5_BuildVisitPass7_bels_15));
bevt_135_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_135_tmpany_phold);
} /* Line: 158 */
bevt_137_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpany_phold);
} /* Line: 160 */
 else  /* Line: 69 */ {
bevt_139_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpany_phold.bevi_int == bevt_140_tmpany_phold.bevi_int) {
bevt_138_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
if (bevl_onode == null) {
bevt_142_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 166 */ {
bevt_144_tmpany_phold = (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_16));
bevt_143_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpany_phold);
} /* Line: 167 */
bevt_146_tmpany_phold = bevl_nnode.bemd_0(-1976602664);
bevt_147_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(-1328502463, bevt_147_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_145_tmpany_phold).bevi_bool) /* Line: 169 */ {
bevl_pnode = bevl_nnode.bemd_0(-918339921);
if (bevl_pnode == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_150_tmpany_phold = bevl_pnode.bemd_0(-1976602664);
bevt_151_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(-1890627721, bevt_151_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_149_tmpany_phold).bevi_bool) /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 171 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpany_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpany_phold = bevl_nnode.bemd_0(2134264229);
bevl_ga.bemd_1(-1198421995, bevt_153_tmpany_phold);
bevl_nnode.bemd_0(-199981944);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpany_phold.bevi_int == bevt_156_tmpany_phold.bevi_int) {
bevt_154_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpany_phold.bevi_bool) /* Line: 180 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 181 */
 else  /* Line: 180 */ {
bevt_158_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpany_phold.bevi_int == bevt_159_tmpany_phold.bevi_int) {
bevt_157_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_163_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(2134264229);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(2107202263);
bevt_164_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_1(-2022722079, bevt_164_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_160_tmpany_phold).bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_167_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bem_aliasedGet_0();
bevt_168_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bem_has_1(bevt_168_tmpany_phold);
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 182 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 182 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 182 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 188 */
} /* Line: 180 */
} /* Line: 180 */
} /* Line: 171 */
} /* Line: 169 */
} /* Line: 69 */
} /* Line: 69 */
} /* Line: 69 */
} /* Line: 69 */
bevt_171_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpany_phold;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) throws Throwable {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpany_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass7_bels_17));
bevl_gnc.bem_nameSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpany_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public final BEC_2_4_6_TextString bem_inFileGetDirect_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass7 bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {36, 39, 39, 39, 39, 40, 40, 41, 41, 41, 43, 43, 44, 45, 47, 47, 47, 47, 48, 48, 50, 50, 50, 50, 51, 51, 53, 53, 53, 53, 54, 54, 56, 56, 56, 56, 58, 58, 59, 59, 61, 61, 61, 61, 62, 62, 63, 63, 69, 69, 69, 69, 70, 70, 71, 71, 73, 73, 73, 73, 73, 73, 73, 0, 0, 0, 74, 74, 74, 74, 74, 74, 0, 74, 74, 74, 0, 0, 0, 0, 0, 75, 75, 75, 75, 75, 75, 77, 77, 77, 78, 79, 83, 83, 85, 85, 85, 85, 86, 86, 86, 86, 86, 0, 0, 0, 87, 87, 87, 88, 89, 89, 89, 90, 91, 91, 91, 92, 95, 95, 96, 97, 100, 101, 101, 102, 103, 103, 104, 105, 106, 107, 108, 108, 108, 108, 108, 0, 0, 0, 109, 110, 110, 111, 111, 111, 112, 112, 112, 112, 113, 113, 114, 114, 115, 115, 116, 116, 118, 120, 120, 120, 120, 120, 120, 120, 120, 120, 0, 120, 120, 120, 120, 0, 0, 0, 0, 0, 121, 122, 122, 123, 124, 124, 125, 126, 126, 127, 127, 128, 128, 129, 129, 131, 133, 133, 133, 134, 134, 134, 135, 135, 135, 136, 136, 136, 139, 140, 141, 143, 143, 144, 144, 148, 148, 148, 148, 151, 152, 152, 153, 153, 153, 155, 156, 157, 157, 157, 157, 158, 158, 158, 160, 160, 161, 161, 161, 161, 163, 166, 166, 0, 166, 166, 0, 0, 167, 167, 167, 169, 169, 169, 170, 171, 171, 0, 171, 171, 171, 0, 0, 172, 173, 173, 174, 175, 175, 176, 177, 178, 179, 180, 180, 180, 180, 181, 182, 182, 182, 182, 182, 182, 182, 182, 182, 0, 182, 182, 182, 182, 0, 0, 0, 0, 0, 183, 184, 184, 185, 186, 186, 187, 188, 193, 193, 197, 198, 199, 199, 200, 200, 201, 203, 204, 204, 205, 205, 206, 206, 207, 207, 208, 208, 209, 210, 210, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {222, 223, 224, 225, 230, 231, 232, 233, 234, 235, 237, 242, 243, 244, 246, 247, 248, 253, 254, 255, 257, 258, 259, 264, 265, 266, 268, 269, 270, 275, 276, 277, 279, 280, 281, 286, 287, 288, 289, 290, 292, 293, 294, 299, 300, 301, 302, 303, 305, 306, 307, 312, 313, 314, 315, 316, 319, 320, 321, 326, 327, 328, 329, 331, 334, 338, 341, 342, 343, 348, 349, 354, 355, 358, 359, 360, 362, 365, 369, 372, 376, 379, 380, 381, 382, 383, 384, 387, 388, 389, 390, 391, 392, 393, 397, 398, 399, 404, 405, 410, 411, 412, 413, 415, 418, 422, 425, 426, 431, 432, 433, 434, 437, 439, 440, 441, 442, 444, 451, 454, 456, 457, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 479, 480, 481, 482, 484, 487, 491, 494, 495, 500, 501, 502, 503, 506, 507, 508, 513, 514, 515, 517, 518, 519, 520, 521, 522, 525, 529, 530, 531, 536, 537, 538, 539, 540, 541, 543, 546, 547, 548, 549, 551, 554, 558, 561, 565, 568, 569, 570, 571, 572, 573, 574, 575, 576, 578, 579, 580, 581, 582, 583, 586, 590, 591, 592, 594, 595, 596, 599, 600, 601, 603, 604, 605, 611, 612, 613, 616, 617, 618, 619, 624, 625, 626, 631, 632, 633, 638, 639, 640, 641, 643, 644, 645, 646, 647, 652, 653, 654, 655, 657, 658, 661, 662, 663, 668, 669, 670, 675, 676, 679, 684, 685, 688, 692, 693, 694, 696, 697, 698, 700, 701, 706, 707, 710, 711, 712, 714, 717, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 738, 739, 742, 743, 744, 749, 750, 751, 752, 753, 754, 756, 759, 760, 761, 762, 764, 767, 771, 774, 778, 781, 782, 783, 784, 785, 786, 787, 788, 798, 799, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 836, 839, 842, 846, 850, 853, 856, 860};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 36 222
nextPeerGet 0 36 222
assign 1 39 223
typenameGet 0 39 223
assign 1 39 224
CLASSGet 0 39 224
assign 1 39 225
equals 1 39 230
assign 1 40 231
heldGet 0 40 231
assign 1 40 232
namepathGet 0 40 232
assign 1 41 233
heldGet 0 41 233
assign 1 41 234
fromFileGet 0 41 234
assign 1 41 235
toString 0 41 235
assign 1 43 237
def 1 43 242
inClassNpSet 1 44 243
inFileSet 1 45 244
assign 1 47 246
typenameGet 0 47 246
assign 1 47 247
INTLGet 0 47 247
assign 1 47 248
equals 1 47 253
assign 1 48 254
new 0 48 254
buildLiteral 2 48 255
assign 1 50 257
typenameGet 0 50 257
assign 1 50 258
FLOATLGet 0 50 258
assign 1 50 259
equals 1 50 264
assign 1 51 265
new 0 51 265
buildLiteral 2 51 266
assign 1 53 268
typenameGet 0 53 268
assign 1 53 269
STRINGLGet 0 53 269
assign 1 53 270
equals 1 53 275
assign 1 54 276
new 0 54 276
buildLiteral 2 54 277
assign 1 56 279
typenameGet 0 56 279
assign 1 56 280
WSTRINGLGet 0 56 280
assign 1 56 281
equals 1 56 286
assign 1 58 287
new 0 58 287
buildLiteral 2 58 288
assign 1 59 289
new 0 59 289
wideStringSet 1 59 290
assign 1 61 292
typenameGet 0 61 292
assign 1 61 293
TRUEGet 0 61 293
assign 1 61 294
equals 1 61 299
assign 1 62 300
new 0 62 300
heldSet 1 62 301
assign 1 63 302
new 0 63 302
buildLiteral 2 63 303
assign 1 69 305
typenameGet 0 69 305
assign 1 69 306
FALSEGet 0 69 306
assign 1 69 307
equals 1 69 312
assign 1 70 313
new 0 70 313
heldSet 1 70 314
assign 1 71 315
new 0 71 315
buildLiteral 2 71 316
assign 1 73 319
typenameGet 0 73 319
assign 1 73 320
VARGet 0 73 320
assign 1 73 321
equals 1 73 326
assign 1 73 327
heldGet 0 73 327
assign 1 73 328
isArgGet 0 73 328
assign 1 73 329
not 0 73 329
assign 1 0 331
assign 1 0 334
assign 1 0 338
assign 1 74 341
heldGet 0 74 341
assign 1 74 342
nameGet 0 74 342
assign 1 74 343
undef 1 74 348
assign 1 74 349
undef 1 74 354
assign 1 0 355
assign 1 74 358
typenameGet 0 74 358
assign 1 74 359
IDGet 0 74 359
assign 1 74 360
notEquals 1 74 360
assign 1 0 362
assign 1 0 365
assign 1 0 369
assign 1 0 372
assign 1 0 376
assign 1 75 379
new 0 75 379
assign 1 75 380
heldGet 0 75 380
assign 1 75 381
nameGet 0 75 381
assign 1 75 382
add 1 75 382
assign 1 75 383
new 2 75 383
throw 1 75 384
assign 1 77 387
heldGet 0 77 387
assign 1 77 388
heldGet 0 77 388
nameSet 1 77 389
addVariable 0 78 390
delete 0 79 391
assign 1 83 392
nextDescendGet 0 83 392
return 1 83 393
assign 1 85 397
typenameGet 0 85 397
assign 1 85 398
IDGet 0 85 398
assign 1 85 399
equals 1 85 404
assign 1 86 405
def 1 86 410
assign 1 86 411
typenameGet 0 86 411
assign 1 86 412
PARENSGet 0 86 412
assign 1 86 413
equals 1 86 413
assign 1 0 415
assign 1 0 418
assign 1 0 422
assign 1 87 425
containedGet 0 87 425
assign 1 87 426
def 1 87 431
assign 1 88 432
new 0 88 432
assign 1 89 433
containedGet 0 89 433
assign 1 89 434
iteratorGet 0 89 434
assign 1 89 437
hasNextGet 0 89 437
assign 1 90 439
nextGet 0 90 439
assign 1 91 440
typenameGet 0 91 440
assign 1 91 441
COMMAGet 0 91 441
assign 1 91 442
equals 1 91 442
addValue 1 92 444
assign 1 95 451
iteratorGet 0 95 451
assign 1 95 454
hasNextGet 0 95 454
assign 1 96 456
nextGet 0 96 456
delete 0 97 457
assign 1 100 464
assign 1 101 465
CALLGet 0 101 465
typenameSet 1 101 466
assign 1 102 467
new 0 102 467
assign 1 103 468
heldGet 0 103 468
nameSet 1 103 469
heldSet 1 104 470
delete 0 105 471
assign 1 106 472
assign 1 107 473
priorPeerGet 0 107 473
assign 1 108 474
def 1 108 479
assign 1 108 480
typenameGet 0 108 480
assign 1 108 481
DOTGet 0 108 481
assign 1 108 482
equals 1 108 482
assign 1 0 484
assign 1 0 487
assign 1 0 491
assign 1 109 494
priorPeerGet 0 109 494
assign 1 110 495
undef 1 110 500
assign 1 111 501
new 0 111 501
assign 1 111 502
new 2 111 502
throw 1 111 503
assign 1 112 506
typenameGet 0 112 506
assign 1 112 507
NAMEPATHGet 0 112 507
assign 1 112 508
equals 1 112 513
assign 1 113 514
nameGet 0 113 514
assign 1 113 515
isNewish 1 113 515
assign 1 114 517
new 0 114 517
wasBoundSet 1 114 518
assign 1 115 519
new 0 115 519
boundSet 1 115 520
assign 1 116 521
new 0 116 521
isConstructSet 1 116 522
createImpliedConstruct 2 118 525
assign 1 120 529
typenameGet 0 120 529
assign 1 120 530
IDGet 0 120 530
assign 1 120 531
equals 1 120 536
assign 1 120 537
transUnitGet 0 120 537
assign 1 120 538
heldGet 0 120 538
assign 1 120 539
aliasedGet 0 120 539
assign 1 120 540
heldGet 0 120 540
assign 1 120 541
has 1 120 541
assign 1 0 543
assign 1 120 546
emitDataGet 0 120 546
assign 1 120 547
aliasedGet 0 120 547
assign 1 120 548
heldGet 0 120 548
assign 1 120 549
has 1 120 549
assign 1 0 551
assign 1 0 554
assign 1 0 558
assign 1 0 561
assign 1 0 565
assign 1 121 568
new 0 121 568
assign 1 122 569
heldGet 0 122 569
addStep 1 122 570
heldSet 1 123 571
assign 1 124 572
NAMEPATHGet 0 124 572
typenameSet 1 124 573
resolveNp 0 125 574
assign 1 126 575
nameGet 0 126 575
assign 1 126 576
isNewish 1 126 576
assign 1 127 578
new 0 127 578
wasBoundSet 1 127 579
assign 1 128 580
new 0 128 580
boundSet 1 128 581
assign 1 129 582
new 0 129 582
isConstructSet 1 129 583
createImpliedConstruct 2 131 586
assign 1 133 590
nameGet 0 133 590
assign 1 133 591
new 0 133 591
assign 1 133 592
equals 1 133 592
assign 1 134 594
new 0 134 594
assign 1 134 595
new 2 134 595
throw 1 134 596
assign 1 135 599
nameGet 0 135 599
assign 1 135 600
new 0 135 600
assign 1 135 601
equals 1 135 601
assign 1 136 603
new 0 136 603
assign 1 136 604
new 2 136 604
throw 1 136 605
delete 0 139 611
prepend 1 140 612
delete 0 141 613
assign 1 143 616
new 0 143 616
boundSet 1 143 617
assign 1 144 618
new 0 144 618
wasBoundSet 1 144 619
assign 1 148 624
typenameGet 0 148 624
assign 1 148 625
IDXGet 0 148 625
assign 1 148 626
equals 1 148 631
assign 1 151 632
priorPeerGet 0 151 632
assign 1 152 633
undef 1 152 638
assign 1 153 639
new 0 153 639
assign 1 153 640
new 2 153 640
throw 1 153 641
delete 0 155 643
prepend 1 156 644
assign 1 157 645
typenameGet 0 157 645
assign 1 157 646
NAMEPATHGet 0 157 646
assign 1 157 647
equals 1 157 652
assign 1 158 653
new 0 158 653
assign 1 158 654
new 2 158 654
throw 1 158 655
assign 1 160 657
IDXACCGet 0 160 657
typenameSet 1 160 658
assign 1 161 661
typenameGet 0 161 661
assign 1 161 662
DOTGet 0 161 662
assign 1 161 663
equals 1 161 668
assign 1 163 669
priorPeerGet 0 163 669
assign 1 166 670
undef 1 166 675
assign 1 0 676
assign 1 166 679
undef 1 166 684
assign 1 0 685
assign 1 0 688
assign 1 167 692
new 0 167 692
assign 1 167 693
new 2 167 693
throw 1 167 694
assign 1 169 696
typenameGet 0 169 696
assign 1 169 697
IDGet 0 169 697
assign 1 169 698
equals 1 169 698
assign 1 170 700
nextPeerGet 0 170 700
assign 1 171 701
undef 1 171 706
assign 1 0 707
assign 1 171 710
typenameGet 0 171 710
assign 1 171 711
PARENSGet 0 171 711
assign 1 171 712
notEquals 1 171 712
assign 1 0 714
assign 1 0 717
assign 1 172 721
priorPeerGet 0 172 721
assign 1 173 722
ACCESSORGet 0 173 722
typenameSet 1 173 723
assign 1 174 724
new 0 174 724
assign 1 175 725
heldGet 0 175 725
nameSet 1 175 726
delete 0 176 727
delete 0 177 728
heldSet 1 178 729
addValue 1 179 730
assign 1 180 731
typenameGet 0 180 731
assign 1 180 732
NAMEPATHGet 0 180 732
assign 1 180 733
equals 1 180 738
createImpliedConstruct 2 181 739
assign 1 182 742
typenameGet 0 182 742
assign 1 182 743
IDGet 0 182 743
assign 1 182 744
equals 1 182 749
assign 1 182 750
transUnitGet 0 182 750
assign 1 182 751
heldGet 0 182 751
assign 1 182 752
aliasedGet 0 182 752
assign 1 182 753
heldGet 0 182 753
assign 1 182 754
has 1 182 754
assign 1 0 756
assign 1 182 759
emitDataGet 0 182 759
assign 1 182 760
aliasedGet 0 182 760
assign 1 182 761
heldGet 0 182 761
assign 1 182 762
has 1 182 762
assign 1 0 764
assign 1 0 767
assign 1 0 771
assign 1 0 774
assign 1 0 778
assign 1 183 781
new 0 183 781
assign 1 184 782
heldGet 0 184 782
addStep 1 184 783
heldSet 1 185 784
assign 1 186 785
NAMEPATHGet 0 186 785
typenameSet 1 186 786
resolveNp 0 187 787
createImpliedConstruct 2 188 788
assign 1 193 798
nextDescendGet 0 193 798
return 1 193 799
assign 1 197 812
new 0 197 812
heldSet 1 198 813
assign 1 199 814
NAMEPATHGet 0 199 814
typenameSet 1 199 815
assign 1 200 816
heldGet 0 200 816
heldSet 1 200 817
prepend 1 201 818
assign 1 203 819
new 0 203 819
assign 1 204 820
new 0 204 820
nameSet 1 204 821
assign 1 205 822
new 0 205 822
wasBoundSet 1 205 823
assign 1 206 824
new 0 206 824
boundSet 1 206 825
assign 1 207 826
new 0 207 826
isConstructSet 1 207 827
assign 1 208 828
new 0 208 828
wasImpliedConstructSet 1 208 829
heldSet 1 209 830
assign 1 210 831
CALLGet 0 210 831
typenameSet 1 210 832
return 1 0 836
return 1 0 839
assign 1 0 842
assign 1 0 846
return 1 0 850
return 1 0 853
assign 1 0 856
assign 1 0 860
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -201292676: return bem_create_0();
case -2065475128: return bem_tagGet_0();
case -675087737: return bem_inFileGetDirect_0();
case -507248646: return bem_toString_0();
case -479220991: return bem_echo_0();
case -1258914489: return bem_inClassNpGetDirect_0();
case 67894489: return bem_sourceFileNameGet_0();
case -1251831938: return bem_buildGetDirect_0();
case 1509454415: return bem_fieldNamesGet_0();
case -755857848: return bem_serializeToString_0();
case -2138329474: return bem_transGetDirect_0();
case -842698583: return bem_print_0();
case -1011972693: return bem_classNameGet_0();
case -1312089850: return bem_serializationIteratorGet_0();
case -344675330: return bem_inClassNpGet_0();
case 116405623: return bem_once_0();
case 1514512159: return bem_buildGet_0();
case 838598675: return bem_deserializeClassNameGet_0();
case 2027881489: return bem_new_0();
case -1817966493: return bem_iteratorGet_0();
case 66023749: return bem_copy_0();
case 1767145499: return bem_toAny_0();
case 1880418594: return bem_many_0();
case 1495319176: return bem_constGet_0();
case 356935991: return bem_transGet_0();
case 1334238154: return bem_hashGet_0();
case 434514320: return bem_ntypesGetDirect_0();
case 2099495156: return bem_inFileGet_0();
case 1292255745: return bem_fieldIteratorGet_0();
case -1646346909: return bem_constGetDirect_0();
case -290928993: return bem_ntypesGet_0();
case 1319463124: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1968558358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1732521280: return bem_buildSetDirect_1(bevd_0);
case 535012638: return bem_transSetDirect_1(bevd_0);
case -960194292: return bem_constSet_1(bevd_0);
case -568061321: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1508117625: return bem_otherClass_1(bevd_0);
case 1741432894: return bem_inClassNpSetDirect_1(bevd_0);
case 236521366: return bem_def_1(bevd_0);
case 1902941795: return bem_defined_1(bevd_0);
case 1201016043: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 972161040: return bem_ntypesSetDirect_1(bevd_0);
case -1368755046: return bem_transSet_1(bevd_0);
case 824292706: return bem_sameType_1(bevd_0);
case -890367556: return bem_undefined_1(bevd_0);
case 358154948: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1867831329: return bem_buildSet_1(bevd_0);
case 440989655: return bem_copyTo_1(bevd_0);
case -1259967062: return bem_constSetDirect_1(bevd_0);
case 931801515: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1644447138: return bem_ntypesSet_1(bevd_0);
case -737237761: return bem_sameObject_1(bevd_0);
case -1932360992: return bem_inFileSet_1(bevd_0);
case 47055995: return bem_begin_1(bevd_0);
case 577728063: return bem_inClassNpSet_1(bevd_0);
case -1890627721: return bem_notEquals_1(bevd_0);
case 1317453949: return bem_sameClass_1(bevd_0);
case 1751676394: return bem_otherType_1(bevd_0);
case 137067553: return bem_end_1(bevd_0);
case -1698892491: return bem_inFileSetDirect_1(bevd_0);
case -1483817890: return bem_undef_1(bevd_0);
case -1328502463: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 77948450: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1008558996: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 139476281: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1704645214: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1221915514: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -778494517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1737168375: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1068088880: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass7_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass7_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst = (BEC_3_5_5_5_BuildVisitPass7) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;
}
}
