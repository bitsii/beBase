package be;
/* IO:File: source/build/Pass7.be */
public final class BEC_3_5_5_5_BuildVisitPass7 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_2 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_3 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_5 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_6 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_7 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_8 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_10 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_15 = {0x6E,0x65,0x77};
public static BEC_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_3_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_5_4_BuildNode bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_4_3_MathInt bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_6_6_SystemObject bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_5_4_LogicBool bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_4_3_MathInt bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_6_6_SystemObject bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
BEC_2_6_6_SystemObject bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_104_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_105_ta_ph = null;
BEC_2_6_6_SystemObject bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_4_3_MathInt bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_6_6_SystemObject bevt_110_ta_ph = null;
BEC_2_5_4_LogicBool bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_5_4_LogicBool bevt_113_ta_ph = null;
BEC_2_6_6_SystemObject bevt_114_ta_ph = null;
BEC_2_6_6_SystemObject bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_117_ta_ph = null;
BEC_2_4_6_TextString bevt_118_ta_ph = null;
BEC_2_6_6_SystemObject bevt_119_ta_ph = null;
BEC_2_6_6_SystemObject bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_122_ta_ph = null;
BEC_2_4_6_TextString bevt_123_ta_ph = null;
BEC_2_5_4_LogicBool bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_5_4_LogicBool bevt_126_ta_ph = null;
BEC_2_4_3_MathInt bevt_127_ta_ph = null;
BEC_2_4_3_MathInt bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_130_ta_ph = null;
BEC_2_4_6_TextString bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_4_3_MathInt bevt_134_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_135_ta_ph = null;
BEC_2_4_6_TextString bevt_136_ta_ph = null;
BEC_2_4_3_MathInt bevt_137_ta_ph = null;
BEC_2_5_4_LogicBool bevt_138_ta_ph = null;
BEC_2_4_3_MathInt bevt_139_ta_ph = null;
BEC_2_4_3_MathInt bevt_140_ta_ph = null;
BEC_2_5_4_LogicBool bevt_141_ta_ph = null;
BEC_2_5_4_LogicBool bevt_142_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_143_ta_ph = null;
BEC_2_4_6_TextString bevt_144_ta_ph = null;
BEC_2_6_6_SystemObject bevt_145_ta_ph = null;
BEC_2_6_6_SystemObject bevt_146_ta_ph = null;
BEC_2_4_3_MathInt bevt_147_ta_ph = null;
BEC_2_5_4_LogicBool bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_6_6_SystemObject bevt_150_ta_ph = null;
BEC_2_4_3_MathInt bevt_151_ta_ph = null;
BEC_2_4_3_MathInt bevt_152_ta_ph = null;
BEC_2_6_6_SystemObject bevt_153_ta_ph = null;
BEC_2_5_4_LogicBool bevt_154_ta_ph = null;
BEC_2_4_3_MathInt bevt_155_ta_ph = null;
BEC_2_4_3_MathInt bevt_156_ta_ph = null;
BEC_2_5_4_LogicBool bevt_157_ta_ph = null;
BEC_2_4_3_MathInt bevt_158_ta_ph = null;
BEC_2_4_3_MathInt bevt_159_ta_ph = null;
BEC_2_6_6_SystemObject bevt_160_ta_ph = null;
BEC_2_6_6_SystemObject bevt_161_ta_ph = null;
BEC_2_6_6_SystemObject bevt_162_ta_ph = null;
BEC_2_6_6_SystemObject bevt_163_ta_ph = null;
BEC_2_6_6_SystemObject bevt_164_ta_ph = null;
BEC_2_5_4_LogicBool bevt_165_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_166_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_167_ta_ph = null;
BEC_2_6_6_SystemObject bevt_168_ta_ph = null;
BEC_2_6_6_SystemObject bevt_169_ta_ph = null;
BEC_2_4_3_MathInt bevt_170_ta_ph = null;
BEC_2_5_4_BuildNode bevt_171_ta_ph = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 38*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_ta_ph.bemd_0(-307727581);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(670900669);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_ta_ph.bemd_0(-989279639);
} /* Line: 40*/
if (bevp_inClassNp == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 42*/ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 44*/
bevt_16_ta_ph = beva_node.bem_typenameGet_0();
bevt_17_ta_ph = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 46*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass7_bels_0));
bevp_build.bem_buildLiteral_2(beva_node, bevt_18_ta_ph);
} /* Line: 47*/
bevt_20_ta_ph = beva_node.bem_typenameGet_0();
bevt_21_ta_ph = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_ta_ph.bevi_int == bevt_21_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_22_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_1));
bevp_build.bem_buildLiteral_2(beva_node, bevt_22_ta_ph);
} /* Line: 50*/
bevt_24_ta_ph = beva_node.bem_typenameGet_0();
bevt_25_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_ta_ph.bevi_int == bevt_25_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 52*/ {
bevt_26_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_26_ta_ph);
} /* Line: 53*/
bevt_28_ta_ph = beva_node.bem_typenameGet_0();
bevt_29_ta_ph = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_ta_ph.bevi_int == bevt_29_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_30_ta_ph);
bevt_31_ta_ph = be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_ta_ph);
} /* Line: 58*/
bevt_33_ta_ph = beva_node.bem_typenameGet_0();
bevt_34_ta_ph = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_ta_ph.bevi_int == bevt_34_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass7_bels_3));
beva_node.bem_heldSet_1(bevt_35_ta_ph);
bevt_36_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
bevp_build.bem_buildLiteral_2(beva_node, bevt_36_ta_ph);
} /* Line: 62*/
bevt_38_ta_ph = beva_node.bem_typenameGet_0();
bevt_39_ta_ph = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_ta_ph.bevi_int == bevt_39_ta_ph.bevi_int) {
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 68*/ {
bevt_40_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_5));
beva_node.bem_heldSet_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
bevp_build.bem_buildLiteral_2(beva_node, bevt_41_ta_ph);
} /* Line: 70*/
 else /* Line: 68*/ {
bevt_43_ta_ph = beva_node.bem_typenameGet_0();
bevt_44_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_43_ta_ph.bevi_int == bevt_44_ta_ph.bevi_int) {
bevt_42_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_42_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_47_ta_ph = beva_node.bem_heldGet_0();
bevt_46_ta_ph = bevt_47_ta_ph.bemd_0(-298968110);
bevt_45_ta_ph = bevt_46_ta_ph.bemd_0(1760971978);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 72*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 72*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 72*/
 else /* Line: 72*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 72*/ {
bevt_50_ta_ph = beva_node.bem_heldGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bemd_0(-1788131037);
if (bevt_49_ta_ph == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 73*/ {
if (bevl_nnode == null) {
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_53_ta_ph = bevl_nnode.bemd_0(-911241410);
bevt_54_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bemd_1(-1283958111, bevt_54_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_52_ta_ph).bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 73*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 73*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 73*/ {
bevt_57_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_3_5_5_5_BuildVisitPass7_bels_6));
bevt_59_ta_ph = beva_node.bem_heldGet_0();
bevt_58_ta_ph = bevt_59_ta_ph.bemd_0(-1788131037);
bevt_56_ta_ph = bevt_57_ta_ph.bem_add_1(bevt_58_ta_ph);
bevt_55_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_55_ta_ph);
} /* Line: 74*/
 else /* Line: 75*/ {
bevt_60_ta_ph = beva_node.bem_heldGet_0();
bevt_61_ta_ph = bevl_nnode.bemd_0(372755822);
bevt_60_ta_ph.bemd_1(1405243153, bevt_61_ta_ph);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(-1373699961);
bevt_62_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_62_ta_ph;
} /* Line: 82*/
} /* Line: 73*/
 else /* Line: 68*/ {
bevt_64_ta_ph = beva_node.bem_typenameGet_0();
bevt_65_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_64_ta_ph.bevi_int == bevt_65_ta_ph.bevi_int) {
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 84*/ {
if (bevl_nnode == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 85*/ {
bevt_68_ta_ph = bevl_nnode.bemd_0(-911241410);
bevt_69_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bemd_1(964719406, bevt_69_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_67_ta_ph).bevi_bool)/* Line: 85*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 85*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 85*/
 else /* Line: 85*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 85*/ {
bevt_71_ta_ph = bevl_nnode.bemd_0(-2017165191);
if (bevt_71_ta_ph == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 86*/ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_ta_ph = bevl_nnode.bemd_0(-2017165191);
bevl_ii = bevt_72_ta_ph.bemd_0(1018929608);
while (true)
/* Line: 88*/ {
bevt_73_ta_ph = bevl_ii.bemd_0(1420438839);
if (((BEC_2_5_4_LogicBool) bevt_73_ta_ph).bevi_bool)/* Line: 88*/ {
bevl_i = bevl_ii.bemd_0(2087009077);
bevt_75_ta_ph = bevl_i.bemd_0(-911241410);
bevt_76_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_74_ta_ph = bevt_75_ta_ph.bemd_1(964719406, bevt_76_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 90*/ {
bevl_toremove.bemd_1(1937927718, bevl_i);
} /* Line: 91*/
} /* Line: 90*/
 else /* Line: 88*/ {
break;
} /* Line: 88*/
} /* Line: 88*/
bevl_ii = bevl_toremove.bemd_0(1018929608);
while (true)
/* Line: 94*/ {
bevt_77_ta_ph = bevl_ii.bemd_0(1420438839);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 94*/ {
bevl_i = bevl_ii.bemd_0(2087009077);
bevl_i.bemd_0(-1373699961);
} /* Line: 96*/
 else /* Line: 94*/ {
break;
} /* Line: 94*/
} /* Line: 94*/
} /* Line: 94*/
bevl_pc = bevl_nnode;
bevt_78_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(1416357233, bevt_78_ta_ph);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_ta_ph = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1405243153, bevt_79_ta_ph);
bevl_pc.bemd_1(-79278615, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_82_ta_ph = bevl_dnode.bemd_0(-911241410);
bevt_83_ta_ph = bevp_ntypes.bem_DOTGet_0();
bevt_81_ta_ph = bevt_82_ta_ph.bemd_1(964719406, bevt_83_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_81_ta_ph).bevi_bool)/* Line: 107*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 107*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 107*/
 else /* Line: 107*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 107*/ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(-810863866);
if (bevl_onode == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 109*/ {
bevt_86_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_3_5_5_5_BuildVisitPass7_bels_7));
bevt_85_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_85_ta_ph);
} /* Line: 110*/
 else /* Line: 109*/ {
bevt_88_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_89_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_ta_ph.bevi_int == bevt_89_ta_ph.bevi_int) {
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 111*/ {
bevt_91_ta_ph = bevl_gc.bemd_0(-1788131037);
bevt_90_ta_ph = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_ta_ph );
if (bevt_90_ta_ph.bevi_bool)/* Line: 112*/ {
bevt_92_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1321394328, bevt_92_ta_ph);
bevt_93_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(639247177, bevt_93_ta_ph);
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(433420660, bevt_94_ta_ph);
} /* Line: 115*/
 else /* Line: 116*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 117*/
} /* Line: 112*/
 else /* Line: 109*/ {
bevt_96_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_97_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_96_ta_ph.bevi_int == bevt_97_ta_ph.bevi_int) {
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 119*/ {
bevt_101_ta_ph = beva_node.bem_transUnitGet_0();
bevt_100_ta_ph = bevt_101_ta_ph.bemd_0(372755822);
bevt_99_ta_ph = bevt_100_ta_ph.bemd_0(647149067);
bevt_102_ta_ph = bevl_onode.bem_heldGet_0();
bevt_98_ta_ph = bevt_99_ta_ph.bemd_1(343249686, bevt_102_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_98_ta_ph).bevi_bool)/* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 119*/ {
bevt_105_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_104_ta_ph = bevt_105_ta_ph.bem_aliasedGet_0();
bevt_106_ta_ph = bevl_onode.bem_heldGet_0();
bevt_103_ta_ph = bevt_104_ta_ph.bem_has_1(bevt_106_ta_ph);
if (bevt_103_ta_ph.bevi_bool)/* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 119*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 119*/
 else /* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 119*/ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_ta_ph = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_ta_ph);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_ta_ph);
bevl_onode.bem_resolveNp_0();
bevt_110_ta_ph = bevl_gc.bemd_0(-1788131037);
bevt_109_ta_ph = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_ta_ph );
if (bevt_109_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_111_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1321394328, bevt_111_ta_ph);
bevt_112_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(639247177, bevt_112_ta_ph);
bevt_113_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(433420660, bevt_113_ta_ph);
} /* Line: 128*/
 else /* Line: 129*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 130*/
} /* Line: 125*/
 else /* Line: 109*/ {
bevt_115_ta_ph = bevl_gc.bemd_0(-1788131037);
bevt_116_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass7_bels_8));
bevt_114_ta_ph = bevt_115_ta_ph.bemd_1(964719406, bevt_116_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_114_ta_ph).bevi_bool)/* Line: 132*/ {
bevt_118_ta_ph = (new BEC_2_4_6_TextString(70, bece_BEC_3_5_5_5_BuildVisitPass7_bels_9));
bevt_117_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_117_ta_ph);
} /* Line: 133*/
 else /* Line: 109*/ {
bevt_120_ta_ph = bevl_gc.bemd_0(-1788131037);
bevt_121_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_10));
bevt_119_ta_ph = bevt_120_ta_ph.bemd_1(964719406, bevt_121_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_119_ta_ph).bevi_bool)/* Line: 134*/ {
bevt_123_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_3_5_5_5_BuildVisitPass7_bels_11));
bevt_122_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_122_ta_ph);
} /* Line: 135*/
} /* Line: 109*/
} /* Line: 109*/
} /* Line: 109*/
} /* Line: 109*/
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(1349976346, bevl_onode);
bevl_dnode.bemd_0(-1373699961);
} /* Line: 140*/
 else /* Line: 141*/ {
bevt_124_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(639247177, bevt_124_ta_ph);
bevt_125_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1321394328, bevt_125_ta_ph);
} /* Line: 143*/
} /* Line: 107*/
} /* Line: 85*/
 else /* Line: 68*/ {
bevt_127_ta_ph = beva_node.bem_typenameGet_0();
bevt_128_ta_ph = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_ta_ph.bevi_int == bevt_128_ta_ph.bevi_int) {
bevt_126_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_126_ta_ph.bevi_bool)/* Line: 147*/ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 151*/ {
bevt_131_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_12));
bevt_130_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_130_ta_ph);
} /* Line: 152*/
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_134_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_ta_ph.bevi_int == bevt_134_ta_ph.bevi_int) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 156*/ {
bevt_136_ta_ph = (new BEC_2_4_6_TextString(84, bece_BEC_3_5_5_5_BuildVisitPass7_bels_13));
bevt_135_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_135_ta_ph);
} /* Line: 157*/
bevt_137_ta_ph = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_ta_ph);
} /* Line: 159*/
 else /* Line: 68*/ {
bevt_139_ta_ph = beva_node.bem_typenameGet_0();
bevt_140_ta_ph = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_ta_ph.bevi_int == bevt_140_ta_ph.bevi_int) {
bevt_138_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_138_ta_ph.bevi_bool)/* Line: 160*/ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_141_ta_ph.bevi_bool)/* Line: 165*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 165*/ {
if (bevl_onode == null) {
bevt_142_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_142_ta_ph.bevi_bool)/* Line: 165*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 165*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 165*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 165*/ {
bevt_144_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_14));
bevt_143_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_143_ta_ph);
} /* Line: 166*/
bevt_146_ta_ph = bevl_nnode.bemd_0(-911241410);
bevt_147_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_145_ta_ph = bevt_146_ta_ph.bemd_1(964719406, bevt_147_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_145_ta_ph).bevi_bool)/* Line: 168*/ {
bevl_pnode = bevl_nnode.bemd_0(-1402006877);
if (bevl_pnode == null) {
bevt_148_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_148_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
bevt_150_ta_ph = bevl_pnode.bemd_0(-911241410);
bevt_151_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_149_ta_ph = bevt_150_ta_ph.bemd_1(-1283958111, bevt_151_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_149_ta_ph).bevi_bool)/* Line: 170*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 170*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 170*/ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_ta_ph);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_ta_ph = bevl_nnode.bemd_0(372755822);
bevl_ga.bemd_1(1405243153, bevt_153_ta_ph);
bevl_nnode.bemd_0(-1373699961);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_156_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_ta_ph.bevi_int == bevt_156_ta_ph.bevi_int) {
bevt_154_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_154_ta_ph.bevi_bool)/* Line: 179*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 180*/
 else /* Line: 179*/ {
bevt_158_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_159_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_158_ta_ph.bevi_int == bevt_159_ta_ph.bevi_int) {
bevt_157_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_157_ta_ph.bevi_bool)/* Line: 181*/ {
bevt_163_ta_ph = beva_node.bem_transUnitGet_0();
bevt_162_ta_ph = bevt_163_ta_ph.bemd_0(372755822);
bevt_161_ta_ph = bevt_162_ta_ph.bemd_0(647149067);
bevt_164_ta_ph = bevl_onode.bem_heldGet_0();
bevt_160_ta_ph = bevt_161_ta_ph.bemd_1(343249686, bevt_164_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_160_ta_ph).bevi_bool)/* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 181*/ {
bevt_167_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_166_ta_ph = bevt_167_ta_ph.bem_aliasedGet_0();
bevt_168_ta_ph = bevl_onode.bem_heldGet_0();
bevt_165_ta_ph = bevt_166_ta_ph.bem_has_1(bevt_168_ta_ph);
if (bevt_165_ta_ph.bevi_bool)/* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 181*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 181*/
 else /* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 181*/ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_ta_ph = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_ta_ph);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_ta_ph);
bevl_onode.bem_resolveNp_0();
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 187*/
} /* Line: 179*/
} /* Line: 179*/
} /* Line: 170*/
} /* Line: 168*/
} /* Line: 68*/
} /* Line: 68*/
} /* Line: 68*/
} /* Line: 68*/
bevt_171_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_171_ta_ph;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) throws Throwable {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_ta_ph);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass7_bels_15));
bevl_gnc.bem_nameSet_1(bevt_2_ta_ph);
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_ta_ph);
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_ta_ph);
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_ta_ph);
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_ta_ph);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {35, 38, 38, 38, 38, 39, 39, 40, 40, 40, 42, 42, 43, 44, 46, 46, 46, 46, 47, 47, 49, 49, 49, 49, 50, 50, 52, 52, 52, 52, 53, 53, 55, 55, 55, 55, 57, 57, 58, 58, 60, 60, 60, 60, 61, 61, 62, 62, 68, 68, 68, 68, 69, 69, 70, 70, 72, 72, 72, 72, 72, 72, 72, 0, 0, 0, 73, 73, 73, 73, 73, 73, 0, 73, 73, 73, 0, 0, 0, 0, 0, 74, 74, 74, 74, 74, 74, 76, 76, 76, 77, 78, 82, 82, 84, 84, 84, 84, 85, 85, 85, 85, 85, 0, 0, 0, 86, 86, 86, 87, 88, 88, 88, 89, 90, 90, 90, 91, 94, 94, 95, 96, 99, 100, 100, 101, 102, 102, 103, 104, 105, 106, 107, 107, 107, 107, 107, 0, 0, 0, 108, 109, 109, 110, 110, 110, 111, 111, 111, 111, 112, 112, 113, 113, 114, 114, 115, 115, 117, 119, 119, 119, 119, 119, 119, 119, 119, 119, 0, 119, 119, 119, 119, 0, 0, 0, 0, 0, 120, 121, 121, 122, 123, 123, 124, 125, 125, 126, 126, 127, 127, 128, 128, 130, 132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 138, 139, 140, 142, 142, 143, 143, 147, 147, 147, 147, 150, 151, 151, 152, 152, 152, 154, 155, 156, 156, 156, 156, 157, 157, 157, 159, 159, 160, 160, 160, 160, 162, 165, 165, 0, 165, 165, 0, 0, 166, 166, 166, 168, 168, 168, 169, 170, 170, 0, 170, 170, 170, 0, 0, 171, 172, 172, 173, 174, 174, 175, 176, 177, 178, 179, 179, 179, 179, 180, 181, 181, 181, 181, 181, 181, 181, 181, 181, 0, 181, 181, 181, 181, 0, 0, 0, 0, 0, 182, 183, 183, 184, 185, 185, 186, 187, 192, 192, 196, 197, 198, 198, 199, 199, 200, 202, 203, 203, 204, 204, 205, 205, 206, 206, 207, 207, 208, 209, 209, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {219, 220, 221, 222, 227, 228, 229, 230, 231, 232, 234, 239, 240, 241, 243, 244, 245, 250, 251, 252, 254, 255, 256, 261, 262, 263, 265, 266, 267, 272, 273, 274, 276, 277, 278, 283, 284, 285, 286, 287, 289, 290, 291, 296, 297, 298, 299, 300, 302, 303, 304, 309, 310, 311, 312, 313, 316, 317, 318, 323, 324, 325, 326, 328, 331, 335, 338, 339, 340, 345, 346, 351, 352, 355, 356, 357, 359, 362, 366, 369, 373, 376, 377, 378, 379, 380, 381, 384, 385, 386, 387, 388, 389, 390, 394, 395, 396, 401, 402, 407, 408, 409, 410, 412, 415, 419, 422, 423, 428, 429, 430, 431, 434, 436, 437, 438, 439, 441, 448, 451, 453, 454, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 476, 477, 478, 479, 481, 484, 488, 491, 492, 497, 498, 499, 500, 503, 504, 505, 510, 511, 512, 514, 515, 516, 517, 518, 519, 522, 526, 527, 528, 533, 534, 535, 536, 537, 538, 540, 543, 544, 545, 546, 548, 551, 555, 558, 562, 565, 566, 567, 568, 569, 570, 571, 572, 573, 575, 576, 577, 578, 579, 580, 583, 587, 588, 589, 591, 592, 593, 596, 597, 598, 600, 601, 602, 608, 609, 610, 613, 614, 615, 616, 621, 622, 623, 628, 629, 630, 635, 636, 637, 638, 640, 641, 642, 643, 644, 649, 650, 651, 652, 654, 655, 658, 659, 660, 665, 666, 667, 672, 673, 676, 681, 682, 685, 689, 690, 691, 693, 694, 695, 697, 698, 703, 704, 707, 708, 709, 711, 714, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 735, 736, 739, 740, 741, 746, 747, 748, 749, 750, 751, 753, 756, 757, 758, 759, 761, 764, 768, 771, 775, 778, 779, 780, 781, 782, 783, 784, 785, 795, 796, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 833, 836, 840, 843};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 35 219
nextPeerGet 0 35 219
assign 1 38 220
typenameGet 0 38 220
assign 1 38 221
CLASSGet 0 38 221
assign 1 38 222
equals 1 38 227
assign 1 39 228
heldGet 0 39 228
assign 1 39 229
namepathGet 0 39 229
assign 1 40 230
heldGet 0 40 230
assign 1 40 231
fromFileGet 0 40 231
assign 1 40 232
toString 0 40 232
assign 1 42 234
def 1 42 239
inClassNpSet 1 43 240
inFileSet 1 44 241
assign 1 46 243
typenameGet 0 46 243
assign 1 46 244
INTLGet 0 46 244
assign 1 46 245
equals 1 46 250
assign 1 47 251
new 0 47 251
buildLiteral 2 47 252
assign 1 49 254
typenameGet 0 49 254
assign 1 49 255
FLOATLGet 0 49 255
assign 1 49 256
equals 1 49 261
assign 1 50 262
new 0 50 262
buildLiteral 2 50 263
assign 1 52 265
typenameGet 0 52 265
assign 1 52 266
STRINGLGet 0 52 266
assign 1 52 267
equals 1 52 272
assign 1 53 273
new 0 53 273
buildLiteral 2 53 274
assign 1 55 276
typenameGet 0 55 276
assign 1 55 277
WSTRINGLGet 0 55 277
assign 1 55 278
equals 1 55 283
assign 1 57 284
new 0 57 284
buildLiteral 2 57 285
assign 1 58 286
new 0 58 286
wideStringSet 1 58 287
assign 1 60 289
typenameGet 0 60 289
assign 1 60 290
TRUEGet 0 60 290
assign 1 60 291
equals 1 60 296
assign 1 61 297
new 0 61 297
heldSet 1 61 298
assign 1 62 299
new 0 62 299
buildLiteral 2 62 300
assign 1 68 302
typenameGet 0 68 302
assign 1 68 303
FALSEGet 0 68 303
assign 1 68 304
equals 1 68 309
assign 1 69 310
new 0 69 310
heldSet 1 69 311
assign 1 70 312
new 0 70 312
buildLiteral 2 70 313
assign 1 72 316
typenameGet 0 72 316
assign 1 72 317
VARGet 0 72 317
assign 1 72 318
equals 1 72 323
assign 1 72 324
heldGet 0 72 324
assign 1 72 325
isArgGet 0 72 325
assign 1 72 326
not 0 72 326
assign 1 0 328
assign 1 0 331
assign 1 0 335
assign 1 73 338
heldGet 0 73 338
assign 1 73 339
nameGet 0 73 339
assign 1 73 340
undef 1 73 345
assign 1 73 346
undef 1 73 351
assign 1 0 352
assign 1 73 355
typenameGet 0 73 355
assign 1 73 356
IDGet 0 73 356
assign 1 73 357
notEquals 1 73 357
assign 1 0 359
assign 1 0 362
assign 1 0 366
assign 1 0 369
assign 1 0 373
assign 1 74 376
new 0 74 376
assign 1 74 377
heldGet 0 74 377
assign 1 74 378
nameGet 0 74 378
assign 1 74 379
add 1 74 379
assign 1 74 380
new 2 74 380
throw 1 74 381
assign 1 76 384
heldGet 0 76 384
assign 1 76 385
heldGet 0 76 385
nameSet 1 76 386
addVariable 0 77 387
delete 0 78 388
assign 1 82 389
nextDescendGet 0 82 389
return 1 82 390
assign 1 84 394
typenameGet 0 84 394
assign 1 84 395
IDGet 0 84 395
assign 1 84 396
equals 1 84 401
assign 1 85 402
def 1 85 407
assign 1 85 408
typenameGet 0 85 408
assign 1 85 409
PARENSGet 0 85 409
assign 1 85 410
equals 1 85 410
assign 1 0 412
assign 1 0 415
assign 1 0 419
assign 1 86 422
containedGet 0 86 422
assign 1 86 423
def 1 86 428
assign 1 87 429
new 0 87 429
assign 1 88 430
containedGet 0 88 430
assign 1 88 431
iteratorGet 0 88 431
assign 1 88 434
hasNextGet 0 88 434
assign 1 89 436
nextGet 0 89 436
assign 1 90 437
typenameGet 0 90 437
assign 1 90 438
COMMAGet 0 90 438
assign 1 90 439
equals 1 90 439
addValue 1 91 441
assign 1 94 448
iteratorGet 0 94 448
assign 1 94 451
hasNextGet 0 94 451
assign 1 95 453
nextGet 0 95 453
delete 0 96 454
assign 1 99 461
assign 1 100 462
CALLGet 0 100 462
typenameSet 1 100 463
assign 1 101 464
new 0 101 464
assign 1 102 465
heldGet 0 102 465
nameSet 1 102 466
heldSet 1 103 467
delete 0 104 468
assign 1 105 469
assign 1 106 470
priorPeerGet 0 106 470
assign 1 107 471
def 1 107 476
assign 1 107 477
typenameGet 0 107 477
assign 1 107 478
DOTGet 0 107 478
assign 1 107 479
equals 1 107 479
assign 1 0 481
assign 1 0 484
assign 1 0 488
assign 1 108 491
priorPeerGet 0 108 491
assign 1 109 492
undef 1 109 497
assign 1 110 498
new 0 110 498
assign 1 110 499
new 2 110 499
throw 1 110 500
assign 1 111 503
typenameGet 0 111 503
assign 1 111 504
NAMEPATHGet 0 111 504
assign 1 111 505
equals 1 111 510
assign 1 112 511
nameGet 0 112 511
assign 1 112 512
isNewish 1 112 512
assign 1 113 514
new 0 113 514
wasBoundSet 1 113 515
assign 1 114 516
new 0 114 516
boundSet 1 114 517
assign 1 115 518
new 0 115 518
isConstructSet 1 115 519
createImpliedConstruct 2 117 522
assign 1 119 526
typenameGet 0 119 526
assign 1 119 527
IDGet 0 119 527
assign 1 119 528
equals 1 119 533
assign 1 119 534
transUnitGet 0 119 534
assign 1 119 535
heldGet 0 119 535
assign 1 119 536
aliasedGet 0 119 536
assign 1 119 537
heldGet 0 119 537
assign 1 119 538
has 1 119 538
assign 1 0 540
assign 1 119 543
emitDataGet 0 119 543
assign 1 119 544
aliasedGet 0 119 544
assign 1 119 545
heldGet 0 119 545
assign 1 119 546
has 1 119 546
assign 1 0 548
assign 1 0 551
assign 1 0 555
assign 1 0 558
assign 1 0 562
assign 1 120 565
new 0 120 565
assign 1 121 566
heldGet 0 121 566
addStep 1 121 567
heldSet 1 122 568
assign 1 123 569
NAMEPATHGet 0 123 569
typenameSet 1 123 570
resolveNp 0 124 571
assign 1 125 572
nameGet 0 125 572
assign 1 125 573
isNewish 1 125 573
assign 1 126 575
new 0 126 575
wasBoundSet 1 126 576
assign 1 127 577
new 0 127 577
boundSet 1 127 578
assign 1 128 579
new 0 128 579
isConstructSet 1 128 580
createImpliedConstruct 2 130 583
assign 1 132 587
nameGet 0 132 587
assign 1 132 588
new 0 132 588
assign 1 132 589
equals 1 132 589
assign 1 133 591
new 0 133 591
assign 1 133 592
new 2 133 592
throw 1 133 593
assign 1 134 596
nameGet 0 134 596
assign 1 134 597
new 0 134 597
assign 1 134 598
equals 1 134 598
assign 1 135 600
new 0 135 600
assign 1 135 601
new 2 135 601
throw 1 135 602
delete 0 138 608
prepend 1 139 609
delete 0 140 610
assign 1 142 613
new 0 142 613
boundSet 1 142 614
assign 1 143 615
new 0 143 615
wasBoundSet 1 143 616
assign 1 147 621
typenameGet 0 147 621
assign 1 147 622
IDXGet 0 147 622
assign 1 147 623
equals 1 147 628
assign 1 150 629
priorPeerGet 0 150 629
assign 1 151 630
undef 1 151 635
assign 1 152 636
new 0 152 636
assign 1 152 637
new 2 152 637
throw 1 152 638
delete 0 154 640
prepend 1 155 641
assign 1 156 642
typenameGet 0 156 642
assign 1 156 643
NAMEPATHGet 0 156 643
assign 1 156 644
equals 1 156 649
assign 1 157 650
new 0 157 650
assign 1 157 651
new 2 157 651
throw 1 157 652
assign 1 159 654
IDXACCGet 0 159 654
typenameSet 1 159 655
assign 1 160 658
typenameGet 0 160 658
assign 1 160 659
DOTGet 0 160 659
assign 1 160 660
equals 1 160 665
assign 1 162 666
priorPeerGet 0 162 666
assign 1 165 667
undef 1 165 672
assign 1 0 673
assign 1 165 676
undef 1 165 681
assign 1 0 682
assign 1 0 685
assign 1 166 689
new 0 166 689
assign 1 166 690
new 2 166 690
throw 1 166 691
assign 1 168 693
typenameGet 0 168 693
assign 1 168 694
IDGet 0 168 694
assign 1 168 695
equals 1 168 695
assign 1 169 697
nextPeerGet 0 169 697
assign 1 170 698
undef 1 170 703
assign 1 0 704
assign 1 170 707
typenameGet 0 170 707
assign 1 170 708
PARENSGet 0 170 708
assign 1 170 709
notEquals 1 170 709
assign 1 0 711
assign 1 0 714
assign 1 171 718
priorPeerGet 0 171 718
assign 1 172 719
ACCESSORGet 0 172 719
typenameSet 1 172 720
assign 1 173 721
new 0 173 721
assign 1 174 722
heldGet 0 174 722
nameSet 1 174 723
delete 0 175 724
delete 0 176 725
heldSet 1 177 726
addValue 1 178 727
assign 1 179 728
typenameGet 0 179 728
assign 1 179 729
NAMEPATHGet 0 179 729
assign 1 179 730
equals 1 179 735
createImpliedConstruct 2 180 736
assign 1 181 739
typenameGet 0 181 739
assign 1 181 740
IDGet 0 181 740
assign 1 181 741
equals 1 181 746
assign 1 181 747
transUnitGet 0 181 747
assign 1 181 748
heldGet 0 181 748
assign 1 181 749
aliasedGet 0 181 749
assign 1 181 750
heldGet 0 181 750
assign 1 181 751
has 1 181 751
assign 1 0 753
assign 1 181 756
emitDataGet 0 181 756
assign 1 181 757
aliasedGet 0 181 757
assign 1 181 758
heldGet 0 181 758
assign 1 181 759
has 1 181 759
assign 1 0 761
assign 1 0 764
assign 1 0 768
assign 1 0 771
assign 1 0 775
assign 1 182 778
new 0 182 778
assign 1 183 779
heldGet 0 183 779
addStep 1 183 780
heldSet 1 184 781
assign 1 185 782
NAMEPATHGet 0 185 782
typenameSet 1 185 783
resolveNp 0 186 784
createImpliedConstruct 2 187 785
assign 1 192 795
nextDescendGet 0 192 795
return 1 192 796
assign 1 196 809
new 0 196 809
heldSet 1 197 810
assign 1 198 811
NAMEPATHGet 0 198 811
typenameSet 1 198 812
assign 1 199 813
heldGet 0 199 813
heldSet 1 199 814
prepend 1 200 815
assign 1 202 816
new 0 202 816
assign 1 203 817
new 0 203 817
nameSet 1 203 818
assign 1 204 819
new 0 204 819
wasBoundSet 1 204 820
assign 1 205 821
new 0 205 821
boundSet 1 205 822
assign 1 206 823
new 0 206 823
isConstructSet 1 206 824
assign 1 207 825
new 0 207 825
wasImpliedConstructSet 1 207 826
heldSet 1 208 827
assign 1 209 828
CALLGet 0 209 828
typenameSet 1 209 829
return 1 0 833
assign 1 0 836
return 1 0 840
assign 1 0 843
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1486356623: return bem_new_0();
case -278676308: return bem_copy_0();
case 1041690009: return bem_create_0();
case -1970586591: return bem_transGet_0();
case 1018929608: return bem_iteratorGet_0();
case -1293340012: return bem_inClassNpGet_0();
case 1349825318: return bem_hashGet_0();
case -533842997: return bem_ntypesGet_0();
case -2075471997: return bem_print_0();
case -612463190: return bem_inFileGet_0();
case -1416945131: return bem_constGet_0();
case -989279639: return bem_toString_0();
case 992843884: return bem_buildGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 441970093: return bem_begin_1(bevd_0);
case -196793939: return bem_ntypesSet_1(bevd_0);
case 942841013: return bem_inFileSet_1(bevd_0);
case 1826376252: return bem_copyTo_1(bevd_0);
case 650870771: return bem_end_1(bevd_0);
case -1731377557: return bem_transSet_1(bevd_0);
case 1578477959: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 2066424018: return bem_buildSet_1(bevd_0);
case -1283958111: return bem_notEquals_1(bevd_0);
case 2001366394: return bem_def_1(bevd_0);
case -989067989: return bem_constSet_1(bevd_0);
case 964719406: return bem_equals_1(bevd_0);
case 429997543: return bem_undef_1(bevd_0);
case -33273034: return bem_inClassNpSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -873382988: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1261192257: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -825340533: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2021068605: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 864744165: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass7_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass7_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst = (BEC_3_5_5_5_BuildVisitPass7) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;
}
}
