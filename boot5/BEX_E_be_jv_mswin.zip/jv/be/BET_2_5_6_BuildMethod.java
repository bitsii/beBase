package be;
public class BET_2_5_6_BuildMethod extends BETS_Object {
public BET_2_5_6_BuildMethod() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "nameGet_0", "nameGetDirect_0", "nameSet_1", "nameSetDirect_1", "orgNameGet_0", "orgNameGetDirect_0", "orgNameSet_1", "orgNameSetDirect_1", "numargsGet_0", "numargsGetDirect_0", "numargsSet_1", "numargsSetDirect_1", "propertyGet_0", "propertyGetDirect_0", "propertySet_1", "propertySetDirect_1", "rtypeGet_0", "rtypeGetDirect_0", "rtypeSet_1", "rtypeSetDirect_1", "tmpVarsGet_0", "tmpVarsGetDirect_0", "tmpVarsSet_1", "tmpVarsSetDirect_1", "anyMapGet_0", "anyMapGetDirect_0", "anyMapSet_1", "anyMapSetDirect_1", "orderedVarsGet_0", "orderedVarsGetDirect_0", "orderedVarsSet_1", "orderedVarsSetDirect_1", "tmpCntGet_0", "tmpCntGetDirect_0", "tmpCntSet_1", "tmpCntSetDirect_1", "isGenAccessorGet_0", "isGenAccessorGetDirect_0", "isGenAccessorSet_1", "isGenAccessorSetDirect_1", "tryDepthGet_0", "tryDepthGetDirect_0", "tryDepthSet_1", "tryDepthSetDirect_1", "isFinalGet_0", "isFinalGetDirect_0", "isFinalSet_1", "isFinalSetDirect_1", "amaxGet_0", "amaxGetDirect_0", "amaxSet_1", "amaxSetDirect_1", "hmaxGet_0", "hmaxGetDirect_0", "hmaxSet_1", "hmaxSetDirect_1", "mmaxGet_0", "mmaxGetDirect_0", "mmaxSet_1", "mmaxSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "name", "orgName", "numargs", "property", "rtype", "tmpVars", "anyMap", "orderedVars", "tmpCnt", "isGenAccessor", "tryDepth", "isFinal", "amax", "hmax", "mmax" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_6_BuildMethod();
}
}
