package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList extends BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_2_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 142*/ {
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /* Line: 143*/
while (true)
/* Line: 147*/ {
if (bevl_f == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 147*/ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 149*/ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 150*/
if (bevl_fnode == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 153*/ {
bevl_fnode = bevl_f;
} /* Line: 154*/
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 157*/
 else /* Line: 147*/ {
break;
} /* Line: 147*/
} /* Line: 147*/
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_node.bemd_1(-2063108486, null);
if (bevp_lastNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 166*/ {
beva_node.bemd_1(122047098, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 169*/
 else /* Line: 170*/ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 172*/
beva_node.bemd_1(2076488185, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_node.bemd_1(-2063108486, null);
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 179*/ {
beva_node.bemd_1(-2063108486, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 182*/
 else /* Line: 183*/ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 185*/
beva_node.bemd_1(2076488185, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(76220107);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(-1073263137, beva_toIns);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 200*/ {
bevt_0_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 200*/ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 201*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 202*/
 else /* Line: 203*/ {
break;
} /* Line: 204*/
bevl_i.bevi_int++;
} /* Line: 206*/
 else /* Line: 200*/ {
break;
} /* Line: 200*/
} /* Line: 200*/
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 208*/ {
return null;
} /* Line: 209*/
bevt_3_ta_ph = bevl_iter.bem_nextGet_0();
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_pos = beva_pos.bem_add_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 217*/ {
bevt_1_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 217*/ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 218*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 219*/
 else /* Line: 220*/ {
break;
} /* Line: 221*/
bevl_i.bevi_int++;
} /* Line: 223*/
 else /* Line: 217*/ {
break;
} /* Line: 217*/
} /* Line: 217*/
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 225*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 226*/
bevt_5_ta_ph = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 232*/ {
return null;
} /* Line: 232*/
bevt_1_ta_ph = bevp_firstNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_ta_ph = null;
if (bevp_firstNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 237*/ {
bevt_3_ta_ph = bevp_firstNode.bem_nextGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 237*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 237*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 237*/
 else /* Line: 237*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 237*/ {
bevt_5_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_heldGet_0();
return bevt_4_ta_ph;
} /* Line: 238*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_ta_ph = null;
if (bevp_firstNode == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_4_ta_ph = bevp_firstNode.bem_nextGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 244*/
 else /* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 244*/ {
bevt_7_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_nextGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 244*/
 else /* Line: 244*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 244*/ {
bevt_10_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_nextGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_heldGet_0();
return bevt_8_ta_ph;
} /* Line: 245*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_lastNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 251*/ {
return null;
} /* Line: 251*/
bevt_1_ta_ph = bevp_lastNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 257*/ {
bevt_0_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 257*/ {
bevt_1_ta_ph = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_1_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 259*/
 else /* Line: 260*/ {
break;
} /* Line: 261*/
bevl_i.bevi_int++;
} /* Line: 263*/
 else /* Line: 257*/ {
break;
} /* Line: 257*/
} /* Line: 257*/
bevt_2_ta_ph = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_2_ta_ph.bevi_bool)/* Line: 265*/ {
return null;
} /* Line: 266*/
bevt_3_ta_ph = bevl_iter.bem_nextNodeGet_0();
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_held == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_held, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 277*/
 else /* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 277*/ {
bem_addAll_1(beva_held);
} /* Line: 278*/
 else /* Line: 279*/ {
bem_addValueWhole_1(beva_held);
} /* Line: 280*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 285*/ {
while (true)
/* Line: 286*/ {
bevt_1_ta_ph = beva_val.bemd_0(873159525);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 286*/ {
bevt_2_ta_ph = beva_val.bemd_0(1077024860);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 287*/
 else /* Line: 286*/ {
break;
} /* Line: 286*/
} /* Line: 286*/
} /* Line: 286*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_1_ta_ph = beva_val.bemd_0(-777617664);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 294*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 305*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 305*/ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 307*/
 else /* Line: 305*/ {
break;
} /* Line: 305*/
} /* Line: 305*/
return bevl_cnt;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 313*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 314*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toNodeList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 323*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 323*/ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_2_ta_ph = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_ta_ph);
} /* Line: 325*/
bevl_cnt.bevi_int++;
} /* Line: 327*/
 else /* Line: 323*/ {
break;
} /* Line: 323*/
} /* Line: 323*/
return bevl_toret;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 336*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 336*/ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 337*/ {
bevt_3_ta_ph = bevl_i.bem_nextNodeGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(1515125588);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_ta_ph);
} /* Line: 338*/
bevl_cnt.bevi_int++;
} /* Line: 340*/
 else /* Line: 336*/ {
break;
} /* Line: 336*/
} /* Line: 336*/
return bevl_toret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_4_MathInts bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_maxGet_0();
bevt_0_ta_ph = bem_subList_2(beva_start, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 363*/ {
return bevl_res;
} /* Line: 364*/
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 367*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 367*/ {
bevt_3_ta_ph = bevl_iter.bem_hasNextGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(1420766919);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 368*/ {
return bevl_res;
} /* Line: 369*/
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 372*/ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 373*/
bevl_i.bevi_int++;
} /* Line: 367*/
 else /* Line: 367*/ {
break;
} /* Line: 367*/
} /* Line: 367*/
return bevl_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_ta_ph = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
/* Line: 416*/ {
if (bevl_current == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 416*/ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_ta_ph = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_ta_ph);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 421*/
 else /* Line: 416*/ {
break;
} /* Line: 416*/
} /* Line: 416*/
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {134, 134, 139, 140, 141, 142, 142, 143, 147, 147, 148, 149, 149, 150, 153, 153, 154, 156, 157, 159, 160, 161, 165, 166, 166, 167, 168, 169, 171, 172, 174, 178, 179, 179, 180, 181, 182, 184, 185, 187, 191, 195, 199, 200, 200, 201, 201, 202, 206, 208, 208, 209, 211, 211, 215, 215, 216, 217, 217, 218, 218, 219, 223, 225, 225, 226, 226, 228, 228, 232, 232, 232, 233, 233, 237, 237, 237, 237, 237, 0, 0, 0, 238, 238, 238, 240, 244, 244, 244, 244, 244, 0, 0, 0, 244, 244, 244, 244, 0, 0, 0, 245, 245, 245, 245, 247, 251, 251, 251, 252, 252, 256, 257, 257, 258, 259, 263, 265, 266, 268, 268, 272, 273, 277, 277, 277, 277, 0, 0, 0, 278, 280, 285, 285, 286, 287, 287, 293, 293, 294, 294, 299, 300, 304, 305, 305, 306, 307, 309, 313, 313, 314, 314, 316, 316, 320, 321, 322, 323, 323, 324, 324, 325, 325, 327, 329, 333, 334, 335, 336, 336, 337, 337, 338, 338, 338, 340, 342, 346, 346, 350, 350, 354, 354, 358, 358, 358, 358, 362, 363, 363, 364, 366, 367, 367, 367, 368, 368, 369, 371, 372, 372, 373, 367, 376, 414, 415, 416, 416, 417, 418, 418, 419, 420, 421, 423, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 31, 32, 33, 34, 39, 40, 44, 49, 50, 51, 56, 57, 59, 64, 65, 67, 68, 74, 75, 76, 80, 81, 86, 87, 88, 89, 92, 93, 95, 100, 101, 106, 107, 108, 109, 112, 113, 115, 119, 123, 133, 134, 137, 139, 144, 145, 150, 156, 161, 162, 164, 165, 176, 177, 178, 179, 182, 184, 189, 190, 195, 201, 206, 207, 208, 210, 211, 216, 221, 222, 224, 225, 234, 239, 240, 241, 246, 247, 250, 254, 257, 258, 259, 261, 275, 280, 281, 282, 287, 288, 291, 295, 298, 299, 300, 305, 306, 309, 313, 316, 317, 318, 319, 321, 326, 331, 332, 334, 335, 344, 345, 348, 350, 352, 357, 363, 365, 367, 368, 372, 373, 381, 386, 387, 388, 390, 393, 397, 400, 403, 411, 416, 419, 421, 422, 434, 439, 440, 441, 447, 448, 455, 456, 459, 461, 462, 468, 474, 479, 480, 481, 483, 484, 494, 495, 496, 497, 500, 502, 507, 508, 509, 511, 517, 528, 529, 530, 531, 534, 536, 541, 542, 543, 544, 546, 552, 556, 557, 561, 562, 566, 567, 573, 574, 575, 576, 588, 589, 594, 595, 597, 598, 601, 606, 607, 608, 610, 612, 613, 618, 619, 621, 627, 635, 636, 639, 644, 645, 646, 647, 648, 649, 650, 656, 660, 663, 667, 670};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 134 18
new 2 134 18
return 1 134 19
assign 1 139 31
create 0 139 31
assign 1 140 32
linkedListIteratorGet 0 140 32
assign 1 141 33
nextNodeGet 0 141 33
assign 1 142 34
undef 1 142 39
return 1 143 40
assign 1 147 44
def 1 147 49
assign 1 148 50
copy 0 148 50
assign 1 149 51
def 1 149 56
nextSet 1 150 57
assign 1 153 59
undef 1 153 64
assign 1 154 65
assign 1 156 67
assign 1 157 68
nextNodeGet 0 157 68
firstNodeSet 1 159 74
lastNodeSet 1 160 75
return 1 161 76
nextSet 1 165 80
assign 1 166 81
def 1 166 86
priorSet 1 167 87
nextSet 1 168 88
assign 1 169 89
assign 1 171 92
assign 1 172 93
mylistSet 1 174 95
nextSet 1 178 100
assign 1 179 101
def 1 179 106
nextSet 1 180 107
priorSet 1 181 108
assign 1 182 109
assign 1 184 112
assign 1 185 113
mylistSet 1 187 115
remove 0 191 119
insertBefore 1 195 123
assign 1 199 133
new 0 199 133
assign 1 200 134
linkedListIteratorGet 0 200 134
assign 1 200 137
hasNextGet 0 200 137
assign 1 201 139
lesser 1 201 144
nextGet 0 202 145
incrementValue 0 206 150
assign 1 208 156
notEquals 1 208 161
return 1 209 162
assign 1 211 164
nextGet 0 211 164
return 1 211 165
assign 1 215 176
new 0 215 176
assign 1 215 177
add 1 215 177
assign 1 216 178
new 0 216 178
assign 1 217 179
linkedListIteratorGet 0 217 179
assign 1 217 182
hasNextGet 0 217 182
assign 1 218 184
lesser 1 218 189
nextGet 0 219 190
incrementValue 0 223 195
assign 1 225 201
notEquals 1 225 206
assign 1 226 207
new 0 226 207
return 1 226 208
assign 1 228 210
currentSet 1 228 210
return 1 228 211
assign 1 232 216
undef 1 232 221
return 1 232 222
assign 1 233 224
heldGet 0 233 224
return 1 233 225
assign 1 237 234
def 1 237 239
assign 1 237 240
nextGet 0 237 240
assign 1 237 241
def 1 237 246
assign 1 0 247
assign 1 0 250
assign 1 0 254
assign 1 238 257
nextGet 0 238 257
assign 1 238 258
heldGet 0 238 258
return 1 238 259
return 1 240 261
assign 1 244 275
def 1 244 280
assign 1 244 281
nextGet 0 244 281
assign 1 244 282
def 1 244 287
assign 1 0 288
assign 1 0 291
assign 1 0 295
assign 1 244 298
nextGet 0 244 298
assign 1 244 299
nextGet 0 244 299
assign 1 244 300
def 1 244 305
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 245 316
nextGet 0 245 316
assign 1 245 317
nextGet 0 245 317
assign 1 245 318
heldGet 0 245 318
return 1 245 319
return 1 247 321
assign 1 251 326
undef 1 251 331
return 1 251 332
assign 1 252 334
heldGet 0 252 334
return 1 252 335
assign 1 256 344
new 0 256 344
assign 1 257 345
linkedListIteratorGet 0 257 345
assign 1 257 348
hasNextGet 0 257 348
assign 1 258 350
lesser 1 258 350
nextGet 0 259 352
incrementValue 0 263 357
assign 1 265 363
notEquals 1 265 363
return 1 266 365
assign 1 268 367
nextNodeGet 0 268 367
return 1 268 368
assign 1 272 372
newNode 1 272 372
appendNode 1 273 373
assign 1 277 381
def 1 277 386
assign 1 277 387
new 0 277 387
assign 1 277 388
sameType 2 277 388
assign 1 0 390
assign 1 0 393
assign 1 0 397
addAll 1 278 400
addValueWhole 1 280 403
assign 1 285 411
def 1 285 416
assign 1 286 419
hasNextGet 0 286 419
assign 1 287 421
nextGet 0 287 421
addValueWhole 1 287 422
assign 1 293 434
def 1 293 439
assign 1 294 440
iteratorGet 0 294 440
iterateAdd 1 294 441
assign 1 299 447
newNode 1 299 447
prependNode 1 300 448
assign 1 304 455
new 0 304 455
assign 1 305 456
linkedListIteratorGet 0 305 456
assign 1 305 459
hasNextGet 0 305 459
nextGet 0 306 461
incrementValue 0 307 462
return 1 309 468
assign 1 313 474
undef 1 313 479
assign 1 314 480
new 0 314 480
return 1 314 481
assign 1 316 483
new 0 316 483
return 1 316 484
assign 1 320 494
lengthGet 0 320 494
assign 1 321 495
new 1 321 495
assign 1 322 496
new 0 322 496
assign 1 323 497
linkedListIteratorGet 0 323 497
assign 1 323 500
hasNextGet 0 323 500
assign 1 324 502
lesser 1 324 507
assign 1 325 508
nextNodeGet 0 325 508
put 2 325 509
incrementValue 0 327 511
return 1 329 517
assign 1 333 528
lengthGet 0 333 528
assign 1 334 529
new 1 334 529
assign 1 335 530
new 0 335 530
assign 1 336 531
linkedListIteratorGet 0 336 531
assign 1 336 534
hasNextGet 0 336 534
assign 1 337 536
lesser 1 337 541
assign 1 338 542
nextNodeGet 0 338 542
assign 1 338 543
heldGet 0 338 543
put 2 338 544
incrementValue 0 340 546
return 1 342 552
assign 1 346 556
new 1 346 556
return 1 346 557
assign 1 350 561
new 1 350 561
return 1 350 562
assign 1 354 566
iteratorGet 0 354 566
return 1 354 567
assign 1 358 573
new 0 358 573
assign 1 358 574
maxGet 0 358 574
assign 1 358 575
subList 2 358 575
return 1 358 576
assign 1 362 588
create 0 362 588
assign 1 363 589
lesserEquals 1 363 594
return 1 364 595
assign 1 366 597
linkedListIteratorGet 0 366 597
assign 1 367 598
new 0 367 598
assign 1 367 601
lesser 1 367 606
assign 1 368 607
hasNextGet 0 368 607
assign 1 368 608
not 0 368 608
return 1 369 610
assign 1 371 612
nextGet 0 371 612
assign 1 372 613
greaterEquals 1 372 618
addValue 1 373 619
incrementValue 0 367 621
return 1 376 627
assign 1 414 635
assign 1 415 636
assign 1 416 639
def 1 416 644
assign 1 417 645
nextGet 0 417 645
assign 1 418 646
priorGet 0 418 646
nextSet 1 418 647
priorSet 1 419 648
assign 1 420 649
assign 1 421 650
assign 1 423 656
return 1 0 660
assign 1 0 663
return 1 0 667
assign 1 0 670
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -777617664: return bem_iteratorGet_0();
case 1154795235: return bem_linkedListIteratorGet_0();
case 1439653353: return bem_create_0();
case -107296617: return bem_firstNodeGet_0();
case 1019282707: return bem_serializationIteratorGet_0();
case 826915224: return bem_thirdGet_0();
case 899024666: return bem_lastNodeGet_0();
case -496842367: return bem_new_0();
case 1492970144: return bem_isEmptyGet_0();
case -585121770: return bem_reverse_0();
case 940935116: return bem_secondGet_0();
case 1126122963: return bem_firstGet_0();
case -905156598: return bem_lengthGet_0();
case 1738619766: return bem_toList_0();
case 1103672703: return bem_print_0();
case -827496939: return bem_toNodeList_0();
case 1630760726: return bem_toString_0();
case -355672893: return bem_hashGet_0();
case 1152967006: return bem_copy_0();
case -2020387487: return bem_lastGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1313544957: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -499681477: return bem_addValue_1(bevd_0);
case 1605827377: return bem_iterateAdd_1(bevd_0);
case -927663136: return bem_getNode_1(bevd_0);
case 863284586: return bem_notEquals_1(bevd_0);
case -1721047471: return bem_def_1(bevd_0);
case -41139961: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 1795471524: return bem_appendNode_1(bevd_0);
case 445187513: return bem_equals_1(bevd_0);
case -938105188: return bem_undef_1(bevd_0);
case 497756533: return bem_lastNodeSet_1(bevd_0);
case -1683269612: return bem_firstNodeSet_1(bevd_0);
case -2059706837: return bem_newNode_1(bevd_0);
case -587753182: return bem_copyTo_1(bevd_0);
case 1794479678: return bem_addValueWhole_1(bevd_0);
case -367533324: return bem_prependNode_1(bevd_0);
case -1347994131: return bem_deleteNode_1(bevd_0);
case -1250946597: return bem_print_1(bevd_0);
case 1495546612: return bem_addAll_1(bevd_0);
case 2089602422: return bem_prepend_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2056786157: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -497175324: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1334197996: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -2082389725: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -558969549: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1197567931: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1887665452: return bem_insertBeforeNode_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
