package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList extends BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_2_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 136 */ {
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /* Line: 137 */
while (true)
 /* Line: 141 */ {
if (bevl_f == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 144 */
if (bevl_fnode == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 147 */ {
bevl_fnode = bevl_f;
} /* Line: 148 */
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 151 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(509377707, null);
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 160 */ {
beva_node.bemd_1(-639535970, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 163 */
 else  /* Line: 164 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 166 */
beva_node.bemd_1(608026126, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(509377707, null);
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 173 */ {
beva_node.bemd_1(509377707, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 176 */
 else  /* Line: 177 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 179 */
beva_node.bemd_1(608026126, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(848259769);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(-1093258900, beva_toIns);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_0;
if (beva_pos.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 193 */ {
bevt_2_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 194 */
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 197 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 197 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 199 */
 else  /* Line: 200 */ {
break;
} /* Line: 201 */
bevl_i.bevi_int++;
} /* Line: 203 */
 else  /* Line: 197 */ {
break;
} /* Line: 197 */
} /* Line: 197 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 205 */ {
return null;
} /* Line: 206 */
bevt_6_tmpany_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 214 */ {
bevt_1_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 214 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 216 */
 else  /* Line: 217 */ {
break;
} /* Line: 218 */
bevl_i.bevi_int++;
} /* Line: 220 */
 else  /* Line: 214 */ {
break;
} /* Line: 214 */
} /* Line: 214 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 223 */
bevt_5_tmpany_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 229 */ {
return null;
} /* Line: 229 */
bevt_1_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_3_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 234 */ {
bevt_5_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_heldGet_0();
return bevt_4_tmpany_phold;
} /* Line: 235 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 241 */ {
bevt_4_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 241 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 241 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 241 */
 else  /* Line: 241 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 241 */ {
bevt_7_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_nextGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 241 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 241 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 241 */
 else  /* Line: 241 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 241 */ {
bevt_10_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_nextGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_heldGet_0();
return bevt_8_tmpany_phold;
} /* Line: 242 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 248 */ {
return null;
} /* Line: 248 */
bevt_1_tmpany_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_pos.bemd_1(-1519516879, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 253 */ {
return bevp_firstNode;
} /* Line: 254 */
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 257 */ {
bevt_2_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 257 */ {
bevt_3_tmpany_phold = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 259 */
 else  /* Line: 260 */ {
break;
} /* Line: 261 */
bevl_i.bevi_int++;
} /* Line: 263 */
 else  /* Line: 257 */ {
break;
} /* Line: 257 */
} /* Line: 257 */
bevt_4_tmpany_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 265 */ {
return null;
} /* Line: 266 */
bevt_5_tmpany_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_held == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_2_tmpany_phold = beva_held.bemd_1(-359346681, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bem_addAll_1(beva_held);
} /* Line: 278 */
 else  /* Line: 279 */ {
bem_addValueWhole_1(beva_held);
} /* Line: 280 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 285 */ {
while (true)
 /* Line: 286 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-1664274967);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 286 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(396718224);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 287 */
 else  /* Line: 286 */ {
break;
} /* Line: 286 */
} /* Line: 286 */
} /* Line: 286 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(569361306);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 294 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 305 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 305 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 307 */
 else  /* Line: 305 */ {
break;
} /* Line: 305 */
} /* Line: 305 */
return bevl_cnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_lengthGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 317 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 318 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toNodeList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 327 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_2_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 329 */
bevl_cnt.bevi_int++;
} /* Line: 331 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return bevl_toret;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 340 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 340 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(436982975);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 342 */
bevl_cnt.bevi_int++;
} /* Line: 344 */
 else  /* Line: 340 */ {
break;
} /* Line: 340 */
} /* Line: 340 */
return bevl_toret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_maxGet_0();
bevt_0_tmpany_phold = bem_subList_2(beva_start, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 367 */ {
return bevl_res;
} /* Line: 368 */
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 371 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 371 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1830123495);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 372 */ {
return bevl_res;
} /* Line: 373 */
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 376 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 377 */
bevl_i.bevi_int++;
} /* Line: 371 */
 else  /* Line: 371 */ {
break;
} /* Line: 371 */
} /* Line: 371 */
return bevl_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 420 */ {
if (bevl_current == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 420 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpany_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpany_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 425 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGetDirect_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_firstNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGetDirect_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_lastNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {128, 128, 133, 134, 135, 136, 136, 137, 141, 141, 142, 143, 143, 144, 147, 147, 148, 150, 151, 153, 154, 155, 159, 160, 160, 161, 162, 163, 165, 166, 168, 172, 173, 173, 174, 175, 176, 178, 179, 181, 185, 189, 193, 193, 193, 194, 194, 196, 197, 197, 198, 198, 199, 203, 205, 205, 206, 208, 208, 212, 212, 213, 214, 214, 215, 215, 216, 220, 222, 222, 223, 223, 225, 225, 229, 229, 229, 230, 230, 234, 234, 234, 234, 234, 0, 0, 0, 235, 235, 235, 237, 241, 241, 241, 241, 241, 0, 0, 0, 241, 241, 241, 241, 0, 0, 0, 242, 242, 242, 242, 244, 248, 248, 248, 249, 249, 253, 253, 254, 256, 257, 257, 258, 259, 263, 265, 266, 268, 268, 272, 273, 277, 277, 277, 0, 0, 0, 278, 280, 285, 285, 286, 287, 287, 293, 293, 294, 294, 299, 300, 304, 305, 305, 306, 307, 309, 313, 313, 317, 317, 318, 318, 320, 320, 324, 325, 326, 327, 327, 328, 328, 329, 329, 331, 333, 337, 338, 339, 340, 340, 341, 341, 342, 342, 342, 344, 346, 350, 350, 354, 354, 358, 358, 362, 362, 362, 362, 366, 367, 367, 368, 370, 371, 371, 371, 372, 372, 373, 375, 376, 376, 377, 371, 380, 418, 419, 420, 420, 421, 422, 422, 423, 424, 425, 427, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 33, 34, 35, 36, 41, 42, 46, 51, 52, 53, 58, 59, 61, 66, 67, 69, 70, 76, 77, 78, 82, 83, 88, 89, 90, 91, 94, 95, 97, 102, 103, 108, 109, 110, 111, 114, 115, 117, 121, 125, 138, 139, 144, 145, 146, 148, 149, 152, 154, 159, 160, 165, 171, 176, 177, 179, 180, 191, 192, 193, 194, 197, 199, 204, 205, 210, 216, 221, 222, 223, 225, 226, 231, 236, 237, 239, 240, 249, 254, 255, 256, 261, 262, 265, 269, 272, 273, 274, 276, 290, 295, 296, 297, 302, 303, 306, 310, 313, 314, 315, 320, 321, 324, 328, 331, 332, 333, 334, 336, 341, 346, 347, 349, 350, 361, 362, 364, 366, 367, 370, 372, 374, 379, 385, 387, 389, 390, 394, 395, 402, 407, 408, 410, 413, 417, 420, 423, 431, 436, 439, 441, 442, 454, 459, 460, 461, 467, 468, 475, 476, 479, 481, 482, 488, 492, 493, 499, 504, 505, 506, 508, 509, 519, 520, 521, 522, 525, 527, 532, 533, 534, 536, 542, 553, 554, 555, 556, 559, 561, 566, 567, 568, 569, 571, 577, 581, 582, 586, 587, 591, 592, 598, 599, 600, 601, 613, 614, 619, 620, 622, 623, 626, 631, 632, 633, 635, 637, 638, 643, 644, 646, 652, 660, 661, 664, 669, 670, 671, 672, 673, 674, 675, 681, 685, 688, 691, 695, 699, 702, 705, 709};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 128 20
new 2 128 20
return 1 128 21
assign 1 133 33
create 0 133 33
assign 1 134 34
linkedListIteratorGet 0 134 34
assign 1 135 35
nextNodeGet 0 135 35
assign 1 136 36
undef 1 136 41
return 1 137 42
assign 1 141 46
def 1 141 51
assign 1 142 52
copy 0 142 52
assign 1 143 53
def 1 143 58
nextSet 1 144 59
assign 1 147 61
undef 1 147 66
assign 1 148 67
assign 1 150 69
assign 1 151 70
nextNodeGet 0 151 70
firstNodeSet 1 153 76
lastNodeSet 1 154 77
return 1 155 78
nextSet 1 159 82
assign 1 160 83
def 1 160 88
priorSet 1 161 89
nextSet 1 162 90
assign 1 163 91
assign 1 165 94
assign 1 166 95
mylistSet 1 168 97
nextSet 1 172 102
assign 1 173 103
def 1 173 108
nextSet 1 174 109
priorSet 1 175 110
assign 1 176 111
assign 1 178 114
assign 1 179 115
mylistSet 1 181 117
delete 0 185 121
insertBefore 1 189 125
assign 1 193 138
new 0 193 138
assign 1 193 139
equals 1 193 144
assign 1 194 145
heldGet 0 194 145
return 1 194 146
assign 1 196 148
new 0 196 148
assign 1 197 149
linkedListIteratorGet 0 197 149
assign 1 197 152
hasNextGet 0 197 152
assign 1 198 154
lesser 1 198 159
nextGet 0 199 160
incrementValue 0 203 165
assign 1 205 171
notEquals 1 205 176
return 1 206 177
assign 1 208 179
nextGet 0 208 179
return 1 208 180
assign 1 212 191
new 0 212 191
assign 1 212 192
add 1 212 192
assign 1 213 193
new 0 213 193
assign 1 214 194
linkedListIteratorGet 0 214 194
assign 1 214 197
hasNextGet 0 214 197
assign 1 215 199
lesser 1 215 204
nextGet 0 216 205
incrementValue 0 220 210
assign 1 222 216
notEquals 1 222 221
assign 1 223 222
new 0 223 222
return 1 223 223
assign 1 225 225
currentSet 1 225 225
return 1 225 226
assign 1 229 231
undef 1 229 236
return 1 229 237
assign 1 230 239
heldGet 0 230 239
return 1 230 240
assign 1 234 249
def 1 234 254
assign 1 234 255
nextGet 0 234 255
assign 1 234 256
def 1 234 261
assign 1 0 262
assign 1 0 265
assign 1 0 269
assign 1 235 272
nextGet 0 235 272
assign 1 235 273
heldGet 0 235 273
return 1 235 274
return 1 237 276
assign 1 241 290
def 1 241 295
assign 1 241 296
nextGet 0 241 296
assign 1 241 297
def 1 241 302
assign 1 0 303
assign 1 0 306
assign 1 0 310
assign 1 241 313
nextGet 0 241 313
assign 1 241 314
nextGet 0 241 314
assign 1 241 315
def 1 241 320
assign 1 0 321
assign 1 0 324
assign 1 0 328
assign 1 242 331
nextGet 0 242 331
assign 1 242 332
nextGet 0 242 332
assign 1 242 333
heldGet 0 242 333
return 1 242 334
return 1 244 336
assign 1 248 341
undef 1 248 346
return 1 248 347
assign 1 249 349
heldGet 0 249 349
return 1 249 350
assign 1 253 361
new 0 253 361
assign 1 253 362
equals 1 253 362
return 1 254 364
assign 1 256 366
new 0 256 366
assign 1 257 367
linkedListIteratorGet 0 257 367
assign 1 257 370
hasNextGet 0 257 370
assign 1 258 372
lesser 1 258 372
nextGet 0 259 374
incrementValue 0 263 379
assign 1 265 385
notEquals 1 265 385
return 1 266 387
assign 1 268 389
nextNodeGet 0 268 389
return 1 268 390
assign 1 272 394
newNode 1 272 394
appendNode 1 273 395
assign 1 277 402
def 1 277 407
assign 1 277 408
sameType 1 277 408
assign 1 0 410
assign 1 0 413
assign 1 0 417
addAll 1 278 420
addValueWhole 1 280 423
assign 1 285 431
def 1 285 436
assign 1 286 439
hasNextGet 0 286 439
assign 1 287 441
nextGet 0 287 441
addValueWhole 1 287 442
assign 1 293 454
def 1 293 459
assign 1 294 460
iteratorGet 0 294 460
iterateAdd 1 294 461
assign 1 299 467
newNode 1 299 467
prependNode 1 300 468
assign 1 304 475
new 0 304 475
assign 1 305 476
linkedListIteratorGet 0 305 476
assign 1 305 479
hasNextGet 0 305 479
nextGet 0 306 481
incrementValue 0 307 482
return 1 309 488
assign 1 313 492
lengthGet 0 313 492
return 1 313 493
assign 1 317 499
undef 1 317 504
assign 1 318 505
new 0 318 505
return 1 318 506
assign 1 320 508
new 0 320 508
return 1 320 509
assign 1 324 519
lengthGet 0 324 519
assign 1 325 520
new 1 325 520
assign 1 326 521
new 0 326 521
assign 1 327 522
linkedListIteratorGet 0 327 522
assign 1 327 525
hasNextGet 0 327 525
assign 1 328 527
lesser 1 328 532
assign 1 329 533
nextNodeGet 0 329 533
put 2 329 534
incrementValue 0 331 536
return 1 333 542
assign 1 337 553
lengthGet 0 337 553
assign 1 338 554
new 1 338 554
assign 1 339 555
new 0 339 555
assign 1 340 556
linkedListIteratorGet 0 340 556
assign 1 340 559
hasNextGet 0 340 559
assign 1 341 561
lesser 1 341 566
assign 1 342 567
nextNodeGet 0 342 567
assign 1 342 568
heldGet 0 342 568
put 2 342 569
incrementValue 0 344 571
return 1 346 577
assign 1 350 581
new 1 350 581
return 1 350 582
assign 1 354 586
new 1 354 586
return 1 354 587
assign 1 358 591
iteratorGet 0 358 591
return 1 358 592
assign 1 362 598
new 0 362 598
assign 1 362 599
maxGet 0 362 599
assign 1 362 600
subList 2 362 600
return 1 362 601
assign 1 366 613
create 0 366 613
assign 1 367 614
lesserEquals 1 367 619
return 1 368 620
assign 1 370 622
linkedListIteratorGet 0 370 622
assign 1 371 623
new 0 371 623
assign 1 371 626
lesser 1 371 631
assign 1 372 632
hasNextGet 0 372 632
assign 1 372 633
not 0 372 633
return 1 373 635
assign 1 375 637
nextGet 0 375 637
assign 1 376 638
greaterEquals 1 376 643
addValue 1 377 644
incrementValue 0 371 646
return 1 380 652
assign 1 418 660
assign 1 419 661
assign 1 420 664
def 1 420 669
assign 1 421 670
nextGet 0 421 670
assign 1 422 671
priorGet 0 422 671
nextSet 1 422 672
priorSet 1 423 673
assign 1 424 674
assign 1 425 675
assign 1 427 681
return 1 0 685
return 1 0 688
assign 1 0 691
assign 1 0 695
return 1 0 699
return 1 0 702
assign 1 0 705
assign 1 0 709
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1092510954: return bem_copy_0();
case 569361306: return bem_iteratorGet_0();
case -881577546: return bem_classNameGet_0();
case -653750385: return bem_create_0();
case -2031839191: return bem_serializationIteratorGet_0();
case 666412813: return bem_firstNodeGetDirect_0();
case 908192303: return bem_lastNodeGetDirect_0();
case -1267791391: return bem_toNodeList_0();
case 2144693643: return bem_deserializeClassNameGet_0();
case 641839943: return bem_toAny_0();
case -1778027080: return bem_isEmptyGet_0();
case -2007275567: return bem_many_0();
case 1099447992: return bem_fieldNamesGet_0();
case 971841201: return bem_fieldIteratorGet_0();
case -212742483: return bem_echo_0();
case -1692281443: return bem_lastNodeGet_0();
case -594040455: return bem_reverse_0();
case -158731083: return bem_firstNodeGet_0();
case 393738758: return bem_serializeToString_0();
case 740892297: return bem_sizeGet_0();
case 148544119: return bem_toString_0();
case 908678857: return bem_print_0();
case -1539165808: return bem_thirdGet_0();
case -1750720088: return bem_hashGet_0();
case 1782351683: return bem_serializeContents_0();
case -444718059: return bem_linkedListIteratorGet_0();
case -224465120: return bem_sourceFileNameGet_0();
case -823117870: return bem_secondGet_0();
case -634018133: return bem_tagGet_0();
case -833851840: return bem_lengthGet_0();
case 920335161: return bem_lastGet_0();
case -124285366: return bem_once_0();
case 2146604653: return bem_new_0();
case 473960562: return bem_toList_0();
case -2038891686: return bem_firstGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1107145729: return bem_appendNode_1(bevd_0);
case 1703616583: return bem_notEquals_1(bevd_0);
case 2129228555: return bem_getNode_1(bevd_0);
case -766368587: return bem_prepend_1(bevd_0);
case -872115670: return bem_defined_1(bevd_0);
case -1254886105: return bem_newNode_1(bevd_0);
case 477790683: return bem_prependNode_1(bevd_0);
case -1928510621: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1257084803: return bem_iterateAdd_1(bevd_0);
case -249326151: return bem_copyTo_1(bevd_0);
case 1367146792: return bem_sameClass_1(bevd_0);
case 557355208: return bem_lastNodeSet_1(bevd_0);
case 1876286442: return bem_addAll_1(bevd_0);
case -1936334442: return bem_firstNodeSetDirect_1(bevd_0);
case 326949551: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1730397553: return bem_undef_1(bevd_0);
case -884607798: return bem_def_1(bevd_0);
case -359346681: return bem_sameType_1(bevd_0);
case 1446250233: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1926763067: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1220767838: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 1236734559: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 389340449: return bem_otherType_1(bevd_0);
case -1159667874: return bem_addValueWhole_1(bevd_0);
case 388861607: return bem_deleteNode_1(bevd_0);
case 1677913800: return bem_firstNodeSet_1(bevd_0);
case -1586811529: return bem_undefined_1(bevd_0);
case -1565662060: return bem_sameObject_1(bevd_0);
case -1519516879: return bem_equals_1(bevd_0);
case -1979724751: return bem_addValue_1(bevd_0);
case -448360789: return bem_otherClass_1(bevd_0);
case -247457951: return bem_lastNodeSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1752052945: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 29395685: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 827793836: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1899980628: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1061986002: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1194360433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -454033656: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2141808757: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 696322560: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 593713857: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
