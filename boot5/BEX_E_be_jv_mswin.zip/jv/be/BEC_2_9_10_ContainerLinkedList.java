package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList extends BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_2_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 136*/ {
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /* Line: 137*/
while (true)
/* Line: 141*/ {
if (bevl_f == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 141*/ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 143*/ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 144*/
if (bevl_fnode == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 147*/ {
bevl_fnode = bevl_f;
} /* Line: 148*/
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 151*/
 else /* Line: 141*/ {
break;
} /* Line: 141*/
} /* Line: 141*/
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_node.bemd_1(-227927927, null);
if (bevp_lastNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 160*/ {
beva_node.bemd_1(-1744425199, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 163*/
 else /* Line: 164*/ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 166*/
beva_node.bemd_1(-1094738669, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_node.bemd_1(-227927927, null);
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 173*/ {
beva_node.bemd_1(-227927927, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 176*/
 else /* Line: 177*/ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 179*/
beva_node.bemd_1(-1094738669, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(-1549309530);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(-1208123687, beva_toIns);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 193*/ {
bevt_2_ta_ph = bevp_firstNode.bem_heldGet_0();
return bevt_2_ta_ph;
} /* Line: 194*/
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 197*/ {
bevt_3_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 197*/ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 198*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 199*/
 else /* Line: 200*/ {
break;
} /* Line: 201*/
bevl_i.bevi_int++;
} /* Line: 203*/
 else /* Line: 197*/ {
break;
} /* Line: 197*/
} /* Line: 197*/
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 205*/ {
return null;
} /* Line: 206*/
bevt_6_ta_ph = bevl_iter.bem_nextGet_0();
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_pos = beva_pos.bem_add_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 214*/ {
bevt_1_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 214*/ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 215*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 216*/
 else /* Line: 217*/ {
break;
} /* Line: 218*/
bevl_i.bevi_int++;
} /* Line: 220*/
 else /* Line: 214*/ {
break;
} /* Line: 214*/
} /* Line: 214*/
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 222*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 223*/
bevt_5_ta_ph = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 229*/ {
return null;
} /* Line: 229*/
bevt_1_ta_ph = bevp_firstNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_ta_ph = null;
if (bevp_firstNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_3_ta_ph = bevp_firstNode.bem_nextGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 234*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 234*/
 else /* Line: 234*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 234*/ {
bevt_5_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_heldGet_0();
return bevt_4_ta_ph;
} /* Line: 235*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_ta_ph = null;
if (bevp_firstNode == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 241*/ {
bevt_4_ta_ph = bevp_firstNode.bem_nextGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 241*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 241*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 241*/
 else /* Line: 241*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 241*/ {
bevt_7_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_nextGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 241*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 241*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 241*/
 else /* Line: 241*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 241*/ {
bevt_10_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_nextGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_heldGet_0();
return bevt_8_ta_ph;
} /* Line: 242*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_lastNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 248*/ {
return null;
} /* Line: 248*/
bevt_1_ta_ph = bevp_lastNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = beva_pos.bemd_1(1276638363, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 253*/ {
return bevp_firstNode;
} /* Line: 254*/
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 257*/ {
bevt_2_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 257*/ {
bevt_3_ta_ph = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_3_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 259*/
 else /* Line: 260*/ {
break;
} /* Line: 261*/
bevl_i.bevi_int++;
} /* Line: 263*/
 else /* Line: 257*/ {
break;
} /* Line: 257*/
} /* Line: 257*/
bevt_4_ta_ph = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_ta_ph.bevi_bool)/* Line: 265*/ {
return null;
} /* Line: 266*/
bevt_5_ta_ph = bevl_iter.bem_nextNodeGet_0();
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_held == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_held, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 277*/
 else /* Line: 277*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 277*/ {
bem_addAll_1(beva_held);
} /* Line: 278*/
 else /* Line: 279*/ {
bem_addValueWhole_1(beva_held);
} /* Line: 280*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 285*/ {
while (true)
/* Line: 286*/ {
bevt_1_ta_ph = beva_val.bemd_0(764792202);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 286*/ {
bevt_2_ta_ph = beva_val.bemd_0(214487301);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 287*/
 else /* Line: 286*/ {
break;
} /* Line: 286*/
} /* Line: 286*/
} /* Line: 286*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_1_ta_ph = beva_val.bemd_0(455087168);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 294*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 305*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 305*/ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 307*/
 else /* Line: 305*/ {
break;
} /* Line: 305*/
} /* Line: 305*/
return bevl_cnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_lengthGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 317*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 318*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toNodeList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 327*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 327*/ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 328*/ {
bevt_2_ta_ph = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_ta_ph);
} /* Line: 329*/
bevl_cnt.bevi_int++;
} /* Line: 331*/
 else /* Line: 327*/ {
break;
} /* Line: 327*/
} /* Line: 327*/
return bevl_toret;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 340*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 340*/ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 341*/ {
bevt_3_ta_ph = bevl_i.bem_nextNodeGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1521235777);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_ta_ph);
} /* Line: 342*/
bevl_cnt.bevi_int++;
} /* Line: 344*/
 else /* Line: 340*/ {
break;
} /* Line: 340*/
} /* Line: 340*/
return bevl_toret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_4_MathInts bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_maxGet_0();
bevt_0_ta_ph = bem_subList_2(beva_start, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 367*/ {
return bevl_res;
} /* Line: 368*/
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 371*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_3_ta_ph = bevl_iter.bem_hasNextGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1545722674);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 372*/ {
return bevl_res;
} /* Line: 373*/
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 376*/ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 377*/
bevl_i.bevi_int++;
} /* Line: 371*/
 else /* Line: 371*/ {
break;
} /* Line: 371*/
} /* Line: 371*/
return bevl_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_ta_ph = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
/* Line: 420*/ {
if (bevl_current == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 420*/ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_ta_ph = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_ta_ph);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 425*/
 else /* Line: 420*/ {
break;
} /* Line: 420*/
} /* Line: 420*/
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {128, 128, 133, 134, 135, 136, 136, 137, 141, 141, 142, 143, 143, 144, 147, 147, 148, 150, 151, 153, 154, 155, 159, 160, 160, 161, 162, 163, 165, 166, 168, 172, 173, 173, 174, 175, 176, 178, 179, 181, 185, 189, 193, 193, 193, 194, 194, 196, 197, 197, 198, 198, 199, 203, 205, 205, 206, 208, 208, 212, 212, 213, 214, 214, 215, 215, 216, 220, 222, 222, 223, 223, 225, 225, 229, 229, 229, 230, 230, 234, 234, 234, 234, 234, 0, 0, 0, 235, 235, 235, 237, 241, 241, 241, 241, 241, 0, 0, 0, 241, 241, 241, 241, 0, 0, 0, 242, 242, 242, 242, 244, 248, 248, 248, 249, 249, 253, 253, 254, 256, 257, 257, 258, 259, 263, 265, 266, 268, 268, 272, 273, 277, 277, 277, 277, 0, 0, 0, 278, 280, 285, 285, 286, 287, 287, 293, 293, 294, 294, 299, 300, 304, 305, 305, 306, 307, 309, 313, 313, 317, 317, 318, 318, 320, 320, 324, 325, 326, 327, 327, 328, 328, 329, 329, 331, 333, 337, 338, 339, 340, 340, 341, 341, 342, 342, 342, 344, 346, 350, 350, 354, 354, 358, 358, 362, 362, 362, 362, 366, 367, 367, 368, 370, 371, 371, 371, 372, 372, 373, 375, 376, 376, 377, 371, 380, 418, 419, 420, 420, 421, 422, 422, 423, 424, 425, 427, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 31, 32, 33, 34, 39, 40, 44, 49, 50, 51, 56, 57, 59, 64, 65, 67, 68, 74, 75, 76, 80, 81, 86, 87, 88, 89, 92, 93, 95, 100, 101, 106, 107, 108, 109, 112, 113, 115, 119, 123, 136, 137, 142, 143, 144, 146, 147, 150, 152, 157, 158, 163, 169, 174, 175, 177, 178, 189, 190, 191, 192, 195, 197, 202, 203, 208, 214, 219, 220, 221, 223, 224, 229, 234, 235, 237, 238, 247, 252, 253, 254, 259, 260, 263, 267, 270, 271, 272, 274, 288, 293, 294, 295, 300, 301, 304, 308, 311, 312, 313, 318, 319, 322, 326, 329, 330, 331, 332, 334, 339, 344, 345, 347, 348, 359, 360, 362, 364, 365, 368, 370, 372, 377, 383, 385, 387, 388, 392, 393, 401, 406, 407, 408, 410, 413, 417, 420, 423, 431, 436, 439, 441, 442, 454, 459, 460, 461, 467, 468, 475, 476, 479, 481, 482, 488, 492, 493, 499, 504, 505, 506, 508, 509, 519, 520, 521, 522, 525, 527, 532, 533, 534, 536, 542, 553, 554, 555, 556, 559, 561, 566, 567, 568, 569, 571, 577, 581, 582, 586, 587, 591, 592, 598, 599, 600, 601, 613, 614, 619, 620, 622, 623, 626, 631, 632, 633, 635, 637, 638, 643, 644, 646, 652, 660, 661, 664, 669, 670, 671, 672, 673, 674, 675, 681, 685, 688, 692, 695};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 128 18
new 2 128 18
return 1 128 19
assign 1 133 31
create 0 133 31
assign 1 134 32
linkedListIteratorGet 0 134 32
assign 1 135 33
nextNodeGet 0 135 33
assign 1 136 34
undef 1 136 39
return 1 137 40
assign 1 141 44
def 1 141 49
assign 1 142 50
copy 0 142 50
assign 1 143 51
def 1 143 56
nextSet 1 144 57
assign 1 147 59
undef 1 147 64
assign 1 148 65
assign 1 150 67
assign 1 151 68
nextNodeGet 0 151 68
firstNodeSet 1 153 74
lastNodeSet 1 154 75
return 1 155 76
nextSet 1 159 80
assign 1 160 81
def 1 160 86
priorSet 1 161 87
nextSet 1 162 88
assign 1 163 89
assign 1 165 92
assign 1 166 93
mylistSet 1 168 95
nextSet 1 172 100
assign 1 173 101
def 1 173 106
nextSet 1 174 107
priorSet 1 175 108
assign 1 176 109
assign 1 178 112
assign 1 179 113
mylistSet 1 181 115
delete 0 185 119
insertBefore 1 189 123
assign 1 193 136
new 0 193 136
assign 1 193 137
equals 1 193 142
assign 1 194 143
heldGet 0 194 143
return 1 194 144
assign 1 196 146
new 0 196 146
assign 1 197 147
linkedListIteratorGet 0 197 147
assign 1 197 150
hasNextGet 0 197 150
assign 1 198 152
lesser 1 198 157
nextGet 0 199 158
incrementValue 0 203 163
assign 1 205 169
notEquals 1 205 174
return 1 206 175
assign 1 208 177
nextGet 0 208 177
return 1 208 178
assign 1 212 189
new 0 212 189
assign 1 212 190
add 1 212 190
assign 1 213 191
new 0 213 191
assign 1 214 192
linkedListIteratorGet 0 214 192
assign 1 214 195
hasNextGet 0 214 195
assign 1 215 197
lesser 1 215 202
nextGet 0 216 203
incrementValue 0 220 208
assign 1 222 214
notEquals 1 222 219
assign 1 223 220
new 0 223 220
return 1 223 221
assign 1 225 223
currentSet 1 225 223
return 1 225 224
assign 1 229 229
undef 1 229 234
return 1 229 235
assign 1 230 237
heldGet 0 230 237
return 1 230 238
assign 1 234 247
def 1 234 252
assign 1 234 253
nextGet 0 234 253
assign 1 234 254
def 1 234 259
assign 1 0 260
assign 1 0 263
assign 1 0 267
assign 1 235 270
nextGet 0 235 270
assign 1 235 271
heldGet 0 235 271
return 1 235 272
return 1 237 274
assign 1 241 288
def 1 241 293
assign 1 241 294
nextGet 0 241 294
assign 1 241 295
def 1 241 300
assign 1 0 301
assign 1 0 304
assign 1 0 308
assign 1 241 311
nextGet 0 241 311
assign 1 241 312
nextGet 0 241 312
assign 1 241 313
def 1 241 318
assign 1 0 319
assign 1 0 322
assign 1 0 326
assign 1 242 329
nextGet 0 242 329
assign 1 242 330
nextGet 0 242 330
assign 1 242 331
heldGet 0 242 331
return 1 242 332
return 1 244 334
assign 1 248 339
undef 1 248 344
return 1 248 345
assign 1 249 347
heldGet 0 249 347
return 1 249 348
assign 1 253 359
new 0 253 359
assign 1 253 360
equals 1 253 360
return 1 254 362
assign 1 256 364
new 0 256 364
assign 1 257 365
linkedListIteratorGet 0 257 365
assign 1 257 368
hasNextGet 0 257 368
assign 1 258 370
lesser 1 258 370
nextGet 0 259 372
incrementValue 0 263 377
assign 1 265 383
notEquals 1 265 383
return 1 266 385
assign 1 268 387
nextNodeGet 0 268 387
return 1 268 388
assign 1 272 392
newNode 1 272 392
appendNode 1 273 393
assign 1 277 401
def 1 277 406
assign 1 277 407
new 0 277 407
assign 1 277 408
sameType 2 277 408
assign 1 0 410
assign 1 0 413
assign 1 0 417
addAll 1 278 420
addValueWhole 1 280 423
assign 1 285 431
def 1 285 436
assign 1 286 439
hasNextGet 0 286 439
assign 1 287 441
nextGet 0 287 441
addValueWhole 1 287 442
assign 1 293 454
def 1 293 459
assign 1 294 460
iteratorGet 0 294 460
iterateAdd 1 294 461
assign 1 299 467
newNode 1 299 467
prependNode 1 300 468
assign 1 304 475
new 0 304 475
assign 1 305 476
linkedListIteratorGet 0 305 476
assign 1 305 479
hasNextGet 0 305 479
nextGet 0 306 481
incrementValue 0 307 482
return 1 309 488
assign 1 313 492
lengthGet 0 313 492
return 1 313 493
assign 1 317 499
undef 1 317 504
assign 1 318 505
new 0 318 505
return 1 318 506
assign 1 320 508
new 0 320 508
return 1 320 509
assign 1 324 519
lengthGet 0 324 519
assign 1 325 520
new 1 325 520
assign 1 326 521
new 0 326 521
assign 1 327 522
linkedListIteratorGet 0 327 522
assign 1 327 525
hasNextGet 0 327 525
assign 1 328 527
lesser 1 328 532
assign 1 329 533
nextNodeGet 0 329 533
put 2 329 534
incrementValue 0 331 536
return 1 333 542
assign 1 337 553
lengthGet 0 337 553
assign 1 338 554
new 1 338 554
assign 1 339 555
new 0 339 555
assign 1 340 556
linkedListIteratorGet 0 340 556
assign 1 340 559
hasNextGet 0 340 559
assign 1 341 561
lesser 1 341 566
assign 1 342 567
nextNodeGet 0 342 567
assign 1 342 568
heldGet 0 342 568
put 2 342 569
incrementValue 0 344 571
return 1 346 577
assign 1 350 581
new 1 350 581
return 1 350 582
assign 1 354 586
new 1 354 586
return 1 354 587
assign 1 358 591
iteratorGet 0 358 591
return 1 358 592
assign 1 362 598
new 0 362 598
assign 1 362 599
maxGet 0 362 599
assign 1 362 600
subList 2 362 600
return 1 362 601
assign 1 366 613
create 0 366 613
assign 1 367 614
lesserEquals 1 367 619
return 1 368 620
assign 1 370 622
linkedListIteratorGet 0 370 622
assign 1 371 623
new 0 371 623
assign 1 371 626
lesser 1 371 631
assign 1 372 632
hasNextGet 0 372 632
assign 1 372 633
not 0 372 633
return 1 373 635
assign 1 375 637
nextGet 0 375 637
assign 1 376 638
greaterEquals 1 376 643
addValue 1 377 644
incrementValue 0 371 646
return 1 380 652
assign 1 418 660
assign 1 419 661
assign 1 420 664
def 1 420 669
assign 1 421 670
nextGet 0 421 670
assign 1 422 671
priorGet 0 422 671
nextSet 1 422 672
priorSet 1 423 673
assign 1 424 674
assign 1 425 675
assign 1 427 681
return 1 0 685
assign 1 0 688
return 1 0 692
assign 1 0 695
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1973733782: return bem_secondGet_0();
case 1715851153: return bem_lastGet_0();
case -1423130981: return bem_hashGet_0();
case -1756046326: return bem_toString_0();
case -630320646: return bem_serializationIteratorGet_0();
case 455087168: return bem_iteratorGet_0();
case 1528322607: return bem_linkedListIteratorGet_0();
case -467961868: return bem_isEmptyGet_0();
case -300364874: return bem_firstGet_0();
case 1311450919: return bem_firstNodeGet_0();
case 917449916: return bem_thirdGet_0();
case 1608954444: return bem_toNodeList_0();
case -1965055770: return bem_sizeGet_0();
case -589086791: return bem_reverse_0();
case 1478255442: return bem_copy_0();
case 454522998: return bem_print_0();
case -1432972175: return bem_lastNodeGet_0();
case 1454675032: return bem_lengthGet_0();
case 303247198: return bem_toList_0();
case 1012381645: return bem_create_0();
case 530227489: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1608718906: return bem_getNode_1(bevd_0);
case 296918684: return bem_prependNode_1(bevd_0);
case 982368804: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 96657329: return bem_notEquals_1(bevd_0);
case -629264853: return bem_firstNodeSet_1(bevd_0);
case 576934107: return bem_copyTo_1(bevd_0);
case -753684555: return bem_appendNode_1(bevd_0);
case 1985434966: return bem_addAll_1(bevd_0);
case 1276638363: return bem_equals_1(bevd_0);
case -1735089744: return bem_newNode_1(bevd_0);
case -1924313453: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1286942840: return bem_iterateAdd_1(bevd_0);
case 344678914: return bem_addValueWhole_1(bevd_0);
case -1659691586: return bem_prepend_1(bevd_0);
case 889955668: return bem_undef_1(bevd_0);
case 1342373171: return bem_def_1(bevd_0);
case 749348357: return bem_addValue_1(bevd_0);
case -1274387121: return bem_lastNodeSet_1(bevd_0);
case 969617410: return bem_deleteNode_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1465920918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1131482033: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1725232611: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 558464110: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -378086012: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1733857199: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 180847688: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
