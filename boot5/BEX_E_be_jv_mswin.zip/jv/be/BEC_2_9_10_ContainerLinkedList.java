package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList extends BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_2_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 136*/ {
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /* Line: 137*/
while (true)
/* Line: 141*/ {
if (bevl_f == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 141*/ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 143*/ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 144*/
if (bevl_fnode == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 147*/ {
bevl_fnode = bevl_f;
} /* Line: 148*/
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 151*/
 else /* Line: 141*/ {
break;
} /* Line: 141*/
} /* Line: 141*/
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_node.bemd_1(1430825156, null);
if (bevp_lastNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 160*/ {
beva_node.bemd_1(-1638077775, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 163*/
 else /* Line: 164*/ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 166*/
beva_node.bemd_1(472945288, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_node.bemd_1(1430825156, null);
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 173*/ {
beva_node.bemd_1(1430825156, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 176*/
 else /* Line: 177*/ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 179*/
beva_node.bemd_1(472945288, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(-1373699961);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(-1195679279, beva_toIns);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 194*/ {
bevt_0_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 194*/ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 195*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 196*/
 else /* Line: 197*/ {
break;
} /* Line: 198*/
bevl_i.bevi_int++;
} /* Line: 200*/
 else /* Line: 194*/ {
break;
} /* Line: 194*/
} /* Line: 194*/
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 202*/ {
return null;
} /* Line: 203*/
bevt_3_ta_ph = bevl_iter.bem_nextGet_0();
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_pos = beva_pos.bem_add_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 211*/ {
bevt_1_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 211*/ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 212*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 213*/
 else /* Line: 214*/ {
break;
} /* Line: 215*/
bevl_i.bevi_int++;
} /* Line: 217*/
 else /* Line: 211*/ {
break;
} /* Line: 211*/
} /* Line: 211*/
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 220*/
bevt_5_ta_ph = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 226*/ {
return null;
} /* Line: 226*/
bevt_1_ta_ph = bevp_firstNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_ta_ph = null;
if (bevp_firstNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 231*/ {
bevt_3_ta_ph = bevp_firstNode.bem_nextGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 231*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 231*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 231*/
 else /* Line: 231*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 231*/ {
bevt_5_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_heldGet_0();
return bevt_4_ta_ph;
} /* Line: 232*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_ta_ph = null;
if (bevp_firstNode == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_4_ta_ph = bevp_firstNode.bem_nextGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 238*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 238*/
 else /* Line: 238*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 238*/ {
bevt_7_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_nextGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 238*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 238*/
 else /* Line: 238*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 238*/ {
bevt_10_ta_ph = bevp_firstNode.bem_nextGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_nextGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_heldGet_0();
return bevt_8_ta_ph;
} /* Line: 239*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_lastNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 245*/ {
return null;
} /* Line: 245*/
bevt_1_ta_ph = bevp_lastNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
/* Line: 251*/ {
bevt_0_ta_ph = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 251*/ {
bevt_1_ta_ph = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_1_ta_ph.bevi_bool)/* Line: 252*/ {
bevl_iter.bem_nextGet_0();
} /* Line: 253*/
 else /* Line: 254*/ {
break;
} /* Line: 255*/
bevl_i.bevi_int++;
} /* Line: 257*/
 else /* Line: 251*/ {
break;
} /* Line: 251*/
} /* Line: 251*/
bevt_2_ta_ph = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_2_ta_ph.bevi_bool)/* Line: 259*/ {
return null;
} /* Line: 260*/
bevt_3_ta_ph = bevl_iter.bem_nextNodeGet_0();
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_held == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 271*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_held, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 271*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 271*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 271*/
 else /* Line: 271*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 271*/ {
bem_addAll_1(beva_held);
} /* Line: 272*/
 else /* Line: 273*/ {
bem_addValueWhole_1(beva_held);
} /* Line: 274*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 279*/ {
while (true)
/* Line: 280*/ {
bevt_1_ta_ph = beva_val.bemd_0(1420438839);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 280*/ {
bevt_2_ta_ph = beva_val.bemd_0(2087009077);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 281*/
 else /* Line: 280*/ {
break;
} /* Line: 280*/
} /* Line: 280*/
} /* Line: 280*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 287*/ {
bevt_1_ta_ph = beva_val.bemd_0(1018929608);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 288*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 299*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 299*/ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 301*/
 else /* Line: 299*/ {
break;
} /* Line: 299*/
} /* Line: 299*/
return bevl_cnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_lengthGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_firstNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 311*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 312*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toNodeList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 321*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 321*/ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 322*/ {
bevt_2_ta_ph = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_ta_ph);
} /* Line: 323*/
bevl_cnt.bevi_int++;
} /* Line: 325*/
 else /* Line: 321*/ {
break;
} /* Line: 321*/
} /* Line: 321*/
return bevl_toret;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
/* Line: 334*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 334*/ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 335*/ {
bevt_3_ta_ph = bevl_i.bem_nextNodeGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(372755822);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_ta_ph);
} /* Line: 336*/
bevl_cnt.bevi_int++;
} /* Line: 338*/
 else /* Line: 334*/ {
break;
} /* Line: 334*/
} /* Line: 334*/
return bevl_toret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_4_MathInts bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_maxGet_0();
bevt_0_ta_ph = bem_subList_2(beva_start, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 361*/ {
return bevl_res;
} /* Line: 362*/
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 365*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 365*/ {
bevt_3_ta_ph = bevl_iter.bem_hasNextGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(1760971978);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 366*/ {
return bevl_res;
} /* Line: 367*/
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 370*/ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 371*/
bevl_i.bevi_int++;
} /* Line: 365*/
 else /* Line: 365*/ {
break;
} /* Line: 365*/
} /* Line: 365*/
return bevl_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_ta_ph = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
/* Line: 414*/ {
if (bevl_current == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 414*/ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_ta_ph = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_ta_ph);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 419*/
 else /* Line: 414*/ {
break;
} /* Line: 414*/
} /* Line: 414*/
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {128, 128, 133, 134, 135, 136, 136, 137, 141, 141, 142, 143, 143, 144, 147, 147, 148, 150, 151, 153, 154, 155, 159, 160, 160, 161, 162, 163, 165, 166, 168, 172, 173, 173, 174, 175, 176, 178, 179, 181, 185, 189, 193, 194, 194, 195, 195, 196, 200, 202, 202, 203, 205, 205, 209, 209, 210, 211, 211, 212, 212, 213, 217, 219, 219, 220, 220, 222, 222, 226, 226, 226, 227, 227, 231, 231, 231, 231, 231, 0, 0, 0, 232, 232, 232, 234, 238, 238, 238, 238, 238, 0, 0, 0, 238, 238, 238, 238, 0, 0, 0, 239, 239, 239, 239, 241, 245, 245, 245, 246, 246, 250, 251, 251, 252, 253, 257, 259, 260, 262, 262, 266, 267, 271, 271, 271, 271, 0, 0, 0, 272, 274, 279, 279, 280, 281, 281, 287, 287, 288, 288, 293, 294, 298, 299, 299, 300, 301, 303, 307, 307, 311, 311, 312, 312, 314, 314, 318, 319, 320, 321, 321, 322, 322, 323, 323, 325, 327, 331, 332, 333, 334, 334, 335, 335, 336, 336, 336, 338, 340, 344, 344, 348, 348, 352, 352, 356, 356, 356, 356, 360, 361, 361, 362, 364, 365, 365, 365, 366, 366, 367, 369, 370, 370, 371, 365, 374, 412, 413, 414, 414, 415, 416, 416, 417, 418, 419, 421, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 31, 32, 33, 34, 39, 40, 44, 49, 50, 51, 56, 57, 59, 64, 65, 67, 68, 74, 75, 76, 80, 81, 86, 87, 88, 89, 92, 93, 95, 100, 101, 106, 107, 108, 109, 112, 113, 115, 119, 123, 133, 134, 137, 139, 144, 145, 150, 156, 161, 162, 164, 165, 176, 177, 178, 179, 182, 184, 189, 190, 195, 201, 206, 207, 208, 210, 211, 216, 221, 222, 224, 225, 234, 239, 240, 241, 246, 247, 250, 254, 257, 258, 259, 261, 275, 280, 281, 282, 287, 288, 291, 295, 298, 299, 300, 305, 306, 309, 313, 316, 317, 318, 319, 321, 326, 331, 332, 334, 335, 344, 345, 348, 350, 352, 357, 363, 365, 367, 368, 372, 373, 381, 386, 387, 388, 390, 393, 397, 400, 403, 411, 416, 419, 421, 422, 434, 439, 440, 441, 447, 448, 455, 456, 459, 461, 462, 468, 472, 473, 479, 484, 485, 486, 488, 489, 499, 500, 501, 502, 505, 507, 512, 513, 514, 516, 522, 533, 534, 535, 536, 539, 541, 546, 547, 548, 549, 551, 557, 561, 562, 566, 567, 571, 572, 578, 579, 580, 581, 593, 594, 599, 600, 602, 603, 606, 611, 612, 613, 615, 617, 618, 623, 624, 626, 632, 640, 641, 644, 649, 650, 651, 652, 653, 654, 655, 661, 665, 668, 672, 675};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 128 18
new 2 128 18
return 1 128 19
assign 1 133 31
create 0 133 31
assign 1 134 32
linkedListIteratorGet 0 134 32
assign 1 135 33
nextNodeGet 0 135 33
assign 1 136 34
undef 1 136 39
return 1 137 40
assign 1 141 44
def 1 141 49
assign 1 142 50
copy 0 142 50
assign 1 143 51
def 1 143 56
nextSet 1 144 57
assign 1 147 59
undef 1 147 64
assign 1 148 65
assign 1 150 67
assign 1 151 68
nextNodeGet 0 151 68
firstNodeSet 1 153 74
lastNodeSet 1 154 75
return 1 155 76
nextSet 1 159 80
assign 1 160 81
def 1 160 86
priorSet 1 161 87
nextSet 1 162 88
assign 1 163 89
assign 1 165 92
assign 1 166 93
mylistSet 1 168 95
nextSet 1 172 100
assign 1 173 101
def 1 173 106
nextSet 1 174 107
priorSet 1 175 108
assign 1 176 109
assign 1 178 112
assign 1 179 113
mylistSet 1 181 115
delete 0 185 119
insertBefore 1 189 123
assign 1 193 133
new 0 193 133
assign 1 194 134
linkedListIteratorGet 0 194 134
assign 1 194 137
hasNextGet 0 194 137
assign 1 195 139
lesser 1 195 144
nextGet 0 196 145
incrementValue 0 200 150
assign 1 202 156
notEquals 1 202 161
return 1 203 162
assign 1 205 164
nextGet 0 205 164
return 1 205 165
assign 1 209 176
new 0 209 176
assign 1 209 177
add 1 209 177
assign 1 210 178
new 0 210 178
assign 1 211 179
linkedListIteratorGet 0 211 179
assign 1 211 182
hasNextGet 0 211 182
assign 1 212 184
lesser 1 212 189
nextGet 0 213 190
incrementValue 0 217 195
assign 1 219 201
notEquals 1 219 206
assign 1 220 207
new 0 220 207
return 1 220 208
assign 1 222 210
currentSet 1 222 210
return 1 222 211
assign 1 226 216
undef 1 226 221
return 1 226 222
assign 1 227 224
heldGet 0 227 224
return 1 227 225
assign 1 231 234
def 1 231 239
assign 1 231 240
nextGet 0 231 240
assign 1 231 241
def 1 231 246
assign 1 0 247
assign 1 0 250
assign 1 0 254
assign 1 232 257
nextGet 0 232 257
assign 1 232 258
heldGet 0 232 258
return 1 232 259
return 1 234 261
assign 1 238 275
def 1 238 280
assign 1 238 281
nextGet 0 238 281
assign 1 238 282
def 1 238 287
assign 1 0 288
assign 1 0 291
assign 1 0 295
assign 1 238 298
nextGet 0 238 298
assign 1 238 299
nextGet 0 238 299
assign 1 238 300
def 1 238 305
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 239 316
nextGet 0 239 316
assign 1 239 317
nextGet 0 239 317
assign 1 239 318
heldGet 0 239 318
return 1 239 319
return 1 241 321
assign 1 245 326
undef 1 245 331
return 1 245 332
assign 1 246 334
heldGet 0 246 334
return 1 246 335
assign 1 250 344
new 0 250 344
assign 1 251 345
linkedListIteratorGet 0 251 345
assign 1 251 348
hasNextGet 0 251 348
assign 1 252 350
lesser 1 252 350
nextGet 0 253 352
incrementValue 0 257 357
assign 1 259 363
notEquals 1 259 363
return 1 260 365
assign 1 262 367
nextNodeGet 0 262 367
return 1 262 368
assign 1 266 372
newNode 1 266 372
appendNode 1 267 373
assign 1 271 381
def 1 271 386
assign 1 271 387
new 0 271 387
assign 1 271 388
sameType 2 271 388
assign 1 0 390
assign 1 0 393
assign 1 0 397
addAll 1 272 400
addValueWhole 1 274 403
assign 1 279 411
def 1 279 416
assign 1 280 419
hasNextGet 0 280 419
assign 1 281 421
nextGet 0 281 421
addValueWhole 1 281 422
assign 1 287 434
def 1 287 439
assign 1 288 440
iteratorGet 0 288 440
iterateAdd 1 288 441
assign 1 293 447
newNode 1 293 447
prependNode 1 294 448
assign 1 298 455
new 0 298 455
assign 1 299 456
linkedListIteratorGet 0 299 456
assign 1 299 459
hasNextGet 0 299 459
nextGet 0 300 461
incrementValue 0 301 462
return 1 303 468
assign 1 307 472
lengthGet 0 307 472
return 1 307 473
assign 1 311 479
undef 1 311 484
assign 1 312 485
new 0 312 485
return 1 312 486
assign 1 314 488
new 0 314 488
return 1 314 489
assign 1 318 499
lengthGet 0 318 499
assign 1 319 500
new 1 319 500
assign 1 320 501
new 0 320 501
assign 1 321 502
linkedListIteratorGet 0 321 502
assign 1 321 505
hasNextGet 0 321 505
assign 1 322 507
lesser 1 322 512
assign 1 323 513
nextNodeGet 0 323 513
put 2 323 514
incrementValue 0 325 516
return 1 327 522
assign 1 331 533
lengthGet 0 331 533
assign 1 332 534
new 1 332 534
assign 1 333 535
new 0 333 535
assign 1 334 536
linkedListIteratorGet 0 334 536
assign 1 334 539
hasNextGet 0 334 539
assign 1 335 541
lesser 1 335 546
assign 1 336 547
nextNodeGet 0 336 547
assign 1 336 548
heldGet 0 336 548
put 2 336 549
incrementValue 0 338 551
return 1 340 557
assign 1 344 561
new 1 344 561
return 1 344 562
assign 1 348 566
new 1 348 566
return 1 348 567
assign 1 352 571
iteratorGet 0 352 571
return 1 352 572
assign 1 356 578
new 0 356 578
assign 1 356 579
maxGet 0 356 579
assign 1 356 580
subList 2 356 580
return 1 356 581
assign 1 360 593
create 0 360 593
assign 1 361 594
lesserEquals 1 361 599
return 1 362 600
assign 1 364 602
linkedListIteratorGet 0 364 602
assign 1 365 603
new 0 365 603
assign 1 365 606
lesser 1 365 611
assign 1 366 612
hasNextGet 0 366 612
assign 1 366 613
not 0 366 613
return 1 367 615
assign 1 369 617
nextGet 0 369 617
assign 1 370 618
greaterEquals 1 370 623
addValue 1 371 624
incrementValue 0 365 626
return 1 374 632
assign 1 412 640
assign 1 413 641
assign 1 414 644
def 1 414 649
assign 1 415 650
nextGet 0 415 650
assign 1 416 651
priorGet 0 416 651
nextSet 1 416 652
priorSet 1 417 653
assign 1 418 654
assign 1 419 655
assign 1 421 661
return 1 0 665
assign 1 0 668
return 1 0 672
assign 1 0 675
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1759691652: return bem_isEmptyGet_0();
case 600041715: return bem_reverse_0();
case -920998616: return bem_firstNodeGet_0();
case -907558589: return bem_firstGet_0();
case 1486356623: return bem_new_0();
case -1826524566: return bem_lastGet_0();
case -989279639: return bem_toString_0();
case -651000580: return bem_secondGet_0();
case 1041690009: return bem_create_0();
case -499249919: return bem_toList_0();
case -935125340: return bem_thirdGet_0();
case -766047655: return bem_lastNodeGet_0();
case -2075471997: return bem_print_0();
case 296234079: return bem_linkedListIteratorGet_0();
case -278676308: return bem_copy_0();
case -1262050974: return bem_toNodeList_0();
case -1546228870: return bem_sizeGet_0();
case -18293313: return bem_serializationIteratorGet_0();
case 1413764899: return bem_lengthGet_0();
case 1349825318: return bem_hashGet_0();
case 1018929608: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 429997543: return bem_undef_1(bevd_0);
case 1445841729: return bem_firstNodeSet_1(bevd_0);
case 2001366394: return bem_def_1(bevd_0);
case -1614016998: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -1290752146: return bem_iterateAdd_1(bevd_0);
case 271679255: return bem_appendNode_1(bevd_0);
case 1826376252: return bem_copyTo_1(bevd_0);
case -1283958111: return bem_notEquals_1(bevd_0);
case -1676474385: return bem_deleteNode_1(bevd_0);
case 1642159399: return bem_prependNode_1(bevd_0);
case 964719406: return bem_equals_1(bevd_0);
case 1937927718: return bem_addValue_1(bevd_0);
case -1310374629: return bem_getNode_1(bevd_0);
case 1349976346: return bem_prepend_1(bevd_0);
case 742791872: return bem_addAll_1(bevd_0);
case 2050086395: return bem_newNode_1(bevd_0);
case -971164411: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1829139713: return bem_lastNodeSet_1(bevd_0);
case -1319557649: return bem_addValueWhole_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -825340533: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 13035210: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -873382988: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 864744165: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2064717466: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -392342023: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1261192257: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
