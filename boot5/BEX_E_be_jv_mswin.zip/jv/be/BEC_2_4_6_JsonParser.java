package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_6_JsonParser extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_JsonParser() { }
private static byte[] becc_BEC_2_4_6_JsonParser_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x72};
private static byte[] becc_BEC_2_4_6_JsonParser_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_0 = {0x7B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_1 = {0x7D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_2 = {0x5B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_3 = {0x5D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_4 = {0x5C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_5 = {0x2C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_6 = {0x62,0x66,0x6E,0x72,0x74,0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_6, 6));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_8 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_9 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_1 = (new BEC_2_4_3_MathInt(55296));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_2 = (new BEC_2_4_3_MathInt(56319));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_3 = (new BEC_2_4_3_MathInt(56320));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_4 = (new BEC_2_4_3_MathInt(57343));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_5 = (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_6 = (new BEC_2_4_3_MathInt(5));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_10 = {0x74,0x6F,0x6B,0x20,0x74,0x6F,0x6F,0x20,0x73,0x6D,0x61,0x6C,0x6C};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_7 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_8 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_11 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_12 = {0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_13 = {0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_14 = {0x37,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_15 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_16 = {0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_17 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_18 = {0x45,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_19 = {0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_20 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_21 = {0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_12 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_22 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_23 = {0x30,0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_24 = {0x31,0x30,0x46,0x46,0x46,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_25 = {0x46,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_26 = {0x31,0x43,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_27 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_28 = {0x30,0x33,0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_29 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_30 = {0x30,0x30,0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_15 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_31 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_32 = {0x30,0x30,0x30,0x30,0x33,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_33 = {0x66,0x61,0x69,0x6C,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x74,0x6F,0x20,0x62,0x75,0x66,0x66,0x65,0x72,0x20,0x63,0x6F,0x6E,0x76,0x65,0x72,0x74};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_34 = {0x75};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_34, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_35 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x69,0x73,0x20,0x69,0x6E,0x76,0x61,0x6C,0x69,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_36 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x65,0x64,0x20,0x62,0x79,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_37 = {0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_37, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_38 = {0x72};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_38, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_39 = {0x66};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_39, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_40 = {0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_40, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_41 = {0x75,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_41, 2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_42 = {0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_42, 4));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_43 = {0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_43, 3));
public static BEC_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_inst;

public static BET_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_type;

public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_lbrace;
public BEC_2_4_6_TextString bevp_rbrace;
public BEC_2_4_6_TextString bevp_lbracket;
public BEC_2_4_6_TextString bevp_rbracket;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_6_TextString bevp_escape;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_comma;
public BEC_2_4_6_TextString bevp_tokens;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_4_3_MathInt bevp_hsub;
public BEC_2_4_3_MathInt bevp_vsub;
public BEC_2_4_3_MathInt bevp_hmAdd;
public BEC_2_4_6_JsonParser bem_new_0() throws Throwable {
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_quote = bevt_0_tmpany_phold.bem_quoteGet_0();
bevp_lbrace = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_0));
bevp_rbrace = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_1));
bevp_lbracket = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_2));
bevp_rbracket = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_3));
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_space = bevt_1_tmpany_phold.bem_spaceGet_0();
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_colon = bevt_2_tmpany_phold.bem_colonGet_0();
bevp_escape = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_4));
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_cr = bevt_3_tmpany_phold.bem_crGet_0();
bevt_4_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_lf = bevt_4_tmpany_phold.bem_lfGet_0();
bevp_comma = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_5));
bevt_14_tmpany_phold = bevp_quote.bem_add_1(bevp_lbrace);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevp_rbrace);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_lbracket);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevp_rbracket);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevp_space);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_colon);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevp_escape);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevp_cr);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_lf);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevp_comma);
bevt_15_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_0;
bevp_tokens = bevt_5_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_toker = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevp_tokens, bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_7));
bevp_hsub = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_8));
bevp_vsub = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevp_hmAdd = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_19_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parse_2(BEC_2_4_6_TextString beva_str, BEC_2_6_6_SystemObject beva_handler) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_toker.bem_tokenize_1(beva_str);
bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold , beva_handler);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_jsonUcIsPairStart_1(BEC_2_4_3_MathInt beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_1;
if (bevt_2_tmpany_phold.bevi_int <= beva_value.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 63 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_2;
if (beva_value.bevi_int <= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 63 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 63 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 63 */
 else  /* Line: 63 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 63 */ {
bevl_result = be.BECS_Runtime.boolTrue;
} /* Line: 64 */
 else  /* Line: 65 */ {
bevl_result = be.BECS_Runtime.boolFalse;
} /* Line: 66 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_jsonUcIsPairEnd_1(BEC_2_4_3_MathInt beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_3;
if (bevt_2_tmpany_phold.bevi_int <= beva_value.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_4;
if (beva_value.bevi_int <= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevl_result = be.BECS_Runtime.boolTrue;
} /* Line: 75 */
 else  /* Line: 76 */ {
bevl_result = be.BECS_Runtime.boolFalse;
} /* Line: 77 */
return bevl_result;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonUcGetAfterPart_1(BEC_2_4_6_TextString beva_tok) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_5;
if (bevt_1_tmpany_phold.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 84 */ {
return null;
} /* Line: 85 */
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevt_3_tmpany_phold = beva_tok.bem_substring_1(bevt_4_tmpany_phold);
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_jsonUcUnescape_1(BEC_2_4_6_TextString beva_tok) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_6;
if (bevt_1_tmpany_phold.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 91 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_6_JsonParser_bels_10));
bevt_3_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 92 */
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_6_tmpany_phold = beva_tok.bem_substring_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_6_tmpany_phold);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_JsonParser bem_jsonUcAppendValue_3(BEC_2_4_3_MathInt beva_heldValue, BEC_2_4_3_MathInt beva_value, BEC_2_4_6_TextString beva_accum) throws Throwable {
BEC_2_4_3_MathInt bevl_sizeNow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_heldm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
bevt_2_tmpany_phold = beva_accum.bem_capacityGet_0();
bevt_3_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_subtract_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_7;
if (bevt_1_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevt_6_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_7_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_8;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
beva_accum.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 100 */
bevl_sizeNow = beva_accum.bem_sizeGet_0();
if (beva_heldValue == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 105 */ {
bevl_heldm = beva_heldValue;
bevl_heldm.bem_subtractValue_1(bevp_hsub);
bevt_9_tmpany_phold = (new BEC_2_4_3_MathInt(10));
bevl_heldm.bem_shiftLeftValue_1(bevt_9_tmpany_phold);
bevl_heldm.bem_subtractValue_1(bevp_vsub);
bevl_heldm.bevi_int += beva_value.bevi_int;
bevl_heldm.bevi_int += bevp_hmAdd.bevi_int;
beva_value = bevl_heldm;
} /* Line: 113 */
bevt_11_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_9;
if (beva_value.bevi_int < bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevl_size = (new BEC_2_4_3_MathInt(-1));
} /* Line: 120 */
 else  /* Line: 119 */ {
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_13_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_14_tmpany_phold);
if (beva_value.bevi_int < bevt_13_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 121 */ {
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, beva_value);
bevl_size = (new BEC_2_4_3_MathInt(1));
} /* Line: 123 */
 else  /* Line: 119 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_12));
bevt_16_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpany_phold);
if (beva_value.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_13));
bevt_19_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_20_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_14));
bevt_23_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_24_tmpany_phold);
bevt_22_tmpany_phold = beva_value.bem_and_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_shiftRight_1(bevt_25_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_18_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_10;
bevt_26_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_15));
bevt_29_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_30_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_16));
bevt_32_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_33_tmpany_phold);
bevt_31_tmpany_phold = beva_value.bem_and_1(bevt_32_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_28_tmpany_phold);
bevl_size = (new BEC_2_4_3_MathInt(2));
} /* Line: 127 */
 else  /* Line: 119 */ {
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_17));
bevt_35_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_36_tmpany_phold);
if (beva_value.bevi_int < bevt_35_tmpany_phold.bevi_int) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_18));
bevt_38_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_39_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_19));
bevt_42_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_43_tmpany_phold);
bevt_41_tmpany_phold = beva_value.bem_and_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_3_MathInt(12));
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_shiftRight_1(bevt_44_tmpany_phold);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_37_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_11;
bevt_45_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_46_tmpany_phold);
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_20));
bevt_48_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_21));
bevt_52_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_53_tmpany_phold);
bevt_51_tmpany_phold = beva_value.bem_and_1(bevt_52_tmpany_phold);
bevt_54_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_shiftRight_1(bevt_54_tmpany_phold);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_50_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_45_tmpany_phold, bevt_47_tmpany_phold);
bevt_56_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_12;
bevt_55_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_56_tmpany_phold);
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_22));
bevt_58_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_59_tmpany_phold);
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_23));
bevt_61_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_tmpany_phold);
bevt_60_tmpany_phold = beva_value.bem_and_1(bevt_61_tmpany_phold);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevt_60_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_55_tmpany_phold, bevt_57_tmpany_phold);
bevl_size = (new BEC_2_4_3_MathInt(3));
} /* Line: 132 */
 else  /* Line: 119 */ {
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_24));
bevt_64_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_tmpany_phold);
if (beva_value.bevi_int <= bevt_64_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 133 */ {
bevt_68_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_25));
bevt_67_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_tmpany_phold);
bevt_72_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_26));
bevt_71_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_72_tmpany_phold);
bevt_70_tmpany_phold = beva_value.bem_and_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_4_3_MathInt(18));
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_shiftRight_1(bevt_73_tmpany_phold);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_add_1(bevt_69_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_66_tmpany_phold);
bevt_75_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_13;
bevt_74_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_75_tmpany_phold);
bevt_78_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_27));
bevt_77_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_78_tmpany_phold);
bevt_82_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_28));
bevt_81_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_82_tmpany_phold);
bevt_80_tmpany_phold = beva_value.bem_and_1(bevt_81_tmpany_phold);
bevt_83_tmpany_phold = (new BEC_2_4_3_MathInt(12));
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_shiftRight_1(bevt_83_tmpany_phold);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bem_add_1(bevt_79_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_74_tmpany_phold, bevt_76_tmpany_phold);
bevt_85_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_14;
bevt_84_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_85_tmpany_phold);
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_29));
bevt_87_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_88_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_30));
bevt_91_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_92_tmpany_phold);
bevt_90_tmpany_phold = beva_value.bem_and_1(bevt_91_tmpany_phold);
bevt_93_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bem_shiftRight_1(bevt_93_tmpany_phold);
bevt_86_tmpany_phold = bevt_87_tmpany_phold.bem_add_1(bevt_89_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_84_tmpany_phold, bevt_86_tmpany_phold);
bevt_95_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_15;
bevt_94_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_95_tmpany_phold);
bevt_98_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_31));
bevt_97_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_98_tmpany_phold);
bevt_101_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_32));
bevt_100_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_101_tmpany_phold);
bevt_99_tmpany_phold = beva_value.bem_and_1(bevt_100_tmpany_phold);
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_add_1(bevt_99_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_94_tmpany_phold, bevt_96_tmpany_phold);
bevl_size = (new BEC_2_4_3_MathInt(4));
} /* Line: 138 */
 else  /* Line: 139 */ {
bevl_size = (new BEC_2_4_3_MathInt(-1));
} /* Line: 140 */
} /* Line: 119 */
} /* Line: 119 */
} /* Line: 119 */
} /* Line: 119 */
bevt_103_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_16;
if (bevl_size.bevi_int < bevt_103_tmpany_phold.bevi_int) {
bevt_102_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_102_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_102_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_4_6_JsonParser_bels_33));
bevt_104_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_105_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_104_tmpany_phold);
} /* Line: 144 */
bevt_107_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_106_tmpany_phold = bevt_107_tmpany_phold.bem_add_1(bevl_size);
beva_accum.bem_sizeSet_1(bevt_106_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parseTokens_2(BEC_2_9_10_ContainerLinkedList beva_toks, BEC_2_6_6_SystemObject beva_handler) throws Throwable {
BEC_2_5_4_LogicBool bevl_inString = null;
BEC_2_5_4_LogicBool bevl_inEscape = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_9_3_ContainerMap bevl_fromEscapes = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_tokIter = null;
BEC_2_4_3_MathInt bevl_heldValue = null;
BEC_2_4_6_TextString bevl_tok = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_6_TextString bevl_remainder = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_4_7_JsonEscapes bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
bevl_inString = be.BECS_Runtime.boolFalse;
bevl_inEscape = be.BECS_Runtime.boolFalse;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevl_fromEscapes = bevt_9_tmpany_phold.bem_fromEscapesGet_0();
bevl_tokIter = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 177 */ {
bevt_10_tmpany_phold = bevl_tokIter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 177 */ {
bevl_tok = (BEC_2_4_6_TextString) bevl_tokIter.bem_nextGet_0();
if (bevl_inString.bevi_bool) /* Line: 180 */ {
if (bevl_inEscape.bevi_bool) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 181 */ {
bevt_12_tmpany_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 181 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 181 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 181 */
 else  /* Line: 181 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 181 */ {
bevl_inString = be.BECS_Runtime.boolFalse;
bevt_13_tmpany_phold = bevl_accum.bem_extractString_0();
beva_handler.bemd_1(231295518, bevt_13_tmpany_phold);
} /* Line: 183 */
 else  /* Line: 184 */ {
if (bevl_inEscape.bevi_bool) /* Line: 185 */ {
bevl_escval = (BEC_2_4_6_TextString) bevl_fromEscapes.bem_get_1(bevl_tok);
if (bevl_escval == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevl_accum.bem_addValue_1(bevl_escval);
} /* Line: 188 */
 else  /* Line: 187 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_17;
bevt_15_tmpany_phold = bevl_tok.bem_begins_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevl_value = bem_jsonUcUnescape_1(bevl_tok);
bevl_remainder = bem_jsonUcGetAfterPart_1(bevl_tok);
bevl_isStart = be.BECS_Runtime.boolFalse;
if (bevl_heldValue == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 193 */ {
bevt_19_tmpany_phold = bem_jsonUcIsPairEnd_1(bevl_value);
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 193 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 193 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 193 */
 else  /* Line: 193 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 193 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(62, bece_BEC_2_4_6_JsonParser_bels_35));
bevt_20_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_21_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 194 */
 else  /* Line: 193 */ {
if (bevl_heldValue == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevl_isStart = bem_jsonUcIsPairStart_1(bevl_value);
} /* Line: 196 */
} /* Line: 193 */
if (bevl_isStart.bevi_bool) /* Line: 198 */ {
if (bevl_remainder == null) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 198 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 198 */
 else  /* Line: 198 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 198 */ {
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(73, bece_BEC_2_4_6_JsonParser_bels_36));
bevt_24_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 199 */
if (bevl_isStart.bevi_bool) /* Line: 201 */ {
bevl_heldValue = bevl_value;
} /* Line: 202 */
 else  /* Line: 203 */ {
bem_jsonUcAppendValue_3(bevl_heldValue, bevl_value, bevl_accum);
bevl_heldValue = null;
if (bevl_remainder == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevl_accum.bem_addValue_1(bevl_remainder);
} /* Line: 207 */
} /* Line: 206 */
} /* Line: 201 */
 else  /* Line: 210 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 211 */
} /* Line: 187 */
bevl_inEscape = be.BECS_Runtime.boolFalse;
} /* Line: 213 */
 else  /* Line: 185 */ {
bevt_27_tmpany_phold = bevl_tok.bem_equals_1(bevp_escape);
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevl_inEscape = be.BECS_Runtime.boolTrue;
} /* Line: 215 */
 else  /* Line: 216 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 217 */
} /* Line: 185 */
} /* Line: 185 */
} /* Line: 181 */
 else  /* Line: 220 */ {
bevt_28_tmpany_phold = bevl_tok.bem_equals_1(bevp_space);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 222 */ {
bevt_29_tmpany_phold = bevl_tok.bem_equals_1(bevp_cr);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 222 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 222 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 222 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 222 */ {
bevt_30_tmpany_phold = bevl_tok.bem_equals_1(bevp_lf);
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 222 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 222 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 222 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 222 */ {
bevt_31_tmpany_phold = bevl_tok.bem_equals_1(bevp_comma);
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 222 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 222 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 222 */ {
} /* Line: 222 */
 else  /* Line: 222 */ {
bevt_32_tmpany_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevl_inString = be.BECS_Runtime.boolTrue;
} /* Line: 224 */
 else  /* Line: 222 */ {
bevt_33_tmpany_phold = bevl_tok.bem_equals_1(bevp_lbrace);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 225 */ {
beva_handler.bemd_0(1602931482);
} /* Line: 226 */
 else  /* Line: 222 */ {
bevt_34_tmpany_phold = bevl_tok.bem_equals_1(bevp_rbrace);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 227 */ {
beva_handler.bemd_0(1186955159);
} /* Line: 228 */
 else  /* Line: 222 */ {
bevt_35_tmpany_phold = bevl_tok.bem_equals_1(bevp_colon);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 229 */ {
beva_handler.bemd_0(-615782553);
} /* Line: 230 */
 else  /* Line: 222 */ {
bevt_36_tmpany_phold = bevl_tok.bem_equals_1(bevp_lbracket);
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 231 */ {
beva_handler.bemd_0(846863036);
} /* Line: 232 */
 else  /* Line: 222 */ {
bevt_37_tmpany_phold = bevl_tok.bem_equals_1(bevp_rbracket);
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 233 */ {
beva_handler.bemd_0(-1408174828);
} /* Line: 234 */
 else  /* Line: 235 */ {
bevt_39_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_18;
bevt_38_tmpany_phold = bevl_tok.bem_equals_1(bevt_39_tmpany_phold);
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_41_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_19;
bevt_40_tmpany_phold = bevl_tok.bem_equals_1(bevt_41_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 238 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_43_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_20;
bevt_42_tmpany_phold = bevl_tok.bem_equals_1(bevt_43_tmpany_phold);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 238 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_45_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_21;
bevt_44_tmpany_phold = bevl_tok.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 238 */ {
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_47_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_22;
bevt_46_tmpany_phold = bevl_tok.bem_equals_1(bevt_47_tmpany_phold);
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 241 */ {
beva_handler.bemd_0(-1394459018);
} /* Line: 242 */
 else  /* Line: 238 */ {
bevt_49_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_23;
bevt_48_tmpany_phold = bevl_tok.bem_equals_1(bevt_49_tmpany_phold);
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 243 */ {
beva_handler.bemd_0(1438378948);
} /* Line: 244 */
 else  /* Line: 238 */ {
bevt_51_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_24;
bevt_50_tmpany_phold = bevl_tok.bem_equals_1(bevt_51_tmpany_phold);
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 245 */ {
beva_handler.bemd_0(-519557463);
} /* Line: 246 */
 else  /* Line: 247 */ {
bevt_52_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_tok);
beva_handler.bemd_1(-1590386444, bevt_52_tmpany_phold);
} /* Line: 249 */
} /* Line: 238 */
} /* Line: 238 */
} /* Line: 238 */
} /* Line: 238 */
} /* Line: 222 */
} /* Line: 222 */
} /* Line: 222 */
} /* Line: 222 */
} /* Line: 222 */
} /* Line: 222 */
} /* Line: 222 */
} /* Line: 180 */
 else  /* Line: 177 */ {
break;
} /* Line: 177 */
} /* Line: 177 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public final BEC_2_4_6_TextString bem_quoteGetDirect_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_JsonParser bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbraceGet_0() throws Throwable {
return bevp_lbrace;
} /*method end*/
public final BEC_2_4_6_TextString bem_lbraceGetDirect_0() throws Throwable {
return bevp_lbrace;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_lbraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_rbraceGet_0() throws Throwable {
return bevp_rbrace;
} /*method end*/
public final BEC_2_4_6_TextString bem_rbraceGetDirect_0() throws Throwable {
return bevp_rbrace;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_rbraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbracketGet_0() throws Throwable {
return bevp_lbracket;
} /*method end*/
public final BEC_2_4_6_TextString bem_lbracketGetDirect_0() throws Throwable {
return bevp_lbracket;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_lbracketSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_rbracketGet_0() throws Throwable {
return bevp_rbracket;
} /*method end*/
public final BEC_2_4_6_TextString bem_rbracketGetDirect_0() throws Throwable {
return bevp_rbracket;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_rbracketSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public final BEC_2_4_6_TextString bem_spaceGetDirect_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_6_JsonParser bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public final BEC_2_4_6_TextString bem_colonGetDirect_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_JsonParser bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_escapeGet_0() throws Throwable {
return bevp_escape;
} /*method end*/
public final BEC_2_4_6_TextString bem_escapeGetDirect_0() throws Throwable {
return bevp_escape;
} /*method end*/
public BEC_2_4_6_JsonParser bem_escapeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_escapeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public final BEC_2_4_6_TextString bem_crGetDirect_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_JsonParser bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public final BEC_2_4_6_TextString bem_lfGetDirect_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commaGet_0() throws Throwable {
return bevp_comma;
} /*method end*/
public final BEC_2_4_6_TextString bem_commaGetDirect_0() throws Throwable {
return bevp_comma;
} /*method end*/
public BEC_2_4_6_JsonParser bem_commaSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_commaSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tokensGet_0() throws Throwable {
return bevp_tokens;
} /*method end*/
public final BEC_2_4_6_TextString bem_tokensGetDirect_0() throws Throwable {
return bevp_tokens;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_tokensSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() throws Throwable {
return bevp_toker;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() throws Throwable {
return bevp_toker;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hsubGet_0() throws Throwable {
return bevp_hsub;
} /*method end*/
public final BEC_2_4_3_MathInt bem_hsubGetDirect_0() throws Throwable {
return bevp_hsub;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_hsubSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vsubGet_0() throws Throwable {
return bevp_vsub;
} /*method end*/
public final BEC_2_4_3_MathInt bem_vsubGetDirect_0() throws Throwable {
return bevp_vsub;
} /*method end*/
public BEC_2_4_6_JsonParser bem_vsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_vsubSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmAddGet_0() throws Throwable {
return bevp_hmAdd;
} /*method end*/
public final BEC_2_4_3_MathInt bem_hmAddGetDirect_0() throws Throwable {
return bevp_hmAdd;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hmAddSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_6_JsonParser bem_hmAddSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {37, 37, 38, 39, 40, 41, 42, 42, 43, 43, 44, 45, 45, 46, 46, 47, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 49, 49, 50, 50, 51, 51, 52, 52, 58, 58, 63, 63, 63, 63, 63, 63, 0, 0, 0, 64, 66, 68, 74, 74, 74, 74, 74, 74, 0, 0, 0, 75, 77, 79, 84, 84, 84, 84, 85, 87, 87, 87, 91, 91, 91, 91, 92, 92, 92, 94, 94, 94, 94, 99, 99, 99, 99, 99, 99, 100, 100, 100, 100, 102, 105, 105, 107, 108, 109, 109, 110, 111, 112, 113, 119, 119, 119, 120, 121, 121, 121, 121, 122, 123, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 128, 128, 128, 128, 129, 129, 129, 129, 129, 129, 129, 129, 129, 130, 130, 130, 130, 130, 130, 130, 130, 130, 130, 130, 131, 131, 131, 131, 131, 131, 131, 131, 131, 132, 133, 133, 133, 133, 134, 134, 134, 134, 134, 134, 134, 134, 134, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 137, 137, 137, 137, 137, 137, 137, 137, 137, 138, 140, 143, 143, 143, 144, 144, 144, 146, 146, 146, 167, 168, 169, 171, 171, 173, 177, 178, 181, 181, 181, 0, 0, 0, 182, 183, 183, 186, 187, 187, 188, 189, 189, 190, 191, 192, 193, 193, 193, 193, 193, 0, 0, 0, 194, 194, 194, 195, 195, 196, 198, 198, 0, 0, 0, 199, 199, 199, 202, 204, 205, 206, 206, 207, 211, 213, 214, 215, 217, 222, 0, 222, 0, 0, 0, 222, 0, 0, 0, 222, 0, 0, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 238, 238, 0, 238, 238, 0, 0, 0, 238, 238, 0, 0, 0, 238, 238, 0, 0, 241, 241, 242, 243, 243, 244, 245, 245, 246, 249, 249, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 157, 158, 168, 169, 174, 175, 176, 181, 182, 185, 189, 192, 195, 197, 206, 207, 212, 213, 214, 219, 220, 223, 227, 230, 233, 235, 243, 244, 245, 250, 251, 253, 254, 255, 266, 267, 268, 273, 274, 275, 276, 278, 279, 280, 281, 395, 396, 397, 398, 399, 404, 405, 406, 407, 408, 410, 411, 416, 417, 418, 419, 420, 421, 422, 423, 424, 426, 427, 432, 433, 436, 437, 438, 443, 444, 445, 448, 449, 450, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 477, 478, 479, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 517, 518, 519, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 568, 574, 575, 580, 581, 582, 583, 585, 586, 587, 655, 656, 657, 658, 659, 660, 663, 665, 667, 672, 673, 675, 678, 682, 685, 686, 687, 691, 692, 697, 698, 701, 702, 704, 705, 706, 707, 712, 713, 714, 719, 720, 723, 727, 730, 731, 732, 735, 740, 741, 745, 750, 751, 754, 758, 761, 762, 763, 766, 769, 770, 771, 776, 777, 782, 785, 788, 790, 793, 799, 801, 804, 806, 809, 813, 816, 818, 821, 825, 828, 830, 833, 839, 841, 844, 846, 849, 851, 854, 856, 859, 861, 864, 866, 869, 870, 872, 875, 876, 878, 881, 885, 888, 889, 891, 894, 898, 901, 902, 904, 907, 913, 914, 916, 919, 920, 922, 925, 926, 928, 931, 932, 953, 956, 959, 963, 967, 970, 973, 977, 981, 984, 987, 991, 995, 998, 1001, 1005, 1009, 1012, 1015, 1019, 1023, 1026, 1029, 1033, 1037, 1040, 1043, 1047, 1051, 1054, 1057, 1061, 1065, 1068, 1071, 1075, 1079, 1082, 1085, 1089, 1093, 1096, 1099, 1103, 1107, 1110, 1113, 1117, 1121, 1124, 1127, 1131, 1135, 1138, 1141, 1145, 1149, 1152, 1155, 1159, 1163, 1166, 1169, 1173};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 37 117
new 0 37 117
assign 1 37 118
quoteGet 0 37 118
assign 1 38 119
new 0 38 119
assign 1 39 120
new 0 39 120
assign 1 40 121
new 0 40 121
assign 1 41 122
new 0 41 122
assign 1 42 123
new 0 42 123
assign 1 42 124
spaceGet 0 42 124
assign 1 43 125
new 0 43 125
assign 1 43 126
colonGet 0 43 126
assign 1 44 127
new 0 44 127
assign 1 45 128
new 0 45 128
assign 1 45 129
crGet 0 45 129
assign 1 46 130
new 0 46 130
assign 1 46 131
lfGet 0 46 131
assign 1 47 132
new 0 47 132
assign 1 48 133
add 1 48 133
assign 1 48 134
add 1 48 134
assign 1 48 135
add 1 48 135
assign 1 48 136
add 1 48 136
assign 1 48 137
add 1 48 137
assign 1 48 138
add 1 48 138
assign 1 48 139
add 1 48 139
assign 1 48 140
add 1 48 140
assign 1 48 141
add 1 48 141
assign 1 48 142
add 1 48 142
assign 1 48 143
new 0 48 143
assign 1 48 144
add 1 48 144
assign 1 49 145
new 0 49 145
assign 1 49 146
new 2 49 146
assign 1 50 147
new 0 50 147
assign 1 50 148
hexNew 1 50 148
assign 1 51 149
new 0 51 149
assign 1 51 150
hexNew 1 51 150
assign 1 52 151
new 0 52 151
assign 1 52 152
hexNew 1 52 152
assign 1 58 157
tokenize 1 58 157
parseTokens 2 58 158
assign 1 63 168
new 0 63 168
assign 1 63 169
lesserEquals 1 63 174
assign 1 63 175
new 0 63 175
assign 1 63 176
lesserEquals 1 63 181
assign 1 0 182
assign 1 0 185
assign 1 0 189
assign 1 64 192
new 0 64 192
assign 1 66 195
new 0 66 195
return 1 68 197
assign 1 74 206
new 0 74 206
assign 1 74 207
lesserEquals 1 74 212
assign 1 74 213
new 0 74 213
assign 1 74 214
lesserEquals 1 74 219
assign 1 0 220
assign 1 0 223
assign 1 0 227
assign 1 75 230
new 0 75 230
assign 1 77 233
new 0 77 233
return 1 79 235
assign 1 84 243
sizeGet 0 84 243
assign 1 84 244
new 0 84 244
assign 1 84 245
lesser 1 84 250
return 1 85 251
assign 1 87 253
new 0 87 253
assign 1 87 254
substring 1 87 254
return 1 87 255
assign 1 91 266
sizeGet 0 91 266
assign 1 91 267
new 0 91 267
assign 1 91 268
lesser 1 91 273
assign 1 92 274
new 0 92 274
assign 1 92 275
new 1 92 275
throw 1 92 276
assign 1 94 278
new 0 94 278
assign 1 94 279
substring 1 94 279
assign 1 94 280
hexNew 1 94 280
return 1 94 281
assign 1 99 395
capacityGet 0 99 395
assign 1 99 396
sizeGet 0 99 396
assign 1 99 397
subtract 1 99 397
assign 1 99 398
new 0 99 398
assign 1 99 399
lesser 1 99 404
assign 1 100 405
sizeGet 0 100 405
assign 1 100 406
new 0 100 406
assign 1 100 407
add 1 100 407
capacitySet 1 100 408
assign 1 102 410
sizeGet 0 102 410
assign 1 105 411
def 1 105 416
assign 1 107 417
subtractValue 1 108 418
assign 1 109 419
new 0 109 419
shiftLeftValue 1 109 420
subtractValue 1 110 421
addValue 1 111 422
addValue 1 112 423
assign 1 113 424
assign 1 119 426
new 0 119 426
assign 1 119 427
lesser 1 119 432
assign 1 120 433
new 0 120 433
assign 1 121 436
new 0 121 436
assign 1 121 437
hexNew 1 121 437
assign 1 121 438
lesser 1 121 443
setIntUnchecked 2 122 444
assign 1 123 445
new 0 123 445
assign 1 124 448
new 0 124 448
assign 1 124 449
hexNew 1 124 449
assign 1 124 450
lesser 1 124 455
assign 1 125 456
new 0 125 456
assign 1 125 457
hexNew 1 125 457
assign 1 125 458
new 0 125 458
assign 1 125 459
hexNew 1 125 459
assign 1 125 460
and 1 125 460
assign 1 125 461
new 0 125 461
assign 1 125 462
shiftRight 1 125 462
assign 1 125 463
add 1 125 463
setIntUnchecked 2 125 464
assign 1 126 465
new 0 126 465
assign 1 126 466
add 1 126 466
assign 1 126 467
new 0 126 467
assign 1 126 468
hexNew 1 126 468
assign 1 126 469
new 0 126 469
assign 1 126 470
hexNew 1 126 470
assign 1 126 471
and 1 126 471
assign 1 126 472
add 1 126 472
setIntUnchecked 2 126 473
assign 1 127 474
new 0 127 474
assign 1 128 477
new 0 128 477
assign 1 128 478
hexNew 1 128 478
assign 1 128 479
lesser 1 128 484
assign 1 129 485
new 0 129 485
assign 1 129 486
hexNew 1 129 486
assign 1 129 487
new 0 129 487
assign 1 129 488
hexNew 1 129 488
assign 1 129 489
and 1 129 489
assign 1 129 490
new 0 129 490
assign 1 129 491
shiftRight 1 129 491
assign 1 129 492
add 1 129 492
setIntUnchecked 2 129 493
assign 1 130 494
new 0 130 494
assign 1 130 495
add 1 130 495
assign 1 130 496
new 0 130 496
assign 1 130 497
hexNew 1 130 497
assign 1 130 498
new 0 130 498
assign 1 130 499
hexNew 1 130 499
assign 1 130 500
and 1 130 500
assign 1 130 501
new 0 130 501
assign 1 130 502
shiftRight 1 130 502
assign 1 130 503
add 1 130 503
setIntUnchecked 2 130 504
assign 1 131 505
new 0 131 505
assign 1 131 506
add 1 131 506
assign 1 131 507
new 0 131 507
assign 1 131 508
hexNew 1 131 508
assign 1 131 509
new 0 131 509
assign 1 131 510
hexNew 1 131 510
assign 1 131 511
and 1 131 511
assign 1 131 512
add 1 131 512
setIntUnchecked 2 131 513
assign 1 132 514
new 0 132 514
assign 1 133 517
new 0 133 517
assign 1 133 518
hexNew 1 133 518
assign 1 133 519
lesserEquals 1 133 524
assign 1 134 525
new 0 134 525
assign 1 134 526
hexNew 1 134 526
assign 1 134 527
new 0 134 527
assign 1 134 528
hexNew 1 134 528
assign 1 134 529
and 1 134 529
assign 1 134 530
new 0 134 530
assign 1 134 531
shiftRight 1 134 531
assign 1 134 532
add 1 134 532
setIntUnchecked 2 134 533
assign 1 135 534
new 0 135 534
assign 1 135 535
add 1 135 535
assign 1 135 536
new 0 135 536
assign 1 135 537
hexNew 1 135 537
assign 1 135 538
new 0 135 538
assign 1 135 539
hexNew 1 135 539
assign 1 135 540
and 1 135 540
assign 1 135 541
new 0 135 541
assign 1 135 542
shiftRight 1 135 542
assign 1 135 543
add 1 135 543
setIntUnchecked 2 135 544
assign 1 136 545
new 0 136 545
assign 1 136 546
add 1 136 546
assign 1 136 547
new 0 136 547
assign 1 136 548
hexNew 1 136 548
assign 1 136 549
new 0 136 549
assign 1 136 550
hexNew 1 136 550
assign 1 136 551
and 1 136 551
assign 1 136 552
new 0 136 552
assign 1 136 553
shiftRight 1 136 553
assign 1 136 554
add 1 136 554
setIntUnchecked 2 136 555
assign 1 137 556
new 0 137 556
assign 1 137 557
add 1 137 557
assign 1 137 558
new 0 137 558
assign 1 137 559
hexNew 1 137 559
assign 1 137 560
new 0 137 560
assign 1 137 561
hexNew 1 137 561
assign 1 137 562
and 1 137 562
assign 1 137 563
add 1 137 563
setIntUnchecked 2 137 564
assign 1 138 565
new 0 138 565
assign 1 140 568
new 0 140 568
assign 1 143 574
new 0 143 574
assign 1 143 575
lesser 1 143 580
assign 1 144 581
new 0 144 581
assign 1 144 582
new 1 144 582
throw 1 144 583
assign 1 146 585
sizeGet 0 146 585
assign 1 146 586
add 1 146 586
sizeSet 1 146 587
assign 1 167 655
new 0 167 655
assign 1 168 656
new 0 168 656
assign 1 169 657
new 0 169 657
assign 1 171 658
new 0 171 658
assign 1 171 659
fromEscapesGet 0 171 659
assign 1 173 660
linkedListIteratorGet 0 173 660
assign 1 177 663
hasNextGet 0 177 663
assign 1 178 665
nextGet 0 178 665
assign 1 181 667
not 0 181 672
assign 1 181 673
equals 1 181 673
assign 1 0 675
assign 1 0 678
assign 1 0 682
assign 1 182 685
new 0 182 685
assign 1 183 686
extractString 0 183 686
handleString 1 183 687
assign 1 186 691
get 1 186 691
assign 1 187 692
def 1 187 697
addValue 1 188 698
assign 1 189 701
new 0 189 701
assign 1 189 702
begins 1 189 702
assign 1 190 704
jsonUcUnescape 1 190 704
assign 1 191 705
jsonUcGetAfterPart 1 191 705
assign 1 192 706
new 0 192 706
assign 1 193 707
def 1 193 712
assign 1 193 713
jsonUcIsPairEnd 1 193 713
assign 1 193 714
not 0 193 719
assign 1 0 720
assign 1 0 723
assign 1 0 727
assign 1 194 730
new 0 194 730
assign 1 194 731
new 1 194 731
throw 1 194 732
assign 1 195 735
undef 1 195 740
assign 1 196 741
jsonUcIsPairStart 1 196 741
assign 1 198 745
def 1 198 750
assign 1 0 751
assign 1 0 754
assign 1 0 758
assign 1 199 761
new 0 199 761
assign 1 199 762
new 1 199 762
throw 1 199 763
assign 1 202 766
jsonUcAppendValue 3 204 769
assign 1 205 770
assign 1 206 771
def 1 206 776
addValue 1 207 777
addValue 1 211 782
assign 1 213 785
new 0 213 785
assign 1 214 788
equals 1 214 788
assign 1 215 790
new 0 215 790
addValue 1 217 793
assign 1 222 799
equals 1 222 799
assign 1 0 801
assign 1 222 804
equals 1 222 804
assign 1 0 806
assign 1 0 809
assign 1 0 813
assign 1 222 816
equals 1 222 816
assign 1 0 818
assign 1 0 821
assign 1 0 825
assign 1 222 828
equals 1 222 828
assign 1 0 830
assign 1 0 833
assign 1 223 839
equals 1 223 839
assign 1 224 841
new 0 224 841
assign 1 225 844
equals 1 225 844
beginMap 0 226 846
assign 1 227 849
equals 1 227 849
endMap 0 228 851
assign 1 229 854
equals 1 229 854
kvMid 0 230 856
assign 1 231 859
equals 1 231 859
beginList 0 232 861
assign 1 233 864
equals 1 233 864
endList 0 234 866
assign 1 238 869
new 0 238 869
assign 1 238 870
equals 1 238 870
assign 1 0 872
assign 1 238 875
new 0 238 875
assign 1 238 876
equals 1 238 876
assign 1 0 878
assign 1 0 881
assign 1 0 885
assign 1 238 888
new 0 238 888
assign 1 238 889
equals 1 238 889
assign 1 0 891
assign 1 0 894
assign 1 0 898
assign 1 238 901
new 0 238 901
assign 1 238 902
equals 1 238 902
assign 1 0 904
assign 1 0 907
assign 1 241 913
new 0 241 913
assign 1 241 914
equals 1 241 914
handleTrue 0 242 916
assign 1 243 919
new 0 243 919
assign 1 243 920
equals 1 243 920
handleFalse 0 244 922
assign 1 245 925
new 0 245 925
assign 1 245 926
equals 1 245 926
handleNull 0 246 928
assign 1 249 931
new 1 249 931
handleInteger 1 249 932
return 1 0 953
return 1 0 956
assign 1 0 959
assign 1 0 963
return 1 0 967
return 1 0 970
assign 1 0 973
assign 1 0 977
return 1 0 981
return 1 0 984
assign 1 0 987
assign 1 0 991
return 1 0 995
return 1 0 998
assign 1 0 1001
assign 1 0 1005
return 1 0 1009
return 1 0 1012
assign 1 0 1015
assign 1 0 1019
return 1 0 1023
return 1 0 1026
assign 1 0 1029
assign 1 0 1033
return 1 0 1037
return 1 0 1040
assign 1 0 1043
assign 1 0 1047
return 1 0 1051
return 1 0 1054
assign 1 0 1057
assign 1 0 1061
return 1 0 1065
return 1 0 1068
assign 1 0 1071
assign 1 0 1075
return 1 0 1079
return 1 0 1082
assign 1 0 1085
assign 1 0 1089
return 1 0 1093
return 1 0 1096
assign 1 0 1099
assign 1 0 1103
return 1 0 1107
return 1 0 1110
assign 1 0 1113
assign 1 0 1117
return 1 0 1121
return 1 0 1124
assign 1 0 1127
assign 1 0 1131
return 1 0 1135
return 1 0 1138
assign 1 0 1141
assign 1 0 1145
return 1 0 1149
return 1 0 1152
assign 1 0 1155
assign 1 0 1159
return 1 0 1163
return 1 0 1166
assign 1 0 1169
assign 1 0 1173
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -912150373: return bem_crGet_0();
case 390696222: return bem_colonGetDirect_0();
case 1215735159: return bem_classNameGet_0();
case -381491321: return bem_colonGet_0();
case 1919080617: return bem_lfGetDirect_0();
case 593040571: return bem_vsubGet_0();
case 1129503343: return bem_once_0();
case -1167767903: return bem_escapeGet_0();
case -1553474845: return bem_hsubGetDirect_0();
case 454049303: return bem_lbracketGetDirect_0();
case -1677419910: return bem_create_0();
case 1691508581: return bem_hmAddGetDirect_0();
case -1437550559: return bem_serializeContents_0();
case 1709585122: return bem_rbracketGetDirect_0();
case -590105018: return bem_commaGet_0();
case -348372876: return bem_spaceGet_0();
case -284999675: return bem_toAny_0();
case -1605431584: return bem_tagGet_0();
case 1728242130: return bem_vsubGetDirect_0();
case -1110913183: return bem_hsubGet_0();
case 416556147: return bem_quoteGet_0();
case 602938551: return bem_lbraceGet_0();
case -429437759: return bem_sourceFileNameGet_0();
case -2069102102: return bem_toString_0();
case -217654194: return bem_spaceGetDirect_0();
case -1232907801: return bem_iteratorGet_0();
case -1511007591: return bem_crGetDirect_0();
case 1029860087: return bem_fieldNamesGet_0();
case 1649954317: return bem_serializeToString_0();
case -1257779059: return bem_lbracketGet_0();
case -610676542: return bem_lfGet_0();
case -1908634330: return bem_tokerGet_0();
case 321704245: return bem_print_0();
case -1054666519: return bem_rbraceGetDirect_0();
case 2117639469: return bem_echo_0();
case -1561145816: return bem_hashGet_0();
case 602097122: return bem_deserializeClassNameGet_0();
case -2027877619: return bem_escapeGetDirect_0();
case 444831026: return bem_serializationIteratorGet_0();
case -1055677288: return bem_fieldIteratorGet_0();
case 57159682: return bem_new_0();
case 1644000934: return bem_copy_0();
case 1974245590: return bem_quoteGetDirect_0();
case 1358495809: return bem_rbracketGet_0();
case -534433092: return bem_rbraceGet_0();
case 863724044: return bem_commaGetDirect_0();
case -1068688537: return bem_tokerGetDirect_0();
case 798031389: return bem_hmAddGet_0();
case -882954893: return bem_tokensGetDirect_0();
case 55315205: return bem_many_0();
case 464334331: return bem_tokensGet_0();
case 5441690: return bem_lbraceGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1668055080: return bem_crSetDirect_1(bevd_0);
case -756536057: return bem_otherClass_1(bevd_0);
case 459332109: return bem_hmAddSetDirect_1(bevd_0);
case -740299402: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1172166477: return bem_escapeSetDirect_1(bevd_0);
case -97426471: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1719096215: return bem_defined_1(bevd_0);
case -1201408540: return bem_hmAddSet_1(bevd_0);
case -1292424603: return bem_spaceSet_1(bevd_0);
case 287377774: return bem_vsubSetDirect_1(bevd_0);
case -524359952: return bem_lbracketSetDirect_1(bevd_0);
case -210114742: return bem_spaceSetDirect_1(bevd_0);
case 2048540690: return bem_quoteSet_1(bevd_0);
case 751821765: return bem_commaSet_1(bevd_0);
case 940565325: return bem_rbraceSet_1(bevd_0);
case -1371671937: return bem_undefined_1(bevd_0);
case 861942002: return bem_escapeSet_1(bevd_0);
case 1521573585: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1411589126: return bem_colonSet_1(bevd_0);
case 1602696702: return bem_equals_1(bevd_0);
case 318075003: return bem_lbraceSetDirect_1(bevd_0);
case 1178220548: return bem_sameType_1(bevd_0);
case 650080222: return bem_notEquals_1(bevd_0);
case -1726084985: return bem_lfSetDirect_1(bevd_0);
case 562253725: return bem_vsubSet_1(bevd_0);
case -68313974: return bem_rbraceSetDirect_1(bevd_0);
case -15022096: return bem_colonSetDirect_1(bevd_0);
case 183434496: return bem_quoteSetDirect_1(bevd_0);
case -60277608: return bem_hsubSet_1(bevd_0);
case -1703979267: return bem_jsonUcIsPairStart_1((BEC_2_4_3_MathInt) bevd_0);
case 230597950: return bem_hsubSetDirect_1(bevd_0);
case -966099397: return bem_tokensSet_1(bevd_0);
case 1366553936: return bem_undef_1(bevd_0);
case -1988005274: return bem_sameObject_1(bevd_0);
case -1083402512: return bem_jsonUcUnescape_1((BEC_2_4_6_TextString) bevd_0);
case -1129239366: return bem_tokerSetDirect_1(bevd_0);
case -481996515: return bem_jsonUcIsPairEnd_1((BEC_2_4_3_MathInt) bevd_0);
case -962669917: return bem_otherType_1(bevd_0);
case 391193293: return bem_jsonUcGetAfterPart_1((BEC_2_4_6_TextString) bevd_0);
case 208310867: return bem_def_1(bevd_0);
case 770031074: return bem_rbracketSetDirect_1(bevd_0);
case 499648938: return bem_rbracketSet_1(bevd_0);
case 1606578014: return bem_lfSet_1(bevd_0);
case 207788966: return bem_commaSetDirect_1(bevd_0);
case -1422291148: return bem_sameClass_1(bevd_0);
case 1099109363: return bem_lbraceSet_1(bevd_0);
case -1519613163: return bem_tokerSet_1(bevd_0);
case 493426545: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1551969328: return bem_crSet_1(bevd_0);
case 1484718882: return bem_copyTo_1(bevd_0);
case 1785349240: return bem_tokensSetDirect_1(bevd_0);
case 1582166154: return bem_lbracketSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2139964622: return bem_parse_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1959141176: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1950811501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 36705687: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1883330128: return bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevd_0, bevd_1);
case 220358760: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -533377424: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -12510800: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281973651: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 994762794: return bem_jsonUcAppendValue_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_JsonParser_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_6_JsonParser_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_JsonParser();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst = (BEC_2_4_6_JsonParser) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_type;
}
}
