package be;
public class BET_2_4_3_MathInt extends BETS_Object {
public BET_2_4_3_MathInt() {String[] bevs_mtnames = new String[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "vintGet_0", "vintSet_0", "new_1", "hexNew_1", "setStringValueDec_1", "setStringValueHex_1", "setStringValue_2", "setStringValue_5", "toFloat_0", "toHexString_0", "toHexString_1", "toString_2", "toString_3", "toString_4", "abs_0", "absValue_0", "setValue_1", "increment_0", "decrement_0", "incrementValue_0", "decrementValue_0", "add_1", "addValue_1", "subtract_1", "subtractValue_1", "multiply_1", "multiplyValue_1", "divide_1", "divideValue_1", "modulus_1", "modulusValue_1", "and_1", "andValue_1", "or_1", "orValue_1", "shiftLeft_1", "shiftLeftValue_1", "shiftRight_1", "shiftRightValue_1", "power_1", "greater_1", "lesser_1", "greaterEquals_1", "lesserEquals_1" };
bems_buildMethodNames(bevs_mtnames);
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_3_MathInt();
}
}
