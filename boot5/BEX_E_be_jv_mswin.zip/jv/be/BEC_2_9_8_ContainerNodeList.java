package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 111};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 13
new 2 111 13
return 1 111 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 322973431: return bem_print_0();
case 2050059376: return bem_iteratorGet_0();
case -43502949: return bem_toAny_0();
case 1851036145: return bem_serializationIteratorGet_0();
case 177371817: return bem_firstNodeGet_0();
case 912963695: return bem_lengthGet_0();
case -304415890: return bem_classNameGet_0();
case 625547167: return bem_toString_0();
case 608365332: return bem_toList_0();
case 305613993: return bem_sourceFileNameGet_0();
case -1087766017: return bem_serializeToString_0();
case 196657943: return bem_linkedListIteratorGet_0();
case -410783155: return bem_new_0();
case -545885409: return bem_fieldNamesGet_0();
case -1760210664: return bem_thirdGet_0();
case -1569222986: return bem_fieldIteratorGet_0();
case 364235321: return bem_echo_0();
case 291309239: return bem_once_0();
case 2058205801: return bem_lastGet_0();
case -499653299: return bem_lastNodeGet_0();
case 601303681: return bem_isEmptyGet_0();
case -1077929313: return bem_reverse_0();
case -753644705: return bem_hashGet_0();
case 174003114: return bem_lastNodeGetDirect_0();
case 1461724031: return bem_copy_0();
case -2042759880: return bem_firstGet_0();
case -381740729: return bem_deserializeClassNameGet_0();
case -1966313462: return bem_sizeGet_0();
case -1124792932: return bem_secondGet_0();
case -1656415392: return bem_firstNodeGetDirect_0();
case -909675958: return bem_create_0();
case 210178980: return bem_toNodeList_0();
case -1101326644: return bem_serializeContents_0();
case 597357534: return bem_tagGet_0();
case 678571136: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 156921255: return bem_prependNode_1(bevd_0);
case -2015062465: return bem_addAll_1(bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1640366378: return bem_lastNodeSet_1(bevd_0);
case 1577651531: return bem_iterateAdd_1(bevd_0);
case -1772740187: return bem_firstNodeSet_1(bevd_0);
case 666382983: return bem_newNode_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
case 1017775604: return bem_lastNodeSetDirect_1(bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case -642381625: return bem_appendNode_1(bevd_0);
case 1462480730: return bem_addValueWhole_1(bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case 1272845686: return bem_deleteNode_1(bevd_0);
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case 1118660496: return bem_prepend_1(bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
case -1397525981: return bem_getNode_1(bevd_0);
case -1917328310: return bem_addValue_1(bevd_0);
case -949389725: return bem_def_1(bevd_0);
case -2016799259: return bem_firstNodeSetDirect_1(bevd_0);
case 1017771905: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case -1003319978: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 661143400: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -787170568: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -790272177: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
