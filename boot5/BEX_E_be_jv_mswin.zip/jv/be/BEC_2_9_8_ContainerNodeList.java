package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 111};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 13
new 2 111 13
return 1 111 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -443343999: return bem_create_0();
case 1288833861: return bem_toList_0();
case -1983878186: return bem_new_0();
case 13717429: return bem_toString_0();
case 1435982177: return bem_isEmptyGet_0();
case 667159469: return bem_serializationIteratorGet_0();
case -123880973: return bem_copy_0();
case 646757854: return bem_lastGet_0();
case 1438192594: return bem_hashGet_0();
case -39181575: return bem_toNodeList_0();
case 1291242400: return bem_secondGet_0();
case 1924411172: return bem_linkedListIteratorGet_0();
case -221627073: return bem_reverse_0();
case 173849741: return bem_thirdGet_0();
case 27645624: return bem_firstNodeGet_0();
case 1844906171: return bem_firstGet_0();
case 621334352: return bem_print_0();
case -1003281216: return bem_iteratorGet_0();
case -292196644: return bem_lengthGet_0();
case 777000236: return bem_sizeGet_0();
case -1353908081: return bem_lastNodeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1863369908: return bem_newNode_1(bevd_0);
case 301931194: return bem_equals_1(bevd_0);
case 1321677635: return bem_deleteNode_1(bevd_0);
case 1355165899: return bem_copyTo_1(bevd_0);
case 1395630298: return bem_getNode_1(bevd_0);
case -1103573037: return bem_prependNode_1(bevd_0);
case 987638933: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -1733390741: return bem_appendNode_1(bevd_0);
case 311997717: return bem_addAll_1(bevd_0);
case -582441351: return bem_prepend_1(bevd_0);
case 936205202: return bem_lastNodeSet_1(bevd_0);
case -1768460495: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -748311832: return bem_firstNodeSet_1(bevd_0);
case -182879054: return bem_notEquals_1(bevd_0);
case 667247388: return bem_addValue_1(bevd_0);
case -731871147: return bem_def_1(bevd_0);
case 1713177550: return bem_undef_1(bevd_0);
case -1950487742: return bem_iterateAdd_1(bevd_0);
case 2121815307: return bem_addValueWhole_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1548431016: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1473620469: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1808641530: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 507523868: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 1512652488: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1378156325: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 258338321: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
