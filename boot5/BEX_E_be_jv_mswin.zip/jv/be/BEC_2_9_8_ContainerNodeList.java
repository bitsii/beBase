package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 111};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 13
new 2 111 13
return 1 111 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -911129421: return bem_isEmptyGet_0();
case 1421774947: return bem_lastNodeGet_0();
case -1866304842: return bem_new_0();
case 2066914062: return bem_thirdGet_0();
case -719941460: return bem_reverse_0();
case -1952530647: return bem_toString_0();
case 226618720: return bem_hashGet_0();
case -1624686425: return bem_secondGet_0();
case 2147003360: return bem_print_0();
case 736240919: return bem_firstNodeGet_0();
case 895375346: return bem_firstGet_0();
case 1400136568: return bem_copy_0();
case 648763997: return bem_sizeGet_0();
case -1490764113: return bem_lastGet_0();
case 1674646972: return bem_toNodeList_0();
case 1796357934: return bem_lengthGet_0();
case 1044896916: return bem_toList_0();
case -346318217: return bem_create_0();
case -1636292534: return bem_iteratorGet_0();
case -704371796: return bem_linkedListIteratorGet_0();
case -1335055614: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -341434884: return bem_lastNodeSet_1(bevd_0);
case -919886868: return bem_addValue_1(bevd_0);
case 1009273818: return bem_prependNode_1(bevd_0);
case -86391126: return bem_addAll_1(bevd_0);
case -433687948: return bem_appendNode_1(bevd_0);
case -1233774166: return bem_addValueWhole_1(bevd_0);
case -1275902572: return bem_undef_1(bevd_0);
case 934430182: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -2120924129: return bem_prepend_1(bevd_0);
case 1645721140: return bem_copyTo_1(bevd_0);
case -922068768: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1904507888: return bem_equals_1(bevd_0);
case -1586825540: return bem_notEquals_1(bevd_0);
case -873158320: return bem_firstNodeSet_1(bevd_0);
case 1840089469: return bem_deleteNode_1(bevd_0);
case -2039582145: return bem_def_1(bevd_0);
case 1142132234: return bem_newNode_1(bevd_0);
case -560923983: return bem_iterateAdd_1(bevd_0);
case -1248782336: return bem_getNode_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 902461176: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1213004425: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1122392643: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -1557979950: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 448764511: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 184191830: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1382381566: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
