package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {112, 112};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 112 13
new 2 112 13
return 1 112 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 621958373: return bem_reverse_0();
case 371307175: return bem_sizeGet_0();
case 1891870089: return bem_print_0();
case -479209354: return bem_hashGet_0();
case -2026346603: return bem_new_0();
case 269301519: return bem_once_0();
case -1592226545: return bem_thirdGet_0();
case -415539380: return bem_many_0();
case 1663979256: return bem_iteratorGet_0();
case -1255628091: return bem_tagGet_0();
case -948023836: return bem_linkedListIteratorGet_0();
case 1630221053: return bem_toList_0();
case -1327723046: return bem_firstNodeGet_0();
case 232635975: return bem_lastNodeGet_0();
case -1084760201: return bem_create_0();
case -1531622162: return bem_copy_0();
case -127984856: return bem_deserializeClassNameGet_0();
case 1964378555: return bem_serializeContents_0();
case 1092154910: return bem_classNameGet_0();
case -2092271774: return bem_echo_0();
case -1179861088: return bem_toNodeList_0();
case 102887971: return bem_fieldIteratorGet_0();
case 2115120452: return bem_serializeToString_0();
case -1369717221: return bem_lastGet_0();
case -1289266065: return bem_lengthGet_0();
case -1213461398: return bem_secondGet_0();
case 1670566168: return bem_sourceFileNameGet_0();
case -333394073: return bem_toString_0();
case 75621306: return bem_isEmptyGet_0();
case 1154933275: return bem_serializationIteratorGet_0();
case -742572283: return bem_firstGet_0();
case -911546686: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1574704139: return bem_copyTo_1(bevd_0);
case -91281186: return bem_undef_1(bevd_0);
case 849908456: return bem_lastNodeSet_1(bevd_0);
case -2088579865: return bem_otherType_1(bevd_0);
case 308292842: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1708030692: return bem_newNode_1(bevd_0);
case 1801626709: return bem_prependNode_1(bevd_0);
case 1060708615: return bem_iterateAdd_1(bevd_0);
case -605366432: return bem_defined_1(bevd_0);
case 1851307565: return bem_firstNodeSet_1(bevd_0);
case 1077702335: return bem_equals_1(bevd_0);
case 1674374988: return bem_sameObject_1(bevd_0);
case 2091571164: return bem_appendNode_1(bevd_0);
case -2109819584: return bem_def_1(bevd_0);
case 785374218: return bem_addAll_1(bevd_0);
case -1338872801: return bem_deleteNode_1(bevd_0);
case -2027519443: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 8626873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -266225430: return bem_notEquals_1(bevd_0);
case 372613641: return bem_addValue_1(bevd_0);
case -289607630: return bem_getNode_1(bevd_0);
case 318302385: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 341131872: return bem_prepend_1(bevd_0);
case -1020405356: return bem_otherClass_1(bevd_0);
case -2035847518: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1139979118: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1900969499: return bem_addValueWhole_1(bevd_0);
case 1980041008: return bem_undefined_1(bevd_0);
case -326579864: return bem_sameClass_1(bevd_0);
case -834006616: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 926020368: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1730689464: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -1571889490: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -730327046: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1465376314: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1129799281: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -783330142: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1456214761: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743986647: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220078438: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
