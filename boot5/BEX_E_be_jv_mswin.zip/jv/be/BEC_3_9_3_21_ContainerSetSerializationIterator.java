package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerSetSerializationIterator extends BEC_3_9_3_11_ContainerSetKeyIterator {
public BEC_3_9_3_21_ContainerSetSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_21_ContainerSetSerializationIterator bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst;

public static BET_3_9_3_21_ContainerSetSerializationIterator bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_contents;
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_contents = (new BEC_2_9_4_ContainerList()).bem_new_0();
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 508*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 508*/ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 508*/
 else /* Line: 508*/ {
break;
} /* Line: 508*/
} /* Line: 508*/
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_postDeserialize_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_0_ta_loop = bevp_contents.bem_iteratorGet_0();
while (true)
/* Line: 514*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 514*/ {
bevl_value = bevt_0_ta_loop.bemd_0(1149836311);
bevp_set.bem_put_1(bevl_value);
} /* Line: 515*/
 else /* Line: 514*/ {
break;
} /* Line: 514*/
} /* Line: 514*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {498, 500, 504, 508, 508, 508, 509, 508, 514, 0, 514, 514, 515, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 24, 27, 32, 33, 34, 46, 46, 49, 51, 52, 61, 64};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 498 13
new 0 498 13
new 1 500 14
addValue 1 504 18
assign 1 508 24
new 0 508 24
assign 1 508 27
lesser 1 508 32
nextSet 1 509 33
assign 1 508 34
increment 0 508 34
assign 1 514 46
iteratorGet 0 0 46
assign 1 514 49
hasNextGet 0 514 49
assign 1 514 51
nextGet 0 514 51
put 1 515 52
return 1 0 61
assign 1 0 64
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1614601099: return bem_delete_0();
case 1156525638: return bem_nodeIteratorIteratorGet_0();
case -174956569: return bem_hasNextGet_0();
case -159849764: return bem_hashGet_0();
case 1149836311: return bem_nextGet_0();
case 324521155: return bem_create_0();
case -82017130: return bem_toString_0();
case 1999259287: return bem_contentsGet_0();
case 1140404476: return bem_iteratorGet_0();
case 153130764: return bem_print_0();
case 416881831: return bem_copy_0();
case 304683696: return bem_containerGet_0();
case -187492472: return bem_new_0();
case -1083898602: return bem_postDeserialize_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1208214563: return bem_nextSet_1(bevd_0);
case -850371892: return bem_notEquals_1(bevd_0);
case 1503120614: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2008583708: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -559238061: return bem_equals_1(bevd_0);
case -1891533263: return bem_contentsSet_1(bevd_0);
case 1267419746: return bem_def_1(bevd_0);
case -393105689: return bem_undef_1(bevd_0);
case 1336352814: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2109827654: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1822328732: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 347449110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -911952501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_21_ContainerSetSerializationIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerSetSerializationIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_type;
}
}
