package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_16_SystemExceptionBuilder extends BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
public static BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;

public static BET_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;

public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_thing;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public BEC_2_6_16_SystemExceptionBuilder bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() throws Throwable {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) throws Throwable {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_klass == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
if (beva_eline == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 170*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 170*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(-1));
return bevt_3_ta_ph;
} /* Line: 172*/
bevl_line = (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toJvString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_ex == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 206*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_6_16_SystemExceptionBuilder_bels_0));
bevt_1_ta_ph.bem_print_0();
} /* Line: 207*/
 else /* Line: 208*/ {
try /* Line: 209*/ {
beva_ex.bemd_0(-419834598);
} /* Line: 210*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_6_16_SystemExceptionBuilder_bels_1));
bevt_2_ta_ph.bem_print_0();
} /* Line: 212*/
} /* Line: 211*/
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_6_16_SystemExceptionBuilder_bels_0));
bevt_1_ta_ph.bem_print_0();
} /* Line: 220*/
 else /* Line: 221*/ {
try /* Line: 222*/ {
} /* Line: 222*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_6_16_SystemExceptionBuilder_bels_1));
bevt_2_ta_ph.bem_print_0();
} /* Line: 225*/
} /* Line: 224*/
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_passBack == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 231*/ {
bevt_2_ta_ph = beva_passBack.bemd_1(574822957, bevp_except);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 231*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 231*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 231*/
 else /* Line: 231*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 231*/ {
beva_passBack.bemd_1(97024700, beva_sinClass);
beva_passBack.bemd_1(1451290722, beva_sinMtd);
beva_passBack.bemd_1(-2040022422, beva_sfname);
beva_passBack.bemd_1(346672714, beva_ilinep);
} /* Line: 235*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() throws Throwable {
return bevp_except;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_exceptGetDirect_0() throws Throwable {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_except = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_except = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGet_0() throws Throwable {
return bevp_thing;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_thingGetDirect_0() throws Throwable {
return bevp_thing;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_thing = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_thing = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_lastStrGetDirect_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastStr = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_lastStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastStr = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {160, 161, 162, 170, 170, 0, 170, 170, 0, 0, 172, 172, 175, 201, 206, 206, 207, 207, 210, 212, 212, 218, 219, 219, 220, 220, 225, 225, 231, 231, 231, 0, 0, 0, 232, 233, 234, 235, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 32, 37, 38, 41, 46, 47, 50, 54, 55, 57, 62, 69, 74, 75, 76, 80, 84, 85, 95, 96, 101, 102, 103, 110, 111, 120, 125, 126, 128, 131, 135, 138, 139, 140, 141, 146, 149, 152, 156, 160, 163, 166, 170, 174, 177, 180, 184, 188, 191, 194, 198};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 160 21
new 0 160 21
assign 1 161 22
new 0 161 22
assign 1 162 23
new 0 162 23
assign 1 170 32
undef 1 170 37
assign 1 0 38
assign 1 170 41
undef 1 170 46
assign 1 0 47
assign 1 0 50
assign 1 172 54
new 0 172 54
return 1 172 55
assign 1 175 57
new 0 175 57
return 1 201 62
assign 1 206 69
undef 1 206 74
assign 1 207 75
new 0 207 75
print 0 207 76
print 0 210 80
assign 1 212 84
new 0 212 84
print 0 212 85
assign 1 218 95
assign 1 219 96
undef 1 219 101
assign 1 220 102
new 0 220 102
print 0 220 103
assign 1 225 110
new 0 225 110
print 0 225 111
assign 1 231 120
def 1 231 125
assign 1 231 126
sameType 1 231 126
assign 1 0 128
assign 1 0 131
assign 1 0 135
klassNameSet 1 232 138
methodNameSet 1 233 139
fileNameSet 1 234 140
lineNumberSet 1 235 141
return 1 0 146
return 1 0 149
assign 1 0 152
assign 1 0 156
return 1 0 160
return 1 0 163
assign 1 0 166
assign 1 0 170
return 1 0 174
return 1 0 177
assign 1 0 180
assign 1 0 184
return 1 0 188
return 1 0 191
assign 1 0 194
assign 1 0 198
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -214646378: return bem_intGet_0();
case -437991849: return bem_toString_0();
case -1350802630: return bem_default_0();
case 881754957: return bem_deserializeClassNameGet_0();
case -763928014: return bem_create_0();
case -829315536: return bem_classNameGet_0();
case 2087607686: return bem_iteratorGet_0();
case -1665544297: return bem_thingGetDirect_0();
case -1111250456: return bem_fieldNamesGet_0();
case -674491561: return bem_sourceFileNameGet_0();
case 1126911928: return bem_serializeContents_0();
case -568575955: return bem_hashGet_0();
case -2057480168: return bem_lastStrGetDirect_0();
case -360776367: return bem_exceptGetDirect_0();
case -1814783732: return bem_serializationIteratorGet_0();
case 712728827: return bem_lastStrGet_0();
case -1454950260: return bem_fieldIteratorGet_0();
case -220602072: return bem_echo_0();
case 1087832621: return bem_tagGet_0();
case 234248288: return bem_copy_0();
case 1779311472: return bem_exceptGet_0();
case -419834598: return bem_print_0();
case -18123974: return bem_new_0();
case 931701808: return bem_intGetDirect_0();
case -1759974073: return bem_thingGet_0();
case 774721401: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -643713889: return bem_notEquals_1(bevd_0);
case -2029512726: return bem_printException_1(bevd_0);
case 1241942215: return bem_exceptSet_1(bevd_0);
case -526197609: return bem_lastStrSetDirect_1(bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case 746797787: return bem_sendToConsole_1(bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1579452404: return bem_thingSet_1(bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case -1093492967: return bem_lastStrSet_1(bevd_0);
case 742528873: return bem_exceptSetDirect_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
case -1854341514: return bem_intSetDirect_1(bevd_0);
case 1509457052: return bem_intSet_1(bevd_0);
case 109139375: return bem_thingSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1807191443: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) throws Throwable {
switch (callId) {
case -1817082923: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return super.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;
}
}
