package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_16_SystemExceptionBuilder extends BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_0, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_1, 25));
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_0, 51));
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_1, 25));
public static BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;

public static BET_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;

public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_thing;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public BEC_2_6_16_SystemExceptionBuilder bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() throws Throwable {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) throws Throwable {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 421 */ {
if (beva_eline == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 421 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 421 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 421 */ {
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
return bevt_3_tmpany_phold;
} /* Line: 423 */
bevl_line = (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toJvString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 458 */
 else  /* Line: 459 */ {
try  /* Line: 460 */ {
beva_ex.bemd_0(908678857);
} /* Line: 461 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 463 */
} /* Line: 462 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 471 */
 else  /* Line: 472 */ {
try  /* Line: 473 */ {
} /* Line: 473 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 476 */
} /* Line: 475 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_passBack == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_2_tmpany_phold = beva_passBack.bemd_1(-359346681, bevp_except);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 482 */
 else  /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 482 */ {
beva_passBack.bemd_1(1042850016, beva_sinClass);
beva_passBack.bemd_1(-507248545, beva_sinMtd);
beva_passBack.bemd_1(861474267, beva_sfname);
beva_passBack.bemd_1(-616064381, beva_ilinep);
} /* Line: 486 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() throws Throwable {
return bevp_except;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_exceptGetDirect_0() throws Throwable {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGet_0() throws Throwable {
return bevp_thing;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_thingGetDirect_0() throws Throwable {
return bevp_thing;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_lastStrGetDirect_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_lastStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {411, 412, 413, 421, 421, 0, 421, 421, 0, 0, 423, 423, 426, 452, 457, 457, 458, 458, 461, 463, 463, 469, 470, 470, 471, 471, 476, 476, 482, 482, 482, 0, 0, 0, 483, 484, 485, 486, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 36, 41, 42, 45, 50, 51, 54, 58, 59, 61, 66, 73, 78, 79, 80, 84, 88, 89, 99, 100, 105, 106, 107, 114, 115, 124, 129, 130, 132, 135, 139, 142, 143, 144, 145, 150, 153, 156, 160, 164, 167, 170, 174, 178, 181, 184, 188, 192, 195, 198, 202};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 411 25
new 0 411 25
assign 1 412 26
new 0 412 26
assign 1 413 27
new 0 413 27
assign 1 421 36
undef 1 421 41
assign 1 0 42
assign 1 421 45
undef 1 421 50
assign 1 0 51
assign 1 0 54
assign 1 423 58
new 0 423 58
return 1 423 59
assign 1 426 61
new 0 426 61
return 1 452 66
assign 1 457 73
undef 1 457 78
assign 1 458 79
new 0 458 79
print 0 458 80
print 0 461 84
assign 1 463 88
new 0 463 88
print 0 463 89
assign 1 469 99
assign 1 470 100
undef 1 470 105
assign 1 471 106
new 0 471 106
print 0 471 107
assign 1 476 114
new 0 476 114
print 0 476 115
assign 1 482 124
def 1 482 129
assign 1 482 130
sameType 1 482 130
assign 1 0 132
assign 1 0 135
assign 1 0 139
klassNameSet 1 483 142
methodNameSet 1 484 143
fileNameSet 1 485 144
lineNumberSet 1 486 145
return 1 0 150
return 1 0 153
assign 1 0 156
assign 1 0 160
return 1 0 164
return 1 0 167
assign 1 0 170
assign 1 0 174
return 1 0 178
return 1 0 181
assign 1 0 184
assign 1 0 188
return 1 0 192
return 1 0 195
assign 1 0 198
assign 1 0 202
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -653750385: return bem_create_0();
case -124285366: return bem_once_0();
case 408062149: return bem_exceptGet_0();
case 1280117216: return bem_lastStrGetDirect_0();
case -885910917: return bem_default_0();
case -634018133: return bem_tagGet_0();
case 278062549: return bem_intGet_0();
case 148544119: return bem_toString_0();
case -1092510954: return bem_copy_0();
case 971841201: return bem_fieldIteratorGet_0();
case 2146604653: return bem_new_0();
case -2007275567: return bem_many_0();
case 393738758: return bem_serializeToString_0();
case -1750720088: return bem_hashGet_0();
case 2144693643: return bem_deserializeClassNameGet_0();
case -212742483: return bem_echo_0();
case 908678857: return bem_print_0();
case 926866514: return bem_thingGet_0();
case -331249480: return bem_exceptGetDirect_0();
case -881577546: return bem_classNameGet_0();
case -860516521: return bem_intGetDirect_0();
case 1782351683: return bem_serializeContents_0();
case -224465120: return bem_sourceFileNameGet_0();
case 1099447992: return bem_fieldNamesGet_0();
case 520197473: return bem_thingGetDirect_0();
case 569361306: return bem_iteratorGet_0();
case 641839943: return bem_toAny_0();
case 2029660839: return bem_lastStrGet_0();
case -2031839191: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -858134310: return bem_lastStrSetDirect_1(bevd_0);
case 1703616583: return bem_notEquals_1(bevd_0);
case -1654341419: return bem_exceptSetDirect_1(bevd_0);
case -126861997: return bem_printException_1(bevd_0);
case -872115670: return bem_defined_1(bevd_0);
case -1685417303: return bem_exceptSet_1(bevd_0);
case -1928510621: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1728521987: return bem_thingSetDirect_1(bevd_0);
case -715506468: return bem_intSetDirect_1(bevd_0);
case -249326151: return bem_copyTo_1(bevd_0);
case 1367146792: return bem_sameClass_1(bevd_0);
case -1875581515: return bem_lastStrSet_1(bevd_0);
case -1699012269: return bem_sendToConsole_1(bevd_0);
case 398142766: return bem_thingSet_1(bevd_0);
case 326949551: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1730397553: return bem_undef_1(bevd_0);
case -1442919124: return bem_intSet_1(bevd_0);
case -884607798: return bem_def_1(bevd_0);
case -359346681: return bem_sameType_1(bevd_0);
case 1446250233: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1236734559: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 389340449: return bem_otherType_1(bevd_0);
case -1586811529: return bem_undefined_1(bevd_0);
case -1565662060: return bem_sameObject_1(bevd_0);
case -1519516879: return bem_equals_1(bevd_0);
case -448360789: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 29395685: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -223815238: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 827793836: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1899980628: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1061986002: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1194360433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -454033656: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 696322560: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) throws Throwable {
switch (callId) {
case 411590506: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return super.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;
}
}
