package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_5_LogicBools extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_LogicBools() { }
private static byte[] becc_BEC_2_5_5_LogicBools_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] becc_BEC_2_5_5_LogicBools_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_1 = {0x31};
public static BEC_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_inst;

public static BET_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_type;

public BEC_2_5_5_LogicBools bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_5_LogicBools bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_fromString_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 113*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_2_ta_ph = beva_str.bemd_1(1684495724, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 113*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 113*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 113*/
 else /* Line: 113*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 113*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 114*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_LogicBools_bels_1));
bevt_0_ta_ph = beva_str.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 120*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 121*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {113, 113, 113, 113, 0, 0, 0, 114, 114, 116, 116, 120, 120, 121, 121, 123, 123};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 31, 32, 33, 35, 38, 42, 45, 46, 48, 49, 56, 57, 59, 60, 62, 63};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 113 26
def 1 113 31
assign 1 113 32
new 0 113 32
assign 1 113 33
equals 1 113 33
assign 1 0 35
assign 1 0 38
assign 1 0 42
assign 1 114 45
new 0 114 45
return 1 114 46
assign 1 116 48
new 0 116 48
return 1 116 49
assign 1 120 56
new 0 120 56
assign 1 120 57
equals 1 120 57
assign 1 121 59
new 0 121 59
return 1 121 60
assign 1 123 62
new 0 123 62
return 1 123 63
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1646234581: return bem_toString_0();
case -612513485: return bem_iteratorGet_0();
case 1958005956: return bem_create_0();
case 1907231669: return bem_copy_0();
case 194410309: return bem_new_0();
case 1394643411: return bem_hashGet_0();
case -105274279: return bem_default_0();
case 809264885: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1987652456: return bem_undef_1(bevd_0);
case 933043830: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 188874323: return bem_fromString_1(bevd_0);
case -428246641: return bem_copyTo_1(bevd_0);
case -261357173: return bem_print_1(bevd_0);
case 1684495724: return bem_equals_1(bevd_0);
case 1629594916: return bem_notEquals_1(bevd_0);
case 18789665: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -742465129: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 485507476: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1409585564: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1654953222: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_LogicBools_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_5_LogicBools_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_LogicBools();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst = (BEC_2_5_5_LogicBools) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_type;
}
}
