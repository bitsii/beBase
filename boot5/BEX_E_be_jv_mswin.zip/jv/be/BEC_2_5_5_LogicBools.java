package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_5_LogicBools extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_LogicBools() { }
private static byte[] becc_BEC_2_5_5_LogicBools_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] becc_BEC_2_5_5_LogicBools_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_2 = {0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_LogicBools_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_LogicBools_bels_2, 1));
public static BEC_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_inst;

public static BET_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_type;

public BEC_2_5_5_LogicBools bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_5_LogicBools bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_forString_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(1077702335, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 115 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 116 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_fromString_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 122 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(1077702335, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 122 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 122 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 122 */
 else  /* Line: 122 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 122 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 123 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_5_LogicBools_bevo_0;
bevt_0_tmpany_phold = beva_str.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 130 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {115, 115, 116, 116, 118, 118, 122, 122, 122, 122, 0, 0, 0, 123, 123, 125, 125, 129, 129, 130, 130, 132, 132};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 29, 30, 32, 33, 42, 47, 48, 49, 51, 54, 58, 61, 62, 64, 65, 72, 73, 75, 76, 78, 79};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 115 26
new 0 115 26
assign 1 115 27
equals 1 115 27
assign 1 116 29
new 0 116 29
return 1 116 30
assign 1 118 32
new 0 118 32
return 1 118 33
assign 1 122 42
def 1 122 47
assign 1 122 48
new 0 122 48
assign 1 122 49
equals 1 122 49
assign 1 0 51
assign 1 0 54
assign 1 0 58
assign 1 123 61
new 0 123 61
return 1 123 62
assign 1 125 64
new 0 125 64
return 1 125 65
assign 1 129 72
new 0 129 72
assign 1 129 73
equals 1 129 73
assign 1 130 75
new 0 130 75
return 1 130 76
assign 1 132 78
new 0 132 78
return 1 132 79
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1670566168: return bem_sourceFileNameGet_0();
case -127984856: return bem_deserializeClassNameGet_0();
case 1891870089: return bem_print_0();
case 2138920286: return bem_default_0();
case -1084760201: return bem_create_0();
case -1255628091: return bem_tagGet_0();
case -911546686: return bem_toAny_0();
case 1154933275: return bem_serializationIteratorGet_0();
case 1964378555: return bem_serializeContents_0();
case -415539380: return bem_many_0();
case 1092154910: return bem_classNameGet_0();
case -2026346603: return bem_new_0();
case 269301519: return bem_once_0();
case -1531622162: return bem_copy_0();
case -479209354: return bem_hashGet_0();
case -2092271774: return bem_echo_0();
case 102887971: return bem_fieldIteratorGet_0();
case 2115120452: return bem_serializeToString_0();
case -333394073: return bem_toString_0();
case 1663979256: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2027519443: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1139979118: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2088579865: return bem_otherType_1(bevd_0);
case 1674374988: return bem_sameObject_1(bevd_0);
case -326579864: return bem_sameClass_1(bevd_0);
case -1574704139: return bem_copyTo_1(bevd_0);
case -397316536: return bem_forString_1(bevd_0);
case 178368470: return bem_fromString_1(bevd_0);
case -266225430: return bem_notEquals_1(bevd_0);
case -1020405356: return bem_otherClass_1(bevd_0);
case -2035847518: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1077702335: return bem_equals_1(bevd_0);
case -605366432: return bem_defined_1(bevd_0);
case -834006616: return bem_sameType_1(bevd_0);
case -2109819584: return bem_def_1(bevd_0);
case 1980041008: return bem_undefined_1(bevd_0);
case 8626873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -91281186: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 926020368: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1571889490: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -730327046: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1129799281: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -783330142: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1456214761: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743986647: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_LogicBools_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_5_LogicBools_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_LogicBools();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst = (BEC_2_5_5_LogicBools) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_type;
}
}
