package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_5_LogicBools extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_LogicBools() { }
private static byte[] becc_BEC_2_5_5_LogicBools_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] becc_BEC_2_5_5_LogicBools_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_1 = {0x31};
public static BEC_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_inst;

public static BET_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_type;

public BEC_2_5_5_LogicBools bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_5_LogicBools bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_forString_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_0_ta_ph = beva_str.bemd_1(301931194, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 122*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 123*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_fromString_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 129*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_2_ta_ph = beva_str.bemd_1(301931194, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 129*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 129*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 129*/
 else /* Line: 129*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 129*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 130*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_LogicBools_bels_1));
bevt_0_ta_ph = beva_str.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 136*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 137*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isTrue_1(BEC_2_5_4_LogicBool beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
if (beva_val == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 143*/ {
if (beva_val.bevi_bool)/* Line: 143*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 143*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 143*/
 else /* Line: 143*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 143*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 144*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {122, 122, 123, 123, 125, 125, 129, 129, 129, 129, 0, 0, 0, 130, 130, 132, 132, 136, 136, 137, 137, 139, 139, 143, 143, 0, 0, 0, 144, 144, 146, 146};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 25, 27, 28, 30, 31, 40, 45, 46, 47, 49, 52, 56, 59, 60, 62, 63, 70, 71, 73, 74, 76, 77, 84, 89, 91, 94, 98, 101, 102, 104, 105};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 122 24
new 0 122 24
assign 1 122 25
equals 1 122 25
assign 1 123 27
new 0 123 27
return 1 123 28
assign 1 125 30
new 0 125 30
return 1 125 31
assign 1 129 40
def 1 129 45
assign 1 129 46
new 0 129 46
assign 1 129 47
equals 1 129 47
assign 1 0 49
assign 1 0 52
assign 1 0 56
assign 1 130 59
new 0 130 59
return 1 130 60
assign 1 132 62
new 0 132 62
return 1 132 63
assign 1 136 70
new 0 136 70
assign 1 136 71
equals 1 136 71
assign 1 137 73
new 0 137 73
return 1 137 74
assign 1 139 76
new 0 139 76
return 1 139 77
assign 1 143 84
def 1 143 89
assign 1 0 91
assign 1 0 94
assign 1 0 98
assign 1 144 101
new 0 144 101
return 1 144 102
assign 1 146 104
new 0 146 104
return 1 146 105
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 621334352: return bem_print_0();
case -443343999: return bem_create_0();
case -890155044: return bem_default_0();
case -123880973: return bem_copy_0();
case -1983878186: return bem_new_0();
case -1003281216: return bem_iteratorGet_0();
case 1438192594: return bem_hashGet_0();
case 13717429: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1512232493: return bem_fromString_1(bevd_0);
case 1989333195: return bem_forString_1(bevd_0);
case 301931194: return bem_equals_1(bevd_0);
case 164670301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -182879054: return bem_notEquals_1(bevd_0);
case 1713177550: return bem_undef_1(bevd_0);
case -731871147: return bem_def_1(bevd_0);
case -629061198: return bem_isTrue_1((BEC_2_5_4_LogicBool) bevd_0);
case 1355165899: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1548431016: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1473620469: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1808641530: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1378156325: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_LogicBools_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_5_LogicBools_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_LogicBools();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst = (BEC_2_5_5_LogicBools) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_type;
}
}
