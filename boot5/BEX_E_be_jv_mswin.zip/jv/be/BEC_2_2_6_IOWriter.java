package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOWriter extends BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOWriter() { }

   
    public java.io.OutputStream bevi_os;
    
   private static byte[] becc_BEC_2_2_6_IOWriter_clname = {0x49,0x4F,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_2_6_IOWriter bece_BEC_2_2_6_IOWriter_bevs_inst;

public static BET_2_2_6_IOWriter bece_BEC_2_2_6_IOWriter_bevs_type;

public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_2_6_IOWriter bem_new_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_vfileGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_extOpen_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_close_0() throws Throwable {

      if (this.bevi_os != null) {
        this.bevi_os.close();
        this.bevi_os = null;
      }
      bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_write_1(BEC_2_4_6_TextString beva_stri) throws Throwable {

      this.bevi_os.write(beva_stri.bevi_bytes, 0, beva_stri.bevp_length.bevi_int);
      return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_writeStringClose_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
bem_write_1(beva_stri);
bem_close_0();
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {528, 539, 586, 614, 615, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 28, 37, 46, 47, 51, 54};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 528 18
new 0 528 18
assign 1 539 28
new 0 539 28
assign 1 586 37
new 0 586 37
write 1 614 46
close 0 615 47
return 1 0 51
assign 1 0 54
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1045256597: return bem_new_0();
case 1389378690: return bem_iteratorGet_0();
case -767914345: return bem_vfileGet_0();
case -203029976: return bem_extOpen_0();
case -1225636174: return bem_toString_0();
case -308470073: return bem_hashGet_0();
case 1661802748: return bem_print_0();
case -355124364: return bem_create_0();
case 1304998376: return bem_isClosedGet_0();
case -681133198: return bem_close_0();
case 1375409336: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1410683219: return bem_notEquals_1(bevd_0);
case 504127526: return bem_vfileSet_1(bevd_0);
case -2119998280: return bem_undef_1(bevd_0);
case -14114992: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case 1024858296: return bem_copyTo_1(bevd_0);
case 308000695: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 207992556: return bem_def_1(bevd_0);
case 789789310: return bem_print_1(bevd_0);
case 145823261: return bem_equals_1(bevd_0);
case -1013074785: return bem_isClosedSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1648212160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 195884639: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1847574000: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 369351178: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOWriter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOWriter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_6_IOWriter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_inst = (BEC_2_2_6_IOWriter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_type;
}
}
