package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;

public static BET_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_0() throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bem_new_0();
bevp_lock.bem_lock_0();
try  /* Line: 1113 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1115 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1118 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_oGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1124 */ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 1126 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1129 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1136 */ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 1139 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1142 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
bevl_res = be.BECS_Runtime.boolFalse;
try  /* Line: 1150 */ {
if (bevp_obj == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1151 */ {
bevp_obj = beva__obj;
bevl_res = be.BECS_Runtime.boolTrue;
} /* Line: 1153 */
bevp_lock.bem_unlock_0();
} /* Line: 1155 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1158 */
return bevl_res;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1165 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1167 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1170 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_oGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_oSet_1(beva__obj);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objGet_0() throws Throwable {
return bevp_obj;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_objGetDirect_0() throws Throwable {
return bevp_obj;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_obj = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_objSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_obj = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1103, 1108, 1112, 1114, 1115, 1117, 1118, 1123, 1125, 1126, 1128, 1129, 1131, 1135, 1137, 1138, 1139, 1141, 1142, 1144, 1148, 1149, 1151, 1151, 1152, 1153, 1155, 1157, 1158, 1160, 1164, 1166, 1167, 1169, 1170, 1175, 1175, 1179, 1179, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 56, 60, 61, 63, 69, 70, 72, 77, 78, 79, 81, 85, 86, 88, 92, 94, 95, 99, 100, 106, 107, 111, 112, 115, 118, 121, 125, 129, 132, 135, 139};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1103 16
new 0 1103 16
new 0 1108 21
lock 0 1112 22
assign 1 1114 24
unlock 0 1115 25
unlock 0 1117 29
throw 1 1118 30
lock 0 1123 37
assign 1 1125 39
unlock 0 1126 40
unlock 0 1128 44
throw 1 1129 45
return 1 1131 47
lock 0 1135 52
assign 1 1137 54
assign 1 1138 55
unlock 0 1139 56
unlock 0 1141 60
throw 1 1142 61
return 1 1144 63
lock 0 1148 69
assign 1 1149 70
new 0 1149 70
assign 1 1151 72
undef 1 1151 77
assign 1 1152 78
assign 1 1153 79
new 0 1153 79
unlock 0 1155 81
unlock 0 1157 85
throw 1 1158 86
return 1 1160 88
lock 0 1164 92
assign 1 1166 94
unlock 0 1167 95
unlock 0 1169 99
throw 1 1170 100
assign 1 1175 106
oGet 0 1175 106
return 1 1175 107
assign 1 1179 111
oSet 1 1179 111
return 1 1179 112
return 1 0 115
return 1 0 118
assign 1 0 121
assign 1 0 125
return 1 0 129
return 1 0 132
assign 1 0 135
assign 1 0 139
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1019772752: return bem_getAndClear_0();
case 342683908: return bem_objGet_0();
case -1685245664: return bem_oGet_0();
case -1920210020: return bem_once_0();
case -670803938: return bem_sourceFileNameGet_0();
case -1768205182: return bem_serializationIteratorGet_0();
case 1993705736: return bem_serializeContents_0();
case -878171847: return bem_lockGet_0();
case -212193921: return bem_tagGet_0();
case -461072455: return bem_toString_0();
case -41333960: return bem_deserializeClassNameGet_0();
case 577093211: return bem_many_0();
case -2074204580: return bem_copy_0();
case -1425389541: return bem_new_0();
case 1821082307: return bem_print_0();
case -1103678979: return bem_lockGetDirect_0();
case -2107653327: return bem_fieldIteratorGet_0();
case -511250160: return bem_fieldNamesGet_0();
case -240515265: return bem_objectGet_0();
case 1800445194: return bem_create_0();
case -102149480: return bem_serializeToString_0();
case 296622746: return bem_classNameGet_0();
case -19384722: return bem_toAny_0();
case -2012967797: return bem_objGetDirect_0();
case 1482277663: return bem_echo_0();
case 361790008: return bem_hashGet_0();
case -314408008: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1389268037: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 726972503: return bem_new_1(bevd_0);
case -1567535449: return bem_sameObject_1(bevd_0);
case 764373340: return bem_copyTo_1(bevd_0);
case -1987055831: return bem_notEquals_1(bevd_0);
case -2110248602: return bem_undefined_1(bevd_0);
case -1192710672: return bem_equals_1(bevd_0);
case 499942082: return bem_lockSetDirect_1(bevd_0);
case 242004544: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1613190756: return bem_objSet_1(bevd_0);
case 1200424028: return bem_oSet_1(bevd_0);
case 211156446: return bem_objSetDirect_1(bevd_0);
case 219377084: return bem_lockSet_1(bevd_0);
case -676548815: return bem_undef_1(bevd_0);
case -155631619: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1026739914: return bem_defined_1(bevd_0);
case -1161197989: return bem_sameType_1(bevd_0);
case -1122643380: return bem_setIfClear_1(bevd_0);
case -320284120: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -824939700: return bem_objectSet_1(bevd_0);
case -1463366211: return bem_def_1(bevd_0);
case -1908940247: return bem_otherClass_1(bevd_0);
case -1398560259: return bem_otherType_1(bevd_0);
case -1272397031: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 764231776: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -830320987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -711906439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1354452916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1773886690: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220461512: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 278898562: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;
}
}
