package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;

public static BET_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_0() throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bem_new_0();
bevp_lock.bem_lock_0();
try  /* Line: 1213 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1215 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1218 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_oGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1224 */ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 1226 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1229 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1236 */ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 1239 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1242 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
bevl_res = be.BECS_Runtime.boolFalse;
try  /* Line: 1250 */ {
if (bevp_obj == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1251 */ {
bevp_obj = beva__obj;
bevl_res = be.BECS_Runtime.boolTrue;
} /* Line: 1253 */
bevp_lock.bem_unlock_0();
} /* Line: 1255 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1258 */
return bevl_res;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1265 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1267 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1270 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_oGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_oSet_1(beva__obj);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objGet_0() throws Throwable {
return bevp_obj;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_objGetDirect_0() throws Throwable {
return bevp_obj;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_obj = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_objSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_obj = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1203, 1208, 1212, 1214, 1215, 1217, 1218, 1223, 1225, 1226, 1228, 1229, 1231, 1235, 1237, 1238, 1239, 1241, 1242, 1244, 1248, 1249, 1251, 1251, 1252, 1253, 1255, 1257, 1258, 1260, 1264, 1266, 1267, 1269, 1270, 1275, 1275, 1279, 1279, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 56, 60, 61, 63, 69, 70, 72, 77, 78, 79, 81, 85, 86, 88, 92, 94, 95, 99, 100, 106, 107, 111, 112, 115, 118, 121, 125, 129, 132, 135, 139};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1203 16
new 0 1203 16
new 0 1208 21
lock 0 1212 22
assign 1 1214 24
unlock 0 1215 25
unlock 0 1217 29
throw 1 1218 30
lock 0 1223 37
assign 1 1225 39
unlock 0 1226 40
unlock 0 1228 44
throw 1 1229 45
return 1 1231 47
lock 0 1235 52
assign 1 1237 54
assign 1 1238 55
unlock 0 1239 56
unlock 0 1241 60
throw 1 1242 61
return 1 1244 63
lock 0 1248 69
assign 1 1249 70
new 0 1249 70
assign 1 1251 72
undef 1 1251 77
assign 1 1252 78
assign 1 1253 79
new 0 1253 79
unlock 0 1255 81
unlock 0 1257 85
throw 1 1258 86
return 1 1260 88
lock 0 1264 92
assign 1 1266 94
unlock 0 1267 95
unlock 0 1269 99
throw 1 1270 100
assign 1 1275 106
oGet 0 1275 106
return 1 1275 107
assign 1 1279 111
oSet 1 1279 111
return 1 1279 112
return 1 0 115
return 1 0 118
assign 1 0 121
assign 1 0 125
return 1 0 129
return 1 0 132
assign 1 0 135
assign 1 0 139
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 322973431: return bem_print_0();
case 2050059376: return bem_iteratorGet_0();
case -43502949: return bem_toAny_0();
case 1851036145: return bem_serializationIteratorGet_0();
case -1640145986: return bem_getAndClear_0();
case -304415890: return bem_classNameGet_0();
case 625547167: return bem_toString_0();
case 305613993: return bem_sourceFileNameGet_0();
case -1087766017: return bem_serializeToString_0();
case -410783155: return bem_new_0();
case -1243583696: return bem_oGet_0();
case -545885409: return bem_fieldNamesGet_0();
case -1569222986: return bem_fieldIteratorGet_0();
case 847681270: return bem_lockGetDirect_0();
case 364235321: return bem_echo_0();
case 1232652027: return bem_lockGet_0();
case 291309239: return bem_once_0();
case -753644705: return bem_hashGet_0();
case 1461724031: return bem_copy_0();
case -381740729: return bem_deserializeClassNameGet_0();
case 1991791209: return bem_objectGet_0();
case -909675958: return bem_create_0();
case -1101326644: return bem_serializeContents_0();
case 597357534: return bem_tagGet_0();
case -186025315: return bem_objGetDirect_0();
case 678571136: return bem_many_0();
case 968723142: return bem_objGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -66735100: return bem_objSetDirect_1(bevd_0);
case -186793001: return bem_new_1(bevd_0);
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case -949389725: return bem_def_1(bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
case 688343531: return bem_objSet_1(bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case -532723443: return bem_oSet_1(bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case -670490754: return bem_lockSetDirect_1(bevd_0);
case -736726059: return bem_setIfClear_1(bevd_0);
case 235595566: return bem_objectSet_1(bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case 1846556981: return bem_lockSet_1(bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;
}
}
