package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_8_BuildClassSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_BEC_2_5_8_BuildClassSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_8_BuildClassSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_0, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_2, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_3, 44));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_4, 78));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_5, 12));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_6, 38));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_7, 68));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_8, 75));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_9, 13));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_10, 65));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_11, 11));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_12, 33));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_13 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_13, 1));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_14, 95));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x62,0x75,0x74,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_15, 90));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_16, 84));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_17 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_17, 80));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_18 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_18, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_19 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_19, 26));
public static BEC_2_5_8_BuildClassSyn bece_BEC_2_5_8_BuildClassSyn_bevs_inst;

public static BET_2_5_8_BuildClassSyn bece_BEC_2_5_8_BuildClassSyn_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_4_ContainerList bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_4_ContainerList bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public BEC_2_5_8_BuildClassSyn bem_new_0() throws Throwable {
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
bevp_integrated = be.BECS_Runtime.boolFalse;
bevp_iChecked = be.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_maxMtdx = (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 96 */ {
bevt_0_tmpany_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 99 */
} /* Line: 98 */
 else  /* Line: 96 */ {
break;
} /* Line: 96 */
} /* Line: 96 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpany_phold);
if (bevl_dmtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 107 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 109 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) throws Throwable {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
bevp_integrated = be.BECS_Runtime.boolFalse;
bevp_iChecked = be.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = beva_psyn.bemd_0(127472467);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bemd_0(-1836757512);
bevt_3_tmpany_phold = beva_psyn.bemd_0(1431969603);
bevp_superList.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = beva_psyn.bemd_0(-1631557130);
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_4_tmpany_phold.bemd_0(-1836757512);
bevt_5_tmpany_phold = beva_psyn.bemd_0(1826221706);
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_5_tmpany_phold.bemd_0(-1836757512);
bevt_7_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(921655777);
bevl_iv = bevt_6_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 132 */ {
bevt_8_tmpany_phold = bevl_iv.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 132 */ {
bevl_ov = bevl_iv.bemd_0(-968892996);
bevt_9_tmpany_phold = beva_psyn.bemd_0(-170971854);
bevt_11_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-851335829);
bevl_pv = bevt_9_tmpany_phold.bemd_1(1362971262, bevt_10_tmpany_phold);
bevt_14_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-851335829);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_8_BuildClassSyn_bels_1));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(177273835, bevt_15_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 135 */ {
if (bevl_pv == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_19_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(93569342);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(-912093780);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_1;
bevt_26_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-851335829);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_2;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(1431969603);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1452564531);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 136 */
} /* Line: 135 */
 else  /* Line: 132 */ {
break;
} /* Line: 132 */
} /* Line: 132 */
bevt_31_tmpany_phold = beva_psyn.bemd_0(1826221706);
bevl_iv = bevt_31_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 141 */ {
bevt_32_tmpany_phold = bevl_iv.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevl_ov = bevl_iv.bemd_0(-968892996);
bevt_34_tmpany_phold = bevl_ov.bemd_0(-353668749);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_0(-1322133419);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevt_35_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_37_tmpany_phold = bevl_ov.bemd_0(-353668749);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(1431969603);
bevt_35_tmpany_phold.bemd_1(1666038174, bevt_36_tmpany_phold);
} /* Line: 144 */
} /* Line: 143 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
bevt_39_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(411299785);
bevl_im = bevt_38_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 148 */ {
bevt_40_tmpany_phold = bevl_im.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 148 */ {
bevl_om = bevl_im.bemd_0(-968892996);
bevt_41_tmpany_phold = beva_psyn.bemd_0(-634521182);
bevt_43_tmpany_phold = bevl_om.bemd_0(-1566200462);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(-851335829);
bevl_pm = bevt_41_tmpany_phold.bemd_1(1362971262, bevt_42_tmpany_phold);
if (bevl_pm == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevt_46_tmpany_phold = bevl_pm.bemd_0(-1375973283);
if (bevt_46_tmpany_phold == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_49_tmpany_phold = bevl_om.bemd_0(-1566200462);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(1583674781);
if (bevt_48_tmpany_phold == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_54_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_3;
bevt_56_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_0(-851335829);
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_add_1(bevt_55_tmpany_phold);
bevt_57_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_4;
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bem_add_1(bevt_57_tmpany_phold);
bevt_59_tmpany_phold = bevl_om.bemd_0(-1566200462);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(-851335829);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_50_tmpany_phold);
} /* Line: 154 */
} /* Line: 153 */
} /* Line: 152 */
} /* Line: 151 */
 else  /* Line: 148 */ {
break;
} /* Line: 148 */
} /* Line: 148 */
bem_loadClass_1(beva_klass);
bevt_60_tmpany_phold = beva_psyn.bemd_0(1480274977);
bevt_61_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpany_phold.bemd_1(-323401251, bevt_61_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpany_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 168 */ {
return this;
} /* Line: 168 */
bevp_integrated = be.BECS_Runtime.boolTrue;
bevp_directProperties = be.BECS_Runtime.boolTrue;
bevp_directMethods = be.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevp_allAncestorsClose = be.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpany_loop = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 178 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 178 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-968892996);
bevt_9_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_methodIndexesGet_0();
bevt_10_tmpany_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpany_phold.bem_put_1(bevt_10_tmpany_phold);
} /* Line: 179 */
 else  /* Line: 178 */ {
break;
} /* Line: 178 */
} /* Line: 178 */
return this;
} /* Line: 181 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (new BEC_2_4_3_MathInt(0));
bevt_11_tmpany_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpany_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpany_phold.bem_subtract_1(bevt_12_tmpany_phold);
bevt_15_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 188 */
bevt_16_tmpany_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_5;
bevt_20_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_17_tmpany_phold);
} /* Line: 190 */
bevt_21_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_23_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 192 */ {
bevt_26_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_6;
bevt_27_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 193 */
bevt_28_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 195 */ {
if (bevp_isLocal.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 195 */ {
if (bevp_isFinal.bevi_bool) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_7;
bevt_34_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_31_tmpany_phold);
} /* Line: 196 */
bevt_1_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 198 */ {
bevt_35_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_35_tmpany_phold).bevi_bool) /* Line: 198 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_has_1(bevt_39_tmpany_phold);
if (bevt_37_tmpany_phold.bevi_bool) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_41_tmpany_phold = bevl_pn.bem_toString_0();
bevt_42_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_8;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_notEquals_1(bevt_42_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 200 */
 else  /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 200 */ {
bevp_directProperties = be.BECS_Runtime.boolFalse;
bevp_directMethods = be.BECS_Runtime.boolFalse;
} /* Line: 203 */
bevt_45_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
} /* Line: 206 */
} /* Line: 205 */
 else  /* Line: 198 */ {
break;
} /* Line: 198 */
} /* Line: 198 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 210 */ {
bevt_47_tmpany_phold = bevl_im.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 210 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(-968892996);
bevt_48_tmpany_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpany_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
if (bevl_pm == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_51_tmpany_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpany_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 217 */
} /* Line: 214 */
 else  /* Line: 219 */ {
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpany_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_methodIndexesGet_0();
bevt_57_tmpany_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpany_phold.bem_put_1(bevt_57_tmpany_phold);
} /* Line: 223 */
} /* Line: 213 */
 else  /* Line: 210 */ {
break;
} /* Line: 210 */
} /* Line: 210 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 230 */ {
return this;
} /* Line: 230 */
bevp_iChecked = be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 232 */ {
return this;
} /* Line: 232 */
bevl_psyn = beva_build.bemd_1(1405658217, bevp_superNp);
bevt_5_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(921655777);
bevl_iv = bevt_4_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 234 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 234 */ {
bevl_ov = bevl_iv.bemd_0(-968892996);
bevt_7_tmpany_phold = bevl_psyn.bemd_0(-170971854);
bevt_9_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-851335829);
bevl_pv = bevt_7_tmpany_phold.bemd_1(1362971262, bevt_8_tmpany_phold);
if (bevl_pv == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_12_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(93569342);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 238 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_9;
bevt_19_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-851335829);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_10;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(1431969603);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1452564531);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_14_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_13_tmpany_phold);
} /* Line: 239 */
 else  /* Line: 240 */ {
bevt_24_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_26_tmpany_phold = bevl_pv.bemd_0(-353668749);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-1322133419);
bevt_24_tmpany_phold.bemd_1(-1710314751, bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_29_tmpany_phold = bevl_pv.bemd_0(-353668749);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1431969603);
bevt_27_tmpany_phold.bemd_1(-266688333, bevt_28_tmpany_phold);
} /* Line: 242 */
} /* Line: 238 */
} /* Line: 237 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
bevt_31_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(411299785);
bevl_im = bevt_30_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 246 */ {
bevt_32_tmpany_phold = bevl_im.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 246 */ {
bevl_om = bevl_im.bemd_0(-968892996);
bevt_33_tmpany_phold = bevl_psyn.bemd_0(-634521182);
bevt_35_tmpany_phold = bevl_om.bemd_0(-1566200462);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(-851335829);
bevl_pm = bevt_33_tmpany_phold.bemd_1(1362971262, bevt_34_tmpany_phold);
if (bevl_pm == null) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevt_37_tmpany_phold = bevl_pm.bemd_0(868781612);
if (((BEC_2_5_4_LogicBool) bevt_37_tmpany_phold).bevi_bool) /* Line: 250 */ {
bevt_42_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_11;
bevt_44_tmpany_phold = bevl_om.bemd_0(-1566200462);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(-851335829);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_45_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_12;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(1431969603);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(1452564531);
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_39_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_38_tmpany_phold);
} /* Line: 251 */
bevt_50_tmpany_phold = bevl_om.bemd_0(-1783416586);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(2054607897);
bevl_oa = bevt_49_tmpany_phold.bemd_0(-1783416586);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 254 */ {
bevt_53_tmpany_phold = bevl_pm.bemd_0(649768173);
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(1664081551);
bevt_51_tmpany_phold = bevl_i.bemd_1(-755059710, bevt_52_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 254 */ {
bevt_54_tmpany_phold = bevl_pm.bemd_0(649768173);
bevl_pmr = bevt_54_tmpany_phold.bemd_1(1362971262, bevl_i);
bevt_55_tmpany_phold = bevl_oa.bemd_1(1362971262, bevl_i);
bevl_omr = bevt_55_tmpany_phold.bemd_0(-1566200462);
bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(-160470335);
} /* Line: 254 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
bevl_pmr = bevl_pm.bemd_0(-1375973283);
bevt_56_tmpany_phold = bevl_om.bemd_0(-1566200462);
bevl_omr = bevt_56_tmpany_phold.bemd_0(1583674781);
if (bevl_pmr == null) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
if (bevl_omr == null) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 262 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 262 */ {
if (bevl_pmr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
if (bevl_omr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_65_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_13;
bevt_68_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(1431969603);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_0(1452564531);
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_add_1(bevt_66_tmpany_phold);
bevt_63_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_63_tmpany_phold);
} /* Line: 268 */
} /* Line: 263 */
 else  /* Line: 270 */ {
bevt_69_tmpany_phold = bevl_pmr.bemd_0(-1574649428);
if (((BEC_2_5_4_LogicBool) bevt_69_tmpany_phold).bevi_bool) /* Line: 272 */ {
bevt_71_tmpany_phold = bevl_pmr.bemd_0(-1574649428);
bevt_72_tmpany_phold = bevl_omr.bemd_0(-1574649428);
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(177273835, bevt_72_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_70_tmpany_phold).bevi_bool) /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 272 */ {
bevt_75_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_14;
bevt_78_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(1431969603);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bemd_0(1452564531);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_76_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 273 */
bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 275 */
} /* Line: 262 */
} /* Line: 249 */
 else  /* Line: 246 */ {
break;
} /* Line: 246 */
} /* Line: 246 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) throws Throwable {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
bevt_2_tmpany_phold = beva_pmr.bemd_0(-1322133419);
bevt_3_tmpany_phold = beva_omr.bemd_0(-1322133419);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(177273835, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_15;
bevt_9_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1431969603);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1452564531);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 283 */
 else  /* Line: 282 */ {
bevt_10_tmpany_phold = beva_pmr.bemd_0(-1322133419);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_11_tmpany_phold = beva_pmr.bemd_0(-1524408288);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_12_tmpany_phold = beva_omr.bemd_0(-1524408288);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 287 */ {
return this;
} /* Line: 288 */
bevt_13_tmpany_phold = beva_omr.bemd_0(1431969603);
bevl_osyn = beva_build.bemd_1(1405658217, bevt_13_tmpany_phold);
bevt_16_tmpany_phold = bevl_osyn.bemd_0(1656179264);
bevt_17_tmpany_phold = beva_pmr.bemd_0(1431969603);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-986730249, bevt_17_tmpany_phold);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(-912093780);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 291 */ {
bevt_20_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_16;
bevt_23_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(1431969603);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1452564531);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_18_tmpany_phold);
} /* Line: 292 */
} /* Line: 291 */
} /* Line: 282 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
bem_new_0();
bevt_1_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(921655777);
bevl_iv = bevt_0_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 299 */ {
bevt_2_tmpany_phold = bevl_iv.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 299 */ {
bevl_ov = bevl_iv.bemd_0(-968892996);
bevt_5_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(93569342);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-912093780);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 301 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_17;
bevt_12_tmpany_phold = bevl_ov.bemd_0(-1566200462);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-851335829);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_18;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_16_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1431969603);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(1452564531);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 302 */
} /* Line: 301 */
 else  /* Line: 299 */ {
break;
} /* Line: 299 */
} /* Line: 299 */
bem_loadClass_1(beva_klass);
bevp_depth = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bemd_0(-250567657);
bevt_1_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_phold.bemd_0(1431969603);
bevt_2_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(1275103320);
bevt_3_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpany_phold.bemd_0(868781612);
bevt_4_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpany_phold.bemd_0(-1345279295);
bevt_5_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpany_phold.bemd_0(288541394);
bevt_7_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-2121744907);
bevl_iu = bevt_6_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 317 */ {
bevt_8_tmpany_phold = bevl_iu.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 317 */ {
bevl_ou = bevl_iu.bemd_0(-968892996);
bevt_9_tmpany_phold = bevl_ou.bemd_0(1452564531);
bevp_uses.bem_put_1(bevt_9_tmpany_phold);
} /* Line: 319 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
bevt_11_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(921655777);
bevl_iv = bevt_10_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 321 */ {
bevt_12_tmpany_phold = bevl_iv.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 321 */ {
bevl_ov = bevl_iv.bemd_0(-968892996);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 324 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
bevt_14_tmpany_phold = beva_klass.bemd_0(-1566200462);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(411299785);
bevl_im = bevt_13_tmpany_phold.bemd_0(-757699318);
while (true)
 /* Line: 326 */ {
bevt_15_tmpany_phold = bevl_im.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 326 */ {
bevl_om = bevl_im.bemd_0(-968892996);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 329 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_postLoad_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_nptyList = null;
BEC_2_9_4_ContainerList bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
bevl_nptyList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_mtdnList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 339 */ {
bevt_1_tmpany_phold = bevl_iv.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 339 */ {
bevl_ov = bevl_iv.bemd_0(-968892996);
bevt_4_tmpany_phold = bevl_ov.bemd_0(-851335829);
bevt_3_tmpany_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_5_tmpany_phold = bevl_ov.bemd_0(-851335829);
bevp_ptyMap.bem_put_2(bevt_5_tmpany_phold, bevl_ov);
} /* Line: 343 */
} /* Line: 341 */
 else  /* Line: 339 */ {
break;
} /* Line: 339 */
} /* Line: 339 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 349 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 349 */ {
bevl_ov = bevl_iv.bemd_0(-968892996);
bevt_9_tmpany_phold = bevl_ov.bemd_0(-851335829);
bevt_8_tmpany_phold = bevl_unq.bem_has_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevt_10_tmpany_phold = bevl_ov.bemd_0(-851335829);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpany_phold);
bevl_nom.bemd_1(1456251128, bevl_mpos);
bevt_11_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(-323401251, bevt_11_tmpany_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpany_phold = bevl_ov.bemd_0(-851335829);
bevt_13_tmpany_phold = bevl_ov.bemd_0(-851335829);
bevl_unq.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
} /* Line: 356 */
} /* Line: 351 */
 else  /* Line: 349 */ {
break;
} /* Line: 349 */
} /* Line: 349 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 363 */ {
bevt_14_tmpany_phold = bevl_im.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 363 */ {
bevl_om = bevl_im.bemd_0(-968892996);
bevt_15_tmpany_phold = bevl_om.bemd_0(-851335829);
bevp_mtdMap.bem_put_2(bevt_15_tmpany_phold, bevl_om);
bevt_18_tmpany_phold = bevl_om.bemd_0(-851335829);
bevt_17_tmpany_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 368 */ {
bevt_19_tmpany_phold = bevl_om.bemd_0(-851335829);
bevl_mtdOmap.bem_put_2(bevt_19_tmpany_phold, bevl_om);
} /* Line: 369 */
} /* Line: 368 */
 else  /* Line: 363 */ {
break;
} /* Line: 363 */
} /* Line: 363 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 375 */ {
bevt_20_tmpany_phold = bevl_im.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 375 */ {
bevl_om = bevl_im.bemd_0(-968892996);
bevt_23_tmpany_phold = bevl_om.bemd_0(-851335829);
bevt_22_tmpany_phold = bevl_unq.bem_has_1(bevt_23_tmpany_phold);
if (bevt_22_tmpany_phold.bevi_bool) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 377 */ {
bevt_24_tmpany_phold = bevl_om.bemd_0(-851335829);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = bevl_om.bemd_0(-851335829);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevt_28_tmpany_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpany_phold);
} /* Line: 389 */
bevt_29_tmpany_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(1401644628, bevt_29_tmpany_phold);
bevl_oma.bemd_1(1581740455, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpany_phold = bevl_om.bemd_0(-851335829);
bevt_31_tmpany_phold = bevl_om.bemd_0(-851335829);
bevl_unq.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
} /* Line: 395 */
} /* Line: 377 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 400 */ {
bevt_32_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 400 */ {
bevl_s = bevt_0_tmpany_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 402 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() throws Throwable {
return bevp_superNp;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_superNpGetDirect_0() throws Throwable {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_superNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
return bevp_depth;
} /*method end*/
public final BEC_2_4_3_MathInt bem_depthGetDirect_0() throws Throwable {
return bevp_depth;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_depthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_fromFileGetDirect_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() throws Throwable {
return bevp_newMbrs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_newMbrsGetDirect_0() throws Throwable {
return bevp_newMbrs;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_newMbrsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() throws Throwable {
return bevp_newMtds;
} /*method end*/
public final BEC_2_4_3_MathInt bem_newMtdsGetDirect_0() throws Throwable {
return bevp_newMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_newMtdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() throws Throwable {
return bevp_defMtds;
} /*method end*/
public final BEC_2_4_3_MathInt bem_defMtdsGetDirect_0() throws Throwable {
return bevp_defMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_defMtdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() throws Throwable {
return bevp_directProperties;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_directPropertiesGetDirect_0() throws Throwable {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_directPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() throws Throwable {
return bevp_directMethods;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_directMethodsGetDirect_0() throws Throwable {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_directMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() throws Throwable {
return bevp_allTypes;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_allTypesGetDirect_0() throws Throwable {
return bevp_allTypes;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_allTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() throws Throwable {
return bevp_superList;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_superListGetDirect_0() throws Throwable {
return bevp_superList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_superListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() throws Throwable {
return bevp_mtdMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_mtdMapGetDirect_0() throws Throwable {
return bevp_mtdMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_mtdMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGet_0() throws Throwable {
return bevp_mtdList;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_mtdListGetDirect_0() throws Throwable {
return bevp_mtdList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_mtdListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() throws Throwable {
return bevp_ptyMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_ptyMapGetDirect_0() throws Throwable {
return bevp_ptyMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_ptyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGet_0() throws Throwable {
return bevp_ptyList;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_ptyListGetDirect_0() throws Throwable {
return bevp_ptyList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_ptyListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_allNamesGetDirect_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_allNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_foreignClassesGetDirect_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_foreignClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() throws Throwable {
return bevp_allAncestorsClose;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_allAncestorsCloseGetDirect_0() throws Throwable {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() throws Throwable {
return bevp_integrated;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_integratedGetDirect_0() throws Throwable {
return bevp_integrated;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_integratedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() throws Throwable {
return bevp_iChecked;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_iCheckedGetDirect_0() throws Throwable {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_iCheckedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() throws Throwable {
return bevp_uses;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_usesGetDirect_0() throws Throwable {
return bevp_uses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_usesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() throws Throwable {
return bevp_signatureChanged;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_signatureChangedGetDirect_0() throws Throwable {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_signatureChangedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() throws Throwable {
return bevp_signatureChecked;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_signatureCheckedGetDirect_0() throws Throwable {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_signatureCheckedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {72, 74, 76, 78, 79, 80, 81, 82, 83, 84, 85, 87, 88, 89, 90, 95, 96, 96, 97, 98, 98, 98, 99, 102, 106, 106, 107, 107, 109, 109, 111, 111, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 126, 127, 127, 128, 128, 129, 129, 132, 132, 132, 132, 133, 134, 134, 134, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 135, 135, 135, 0, 0, 0, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 141, 141, 141, 142, 143, 143, 144, 144, 144, 144, 148, 148, 148, 148, 149, 150, 150, 150, 150, 151, 151, 152, 152, 152, 153, 153, 153, 153, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 159, 160, 160, 160, 164, 164, 168, 169, 170, 171, 172, 173, 173, 174, 175, 176, 177, 178, 0, 178, 178, 179, 179, 179, 179, 181, 183, 184, 185, 187, 187, 187, 187, 188, 188, 188, 189, 190, 190, 190, 190, 190, 192, 192, 192, 0, 0, 0, 193, 193, 193, 193, 193, 195, 195, 195, 0, 0, 0, 195, 195, 0, 0, 0, 196, 196, 196, 196, 196, 198, 0, 198, 198, 199, 200, 200, 200, 200, 200, 200, 200, 200, 0, 0, 0, 202, 203, 205, 205, 205, 205, 205, 206, 210, 210, 211, 212, 212, 212, 213, 213, 214, 215, 215, 216, 216, 217, 220, 220, 221, 222, 223, 223, 223, 223, 230, 231, 232, 232, 232, 233, 234, 234, 234, 234, 235, 236, 236, 236, 236, 237, 237, 238, 238, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 241, 241, 241, 241, 242, 242, 242, 242, 246, 246, 246, 246, 247, 248, 248, 248, 248, 249, 249, 250, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 253, 253, 253, 254, 254, 254, 254, 255, 255, 256, 256, 258, 254, 260, 261, 261, 262, 262, 0, 262, 262, 0, 0, 263, 263, 263, 0, 263, 263, 263, 0, 0, 268, 268, 268, 268, 268, 268, 268, 272, 272, 272, 272, 0, 0, 0, 273, 273, 273, 273, 273, 273, 273, 275, 282, 282, 282, 283, 283, 283, 283, 283, 283, 283, 284, 287, 287, 0, 0, 0, 288, 290, 290, 291, 291, 291, 291, 292, 292, 292, 292, 292, 292, 292, 298, 299, 299, 299, 299, 300, 301, 301, 301, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 305, 306, 311, 311, 312, 312, 313, 313, 314, 314, 315, 315, 316, 316, 317, 317, 317, 317, 318, 319, 319, 321, 321, 321, 321, 322, 323, 324, 326, 326, 326, 326, 327, 328, 329, 331, 335, 336, 339, 339, 340, 341, 341, 341, 341, 343, 343, 347, 348, 349, 349, 350, 351, 351, 351, 351, 352, 352, 353, 354, 354, 355, 356, 356, 356, 359, 361, 363, 363, 364, 366, 366, 368, 368, 368, 368, 369, 369, 373, 374, 375, 375, 376, 377, 377, 377, 377, 378, 378, 387, 387, 388, 388, 388, 389, 389, 391, 391, 392, 393, 394, 395, 395, 395, 398, 400, 0, 400, 400, 401, 402, 405, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 102, 103, 106, 108, 109, 110, 115, 116, 123, 131, 132, 133, 138, 139, 140, 142, 143, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 240, 242, 243, 244, 245, 246, 247, 248, 249, 250, 252, 257, 258, 261, 265, 268, 269, 270, 272, 275, 279, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 300, 301, 304, 306, 307, 308, 310, 311, 312, 313, 320, 321, 322, 325, 327, 328, 329, 330, 331, 332, 337, 338, 339, 344, 345, 346, 347, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 372, 373, 374, 375, 380, 381, 449, 451, 452, 453, 454, 455, 460, 461, 462, 463, 464, 465, 465, 468, 470, 471, 472, 473, 474, 480, 482, 483, 484, 485, 486, 487, 488, 489, 490, 492, 494, 496, 497, 498, 499, 500, 502, 504, 505, 507, 510, 514, 517, 518, 519, 520, 521, 523, 525, 530, 531, 534, 538, 541, 546, 547, 550, 554, 557, 558, 559, 560, 561, 563, 563, 566, 568, 569, 570, 571, 572, 573, 578, 579, 580, 581, 583, 586, 590, 593, 594, 596, 597, 598, 599, 604, 605, 612, 615, 617, 618, 619, 620, 621, 626, 627, 629, 630, 631, 632, 633, 637, 638, 639, 640, 641, 642, 643, 644, 745, 747, 748, 753, 754, 756, 757, 758, 759, 762, 764, 765, 766, 767, 768, 769, 774, 775, 776, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 792, 793, 794, 795, 796, 797, 798, 799, 807, 808, 809, 812, 814, 815, 816, 817, 818, 819, 824, 825, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 840, 841, 842, 843, 846, 847, 848, 850, 851, 852, 853, 854, 855, 861, 862, 863, 864, 869, 870, 873, 878, 879, 882, 886, 891, 896, 897, 900, 905, 910, 911, 914, 918, 919, 920, 921, 922, 923, 924, 928, 930, 931, 932, 934, 937, 941, 944, 945, 946, 947, 948, 949, 950, 952, 988, 989, 990, 992, 993, 994, 995, 996, 997, 998, 1001, 1003, 1005, 1007, 1010, 1014, 1017, 1019, 1020, 1021, 1022, 1023, 1024, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1058, 1059, 1060, 1061, 1064, 1066, 1067, 1068, 1069, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1089, 1090, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1135, 1137, 1138, 1139, 1145, 1146, 1147, 1150, 1152, 1153, 1154, 1160, 1161, 1162, 1165, 1167, 1168, 1169, 1175, 1226, 1227, 1228, 1231, 1233, 1234, 1235, 1236, 1241, 1242, 1243, 1250, 1251, 1252, 1255, 1257, 1258, 1259, 1260, 1265, 1266, 1267, 1268, 1269, 1270, 1271, 1272, 1273, 1274, 1281, 1282, 1283, 1286, 1288, 1289, 1290, 1291, 1292, 1293, 1298, 1299, 1300, 1307, 1308, 1309, 1312, 1314, 1315, 1316, 1317, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1333, 1334, 1335, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1351, 1352, 1352, 1355, 1357, 1358, 1359, 1365, 1369, 1372, 1375, 1379, 1383, 1386, 1389, 1393, 1397, 1400, 1403, 1407, 1411, 1414, 1417, 1421, 1425, 1428, 1431, 1435, 1439, 1442, 1445, 1449, 1453, 1456, 1459, 1463, 1467, 1470, 1473, 1477, 1481, 1484, 1487, 1491, 1495, 1498, 1501, 1505, 1509, 1512, 1515, 1519, 1523, 1526, 1529, 1533, 1537, 1540, 1543, 1547, 1551, 1554, 1557, 1561, 1565, 1568, 1571, 1575, 1579, 1582, 1585, 1589, 1593, 1596, 1599, 1603, 1607, 1610, 1613, 1617, 1621, 1624, 1627, 1631, 1635, 1638, 1641, 1645, 1649, 1652, 1655, 1659, 1663, 1666, 1669, 1673, 1677, 1680, 1683, 1687, 1691, 1694, 1697, 1701, 1705, 1708, 1711, 1715, 1719, 1722, 1725, 1729, 1733, 1736, 1739, 1743};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 72 78
new 0 72 78
assign 1 74 79
new 0 74 79
assign 1 76 80
new 0 76 80
assign 1 78 81
new 0 78 81
assign 1 79 82
new 0 79 82
assign 1 80 83
new 0 80 83
assign 1 81 84
new 0 81 84
assign 1 82 85
new 0 82 85
assign 1 83 86
new 0 83 86
assign 1 84 87
new 0 84 87
assign 1 85 88
new 0 85 88
assign 1 87 89
new 0 87 89
assign 1 88 90
new 0 88 90
assign 1 89 91
new 0 89 91
assign 1 90 92
new 0 90 92
assign 1 95 102
new 0 95 102
assign 1 96 103
valueIteratorGet 0 96 103
assign 1 96 106
hasNextGet 0 96 106
assign 1 97 108
nextGet 0 97 108
assign 1 98 109
mtdxGet 0 98 109
assign 1 98 110
greater 1 98 115
assign 1 99 116
mtdxGet 0 99 116
return 1 102 123
assign 1 106 131
new 0 106 131
assign 1 106 132
get 1 106 132
assign 1 107 133
def 1 107 138
assign 1 109 139
new 0 109 139
return 1 109 140
assign 1 111 142
new 0 111 142
return 1 111 143
assign 1 115 216
new 0 115 216
assign 1 116 217
new 0 116 217
assign 1 117 218
new 0 117 218
assign 1 118 219
new 0 118 219
assign 1 119 220
new 0 119 220
assign 1 120 221
new 0 120 221
assign 1 121 222
new 0 121 222
assign 1 122 223
new 0 122 223
assign 1 123 224
new 0 123 224
assign 1 124 225
new 0 124 225
assign 1 125 226
new 0 125 226
assign 1 126 227
superListGet 0 126 227
assign 1 126 228
copy 0 126 228
assign 1 127 229
namepathGet 0 127 229
addValue 1 127 230
assign 1 128 231
mtdListGet 0 128 231
assign 1 128 232
copy 0 128 232
assign 1 129 233
ptyListGet 0 129 233
assign 1 129 234
copy 0 129 234
assign 1 132 235
heldGet 0 132 235
assign 1 132 236
orderedVarsGet 0 132 236
assign 1 132 237
iteratorGet 0 132 237
assign 1 132 240
hasNextGet 0 132 240
assign 1 133 242
nextGet 0 133 242
assign 1 134 243
ptyMapGet 0 134 243
assign 1 134 244
heldGet 0 134 244
assign 1 134 245
nameGet 0 134 245
assign 1 134 246
get 1 134 246
assign 1 135 247
heldGet 0 135 247
assign 1 135 248
nameGet 0 135 248
assign 1 135 249
new 0 135 249
assign 1 135 250
notEquals 1 135 250
assign 1 135 252
undef 1 135 257
assign 1 0 258
assign 1 0 261
assign 1 0 265
assign 1 135 268
heldGet 0 135 268
assign 1 135 269
isDeclaredGet 0 135 269
assign 1 135 270
not 0 135 270
assign 1 0 272
assign 1 0 275
assign 1 0 279
assign 1 136 282
new 0 136 282
assign 1 136 283
heldGet 0 136 283
assign 1 136 284
nameGet 0 136 284
assign 1 136 285
add 1 136 285
assign 1 136 286
new 0 136 286
assign 1 136 287
add 1 136 287
assign 1 136 288
heldGet 0 136 288
assign 1 136 289
namepathGet 0 136 289
assign 1 136 290
toString 0 136 290
assign 1 136 291
add 1 136 291
assign 1 136 292
new 2 136 292
throw 1 136 293
assign 1 141 300
ptyListGet 0 141 300
assign 1 141 301
iteratorGet 0 141 301
assign 1 141 304
hasNextGet 0 141 304
assign 1 142 306
nextGet 0 142 306
assign 1 143 307
memSynGet 0 143 307
assign 1 143 308
isTypedGet 0 143 308
assign 1 144 310
heldGet 0 144 310
assign 1 144 311
memSynGet 0 144 311
assign 1 144 312
namepathGet 0 144 312
addUsed 1 144 313
assign 1 148 320
heldGet 0 148 320
assign 1 148 321
orderedMethodsGet 0 148 321
assign 1 148 322
iteratorGet 0 148 322
assign 1 148 325
hasNextGet 0 148 325
assign 1 149 327
nextGet 0 149 327
assign 1 150 328
mtdMapGet 0 150 328
assign 1 150 329
heldGet 0 150 329
assign 1 150 330
nameGet 0 150 330
assign 1 150 331
get 1 150 331
assign 1 151 332
def 1 151 337
assign 1 152 338
rsynGet 0 152 338
assign 1 152 339
def 1 152 344
assign 1 153 345
heldGet 0 153 345
assign 1 153 346
rtypeGet 0 153 346
assign 1 153 347
undef 1 153 352
assign 1 154 353
new 0 154 353
assign 1 154 354
heldGet 0 154 354
assign 1 154 355
nameGet 0 154 355
assign 1 154 356
add 1 154 356
assign 1 154 357
new 0 154 357
assign 1 154 358
add 1 154 358
assign 1 154 359
heldGet 0 154 359
assign 1 154 360
nameGet 0 154 360
assign 1 154 361
add 1 154 361
assign 1 154 362
new 2 154 362
throw 1 154 363
loadClass 1 159 372
assign 1 160 373
depthGet 0 160 373
assign 1 160 374
new 0 160 374
assign 1 160 375
add 1 160 375
assign 1 164 380
has 1 164 380
return 1 164 381
return 1 168 449
assign 1 169 451
new 0 169 451
assign 1 170 452
new 0 170 452
assign 1 171 453
new 0 171 453
assign 1 172 454
new 0 172 454
assign 1 173 455
undef 1 173 460
assign 1 174 461
new 0 174 461
assign 1 175 462
sizeGet 0 175 462
assign 1 176 463
sizeGet 0 176 463
assign 1 177 464
assign 1 178 465
iteratorGet 0 0 465
assign 1 178 468
hasNextGet 0 178 468
assign 1 178 470
nextGet 0 178 470
assign 1 179 471
emitDataGet 0 179 471
assign 1 179 472
methodIndexesGet 0 179 472
assign 1 179 473
new 2 179 473
put 1 179 474
return 1 181 480
assign 1 183 482
getSynNp 1 183 482
assign 1 184 483
new 0 184 483
assign 1 185 484
new 0 185 484
assign 1 187 485
sizeGet 0 187 485
assign 1 187 486
ptyListGet 0 187 486
assign 1 187 487
sizeGet 0 187 487
assign 1 187 488
subtract 1 187 488
assign 1 188 489
libNameGet 0 188 489
assign 1 188 490
equals 1 188 490
integrate 1 188 492
assign 1 189 494
isFinalGet 0 189 494
assign 1 190 496
new 0 190 496
assign 1 190 497
toString 0 190 497
assign 1 190 498
add 1 190 498
assign 1 190 499
new 1 190 499
throw 1 190 500
assign 1 192 502
isLocalGet 0 192 502
assign 1 192 504
libNameGet 0 192 504
assign 1 192 505
notEquals 1 192 505
assign 1 0 507
assign 1 0 510
assign 1 0 514
assign 1 193 517
new 0 193 517
assign 1 193 518
toString 0 193 518
assign 1 193 519
add 1 193 519
assign 1 193 520
new 1 193 520
throw 1 193 521
assign 1 195 523
isLocalGet 0 195 523
assign 1 195 525
not 0 195 530
assign 1 0 531
assign 1 0 534
assign 1 0 538
assign 1 195 541
not 0 195 546
assign 1 0 547
assign 1 0 550
assign 1 0 554
assign 1 196 557
new 0 196 557
assign 1 196 558
toString 0 196 558
assign 1 196 559
add 1 196 559
assign 1 196 560
new 1 196 560
throw 1 196 561
assign 1 198 563
linkedListIteratorGet 0 0 563
assign 1 198 566
hasNextGet 0 198 566
assign 1 198 568
nextGet 0 198 568
assign 1 199 569
getSynNp 1 199 569
assign 1 200 570
closeLibrariesGet 0 200 570
assign 1 200 571
libNameGet 0 200 571
assign 1 200 572
has 1 200 572
assign 1 200 573
not 0 200 578
assign 1 200 579
toString 0 200 579
assign 1 200 580
new 0 200 580
assign 1 200 581
notEquals 1 200 581
assign 1 0 583
assign 1 0 586
assign 1 0 590
assign 1 202 593
new 0 202 593
assign 1 203 594
new 0 203 594
assign 1 205 596
closeLibrariesGet 0 205 596
assign 1 205 597
libNameGet 0 205 597
assign 1 205 598
has 1 205 598
assign 1 205 599
not 0 205 604
assign 1 206 605
new 0 206 605
assign 1 210 612
valueIteratorGet 0 210 612
assign 1 210 615
hasNextGet 0 210 615
assign 1 211 617
nextGet 0 211 617
assign 1 212 618
mtdMapGet 0 212 618
assign 1 212 619
nameGet 0 212 619
assign 1 212 620
get 1 212 620
assign 1 213 621
def 1 213 626
assign 1 214 627
notEquals 1 214 627
assign 1 215 629
new 0 215 629
lastDefSet 1 215 630
assign 1 216 631
new 0 216 631
isOverrideSet 1 216 632
assign 1 217 633
increment 0 217 633
assign 1 220 637
new 0 220 637
isOverrideSet 1 220 638
assign 1 221 639
increment 0 221 639
assign 1 222 640
increment 0 222 640
assign 1 223 641
emitDataGet 0 223 641
assign 1 223 642
methodIndexesGet 0 223 642
assign 1 223 643
new 2 223 643
put 1 223 644
return 1 230 745
assign 1 231 747
new 0 231 747
assign 1 232 748
undef 1 232 753
return 1 232 754
assign 1 233 756
getSynNp 1 233 756
assign 1 234 757
heldGet 0 234 757
assign 1 234 758
orderedVarsGet 0 234 758
assign 1 234 759
iteratorGet 0 234 759
assign 1 234 762
hasNextGet 0 234 762
assign 1 235 764
nextGet 0 235 764
assign 1 236 765
ptyMapGet 0 236 765
assign 1 236 766
heldGet 0 236 766
assign 1 236 767
nameGet 0 236 767
assign 1 236 768
get 1 236 768
assign 1 237 769
def 1 237 774
assign 1 238 775
heldGet 0 238 775
assign 1 238 776
isDeclaredGet 0 238 776
assign 1 239 778
new 0 239 778
assign 1 239 779
heldGet 0 239 779
assign 1 239 780
nameGet 0 239 780
assign 1 239 781
add 1 239 781
assign 1 239 782
new 0 239 782
assign 1 239 783
add 1 239 783
assign 1 239 784
heldGet 0 239 784
assign 1 239 785
namepathGet 0 239 785
assign 1 239 786
toString 0 239 786
assign 1 239 787
add 1 239 787
assign 1 239 788
new 1 239 788
throw 1 239 789
assign 1 241 792
heldGet 0 241 792
assign 1 241 793
memSynGet 0 241 793
assign 1 241 794
isTypedGet 0 241 794
isTypedSet 1 241 795
assign 1 242 796
heldGet 0 242 796
assign 1 242 797
memSynGet 0 242 797
assign 1 242 798
namepathGet 0 242 798
namepathSet 1 242 799
assign 1 246 807
heldGet 0 246 807
assign 1 246 808
orderedMethodsGet 0 246 808
assign 1 246 809
iteratorGet 0 246 809
assign 1 246 812
hasNextGet 0 246 812
assign 1 247 814
nextGet 0 247 814
assign 1 248 815
mtdMapGet 0 248 815
assign 1 248 816
heldGet 0 248 816
assign 1 248 817
nameGet 0 248 817
assign 1 248 818
get 1 248 818
assign 1 249 819
def 1 249 824
assign 1 250 825
isFinalGet 0 250 825
assign 1 251 827
new 0 251 827
assign 1 251 828
heldGet 0 251 828
assign 1 251 829
nameGet 0 251 829
assign 1 251 830
add 1 251 830
assign 1 251 831
new 0 251 831
assign 1 251 832
add 1 251 832
assign 1 251 833
heldGet 0 251 833
assign 1 251 834
namepathGet 0 251 834
assign 1 251 835
toString 0 251 835
assign 1 251 836
add 1 251 836
assign 1 251 837
new 2 251 837
throw 1 251 838
assign 1 253 840
containedGet 0 253 840
assign 1 253 841
firstGet 0 253 841
assign 1 253 842
containedGet 0 253 842
assign 1 254 843
new 0 254 843
assign 1 254 846
argSynsGet 0 254 846
assign 1 254 847
lengthGet 0 254 847
assign 1 254 848
lesser 1 254 848
assign 1 255 850
argSynsGet 0 255 850
assign 1 255 851
get 1 255 851
assign 1 256 852
get 1 256 852
assign 1 256 853
heldGet 0 256 853
checkTypes 5 258 854
assign 1 254 855
increment 0 254 855
assign 1 260 861
rsynGet 0 260 861
assign 1 261 862
heldGet 0 261 862
assign 1 261 863
rtypeGet 0 261 863
assign 1 262 864
undef 1 262 869
assign 1 0 870
assign 1 262 873
undef 1 262 878
assign 1 0 879
assign 1 0 882
assign 1 263 886
undef 1 263 891
assign 1 263 891
not 0 263 896
assign 1 0 897
assign 1 263 900
undef 1 263 905
assign 1 263 905
not 0 263 910
assign 1 0 911
assign 1 0 914
assign 1 268 918
new 0 268 918
assign 1 268 919
heldGet 0 268 919
assign 1 268 920
namepathGet 0 268 920
assign 1 268 921
toString 0 268 921
assign 1 268 922
add 1 268 922
assign 1 268 923
new 2 268 923
throw 1 268 924
assign 1 272 928
isThisGet 0 272 928
assign 1 272 930
isThisGet 0 272 930
assign 1 272 931
isThisGet 0 272 931
assign 1 272 932
notEquals 1 272 932
assign 1 0 934
assign 1 0 937
assign 1 0 941
assign 1 273 944
new 0 273 944
assign 1 273 945
heldGet 0 273 945
assign 1 273 946
namepathGet 0 273 946
assign 1 273 947
toString 0 273 947
assign 1 273 948
add 1 273 948
assign 1 273 949
new 2 273 949
throw 1 273 950
checkTypes 5 275 952
assign 1 282 988
isTypedGet 0 282 988
assign 1 282 989
isTypedGet 0 282 989
assign 1 282 990
notEquals 1 282 990
assign 1 283 992
new 0 283 992
assign 1 283 993
heldGet 0 283 993
assign 1 283 994
namepathGet 0 283 994
assign 1 283 995
toString 0 283 995
assign 1 283 996
add 1 283 996
assign 1 283 997
new 2 283 997
throw 1 283 998
assign 1 284 1001
isTypedGet 0 284 1001
assign 1 287 1003
isSelfGet 0 287 1003
assign 1 287 1005
isSelfGet 0 287 1005
assign 1 0 1007
assign 1 0 1010
assign 1 0 1014
return 1 288 1017
assign 1 290 1019
namepathGet 0 290 1019
assign 1 290 1020
getSynNp 1 290 1020
assign 1 291 1021
allTypesGet 0 291 1021
assign 1 291 1022
namepathGet 0 291 1022
assign 1 291 1023
has 1 291 1023
assign 1 291 1024
not 0 291 1024
assign 1 292 1026
new 0 292 1026
assign 1 292 1027
heldGet 0 292 1027
assign 1 292 1028
namepathGet 0 292 1028
assign 1 292 1029
toString 0 292 1029
assign 1 292 1030
add 1 292 1030
assign 1 292 1031
new 2 292 1031
throw 1 292 1032
new 0 298 1058
assign 1 299 1059
heldGet 0 299 1059
assign 1 299 1060
orderedVarsGet 0 299 1060
assign 1 299 1061
iteratorGet 0 299 1061
assign 1 299 1064
hasNextGet 0 299 1064
assign 1 300 1066
nextGet 0 300 1066
assign 1 301 1067
heldGet 0 301 1067
assign 1 301 1068
isDeclaredGet 0 301 1068
assign 1 301 1069
not 0 301 1069
assign 1 302 1071
new 0 302 1071
assign 1 302 1072
heldGet 0 302 1072
assign 1 302 1073
nameGet 0 302 1073
assign 1 302 1074
add 1 302 1074
assign 1 302 1075
new 0 302 1075
assign 1 302 1076
add 1 302 1076
assign 1 302 1077
heldGet 0 302 1077
assign 1 302 1078
namepathGet 0 302 1078
assign 1 302 1079
toString 0 302 1079
assign 1 302 1080
add 1 302 1080
assign 1 302 1081
new 2 302 1081
throw 1 302 1082
loadClass 1 305 1089
assign 1 306 1090
new 0 306 1090
assign 1 311 1118
heldGet 0 311 1118
assign 1 311 1119
fromFileGet 0 311 1119
assign 1 312 1120
heldGet 0 312 1120
assign 1 312 1121
namepathGet 0 312 1121
assign 1 313 1122
heldGet 0 313 1122
assign 1 313 1123
libNameGet 0 313 1123
assign 1 314 1124
heldGet 0 314 1124
assign 1 314 1125
isFinalGet 0 314 1125
assign 1 315 1126
heldGet 0 315 1126
assign 1 315 1127
isLocalGet 0 315 1127
assign 1 316 1128
heldGet 0 316 1128
assign 1 316 1129
isNotNullGet 0 316 1129
assign 1 317 1130
heldGet 0 317 1130
assign 1 317 1131
usedGet 0 317 1131
assign 1 317 1132
iteratorGet 0 317 1132
assign 1 317 1135
hasNextGet 0 317 1135
assign 1 318 1137
nextGet 0 318 1137
assign 1 319 1138
toString 0 319 1138
put 1 319 1139
assign 1 321 1145
heldGet 0 321 1145
assign 1 321 1146
orderedVarsGet 0 321 1146
assign 1 321 1147
iteratorGet 0 321 1147
assign 1 321 1150
hasNextGet 0 321 1150
assign 1 322 1152
nextGet 0 322 1152
assign 1 323 1153
new 2 323 1153
addValue 1 324 1154
assign 1 326 1160
heldGet 0 326 1160
assign 1 326 1161
orderedMethodsGet 0 326 1161
assign 1 326 1162
iteratorGet 0 326 1162
assign 1 326 1165
hasNextGet 0 326 1165
assign 1 327 1167
nextGet 0 327 1167
assign 1 328 1168
new 2 328 1168
addValue 1 329 1169
postLoad 0 331 1175
assign 1 335 1226
new 0 335 1226
assign 1 336 1227
new 0 336 1227
assign 1 339 1228
iteratorGet 0 339 1228
assign 1 339 1231
hasNextGet 0 339 1231
assign 1 340 1233
nextGet 0 340 1233
assign 1 341 1234
nameGet 0 341 1234
assign 1 341 1235
has 1 341 1235
assign 1 341 1236
not 0 341 1241
assign 1 343 1242
nameGet 0 343 1242
put 2 343 1243
assign 1 347 1250
new 0 347 1250
assign 1 348 1251
new 0 348 1251
assign 1 349 1252
iteratorGet 0 349 1252
assign 1 349 1255
hasNextGet 0 349 1255
assign 1 350 1257
nextGet 0 350 1257
assign 1 351 1258
nameGet 0 351 1258
assign 1 351 1259
has 1 351 1259
assign 1 351 1260
not 0 351 1265
assign 1 352 1266
nameGet 0 352 1266
assign 1 352 1267
get 1 352 1267
mposSet 1 353 1268
assign 1 354 1269
new 0 354 1269
assign 1 354 1270
add 1 354 1270
addValue 1 355 1271
assign 1 356 1272
nameGet 0 356 1272
assign 1 356 1273
nameGet 0 356 1273
put 2 356 1274
assign 1 359 1281
assign 1 361 1282
new 0 361 1282
assign 1 363 1283
iteratorGet 0 363 1283
assign 1 363 1286
hasNextGet 0 363 1286
assign 1 364 1288
nextGet 0 364 1288
assign 1 366 1289
nameGet 0 366 1289
put 2 366 1290
assign 1 368 1291
nameGet 0 368 1291
assign 1 368 1292
has 1 368 1292
assign 1 368 1293
not 0 368 1298
assign 1 369 1299
nameGet 0 369 1299
put 2 369 1300
assign 1 373 1307
new 0 373 1307
assign 1 374 1308
new 0 374 1308
assign 1 375 1309
iteratorGet 0 375 1309
assign 1 375 1312
hasNextGet 0 375 1312
assign 1 376 1314
nextGet 0 376 1314
assign 1 377 1315
nameGet 0 377 1315
assign 1 377 1316
has 1 377 1316
assign 1 377 1317
not 0 377 1322
assign 1 378 1323
nameGet 0 378 1323
assign 1 378 1324
get 1 378 1324
assign 1 387 1325
nameGet 0 387 1325
assign 1 387 1326
get 1 387 1326
assign 1 388 1327
declarationGet 0 388 1327
assign 1 388 1328
undef 1 388 1333
assign 1 389 1334
originGet 0 389 1334
declarationSet 1 389 1335
assign 1 391 1337
declarationGet 0 391 1337
declarationSet 1 391 1338
mtdxSet 1 392 1339
assign 1 393 1340
increment 0 393 1340
addValue 1 394 1341
assign 1 395 1342
nameGet 0 395 1342
assign 1 395 1343
nameGet 0 395 1343
put 2 395 1344
assign 1 398 1351
assign 1 400 1352
linkedListIteratorGet 0 0 1352
assign 1 400 1355
hasNextGet 0 400 1355
assign 1 400 1357
nextGet 0 400 1357
put 2 401 1358
assign 1 402 1359
put 2 405 1365
return 1 0 1369
return 1 0 1372
assign 1 0 1375
assign 1 0 1379
return 1 0 1383
return 1 0 1386
assign 1 0 1389
assign 1 0 1393
return 1 0 1397
return 1 0 1400
assign 1 0 1403
assign 1 0 1407
return 1 0 1411
return 1 0 1414
assign 1 0 1417
assign 1 0 1421
return 1 0 1425
return 1 0 1428
assign 1 0 1431
assign 1 0 1435
return 1 0 1439
return 1 0 1442
assign 1 0 1445
assign 1 0 1449
return 1 0 1453
return 1 0 1456
assign 1 0 1459
assign 1 0 1463
return 1 0 1467
return 1 0 1470
assign 1 0 1473
assign 1 0 1477
return 1 0 1481
return 1 0 1484
assign 1 0 1487
assign 1 0 1491
return 1 0 1495
return 1 0 1498
assign 1 0 1501
assign 1 0 1505
return 1 0 1509
return 1 0 1512
assign 1 0 1515
assign 1 0 1519
return 1 0 1523
return 1 0 1526
assign 1 0 1529
assign 1 0 1533
return 1 0 1537
return 1 0 1540
assign 1 0 1543
assign 1 0 1547
return 1 0 1551
return 1 0 1554
assign 1 0 1557
assign 1 0 1561
return 1 0 1565
return 1 0 1568
assign 1 0 1571
assign 1 0 1575
return 1 0 1579
return 1 0 1582
assign 1 0 1585
assign 1 0 1589
return 1 0 1593
return 1 0 1596
assign 1 0 1599
assign 1 0 1603
return 1 0 1607
return 1 0 1610
assign 1 0 1613
assign 1 0 1617
return 1 0 1621
return 1 0 1624
assign 1 0 1627
assign 1 0 1631
return 1 0 1635
return 1 0 1638
assign 1 0 1641
assign 1 0 1645
return 1 0 1649
return 1 0 1652
assign 1 0 1655
assign 1 0 1659
return 1 0 1663
return 1 0 1666
assign 1 0 1669
assign 1 0 1673
return 1 0 1677
return 1 0 1680
assign 1 0 1683
assign 1 0 1687
return 1 0 1691
return 1 0 1694
assign 1 0 1697
assign 1 0 1701
return 1 0 1705
return 1 0 1708
assign 1 0 1711
assign 1 0 1715
return 1 0 1719
return 1 0 1722
assign 1 0 1725
assign 1 0 1729
return 1 0 1733
return 1 0 1736
assign 1 0 1739
assign 1 0 1743
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1605752359: return bem_many_0();
case -197180620: return bem_echo_0();
case 1514330702: return bem_fromFileGetDirect_0();
case -1769469261: return bem_signatureChangedGetDirect_0();
case -919772434: return bem_serializeToString_0();
case -2089752157: return bem_directMethodsGet_0();
case 1623987490: return bem_serializeContents_0();
case -977356120: return bem_fieldNamesGet_0();
case 1723987264: return bem_integratedGet_0();
case -250567657: return bem_fromFileGet_0();
case 916233336: return bem_newMtdsGet_0();
case 313446087: return bem_directMethodsGetDirect_0();
case -331909812: return bem_mtdMapGetDirect_0();
case -783243456: return bem_allAncestorsCloseGetDirect_0();
case 619304343: return bem_hashGet_0();
case 1656179264: return bem_allTypesGet_0();
case 231110866: return bem_foreignClassesGetDirect_0();
case 1576417178: return bem_new_0();
case 1431969603: return bem_namepathGet_0();
case 1116831429: return bem_superNpGetDirect_0();
case 237156531: return bem_superNpGet_0();
case -295794371: return bem_integratedGetDirect_0();
case 1684475169: return bem_postLoad_0();
case 609427924: return bem_usesGet_0();
case -1836757512: return bem_copy_0();
case -1555398674: return bem_iCheckedGet_0();
case 1636169443: return bem_mtdListGetDirect_0();
case -1345279295: return bem_isLocalGet_0();
case 471486056: return bem_newMtdsGetDirect_0();
case 500389220: return bem_print_0();
case 1480274977: return bem_depthGet_0();
case -1895797969: return bem_fieldIteratorGet_0();
case 1171311734: return bem_libNameGetDirect_0();
case 288541394: return bem_isNotNullGet_0();
case -601080887: return bem_directPropertiesGet_0();
case 1733513513: return bem_deserializeClassNameGet_0();
case 940407249: return bem_directPropertiesGetDirect_0();
case 868760417: return bem_serializationIteratorGet_0();
case 1148186102: return bem_toAny_0();
case 1162151132: return bem_maxMtdxGet_0();
case -401093750: return bem_allTypesGetDirect_0();
case 868781612: return bem_isFinalGet_0();
case 2088053405: return bem_allAncestorsCloseGet_0();
case -1210381096: return bem_defMtdsGet_0();
case 620699801: return bem_allNamesGet_0();
case -236639957: return bem_allNamesGetDirect_0();
case 594617573: return bem_signatureChangedGet_0();
case 1452564531: return bem_toString_0();
case -1631557130: return bem_mtdListGet_0();
case 293010685: return bem_namepathGetDirect_0();
case 141983605: return bem_sourceFileNameGet_0();
case 528048828: return bem_depthGetDirect_0();
case -634521182: return bem_mtdMapGet_0();
case -866118742: return bem_isNotNullGetDirect_0();
case 1275103320: return bem_libNameGet_0();
case 1979431299: return bem_ptyMapGetDirect_0();
case 415409960: return bem_usesGetDirect_0();
case -1867381336: return bem_signatureCheckedGet_0();
case 664965321: return bem_isFinalGetDirect_0();
case 1638567617: return bem_newMbrsGet_0();
case 1826221706: return bem_ptyListGet_0();
case -978724962: return bem_tagGet_0();
case -464967776: return bem_classNameGet_0();
case -757699318: return bem_iteratorGet_0();
case -374746704: return bem_hasDefaultGet_0();
case 1928293906: return bem_once_0();
case -699742583: return bem_signatureCheckedGetDirect_0();
case -478141978: return bem_newMbrsGetDirect_0();
case 127472467: return bem_superListGet_0();
case -634526855: return bem_superListGetDirect_0();
case -170971854: return bem_ptyMapGet_0();
case 1003058830: return bem_iCheckedGetDirect_0();
case -178342989: return bem_foreignClassesGet_0();
case -574639786: return bem_defMtdsGetDirect_0();
case -1935411337: return bem_isLocalGetDirect_0();
case 1046164825: return bem_ptyListGetDirect_0();
case 438244040: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2042750365: return bem_signatureCheckedSetDirect_1(bevd_0);
case 1325153058: return bem_superNpSet_1(bevd_0);
case -1370861903: return bem_otherClass_1(bevd_0);
case -1478855850: return bem_sameClass_1(bevd_0);
case -648517549: return bem_newMbrsSetDirect_1(bevd_0);
case -679137521: return bem_foreignClassesSet_1(bevd_0);
case 416661969: return bem_directPropertiesSet_1(bevd_0);
case -977471415: return bem_usesSet_1(bevd_0);
case 1455200885: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 559985449: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -251803646: return bem_allAncestorsCloseSet_1(bevd_0);
case 177273835: return bem_notEquals_1(bevd_0);
case -1034514739: return bem_allTypesSetDirect_1(bevd_0);
case -1868285108: return bem_def_1(bevd_0);
case 1750766936: return bem_superNpSetDirect_1(bevd_0);
case -1998220414: return bem_namepathSetDirect_1(bevd_0);
case 348433454: return bem_ptyListSet_1(bevd_0);
case -1042498189: return bem_loadClass_1(bevd_0);
case -672436418: return bem_iCheckedSet_1(bevd_0);
case 686365907: return bem_newMtdsSet_1(bevd_0);
case -188028197: return bem_directMethodsSetDirect_1(bevd_0);
case -1027935143: return bem_usesSetDirect_1(bevd_0);
case -160841596: return bem_isFinalSet_1(bevd_0);
case -1386227183: return bem_equals_1(bevd_0);
case -189465611: return bem_isNotNullSet_1(bevd_0);
case -925234766: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1303050663: return bem_signatureCheckedSet_1(bevd_0);
case 965973322: return bem_depthSet_1(bevd_0);
case 1051023847: return bem_ptyListSetDirect_1(bevd_0);
case -1484254712: return bem_allNamesSetDirect_1(bevd_0);
case -266688333: return bem_namepathSet_1(bevd_0);
case -1302299898: return bem_allAncestorsCloseSetDirect_1(bevd_0);
case -525860295: return bem_directPropertiesSetDirect_1(bevd_0);
case 1376253472: return bem_allNamesSet_1(bevd_0);
case 1698026019: return bem_new_1(bevd_0);
case 684864423: return bem_integratedSet_1(bevd_0);
case 743631706: return bem_allTypesSet_1(bevd_0);
case 167766576: return bem_fromFileSet_1(bevd_0);
case 1016435319: return bem_sameObject_1(bevd_0);
case 140576519: return bem_undef_1(bevd_0);
case -627194052: return bem_newMbrsSet_1(bevd_0);
case 833056894: return bem_isNotNullSetDirect_1(bevd_0);
case -1724832529: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -30582739: return bem_iCheckedSetDirect_1(bevd_0);
case -1636413316: return bem_defMtdsSet_1(bevd_0);
case -1049836115: return bem_isLocalSet_1(bevd_0);
case 431616634: return bem_fromFileSetDirect_1(bevd_0);
case -2101372703: return bem_integratedSetDirect_1(bevd_0);
case 637200623: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1140122456: return bem_sameType_1(bevd_0);
case -1043597421: return bem_signatureChangedSet_1(bevd_0);
case -2141145390: return bem_ptyMapSetDirect_1(bevd_0);
case -1820354251: return bem_mtdListSet_1(bevd_0);
case -777223486: return bem_signatureChangedSetDirect_1(bevd_0);
case -1420317727: return bem_defMtdsSetDirect_1(bevd_0);
case -1360089788: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1158572731: return bem_otherType_1(bevd_0);
case 1764612179: return bem_isLocalSetDirect_1(bevd_0);
case 1874138335: return bem_newMtdsSetDirect_1(bevd_0);
case 2072444885: return bem_depthSetDirect_1(bevd_0);
case -1434700226: return bem_libNameSet_1(bevd_0);
case 2141085532: return bem_undefined_1(bevd_0);
case 191323429: return bem_mtdMapSetDirect_1(bevd_0);
case -1750009071: return bem_isFinalSetDirect_1(bevd_0);
case -903511281: return bem_directMethodsSet_1(bevd_0);
case -445661276: return bem_mtdListSetDirect_1(bevd_0);
case -38727455: return bem_libNameSetDirect_1(bevd_0);
case 224167801: return bem_foreignClassesSetDirect_1(bevd_0);
case -2080355933: return bem_defined_1(bevd_0);
case -2132214720: return bem_superListSet_1(bevd_0);
case 1108388022: return bem_copyTo_1(bevd_0);
case 659707544: return bem_superListSetDirect_1(bevd_0);
case 75409902: return bem_ptyMapSet_1(bevd_0);
case -1665803784: return bem_mtdMapSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1674698361: return bem_checkInheritance_2(bevd_0, bevd_1);
case -403604142: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -953745911: return bem_new_2(bevd_0, bevd_1);
case 1832424834: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1387375867: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1429864581: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809509937: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1155977356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 858274939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1653180572: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildClassSyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_8_BuildClassSyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildClassSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_inst = (BEC_2_5_8_BuildClassSyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_type;
}
}
