package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_19_SystemInvocationException extends BEC_2_6_9_SystemException {
public BEC_2_6_19_SystemInvocationException() { }
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_inst;

public static BET_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 254283761: return bem_classNameGet_0();
case 32986096: return bem_tagGet_0();
case -857413750: return bem_descriptionGet_0();
case -335200426: return bem_langGet_0();
case 1337499076: return bem_fieldIteratorGet_0();
case -434766936: return bem_many_0();
case -1639952368: return bem_framesTextGetDirect_0();
case -1193538733: return bem_echo_0();
case 1814565119: return bem_klassNameGetDirect_0();
case -1449015112: return bem_emitLangGetDirect_0();
case 1708691670: return bem_klassNameGet_0();
case -1667230363: return bem_new_0();
case -2068645774: return bem_toString_0();
case 656174411: return bem_iteratorGet_0();
case -364835164: return bem_translatedGet_0();
case 1258540231: return bem_print_0();
case 1043653138: return bem_framesGetDirect_0();
case -1723302242: return bem_emitLangGet_0();
case -23495678: return bem_methodNameGet_0();
case -1976477233: return bem_vvGetDirect_0();
case 181316061: return bem_serializeContents_0();
case 1648944132: return bem_translateEmittedException_0();
case 1559646396: return bem_methodNameGetDirect_0();
case 1806144780: return bem_framesTextGet_0();
case -750795685: return bem_framesGet_0();
case -1623758382: return bem_fileNameGet_0();
case 192923601: return bem_lineNumberGet_0();
case 1333189262: return bem_copy_0();
case -1134589630: return bem_serializeToString_0();
case -1069872570: return bem_getFrameText_0();
case 1887791078: return bem_toAny_0();
case 611274904: return bem_vvGet_0();
case -152298688: return bem_translateEmittedExceptionInner_0();
case 1104438617: return bem_serializationIteratorGet_0();
case -810892117: return bem_sourceFileNameGet_0();
case 238716313: return bem_once_0();
case -1982045096: return bem_lineNumberGetDirect_0();
case -1916545082: return bem_hashGet_0();
case -493526692: return bem_translatedGetDirect_0();
case 1682074595: return bem_fileNameGetDirect_0();
case -135939427: return bem_descriptionGetDirect_0();
case 470335985: return bem_fieldNamesGet_0();
case -1742789838: return bem_langGetDirect_0();
case 1422294520: return bem_create_0();
case 1433312714: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1083248871: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -304085546: return bem_klassNameSet_1(bevd_0);
case -25458794: return bem_framesTextSetDirect_1(bevd_0);
case 1537925034: return bem_framesSet_1(bevd_0);
case -968969729: return bem_fileNameSetDirect_1(bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case 1854448500: return bem_emitLangSet_1(bevd_0);
case 1598801759: return bem_vvSet_1(bevd_0);
case 252756311: return bem_vvSetDirect_1(bevd_0);
case 1265043700: return bem_descriptionSet_1(bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case -887751171: return bem_emitLangSetDirect_1(bevd_0);
case -184175961: return bem_klassNameSetDirect_1(bevd_0);
case -1742780291: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -91969480: return bem_translatedSet_1(bevd_0);
case 226161992: return bem_framesSetDirect_1(bevd_0);
case -1335631064: return bem_fileNameSet_1(bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case 1290216463: return bem_def_1(bevd_0);
case 454461474: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -588560885: return bem_lineNumberSet_1(bevd_0);
case -1013582118: return bem_lineNumberSetDirect_1(bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case -1612212657: return bem_methodNameSetDirect_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -437060655: return bem_descriptionSetDirect_1(bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case -2136394139: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1940151461: return bem_methodNameSet_1(bevd_0);
case 729030396: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -494057614: return bem_framesTextSet_1(bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -2101960569: return bem_langSetDirect_1(bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case 1948301764: return bem_new_1(bevd_0);
case 1634548560: return bem_langSet_1(bevd_0);
case 798567198: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case 1297978910: return bem_translatedSetDirect_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 462334666: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemInvocationException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_19_SystemInvocationException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemInvocationException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst = (BEC_2_6_19_SystemInvocationException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_type;
}
}
