package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_19_SystemInvocationException extends BEC_2_6_9_SystemException {
public BEC_2_6_19_SystemInvocationException() { }
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_inst;

public static BET_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -777617664: return bem_iteratorGet_0();
case -1727963940: return bem_framesTextGet_0();
case -355672893: return bem_hashGet_0();
case -865332030: return bem_descriptionGet_0();
case 1844538075: return bem_vvGet_0();
case 1630760726: return bem_toString_0();
case 1103672703: return bem_print_0();
case 1960046785: return bem_translatedGet_0();
case 1503899631: return bem_klassNameGet_0();
case 1031735678: return bem_langGet_0();
case -1864811962: return bem_framesGet_0();
case -496842367: return bem_new_0();
case 92890873: return bem_getFrameText_0();
case 1152967006: return bem_copy_0();
case 1316029283: return bem_fileNameGet_0();
case 1439653353: return bem_create_0();
case 736212465: return bem_lineNumberGet_0();
case -249981475: return bem_emitLangGet_0();
case 1292881310: return bem_methodNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1893928562: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 863284586: return bem_notEquals_1(bevd_0);
case -1721047471: return bem_def_1(bevd_0);
case -1325034271: return bem_framesSet_1(bevd_0);
case -1959331138: return bem_emitLangSet_1(bevd_0);
case -1109268004: return bem_new_1(bevd_0);
case 445187513: return bem_equals_1(bevd_0);
case -938105188: return bem_undef_1(bevd_0);
case -1663218818: return bem_framesTextSet_1(bevd_0);
case 430291623: return bem_vvSet_1(bevd_0);
case 906556457: return bem_fileNameSet_1(bevd_0);
case -587753182: return bem_copyTo_1(bevd_0);
case 996918756: return bem_translatedSet_1(bevd_0);
case 634637210: return bem_langSet_1(bevd_0);
case -1770527512: return bem_methodNameSet_1(bevd_0);
case 1783521427: return bem_descriptionSet_1(bevd_0);
case -1250946597: return bem_print_1(bevd_0);
case -563602503: return bem_klassNameSet_1(bevd_0);
case -158121229: return bem_lineNumberSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -558969549: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2056786157: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2082389725: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1197567931: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1987186150: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemInvocationException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_19_SystemInvocationException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemInvocationException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst = (BEC_2_6_19_SystemInvocationException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_type;
}
}
