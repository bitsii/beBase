package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {91, 91, 95, 96, 97, 98, 99, 100};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 91 13
new 0 91 13
new 1 91 14
assign 1 95 18
new 1 95 18
assign 1 96 19
assign 1 97 20
new 0 97 20
assign 1 98 21
new 0 98 21
assign 1 99 22
new 0 99 22
assign 1 100 23
new 0 100 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -329338674: return bem_clear_0();
case -479209354: return bem_hashGet_0();
case -1255628091: return bem_tagGet_0();
case -200179425: return bem_relGet_0();
case -1531622162: return bem_copy_0();
case -1009904954: return bem_keyValueIteratorGet_0();
case 1663979256: return bem_iteratorGet_0();
case -1084760201: return bem_create_0();
case -2026346603: return bem_new_0();
case -1327609792: return bem_valueIteratorGet_0();
case 1964378555: return bem_serializeContents_0();
case 1154933275: return bem_serializationIteratorGet_0();
case 75621306: return bem_isEmptyGet_0();
case 1670566168: return bem_sourceFileNameGet_0();
case 102887971: return bem_fieldIteratorGet_0();
case 1763919506: return bem_slotsGet_0();
case 2115120452: return bem_serializeToString_0();
case -1259431415: return bem_keysGet_0();
case 371307175: return bem_sizeGet_0();
case 2000976017: return bem_setIteratorGet_0();
case -2092271774: return bem_echo_0();
case -572994111: return bem_moduGet_0();
case -333394073: return bem_toString_0();
case -525773786: return bem_innerPutAddedGet_0();
case -1246474780: return bem_keyIteratorGet_0();
case -1078611681: return bem_multiGet_0();
case -1471006545: return bem_mapIteratorGet_0();
case -881487671: return bem_baseNodeGet_0();
case 269301519: return bem_once_0();
case 1891870089: return bem_print_0();
case -1874792683: return bem_valuesGet_0();
case 1092154910: return bem_classNameGet_0();
case -415539380: return bem_many_0();
case -911546686: return bem_toAny_0();
case -149497015: return bem_notEmptyGet_0();
case 947727070: return bem_nodesGet_0();
case -127984856: return bem_deserializeClassNameGet_0();
case 1457993794: return bem_nodeIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -215188181: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1574704139: return bem_copyTo_1(bevd_0);
case -91281186: return bem_undef_1(bevd_0);
case -1318320119: return bem_baseNodeSet_1(bevd_0);
case -2088579865: return bem_otherType_1(bevd_0);
case 308292842: return bem_get_1(bevd_0);
case -1668025579: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 979510697: return bem_relSet_1(bevd_0);
case -605366432: return bem_defined_1(bevd_0);
case 1077702335: return bem_equals_1(bevd_0);
case 1674374988: return bem_sameObject_1(bevd_0);
case 377248223: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2109819584: return bem_def_1(bevd_0);
case 1133099499: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1636743733: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -754611247: return bem_delete_1(bevd_0);
case -278876230: return bem_slotsSet_1(bevd_0);
case -1428410138: return bem_sizeSet_1(bevd_0);
case -2027519443: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 8626873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -266225430: return bem_notEquals_1(bevd_0);
case 372613641: return bem_addValue_1(bevd_0);
case -219829968: return bem_put_1(bevd_0);
case -405307321: return bem_has_1(bevd_0);
case -1172037343: return bem_multiSet_1(bevd_0);
case -1020405356: return bem_otherClass_1(bevd_0);
case -2035847518: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1139979118: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1949805813: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1913219356: return bem_moduSet_1(bevd_0);
case 1980041008: return bem_undefined_1(bevd_0);
case -326579864: return bem_sameClass_1(bevd_0);
case 380815729: return bem_innerPutAddedSet_1(bevd_0);
case -250259457: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -834006616: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 926020368: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 884440643: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1571889490: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -730327046: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1129799281: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -783330142: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1456214761: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743986647: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220078438: return bem_put_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1671101462: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
