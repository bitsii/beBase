package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {90, 90, 94, 95, 96, 97, 98, 99};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 90 13
new 0 90 13
new 1 90 14
assign 1 94 18
new 1 94 18
assign 1 95 19
assign 1 96 20
new 0 96 20
assign 1 97 21
new 0 97 21
assign 1 98 22
new 0 98 22
assign 1 99 23
new 0 99 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1171876871: return bem_slotsGetDirect_0();
case -584739176: return bem_moduGetDirect_0();
case 1099447992: return bem_fieldNamesGet_0();
case 393738758: return bem_serializeToString_0();
case -422398160: return bem_nodeIteratorGet_0();
case 1456361496: return bem_multiGetDirect_0();
case -124285366: return bem_once_0();
case -1778027080: return bem_isEmptyGet_0();
case 1665763404: return bem_innerPutAddedGetDirect_0();
case -359858819: return bem_valuesGet_0();
case -658254226: return bem_keyIteratorGet_0();
case -224465120: return bem_sourceFileNameGet_0();
case 583053744: return bem_relGet_0();
case -2081219260: return bem_baseNodeGet_0();
case 1073764355: return bem_innerPutAddedGet_0();
case -147981807: return bem_relGetDirect_0();
case -1752369208: return bem_keyValueIteratorGet_0();
case -634018133: return bem_tagGet_0();
case -2031839191: return bem_serializationIteratorGet_0();
case 1429560218: return bem_mapIteratorGet_0();
case 2062571444: return bem_keysGet_0();
case -417965794: return bem_clear_0();
case 1072278304: return bem_sizeGetDirect_0();
case -1344716247: return bem_slotsGet_0();
case 2146604653: return bem_new_0();
case 569361306: return bem_iteratorGet_0();
case 740892297: return bem_sizeGet_0();
case 641839943: return bem_toAny_0();
case -2007275567: return bem_many_0();
case -1092510954: return bem_copy_0();
case -941132809: return bem_moduGet_0();
case -881577546: return bem_classNameGet_0();
case -543819359: return bem_notEmptyGet_0();
case 908678857: return bem_print_0();
case 2144693643: return bem_deserializeClassNameGet_0();
case 971841201: return bem_fieldIteratorGet_0();
case -212742483: return bem_echo_0();
case 148544119: return bem_toString_0();
case -1339898518: return bem_nodesGet_0();
case 1782351683: return bem_serializeContents_0();
case -1750720088: return bem_hashGet_0();
case -551876293: return bem_valueIteratorGet_0();
case 750839292: return bem_baseNodeGetDirect_0();
case -653750385: return bem_create_0();
case 224654807: return bem_multiGet_0();
case -431640049: return bem_setIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1928510621: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 663630888: return bem_baseNodeSetDirect_1(bevd_0);
case 389340449: return bem_otherType_1(bevd_0);
case -872115670: return bem_defined_1(bevd_0);
case -642151924: return bem_innerPutAddedSetDirect_1(bevd_0);
case -764721980: return bem_multiSet_1(bevd_0);
case 1236734559: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -969296775: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -884607798: return bem_def_1(bevd_0);
case 887663957: return bem_delete_1(bevd_0);
case -704016930: return bem_moduSet_1(bevd_0);
case 326949551: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1367146792: return bem_sameClass_1(bevd_0);
case -1979724751: return bem_addValue_1(bevd_0);
case 236131489: return bem_sizeSetDirect_1(bevd_0);
case -1997952645: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1508577220: return bem_relSet_1(bevd_0);
case -811636854: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1926763067: return bem_get_1(bevd_0);
case 338229476: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -249326151: return bem_copyTo_1(bevd_0);
case -909123096: return bem_put_1(bevd_0);
case -1586811529: return bem_undefined_1(bevd_0);
case 794287143: return bem_slotsSetDirect_1(bevd_0);
case 1730397553: return bem_undef_1(bevd_0);
case -1519516879: return bem_equals_1(bevd_0);
case 75968176: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1446250233: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1796044601: return bem_moduSetDirect_1(bevd_0);
case -1069040816: return bem_has_1(bevd_0);
case -235508366: return bem_sizeSet_1(bevd_0);
case -1565662060: return bem_sameObject_1(bevd_0);
case 60460661: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -666280331: return bem_slotsSet_1(bevd_0);
case 320865341: return bem_relSetDirect_1(bevd_0);
case 1030347818: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1652733060: return bem_baseNodeSet_1(bevd_0);
case 45351873: return bem_multiSetDirect_1(bevd_0);
case -448360789: return bem_otherClass_1(bevd_0);
case -359346681: return bem_sameType_1(bevd_0);
case 1703616583: return bem_notEquals_1(bevd_0);
case -1797897868: return bem_innerPutAddedSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -350858263: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 29395685: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 827793836: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1899980628: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1061986002: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1194360433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -454033656: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 696322560: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 593713857: return bem_put_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1943026948: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
