package be;
/* IO:File: source/extended/IdentityMap.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {37, 37, 41, 42, 43, 44, 45, 46};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 37 13
new 0 37 13
new 1 37 14
assign 1 41 18
new 1 41 18
assign 1 42 19
assign 1 43 20
new 0 43 20
assign 1 44 21
new 0 44 21
assign 1 45 22
new 0 45 22
assign 1 46 23
new 0 46 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -334139513: return bem_toString_0();
case 323586228: return bem_hashGet_0();
case -1349505949: return bem_sizeGet_0();
case -1034623811: return bem_keysGet_0();
case 1406439869: return bem_iteratorGet_0();
case 210402723: return bem_keyIteratorGet_0();
case -1182295625: return bem_clear_0();
case -582936884: return bem_copy_0();
case 533535769: return bem_isEmptyGet_0();
case -1109080542: return bem_serializeToString_0();
case -1477451991: return bem_bucketsGet_0();
case 172866: return bem_nodeIteratorGet_0();
case 1968745185: return bem_valuesGet_0();
case -171679157: return bem_mapIteratorGet_0();
case 2095715431: return bem_keyValueIteratorGet_0();
case -31592683: return bem_setIteratorGet_0();
case -507985549: return bem_new_0();
case -1277691905: return bem_create_0();
case 601816268: return bem_valueIteratorGet_0();
case -725978498: return bem_serializationIteratorGet_0();
case -1904974225: return bem_print_0();
case 1581599700: return bem_nodesGet_0();
case -1959831874: return bem_notEmptyGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -269589400: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 153961100: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1099146002: return bem_sizeSet_1(bevd_0);
case 730183103: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -900715304: return bem_notEquals_1(bevd_0);
case -259329005: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1497768755: return bem_get_1(bevd_0);
case -1472767207: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 536875010: return bem_addValue_1(bevd_0);
case -1958108314: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 18112218: return bem_bucketsSet_1(bevd_0);
case -1564500571: return bem_def_1(bevd_0);
case -1412823423: return bem_has_1(bevd_0);
case -1263745685: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1441152686: return bem_equals_1(bevd_0);
case 796824038: return bem_delete_1(bevd_0);
case 2083304692: return bem_copyTo_1(bevd_0);
case 1894221943: return bem_undef_1(bevd_0);
case 959821348: return bem_put_1(bevd_0);
case -2049829498: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1170875190: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -506946318: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1280428261: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1594212926: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2064104272: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -191370959: return bem_put_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 40552174: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
