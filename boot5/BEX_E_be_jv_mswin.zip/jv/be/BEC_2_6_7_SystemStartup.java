package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_7_SystemStartup extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemStartup() { }
private static byte[] becc_BEC_2_6_7_SystemStartup_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70};
private static byte[] becc_BEC_2_6_7_SystemStartup_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemStartup_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
public static BEC_2_6_7_SystemStartup bece_BEC_2_6_7_SystemStartup_bevs_inst;

public static BET_2_6_7_SystemStartup bece_BEC_2_6_7_SystemStartup_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_7_SystemStartup bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_7_SystemStartup bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_ta_ph.bem_argsGet_0();
bevt_2_ta_ph = bevp_args.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(136, bece_BEC_2_6_7_SystemStartup_bels_0));
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 32*/
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_7_ta_ph = bevp_args.bem_get_1(bevt_8_ta_ph);
bevt_6_ta_ph = bem_createInstance_1((BEC_2_4_6_TextString) bevt_7_ta_ph );
bevl_x = bevt_6_ta_ph.bemd_0(1847639727);
bevt_9_ta_ph = bevl_x.bemd_0(-1634438305);
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_7_SystemStartup bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemStartup bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {30, 30, 31, 31, 31, 31, 32, 32, 32, 34, 34, 34, 34, 35, 35, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 33, 34, 35, 40, 41, 42, 43, 45, 46, 47, 48, 49, 50, 53, 56, 59, 63};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 30 31
new 0 30 31
assign 1 30 32
argsGet 0 30 32
assign 1 31 33
sizeGet 0 31 33
assign 1 31 34
new 0 31 34
assign 1 31 35
lesser 1 31 40
assign 1 32 41
new 0 32 41
assign 1 32 42
new 1 32 42
throw 1 32 43
assign 1 34 45
new 0 34 45
assign 1 34 46
get 1 34 46
assign 1 34 47
createInstance 1 34 47
assign 1 34 48
new 0 34 48
assign 1 35 49
main 0 35 49
return 1 35 50
return 1 0 53
return 1 0 56
assign 1 0 59
assign 1 0 63
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 38127485: return bem_iteratorGet_0();
case -1634438305: return bem_main_0();
case 206544563: return bem_argsGet_0();
case 854710191: return bem_create_0();
case 764630274: return bem_argsGetDirect_0();
case 636345: return bem_print_0();
case 2061432375: return bem_tagGet_0();
case -1849826772: return bem_default_0();
case 1847639727: return bem_new_0();
case 793589441: return bem_classNameGet_0();
case -1331374769: return bem_toString_0();
case -1818293830: return bem_fieldNamesGet_0();
case -1508036637: return bem_copy_0();
case -22788464: return bem_hashGet_0();
case -593469656: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 882589836: return bem_sameObject_1(bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
case 1281048000: return bem_notEquals_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case -502376443: return bem_equals_1(bevd_0);
case 1990280778: return bem_argsSetDirect_1(bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case -1398221654: return bem_argsSet_1(bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemStartup_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemStartup_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemStartup();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_inst = (BEC_2_6_7_SystemStartup) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_type;
}
}
