package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_6_BuildMethod extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
private static byte[] becc_BEC_2_5_6_BuildMethod_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_5_6_BuildMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_0 = {0x20};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
public static BEC_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_inst;

public static BET_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public BEC_2_5_6_BuildMethod bem_new_0() throws Throwable {
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = be.BECS_Runtime.boolFalse;
bevp_tryDepth = (new BEC_2_4_3_MathInt(0));
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_amax = (new BEC_2_4_3_MathInt(0));
bevp_hmax = (new BEC_2_4_3_MathInt(0));
bevp_mmax = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_className_1(this);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_6_BuildMethod_bels_0));
bevl_ret = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
if (bevp_name == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 182*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMethod_bels_1));
bevt_4_ta_ph = bevl_ret.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
} /* Line: 183*/
if (bevp_numargs == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 185*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_6_BuildMethod_bels_2));
bevt_8_ta_ph = bevl_ret.bem_add_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_numargs.bem_toString_0();
bevl_ret = bevt_8_ta_ph.bem_add_1(bevt_10_ta_ph);
} /* Line: 186*/
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() throws Throwable {
return bevp_property;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_property = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() throws Throwable {
return bevp_rtype;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rtype = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() throws Throwable {
return bevp_tmpVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tmpVars = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() throws Throwable {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() throws Throwable {
return bevp_tryDepth;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() throws Throwable {
return bevp_amax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() throws Throwable {
return bevp_hmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() throws Throwable {
return bevp_mmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {166, 167, 168, 169, 170, 171, 173, 174, 175, 181, 181, 181, 181, 182, 182, 183, 183, 183, 183, 185, 185, 186, 186, 186, 186, 188, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 31, 32, 33, 34, 35, 36, 37, 38, 54, 55, 56, 57, 58, 63, 64, 65, 66, 67, 69, 74, 75, 76, 77, 78, 80, 83, 86, 90, 93, 97, 100, 104, 107, 111, 114, 118, 121, 125, 128, 132, 135, 139, 142, 146, 149, 153, 156, 160, 163, 167, 170, 174, 177, 181, 184};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 166 30
new 0 166 30
assign 1 167 31
new 0 167 31
assign 1 168 32
new 0 168 32
assign 1 169 33
new 0 169 33
assign 1 170 34
new 0 170 34
assign 1 171 35
new 0 171 35
assign 1 173 36
new 0 173 36
assign 1 174 37
new 0 174 37
assign 1 175 38
new 0 175 38
assign 1 181 54
new 0 181 54
assign 1 181 55
className 1 181 55
assign 1 181 56
new 0 181 56
assign 1 181 57
add 1 181 57
assign 1 182 58
def 1 182 63
assign 1 183 64
new 0 183 64
assign 1 183 65
add 1 183 65
assign 1 183 66
toString 0 183 66
assign 1 183 67
add 1 183 67
assign 1 185 69
def 1 185 74
assign 1 186 75
new 0 186 75
assign 1 186 76
add 1 186 76
assign 1 186 77
toString 0 186 77
assign 1 186 78
add 1 186 78
return 1 188 80
return 1 0 83
assign 1 0 86
return 1 0 90
assign 1 0 93
return 1 0 97
assign 1 0 100
return 1 0 104
assign 1 0 107
return 1 0 111
assign 1 0 114
return 1 0 118
assign 1 0 121
return 1 0 125
assign 1 0 128
return 1 0 132
assign 1 0 135
return 1 0 139
assign 1 0 142
return 1 0 146
assign 1 0 149
return 1 0 153
assign 1 0 156
return 1 0 160
assign 1 0 163
return 1 0 167
assign 1 0 170
return 1 0 174
assign 1 0 177
return 1 0 181
assign 1 0 184
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1629622782: return bem_isFinalGet_0();
case 870688782: return bem_amaxGet_0();
case -554230492: return bem_propertyGet_0();
case -1641977263: return bem_tmpVarsGet_0();
case -319080989: return bem_hmaxGet_0();
case -1928594171: return bem_rtypeGet_0();
case -29696647: return bem_orgNameGet_0();
case -509281348: return bem_new_0();
case 865010846: return bem_numargsGet_0();
case 1967536104: return bem_nameGet_0();
case 1848528939: return bem_anyMapGet_0();
case 916511308: return bem_print_0();
case -1436588716: return bem_copy_0();
case 1377393171: return bem_iteratorGet_0();
case 265452285: return bem_tryDepthGet_0();
case 1991935836: return bem_orderedVarsGet_0();
case 572942595: return bem_create_0();
case 321674636: return bem_mmaxGet_0();
case 964424974: return bem_isGenAccessorGet_0();
case 593600550: return bem_toString_0();
case 1247691513: return bem_tmpCntGet_0();
case -593179039: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 740081825: return bem_notEquals_1(bevd_0);
case -1686309188: return bem_tmpCntSet_1(bevd_0);
case 1682879882: return bem_hmaxSet_1(bevd_0);
case 538901379: return bem_tmpVarsSet_1(bevd_0);
case -967241751: return bem_isGenAccessorSet_1(bevd_0);
case 152454017: return bem_def_1(bevd_0);
case 77539498: return bem_numargsSet_1(bevd_0);
case -257664443: return bem_equals_1(bevd_0);
case -1239385327: return bem_undef_1(bevd_0);
case -1975251528: return bem_propertySet_1(bevd_0);
case -932987341: return bem_nameSet_1(bevd_0);
case 362529916: return bem_amaxSet_1(bevd_0);
case -971019176: return bem_isFinalSet_1(bevd_0);
case 463793854: return bem_tryDepthSet_1(bevd_0);
case 1259253556: return bem_orderedVarsSet_1(bevd_0);
case 1566934721: return bem_rtypeSet_1(bevd_0);
case -1490966740: return bem_copyTo_1(bevd_0);
case 273639879: return bem_orgNameSet_1(bevd_0);
case 396255714: return bem_anyMapSet_1(bevd_0);
case 1330528477: return bem_mmaxSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 376456972: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2087906856: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 426315431: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -840314986: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMethod_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_6_BuildMethod_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMethod();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst = (BEC_2_5_6_BuildMethod) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_type;
}
}
