package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerMaps extends BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerMaps() { }
private static byte[] becc_BEC_2_9_4_ContainerMaps_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x73};
private static byte[] becc_BEC_2_9_4_ContainerMaps_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerMaps_bevo_0 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_inst;

public static BET_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_type;

public BEC_2_9_4_ContainerMaps bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_4_3_MathInt bevl_ls = null;
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_ls = beva_list.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerMaps_bevo_0;
bevt_0_tmpany_phold = bevl_ls.bem_add_1(bevt_1_tmpany_phold);
bevl_map = (new BEC_2_9_3_ContainerMap()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 725 */ {
if (bevl_i.bevi_int < bevl_ls.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 725 */ {
bevt_3_tmpany_phold = beva_list.bem_get_1(bevl_i);
bevl_i.bevi_int++;
bevt_5_tmpany_phold = bevl_i;
bevt_4_tmpany_phold = beva_list.bem_get_1(bevt_5_tmpany_phold);
bevl_map.bem_put_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 725 */
 else  /* Line: 725 */ {
break;
} /* Line: 725 */
} /* Line: 725 */
return bevl_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fieldsIntoMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_9_3_ContainerMap beva_res) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(-2073027086);
while (true)
 /* Line: 732 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 732 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(417140901);
bevt_2_tmpany_phold = bevl_i.bemd_0(264044638);
beva_res.bem_put_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 733 */
 else  /* Line: 732 */ {
break;
} /* Line: 732 */
} /* Line: 732 */
return beva_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapIntoFields_2(BEC_2_9_3_ContainerMap beva_from, BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(-2073027086);
while (true)
 /* Line: 739 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 739 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(417140901);
bevt_1_tmpany_phold = beva_from.bem_get_1(bevt_2_tmpany_phold);
bevl_i.bemd_1(-1367014370, bevt_1_tmpany_phold);
} /* Line: 740 */
 else  /* Line: 739 */ {
break;
} /* Line: 739 */
} /* Line: 739 */
return beva_inst;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {723, 724, 724, 724, 725, 725, 725, 726, 726, 726, 726, 725, 728, 732, 732, 733, 733, 733, 735, 739, 739, 740, 740, 740, 742};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 29, 32, 37, 38, 39, 41, 42, 43, 49, 56, 59, 61, 62, 63, 69, 76, 79, 81, 82, 83, 89};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 723 25
sizeGet 0 723 25
assign 1 724 26
new 0 724 26
assign 1 724 27
add 1 724 27
assign 1 724 28
new 1 724 28
assign 1 725 29
new 0 725 29
assign 1 725 32
lesser 1 725 37
assign 1 726 38
get 1 726 38
assign 1 726 39
incrementValue 0 726 39
assign 1 726 41
get 1 726 41
put 2 726 42
incrementValue 0 725 43
return 1 728 49
assign 1 732 56
fieldIteratorGet 0 732 56
assign 1 732 59
hasNextGet 0 732 59
assign 1 733 61
nextNameGet 0 733 61
assign 1 733 62
currentGet 0 733 62
put 2 733 63
return 1 735 69
assign 1 739 76
fieldIteratorGet 0 739 76
assign 1 739 79
hasNextGet 0 739 79
assign 1 740 81
nextNameGet 0 740 81
assign 1 740 82
get 1 740 82
currentSet 1 740 83
return 1 742 89
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 623957818: return bem_once_0();
case 1070146794: return bem_toAny_0();
case -2070113098: return bem_create_0();
case -897350462: return bem_iteratorGet_0();
case 1326542704: return bem_tagGet_0();
case -1439777293: return bem_hashGet_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case -948982310: return bem_many_0();
case 1172450247: return bem_copy_0();
case 450230894: return bem_print_0();
case 1935136194: return bem_classNameGet_0();
case 742371580: return bem_serializeToString_0();
case 1730802409: return bem_echo_0();
case 1516161879: return bem_fieldNamesGet_0();
case -2073027086: return bem_fieldIteratorGet_0();
case 2022988218: return bem_default_0();
case -61288189: return bem_serializationIteratorGet_0();
case 1660533487: return bem_serializeContents_0();
case -1556712456: return bem_new_0();
case -1750213491: return bem_sourceFileNameGet_0();
case -1476019175: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case -957438933: return bem_undef_1(bevd_0);
case -299391132: return bem_equals_1(bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case -1438493756: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 724347790: return bem_mapIntoFields_2((BEC_2_9_3_ContainerMap) bevd_0, bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1439962377: return bem_fieldsIntoMap_2(bevd_0, (BEC_2_9_3_ContainerMap) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerMaps_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerMaps_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerMaps();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst = (BEC_2_9_4_ContainerMaps) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_type;
}
}
