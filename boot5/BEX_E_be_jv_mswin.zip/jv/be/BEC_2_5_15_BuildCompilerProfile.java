package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_15_BuildCompilerProfile extends BEC_2_6_6_SystemObject {
public BEC_2_5_15_BuildCompilerProfile() { }
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72,0x50,0x72,0x6F,0x66,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_0 = {0x2E,0x65,0x78,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_1 = {0x2E,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_2 = {0x2D,0x49,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_3 = {0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_4 = {0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_5 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_6 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_7 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_8 = {0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_9 = {0x2E,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_10 = {0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_11 = {0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_12 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_13 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_14 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_15 = {0x61,0x70,0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_16 = {0x61,0x70,0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_17 = {0x2E,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_18 = {0x61,0x70,0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_19 = {0x61,0x70,0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_20 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_21 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_22 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_23 = {0x6D,0x61,0x63,0x6F,0x73};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_24 = {0x2E,0x64,0x79,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_25 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_25, 20));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_26 = {0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_26, 10));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_27 = {0x6C,0x69,0x62,0x74,0x6F,0x6F,0x6C,0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6C,0x63,0x63,0x5F,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_28 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_29 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_30 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_31 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_31, 17));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_32 = {0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_32, 4));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_33 = {0x6C,0x69,0x6E,0x75,0x78};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_34 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_35 = {0x2E,0x73,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_36 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_36, 20));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_37 = {0x20,0x2D,0x66,0x50,0x49,0x43,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_37, 7));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_38 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_38, 17));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_39 = {0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_39, 12));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_40 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_41 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_42 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_43 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_43, 17));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_44 = {0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_44, 4));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_45 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_46 = {0x2E,0x65,0x78,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_47 = {0x6D,0x73,0x76,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_48 = {0x63,0x6C,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_49 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_50 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_51 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_52 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_53 = {0x2D,0x6E,0x6F,0x6C,0x6F,0x67,0x6F,0x20,0x2D,0x4D,0x44,0x20,0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x4D,0x53,0x56,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_53, 45));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_54 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x53,0x45,0x43,0x55,0x52,0x45,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x4E,0x4F,0x4E,0x53,0x54,0x44,0x43,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_54, 76));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_55 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x44,0x4C,0x4C,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_56 = {0x20,0x2D,0x46,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_57 = {0x63,0x6F,0x70,0x79,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_58 = {0x6D,0x6B,0x64,0x69,0x72,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_59 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_60 = {0x2E,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_61 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_62 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_62, 32));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_63 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_63, 19));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_64 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_64, 37));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_65 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_66 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_67 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_68 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_68, 29));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_69 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_69, 22));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_70 = {0x65,0x78,0x65,0x45,0x78,0x74,0x4F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_70, 15));
public static BEC_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;

public static BET_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;

public BEC_2_4_6_TextString bevp_exeExt;
public BEC_2_4_6_TextString bevp_libExt;
public BEC_2_4_6_TextString bevp_ccObj;
public BEC_2_4_6_TextString bevp_cc;
public BEC_2_4_6_TextString bevp_cext;
public BEC_2_4_6_TextString bevp_oext;
public BEC_2_4_6_TextString bevp_lBuild;
public BEC_2_4_6_TextString bevp_ccout;
public BEC_2_4_6_TextString bevp_doCopy;
public BEC_2_4_6_TextString bevp_mkdirs;
public BEC_2_4_6_TextString bevp_lexe;
public BEC_2_4_6_TextString bevp_exeLibExt;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_di;
public BEC_2_4_6_TextString bevp_smac;
public BEC_2_4_6_TextString bevp_dialect;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_5_15_BuildCompilerProfile bem_new_1(BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_4_6_TextString bevl_dialectMacro = null;
BEC_2_6_6_SystemObject bevl_exeExtOverride = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
bevp_exeExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_2_tmpany_phold = beva_build.bemd_0(1110616001);
bevp_name = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(1543632707);
bevp_oext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_1));
bevp_di = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_2));
bevp_smac = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_3));
bevp_dialect = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_15_BuildCompilerProfile_bels_4));
bevl_dialectMacro = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_5));
bevt_4_tmpany_phold = beva_build.bemd_0(-831443384);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 848 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
beva_build.bemd_1(-1569901537, bevt_5_tmpany_phold);
} /* Line: 849 */
bevp_compiler = (BEC_2_4_6_TextString) beva_build.bemd_0(-831443384);
bevt_7_tmpany_phold = beva_build.bemd_0(-831443384);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_7));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(-2130755695, bevt_8_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 852 */ {
bevp_cc = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
bevp_cext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_9));
} /* Line: 854 */
 else  /* Line: 852 */ {
bevt_10_tmpany_phold = beva_build.bemd_0(-831443384);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_10));
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(-2130755695, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 855 */ {
bevp_cc = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_14));
} /* Line: 860 */
 else  /* Line: 852 */ {
bevt_13_tmpany_phold = beva_build.bemd_0(-831443384);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_15));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(-2130755695, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 861 */ {
bevp_cc = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_16));
bevp_cext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_17));
} /* Line: 864 */
 else  /* Line: 852 */ {
bevt_16_tmpany_phold = beva_build.bemd_0(-831443384);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_18));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-2130755695, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 865 */ {
bevp_cc = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_19));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_20));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_21));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_22));
} /* Line: 870 */
} /* Line: 852 */
} /* Line: 852 */
} /* Line: 852 */
bevt_20_tmpany_phold = beva_build.bemd_0(1110616001);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1543632707);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-2130755695, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 872 */ {
bevp_libExt = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevt_24_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_0;
bevt_23_tmpany_phold = bevp_cc.bem_add_1(bevt_24_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_25_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_1;
bevp_ccObj = bevt_22_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevp_lBuild = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_15_BuildCompilerProfile_bels_27));
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_28));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_29));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_30));
bevt_28_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_2;
bevt_27_tmpany_phold = bevp_cc.bem_add_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_29_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_3;
bevp_lexe = bevt_26_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 880 */
bevt_32_tmpany_phold = beva_build.bemd_0(1110616001);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_0(1543632707);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_33));
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_1(-2130755695, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 882 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 882 */ {
bevt_36_tmpany_phold = beva_build.bemd_0(1110616001);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_0(1543632707);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_34));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(-2130755695, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 882 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 882 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 882 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 882 */ {
bevp_libExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_40_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_4;
bevt_39_tmpany_phold = bevp_cc.bem_add_1(bevt_40_tmpany_phold);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_41_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_5;
bevp_ccObj = bevt_38_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_6;
bevt_43_tmpany_phold = bevp_cc.bem_add_1(bevt_44_tmpany_phold);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_45_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_7;
bevp_lBuild = bevt_42_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_40));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_41));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_42));
bevt_48_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_8;
bevt_47_tmpany_phold = bevp_cc.bem_add_1(bevt_48_tmpany_phold);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_49_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_9;
bevp_lexe = bevt_46_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 890 */
bevt_52_tmpany_phold = beva_build.bemd_0(1110616001);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(1543632707);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_45));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_1(-2130755695, bevt_53_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 892 */ {
bevp_exeExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_46));
bevt_55_tmpany_phold = beva_build.bemd_0(-831443384);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_47));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_1(-2130755695, bevt_56_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_54_tmpany_phold).bevi_bool) /* Line: 894 */ {
bevp_cc = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_48));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_49));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_50));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_51));
bevp_libExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_52));
bevt_59_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_10;
bevt_58_tmpany_phold = bevp_cc.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_60_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_11;
bevp_ccObj = bevt_57_tmpany_phold.bem_add_1(bevt_60_tmpany_phold);
bevp_lBuild = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_15_BuildCompilerProfile_bels_55));
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_56));
bevp_doCopy = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_57));
bevp_mkdirs = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_58));
bevp_lexe = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_59));
bevp_exeLibExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_60));
} /* Line: 906 */
 else  /* Line: 907 */ {
bevp_libExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_61));
bevt_63_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_12;
bevt_62_tmpany_phold = bevp_cc.bem_add_1(bevt_63_tmpany_phold);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_64_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_13;
bevp_ccObj = bevt_61_tmpany_phold.bem_add_1(bevt_64_tmpany_phold);
bevt_65_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_14;
bevp_lBuild = bevp_cc.bem_add_1(bevt_65_tmpany_phold);
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_65));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_66));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_67));
bevt_68_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_15;
bevt_67_tmpany_phold = bevp_cc.bem_add_1(bevt_68_tmpany_phold);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_69_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_16;
bevp_lexe = bevt_66_tmpany_phold.bem_add_1(bevt_69_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 915 */
} /* Line: 894 */
bevt_70_tmpany_phold = beva_build.bemd_0(-1451555458);
bevt_72_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_17;
bevt_74_tmpany_phold = beva_build.bemd_0(1110616001);
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(1543632707);
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_exeExtOverride = bevt_70_tmpany_phold.bemd_1(-747864538, bevt_71_tmpany_phold);
if (bevl_exeExtOverride == null) {
bevt_75_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 919 */ {
bevt_77_tmpany_phold = bevl_exeExtOverride.bemd_0(-401222514);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 919 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 919 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 919 */
 else  /* Line: 919 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 919 */ {
bevp_exeExt = (BEC_2_4_6_TextString) bevl_exeExtOverride.bemd_0(-401222514);
} /* Line: 920 */
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doMakeDirs_1(BEC_2_4_6_TextString beva_path) throws Throwable {
BEC_2_2_4_IOFile bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(beva_path);
bevt_0_tmpany_phold.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeExtGet_0() throws Throwable {
return bevp_exeExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_exeExtGetDirect_0() throws Throwable {
return bevp_exeExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_exeExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libExtGet_0() throws Throwable {
return bevp_libExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_libExtGetDirect_0() throws Throwable {
return bevp_libExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_libExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_libExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccObjGet_0() throws Throwable {
return bevp_ccObj;
} /*method end*/
public final BEC_2_4_6_TextString bem_ccObjGetDirect_0() throws Throwable {
return bevp_ccObj;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccObjSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_ccObjSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccGet_0() throws Throwable {
return bevp_cc;
} /*method end*/
public final BEC_2_4_6_TextString bem_ccGetDirect_0() throws Throwable {
return bevp_cc;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_ccSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cextGet_0() throws Throwable {
return bevp_cext;
} /*method end*/
public final BEC_2_4_6_TextString bem_cextGetDirect_0() throws Throwable {
return bevp_cext;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_cextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_oextGet_0() throws Throwable {
return bevp_oext;
} /*method end*/
public final BEC_2_4_6_TextString bem_oextGetDirect_0() throws Throwable {
return bevp_oext;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_oextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_oextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lBuildGet_0() throws Throwable {
return bevp_lBuild;
} /*method end*/
public final BEC_2_4_6_TextString bem_lBuildGetDirect_0() throws Throwable {
return bevp_lBuild;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_lBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccoutGet_0() throws Throwable {
return bevp_ccout;
} /*method end*/
public final BEC_2_4_6_TextString bem_ccoutGetDirect_0() throws Throwable {
return bevp_ccout;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccoutSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_ccoutSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_doCopyGet_0() throws Throwable {
return bevp_doCopy;
} /*method end*/
public final BEC_2_4_6_TextString bem_doCopyGetDirect_0() throws Throwable {
return bevp_doCopy;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doCopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_doCopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mkdirsGet_0() throws Throwable {
return bevp_mkdirs;
} /*method end*/
public final BEC_2_4_6_TextString bem_mkdirsGetDirect_0() throws Throwable {
return bevp_mkdirs;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_mkdirsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_mkdirsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lexeGet_0() throws Throwable {
return bevp_lexe;
} /*method end*/
public final BEC_2_4_6_TextString bem_lexeGetDirect_0() throws Throwable {
return bevp_lexe;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lexeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_lexeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeLibExtGet_0() throws Throwable {
return bevp_exeLibExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_exeLibExtGetDirect_0() throws Throwable {
return bevp_exeLibExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_diGet_0() throws Throwable {
return bevp_di;
} /*method end*/
public final BEC_2_4_6_TextString bem_diGetDirect_0() throws Throwable {
return bevp_di;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_diSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_di = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_diSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_di = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_smacGet_0() throws Throwable {
return bevp_smac;
} /*method end*/
public final BEC_2_4_6_TextString bem_smacGetDirect_0() throws Throwable {
return bevp_smac;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_smacSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_smacSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dialectGet_0() throws Throwable {
return bevp_dialect;
} /*method end*/
public final BEC_2_4_6_TextString bem_dialectGetDirect_0() throws Throwable {
return bevp_dialect;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_dialectSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_dialectSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public final BEC_2_4_6_TextString bem_compilerGetDirect_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {841, 842, 842, 843, 844, 845, 846, 847, 848, 848, 848, 849, 849, 851, 852, 852, 852, 853, 854, 855, 855, 855, 857, 858, 859, 860, 861, 861, 861, 863, 864, 865, 865, 865, 867, 868, 869, 870, 872, 872, 872, 872, 873, 874, 874, 874, 874, 874, 875, 876, 877, 878, 879, 879, 879, 879, 879, 880, 882, 882, 882, 882, 0, 882, 882, 882, 882, 0, 0, 883, 884, 884, 884, 884, 884, 885, 885, 885, 885, 885, 886, 887, 888, 889, 889, 889, 889, 889, 890, 892, 892, 892, 892, 893, 894, 894, 894, 895, 896, 897, 898, 899, 900, 900, 900, 900, 900, 901, 902, 903, 904, 905, 906, 908, 909, 909, 909, 909, 909, 910, 910, 911, 912, 913, 914, 914, 914, 914, 914, 915, 918, 918, 918, 918, 918, 918, 919, 919, 919, 919, 919, 0, 0, 0, 920, 925, 925, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 212, 213, 214, 216, 217, 218, 219, 221, 222, 225, 226, 227, 229, 230, 231, 232, 235, 236, 237, 239, 240, 243, 244, 245, 247, 248, 249, 250, 255, 256, 257, 258, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 277, 278, 279, 280, 282, 285, 286, 287, 288, 290, 293, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 318, 319, 320, 321, 323, 324, 325, 326, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 365, 366, 367, 368, 369, 370, 371, 376, 377, 378, 383, 384, 387, 391, 394, 400, 401, 405, 408, 411, 415, 419, 422, 425, 429, 433, 436, 439, 443, 447, 450, 453, 457, 461, 464, 467, 471, 475, 478, 481, 485, 489, 492, 495, 499, 503, 506, 509, 513, 517, 520, 523, 527, 531, 534, 537, 541, 545, 548, 551, 555, 559, 562, 565, 569, 573, 576, 579, 583, 587, 590, 593, 597, 601, 604, 607, 611, 615, 618, 621, 625, 629, 632, 635, 639};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 841 198
new 0 841 198
assign 1 842 199
platformGet 0 842 199
assign 1 842 200
nameGet 0 842 200
assign 1 843 201
new 0 843 201
assign 1 844 202
new 0 844 202
assign 1 845 203
new 0 845 203
assign 1 846 204
new 0 846 204
assign 1 847 205
new 0 847 205
assign 1 848 206
compilerGet 0 848 206
assign 1 848 207
undef 1 848 212
assign 1 849 213
new 0 849 213
compilerSet 1 849 214
assign 1 851 216
compilerGet 0 851 216
assign 1 852 217
compilerGet 0 852 217
assign 1 852 218
new 0 852 218
assign 1 852 219
equals 1 852 219
assign 1 853 221
new 0 853 221
assign 1 854 222
new 0 854 222
assign 1 855 225
compilerGet 0 855 225
assign 1 855 226
new 0 855 226
assign 1 855 227
equals 1 855 227
assign 1 857 229
new 0 857 229
assign 1 858 230
new 0 858 230
assign 1 859 231
new 0 859 231
assign 1 860 232
new 0 860 232
assign 1 861 235
compilerGet 0 861 235
assign 1 861 236
new 0 861 236
assign 1 861 237
equals 1 861 237
assign 1 863 239
new 0 863 239
assign 1 864 240
new 0 864 240
assign 1 865 243
compilerGet 0 865 243
assign 1 865 244
new 0 865 244
assign 1 865 245
equals 1 865 245
assign 1 867 247
new 0 867 247
assign 1 868 248
new 0 868 248
assign 1 869 249
new 0 869 249
assign 1 870 250
new 0 870 250
assign 1 872 255
platformGet 0 872 255
assign 1 872 256
nameGet 0 872 256
assign 1 872 257
new 0 872 257
assign 1 872 258
equals 1 872 258
assign 1 873 260
new 0 873 260
assign 1 874 261
new 0 874 261
assign 1 874 262
add 1 874 262
assign 1 874 263
add 1 874 263
assign 1 874 264
new 0 874 264
assign 1 874 265
add 1 874 265
assign 1 875 266
new 0 875 266
assign 1 876 267
new 0 876 267
assign 1 877 268
new 0 877 268
assign 1 878 269
new 0 878 269
assign 1 879 270
new 0 879 270
assign 1 879 271
add 1 879 271
assign 1 879 272
add 1 879 272
assign 1 879 273
new 0 879 273
assign 1 879 274
add 1 879 274
assign 1 880 275
assign 1 882 277
platformGet 0 882 277
assign 1 882 278
nameGet 0 882 278
assign 1 882 279
new 0 882 279
assign 1 882 280
equals 1 882 280
assign 1 0 282
assign 1 882 285
platformGet 0 882 285
assign 1 882 286
nameGet 0 882 286
assign 1 882 287
new 0 882 287
assign 1 882 288
equals 1 882 288
assign 1 0 290
assign 1 0 293
assign 1 883 297
new 0 883 297
assign 1 884 298
new 0 884 298
assign 1 884 299
add 1 884 299
assign 1 884 300
add 1 884 300
assign 1 884 301
new 0 884 301
assign 1 884 302
add 1 884 302
assign 1 885 303
new 0 885 303
assign 1 885 304
add 1 885 304
assign 1 885 305
add 1 885 305
assign 1 885 306
new 0 885 306
assign 1 885 307
add 1 885 307
assign 1 886 308
new 0 886 308
assign 1 887 309
new 0 887 309
assign 1 888 310
new 0 888 310
assign 1 889 311
new 0 889 311
assign 1 889 312
add 1 889 312
assign 1 889 313
add 1 889 313
assign 1 889 314
new 0 889 314
assign 1 889 315
add 1 889 315
assign 1 890 316
assign 1 892 318
platformGet 0 892 318
assign 1 892 319
nameGet 0 892 319
assign 1 892 320
new 0 892 320
assign 1 892 321
equals 1 892 321
assign 1 893 323
new 0 893 323
assign 1 894 324
compilerGet 0 894 324
assign 1 894 325
new 0 894 325
assign 1 894 326
equals 1 894 326
assign 1 895 328
new 0 895 328
assign 1 896 329
new 0 896 329
assign 1 897 330
new 0 897 330
assign 1 898 331
new 0 898 331
assign 1 899 332
new 0 899 332
assign 1 900 333
new 0 900 333
assign 1 900 334
add 1 900 334
assign 1 900 335
add 1 900 335
assign 1 900 336
new 0 900 336
assign 1 900 337
add 1 900 337
assign 1 901 338
new 0 901 338
assign 1 902 339
new 0 902 339
assign 1 903 340
new 0 903 340
assign 1 904 341
new 0 904 341
assign 1 905 342
new 0 905 342
assign 1 906 343
new 0 906 343
assign 1 908 346
new 0 908 346
assign 1 909 347
new 0 909 347
assign 1 909 348
add 1 909 348
assign 1 909 349
add 1 909 349
assign 1 909 350
new 0 909 350
assign 1 909 351
add 1 909 351
assign 1 910 352
new 0 910 352
assign 1 910 353
add 1 910 353
assign 1 911 354
new 0 911 354
assign 1 912 355
new 0 912 355
assign 1 913 356
new 0 913 356
assign 1 914 357
new 0 914 357
assign 1 914 358
add 1 914 358
assign 1 914 359
add 1 914 359
assign 1 914 360
new 0 914 360
assign 1 914 361
add 1 914 361
assign 1 915 362
assign 1 918 365
paramsGet 0 918 365
assign 1 918 366
new 0 918 366
assign 1 918 367
platformGet 0 918 367
assign 1 918 368
nameGet 0 918 368
assign 1 918 369
add 1 918 369
assign 1 918 370
get 1 918 370
assign 1 919 371
def 1 919 376
assign 1 919 377
firstGet 0 919 377
assign 1 919 378
def 1 919 383
assign 1 0 384
assign 1 0 387
assign 1 0 391
assign 1 920 394
firstGet 0 920 394
assign 1 925 400
new 1 925 400
makeDirs 0 925 401
return 1 0 405
return 1 0 408
assign 1 0 411
assign 1 0 415
return 1 0 419
return 1 0 422
assign 1 0 425
assign 1 0 429
return 1 0 433
return 1 0 436
assign 1 0 439
assign 1 0 443
return 1 0 447
return 1 0 450
assign 1 0 453
assign 1 0 457
return 1 0 461
return 1 0 464
assign 1 0 467
assign 1 0 471
return 1 0 475
return 1 0 478
assign 1 0 481
assign 1 0 485
return 1 0 489
return 1 0 492
assign 1 0 495
assign 1 0 499
return 1 0 503
return 1 0 506
assign 1 0 509
assign 1 0 513
return 1 0 517
return 1 0 520
assign 1 0 523
assign 1 0 527
return 1 0 531
return 1 0 534
assign 1 0 537
assign 1 0 541
return 1 0 545
return 1 0 548
assign 1 0 551
assign 1 0 555
return 1 0 559
return 1 0 562
assign 1 0 565
assign 1 0 569
return 1 0 573
return 1 0 576
assign 1 0 579
assign 1 0 583
return 1 0 587
return 1 0 590
assign 1 0 593
assign 1 0 597
return 1 0 601
return 1 0 604
assign 1 0 607
assign 1 0 611
return 1 0 615
return 1 0 618
assign 1 0 621
assign 1 0 625
return 1 0 629
return 1 0 632
assign 1 0 635
assign 1 0 639
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1000868272: return bem_ccObjGet_0();
case -1248504201: return bem_exeLibExtGet_0();
case 1639062936: return bem_create_0();
case -831443384: return bem_compilerGet_0();
case 274758626: return bem_ccoutGetDirect_0();
case -835256918: return bem_deserializeClassNameGet_0();
case 542454679: return bem_tagGet_0();
case -2001141426: return bem_diGet_0();
case -1517534893: return bem_ccGetDirect_0();
case -258746779: return bem_libExtGet_0();
case -636488155: return bem_exeExtGet_0();
case -268678688: return bem_dialectGet_0();
case -2039065793: return bem_lBuildGetDirect_0();
case -395226796: return bem_oextGet_0();
case 1042227348: return bem_print_0();
case -2073568541: return bem_smacGetDirect_0();
case -1698418878: return bem_ccGet_0();
case -1788326649: return bem_iteratorGet_0();
case 434703584: return bem_many_0();
case 681743616: return bem_oextGetDirect_0();
case 1265893898: return bem_dialectGetDirect_0();
case -653615460: return bem_fieldIteratorGet_0();
case 1093549819: return bem_diGetDirect_0();
case -1206807373: return bem_echo_0();
case -713727621: return bem_nameGetDirect_0();
case 324544151: return bem_compilerGetDirect_0();
case 702386781: return bem_serializationIteratorGet_0();
case -717337946: return bem_exeExtGetDirect_0();
case 1728977971: return bem_doCopyGetDirect_0();
case -1365152312: return bem_mkdirsGet_0();
case -867540373: return bem_sourceFileNameGet_0();
case 2048167379: return bem_lexeGet_0();
case 554051393: return bem_lBuildGet_0();
case 1173227505: return bem_once_0();
case 121043123: return bem_exeLibExtGetDirect_0();
case 695019909: return bem_new_0();
case -45870993: return bem_hashGet_0();
case -660026306: return bem_doCopyGet_0();
case 587827837: return bem_mkdirsGetDirect_0();
case 1154111609: return bem_serializeToString_0();
case 1941523784: return bem_cextGet_0();
case -2060052900: return bem_classNameGet_0();
case 584319597: return bem_serializeContents_0();
case 376367511: return bem_toString_0();
case -480589780: return bem_smacGet_0();
case -2063692354: return bem_toAny_0();
case 936108049: return bem_fieldNamesGet_0();
case 1258468962: return bem_ccObjGetDirect_0();
case -743549648: return bem_libExtGetDirect_0();
case -1831125774: return bem_cextGetDirect_0();
case 1543632707: return bem_nameGet_0();
case 1930515945: return bem_lexeGetDirect_0();
case 845843737: return bem_copy_0();
case -94078659: return bem_ccoutGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1327504124: return bem_exeExtSet_1(bevd_0);
case -886160285: return bem_notEquals_1(bevd_0);
case -237859895: return bem_libExtSetDirect_1(bevd_0);
case -1191551357: return bem_lexeSet_1(bevd_0);
case -2130755695: return bem_equals_1(bevd_0);
case -1356620423: return bem_nameSet_1(bevd_0);
case 699166467: return bem_sameClass_1(bevd_0);
case -1438256358: return bem_otherType_1(bevd_0);
case -1137059110: return bem_dialectSet_1(bevd_0);
case -1253948557: return bem_otherClass_1(bevd_0);
case 2055604815: return bem_oextSet_1(bevd_0);
case -1804080941: return bem_compilerSetDirect_1(bevd_0);
case 1617681110: return bem_exeLibExtSet_1(bevd_0);
case 301362299: return bem_undef_1(bevd_0);
case -116418086: return bem_ccoutSet_1(bevd_0);
case -1253472481: return bem_copyTo_1(bevd_0);
case 471926371: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 857972320: return bem_diSet_1(bevd_0);
case 285945119: return bem_ccoutSetDirect_1(bevd_0);
case 1326406145: return bem_lexeSetDirect_1(bevd_0);
case -1141218807: return bem_lBuildSetDirect_1(bevd_0);
case -921384019: return bem_diSetDirect_1(bevd_0);
case 604219486: return bem_undefined_1(bevd_0);
case -2031145791: return bem_def_1(bevd_0);
case 1689281313: return bem_defined_1(bevd_0);
case 530980523: return bem_libExtSet_1(bevd_0);
case -2058472659: return bem_dialectSetDirect_1(bevd_0);
case 494232480: return bem_cextSetDirect_1(bevd_0);
case 703202135: return bem_exeLibExtSetDirect_1(bevd_0);
case -1569901537: return bem_compilerSet_1(bevd_0);
case -1569160884: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -553924566: return bem_ccSetDirect_1(bevd_0);
case -671092537: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -670346435: return bem_sameObject_1(bevd_0);
case 388948509: return bem_ccObjSetDirect_1(bevd_0);
case -1264148720: return bem_cextSet_1(bevd_0);
case -1971602014: return bem_doCopySetDirect_1(bevd_0);
case 310219587: return bem_mkdirsSetDirect_1(bevd_0);
case -720414260: return bem_smacSetDirect_1(bevd_0);
case -1982174662: return bem_lBuildSet_1(bevd_0);
case -1259086305: return bem_nameSetDirect_1(bevd_0);
case 1952601345: return bem_smacSet_1(bevd_0);
case 1387541505: return bem_doMakeDirs_1((BEC_2_4_6_TextString) bevd_0);
case 1738623736: return bem_sameType_1(bevd_0);
case -534488648: return bem_ccObjSet_1(bevd_0);
case 2039403626: return bem_new_1(bevd_0);
case 1631701311: return bem_mkdirsSet_1(bevd_0);
case -895091692: return bem_exeExtSetDirect_1(bevd_0);
case 649863764: return bem_ccSet_1(bevd_0);
case 1643803894: return bem_oextSetDirect_1(bevd_0);
case 129120363: return bem_doCopySet_1(bevd_0);
case 585390927: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1353806938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1092172708: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1390495691: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1588508948: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 167635781: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1229766114: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 39825618: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_15_BuildCompilerProfile_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_15_BuildCompilerProfile_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_15_BuildCompilerProfile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst = (BEC_2_5_15_BuildCompilerProfile) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;
}
}
