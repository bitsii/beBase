package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_15_BuildCompilerProfile extends BEC_2_6_6_SystemObject {
public BEC_2_5_15_BuildCompilerProfile() { }
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72,0x50,0x72,0x6F,0x66,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_0 = {0x2E,0x65,0x78,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_1 = {0x2E,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_2 = {0x2D,0x49,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_3 = {0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_4 = {0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_5 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_6 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_7 = {0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_8 = {0x2E,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_9 = {0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_10 = {0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_11 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_12 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_13 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_14 = {0x61,0x70,0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_15 = {0x61,0x70,0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_16 = {0x61,0x70,0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_17 = {0x61,0x70,0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_18 = {0x6D,0x61,0x63,0x6F,0x73};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_19 = {0x2E,0x64,0x79,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_20 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_20, 20));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_21 = {0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_21, 10));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_22 = {0x6C,0x69,0x62,0x74,0x6F,0x6F,0x6C,0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6C,0x63,0x63,0x5F,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_23 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_24 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_25 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_26 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_26, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_23, 4));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_27 = {0x6C,0x69,0x6E,0x75,0x78};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_28 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_29 = {0x2E,0x73,0x6F};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_20, 20));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_30 = {0x20,0x2D,0x66,0x50,0x49,0x43,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_30, 7));
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_26, 17));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_31 = {0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_31, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_26, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_23, 4));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_32 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_33 = {0x6D,0x73,0x76,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_34 = {0x63,0x6C,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_35 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_36 = {0x2D,0x6E,0x6F,0x6C,0x6F,0x67,0x6F,0x20,0x2D,0x4D,0x44,0x20,0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x4D,0x53,0x56,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_36, 45));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_37 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x53,0x45,0x43,0x55,0x52,0x45,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x4E,0x4F,0x4E,0x53,0x54,0x44,0x43,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_37, 76));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_38 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x44,0x4C,0x4C,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_39 = {0x20,0x2D,0x46,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_40 = {0x63,0x6F,0x70,0x79,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_41 = {0x6D,0x6B,0x64,0x69,0x72,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_42 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_43 = {0x2E,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_44 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_44, 32));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_45 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_45, 19));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_46 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_46, 37));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_47 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_47, 29));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_48 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_48, 22));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_49 = {0x65,0x78,0x65,0x45,0x78,0x74,0x4F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_49, 15));
public static BEC_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;

public static BET_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;

public BEC_2_4_6_TextString bevp_exeExt;
public BEC_2_4_6_TextString bevp_libExt;
public BEC_2_4_6_TextString bevp_ccObj;
public BEC_2_4_6_TextString bevp_cc;
public BEC_2_4_6_TextString bevp_cext;
public BEC_2_4_6_TextString bevp_oext;
public BEC_2_4_6_TextString bevp_lBuild;
public BEC_2_4_6_TextString bevp_ccout;
public BEC_2_4_6_TextString bevp_doCopy;
public BEC_2_4_6_TextString bevp_mkdirs;
public BEC_2_4_6_TextString bevp_lexe;
public BEC_2_4_6_TextString bevp_exeLibExt;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_di;
public BEC_2_4_6_TextString bevp_smac;
public BEC_2_4_6_TextString bevp_dialect;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_5_15_BuildCompilerProfile bem_new_1(BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_4_6_TextString bevl_dialectMacro = null;
BEC_2_6_6_SystemObject bevl_exeExtOverride = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
bevp_exeExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_2_tmpany_phold = beva_build.bemd_0(694772787);
bevp_name = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(-912973781);
bevp_oext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_1));
bevp_di = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_2));
bevp_smac = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_3));
bevp_dialect = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_15_BuildCompilerProfile_bels_4));
bevl_dialectMacro = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_5));
bevt_4_tmpany_phold = beva_build.bemd_0(-332679759);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 847 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
beva_build.bemd_1(-1853796626, bevt_5_tmpany_phold);
} /* Line: 848 */
bevp_compiler = (BEC_2_4_6_TextString) beva_build.bemd_0(-332679759);
bevt_7_tmpany_phold = beva_build.bemd_0(-332679759);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(1876359344, bevt_8_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 851 */ {
bevp_cc = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_7));
bevp_cext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
} /* Line: 853 */
 else  /* Line: 851 */ {
bevt_10_tmpany_phold = beva_build.bemd_0(-332679759);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_9));
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(1876359344, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 854 */ {
bevp_cc = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_10));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
} /* Line: 859 */
 else  /* Line: 851 */ {
bevt_13_tmpany_phold = beva_build.bemd_0(-332679759);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_14));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(1876359344, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 860 */ {
bevp_cc = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_15));
bevp_cext = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
} /* Line: 863 */
 else  /* Line: 851 */ {
bevt_16_tmpany_phold = beva_build.bemd_0(-332679759);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_16));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(1876359344, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 864 */ {
bevp_cc = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_17));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
} /* Line: 869 */
} /* Line: 851 */
} /* Line: 851 */
} /* Line: 851 */
bevt_20_tmpany_phold = beva_build.bemd_0(694772787);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-912973781);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_18));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(1876359344, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 871 */ {
bevp_libExt = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_19));
bevt_24_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_0;
bevt_23_tmpany_phold = bevp_cc.bem_add_1(bevt_24_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_25_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_1;
bevp_ccObj = bevt_22_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevp_lBuild = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_15_BuildCompilerProfile_bels_22));
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_28_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_2;
bevt_27_tmpany_phold = bevp_cc.bem_add_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_29_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_3;
bevp_lexe = bevt_26_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 879 */
bevt_32_tmpany_phold = beva_build.bemd_0(694772787);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_0(-912973781);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_27));
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_1(1876359344, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 881 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 881 */ {
bevt_36_tmpany_phold = beva_build.bemd_0(694772787);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_0(-912973781);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_28));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1876359344, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 881 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 881 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 881 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 881 */ {
bevp_libExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_29));
bevt_40_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_4;
bevt_39_tmpany_phold = bevp_cc.bem_add_1(bevt_40_tmpany_phold);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_41_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_5;
bevp_ccObj = bevt_38_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_6;
bevt_43_tmpany_phold = bevp_cc.bem_add_1(bevt_44_tmpany_phold);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_45_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_7;
bevp_lBuild = bevt_42_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_48_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_8;
bevt_47_tmpany_phold = bevp_cc.bem_add_1(bevt_48_tmpany_phold);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_49_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_9;
bevp_lexe = bevt_46_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 889 */
bevt_52_tmpany_phold = beva_build.bemd_0(694772787);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(-912973781);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_32));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_1(1876359344, bevt_53_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 891 */ {
bevp_exeExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_55_tmpany_phold = beva_build.bemd_0(-332679759);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_33));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_1(1876359344, bevt_56_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_54_tmpany_phold).bevi_bool) /* Line: 893 */ {
bevp_cc = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_34));
bevp_cext = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
bevp_libExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_59_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_10;
bevt_58_tmpany_phold = bevp_cc.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_60_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_11;
bevp_ccObj = bevt_57_tmpany_phold.bem_add_1(bevt_60_tmpany_phold);
bevp_lBuild = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_15_BuildCompilerProfile_bels_38));
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_39));
bevp_doCopy = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_40));
bevp_mkdirs = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_41));
bevp_lexe = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_42));
bevp_exeLibExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_43));
} /* Line: 905 */
 else  /* Line: 906 */ {
bevp_libExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_63_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_12;
bevt_62_tmpany_phold = bevp_cc.bem_add_1(bevt_63_tmpany_phold);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_64_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_13;
bevp_ccObj = bevt_61_tmpany_phold.bem_add_1(bevt_64_tmpany_phold);
bevt_65_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_14;
bevp_lBuild = bevp_cc.bem_add_1(bevt_65_tmpany_phold);
bevp_ccout = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_68_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_15;
bevt_67_tmpany_phold = bevp_cc.bem_add_1(bevt_68_tmpany_phold);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_69_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_16;
bevp_lexe = bevt_66_tmpany_phold.bem_add_1(bevt_69_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 914 */
} /* Line: 893 */
bevt_70_tmpany_phold = beva_build.bemd_0(1393065712);
bevt_72_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_17;
bevt_74_tmpany_phold = beva_build.bemd_0(694772787);
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(-912973781);
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_exeExtOverride = bevt_70_tmpany_phold.bemd_1(-1640977038, bevt_71_tmpany_phold);
if (bevl_exeExtOverride == null) {
bevt_75_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 918 */ {
bevt_77_tmpany_phold = bevl_exeExtOverride.bemd_0(-1774236064);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 918 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 918 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 918 */
 else  /* Line: 918 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 918 */ {
bevp_exeExt = (BEC_2_4_6_TextString) bevl_exeExtOverride.bemd_0(-1774236064);
} /* Line: 919 */
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doMakeDirs_1(BEC_2_4_6_TextString beva_path) throws Throwable {
BEC_2_2_4_IOFile bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(beva_path);
bevt_0_tmpany_phold.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeExtGet_0() throws Throwable {
return bevp_exeExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_exeExtGetDirect_0() throws Throwable {
return bevp_exeExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_exeExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libExtGet_0() throws Throwable {
return bevp_libExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_libExtGetDirect_0() throws Throwable {
return bevp_libExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_libExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_libExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccObjGet_0() throws Throwable {
return bevp_ccObj;
} /*method end*/
public final BEC_2_4_6_TextString bem_ccObjGetDirect_0() throws Throwable {
return bevp_ccObj;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccObjSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_ccObjSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccGet_0() throws Throwable {
return bevp_cc;
} /*method end*/
public final BEC_2_4_6_TextString bem_ccGetDirect_0() throws Throwable {
return bevp_cc;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_ccSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cextGet_0() throws Throwable {
return bevp_cext;
} /*method end*/
public final BEC_2_4_6_TextString bem_cextGetDirect_0() throws Throwable {
return bevp_cext;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_cextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_oextGet_0() throws Throwable {
return bevp_oext;
} /*method end*/
public final BEC_2_4_6_TextString bem_oextGetDirect_0() throws Throwable {
return bevp_oext;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_oextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_oextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lBuildGet_0() throws Throwable {
return bevp_lBuild;
} /*method end*/
public final BEC_2_4_6_TextString bem_lBuildGetDirect_0() throws Throwable {
return bevp_lBuild;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_lBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_ccoutGet_0() throws Throwable {
return bevp_ccout;
} /*method end*/
public final BEC_2_4_6_TextString bem_ccoutGetDirect_0() throws Throwable {
return bevp_ccout;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccoutSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_ccoutSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_doCopyGet_0() throws Throwable {
return bevp_doCopy;
} /*method end*/
public final BEC_2_4_6_TextString bem_doCopyGetDirect_0() throws Throwable {
return bevp_doCopy;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doCopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_doCopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mkdirsGet_0() throws Throwable {
return bevp_mkdirs;
} /*method end*/
public final BEC_2_4_6_TextString bem_mkdirsGetDirect_0() throws Throwable {
return bevp_mkdirs;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_mkdirsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_mkdirsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lexeGet_0() throws Throwable {
return bevp_lexe;
} /*method end*/
public final BEC_2_4_6_TextString bem_lexeGetDirect_0() throws Throwable {
return bevp_lexe;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lexeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_lexeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeLibExtGet_0() throws Throwable {
return bevp_exeLibExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_exeLibExtGetDirect_0() throws Throwable {
return bevp_exeLibExt;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_diGet_0() throws Throwable {
return bevp_di;
} /*method end*/
public final BEC_2_4_6_TextString bem_diGetDirect_0() throws Throwable {
return bevp_di;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_diSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_di = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_diSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_di = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_smacGet_0() throws Throwable {
return bevp_smac;
} /*method end*/
public final BEC_2_4_6_TextString bem_smacGetDirect_0() throws Throwable {
return bevp_smac;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_smacSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_smacSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dialectGet_0() throws Throwable {
return bevp_dialect;
} /*method end*/
public final BEC_2_4_6_TextString bem_dialectGetDirect_0() throws Throwable {
return bevp_dialect;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_dialectSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_dialectSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public final BEC_2_4_6_TextString bem_compilerGetDirect_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {840, 841, 841, 842, 843, 844, 845, 846, 847, 847, 847, 848, 848, 850, 851, 851, 851, 852, 853, 854, 854, 854, 856, 857, 858, 859, 860, 860, 860, 862, 863, 864, 864, 864, 866, 867, 868, 869, 871, 871, 871, 871, 872, 873, 873, 873, 873, 873, 874, 875, 876, 877, 878, 878, 878, 878, 878, 879, 881, 881, 881, 881, 0, 881, 881, 881, 881, 0, 0, 882, 883, 883, 883, 883, 883, 884, 884, 884, 884, 884, 885, 886, 887, 888, 888, 888, 888, 888, 889, 891, 891, 891, 891, 892, 893, 893, 893, 894, 895, 896, 897, 898, 899, 899, 899, 899, 899, 900, 901, 902, 903, 904, 905, 907, 908, 908, 908, 908, 908, 909, 909, 910, 911, 912, 913, 913, 913, 913, 913, 914, 917, 917, 917, 917, 917, 917, 918, 918, 918, 918, 918, 0, 0, 0, 919, 924, 924, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 191, 192, 193, 195, 196, 197, 198, 200, 201, 204, 205, 206, 208, 209, 210, 211, 214, 215, 216, 218, 219, 222, 223, 224, 226, 227, 228, 229, 234, 235, 236, 237, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 256, 257, 258, 259, 261, 264, 265, 266, 267, 269, 272, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 297, 298, 299, 300, 302, 303, 304, 305, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 344, 345, 346, 347, 348, 349, 350, 355, 356, 357, 362, 363, 366, 370, 373, 379, 380, 384, 387, 390, 394, 398, 401, 404, 408, 412, 415, 418, 422, 426, 429, 432, 436, 440, 443, 446, 450, 454, 457, 460, 464, 468, 471, 474, 478, 482, 485, 488, 492, 496, 499, 502, 506, 510, 513, 516, 520, 524, 527, 530, 534, 538, 541, 544, 548, 552, 555, 558, 562, 566, 569, 572, 576, 580, 583, 586, 590, 594, 597, 600, 604, 608, 611, 614, 618};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 840 177
new 0 840 177
assign 1 841 178
platformGet 0 841 178
assign 1 841 179
nameGet 0 841 179
assign 1 842 180
new 0 842 180
assign 1 843 181
new 0 843 181
assign 1 844 182
new 0 844 182
assign 1 845 183
new 0 845 183
assign 1 846 184
new 0 846 184
assign 1 847 185
compilerGet 0 847 185
assign 1 847 186
undef 1 847 191
assign 1 848 192
new 0 848 192
compilerSet 1 848 193
assign 1 850 195
compilerGet 0 850 195
assign 1 851 196
compilerGet 0 851 196
assign 1 851 197
new 0 851 197
assign 1 851 198
equals 1 851 198
assign 1 852 200
new 0 852 200
assign 1 853 201
new 0 853 201
assign 1 854 204
compilerGet 0 854 204
assign 1 854 205
new 0 854 205
assign 1 854 206
equals 1 854 206
assign 1 856 208
new 0 856 208
assign 1 857 209
new 0 857 209
assign 1 858 210
new 0 858 210
assign 1 859 211
new 0 859 211
assign 1 860 214
compilerGet 0 860 214
assign 1 860 215
new 0 860 215
assign 1 860 216
equals 1 860 216
assign 1 862 218
new 0 862 218
assign 1 863 219
new 0 863 219
assign 1 864 222
compilerGet 0 864 222
assign 1 864 223
new 0 864 223
assign 1 864 224
equals 1 864 224
assign 1 866 226
new 0 866 226
assign 1 867 227
new 0 867 227
assign 1 868 228
new 0 868 228
assign 1 869 229
new 0 869 229
assign 1 871 234
platformGet 0 871 234
assign 1 871 235
nameGet 0 871 235
assign 1 871 236
new 0 871 236
assign 1 871 237
equals 1 871 237
assign 1 872 239
new 0 872 239
assign 1 873 240
new 0 873 240
assign 1 873 241
add 1 873 241
assign 1 873 242
add 1 873 242
assign 1 873 243
new 0 873 243
assign 1 873 244
add 1 873 244
assign 1 874 245
new 0 874 245
assign 1 875 246
new 0 875 246
assign 1 876 247
new 0 876 247
assign 1 877 248
new 0 877 248
assign 1 878 249
new 0 878 249
assign 1 878 250
add 1 878 250
assign 1 878 251
add 1 878 251
assign 1 878 252
new 0 878 252
assign 1 878 253
add 1 878 253
assign 1 879 254
assign 1 881 256
platformGet 0 881 256
assign 1 881 257
nameGet 0 881 257
assign 1 881 258
new 0 881 258
assign 1 881 259
equals 1 881 259
assign 1 0 261
assign 1 881 264
platformGet 0 881 264
assign 1 881 265
nameGet 0 881 265
assign 1 881 266
new 0 881 266
assign 1 881 267
equals 1 881 267
assign 1 0 269
assign 1 0 272
assign 1 882 276
new 0 882 276
assign 1 883 277
new 0 883 277
assign 1 883 278
add 1 883 278
assign 1 883 279
add 1 883 279
assign 1 883 280
new 0 883 280
assign 1 883 281
add 1 883 281
assign 1 884 282
new 0 884 282
assign 1 884 283
add 1 884 283
assign 1 884 284
add 1 884 284
assign 1 884 285
new 0 884 285
assign 1 884 286
add 1 884 286
assign 1 885 287
new 0 885 287
assign 1 886 288
new 0 886 288
assign 1 887 289
new 0 887 289
assign 1 888 290
new 0 888 290
assign 1 888 291
add 1 888 291
assign 1 888 292
add 1 888 292
assign 1 888 293
new 0 888 293
assign 1 888 294
add 1 888 294
assign 1 889 295
assign 1 891 297
platformGet 0 891 297
assign 1 891 298
nameGet 0 891 298
assign 1 891 299
new 0 891 299
assign 1 891 300
equals 1 891 300
assign 1 892 302
new 0 892 302
assign 1 893 303
compilerGet 0 893 303
assign 1 893 304
new 0 893 304
assign 1 893 305
equals 1 893 305
assign 1 894 307
new 0 894 307
assign 1 895 308
new 0 895 308
assign 1 896 309
new 0 896 309
assign 1 897 310
new 0 897 310
assign 1 898 311
new 0 898 311
assign 1 899 312
new 0 899 312
assign 1 899 313
add 1 899 313
assign 1 899 314
add 1 899 314
assign 1 899 315
new 0 899 315
assign 1 899 316
add 1 899 316
assign 1 900 317
new 0 900 317
assign 1 901 318
new 0 901 318
assign 1 902 319
new 0 902 319
assign 1 903 320
new 0 903 320
assign 1 904 321
new 0 904 321
assign 1 905 322
new 0 905 322
assign 1 907 325
new 0 907 325
assign 1 908 326
new 0 908 326
assign 1 908 327
add 1 908 327
assign 1 908 328
add 1 908 328
assign 1 908 329
new 0 908 329
assign 1 908 330
add 1 908 330
assign 1 909 331
new 0 909 331
assign 1 909 332
add 1 909 332
assign 1 910 333
new 0 910 333
assign 1 911 334
new 0 911 334
assign 1 912 335
new 0 912 335
assign 1 913 336
new 0 913 336
assign 1 913 337
add 1 913 337
assign 1 913 338
add 1 913 338
assign 1 913 339
new 0 913 339
assign 1 913 340
add 1 913 340
assign 1 914 341
assign 1 917 344
paramsGet 0 917 344
assign 1 917 345
new 0 917 345
assign 1 917 346
platformGet 0 917 346
assign 1 917 347
nameGet 0 917 347
assign 1 917 348
add 1 917 348
assign 1 917 349
get 1 917 349
assign 1 918 350
def 1 918 355
assign 1 918 356
firstGet 0 918 356
assign 1 918 357
def 1 918 362
assign 1 0 363
assign 1 0 366
assign 1 0 370
assign 1 919 373
firstGet 0 919 373
assign 1 924 379
new 1 924 379
makeDirs 0 924 380
return 1 0 384
return 1 0 387
assign 1 0 390
assign 1 0 394
return 1 0 398
return 1 0 401
assign 1 0 404
assign 1 0 408
return 1 0 412
return 1 0 415
assign 1 0 418
assign 1 0 422
return 1 0 426
return 1 0 429
assign 1 0 432
assign 1 0 436
return 1 0 440
return 1 0 443
assign 1 0 446
assign 1 0 450
return 1 0 454
return 1 0 457
assign 1 0 460
assign 1 0 464
return 1 0 468
return 1 0 471
assign 1 0 474
assign 1 0 478
return 1 0 482
return 1 0 485
assign 1 0 488
assign 1 0 492
return 1 0 496
return 1 0 499
assign 1 0 502
assign 1 0 506
return 1 0 510
return 1 0 513
assign 1 0 516
assign 1 0 520
return 1 0 524
return 1 0 527
assign 1 0 530
assign 1 0 534
return 1 0 538
return 1 0 541
assign 1 0 544
assign 1 0 548
return 1 0 552
return 1 0 555
assign 1 0 558
assign 1 0 562
return 1 0 566
return 1 0 569
assign 1 0 572
assign 1 0 576
return 1 0 580
return 1 0 583
assign 1 0 586
assign 1 0 590
return 1 0 594
return 1 0 597
assign 1 0 600
assign 1 0 604
return 1 0 608
return 1 0 611
assign 1 0 614
assign 1 0 618
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 761879635: return bem_doCopyGetDirect_0();
case -357139526: return bem_many_0();
case -967759506: return bem_cextGetDirect_0();
case -112964036: return bem_nameGetDirect_0();
case 1044367186: return bem_dialectGetDirect_0();
case -332679759: return bem_compilerGet_0();
case 148815260: return bem_smacGetDirect_0();
case -2005156683: return bem_classNameGet_0();
case 1345115319: return bem_libExtGetDirect_0();
case 645211302: return bem_iteratorGet_0();
case -738439163: return bem_copy_0();
case -1953414721: return bem_ccGet_0();
case 320622940: return bem_echo_0();
case 1553639313: return bem_doCopyGet_0();
case 2056953676: return bem_ccObjGetDirect_0();
case 247075507: return bem_fieldNamesGet_0();
case 1178734934: return bem_ccGetDirect_0();
case -1522610135: return bem_serializeToString_0();
case 690609043: return bem_print_0();
case -912973781: return bem_nameGet_0();
case 1551415145: return bem_toAny_0();
case 689693556: return bem_oextGet_0();
case 101762581: return bem_serializeContents_0();
case 1908881867: return bem_ccoutGetDirect_0();
case -177155870: return bem_lexeGet_0();
case 2097624570: return bem_exeLibExtGet_0();
case 583763942: return bem_exeExtGetDirect_0();
case 588593745: return bem_compilerGetDirect_0();
case -1461293111: return bem_lexeGetDirect_0();
case -294098553: return bem_libExtGet_0();
case -753430171: return bem_fieldIteratorGet_0();
case 1252606819: return bem_lBuildGetDirect_0();
case -500350719: return bem_mkdirsGet_0();
case -1227320079: return bem_cextGet_0();
case -321801872: return bem_ccoutGet_0();
case 484635838: return bem_tagGet_0();
case 1898100592: return bem_smacGet_0();
case 1179744111: return bem_exeExtGet_0();
case 760402671: return bem_diGetDirect_0();
case -1313098664: return bem_toString_0();
case -576502505: return bem_create_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case 1327483113: return bem_exeLibExtGetDirect_0();
case -1966626789: return bem_hashGet_0();
case 983736684: return bem_serializationIteratorGet_0();
case 1969080256: return bem_once_0();
case -890719598: return bem_sourceFileNameGet_0();
case 2084331281: return bem_new_0();
case 708413523: return bem_diGet_0();
case 1537154733: return bem_dialectGet_0();
case -1237418495: return bem_mkdirsGetDirect_0();
case 1319491090: return bem_oextGetDirect_0();
case 2064283567: return bem_ccObjGet_0();
case -463387732: return bem_lBuildGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1017947358: return bem_lexeSetDirect_1(bevd_0);
case 1671156923: return bem_exeLibExtSet_1(bevd_0);
case -1235998079: return bem_smacSetDirect_1(bevd_0);
case -275835081: return bem_doCopySetDirect_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 1621153616: return bem_ccSet_1(bevd_0);
case -1853796626: return bem_compilerSet_1(bevd_0);
case -1865671550: return bem_new_1(bevd_0);
case -577629536: return bem_ccObjSetDirect_1(bevd_0);
case 65774935: return bem_cextSetDirect_1(bevd_0);
case -755202514: return bem_compilerSetDirect_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case -1480200856: return bem_ccObjSet_1(bevd_0);
case -188148064: return bem_doCopySet_1(bevd_0);
case -532837734: return bem_lexeSet_1(bevd_0);
case 1130698060: return bem_exeExtSetDirect_1(bevd_0);
case -1090081705: return bem_diSet_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case -680830511: return bem_libExtSet_1(bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 1520315207: return bem_ccoutSetDirect_1(bevd_0);
case 546711596: return bem_mkdirsSetDirect_1(bevd_0);
case -670773723: return bem_sameType_1(bevd_0);
case -344584157: return bem_nameSet_1(bevd_0);
case 130028710: return bem_mkdirsSet_1(bevd_0);
case 1127156190: return bem_dialectSet_1(bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 758604875: return bem_def_1(bevd_0);
case -1472204736: return bem_exeLibExtSetDirect_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case -1733305804: return bem_lBuildSetDirect_1(bevd_0);
case 1856912546: return bem_exeExtSet_1(bevd_0);
case -1532292470: return bem_ccoutSet_1(bevd_0);
case -460681450: return bem_diSetDirect_1(bevd_0);
case -1679488955: return bem_oextSetDirect_1(bevd_0);
case 1664335947: return bem_doMakeDirs_1((BEC_2_4_6_TextString) bevd_0);
case -654606622: return bem_cextSet_1(bevd_0);
case -319319613: return bem_dialectSetDirect_1(bevd_0);
case -32547225: return bem_nameSetDirect_1(bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case 415478342: return bem_libExtSetDirect_1(bevd_0);
case 1113204382: return bem_oextSet_1(bevd_0);
case 1297095708: return bem_smacSet_1(bevd_0);
case -118077713: return bem_ccSetDirect_1(bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -559803890: return bem_notEquals_1(bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case -738036775: return bem_lBuildSet_1(bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_15_BuildCompilerProfile_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_15_BuildCompilerProfile_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_15_BuildCompilerProfile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst = (BEC_2_5_15_BuildCompilerProfile) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;
}
}
