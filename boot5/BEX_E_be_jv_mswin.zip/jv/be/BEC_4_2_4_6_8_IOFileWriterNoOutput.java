package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_8_IOFileWriterNoOutput extends BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_8_IOFileWriterNoOutput() { }
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x4E,0x6F,0x4F,0x75,0x74,0x70,0x75,0x74};
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;

public static BET_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;

public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_writeIfPossible_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_write_1(BEC_2_4_6_TextString beva_str) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {749, 758, 758};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 26, 27};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 749 12
new 0 749 12
assign 1 758 26
new 0 758 26
return 1 758 27
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 623957818: return bem_once_0();
case 1070146794: return bem_toAny_0();
case -2070113098: return bem_create_0();
case -897350462: return bem_iteratorGet_0();
case 56968208: return bem_vfileGet_0();
case -599614101: return bem_openTruncate_0();
case 1326542704: return bem_tagGet_0();
case -1439777293: return bem_hashGet_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case -948982310: return bem_many_0();
case 1788389585: return bem_openAppend_0();
case 1172450247: return bem_copy_0();
case 450230894: return bem_print_0();
case 2051107343: return bem_isClosedGet_0();
case 1393807854: return bem_pathGetDirect_0();
case 144022910: return bem_vfileGetDirect_0();
case 1935136194: return bem_classNameGet_0();
case 742371580: return bem_serializeToString_0();
case 655049860: return bem_isClosedGetDirect_0();
case 1730802409: return bem_echo_0();
case 1516161879: return bem_fieldNamesGet_0();
case -2073027086: return bem_fieldIteratorGet_0();
case 2022988218: return bem_default_0();
case -61288189: return bem_serializationIteratorGet_0();
case 1660533487: return bem_serializeContents_0();
case -127605128: return bem_extOpen_0();
case -1556712456: return bem_new_0();
case -1750213491: return bem_sourceFileNameGet_0();
case -396818886: return bem_close_0();
case -2076916021: return bem_pathGet_0();
case -1476019175: return bem_toString_0();
case -41895186: return bem_open_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -741727387: return bem_writeIfPossible_1(bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -284904822: return bem_pathSetDirect_1(bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case 1025540389: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case -957438933: return bem_undef_1(bevd_0);
case -1429851340: return bem_isClosedSetDirect_1(bevd_0);
case -299391132: return bem_equals_1(bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case -691889027: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 1035756454: return bem_vfileSet_1(bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 650255571: return bem_vfileSetDirect_1(bevd_0);
case 581796080: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 459214857: return bem_isClosedSet_1(bevd_0);
case 229070821: return bem_new_1(bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case -637496309: return bem_pathSet_1(bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_8_IOFileWriterNoOutput();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst = (BEC_4_2_4_6_8_IOFileWriterNoOutput) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;
}
}
