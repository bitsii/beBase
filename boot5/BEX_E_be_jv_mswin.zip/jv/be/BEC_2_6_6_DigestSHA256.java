package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_6_DigestSHA256 extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_DigestSHA256() { }

   
    public MessageDigest bevi_md;
    
   private static byte[] becc_BEC_2_6_6_DigestSHA256_clname = {0x44,0x69,0x67,0x65,0x73,0x74,0x3A,0x53,0x48,0x41,0x32,0x35,0x36};
private static byte[] becc_BEC_2_6_6_DigestSHA256_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
public static BEC_2_6_6_DigestSHA256 bece_BEC_2_6_6_DigestSHA256_bevs_inst;

public static BET_2_6_6_DigestSHA256 bece_BEC_2_6_6_DigestSHA256_bevs_type;

public BEC_2_6_6_DigestSHA256 bem_new_0() throws Throwable {

        bevi_md = MessageDigest.getInstance("SHA-256");
        return this;
} /*method end*/
public BEC_2_4_6_TextString bem_digest_1(BEC_2_4_6_TextString beva_with) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bem_new_0();

        bevi_md.update(beva_with.bevi_bytes, 0, beva_with.bevp_size.bevi_int);
        bevl_res = new BEC_2_4_6_TextString(bevi_md.digest());
        return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_digestToHex_1(BEC_2_4_6_TextString beva_input) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_3_EncodeHex bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevt_2_ta_ph = bem_digest_1(beva_input);
bevt_0_ta_ph = bevt_1_ta_ph.bem_encode_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {48, 63, 67, 67, 67, 67};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 28, 34, 35, 36, 37};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 48 24
return 1 63 28
assign 1 67 34
new 0 67 34
assign 1 67 35
digest 1 67 35
assign 1 67 36
encode 1 67 36
return 1 67 37
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 416881831: return bem_copy_0();
case -82017130: return bem_toString_0();
case 153130764: return bem_print_0();
case 1140404476: return bem_iteratorGet_0();
case 324521155: return bem_create_0();
case -187492472: return bem_new_0();
case -159849764: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -436643248: return bem_digest_1((BEC_2_4_6_TextString) bevd_0);
case 1336352814: return bem_copyTo_1(bevd_0);
case -559238061: return bem_equals_1(bevd_0);
case 1267419746: return bem_def_1(bevd_0);
case 536552221: return bem_digestToHex_1((BEC_2_4_6_TextString) bevd_0);
case -393105689: return bem_undef_1(bevd_0);
case -850371892: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2109827654: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1822328732: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 347449110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -911952501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_DigestSHA256_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_DigestSHA256_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_DigestSHA256();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_DigestSHA256.bece_BEC_2_6_6_DigestSHA256_bevs_inst = (BEC_2_6_6_DigestSHA256) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_DigestSHA256.bece_BEC_2_6_6_DigestSHA256_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_DigestSHA256.bece_BEC_2_6_6_DigestSHA256_bevs_type;
}
}
