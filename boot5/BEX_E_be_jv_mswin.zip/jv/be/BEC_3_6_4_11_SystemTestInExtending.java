package be;
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_11_SystemTestInExtending extends BEC_3_6_4_10_SystemTestExtendable {
public BEC_3_6_4_11_SystemTestInExtending() { }
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x49,0x6E,0x45,0x78,0x74,0x65,0x6E,0x64,0x69,0x6E,0x67};
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;
public BEC_2_6_6_SystemObject bevp_prop2a;
public BEC_3_6_4_11_SystemTestInExtending bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_bcall_0() throws Throwable {
bevp_propa.bemd_0(1342246094);
return this;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_ccall_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prop2aGet_0() throws Throwable {
return bevp_prop2a;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_prop2aSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {222, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 20, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
print 0 222 13
return 1 0 20
assign 1 0 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2092326455: return bem_many_0();
case 65678538: return bem_echo_0();
case -856189883: return bem_bcall_0();
case -1620819332: return bem_once_0();
case -199763542: return bem_ccall_0();
case 1342246094: return bem_print_0();
case -117420215: return bem_serializeContents_0();
case -1197182710: return bem_serializeToString_0();
case 1637405965: return bem_toString_0();
case -261636586: return bem_classNameGet_0();
case 1053098123: return bem_hashGet_0();
case -1452952746: return bem_acall_0();
case -1668889460: return bem_propbGet_0();
case -1975952737: return bem_tagGet_0();
case 386788561: return bem_new_0();
case 866679447: return bem_serializationIteratorGet_0();
case 168705805: return bem_iteratorGet_0();
case 1340503259: return bem_propaGet_0();
case 845917022: return bem_fieldIteratorGet_0();
case 582818432: return bem_create_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case 877808917: return bem_prop2aGet_0();
case -1712633963: return bem_toAny_0();
case -935771084: return bem_sourceFileNameGet_0();
case 1449516553: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -217817307: return bem_propbSet_1(bevd_0);
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case -1921133350: return bem_defined_1(bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1121468616: return bem_propaSet_1(bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case 692481445: return bem_prop2aSet_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_6_4_11_SystemTestInExtending_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_11_SystemTestInExtending_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_4_11_SystemTestInExtending();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst = (BEC_3_6_4_11_SystemTestInExtending) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;
}
}
