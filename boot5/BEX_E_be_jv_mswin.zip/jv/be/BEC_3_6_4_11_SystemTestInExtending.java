package be;
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_11_SystemTestInExtending extends BEC_3_6_4_10_SystemTestExtendable {
public BEC_3_6_4_11_SystemTestInExtending() { }
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x49,0x6E,0x45,0x78,0x74,0x65,0x6E,0x64,0x69,0x6E,0x67};
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;

public static BET_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_type;

public BEC_2_6_6_SystemObject bevp_prop2a;
public BEC_3_6_4_11_SystemTestInExtending bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_bcall_0() throws Throwable {
bevp_propa.bemd_0(500389220);
return this;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_ccall_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prop2aGet_0() throws Throwable {
return bevp_prop2a;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_prop2aGetDirect_0() throws Throwable {
return bevp_prop2a;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_prop2aSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_4_11_SystemTestInExtending bem_prop2aSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {222, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 23, 26, 29, 33};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
print 0 222 16
return 1 0 23
return 1 0 26
assign 1 0 29
assign 1 0 33
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -919772434: return bem_serializeToString_0();
case 1928293906: return bem_once_0();
case 619304343: return bem_hashGet_0();
case 1623987490: return bem_serializeContents_0();
case -1206102618: return bem_bcall_0();
case 1733513513: return bem_deserializeClassNameGet_0();
case 868760417: return bem_serializationIteratorGet_0();
case -1836757512: return bem_copy_0();
case 1452564531: return bem_toString_0();
case -757699318: return bem_iteratorGet_0();
case -977356120: return bem_fieldNamesGet_0();
case -252322114: return bem_propaGet_0();
case 1605752359: return bem_many_0();
case 438244040: return bem_create_0();
case 1576417178: return bem_new_0();
case 80468906: return bem_propbGetDirect_0();
case -197180620: return bem_echo_0();
case 1148186102: return bem_toAny_0();
case 141983605: return bem_sourceFileNameGet_0();
case -464967776: return bem_classNameGet_0();
case -771726284: return bem_propaGetDirect_0();
case 500389220: return bem_print_0();
case -321841282: return bem_ccall_0();
case 500071255: return bem_propbGet_0();
case 1021117333: return bem_prop2aGetDirect_0();
case -978724962: return bem_tagGet_0();
case 1503468860: return bem_prop2aGet_0();
case -1895797969: return bem_fieldIteratorGet_0();
case 672308558: return bem_acall_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1838725774: return bem_propaSet_1(bevd_0);
case 1140122456: return bem_sameType_1(bevd_0);
case 2096645963: return bem_propaSetDirect_1(bevd_0);
case -1853663094: return bem_propbSet_1(bevd_0);
case 2141085532: return bem_undefined_1(bevd_0);
case -1724832529: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 902718899: return bem_prop2aSetDirect_1(bevd_0);
case -1386227183: return bem_equals_1(bevd_0);
case 140576519: return bem_undef_1(bevd_0);
case 1455200885: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2110194662: return bem_propbSetDirect_1(bevd_0);
case -1868285108: return bem_def_1(bevd_0);
case -1370861903: return bem_otherClass_1(bevd_0);
case 1016435319: return bem_sameObject_1(bevd_0);
case 125654008: return bem_prop2aSet_1(bevd_0);
case -1158572731: return bem_otherType_1(bevd_0);
case 1108388022: return bem_copyTo_1(bevd_0);
case -1478855850: return bem_sameClass_1(bevd_0);
case 177273835: return bem_notEquals_1(bevd_0);
case -2080355933: return bem_defined_1(bevd_0);
case 559985449: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -925234766: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1155977356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403604142: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 809509937: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1429864581: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 858274939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1387375867: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1832424834: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_6_4_11_SystemTestInExtending_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_11_SystemTestInExtending_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_4_11_SystemTestInExtending();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst = (BEC_3_6_4_11_SystemTestInExtending) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_type;
}
}
