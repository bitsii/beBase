package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_5_BuildClass extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildClass_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildClass_bels_2, 11));
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildClass_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildClass_bels_3, 10));
public static BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public BEC_2_5_5_BuildClass bem_new_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevp_methods = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_isLocal = be.BECS_Runtime.boolFalse;
bevp_isNotNull = be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (new BEC_2_4_3_MathInt(0));
bevp_isList = be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = be.BECS_Runtime.boolFalse;
bevp_belsCount = (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_tmpany_phold);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_tmpany_phold);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) throws Throwable {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_emits == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevp_emits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 139 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 146 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_5_BuildClass_bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
if (bevp_extends == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_5_BuildClass_bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 149 */
} /* Line: 148 */
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() throws Throwable {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() throws Throwable {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() throws Throwable {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() throws Throwable {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() throws Throwable {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() throws Throwable {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() throws Throwable {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() throws Throwable {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() throws Throwable {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() throws Throwable {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() throws Throwable {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() throws Throwable {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() throws Throwable {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 124, 125, 125, 126, 128, 129, 129, 130, 134, 138, 138, 139, 141, 145, 146, 146, 147, 147, 147, 147, 148, 148, 149, 149, 149, 149, 152, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 68, 73, 78, 79, 81, 94, 95, 100, 101, 102, 103, 104, 105, 110, 111, 112, 113, 114, 117, 120, 123, 127, 130, 134, 137, 141, 144, 148, 151, 155, 158, 162, 165, 169, 172, 176, 179, 183, 186, 190, 193, 197, 200, 204, 207, 211, 214, 218, 221, 225, 228, 232, 235, 239, 242, 246, 249, 253, 256, 260, 263, 267, 270, 274, 277};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 104 41
new 0 104 41
assign 1 105 42
new 0 105 42
assign 1 106 43
new 0 106 43
assign 1 107 44
new 0 107 44
assign 1 108 45
new 0 108 45
assign 1 109 46
new 0 109 46
assign 1 110 47
new 0 110 47
assign 1 111 48
new 0 111 48
assign 1 112 49
new 0 112 49
assign 1 113 50
new 0 113 50
assign 1 114 51
new 0 114 51
assign 1 115 52
new 0 115 52
assign 1 116 53
new 0 116 53
assign 1 117 54
new 0 117 54
assign 1 118 55
new 0 118 55
assign 1 119 56
new 0 119 56
assign 1 124 57
new 0 124 57
assign 1 125 58
new 0 125 58
fromString 1 125 59
addUsed 1 126 60
assign 1 128 61
new 0 128 61
assign 1 129 62
new 0 129 62
fromString 1 129 63
addUsed 1 130 64
addValue 1 134 68
assign 1 138 73
undef 1 138 78
assign 1 139 79
new 0 139 79
addValue 1 141 81
assign 1 145 94
classNameGet 0 145 94
assign 1 146 95
def 1 146 100
assign 1 147 101
new 0 147 101
assign 1 147 102
add 1 147 102
assign 1 147 103
toString 0 147 103
assign 1 147 104
add 1 147 104
assign 1 148 105
def 1 148 110
assign 1 149 111
new 0 149 111
assign 1 149 112
add 1 149 112
assign 1 149 113
toString 0 149 113
assign 1 149 114
add 1 149 114
return 1 152 117
return 1 0 120
assign 1 0 123
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
return 1 0 162
assign 1 0 165
return 1 0 169
assign 1 0 172
return 1 0 176
assign 1 0 179
return 1 0 183
assign 1 0 186
return 1 0 190
assign 1 0 193
return 1 0 197
assign 1 0 200
return 1 0 204
assign 1 0 207
return 1 0 211
assign 1 0 214
return 1 0 218
assign 1 0 221
return 1 0 225
assign 1 0 228
return 1 0 232
assign 1 0 235
return 1 0 239
assign 1 0 242
return 1 0 246
assign 1 0 249
return 1 0 253
assign 1 0 256
return 1 0 260
assign 1 0 263
return 1 0 267
assign 1 0 270
return 1 0 274
assign 1 0 277
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 386788561: return bem_new_0();
case 985887573: return bem_emitsGet_0();
case -935771084: return bem_sourceFileNameGet_0();
case -261636586: return bem_classNameGet_0();
case -1620819332: return bem_once_0();
case 1637405965: return bem_toString_0();
case -1715673571: return bem_isListGet_0();
case -1828940205: return bem_firstSlotNativeGet_0();
case -1524814346: return bem_extendsGet_0();
case -216670822: return bem_usedGet_0();
case -1348335897: return bem_methodsGet_0();
case 1395718604: return bem_anyMapGet_0();
case 1951478759: return bem_fromFileGet_0();
case -1975952737: return bem_tagGet_0();
case -1197182710: return bem_serializeToString_0();
case 500168132: return bem_libNameGet_0();
case -1964447476: return bem_belsCountGet_0();
case -1828003583: return bem_isFinalGet_0();
case 582818432: return bem_create_0();
case -1011781326: return bem_onceEvalCountGet_0();
case 1420288115: return bem_shouldWriteGet_0();
case 1342246094: return bem_print_0();
case 168705805: return bem_iteratorGet_0();
case -555828623: return bem_synGet_0();
case -205601664: return bem_orderedVarsGet_0();
case -117420215: return bem_serializeContents_0();
case -1382429075: return bem_isLocalGet_0();
case 1068209058: return bem_nativeSlotsGet_0();
case 1855468091: return bem_freeFirstSlotGet_0();
case 1203841037: return bem_nameGet_0();
case 65678538: return bem_echo_0();
case 866679447: return bem_serializationIteratorGet_0();
case 1053098123: return bem_hashGet_0();
case 1429096521: return bem_orderedMethodsGet_0();
case 2092326455: return bem_many_0();
case 2116244641: return bem_isNotNullGet_0();
case 1758803612: return bem_referencedPropertiesGet_0();
case 1449516553: return bem_copy_0();
case -2010329225: return bem_namepathGet_0();
case 845917022: return bem_fieldIteratorGet_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case -1712633963: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 301795029: return bem_methodsSet_1(bevd_0);
case -1181610225: return bem_referencedPropertiesSet_1(bevd_0);
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case 534605993: return bem_extendsSet_1(bevd_0);
case -1921133350: return bem_defined_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case 1119352987: return bem_isNotNullSet_1(bevd_0);
case 1104438781: return bem_synSet_1(bevd_0);
case 573827232: return bem_onceEvalCountSet_1(bevd_0);
case -903938119: return bem_anyMapSet_1(bevd_0);
case 963648956: return bem_fromFileSet_1(bevd_0);
case 585796536: return bem_isLocalSet_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
case -210370375: return bem_emitsSet_1(bevd_0);
case 2102189090: return bem_usedSet_1(bevd_0);
case -295294009: return bem_orderedMethodsSet_1(bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1198754871: return bem_addUsed_1(bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case 1656796774: return bem_isListSet_1(bevd_0);
case 487975353: return bem_freeFirstSlotSet_1(bevd_0);
case 1863536243: return bem_nameSet_1(bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1603122378: return bem_belsCountSet_1(bevd_0);
case 104633021: return bem_libNameSet_1(bevd_0);
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1881282934: return bem_isFinalSet_1(bevd_0);
case -82684881: return bem_namepathSet_1(bevd_0);
case 1405248564: return bem_orderedVarsSet_1(bevd_0);
case 1647901977: return bem_nativeSlotsSet_1(bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case 1562670199: return bem_addEmit_1(bevd_0);
case -593290797: return bem_firstSlotNativeSet_1(bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case 549058150: return bem_shouldWriteSet_1(bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildClass();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
}
