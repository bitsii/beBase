package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_5_BuildClass extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildClass_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildClass_bels_2, 11));
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildClass_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildClass_bels_3, 10));
public static BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;

public static BET_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public BEC_2_5_5_BuildClass bem_new_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevp_methods = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_isLocal = be.BECS_Runtime.boolFalse;
bevp_isNotNull = be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (new BEC_2_4_3_MathInt(0));
bevp_isList = be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = be.BECS_Runtime.boolFalse;
bevp_belsCount = (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_tmpany_phold);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_tmpany_phold);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) throws Throwable {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_emits == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevp_emits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 139 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 146 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_5_BuildClass_bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
if (bevp_extends == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_5_BuildClass_bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 149 */
} /* Line: 148 */
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() throws Throwable {
return bevp_extends;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_extendsGetDirect_0() throws Throwable {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_extendsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() throws Throwable {
return bevp_emits;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitsGetDirect_0() throws Throwable {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_emitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() throws Throwable {
return bevp_methods;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_methodsGetDirect_0() throws Throwable {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_methodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() throws Throwable {
return bevp_orderedMethods;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGetDirect_0() throws Throwable {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_orderedMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() throws Throwable {
return bevp_used;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_usedGetDirect_0() throws Throwable {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_usedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() throws Throwable {
return bevp_freeFirstSlot;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_freeFirstSlotGetDirect_0() throws Throwable {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_freeFirstSlotSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() throws Throwable {
return bevp_firstSlotNative;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_firstSlotNativeGetDirect_0() throws Throwable {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_firstSlotNativeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() throws Throwable {
return bevp_nativeSlots;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nativeSlotsGetDirect_0() throws Throwable {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_nativeSlotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() throws Throwable {
return bevp_isList;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isListGetDirect_0() throws Throwable {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_isListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() throws Throwable {
return bevp_onceEvalCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_onceEvalCountGetDirect_0() throws Throwable {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_onceEvalCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() throws Throwable {
return bevp_referencedProperties;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_referencedPropertiesGetDirect_0() throws Throwable {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_referencedPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() throws Throwable {
return bevp_shouldWrite;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_shouldWriteGetDirect_0() throws Throwable {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_shouldWriteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() throws Throwable {
return bevp_belsCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_belsCountGetDirect_0() throws Throwable {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildClass bem_belsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 124, 125, 125, 126, 128, 129, 129, 130, 134, 138, 138, 139, 141, 145, 146, 146, 147, 147, 147, 147, 148, 148, 149, 149, 149, 149, 152, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 71, 76, 81, 82, 84, 97, 98, 103, 104, 105, 106, 107, 108, 113, 114, 115, 116, 117, 120, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203, 207, 210, 213, 217, 221, 224, 227, 231, 235, 238, 241, 245, 249, 252, 255, 259, 263, 266, 269, 273, 277, 280, 283, 287, 291, 294, 297, 301, 305, 308, 311, 315, 319, 322, 325, 329, 333, 336, 339, 343, 347, 350, 353, 357, 361, 364, 367, 371, 375, 378, 381, 385, 389, 392, 395, 399, 403, 406, 409, 413, 417, 420, 423, 427, 431, 434, 437, 441};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 104 44
new 0 104 44
assign 1 105 45
new 0 105 45
assign 1 106 46
new 0 106 46
assign 1 107 47
new 0 107 47
assign 1 108 48
new 0 108 48
assign 1 109 49
new 0 109 49
assign 1 110 50
new 0 110 50
assign 1 111 51
new 0 111 51
assign 1 112 52
new 0 112 52
assign 1 113 53
new 0 113 53
assign 1 114 54
new 0 114 54
assign 1 115 55
new 0 115 55
assign 1 116 56
new 0 116 56
assign 1 117 57
new 0 117 57
assign 1 118 58
new 0 118 58
assign 1 119 59
new 0 119 59
assign 1 124 60
new 0 124 60
assign 1 125 61
new 0 125 61
fromString 1 125 62
addUsed 1 126 63
assign 1 128 64
new 0 128 64
assign 1 129 65
new 0 129 65
fromString 1 129 66
addUsed 1 130 67
addValue 1 134 71
assign 1 138 76
undef 1 138 81
assign 1 139 82
new 0 139 82
addValue 1 141 84
assign 1 145 97
classNameGet 0 145 97
assign 1 146 98
def 1 146 103
assign 1 147 104
new 0 147 104
assign 1 147 105
add 1 147 105
assign 1 147 106
toString 0 147 106
assign 1 147 107
add 1 147 107
assign 1 148 108
def 1 148 113
assign 1 149 114
new 0 149 114
assign 1 149 115
add 1 149 115
assign 1 149 116
toString 0 149 116
assign 1 149 117
add 1 149 117
return 1 152 120
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
return 1 0 235
return 1 0 238
assign 1 0 241
assign 1 0 245
return 1 0 249
return 1 0 252
assign 1 0 255
assign 1 0 259
return 1 0 263
return 1 0 266
assign 1 0 269
assign 1 0 273
return 1 0 277
return 1 0 280
assign 1 0 283
assign 1 0 287
return 1 0 291
return 1 0 294
assign 1 0 297
assign 1 0 301
return 1 0 305
return 1 0 308
assign 1 0 311
assign 1 0 315
return 1 0 319
return 1 0 322
assign 1 0 325
assign 1 0 329
return 1 0 333
return 1 0 336
assign 1 0 339
assign 1 0 343
return 1 0 347
return 1 0 350
assign 1 0 353
assign 1 0 357
return 1 0 361
return 1 0 364
assign 1 0 367
assign 1 0 371
return 1 0 375
return 1 0 378
assign 1 0 381
assign 1 0 385
return 1 0 389
return 1 0 392
assign 1 0 395
assign 1 0 399
return 1 0 403
return 1 0 406
assign 1 0 409
assign 1 0 413
return 1 0 417
return 1 0 420
assign 1 0 423
assign 1 0 427
return 1 0 431
return 1 0 434
assign 1 0 437
assign 1 0 441
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2019587701: return bem_isListGet_0();
case -1796790315: return bem_synGet_0();
case 1330906851: return bem_shouldWriteGetDirect_0();
case -555468324: return bem_usedGetDirect_0();
case 92238684: return bem_onceEvalCountGetDirect_0();
case -54366542: return bem_orderedVarsGetDirect_0();
case -601561234: return bem_isLocalGetDirect_0();
case 296622746: return bem_classNameGet_0();
case -1781339164: return bem_orderedVarsGet_0();
case -2047887793: return bem_fromFileGet_0();
case 1261833215: return bem_extendsGet_0();
case 1679558291: return bem_nameGetDirect_0();
case 577093211: return bem_many_0();
case 1800445194: return bem_create_0();
case -314408008: return bem_iteratorGet_0();
case -870262123: return bem_freeFirstSlotGetDirect_0();
case -1302880804: return bem_isLocalGet_0();
case 96897561: return bem_belsCountGetDirect_0();
case -1300455563: return bem_isFinalGet_0();
case -2070999107: return bem_referencedPropertiesGetDirect_0();
case -613316380: return bem_freeFirstSlotGet_0();
case -511250160: return bem_fieldNamesGet_0();
case 843596641: return bem_synGetDirect_0();
case -1768205182: return bem_serializationIteratorGet_0();
case -1920210020: return bem_once_0();
case -2107653327: return bem_fieldIteratorGet_0();
case -212193921: return bem_tagGet_0();
case 1482277663: return bem_echo_0();
case -670803938: return bem_sourceFileNameGet_0();
case -41333960: return bem_deserializeClassNameGet_0();
case -19384722: return bem_toAny_0();
case 1821082307: return bem_print_0();
case -2074204580: return bem_copy_0();
case 1004469699: return bem_emitsGet_0();
case -461072455: return bem_toString_0();
case 1131955867: return bem_isFinalGetDirect_0();
case 1554714772: return bem_extendsGetDirect_0();
case 614649662: return bem_firstSlotNativeGet_0();
case -1074098770: return bem_methodsGet_0();
case -102149480: return bem_serializeToString_0();
case 2075558412: return bem_orderedMethodsGet_0();
case -2089909759: return bem_isNotNullGet_0();
case -1605253198: return bem_libNameGetDirect_0();
case -2003774128: return bem_nameGet_0();
case 1993705736: return bem_serializeContents_0();
case 291405240: return bem_emitsGetDirect_0();
case 1144340710: return bem_namepathGet_0();
case -1065969451: return bem_nativeSlotsGet_0();
case 1181404492: return bem_belsCountGet_0();
case -1309246546: return bem_usedGet_0();
case -1750924278: return bem_orderedMethodsGetDirect_0();
case -1425389541: return bem_new_0();
case -898838673: return bem_isNotNullGetDirect_0();
case 2090341753: return bem_isListGetDirect_0();
case -1189748036: return bem_referencedPropertiesGet_0();
case -537752799: return bem_anyMapGet_0();
case 1544245486: return bem_namepathGetDirect_0();
case -813361985: return bem_methodsGetDirect_0();
case 857020393: return bem_anyMapGetDirect_0();
case -1730964772: return bem_onceEvalCountGet_0();
case -1162356994: return bem_libNameGet_0();
case 361790008: return bem_hashGet_0();
case -1065425852: return bem_shouldWriteGet_0();
case -733709875: return bem_firstSlotNativeGetDirect_0();
case -1936714094: return bem_fromFileGetDirect_0();
case -825285843: return bem_nativeSlotsGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1463366211: return bem_def_1(bevd_0);
case -1272397031: return bem_sameClass_1(bevd_0);
case -695366073: return bem_orderedMethodsSet_1(bevd_0);
case -1559301071: return bem_addEmit_1(bevd_0);
case -1777212675: return bem_isNotNullSetDirect_1(bevd_0);
case -433605868: return bem_extendsSet_1(bevd_0);
case -2092758794: return bem_isListSet_1(bevd_0);
case -513222035: return bem_freeFirstSlotSet_1(bevd_0);
case -53257514: return bem_anyMapSetDirect_1(bevd_0);
case 1491932454: return bem_onceEvalCountSet_1(bevd_0);
case -1196885195: return bem_shouldWriteSet_1(bevd_0);
case 1961670890: return bem_nameSet_1(bevd_0);
case 978518794: return bem_emitsSet_1(bevd_0);
case 889100408: return bem_usedSet_1(bevd_0);
case -331037351: return bem_onceEvalCountSetDirect_1(bevd_0);
case -1817891399: return bem_isListSetDirect_1(bevd_0);
case -1902046644: return bem_usedSetDirect_1(bevd_0);
case 1389268037: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1398560259: return bem_otherType_1(bevd_0);
case -783723091: return bem_methodsSetDirect_1(bevd_0);
case 1687925605: return bem_nativeSlotsSet_1(bevd_0);
case 1988395584: return bem_isFinalSet_1(bevd_0);
case -954306255: return bem_emitsSetDirect_1(bevd_0);
case -320284120: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 953495563: return bem_nameSetDirect_1(bevd_0);
case -787420891: return bem_referencedPropertiesSetDirect_1(bevd_0);
case -1795923123: return bem_freeFirstSlotSetDirect_1(bevd_0);
case -8604500: return bem_libNameSet_1(bevd_0);
case 764373340: return bem_copyTo_1(bevd_0);
case -1170434685: return bem_isFinalSetDirect_1(bevd_0);
case -784434267: return bem_namepathSetDirect_1(bevd_0);
case -676548815: return bem_undef_1(bevd_0);
case -1192710672: return bem_equals_1(bevd_0);
case -1540439331: return bem_fromFileSetDirect_1(bevd_0);
case 493924621: return bem_methodsSet_1(bevd_0);
case -155631619: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1674667455: return bem_nativeSlotsSetDirect_1(bevd_0);
case -1987055831: return bem_notEquals_1(bevd_0);
case -1422724101: return bem_fromFileSet_1(bevd_0);
case 1068752848: return bem_isNotNullSet_1(bevd_0);
case 1975148200: return bem_firstSlotNativeSetDirect_1(bevd_0);
case -906296901: return bem_orderedMethodsSetDirect_1(bevd_0);
case 879754135: return bem_firstSlotNativeSet_1(bevd_0);
case 1631932642: return bem_extendsSetDirect_1(bevd_0);
case -1222973614: return bem_belsCountSetDirect_1(bevd_0);
case 1830061023: return bem_addUsed_1(bevd_0);
case 649915710: return bem_namepathSet_1(bevd_0);
case -1086607946: return bem_orderedVarsSetDirect_1(bevd_0);
case -1399461146: return bem_libNameSetDirect_1(bevd_0);
case -2030735911: return bem_isLocalSet_1(bevd_0);
case 1578472060: return bem_synSetDirect_1(bevd_0);
case -1161197989: return bem_sameType_1(bevd_0);
case -1886279917: return bem_belsCountSet_1(bevd_0);
case -1567535449: return bem_sameObject_1(bevd_0);
case 242004544: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1453208762: return bem_orderedVarsSet_1(bevd_0);
case 192506974: return bem_anyMapSet_1(bevd_0);
case -1342840550: return bem_shouldWriteSetDirect_1(bevd_0);
case 1026739914: return bem_defined_1(bevd_0);
case -1908940247: return bem_otherClass_1(bevd_0);
case -2110248602: return bem_undefined_1(bevd_0);
case 300621033: return bem_synSet_1(bevd_0);
case 114137256: return bem_referencedPropertiesSet_1(bevd_0);
case -1947372346: return bem_isLocalSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 764231776: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -830320987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -711906439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1354452916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1773886690: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220461512: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 278898562: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildClass();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_type;
}
}
