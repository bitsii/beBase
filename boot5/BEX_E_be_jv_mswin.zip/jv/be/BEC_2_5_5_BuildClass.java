package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_5_BuildClass extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
public static BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;

public static BET_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public BEC_2_5_5_BuildClass bem_new_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevp_methods = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_isLocal = be.BECS_Runtime.boolFalse;
bevp_isNotNull = be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (new BEC_2_4_3_MathInt(0));
bevp_isList = be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = be.BECS_Runtime.boolFalse;
bevp_belsCount = (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_ta_ph);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_ta_ph);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) throws Throwable {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_emits == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 137*/ {
bevp_emits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 138*/
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevl_ret = bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_2));
bevt_1_ta_ph = bevl_ret.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
if (bevp_extends == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_3));
bevt_5_ta_ph = bevl_ret.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
} /* Line: 148*/
} /* Line: 147*/
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() throws Throwable {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() throws Throwable {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() throws Throwable {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() throws Throwable {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() throws Throwable {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() throws Throwable {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() throws Throwable {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() throws Throwable {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() throws Throwable {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() throws Throwable {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() throws Throwable {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() throws Throwable {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() throws Throwable {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 123, 124, 124, 125, 127, 128, 128, 129, 133, 137, 137, 138, 140, 144, 145, 145, 146, 146, 146, 146, 147, 147, 148, 148, 148, 148, 151, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 69, 74, 79, 80, 82, 95, 96, 101, 102, 103, 104, 105, 106, 111, 112, 113, 114, 115, 118, 121, 124, 128, 131, 135, 138, 142, 145, 149, 152, 156, 159, 163, 166, 170, 173, 177, 180, 184, 187, 191, 194, 198, 201, 205, 208, 212, 215, 219, 222, 226, 229, 233, 236, 240, 243, 247, 250, 254, 257, 261, 264, 268, 271, 275, 278};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 103 42
new 0 103 42
assign 1 104 43
new 0 104 43
assign 1 105 44
new 0 105 44
assign 1 106 45
new 0 106 45
assign 1 107 46
new 0 107 46
assign 1 108 47
new 0 108 47
assign 1 109 48
new 0 109 48
assign 1 110 49
new 0 110 49
assign 1 111 50
new 0 111 50
assign 1 112 51
new 0 112 51
assign 1 113 52
new 0 113 52
assign 1 114 53
new 0 114 53
assign 1 115 54
new 0 115 54
assign 1 116 55
new 0 116 55
assign 1 117 56
new 0 117 56
assign 1 118 57
new 0 118 57
assign 1 123 58
new 0 123 58
assign 1 124 59
new 0 124 59
fromString 1 124 60
addUsed 1 125 61
assign 1 127 62
new 0 127 62
assign 1 128 63
new 0 128 63
fromString 1 128 64
addUsed 1 129 65
addValue 1 133 69
assign 1 137 74
undef 1 137 79
assign 1 138 80
new 0 138 80
addValue 1 140 82
assign 1 144 95
classNameGet 0 144 95
assign 1 145 96
def 1 145 101
assign 1 146 102
new 0 146 102
assign 1 146 103
add 1 146 103
assign 1 146 104
toString 0 146 104
assign 1 146 105
add 1 146 105
assign 1 147 106
def 1 147 111
assign 1 148 112
new 0 148 112
assign 1 148 113
add 1 148 113
assign 1 148 114
toString 0 148 114
assign 1 148 115
add 1 148 115
return 1 151 118
return 1 0 121
assign 1 0 124
return 1 0 128
assign 1 0 131
return 1 0 135
assign 1 0 138
return 1 0 142
assign 1 0 145
return 1 0 149
assign 1 0 152
return 1 0 156
assign 1 0 159
return 1 0 163
assign 1 0 166
return 1 0 170
assign 1 0 173
return 1 0 177
assign 1 0 180
return 1 0 184
assign 1 0 187
return 1 0 191
assign 1 0 194
return 1 0 198
assign 1 0 201
return 1 0 205
assign 1 0 208
return 1 0 212
assign 1 0 215
return 1 0 219
assign 1 0 222
return 1 0 226
assign 1 0 229
return 1 0 233
assign 1 0 236
return 1 0 240
assign 1 0 243
return 1 0 247
assign 1 0 250
return 1 0 254
assign 1 0 257
return 1 0 261
assign 1 0 264
return 1 0 268
assign 1 0 271
return 1 0 275
assign 1 0 278
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -169489012: return bem_hashGet_0();
case -1672500686: return bem_anyMapGet_0();
case 452850705: return bem_belsCountGet_0();
case -1645472853: return bem_orderedMethodsGet_0();
case 902093803: return bem_new_0();
case 146976840: return bem_iteratorGet_0();
case 1941697074: return bem_synGet_0();
case -1160240821: return bem_orderedVarsGet_0();
case -798754224: return bem_methodsGet_0();
case -103606480: return bem_classNameGet_0();
case -1502342659: return bem_onceEvalCountGet_0();
case 274334329: return bem_emitsGet_0();
case 1935037882: return bem_libNameGet_0();
case -931390569: return bem_isNotNullGet_0();
case -220528685: return bem_nativeSlotsGet_0();
case -239850825: return bem_firstSlotNativeGet_0();
case -1547810058: return bem_isListGet_0();
case 1431977737: return bem_create_0();
case 786281233: return bem_print_0();
case -1236745184: return bem_fromFileGet_0();
case -2022684029: return bem_tagGet_0();
case -1936670813: return bem_toString_0();
case -1883023310: return bem_referencedPropertiesGet_0();
case -565812445: return bem_shouldWriteGet_0();
case -832661413: return bem_copy_0();
case -106014332: return bem_usedGet_0();
case 1836321157: return bem_namepathGet_0();
case -482545438: return bem_nameGet_0();
case -540316062: return bem_isFinalGet_0();
case -1933068582: return bem_isLocalGet_0();
case -1135779580: return bem_extendsGet_0();
case 454848157: return bem_freeFirstSlotGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1841728780: return bem_addEmit_1(bevd_0);
case 1879837114: return bem_addUsed_1(bevd_0);
case 358111662: return bem_isNotNullSet_1(bevd_0);
case 1616286728: return bem_referencedPropertiesSet_1(bevd_0);
case -623160459: return bem_shouldWriteSet_1(bevd_0);
case 1994254348: return bem_usedSet_1(bevd_0);
case -972570526: return bem_isLocalSet_1(bevd_0);
case -2074034102: return bem_sameObject_1(bevd_0);
case -807188599: return bem_isListSet_1(bevd_0);
case 1324342877: return bem_undef_1(bevd_0);
case -7632235: return bem_extendsSet_1(bevd_0);
case 338518726: return bem_methodsSet_1(bevd_0);
case 904780261: return bem_nameSet_1(bevd_0);
case -604821076: return bem_synSet_1(bevd_0);
case -1814604953: return bem_anyMapSet_1(bevd_0);
case 2118717831: return bem_isFinalSet_1(bevd_0);
case 1859867948: return bem_namepathSet_1(bevd_0);
case 1959493383: return bem_notEquals_1(bevd_0);
case -428182403: return bem_fromFileSet_1(bevd_0);
case -133084731: return bem_belsCountSet_1(bevd_0);
case 947068481: return bem_nativeSlotsSet_1(bevd_0);
case 1750033248: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -341094436: return bem_orderedMethodsSet_1(bevd_0);
case 2034521641: return bem_orderedVarsSet_1(bevd_0);
case 1239929173: return bem_copyTo_1(bevd_0);
case 2087795747: return bem_firstSlotNativeSet_1(bevd_0);
case 963437385: return bem_emitsSet_1(bevd_0);
case 1180186674: return bem_onceEvalCountSet_1(bevd_0);
case -1900104838: return bem_equals_1(bevd_0);
case -1124221202: return bem_freeFirstSlotSet_1(bevd_0);
case -586319938: return bem_libNameSet_1(bevd_0);
case -1974318672: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -378001330: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1813762108: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1271563629: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 603991209: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1710912728: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildClass();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_type;
}
}
