package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildCall extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildCall() { }
private static byte[] becc_BEC_2_5_4_BuildCall_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C};
private static byte[] becc_BEC_2_5_4_BuildCall_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_0 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_1, 7));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_2 = {0x20,0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_2, 10));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_3 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_3, 10));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_4 = {0x20,0x6E,0x6F,0x74,0x42,0x6F,0x75,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_4, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_5 = {0x20,0x77,0x61,0x73,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_5, 12));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_6 = {0x47,0x45,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_6, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_7 = {0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_7, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_8 = {0x53,0x45,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_8, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_9 = {0x53,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_9, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_10 = {0x47,0x45,0x54,0x44,0x49,0x52,0x45,0x43,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_10, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_11 = {0x47,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_11, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_12 = {0x53,0x45,0x54,0x44,0x49,0x52,0x45,0x43,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_12, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_13 = {0x53,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_13, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_14 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72,0x20,0x74,0x79,0x70,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_14, 22));
public static BEC_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_inst;

public static BET_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_6_TextString bevp_accessorType;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_literalValue;
public BEC_2_5_8_BuildNamePath bevp_newNp;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_2_5_4_LogicBool bevp_isConstruct;
public BEC_2_5_4_LogicBool bevp_bound;
public BEC_2_5_4_LogicBool bevp_wasBound;
public BEC_2_5_4_LogicBool bevp_wasAccessor;
public BEC_2_5_4_LogicBool bevp_wasOper;
public BEC_2_5_4_LogicBool bevp_isLiteral;
public BEC_2_5_4_LogicBool bevp_isOnce;
public BEC_2_5_4_LogicBool bevp_isMany;
public BEC_2_5_4_LogicBool bevp_checkTypes;
public BEC_2_4_6_TextString bevp_checkTypesType;
public BEC_2_5_4_LogicBool bevp_superCall;
public BEC_2_5_4_LogicBool bevp_wasImpliedConstruct;
public BEC_2_5_4_LogicBool bevp_wasForeachGenned;
public BEC_2_5_4_LogicBool bevp_untyped;
public BEC_2_5_4_LogicBool bevp_isForward;
public BEC_2_9_4_ContainerList bevp_argCasts;
public BEC_2_5_4_BuildCall bem_new_0() throws Throwable {
bevp_isConstruct = be.BECS_Runtime.boolFalse;
bevp_bound = be.BECS_Runtime.boolTrue;
bevp_wasBound = be.BECS_Runtime.boolTrue;
bevp_wasAccessor = be.BECS_Runtime.boolFalse;
bevp_wasOper = be.BECS_Runtime.boolFalse;
bevp_isLiteral = be.BECS_Runtime.boolFalse;
bevp_isOnce = be.BECS_Runtime.boolFalse;
bevp_isMany = be.BECS_Runtime.boolFalse;
bevp_checkTypes = be.BECS_Runtime.boolTrue;
bevp_checkTypesType = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_0));
bevp_superCall = be.BECS_Runtime.boolFalse;
bevp_wasImpliedConstruct = be.BECS_Runtime.boolFalse;
bevp_wasForeachGenned = be.BECS_Runtime.boolFalse;
bevp_untyped = be.BECS_Runtime.boolFalse;
bevp_isForward = be.BECS_Runtime.boolFalse;
bevp_argCasts = (new BEC_2_9_4_ContainerList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 326 */
if (bevp_orgName == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_orgName.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 329 */
if (bevp_numargs == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_2;
bevt_9_tmpany_phold = bevl_ret.bem_add_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
} /* Line: 332 */
if (bevp_bound.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_13_tmpany_phold);
} /* Line: 335 */
if (bevp_wasAccessor.bevi_bool) /* Line: 337 */ {
bevt_14_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_14_tmpany_phold);
} /* Line: 338 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildCall bem_toAccessorName_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_5;
bevt_0_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_6;
bevp_name = bevp_name.bem_add_1(bevt_2_tmpany_phold);
} /* Line: 345 */
 else  /* Line: 344 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_7;
bevt_3_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_8;
bevp_name = bevp_name.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 347 */
 else  /* Line: 344 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_9;
bevt_6_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_10;
bevp_name = bevp_name.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 349 */
 else  /* Line: 344 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_11;
bevt_9_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_12;
bevp_name = bevp_name.bem_add_1(bevt_11_tmpany_phold);
} /* Line: 351 */
 else  /* Line: 352 */ {
bevt_14_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_13;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevp_accessorType);
bevt_12_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_13_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_12_tmpany_phold);
} /* Line: 353 */
} /* Line: 344 */
} /* Line: 344 */
} /* Line: 344 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public final BEC_2_4_6_TextString bem_orgNameGetDirect_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGet_0() throws Throwable {
return bevp_accessorType;
} /*method end*/
public final BEC_2_4_6_TextString bem_accessorTypeGetDirect_0() throws Throwable {
return bevp_accessorType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_accessorTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_numargsGetDirect_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGet_0() throws Throwable {
return bevp_literalValue;
} /*method end*/
public final BEC_2_4_6_TextString bem_literalValueGetDirect_0() throws Throwable {
return bevp_literalValue;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_literalValueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGet_0() throws Throwable {
return bevp_newNp;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_newNpGetDirect_0() throws Throwable {
return bevp_newNp;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_newNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_cposGetDirect_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_cposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGet_0() throws Throwable {
return bevp_isConstruct;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isConstructGetDirect_0() throws Throwable {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_isConstructSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGet_0() throws Throwable {
return bevp_bound;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_boundGetDirect_0() throws Throwable {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_boundSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGet_0() throws Throwable {
return bevp_wasBound;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasBoundGetDirect_0() throws Throwable {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasBoundSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGet_0() throws Throwable {
return bevp_wasAccessor;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasAccessorGetDirect_0() throws Throwable {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGet_0() throws Throwable {
return bevp_wasOper;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasOperGetDirect_0() throws Throwable {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasOperSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGet_0() throws Throwable {
return bevp_isLiteral;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isLiteralGetDirect_0() throws Throwable {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_isLiteralSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOnceGet_0() throws Throwable {
return bevp_isOnce;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isOnceGetDirect_0() throws Throwable {
return bevp_isOnce;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isOnceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_isOnceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isManyGet_0() throws Throwable {
return bevp_isMany;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isManyGetDirect_0() throws Throwable {
return bevp_isMany;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isManySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_isManySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGet_0() throws Throwable {
return bevp_checkTypes;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_checkTypesGetDirect_0() throws Throwable {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_checkTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_checkTypesTypeGet_0() throws Throwable {
return bevp_checkTypesType;
} /*method end*/
public final BEC_2_4_6_TextString bem_checkTypesTypeGetDirect_0() throws Throwable {
return bevp_checkTypesType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_checkTypesTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGet_0() throws Throwable {
return bevp_superCall;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_superCallGetDirect_0() throws Throwable {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_superCallSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGet_0() throws Throwable {
return bevp_wasImpliedConstruct;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasImpliedConstructGetDirect_0() throws Throwable {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasImpliedConstructSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGet_0() throws Throwable {
return bevp_wasForeachGenned;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasForeachGennedGetDirect_0() throws Throwable {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasForeachGennedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGet_0() throws Throwable {
return bevp_untyped;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_untypedGetDirect_0() throws Throwable {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_untypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGet_0() throws Throwable {
return bevp_isForward;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isForwardGetDirect_0() throws Throwable {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_isForwardSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGet_0() throws Throwable {
return bevp_argCasts;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argCastsGetDirect_0() throws Throwable {
return bevp_argCasts;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_argCastsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 317, 324, 325, 325, 326, 326, 326, 326, 328, 328, 329, 329, 329, 329, 331, 331, 332, 332, 332, 332, 334, 334, 335, 335, 338, 338, 340, 344, 344, 345, 345, 346, 346, 347, 347, 348, 348, 349, 349, 350, 350, 351, 351, 353, 353, 353, 353, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 99, 100, 105, 106, 107, 108, 109, 111, 116, 117, 118, 119, 120, 122, 127, 128, 129, 130, 131, 133, 138, 139, 140, 143, 144, 146, 164, 165, 167, 168, 171, 172, 174, 175, 178, 179, 181, 182, 185, 186, 188, 189, 192, 193, 194, 195, 203, 206, 209, 213, 217, 220, 223, 227, 231, 234, 237, 241, 245, 248, 251, 255, 259, 262, 265, 269, 273, 276, 279, 283, 287, 290, 293, 297, 301, 304, 307, 311, 315, 318, 321, 325, 329, 332, 335, 339, 343, 346, 349, 353, 357, 360, 363, 367, 371, 374, 377, 381, 385, 388, 391, 395, 399, 402, 405, 409, 413, 416, 419, 423, 427, 430, 433, 437, 441, 444, 447, 451, 455, 458, 461, 465, 469, 472, 475, 479, 483, 486, 489, 493, 497, 500, 503, 507, 511, 514, 517, 521};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 301 64
new 0 301 64
assign 1 302 65
new 0 302 65
assign 1 303 66
new 0 303 66
assign 1 304 67
new 0 304 67
assign 1 305 68
new 0 305 68
assign 1 306 69
new 0 306 69
assign 1 307 70
new 0 307 70
assign 1 308 71
new 0 308 71
assign 1 309 72
new 0 309 72
assign 1 310 73
new 0 310 73
assign 1 311 74
new 0 311 74
assign 1 312 75
new 0 312 75
assign 1 313 76
new 0 313 76
assign 1 314 77
new 0 314 77
assign 1 315 78
new 0 315 78
assign 1 317 79
new 0 317 79
assign 1 324 99
classNameGet 0 324 99
assign 1 325 100
def 1 325 105
assign 1 326 106
new 0 326 106
assign 1 326 107
add 1 326 107
assign 1 326 108
toString 0 326 108
assign 1 326 109
add 1 326 109
assign 1 328 111
def 1 328 116
assign 1 329 117
new 0 329 117
assign 1 329 118
add 1 329 118
assign 1 329 119
toString 0 329 119
assign 1 329 120
add 1 329 120
assign 1 331 122
def 1 331 127
assign 1 332 128
new 0 332 128
assign 1 332 129
add 1 332 129
assign 1 332 130
toString 0 332 130
assign 1 332 131
add 1 332 131
assign 1 334 133
not 0 334 138
assign 1 335 139
new 0 335 139
assign 1 335 140
add 1 335 140
assign 1 338 143
new 0 338 143
assign 1 338 144
add 1 338 144
return 1 340 146
assign 1 344 164
new 0 344 164
assign 1 344 165
equals 1 344 165
assign 1 345 167
new 0 345 167
assign 1 345 168
add 1 345 168
assign 1 346 171
new 0 346 171
assign 1 346 172
equals 1 346 172
assign 1 347 174
new 0 347 174
assign 1 347 175
add 1 347 175
assign 1 348 178
new 0 348 178
assign 1 348 179
equals 1 348 179
assign 1 349 181
new 0 349 181
assign 1 349 182
add 1 349 182
assign 1 350 185
new 0 350 185
assign 1 350 186
equals 1 350 186
assign 1 351 188
new 0 351 188
assign 1 351 189
add 1 351 189
assign 1 353 192
new 0 353 192
assign 1 353 193
add 1 353 193
assign 1 353 194
new 1 353 194
throw 1 353 195
return 1 0 203
return 1 0 206
assign 1 0 209
assign 1 0 213
return 1 0 217
return 1 0 220
assign 1 0 223
assign 1 0 227
return 1 0 231
return 1 0 234
assign 1 0 237
assign 1 0 241
return 1 0 245
return 1 0 248
assign 1 0 251
assign 1 0 255
return 1 0 259
return 1 0 262
assign 1 0 265
assign 1 0 269
return 1 0 273
return 1 0 276
assign 1 0 279
assign 1 0 283
return 1 0 287
return 1 0 290
assign 1 0 293
assign 1 0 297
return 1 0 301
return 1 0 304
assign 1 0 307
assign 1 0 311
return 1 0 315
return 1 0 318
assign 1 0 321
assign 1 0 325
return 1 0 329
return 1 0 332
assign 1 0 335
assign 1 0 339
return 1 0 343
return 1 0 346
assign 1 0 349
assign 1 0 353
return 1 0 357
return 1 0 360
assign 1 0 363
assign 1 0 367
return 1 0 371
return 1 0 374
assign 1 0 377
assign 1 0 381
return 1 0 385
return 1 0 388
assign 1 0 391
assign 1 0 395
return 1 0 399
return 1 0 402
assign 1 0 405
assign 1 0 409
return 1 0 413
return 1 0 416
assign 1 0 419
assign 1 0 423
return 1 0 427
return 1 0 430
assign 1 0 433
assign 1 0 437
return 1 0 441
return 1 0 444
assign 1 0 447
assign 1 0 451
return 1 0 455
return 1 0 458
assign 1 0 461
assign 1 0 465
return 1 0 469
return 1 0 472
assign 1 0 475
assign 1 0 479
return 1 0 483
return 1 0 486
assign 1 0 489
assign 1 0 493
return 1 0 497
return 1 0 500
assign 1 0 503
assign 1 0 507
return 1 0 511
return 1 0 514
assign 1 0 517
assign 1 0 521
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1439777293: return bem_hashGet_0();
case -1288007822: return bem_newNpGetDirect_0();
case -2073027086: return bem_fieldIteratorGet_0();
case -948982310: return bem_many_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case -1321403182: return bem_nameGetDirect_0();
case -1735079856: return bem_superCallGetDirect_0();
case 2101523382: return bem_cposGet_0();
case -1390490936: return bem_isLiteralGetDirect_0();
case 623957818: return bem_once_0();
case 1233677243: return bem_argCastsGetDirect_0();
case -897350462: return bem_iteratorGet_0();
case 1935136194: return bem_classNameGet_0();
case -1915435848: return bem_boundGetDirect_0();
case -359321936: return bem_checkTypesGet_0();
case 1155360082: return bem_toAccessorName_0();
case 1516161879: return bem_fieldNamesGet_0();
case 1434708187: return bem_orgNameGet_0();
case -1266978523: return bem_superCallGet_0();
case -1969994213: return bem_cposGetDirect_0();
case 450230894: return bem_print_0();
case 1326542704: return bem_tagGet_0();
case 742371580: return bem_serializeToString_0();
case -667471999: return bem_wasAccessorGet_0();
case -1057497728: return bem_untypedGet_0();
case 931504267: return bem_isForwardGetDirect_0();
case 1167771026: return bem_numargsGet_0();
case 765191186: return bem_isConstructGet_0();
case 2031369362: return bem_nameGet_0();
case 723377834: return bem_boundGet_0();
case 1188784683: return bem_wasBoundGet_0();
case -950099139: return bem_wasOperGetDirect_0();
case -2070113098: return bem_create_0();
case 1200936414: return bem_argCastsGet_0();
case 1651974370: return bem_wasAccessorGetDirect_0();
case -210692963: return bem_wasOperGet_0();
case 409663718: return bem_isConstructGetDirect_0();
case 615568362: return bem_orgNameGetDirect_0();
case 1070146794: return bem_toAny_0();
case 480657644: return bem_accessorTypeGet_0();
case -1890794349: return bem_wasForeachGennedGetDirect_0();
case -1750213491: return bem_sourceFileNameGet_0();
case -564632692: return bem_checkTypesGetDirect_0();
case 1822012280: return bem_isOnceGet_0();
case -61288189: return bem_serializationIteratorGet_0();
case 1334439424: return bem_wasImpliedConstructGet_0();
case -698708614: return bem_literalValueGetDirect_0();
case -1556712456: return bem_new_0();
case 724595979: return bem_wasForeachGennedGet_0();
case -1286306958: return bem_wasBoundGetDirect_0();
case -1393813151: return bem_accessorTypeGetDirect_0();
case 68710943: return bem_wasImpliedConstructGetDirect_0();
case -224202535: return bem_isLiteralGet_0();
case 670682025: return bem_newNpGet_0();
case 898940841: return bem_checkTypesTypeGetDirect_0();
case -2094647350: return bem_untypedGetDirect_0();
case 455770300: return bem_numargsGetDirect_0();
case -1936893254: return bem_isManyGet_0();
case 1172450247: return bem_copy_0();
case 2038611021: return bem_isForwardGet_0();
case -937262927: return bem_checkTypesTypeGet_0();
case -1476019175: return bem_toString_0();
case 1730802409: return bem_echo_0();
case -262525036: return bem_literalValueGet_0();
case 1660533487: return bem_serializeContents_0();
case 700001649: return bem_isManyGetDirect_0();
case 1412933369: return bem_isOnceGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -957438933: return bem_undef_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1901606255: return bem_newNpSetDirect_1(bevd_0);
case 1866805969: return bem_superCallSet_1(bevd_0);
case -913015671: return bem_checkTypesSetDirect_1(bevd_0);
case 976436880: return bem_wasImpliedConstructSetDirect_1(bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case -91146709: return bem_isForwardSetDirect_1(bevd_0);
case -297767271: return bem_wasAccessorSetDirect_1(bevd_0);
case -1723771388: return bem_newNpSet_1(bevd_0);
case -1793118385: return bem_isForwardSet_1(bevd_0);
case -473961774: return bem_accessorTypeSetDirect_1(bevd_0);
case 147322055: return bem_isConstructSet_1(bevd_0);
case 1629623941: return bem_argCastsSet_1(bevd_0);
case -299391132: return bem_equals_1(bevd_0);
case -733929448: return bem_wasOperSet_1(bevd_0);
case 1570535893: return bem_literalValueSet_1(bevd_0);
case -10662726: return bem_boundSetDirect_1(bevd_0);
case 1355399541: return bem_isManySetDirect_1(bevd_0);
case 1887602006: return bem_nameSet_1(bevd_0);
case -1582890711: return bem_nameSetDirect_1(bevd_0);
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case -2021154280: return bem_wasOperSetDirect_1(bevd_0);
case -224134971: return bem_argCastsSetDirect_1(bevd_0);
case -1236377789: return bem_wasForeachGennedSetDirect_1(bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case -622488169: return bem_boundSet_1(bevd_0);
case 1980571644: return bem_wasImpliedConstructSet_1(bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case 544690570: return bem_wasForeachGennedSet_1(bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case 444473945: return bem_untypedSetDirect_1(bevd_0);
case 2133488021: return bem_isConstructSetDirect_1(bevd_0);
case 694639716: return bem_isManySet_1(bevd_0);
case 763842534: return bem_numargsSet_1(bevd_0);
case -121949760: return bem_cposSet_1(bevd_0);
case -1194926577: return bem_untypedSet_1(bevd_0);
case 1064558017: return bem_wasBoundSetDirect_1(bevd_0);
case -235547029: return bem_isLiteralSet_1(bevd_0);
case 1496686838: return bem_isOnceSet_1(bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case -515339786: return bem_literalValueSetDirect_1(bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1544855545: return bem_cposSetDirect_1(bevd_0);
case 493291682: return bem_wasAccessorSet_1(bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case -1546107710: return bem_orgNameSet_1(bevd_0);
case 2126275813: return bem_checkTypesTypeSet_1(bevd_0);
case -342881638: return bem_orgNameSetDirect_1(bevd_0);
case -421888760: return bem_accessorTypeSet_1(bevd_0);
case 857601016: return bem_superCallSetDirect_1(bevd_0);
case -2103320426: return bem_checkTypesTypeSetDirect_1(bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case 1717878263: return bem_isOnceSetDirect_1(bevd_0);
case -559039512: return bem_wasBoundSet_1(bevd_0);
case 58299994: return bem_isLiteralSetDirect_1(bevd_0);
case 321940784: return bem_checkTypesSet_1(bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
case 1614880074: return bem_numargsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildCall_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildCall_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildCall();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst = (BEC_2_5_4_BuildCall) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_type;
}
}
