package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildCall extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildCall() { }
private static byte[] becc_BEC_2_5_4_BuildCall_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C};
private static byte[] becc_BEC_2_5_4_BuildCall_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_0 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_2 = {0x20,0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_3 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_4 = {0x20,0x6E,0x6F,0x74,0x42,0x6F,0x75,0x6E,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_5 = {0x20,0x77,0x61,0x73,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_6 = {0x47,0x45,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_7 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_8 = {0x53,0x45,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_9 = {0x53,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_10 = {0x47,0x45,0x54,0x44,0x49,0x52,0x45,0x43,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_11 = {0x47,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_12 = {0x53,0x45,0x54,0x44,0x49,0x52,0x45,0x43,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_13 = {0x53,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_14 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72,0x20,0x74,0x79,0x70,0x65,0x20};
public static BEC_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_inst;

public static BET_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_6_TextString bevp_accessorType;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_literalValue;
public BEC_2_5_8_BuildNamePath bevp_newNp;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_2_5_4_LogicBool bevp_isConstruct;
public BEC_2_5_4_LogicBool bevp_bound;
public BEC_2_5_4_LogicBool bevp_wasBound;
public BEC_2_5_4_LogicBool bevp_wasAccessor;
public BEC_2_5_4_LogicBool bevp_wasOper;
public BEC_2_5_4_LogicBool bevp_isLiteral;
public BEC_2_5_4_LogicBool bevp_checkTypes;
public BEC_2_4_6_TextString bevp_checkTypesType;
public BEC_2_5_4_LogicBool bevp_superCall;
public BEC_2_5_4_LogicBool bevp_wasImpliedConstruct;
public BEC_2_5_4_LogicBool bevp_wasForeachGenned;
public BEC_2_5_4_LogicBool bevp_untyped;
public BEC_2_5_4_LogicBool bevp_isForward;
public BEC_2_9_4_ContainerList bevp_argCasts;
public BEC_2_5_4_BuildCall bem_new_0() throws Throwable {
bevp_isConstruct = be.BECS_Runtime.boolFalse;
bevp_bound = be.BECS_Runtime.boolTrue;
bevp_wasBound = be.BECS_Runtime.boolTrue;
bevp_wasAccessor = be.BECS_Runtime.boolFalse;
bevp_wasOper = be.BECS_Runtime.boolFalse;
bevp_isLiteral = be.BECS_Runtime.boolFalse;
bevp_checkTypes = be.BECS_Runtime.boolTrue;
bevp_checkTypesType = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_0));
bevp_superCall = be.BECS_Runtime.boolFalse;
bevp_wasImpliedConstruct = be.BECS_Runtime.boolFalse;
bevp_wasForeachGenned = be.BECS_Runtime.boolFalse;
bevp_untyped = be.BECS_Runtime.boolFalse;
bevp_isForward = be.BECS_Runtime.boolFalse;
bevp_argCasts = (new BEC_2_9_4_ContainerList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 322*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_1));
bevt_1_ta_ph = bevl_ret.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
} /* Line: 323*/
if (bevp_orgName == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 325*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildCall_bels_2));
bevt_5_ta_ph = bevl_ret.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bevp_orgName.bem_toString_0();
bevl_ret = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
} /* Line: 326*/
if (bevp_numargs == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 328*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildCall_bels_3));
bevt_9_ta_ph = bevl_ret.bem_add_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_numargs.bem_toString_0();
bevl_ret = bevt_9_ta_ph.bem_add_1(bevt_11_ta_ph);
} /* Line: 329*/
if (bevp_bound.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_4));
bevl_ret = bevl_ret.bem_add_1(bevt_13_ta_ph);
} /* Line: 332*/
if (bevp_wasAccessor.bevi_bool)/* Line: 334*/ {
bevt_14_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_4_BuildCall_bels_5));
bevl_ret = bevl_ret.bem_add_1(bevt_14_ta_ph);
} /* Line: 335*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildCall bem_toAccessorName_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_9_SystemException bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_6));
bevt_0_ta_ph = bevp_accessorType.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 341*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_7));
bevp_name = bevp_name.bem_add_1(bevt_2_ta_ph);
} /* Line: 342*/
 else /* Line: 341*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_8));
bevt_3_ta_ph = bevp_accessorType.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 343*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_9));
bevp_name = bevp_name.bem_add_1(bevt_5_ta_ph);
} /* Line: 344*/
 else /* Line: 341*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_10));
bevt_6_ta_ph = bevp_accessorType.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_11));
bevp_name = bevp_name.bem_add_1(bevt_8_ta_ph);
} /* Line: 346*/
 else /* Line: 341*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_12));
bevt_9_ta_ph = bevp_accessorType.bem_equals_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 347*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_13));
bevp_name = bevp_name.bem_add_1(bevt_11_ta_ph);
} /* Line: 348*/
 else /* Line: 349*/ {
bevt_14_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildCall_bels_14));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevp_accessorType);
bevt_12_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_13_ta_ph);
throw new be.BECS_ThrowBack(bevt_12_ta_ph);
} /* Line: 350*/
} /* Line: 341*/
} /* Line: 341*/
} /* Line: 341*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public final BEC_2_4_6_TextString bem_orgNameGetDirect_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGet_0() throws Throwable {
return bevp_accessorType;
} /*method end*/
public final BEC_2_4_6_TextString bem_accessorTypeGetDirect_0() throws Throwable {
return bevp_accessorType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_accessorTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_numargsGetDirect_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGet_0() throws Throwable {
return bevp_literalValue;
} /*method end*/
public final BEC_2_4_6_TextString bem_literalValueGetDirect_0() throws Throwable {
return bevp_literalValue;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_literalValueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGet_0() throws Throwable {
return bevp_newNp;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_newNpGetDirect_0() throws Throwable {
return bevp_newNp;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_newNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_cposGetDirect_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_cposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGet_0() throws Throwable {
return bevp_isConstruct;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isConstructGetDirect_0() throws Throwable {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_isConstructSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGet_0() throws Throwable {
return bevp_bound;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_boundGetDirect_0() throws Throwable {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_boundSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGet_0() throws Throwable {
return bevp_wasBound;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasBoundGetDirect_0() throws Throwable {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasBoundSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGet_0() throws Throwable {
return bevp_wasAccessor;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasAccessorGetDirect_0() throws Throwable {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGet_0() throws Throwable {
return bevp_wasOper;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasOperGetDirect_0() throws Throwable {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasOperSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGet_0() throws Throwable {
return bevp_isLiteral;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isLiteralGetDirect_0() throws Throwable {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_isLiteralSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGet_0() throws Throwable {
return bevp_checkTypes;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_checkTypesGetDirect_0() throws Throwable {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_checkTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_checkTypesTypeGet_0() throws Throwable {
return bevp_checkTypesType;
} /*method end*/
public final BEC_2_4_6_TextString bem_checkTypesTypeGetDirect_0() throws Throwable {
return bevp_checkTypesType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_checkTypesTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGet_0() throws Throwable {
return bevp_superCall;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_superCallGetDirect_0() throws Throwable {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_superCallSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGet_0() throws Throwable {
return bevp_wasImpliedConstruct;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasImpliedConstructGetDirect_0() throws Throwable {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasImpliedConstructSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGet_0() throws Throwable {
return bevp_wasForeachGenned;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wasForeachGennedGetDirect_0() throws Throwable {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_wasForeachGennedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGet_0() throws Throwable {
return bevp_untyped;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_untypedGetDirect_0() throws Throwable {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_untypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGet_0() throws Throwable {
return bevp_isForward;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isForwardGetDirect_0() throws Throwable {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_isForwardSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGet_0() throws Throwable {
return bevp_argCasts;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argCastsGetDirect_0() throws Throwable {
return bevp_argCasts;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildCall bem_argCastsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 314, 321, 322, 322, 323, 323, 323, 323, 325, 325, 326, 326, 326, 326, 328, 328, 329, 329, 329, 329, 331, 331, 332, 332, 335, 335, 337, 341, 341, 342, 342, 343, 343, 344, 344, 345, 345, 346, 346, 347, 347, 348, 348, 350, 350, 350, 350, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 81, 82, 87, 88, 89, 90, 91, 93, 98, 99, 100, 101, 102, 104, 109, 110, 111, 112, 113, 115, 120, 121, 122, 125, 126, 128, 146, 147, 149, 150, 153, 154, 156, 157, 160, 161, 163, 164, 167, 168, 170, 171, 174, 175, 176, 177, 185, 188, 191, 195, 199, 202, 205, 209, 213, 216, 219, 223, 227, 230, 233, 237, 241, 244, 247, 251, 255, 258, 261, 265, 269, 272, 275, 279, 283, 286, 289, 293, 297, 300, 303, 307, 311, 314, 317, 321, 325, 328, 331, 335, 339, 342, 345, 349, 353, 356, 359, 363, 367, 370, 373, 377, 381, 384, 387, 391, 395, 398, 401, 405, 409, 412, 415, 419, 423, 426, 429, 433, 437, 440, 443, 447, 451, 454, 457, 461, 465, 468, 471, 475};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 300 48
new 0 300 48
assign 1 301 49
new 0 301 49
assign 1 302 50
new 0 302 50
assign 1 303 51
new 0 303 51
assign 1 304 52
new 0 304 52
assign 1 305 53
new 0 305 53
assign 1 306 54
new 0 306 54
assign 1 307 55
new 0 307 55
assign 1 308 56
new 0 308 56
assign 1 309 57
new 0 309 57
assign 1 310 58
new 0 310 58
assign 1 311 59
new 0 311 59
assign 1 312 60
new 0 312 60
assign 1 314 61
new 0 314 61
assign 1 321 81
classNameGet 0 321 81
assign 1 322 82
def 1 322 87
assign 1 323 88
new 0 323 88
assign 1 323 89
add 1 323 89
assign 1 323 90
toString 0 323 90
assign 1 323 91
add 1 323 91
assign 1 325 93
def 1 325 98
assign 1 326 99
new 0 326 99
assign 1 326 100
add 1 326 100
assign 1 326 101
toString 0 326 101
assign 1 326 102
add 1 326 102
assign 1 328 104
def 1 328 109
assign 1 329 110
new 0 329 110
assign 1 329 111
add 1 329 111
assign 1 329 112
toString 0 329 112
assign 1 329 113
add 1 329 113
assign 1 331 115
not 0 331 120
assign 1 332 121
new 0 332 121
assign 1 332 122
add 1 332 122
assign 1 335 125
new 0 335 125
assign 1 335 126
add 1 335 126
return 1 337 128
assign 1 341 146
new 0 341 146
assign 1 341 147
equals 1 341 147
assign 1 342 149
new 0 342 149
assign 1 342 150
add 1 342 150
assign 1 343 153
new 0 343 153
assign 1 343 154
equals 1 343 154
assign 1 344 156
new 0 344 156
assign 1 344 157
add 1 344 157
assign 1 345 160
new 0 345 160
assign 1 345 161
equals 1 345 161
assign 1 346 163
new 0 346 163
assign 1 346 164
add 1 346 164
assign 1 347 167
new 0 347 167
assign 1 347 168
equals 1 347 168
assign 1 348 170
new 0 348 170
assign 1 348 171
add 1 348 171
assign 1 350 174
new 0 350 174
assign 1 350 175
add 1 350 175
assign 1 350 176
new 1 350 176
throw 1 350 177
return 1 0 185
return 1 0 188
assign 1 0 191
assign 1 0 195
return 1 0 199
return 1 0 202
assign 1 0 205
assign 1 0 209
return 1 0 213
return 1 0 216
assign 1 0 219
assign 1 0 223
return 1 0 227
return 1 0 230
assign 1 0 233
assign 1 0 237
return 1 0 241
return 1 0 244
assign 1 0 247
assign 1 0 251
return 1 0 255
return 1 0 258
assign 1 0 261
assign 1 0 265
return 1 0 269
return 1 0 272
assign 1 0 275
assign 1 0 279
return 1 0 283
return 1 0 286
assign 1 0 289
assign 1 0 293
return 1 0 297
return 1 0 300
assign 1 0 303
assign 1 0 307
return 1 0 311
return 1 0 314
assign 1 0 317
assign 1 0 321
return 1 0 325
return 1 0 328
assign 1 0 331
assign 1 0 335
return 1 0 339
return 1 0 342
assign 1 0 345
assign 1 0 349
return 1 0 353
return 1 0 356
assign 1 0 359
assign 1 0 363
return 1 0 367
return 1 0 370
assign 1 0 373
assign 1 0 377
return 1 0 381
return 1 0 384
assign 1 0 387
assign 1 0 391
return 1 0 395
return 1 0 398
assign 1 0 401
assign 1 0 405
return 1 0 409
return 1 0 412
assign 1 0 415
assign 1 0 419
return 1 0 423
return 1 0 426
assign 1 0 429
assign 1 0 433
return 1 0 437
return 1 0 440
assign 1 0 443
assign 1 0 447
return 1 0 451
return 1 0 454
assign 1 0 457
assign 1 0 461
return 1 0 465
return 1 0 468
assign 1 0 471
assign 1 0 475
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1448397440: return bem_wasForeachGennedGet_0();
case 774721401: return bem_serializeToString_0();
case 1230014906: return bem_wasImpliedConstructGet_0();
case -2117031246: return bem_isForwardGet_0();
case 1667871470: return bem_wasAccessorGetDirect_0();
case 1600706849: return bem_untypedGetDirect_0();
case 362442119: return bem_newNpGetDirect_0();
case 1124083861: return bem_isLiteralGet_0();
case -1052208297: return bem_superCallGet_0();
case 2087607686: return bem_iteratorGet_0();
case -1111250456: return bem_fieldNamesGet_0();
case 2142974370: return bem_newNpGet_0();
case 2107010550: return bem_boundGet_0();
case -674491561: return bem_sourceFileNameGet_0();
case -1140890468: return bem_nameGetDirect_0();
case -1839332199: return bem_argCastsGetDirect_0();
case 1126911928: return bem_serializeContents_0();
case 881754957: return bem_deserializeClassNameGet_0();
case -419834598: return bem_print_0();
case 833916467: return bem_accessorTypeGet_0();
case -437991849: return bem_toString_0();
case -1454950260: return bem_fieldIteratorGet_0();
case 234248288: return bem_copy_0();
case 1087832621: return bem_tagGet_0();
case -1770692736: return bem_checkTypesGetDirect_0();
case -1814783732: return bem_serializationIteratorGet_0();
case -1138422424: return bem_checkTypesTypeGetDirect_0();
case -1133340290: return bem_wasBoundGetDirect_0();
case -568575955: return bem_hashGet_0();
case -252252123: return bem_cposGet_0();
case -1699804334: return bem_isLiteralGetDirect_0();
case 2038477037: return bem_numargsGet_0();
case -834785593: return bem_wasAccessorGet_0();
case -1278554158: return bem_accessorTypeGetDirect_0();
case 1808192205: return bem_wasOperGetDirect_0();
case 465049448: return bem_isConstructGet_0();
case -1109994440: return bem_wasImpliedConstructGetDirect_0();
case 1380770770: return bem_literalValueGet_0();
case -49547947: return bem_isConstructGetDirect_0();
case -877757628: return bem_boundGetDirect_0();
case -894324063: return bem_argCastsGet_0();
case -18123974: return bem_new_0();
case 1661326373: return bem_cposGetDirect_0();
case 36364789: return bem_orgNameGet_0();
case 1830001964: return bem_checkTypesTypeGet_0();
case -220602072: return bem_echo_0();
case -1715320936: return bem_isForwardGetDirect_0();
case 173990720: return bem_superCallGetDirect_0();
case -1423832566: return bem_toAccessorName_0();
case 84096796: return bem_wasForeachGennedGetDirect_0();
case -763928014: return bem_create_0();
case -829315536: return bem_classNameGet_0();
case 1027189297: return bem_nameGet_0();
case -157068459: return bem_orgNameGetDirect_0();
case 26331022: return bem_numargsGetDirect_0();
case 1186812006: return bem_wasOperGet_0();
case 470606630: return bem_untypedGet_0();
case 101378969: return bem_literalValueGetDirect_0();
case -266897572: return bem_checkTypesGet_0();
case 609059342: return bem_wasBoundGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1007975479: return bem_superCallSet_1(bevd_0);
case 1778197464: return bem_wasForeachGennedSet_1(bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case 889418618: return bem_boundSetDirect_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case 1781436973: return bem_isForwardSet_1(bevd_0);
case 2112281055: return bem_checkTypesSet_1(bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case 1695396518: return bem_numargsSet_1(bevd_0);
case 1433126176: return bem_argCastsSetDirect_1(bevd_0);
case 1687388756: return bem_isLiteralSet_1(bevd_0);
case -1531313566: return bem_newNpSet_1(bevd_0);
case 1232365744: return bem_cposSetDirect_1(bevd_0);
case -1591970870: return bem_newNpSetDirect_1(bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
case -1306175828: return bem_argCastsSet_1(bevd_0);
case 1098845862: return bem_wasAccessorSet_1(bevd_0);
case 419697243: return bem_literalValueSetDirect_1(bevd_0);
case 1909338797: return bem_cposSet_1(bevd_0);
case -274158629: return bem_orgNameSetDirect_1(bevd_0);
case -643713889: return bem_notEquals_1(bevd_0);
case -23598126: return bem_accessorTypeSetDirect_1(bevd_0);
case 266759256: return bem_isLiteralSetDirect_1(bevd_0);
case -1477365807: return bem_wasImpliedConstructSet_1(bevd_0);
case -1605328726: return bem_boundSet_1(bevd_0);
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -852163854: return bem_isConstructSetDirect_1(bevd_0);
case 1065899121: return bem_wasOperSet_1(bevd_0);
case 1208618881: return bem_wasAccessorSetDirect_1(bevd_0);
case 189145657: return bem_wasImpliedConstructSetDirect_1(bevd_0);
case -1140632371: return bem_checkTypesTypeSetDirect_1(bevd_0);
case 113880893: return bem_untypedSetDirect_1(bevd_0);
case -1664445914: return bem_wasBoundSetDirect_1(bevd_0);
case -2118706885: return bem_numargsSetDirect_1(bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1894092078: return bem_nameSetDirect_1(bevd_0);
case 129000755: return bem_wasOperSetDirect_1(bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case -972970897: return bem_wasForeachGennedSetDirect_1(bevd_0);
case -1049660218: return bem_superCallSetDirect_1(bevd_0);
case -1760640825: return bem_accessorTypeSet_1(bevd_0);
case 1841897330: return bem_checkTypesTypeSet_1(bevd_0);
case 691915948: return bem_nameSet_1(bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case 1998136000: return bem_untypedSet_1(bevd_0);
case -1289335328: return bem_literalValueSet_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
case 1747067909: return bem_isConstructSet_1(bevd_0);
case -458622711: return bem_isForwardSetDirect_1(bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case 1115344627: return bem_wasBoundSet_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 283218026: return bem_orgNameSet_1(bevd_0);
case 108868982: return bem_checkTypesSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildCall_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildCall_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildCall();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst = (BEC_2_5_4_BuildCall) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_type;
}
}
