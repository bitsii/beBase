package be;
public class BET_2_8_7_TemplateReplace extends BETS_Object {
public BET_2_8_7_TemplateReplace() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "load_1", "load_2", "accept_2", "stepsGet_0", "stepsSet_1", "lengthGet_0", "lengthSet_1", "appendGet_0", "appendSet_1", "runnerGet_0", "runnerSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "steps", "length", "append", "runner" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_8_7_TemplateReplace();
}
}
