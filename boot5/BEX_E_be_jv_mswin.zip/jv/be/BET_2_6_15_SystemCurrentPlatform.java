package be;
public class BET_2_6_15_SystemCurrentPlatform extends BETS_Object {
public BET_2_6_15_SystemCurrentPlatform() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "new_1", "buildProfile_0", "nameGet_0", "nameGetDirect_0", "nameSet_1", "nameSetDirect_1", "properNameGet_0", "properNameGetDirect_0", "properNameSet_1", "properNameSetDirect_1", "isNixGet_0", "isNixGetDirect_0", "isNixSet_1", "isNixSetDirect_1", "isWinGet_0", "isWinGetDirect_0", "isWinSet_1", "isWinSetDirect_1", "separatorGet_0", "separatorGetDirect_0", "separatorSet_1", "separatorSetDirect_1", "newlineGet_0", "newlineGetDirect_0", "newlineSet_1", "newlineSetDirect_1", "otherSeparatorGet_0", "otherSeparatorGetDirect_0", "otherSeparatorSet_1", "otherSeparatorSetDirect_1", "nullFileGet_0", "nullFileGetDirect_0", "nullFileSet_1", "nullFileSetDirect_1", "scriptExtGet_0", "scriptExtGetDirect_0", "scriptExtSet_1", "scriptExtSetDirect_1", "default_0", "setName_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "name", "properName", "isNix", "isWin", "separator", "newline", "otherSeparator", "nullFile", "scriptExt" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
}
