package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_EncodeHtml extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_EncodeHtml() { }
private static byte[] becc_BEC_2_6_4_EncodeHtml_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x74,0x6D,0x6C};
private static byte[] becc_BEC_2_6_4_EncodeHtml_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_0 = {0x22};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_1 = {0x3C};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_2 = {0x3E};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_3 = {0x26};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_4 = {0x26,0x23};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_5 = {0x3B};
public static BEC_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_inst;

public static BET_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_type;

public BEC_2_6_4_EncodeHtml bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_EncodeHtml bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
bevt_5_ta_ph = beva_str.bem_lengthGet_0();
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_4_ta_ph = bevt_5_ta_ph.bem_multiply_1(bevt_6_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_ta_ph);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_7_ta_ph);
while (true)
/* Line: 145*/ {
bevt_8_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_8_ta_ph.bevi_bool)/* Line: 145*/ {
bevl_tb.bem_next_1(bevl_pt);
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(127));
if (bevl_ac.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 148*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_0));
bevt_12_ta_ph = bevl_pt.bem_equals_1(bevt_13_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 148*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 148*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 148*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_1));
bevt_14_ta_ph = bevl_pt.bem_equals_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_bool)/* Line: 148*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 148*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 148*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_2));
bevt_16_ta_ph = bevl_pt.bem_equals_1(bevt_17_ta_ph);
if (bevt_16_ta_ph.bevi_bool)/* Line: 148*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 148*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 148*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_3));
bevt_18_ta_ph = bevl_pt.bem_equals_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 148*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 148*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 148*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_4_EncodeHtml_bels_4));
bevl_r.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = bevl_ac.bem_toString_0();
bevl_r.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_5));
bevl_r.bem_addValue_1(bevt_22_ta_ph);
} /* Line: 151*/
 else /* Line: 152*/ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 153*/
} /* Line: 148*/
 else /* Line: 145*/ {
break;
} /* Line: 145*/
} /* Line: 145*/
return bevl_r;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {142, 142, 142, 142, 143, 144, 144, 145, 146, 147, 147, 148, 148, 148, 0, 148, 148, 0, 0, 0, 148, 148, 0, 0, 0, 148, 148, 0, 0, 0, 148, 148, 0, 0, 149, 149, 150, 150, 151, 151, 153, 156};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {53, 54, 55, 56, 57, 58, 59, 62, 64, 65, 66, 67, 68, 73, 74, 77, 78, 80, 83, 87, 90, 91, 93, 96, 100, 103, 104, 106, 109, 113, 116, 117, 119, 122, 126, 127, 128, 129, 130, 131, 134, 141};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 142 53
lengthGet 0 142 53
assign 1 142 54
new 0 142 54
assign 1 142 55
multiply 1 142 55
assign 1 142 56
new 1 142 56
assign 1 143 57
new 1 143 57
assign 1 144 58
new 0 144 58
assign 1 144 59
new 1 144 59
assign 1 145 62
hasNextGet 0 145 62
next 1 146 64
assign 1 147 65
new 0 147 65
assign 1 147 66
getCode 1 147 66
assign 1 148 67
new 0 148 67
assign 1 148 68
greater 1 148 73
assign 1 0 74
assign 1 148 77
new 0 148 77
assign 1 148 78
equals 1 148 78
assign 1 0 80
assign 1 0 83
assign 1 0 87
assign 1 148 90
new 0 148 90
assign 1 148 91
equals 1 148 91
assign 1 0 93
assign 1 0 96
assign 1 0 100
assign 1 148 103
new 0 148 103
assign 1 148 104
equals 1 148 104
assign 1 0 106
assign 1 0 109
assign 1 0 113
assign 1 148 116
new 0 148 116
assign 1 148 117
equals 1 148 117
assign 1 0 119
assign 1 0 122
assign 1 149 126
new 0 149 126
addValue 1 149 127
assign 1 150 128
toString 0 150 128
addValue 1 150 129
assign 1 151 130
new 0 151 130
addValue 1 151 131
addValue 1 153 134
return 1 156 141
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1550354971: return bem_print_0();
case -953648774: return bem_create_0();
case -1035398654: return bem_copy_0();
case 1679318778: return bem_toString_0();
case -201610096: return bem_hashGet_0();
case -1614594504: return bem_default_0();
case 1394834757: return bem_new_0();
case 1900805838: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -313527528: return bem_print_1(bevd_0);
case -1715921186: return bem_def_1(bevd_0);
case -873014888: return bem_undef_1(bevd_0);
case -769543545: return bem_copyTo_1(bevd_0);
case -819085863: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 580052299: return bem_notEquals_1(bevd_0);
case 914891998: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1657225406: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -222789624: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 979775573: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1703451725: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_EncodeHtml_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_4_EncodeHtml_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_EncodeHtml();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst = (BEC_2_6_4_EncodeHtml) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_type;
}
}
