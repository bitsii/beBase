package be;
/* IO:File: source/base/Functions.be */
public class BEC_2_6_10_SystemInvocation extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemInvocation() { }
private static byte[] becc_BEC_2_6_10_SystemInvocation_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_10_SystemInvocation_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_inst;
public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemInvocation bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_9_4_ContainerList beva__args) throws Throwable {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_args = beva__args;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(1461540614, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(1461540614, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGet_0() throws Throwable {
return bevp_callName;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {55, 56, 57, 62, 63, 67, 68, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 13, 14, 19, 20, 24, 25, 28, 31, 35, 38, 42, 45};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 55 12
assign 1 56 13
assign 1 57 14
assign 1 62 19
invoke 2 62 19
return 1 63 20
assign 1 67 24
invoke 2 67 24
return 1 68 25
return 1 0 28
assign 1 0 31
return 1 0 35
assign 1 0 38
return 1 0 42
assign 1 0 45
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1387595522: return bem_toAny_0();
case -1601492406: return bem_new_0();
case 436412028: return bem_sourceFileNameGet_0();
case -1550372712: return bem_serializeToString_0();
case 1278732754: return bem_create_0();
case 741511465: return bem_print_0();
case -612311095: return bem_iteratorGet_0();
case 730619711: return bem_many_0();
case -961535531: return bem_hashGet_0();
case 627086221: return bem_once_0();
case 144613256: return bem_serializeContents_0();
case -1194864649: return bem_toString_0();
case 975723195: return bem_argsGet_0();
case -1988392847: return bem_fieldIteratorGet_0();
case 1312002346: return bem_callNameGet_0();
case -570363758: return bem_serializationIteratorGet_0();
case 901060004: return bem_copy_0();
case -211764174: return bem_main_0();
case 1359373450: return bem_echo_0();
case 305137971: return bem_classNameGet_0();
case 1234289396: return bem_tagGet_0();
case -1524930612: return bem_targetGet_0();
case 1186043273: return bem_invoke_0();
case 1087786397: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 661372330: return bem_equals_1(bevd_0);
case -1903482804: return bem_otherClass_1(bevd_0);
case -1086824139: return bem_callNameSet_1(bevd_0);
case -1568064603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1011983528: return bem_argsSet_1(bevd_0);
case -1633632376: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -309742024: return bem_def_1(bevd_0);
case -1377518202: return bem_targetSet_1(bevd_0);
case -1001249520: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1067421305: return bem_notEquals_1(bevd_0);
case 266931166: return bem_undef_1(bevd_0);
case -596533003: return bem_otherType_1(bevd_0);
case 1717289899: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1718194680: return bem_undefined_1(bevd_0);
case -2049241562: return bem_sameObject_1(bevd_0);
case 457153382: return bem_copyTo_1(bevd_0);
case 1420318580: return bem_sameType_1(bevd_0);
case -686450804: return bem_defined_1(bevd_0);
case -1023168427: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1461540614: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513720300: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 224164494: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2129126272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 88269440: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -366737409: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -666768572: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 44950426: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_4_ContainerList) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemInvocation_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_10_SystemInvocation_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemInvocation();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst = (BEC_2_6_10_SystemInvocation) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst;
}
}
