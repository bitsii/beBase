package be;
/* IO:File: source/base/Functions.be */
public class BEC_2_6_10_SystemInvocation extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemInvocation() { }
private static byte[] becc_BEC_2_6_10_SystemInvocation_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_10_SystemInvocation_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_inst;

public static BET_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemInvocation bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_9_4_ContainerList beva__args) throws Throwable {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_args = beva__args;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-432356215, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-432356215, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_targetGetDirect_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGet_0() throws Throwable {
return bevp_callName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_callNameGetDirect_0() throws Throwable {
return bevp_callName;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {57, 58, 59, 64, 65, 69, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 22, 23, 27, 28, 31, 34, 37, 41, 45, 48, 51, 55, 59, 62, 65, 69};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 57 15
assign 1 58 16
assign 1 59 17
assign 1 64 22
invoke 2 64 22
return 1 65 23
assign 1 69 27
invoke 2 69 27
return 1 70 28
return 1 0 31
return 1 0 34
assign 1 0 37
assign 1 0 41
return 1 0 45
return 1 0 48
assign 1 0 51
assign 1 0 55
return 1 0 59
return 1 0 62
assign 1 0 65
assign 1 0 69
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 718019775: return bem_main_0();
case 1533301608: return bem_once_0();
case 2090308182: return bem_serializationIteratorGet_0();
case 469657691: return bem_fieldNamesGet_0();
case -1166070618: return bem_targetGetDirect_0();
case -1070994386: return bem_serializeToString_0();
case 1965801140: return bem_iteratorGet_0();
case 1432496654: return bem_callNameGetDirect_0();
case -1008016829: return bem_argsGet_0();
case -1864181718: return bem_argsGetDirect_0();
case 813213658: return bem_targetGet_0();
case -1248679117: return bem_toString_0();
case -1648057302: return bem_echo_0();
case -1456422317: return bem_toAny_0();
case 983251128: return bem_new_0();
case 1085612775: return bem_tagGet_0();
case -1485421802: return bem_serializeContents_0();
case -369356392: return bem_fieldIteratorGet_0();
case 238971711: return bem_sourceFileNameGet_0();
case 1446040207: return bem_many_0();
case 1350181777: return bem_deserializeClassNameGet_0();
case 2036262769: return bem_callNameGet_0();
case -315448632: return bem_create_0();
case 1579512018: return bem_print_0();
case -1570336996: return bem_invoke_0();
case 677156823: return bem_hashGet_0();
case -1745697587: return bem_classNameGet_0();
case 887875557: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1630597488: return bem_notEquals_1(bevd_0);
case -264285165: return bem_callNameSetDirect_1(bevd_0);
case 851006420: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 203482140: return bem_undefined_1(bevd_0);
case 603494847: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 565121501: return bem_def_1(bevd_0);
case 1812369063: return bem_sameClass_1(bevd_0);
case 2104958141: return bem_argsSet_1(bevd_0);
case 130714078: return bem_equals_1(bevd_0);
case -2023300100: return bem_sameObject_1(bevd_0);
case -513408185: return bem_otherClass_1(bevd_0);
case 1788882700: return bem_undef_1(bevd_0);
case 1894822196: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -580813096: return bem_sameType_1(bevd_0);
case -250946314: return bem_targetSet_1(bevd_0);
case 2007584940: return bem_callNameSet_1(bevd_0);
case 38767287: return bem_copyTo_1(bevd_0);
case -516066761: return bem_defined_1(bevd_0);
case -1693745602: return bem_otherType_1(bevd_0);
case 1474459106: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -874238346: return bem_targetSetDirect_1(bevd_0);
case -1012212343: return bem_argsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 619523077: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -432356215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1753294364: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -693517224: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 391432487: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 828688575: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1676574552: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1543243577: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_4_ContainerList) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemInvocation_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_10_SystemInvocation_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemInvocation();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst = (BEC_2_6_10_SystemInvocation) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_type;
}
}
