package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;

public static BET_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;

public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_buckets;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_set = beva__set;
bevp_buckets = bevp_set.bem_bucketsGet_0();
bevp_modu = bevp_buckets.bem_sizeGet_0();
bevp_current = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_containerGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = bevp_current;
while (true)
/* Line: 613*/ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 613*/ {
bevt_2_ta_ph = bevp_buckets.bem_get_1(bevl_i);
if (bevt_2_ta_ph == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 614*/ {
bevp_current = bevl_i;
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 616*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 613*/
 else /* Line: 613*/ {
break;
} /* Line: 613*/
} /* Line: 613*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_i = bevp_current;
while (true)
/* Line: 623*/ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 623*/ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 625*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_current = bevl_i.bem_add_1(bevt_2_ta_ph);
return bevl_toRet;
} /* Line: 627*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 623*/
 else /* Line: 623*/ {
break;
} /* Line: 623*/
} /* Line: 623*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delete_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_i = bevp_current.bem_subtract_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_i.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 635*/ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 637*/ {
bevt_5_ta_ph = bevl_sn.bem_keyGet_0();
bevt_4_ta_ph = bevp_set.bem_delete_1(bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 638*/ {
bevp_current = bevl_i;
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 640*/
} /* Line: 638*/
} /* Line: 637*/
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {600, 601, 602, 603, 609, 613, 613, 613, 614, 614, 614, 615, 616, 616, 613, 619, 619, 623, 623, 623, 624, 625, 625, 626, 626, 627, 623, 630, 634, 634, 635, 635, 635, 636, 637, 637, 638, 638, 639, 640, 640, 644, 644, 649, 653};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 23, 32, 35, 40, 41, 42, 47, 48, 49, 50, 52, 58, 59, 67, 70, 75, 76, 77, 82, 83, 84, 85, 87, 93, 106, 107, 108, 109, 114, 115, 116, 121, 122, 123, 125, 126, 127, 131, 132, 135, 138};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 600 16
assign 1 601 17
bucketsGet 0 601 17
assign 1 602 18
sizeGet 0 602 18
assign 1 603 19
new 0 603 19
return 1 609 23
assign 1 613 32
assign 1 613 35
lesser 1 613 40
assign 1 614 41
get 1 614 41
assign 1 614 42
def 1 614 47
assign 1 615 48
assign 1 616 49
new 0 616 49
return 1 616 50
assign 1 613 52
increment 0 613 52
assign 1 619 58
new 0 619 58
return 1 619 59
assign 1 623 67
assign 1 623 70
lesser 1 623 75
assign 1 624 76
get 1 624 76
assign 1 625 77
def 1 625 82
assign 1 626 83
new 0 626 83
assign 1 626 84
add 1 626 84
return 1 627 85
assign 1 623 87
increment 0 623 87
return 1 630 93
assign 1 634 106
new 0 634 106
assign 1 634 107
subtract 1 634 107
assign 1 635 108
new 0 635 108
assign 1 635 109
greaterEquals 1 635 114
assign 1 636 115
get 1 636 115
assign 1 637 116
def 1 637 121
assign 1 638 122
keyGet 0 638 122
assign 1 638 123
delete 1 638 123
assign 1 639 125
assign 1 640 126
new 0 640 126
return 1 640 127
assign 1 644 131
new 0 644 131
return 1 644 132
return 1 649 135
return 1 653 138
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1423130981: return bem_hashGet_0();
case 530227489: return bem_new_0();
case -1756046326: return bem_toString_0();
case 1012381645: return bem_create_0();
case 64832086: return bem_containerGet_0();
case 454522998: return bem_print_0();
case 455087168: return bem_iteratorGet_0();
case -1381248709: return bem_nodeIteratorIteratorGet_0();
case 1478255442: return bem_copy_0();
case 214487301: return bem_nextGet_0();
case 764792202: return bem_hasNextGet_0();
case -1549309530: return bem_delete_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 96657329: return bem_notEquals_1(bevd_0);
case 576934107: return bem_copyTo_1(bevd_0);
case -43115079: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 889955668: return bem_undef_1(bevd_0);
case 1276638363: return bem_equals_1(bevd_0);
case 1342373171: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1465920918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1131482033: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 558464110: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 180847688: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;
}
}
