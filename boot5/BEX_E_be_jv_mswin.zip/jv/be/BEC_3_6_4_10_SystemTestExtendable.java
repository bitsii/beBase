package be;
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_10_SystemTestExtendable extends BEC_2_6_6_SystemObject {
public BEC_3_6_4_10_SystemTestExtendable() { }
private static byte[] becc_BEC_3_6_4_10_SystemTestExtendable_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x45,0x78,0x74,0x65,0x6E,0x64,0x61,0x62,0x6C,0x65};
private static byte[] becc_BEC_3_6_4_10_SystemTestExtendable_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_3_6_4_10_SystemTestExtendable bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst;

public static BET_3_6_4_10_SystemTestExtendable bece_BEC_3_6_4_10_SystemTestExtendable_bevs_type;

public BEC_2_6_6_SystemObject bevp_propa;
public BEC_2_6_6_SystemObject bevp_propb;
public BEC_3_6_4_10_SystemTestExtendable bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_6_4_10_SystemTestExtendable bem_acall_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_6_4_10_SystemTestExtendable bem_bcall_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propaGet_0() throws Throwable {
return bevp_propa;
} /*method end*/
public BEC_3_6_4_10_SystemTestExtendable bem_propaSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_propa = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propbGet_0() throws Throwable {
return bevp_propb;
} /*method end*/
public BEC_3_6_4_10_SystemTestExtendable bem_propbSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_propb = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 26, 30, 33};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
return 1 0 23
assign 1 0 26
return 1 0 30
assign 1 0 33
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -96677338: return bem_copy_0();
case -395536224: return bem_iteratorGet_0();
case 299271022: return bem_hashGet_0();
case 687839748: return bem_propbGet_0();
case 1884194420: return bem_print_0();
case 942207105: return bem_propaGet_0();
case 1799552386: return bem_new_0();
case 220656764: return bem_acall_0();
case 1341364362: return bem_create_0();
case -536022669: return bem_bcall_0();
case -1152814540: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -158441044: return bem_def_1(bevd_0);
case -564841251: return bem_propbSet_1(bevd_0);
case 25777534: return bem_notEquals_1(bevd_0);
case -904751583: return bem_undef_1(bevd_0);
case 1292080003: return bem_copyTo_1(bevd_0);
case -659088107: return bem_equals_1(bevd_0);
case 270193694: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -389465645: return bem_propaSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -869432918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 617695149: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 70167069: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -94082723: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1102317820: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_6_4_10_SystemTestExtendable_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_10_SystemTestExtendable_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_4_10_SystemTestExtendable();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_4_10_SystemTestExtendable.bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst = (BEC_3_6_4_10_SystemTestExtendable) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_4_10_SystemTestExtendable.bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_4_10_SystemTestExtendable.bece_BEC_3_6_4_10_SystemTestExtendable_bevs_type;
}
}
