package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_8_DbDirStore extends BEC_2_6_6_SystemObject {
public BEC_2_2_8_DbDirStore() { }
private static byte[] becc_BEC_2_2_8_DbDirStore_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_BEC_2_2_8_DbDirStore_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_0 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_1 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_1, 0));
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_2 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_2, 0));
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_3 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_3, 0));
public static BEC_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_inst;

public static BET_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_type;

public BEC_2_6_10_SystemSerializer bevp_ser;
public BEC_3_2_4_4_IOFilePath bevp_storageDir;
public BEC_2_6_6_SystemObject bevp_keyEncoder;
public BEC_2_2_8_DbDirStore bem_new_2(BEC_2_4_6_TextString beva_storageDir, BEC_2_6_6_SystemObject beva__keyEncoder) throws Throwable {
bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_new_1(BEC_2_4_6_TextString beva_storageDir) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
bem_pathNew_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__storageDir) throws Throwable {
bevp_ser = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getStoreId_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_keyEncoder == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevl_storeId = (BEC_2_4_6_TextString) bevp_keyEncoder.bemd_1(424986730, beva_id);
} /* Line: 374 */
 else  /* Line: 375 */ {
bevl_storeId = beva_id;
} /* Line: 376 */
return bevl_storeId;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_getPath_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_0;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 383 */
 else  /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 383 */ {
bevt_6_tmpany_phold = bevp_storageDir.bem_fileGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_7_tmpany_phold = bevp_storageDir.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 385 */
bevl_storeId = (BEC_2_4_6_TextString) bem_getStoreId_1(beva_id);
bevt_8_tmpany_phold = bevp_storageDir.bem_copy_0();
bevl_p = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevl_storeId);
} /* Line: 388 */
return bevl_p;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_1;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 394 */
 else  /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 394 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_writerGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(740682944);
bevp_ser.bem_serialize_2(beva_object, bevt_5_tmpany_phold);
bevt_9_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevt_8_tmpany_phold.bemd_0(-338991492);
} /* Line: 398 */
} /* Line: 396 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_6_6_SystemObject bevl_object = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_12_tmpany_phold = null;
if (beva_id == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_4_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_2;
bevt_3_tmpany_phold = beva_id.bem_notEquals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 404 */
 else  /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 404 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_existsGet_0();
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 406 */
 else  /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 406 */ {
bevt_10_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_readerGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(740682944);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_tmpany_phold);
bevt_12_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_readerGet_0();
bevt_11_tmpany_phold.bemd_0(-338991492);
return bevl_object;
} /* Line: 409 */
} /* Line: 406 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 416 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_3;
bevt_2_tmpany_phold = beva_id.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 416 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 416 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 416 */
bevl_p = bem_getPath_1(beva_id);
bevt_6_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 418 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 419 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_delete_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_2_4_IOFile bevt_0_tmpany_phold = null;
bevl_p = bem_getPath_1(beva_id);
bevt_0_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_0_tmpany_phold.bem_delete_0();
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serGet_0() throws Throwable {
return bevp_ser;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_serGetDirect_0() throws Throwable {
return bevp_ser;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_serSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_serSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_storageDirGet_0() throws Throwable {
return bevp_storageDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_storageDirGetDirect_0() throws Throwable {
return bevp_storageDir;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_storageDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_storageDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyEncoderGet_0() throws Throwable {
return bevp_keyEncoder;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_keyEncoderGetDirect_0() throws Throwable {
return bevp_keyEncoder;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_keyEncoderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_keyEncoder = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_8_DbDirStore bem_keyEncoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_keyEncoder = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {355, 356, 360, 360, 365, 366, 367, 373, 373, 374, 376, 378, 383, 383, 383, 383, 0, 0, 0, 384, 384, 384, 384, 385, 385, 387, 388, 388, 390, 394, 394, 394, 394, 0, 0, 0, 395, 396, 396, 397, 397, 397, 397, 398, 398, 398, 404, 404, 404, 404, 0, 0, 0, 405, 406, 406, 406, 406, 0, 0, 0, 407, 407, 407, 407, 408, 408, 408, 409, 412, 416, 416, 0, 416, 416, 0, 0, 416, 416, 417, 418, 418, 419, 419, 421, 421, 425, 426, 426, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 29, 30, 34, 35, 36, 42, 47, 48, 51, 53, 67, 72, 73, 74, 76, 79, 83, 86, 87, 88, 93, 94, 95, 97, 98, 99, 101, 115, 120, 121, 122, 124, 127, 131, 134, 135, 140, 141, 142, 143, 144, 145, 146, 147, 168, 173, 174, 175, 177, 180, 184, 187, 188, 193, 194, 195, 197, 200, 204, 207, 208, 209, 210, 211, 212, 213, 214, 217, 230, 235, 236, 239, 240, 242, 245, 249, 250, 252, 253, 254, 256, 257, 259, 260, 265, 266, 267, 271, 274, 277, 281, 285, 288, 291, 295, 299, 302, 305, 309};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 355 23
assign 1 356 24
assign 1 360 29
apNew 1 360 29
pathNew 1 360 30
assign 1 365 34
new 0 365 34
assign 1 366 35
assign 1 367 36
assign 1 373 42
def 1 373 47
assign 1 374 48
encode 1 374 48
assign 1 376 51
return 1 378 53
assign 1 383 67
def 1 383 72
assign 1 383 73
new 0 383 73
assign 1 383 74
notEquals 1 383 74
assign 1 0 76
assign 1 0 79
assign 1 0 83
assign 1 384 86
fileGet 0 384 86
assign 1 384 87
existsGet 0 384 87
assign 1 384 88
not 0 384 93
assign 1 385 94
fileGet 0 385 94
makeDirs 0 385 95
assign 1 387 97
getStoreId 1 387 97
assign 1 388 98
copy 0 388 98
assign 1 388 99
addStep 1 388 99
return 1 390 101
assign 1 394 115
def 1 394 120
assign 1 394 121
new 0 394 121
assign 1 394 122
notEquals 1 394 122
assign 1 0 124
assign 1 0 127
assign 1 0 131
assign 1 395 134
getPath 1 395 134
assign 1 396 135
def 1 396 140
assign 1 397 141
fileGet 0 397 141
assign 1 397 142
writerGet 0 397 142
assign 1 397 143
open 0 397 143
serialize 2 397 144
assign 1 398 145
fileGet 0 398 145
assign 1 398 146
writerGet 0 398 146
close 0 398 147
assign 1 404 168
def 1 404 173
assign 1 404 174
new 0 404 174
assign 1 404 175
notEquals 1 404 175
assign 1 0 177
assign 1 0 180
assign 1 0 184
assign 1 405 187
getPath 1 405 187
assign 1 406 188
def 1 406 193
assign 1 406 194
fileGet 0 406 194
assign 1 406 195
existsGet 0 406 195
assign 1 0 197
assign 1 0 200
assign 1 0 204
assign 1 407 207
fileGet 0 407 207
assign 1 407 208
readerGet 0 407 208
assign 1 407 209
open 0 407 209
assign 1 407 210
deserialize 1 407 210
assign 1 408 211
fileGet 0 408 211
assign 1 408 212
readerGet 0 408 212
close 0 408 213
return 1 409 214
return 1 412 217
assign 1 416 230
undef 1 416 235
assign 1 0 236
assign 1 416 239
new 0 416 239
assign 1 416 240
equals 1 416 240
assign 1 0 242
assign 1 0 245
assign 1 416 249
new 0 416 249
return 1 416 250
assign 1 417 252
getPath 1 417 252
assign 1 418 253
fileGet 0 418 253
assign 1 418 254
existsGet 0 418 254
assign 1 419 256
new 0 419 256
return 1 419 257
assign 1 421 259
new 0 421 259
return 1 421 260
assign 1 425 265
getPath 1 425 265
assign 1 426 266
fileGet 0 426 266
delete 0 426 267
return 1 0 271
return 1 0 274
assign 1 0 277
assign 1 0 281
return 1 0 285
return 1 0 288
assign 1 0 291
assign 1 0 295
return 1 0 299
return 1 0 302
assign 1 0 305
assign 1 0 309
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1515347213: return bem_hashGet_0();
case 507602572: return bem_once_0();
case 631342118: return bem_deserializeClassNameGet_0();
case -862155694: return bem_copy_0();
case -1370019545: return bem_serializeToString_0();
case -647428547: return bem_fieldIteratorGet_0();
case 1379664484: return bem_toAny_0();
case -688295882: return bem_tagGet_0();
case 714809740: return bem_serGetDirect_0();
case 1462002510: return bem_serGet_0();
case -88598489: return bem_keyEncoderGetDirect_0();
case -1814630541: return bem_classNameGet_0();
case 562477328: return bem_serializationIteratorGet_0();
case 886168102: return bem_many_0();
case 146719631: return bem_keyEncoderGet_0();
case 899271096: return bem_new_0();
case -542639344: return bem_toString_0();
case 1884909798: return bem_create_0();
case -1906660880: return bem_print_0();
case 467277446: return bem_storageDirGetDirect_0();
case -973290132: return bem_iteratorGet_0();
case 1688744619: return bem_serializeContents_0();
case -1749904924: return bem_storageDirGet_0();
case -1067099981: return bem_fieldNamesGet_0();
case -21012660: return bem_sourceFileNameGet_0();
case -1648627766: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2120701530: return bem_equals_1(bevd_0);
case -241199401: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1000031854: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1715866358: return bem_notEquals_1(bevd_0);
case -1364853423: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -345992202: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1116816979: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case 216018244: return bem_copyTo_1(bevd_0);
case -1711091481: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1227060021: return bem_serSet_1(bevd_0);
case 164156228: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case -734789597: return bem_undefined_1(bevd_0);
case 1727691035: return bem_storageDirSetDirect_1(bevd_0);
case 1116925492: return bem_sameType_1(bevd_0);
case -1028156837: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1280914604: return bem_otherClass_1(bevd_0);
case 850179474: return bem_storageDirSet_1(bevd_0);
case -2039997: return bem_keyEncoderSetDirect_1(bevd_0);
case 1744917313: return bem_defined_1(bevd_0);
case 1142143738: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -793387435: return bem_keyEncoderSet_1(bevd_0);
case 898034411: return bem_sameClass_1(bevd_0);
case 2001300007: return bem_sameObject_1(bevd_0);
case -914794223: return bem_undef_1(bevd_0);
case 1402754792: return bem_def_1(bevd_0);
case -84369777: return bem_serSetDirect_1(bevd_0);
case 1820085236: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1349849963: return bem_otherType_1(bevd_0);
case 2132455403: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1506940745: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2011759429: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1630879145: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -603725496: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 873825288: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1922480642: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -2028721987: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1784313817: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1485133109: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_2_8_DbDirStore_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_8_DbDirStore_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_8_DbDirStore();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst = (BEC_2_2_8_DbDirStore) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_type;
}
}
