package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_17_TextMultiByteIterator extends BEC_2_4_12_TextByteIterator {
public BEC_2_4_17_TextMultiByteIterator() { }
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x4D,0x75,0x6C,0x74,0x69,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_17_TextMultiByteIterator_bels_0 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x2C,0x20,0x75,0x74,0x66,0x2D,0x38,0x20,0x6D,0x75,0x6C,0x74,0x69,0x62,0x79,0x74,0x65,0x20,0x73,0x65,0x71,0x75,0x65,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x20,0x74,0x68,0x61,0x6E,0x20,0x34,0x20,0x62,0x79,0x74,0x65,0x73};
public static BEC_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;

public static BET_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_bcount;
public BEC_2_4_3_MathInt bevp_ival;
public BEC_2_4_17_TextMultiByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_bcount = (new BEC_2_4_3_MathInt());
bevp_ival = (new BEC_2_4_3_MathInt());
super.bem_new_1(beva__str);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(5));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_6_9_SystemException bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
bevt_2_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_2_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1474*/ {
bevp_str.bem_getInt_2(bevp_pos, bevp_ival);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_ival.bevi_int >= bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1476*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(127));
if (bevp_ival.bevi_int <= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 1476*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1476*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1476*/
 else /* Line: 1476*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1476*/ {
bevp_bcount = (new BEC_2_4_3_MathInt(1));
} /* Line: 1477*/
 else /* Line: 1476*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(-32));
bevt_8_ta_ph = bevp_ival.bem_and_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(-64));
if (bevt_8_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 1478*/ {
bevp_bcount = (new BEC_2_4_3_MathInt(2));
} /* Line: 1479*/
 else /* Line: 1476*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(-16));
bevt_12_ta_ph = bevp_ival.bem_and_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(-32));
if (bevt_12_ta_ph.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 1480*/ {
bevp_bcount = (new BEC_2_4_3_MathInt(3));
} /* Line: 1481*/
 else /* Line: 1476*/ {
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(-8));
bevt_16_ta_ph = bevp_ival.bem_and_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(-16));
if (bevt_16_ta_ph.bevi_int == bevt_18_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 1482*/ {
bevp_bcount = (new BEC_2_4_3_MathInt(4));
} /* Line: 1483*/
 else /* Line: 1484*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(66, bece_BEC_2_4_17_TextMultiByteIterator_bels_0));
bevt_19_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_20_ta_ph);
throw new be.BECS_ThrowBack(bevt_19_ta_ph);
} /* Line: 1485*/
} /* Line: 1476*/
} /* Line: 1476*/
} /* Line: 1476*/
bevt_22_ta_ph = beva_buf.bem_sizeGet_0();
if (bevt_22_ta_ph.bevi_int != bevp_bcount.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 1487*/ {
bevt_23_ta_ph = beva_buf.bem_sizeGet_0();
bevt_23_ta_ph.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1488*/
bevp_bcount.bevi_int += bevp_pos.bevi_int;
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(0));
beva_buf.bem_copyValue_4(bevp_str, bevp_pos, bevp_bcount, bevt_24_ta_ph);
bevp_pos.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1492*/
return beva_buf;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_bcountGet_0() throws Throwable {
return bevp_bcount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_bcountGetDirect_0() throws Throwable {
return bevp_bcount;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_bcountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_bcountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ivalGet_0() throws Throwable {
return bevp_ival;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ivalGetDirect_0() throws Throwable {
return bevp_ival;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_ivalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_ivalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1463, 1464, 1466, 1470, 1470, 1470, 1470, 1474, 1474, 1474, 1475, 1476, 1476, 1476, 1476, 1476, 1476, 0, 0, 0, 1477, 1478, 1478, 1478, 1478, 1478, 1479, 1480, 1480, 1480, 1480, 1480, 1481, 1482, 1482, 1482, 1482, 1482, 1483, 1485, 1485, 1485, 1487, 1487, 1487, 1488, 1488, 1490, 1491, 1491, 1492, 1494, 1498, 1502, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 24, 25, 26, 27, 55, 56, 61, 62, 63, 64, 69, 70, 71, 76, 77, 80, 84, 87, 90, 91, 92, 93, 98, 99, 102, 103, 104, 105, 110, 111, 114, 115, 116, 117, 122, 123, 126, 127, 128, 133, 134, 139, 140, 141, 143, 144, 145, 146, 148, 151, 154, 157, 160, 163, 167, 171, 174, 177, 181};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1463 15
new 0 1463 15
assign 1 1464 16
new 0 1464 16
new 1 1466 17
assign 1 1470 24
new 0 1470 24
assign 1 1470 25
new 1 1470 25
assign 1 1470 26
next 1 1470 26
return 1 1470 27
assign 1 1474 55
sizeGet 0 1474 55
assign 1 1474 56
greater 1 1474 61
getInt 2 1475 62
assign 1 1476 63
new 0 1476 63
assign 1 1476 64
greaterEquals 1 1476 69
assign 1 1476 70
new 0 1476 70
assign 1 1476 71
lesserEquals 1 1476 76
assign 1 0 77
assign 1 0 80
assign 1 0 84
assign 1 1477 87
new 0 1477 87
assign 1 1478 90
new 0 1478 90
assign 1 1478 91
and 1 1478 91
assign 1 1478 92
new 0 1478 92
assign 1 1478 93
equals 1 1478 98
assign 1 1479 99
new 0 1479 99
assign 1 1480 102
new 0 1480 102
assign 1 1480 103
and 1 1480 103
assign 1 1480 104
new 0 1480 104
assign 1 1480 105
equals 1 1480 110
assign 1 1481 111
new 0 1481 111
assign 1 1482 114
new 0 1482 114
assign 1 1482 115
and 1 1482 115
assign 1 1482 116
new 0 1482 116
assign 1 1482 117
equals 1 1482 122
assign 1 1483 123
new 0 1483 123
assign 1 1485 126
new 0 1485 126
assign 1 1485 127
new 1 1485 127
throw 1 1485 128
assign 1 1487 133
sizeGet 0 1487 133
assign 1 1487 134
notEquals 1 1487 139
assign 1 1488 140
sizeGet 0 1488 140
setValue 1 1488 141
addValue 1 1490 143
assign 1 1491 144
new 0 1491 144
copyValue 4 1491 145
setValue 1 1492 146
return 1 1494 148
return 1 1498 151
return 1 1502 154
return 1 0 157
return 1 0 160
assign 1 0 163
assign 1 0 167
return 1 0 171
return 1 0 174
assign 1 0 177
assign 1 0 181
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1485421802: return bem_serializeContents_0();
case 1446040207: return bem_many_0();
case 1533301608: return bem_once_0();
case 458281016: return bem_ivalGetDirect_0();
case 1579512018: return bem_print_0();
case 677156823: return bem_hashGet_0();
case -315448632: return bem_create_0();
case 1173787648: return bem_bcountGetDirect_0();
case -1742282286: return bem_strGet_0();
case 175146487: return bem_bcountGet_0();
case 469657691: return bem_fieldNamesGet_0();
case 2037547095: return bem_posGet_0();
case 1586597499: return bem_ivalGet_0();
case -1648057302: return bem_echo_0();
case -1062387307: return bem_strGetDirect_0();
case -796347509: return bem_hasNextGet_0();
case 238971711: return bem_sourceFileNameGet_0();
case 305711515: return bem_vcopyGetDirect_0();
case -1248679117: return bem_toString_0();
case -1456422317: return bem_toAny_0();
case -1248257717: return bem_vcopyGet_0();
case 1013451926: return bem_containerGet_0();
case 983251128: return bem_new_0();
case 1965801140: return bem_iteratorGet_0();
case 887875557: return bem_copy_0();
case 776055157: return bem_multiByteIteratorIteratorGet_0();
case 1898323567: return bem_byteIteratorIteratorGet_0();
case -275494575: return bem_nextGet_0();
case 1085612775: return bem_tagGet_0();
case 1350181777: return bem_deserializeClassNameGet_0();
case 2090308182: return bem_serializationIteratorGet_0();
case -1070994386: return bem_serializeToString_0();
case -1745697587: return bem_classNameGet_0();
case -369356392: return bem_fieldIteratorGet_0();
case 2139717795: return bem_posGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -386132038: return bem_bcountSet_1(bevd_0);
case 1894822196: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1693745602: return bem_otherType_1(bevd_0);
case 38767287: return bem_copyTo_1(bevd_0);
case 740668336: return bem_posSetDirect_1(bevd_0);
case 1724226543: return bem_bcountSetDirect_1(bevd_0);
case -1630597488: return bem_notEquals_1(bevd_0);
case -1737278009: return bem_vcopySet_1(bevd_0);
case 1740168739: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1812369063: return bem_sameClass_1(bevd_0);
case -516066761: return bem_defined_1(bevd_0);
case -1765818215: return bem_strSetDirect_1(bevd_0);
case -513408185: return bem_otherClass_1(bevd_0);
case 851006420: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2035527377: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case 2007747535: return bem_strSet_1(bevd_0);
case -981599172: return bem_posSet_1(bevd_0);
case 1474459106: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1478016894: return bem_ivalSetDirect_1(bevd_0);
case 603494847: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -288729333: return bem_vcopySetDirect_1(bevd_0);
case 130714078: return bem_equals_1(bevd_0);
case 1271224471: return bem_ivalSet_1(bevd_0);
case -2023300100: return bem_sameObject_1(bevd_0);
case 932156558: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 203482140: return bem_undefined_1(bevd_0);
case -580813096: return bem_sameType_1(bevd_0);
case 1788882700: return bem_undef_1(bevd_0);
case 1430920383: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 565121501: return bem_def_1(bevd_0);
case -422083730: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 619523077: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -432356215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1753294364: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -693517224: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 391432487: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 828688575: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1676574552: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_4_17_TextMultiByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_17_TextMultiByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_17_TextMultiByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst = (BEC_2_4_17_TextMultiByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;
}
}
