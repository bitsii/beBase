package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_17_TextMultiByteIterator extends BEC_2_4_12_TextByteIterator {
public BEC_2_4_17_TextMultiByteIterator() { }
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x4D,0x75,0x6C,0x74,0x69,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_17_TextMultiByteIterator_bels_0 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x2C,0x20,0x75,0x74,0x66,0x2D,0x38,0x20,0x6D,0x75,0x6C,0x74,0x69,0x62,0x79,0x74,0x65,0x20,0x73,0x65,0x71,0x75,0x65,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x20,0x74,0x68,0x61,0x6E,0x20,0x34,0x20,0x62,0x79,0x74,0x65,0x73};
public static BEC_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;

public static BET_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_bcount;
public BEC_2_4_3_MathInt bevp_ival;
public BEC_2_4_17_TextMultiByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_bcount = (new BEC_2_4_3_MathInt());
bevp_ival = (new BEC_2_4_3_MathInt());
super.bem_new_1(beva__str);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(5));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_6_9_SystemException bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
bevt_2_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_2_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1455*/ {
bevp_str.bem_getInt_2(bevp_pos, bevp_ival);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_ival.bevi_int >= bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1457*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(127));
if (bevp_ival.bevi_int <= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 1457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1457*/
 else /* Line: 1457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1457*/ {
bevp_bcount = (new BEC_2_4_3_MathInt(1));
} /* Line: 1458*/
 else /* Line: 1457*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(-32));
bevt_8_ta_ph = bevp_ival.bem_and_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(-64));
if (bevt_8_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 1459*/ {
bevp_bcount = (new BEC_2_4_3_MathInt(2));
} /* Line: 1460*/
 else /* Line: 1457*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(-16));
bevt_12_ta_ph = bevp_ival.bem_and_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(-32));
if (bevt_12_ta_ph.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 1461*/ {
bevp_bcount = (new BEC_2_4_3_MathInt(3));
} /* Line: 1462*/
 else /* Line: 1457*/ {
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(-8));
bevt_16_ta_ph = bevp_ival.bem_and_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(-16));
if (bevt_16_ta_ph.bevi_int == bevt_18_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 1463*/ {
bevp_bcount = (new BEC_2_4_3_MathInt(4));
} /* Line: 1464*/
 else /* Line: 1465*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(66, bece_BEC_2_4_17_TextMultiByteIterator_bels_0));
bevt_19_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_20_ta_ph);
throw new be.BECS_ThrowBack(bevt_19_ta_ph);
} /* Line: 1466*/
} /* Line: 1457*/
} /* Line: 1457*/
} /* Line: 1457*/
bevt_22_ta_ph = beva_buf.bem_sizeGet_0();
if (bevt_22_ta_ph.bevi_int != bevp_bcount.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 1468*/ {
bevt_23_ta_ph = beva_buf.bem_sizeGet_0();
bevt_23_ta_ph.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1469*/
bevp_bcount.bevi_int += bevp_pos.bevi_int;
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(0));
beva_buf.bem_copyValue_4(bevp_str, bevp_pos, bevp_bcount, bevt_24_ta_ph);
bevp_pos.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1473*/
return beva_buf;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_bcountGet_0() throws Throwable {
return bevp_bcount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_bcountGetDirect_0() throws Throwable {
return bevp_bcount;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_bcountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_bcountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ivalGet_0() throws Throwable {
return bevp_ival;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ivalGetDirect_0() throws Throwable {
return bevp_ival;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_ivalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_ivalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1444, 1445, 1447, 1451, 1451, 1451, 1451, 1455, 1455, 1455, 1456, 1457, 1457, 1457, 1457, 1457, 1457, 0, 0, 0, 1458, 1459, 1459, 1459, 1459, 1459, 1460, 1461, 1461, 1461, 1461, 1461, 1462, 1463, 1463, 1463, 1463, 1463, 1464, 1466, 1466, 1466, 1468, 1468, 1468, 1469, 1469, 1471, 1472, 1472, 1473, 1475, 1479, 1483, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 24, 25, 26, 27, 55, 56, 61, 62, 63, 64, 69, 70, 71, 76, 77, 80, 84, 87, 90, 91, 92, 93, 98, 99, 102, 103, 104, 105, 110, 111, 114, 115, 116, 117, 122, 123, 126, 127, 128, 133, 134, 139, 140, 141, 143, 144, 145, 146, 148, 151, 154, 157, 160, 163, 167, 171, 174, 177, 181};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1444 15
new 0 1444 15
assign 1 1445 16
new 0 1445 16
new 1 1447 17
assign 1 1451 24
new 0 1451 24
assign 1 1451 25
new 1 1451 25
assign 1 1451 26
next 1 1451 26
return 1 1451 27
assign 1 1455 55
sizeGet 0 1455 55
assign 1 1455 56
greater 1 1455 61
getInt 2 1456 62
assign 1 1457 63
new 0 1457 63
assign 1 1457 64
greaterEquals 1 1457 69
assign 1 1457 70
new 0 1457 70
assign 1 1457 71
lesserEquals 1 1457 76
assign 1 0 77
assign 1 0 80
assign 1 0 84
assign 1 1458 87
new 0 1458 87
assign 1 1459 90
new 0 1459 90
assign 1 1459 91
and 1 1459 91
assign 1 1459 92
new 0 1459 92
assign 1 1459 93
equals 1 1459 98
assign 1 1460 99
new 0 1460 99
assign 1 1461 102
new 0 1461 102
assign 1 1461 103
and 1 1461 103
assign 1 1461 104
new 0 1461 104
assign 1 1461 105
equals 1 1461 110
assign 1 1462 111
new 0 1462 111
assign 1 1463 114
new 0 1463 114
assign 1 1463 115
and 1 1463 115
assign 1 1463 116
new 0 1463 116
assign 1 1463 117
equals 1 1463 122
assign 1 1464 123
new 0 1464 123
assign 1 1466 126
new 0 1466 126
assign 1 1466 127
new 1 1466 127
throw 1 1466 128
assign 1 1468 133
sizeGet 0 1468 133
assign 1 1468 134
notEquals 1 1468 139
assign 1 1469 140
sizeGet 0 1469 140
setValue 1 1469 141
addValue 1 1471 143
assign 1 1472 144
new 0 1472 144
copyValue 4 1472 145
setValue 1 1473 146
return 1 1475 148
return 1 1479 151
return 1 1483 154
return 1 0 157
return 1 0 160
assign 1 0 163
assign 1 0 167
return 1 0 171
return 1 0 174
assign 1 0 177
assign 1 0 181
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -436425250: return bem_sourceFileNameGet_0();
case -1296133926: return bem_strGet_0();
case 411688773: return bem_toString_0();
case -74182749: return bem_serializationIteratorGet_0();
case 115209925: return bem_fieldIteratorGet_0();
case -1370457182: return bem_tagGet_0();
case 1375821928: return bem_serializeToString_0();
case 545578456: return bem_ivalGet_0();
case -2064971041: return bem_ivalGetDirect_0();
case 665623324: return bem_hasNextGet_0();
case -1574006018: return bem_new_0();
case -2019788295: return bem_fieldNamesGet_0();
case 1982260447: return bem_copy_0();
case 77682213: return bem_hashGet_0();
case 864597329: return bem_vcopyGetDirect_0();
case 55049320: return bem_print_0();
case -1609947385: return bem_echo_0();
case 1400956038: return bem_iteratorGet_0();
case 1357437869: return bem_strGetDirect_0();
case 1792068855: return bem_posGet_0();
case -660861106: return bem_create_0();
case -338202822: return bem_deserializeClassNameGet_0();
case -1825029678: return bem_bcountGetDirect_0();
case 879231054: return bem_classNameGet_0();
case -1178365630: return bem_byteIteratorIteratorGet_0();
case 1553323794: return bem_vcopyGet_0();
case -1284123625: return bem_bcountGet_0();
case 602029329: return bem_posGetDirect_0();
case 645531065: return bem_containerGet_0();
case -272002283: return bem_serializeContents_0();
case 303181667: return bem_nextGet_0();
case -1837858504: return bem_multiByteIteratorIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1548005339: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1537524086: return bem_posSetDirect_1(bevd_0);
case -1313156890: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 1724041773: return bem_notEquals_1(bevd_0);
case 73885221: return bem_vcopySetDirect_1(bevd_0);
case 247454022: return bem_bcountSetDirect_1(bevd_0);
case -1547233575: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1421983771: return bem_bcountSet_1(bevd_0);
case -1179673448: return bem_strSet_1(bevd_0);
case -545796780: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2134509998: return bem_strSetDirect_1(bevd_0);
case -615227441: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1091713249: return bem_posSet_1(bevd_0);
case 1020423162: return bem_otherClass_1(bevd_0);
case -292252818: return bem_undef_1(bevd_0);
case 843541338: return bem_sameObject_1(bevd_0);
case -84338104: return bem_ivalSetDirect_1(bevd_0);
case -1903892968: return bem_equals_1(bevd_0);
case 1531126746: return bem_otherType_1(bevd_0);
case -1520943511: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 462653776: return bem_sameClass_1(bevd_0);
case -544336298: return bem_ivalSet_1(bevd_0);
case 1560006190: return bem_copyTo_1(bevd_0);
case 1706172624: return bem_sameType_1(bevd_0);
case 1277553622: return bem_def_1(bevd_0);
case 924345339: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 47344956: return bem_vcopySet_1(bevd_0);
case -1253673578: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1397786085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1432975146: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 861664880: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 53516876: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1645563126: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_4_17_TextMultiByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_17_TextMultiByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_17_TextMultiByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst = (BEC_2_4_17_TextMultiByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;
}
}
