package be;
/* IO:File: source/build/Nodes.be */
public final class BEC_2_5_4_BuildNode extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
private static byte[] becc_BEC_2_5_4_BuildNode_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_2_5_4_BuildNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_0 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_1 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_5 = {0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_6 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_8 = {0x20,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_9 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_10 = {0x5F,0x74,0x61,0x5F};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_11 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_12 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_13 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_15 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_16 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
public static BEC_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_inst;

public static BET_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_type;

public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_3_9_10_9_ContainerLinkedListAwareNode bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_2_4_3_MathInt(0));
bevp_nlec = (new BEC_2_4_3_MathInt(0));
bevp_wideString = be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_fromNode.bem_nlcGet_0();
bevp_nlc = bevt_0_ta_ph.bem_copy_0();
bevt_1_ta_ph = beva_fromNode.bem_nlecGet_0();
bevp_nlec = bevt_1_ta_ph.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (bevp_contained == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_4_ta_ph = bevp_contained.bem_firstGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_5_ta_ph = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_ta_ph;
} /* Line: 45*/
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
/* Line: 49*/ {
if (bevl_ret == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 49*/ {
if (bevl_con == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 49*/
 else /* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 49*/ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 51*/
 else /* Line: 49*/ {
break;
} /* Line: 49*/
} /* Line: 49*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
/* Line: 59*/ {
if (bevl_ret == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 59*/ {
if (bevl_con == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 59*/
 else /* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 59*/ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 61*/
 else /* Line: 59*/ {
break;
} /* Line: 59*/
} /* Line: 59*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 67*/ {
return null;
} /* Line: 68*/
bevl_hh = bevp_heldBy.bem_nextGet_0();
if (bevl_hh == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 71*/ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 72*/
bevt_2_ta_ph = bevl_hh.bemd_0(194152856);
return (BEC_2_5_4_BuildNode) bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 78*/ {
return null;
} /* Line: 79*/
bevl_hh = bevp_heldBy.bem_priorGet_0();
if (bevl_hh == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 82*/ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 83*/
bevt_2_ta_ph = bevl_hh.bemd_0(194152856);
return (BEC_2_5_4_BuildNode) bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 102*/
bevt_3_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
if (bevp_heldBy == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 108*/ {
bevt_3_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 108*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 108*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 109*/
bevt_7_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_priorGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_11_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_12_ta_ph = null;
if (bevp_heldBy == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_4_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 115*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_7_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_priorGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 115*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 115*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 116*/
bevt_12_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_priorGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_priorGet_0();
if (bevt_10_ta_ph == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 126*/ {
return null;
} /* Line: 127*/
bevp_heldBy.bem_delete_0();
bem_containerSet_1(null);
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
BEC_2_5_4_BuildNode bevt_3_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 135*/ {
return null;
} /* Line: 136*/
bevt_2_ta_ph = bevp_heldBy.bem_mylistGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_newNode_1(beva_x);
bevp_heldBy.bem_insertBefore_1(bevt_1_ta_ph);
bevt_3_ta_ph = bem_containerGet_0();
beva_x.bem_containerSet_1(bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 143*/ {
bem_initContained_0();
} /* Line: 144*/
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 151*/ {
bem_initContained_0();
} /* Line: 152*/
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 163*/ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 164*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try /* Line: 170*/ {
bevl_res = bem_toStringCompact_0();
} /* Line: 171*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(592950024);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 174*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_7_TextStrings bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_7_TextStrings bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_7_TextStrings bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
bevl_prefix = bem_prefixGet_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_2_ta_ph = bevl_prefix.bemd_1(-1389686553, bevt_3_ta_ph);
bevt_4_ta_ph = bevp_typename.bem_toString_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(-1389686553, bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = bevt_1_ta_ph.bemd_1(-1389686553, bevt_5_ta_ph);
bevt_10_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_9_ta_ph = bevt_10_ta_ph.bem_newlineGet_0();
bevt_8_ta_ph = bevl_ret.bemd_1(-1389686553, bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(-1389686553, bevl_prefix);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_2));
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(-1389686553, bevt_11_ta_ph);
bevt_12_ta_ph = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bemd_1(-1389686553, bevt_12_ta_ph);
if (bevp_inClassNp == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 183*/ {
if (bevp_inFile == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 183*/
 else /* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 183*/ {
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_21_ta_ph = bevt_22_ta_ph.bem_newlineGet_0();
bevt_20_ta_ph = bevl_ret.bemd_1(-1389686553, bevt_21_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_1(-1389686553, bevl_prefix);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_3));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-1389686553, bevt_23_ta_ph);
bevt_24_ta_ph = bevp_inClassNp.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(-1389686553, bevt_24_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_4));
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(-1389686553, bevt_25_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-1389686553, bevp_inFile);
bevt_27_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_26_ta_ph = bevt_27_ta_ph.bem_newlineGet_0();
bevl_ret = bevt_15_ta_ph.bemd_1(-1389686553, bevt_26_ta_ph);
} /* Line: 184*/
if (bevp_held == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 186*/ {
bevt_32_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_31_ta_ph = bevt_32_ta_ph.bem_newlineGet_0();
bevt_30_ta_ph = bevl_ret.bemd_1(-1389686553, bevt_31_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(-1389686553, bevl_prefix);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevl_ret = bevt_29_ta_ph.bemd_1(-1389686553, bevt_33_ta_ph);
bevt_34_ta_ph = bevp_held.bemd_0(1909120093);
bevl_ret = bevl_ret.bemd_1(-1389686553, bevt_34_ta_ph);
} /* Line: 188*/
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
bevl_prefix = bem_prefixGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_1_ta_ph = bevl_prefix.bemd_1(-1389686553, bevt_2_ta_ph);
bevt_3_ta_ph = bevp_typename.bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-1389686553, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(-1389686553, bevt_4_ta_ph);
if (bevp_nlc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 196*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_6));
bevt_6_ta_ph = bevl_ret.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
} /* Line: 197*/
if (bevp_inClassNp == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 199*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_7));
bevt_10_ta_ph = bevl_ret.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_ta_ph.bem_add_1(bevt_12_ta_ph);
} /* Line: 200*/
if (bevp_held == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 202*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevt_14_ta_ph = bevl_ret.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = bevp_held.bemd_0(1909120093);
bevl_ret = bevt_14_ta_ph.bem_add_1(bevt_16_ta_ph);
} /* Line: 203*/
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_d = (new BEC_2_4_3_MathInt(0));
bevl_c = bem_containerGet_0();
while (true)
/* Line: 211*/ {
if (bevl_c == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 211*/ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 213*/
 else /* Line: 211*/ {
break;
} /* Line: 211*/
} /* Line: 211*/
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_d = bem_depthGet_0();
bevl_p = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_4_BuildNode_bels_8));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 222*/ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 222*/ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 222*/
 else /* Line: 222*/ {
break;
} /* Line: 222*/
} /* Line: 222*/
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 230*/ {
if (bevl_targ == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 230*/ {
bevt_3_ta_ph = bevl_targ.bemd_0(-1696436091);
bevt_4_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(-1308882044, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 230*/
 else /* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 230*/ {
bevl_targ = bevl_targ.bemd_0(1631932912);
} /* Line: 231*/
 else /* Line: 230*/ {
break;
} /* Line: 230*/
} /* Line: 230*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_clnode = bem_scopeGet_0();
bevt_1_ta_ph = bevl_clnode.bemd_0(-1696436091);
bevt_2_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-1308882044, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 238*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildNode_bels_9));
bevt_3_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 239*/
bevt_6_ta_ph = bevl_clnode.bemd_0(194152856);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(626916174);
bevl_tmpanyn = bevt_5_ta_ph.bemd_0(1909120093);
bevt_8_ta_ph = bevl_clnode.bemd_0(194152856);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(626916174);
bevt_7_ta_ph.bemd_0(457101503);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(969864676, bevt_9_ta_ph);
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(-1616620445, bevt_10_ta_ph);
bevl_tmpany.bemd_1(1828782564, beva_suffix);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_BuildNode_bels_10));
bevt_12_ta_ph = bevl_tmpanyn.bemd_1(-1389686553, bevt_13_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(-1389686553, beva_suffix);
bevl_tmpany.bemd_1(-187781316, bevt_11_ta_ph);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevl_con = bem_containerGet_0();
while (true)
/* Line: 253*/ {
if (bevl_con == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 253*/ {
bevt_3_ta_ph = bevl_con.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_SLOTSGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 254*/ {
bevt_6_ta_ph = bevl_con.bem_typenameGet_0();
bevt_7_ta_ph = bevp_ntypes.bem_FIELDSGet_0();
if (bevt_6_ta_ph.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 254*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 254*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 254*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_8_ta_ph;
} /* Line: 255*/
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 257*/
 else /* Line: 253*/ {
break;
} /* Line: 253*/
} /* Line: 253*/
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inSlotsGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_con = bem_containerGet_0();
while (true)
/* Line: 264*/ {
if (bevl_con == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 264*/ {
bevt_2_ta_ph = bevl_con.bem_typenameGet_0();
bevt_3_ta_ph = bevp_ntypes.bem_SLOTSGet_0();
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 265*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 266*/
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 268*/
 else /* Line: 264*/ {
break;
} /* Line: 264*/
} /* Line: 264*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
bevl_v = bevp_held;
bevt_2_ta_ph = bevl_v.bemd_0(-410016122);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(2060369684);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 275*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1180850566, bevt_3_ta_ph);
bevl_sco = bem_scopeGet_0();
bevt_5_ta_ph = bevl_sco.bemd_0(-1696436091);
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(441346402, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 278*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_4_BuildNode_bels_11));
bevt_7_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_7_ta_ph);
} /* Line: 279*/
bevt_9_ta_ph = bem_inPropertiesGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 281*/ {
bevt_11_ta_ph = bevl_v.bemd_0(1643090671);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(2060369684);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 281*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 281*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 281*/
 else /* Line: 281*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 281*/ {
bevl_sco = bem_classGet_0();
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(985368494, bevt_12_ta_ph);
bevt_13_ta_ph = bem_inSlotsGet_0();
if (bevt_13_ta_ph.bevi_bool)/* Line: 284*/ {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1286081851, bevt_14_ta_ph);
} /* Line: 285*/
} /* Line: 284*/
bevl_sc = bevl_sco.bemd_0(194152856);
bevt_16_ta_ph = bevl_sc.bemd_0(1921368993);
bevt_17_ta_ph = bevl_v.bemd_0(-1010906356);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-1283513449, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 289*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_4_BuildNode_bels_12));
bevt_18_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_18_ta_ph);
} /* Line: 290*/
bevt_20_ta_ph = bevl_sc.bemd_0(1921368993);
bevt_21_ta_ph = bevl_v.bemd_0(-1010906356);
bevt_20_ta_ph.bemd_2(-529143997, bevt_21_ta_ph, this);
bevt_22_ta_ph = bevl_sc.bemd_0(-447177723);
bevt_22_ta_ph.bemd_1(-1179923885, this);
} /* Line: 293*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevl_v = bevp_held;
bevt_1_ta_ph = bevl_v.bemd_0(-410016122);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(2060369684);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 299*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1180850566, bevt_2_ta_ph);
bevl_sco = bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(194152856);
bevt_4_ta_ph = bevl_sc.bemd_0(1921368993);
bevt_5_ta_ph = bevl_v.bemd_0(-1010906356);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(-1283513449, bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 303*/ {
bevt_6_ta_ph = bevl_sc.bemd_0(1921368993);
bevt_7_ta_ph = bevl_v.bemd_0(-1010906356);
bevp_held = bevt_6_ta_ph.bemd_1(1529971033, bevt_7_ta_ph);
} /* Line: 304*/
 else /* Line: 305*/ {
bevt_8_ta_ph = bem_classGet_0();
bevl_cl = bevt_8_ta_ph.bemd_0(194152856);
bevt_10_ta_ph = bevl_cl.bemd_0(1921368993);
bevt_11_ta_ph = bevl_v.bemd_0(-1010906356);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(-1283513449, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 307*/ {
bevt_12_ta_ph = bevl_cl.bemd_0(1921368993);
bevt_13_ta_ph = bevl_v.bemd_0(-1010906356);
bevp_held = bevt_12_ta_ph.bemd_1(1529971033, bevt_13_ta_ph);
} /* Line: 308*/
 else /* Line: 309*/ {
bevt_14_ta_ph = bevl_sc.bemd_0(1921368993);
bevt_15_ta_ph = bevl_v.bemd_0(-1010906356);
bevt_14_ta_ph.bemd_2(-529143997, bevt_15_ta_ph, this);
bevt_16_ta_ph = bevl_sc.bemd_0(-447177723);
bevt_16_ta_ph.bemd_1(-1179923885, this);
bevt_18_ta_ph = bevl_sco.bemd_0(-1696436091);
bevt_19_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(441346402, bevt_19_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 312*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_4_BuildNode_bels_13));
bevt_20_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_20_ta_ph);
} /* Line: 313*/
} /* Line: 312*/
} /* Line: 307*/
} /* Line: 303*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_13_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
bevl_vname = bevp_held;
bevt_0_ta_ph = bem_scopeGet_0();
bevl_sc = bevt_0_ta_ph.bemd_0(194152856);
bevt_2_ta_ph = bevl_sc.bemd_0(1921368993);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(-1283513449, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 324*/ {
bevt_4_ta_ph = bevl_sc.bemd_0(1921368993);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(1529971033, bevl_vname);
bevp_held = bevt_3_ta_ph.bemd_0(194152856);
} /* Line: 325*/
 else /* Line: 326*/ {
bevt_5_ta_ph = bem_classGet_0();
bevl_cl = bevt_5_ta_ph.bemd_0(194152856);
bevt_7_ta_ph = bevl_cl.bemd_0(1921368993);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(-1283513449, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 328*/ {
bevt_9_ta_ph = bevl_cl.bemd_0(1921368993);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_1(1529971033, bevl_vname);
bevp_held = bevt_8_ta_ph.bemd_0(194152856);
} /* Line: 329*/
 else /* Line: 330*/ {
bevl_tunode = bem_transUnitGet_0();
bevt_11_ta_ph = bevl_tunode.bemd_0(194152856);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(1372986364);
bevl_np = bevt_10_ta_ph.bemd_1(1529971033, bevl_vname);
if (bevl_np == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_14_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_aliasedGet_0();
bevl_np = bevt_13_ta_ph.bem_get_1(bevl_vname);
} /* Line: 334*/
if (bevl_np == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_14));
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(bevl_np);
bevt_16_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_16_ta_ph);
} /* Line: 337*/
 else /* Line: 338*/ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(-187781316, bevl_vname);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_15));
bevt_19_ta_ph = bevl_vname.bemd_1(441346402, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_19_ta_ph).bevi_bool)/* Line: 342*/ {
bevp_held = bevl_v;
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1950006483, bevt_21_ta_ph);
bevt_22_ta_ph = bevl_cl.bemd_0(-1563576528);
bevl_v.bemd_1(211543340, bevt_22_ta_ph);
bevt_23_ta_ph = bevl_sc.bemd_0(1921368993);
bevt_23_ta_ph.bemd_2(-529143997, bevl_vname, this);
bevt_24_ta_ph = bevl_sc.bemd_0(-447177723);
bevt_24_ta_ph.bemd_1(-1179923885, this);
} /* Line: 347*/
 else /* Line: 348*/ {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(416448884, bevt_25_ta_ph);
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(985368494, bevt_26_ta_ph);
bevp_held = bevl_v;
bevt_27_ta_ph = bevl_cl.bemd_0(1921368993);
bevt_27_ta_ph.bemd_2(-529143997, bevl_vname, this);
bevt_28_ta_ph = bevl_cl.bemd_0(-447177723);
bevt_28_ta_ph.bemd_1(-1179923885, this);
} /* Line: 353*/
} /* Line: 342*/
} /* Line: 336*/
} /* Line: 328*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_node = this;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 362*/ {
while (true)
/* Line: 363*/ {
bevt_2_ta_ph = bevp_constants.bem_anchorTypesGet_0();
bevt_3_ta_ph = bevl_node.bemd_0(-1696436091);
bevt_1_ta_ph = bevt_2_ta_ph.bem_has_1(bevt_3_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 364*/ {
return bevl_node;
} /* Line: 365*/
 else /* Line: 366*/ {
bevl_node = bevl_node.bemd_0(1631932912);
if (bevl_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 368*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_16));
bevt_5_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 369*/
} /* Line: 368*/
} /* Line: 364*/
} /* Line: 363*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 378*/ {
if (bevl_targ == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 378*/ {
bevt_3_ta_ph = bevl_targ.bemd_0(-1696436091);
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(-1308882044, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 378*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 378*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 378*/
 else /* Line: 378*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 378*/ {
bevl_targ = bevl_targ.bemd_0(1631932912);
} /* Line: 379*/
 else /* Line: 378*/ {
break;
} /* Line: 378*/
} /* Line: 378*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 386*/ {
if (bevl_targ == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 386*/ {
bevt_5_ta_ph = bevl_targ.bemd_0(-1696436091);
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(-1308882044, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 386*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 386*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 386*/
 else /* Line: 386*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 386*/ {
bevt_8_ta_ph = bevl_targ.bemd_0(-1696436091);
bevt_9_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(-1308882044, bevt_9_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 386*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 386*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 386*/
 else /* Line: 386*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 386*/ {
bevt_11_ta_ph = bevl_targ.bemd_0(-1696436091);
bevt_12_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(-1308882044, bevt_12_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 386*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 386*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 386*/
 else /* Line: 386*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 386*/ {
bevl_targ = bevl_targ.bemd_0(1631932912);
} /* Line: 387*/
 else /* Line: 386*/ {
break;
} /* Line: 386*/
} /* Line: 386*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_BuildNode bevt_1_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 393*/ {
return null;
} /* Line: 394*/
bevt_1_ta_ph = bem_containerGet_0();
beva_other.bem_containerSet_1(bevt_1_ta_ph);
bevp_heldBy.bem_heldSet_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
/* Line: 407*/ {
bevt_0_ta_ph = bevl_it.bemd_0(-542409727);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 407*/ {
bevl_i = bevl_it.bemd_0(698381837);
bevl_i.bemd_1(901608681, this);
} /* Line: 409*/
 else /* Line: 407*/ {
break;
} /* Line: 407*/
} /* Line: 407*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
bevt_1_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 415*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 417*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 418*/
} /* Line: 417*/
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 421*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-563490785);
if (bevl_np == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 423*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 424*/
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-1563576528);
if (bevl_np == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 427*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 428*/
bevt_8_ta_ph = bevp_held.bemd_0(-563490785);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(1909120093);
bevp_held.bemd_1(-187781316, bevt_7_ta_ph);
} /* Line: 430*/
bevt_10_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 432*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-563490785);
if (bevl_np == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 434*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 435*/
} /* Line: 434*/
return this;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() throws Throwable {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_condany = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeDetail = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 37, 37, 38, 38, 39, 40, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 47, 48, 49, 49, 49, 49, 0, 0, 0, 50, 51, 53, 57, 58, 59, 59, 59, 59, 0, 0, 0, 60, 61, 63, 67, 67, 68, 70, 71, 71, 72, 74, 74, 78, 78, 79, 81, 82, 82, 83, 85, 85, 89, 89, 93, 93, 97, 97, 101, 101, 102, 102, 104, 104, 104, 108, 108, 0, 108, 108, 108, 0, 0, 109, 109, 111, 111, 111, 111, 115, 115, 0, 115, 115, 115, 0, 0, 0, 115, 115, 115, 115, 0, 0, 116, 116, 118, 118, 118, 118, 118, 122, 126, 126, 127, 129, 130, 131, 135, 135, 136, 138, 138, 138, 139, 139, 143, 143, 144, 146, 147, 151, 151, 152, 154, 155, 159, 163, 163, 164, 171, 173, 174, 176, 180, 181, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 0, 0, 0, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 187, 187, 188, 188, 190, 194, 195, 195, 195, 195, 195, 195, 196, 196, 197, 197, 197, 197, 199, 199, 200, 200, 200, 200, 202, 202, 203, 203, 203, 203, 205, 209, 210, 211, 211, 212, 213, 215, 219, 220, 221, 222, 222, 222, 223, 222, 225, 229, 230, 230, 230, 230, 230, 0, 0, 0, 231, 233, 237, 238, 238, 238, 239, 239, 239, 241, 241, 241, 242, 242, 242, 243, 244, 244, 245, 245, 246, 247, 247, 247, 247, 248, 252, 253, 253, 254, 254, 254, 254, 0, 254, 254, 254, 254, 0, 0, 255, 255, 257, 259, 259, 263, 264, 264, 265, 265, 265, 265, 266, 266, 268, 270, 270, 274, 275, 275, 276, 276, 277, 278, 278, 278, 279, 279, 279, 281, 281, 281, 0, 0, 0, 282, 283, 283, 284, 285, 285, 288, 289, 289, 289, 290, 290, 290, 292, 292, 292, 293, 293, 298, 299, 299, 300, 300, 301, 302, 303, 303, 303, 304, 304, 304, 306, 306, 307, 307, 307, 308, 308, 308, 310, 310, 310, 311, 311, 312, 312, 312, 313, 313, 313, 322, 323, 323, 324, 324, 325, 325, 325, 327, 327, 328, 328, 329, 329, 329, 331, 332, 332, 332, 333, 333, 334, 334, 334, 336, 336, 337, 337, 337, 337, 340, 341, 342, 342, 343, 344, 344, 345, 345, 346, 346, 347, 347, 349, 349, 350, 350, 351, 352, 352, 353, 353, 361, 362, 364, 364, 364, 365, 367, 368, 368, 369, 369, 369, 377, 378, 378, 378, 378, 378, 0, 0, 0, 379, 381, 385, 386, 386, 386, 386, 386, 0, 0, 0, 386, 386, 386, 0, 0, 0, 386, 386, 386, 0, 0, 0, 387, 389, 393, 393, 394, 396, 396, 397, 401, 402, 406, 407, 407, 408, 409, 415, 415, 415, 416, 417, 417, 418, 421, 421, 421, 422, 423, 423, 424, 426, 427, 427, 428, 430, 430, 430, 432, 432, 432, 433, 434, 434, 435, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 60, 61, 62, 63, 64, 65, 79, 84, 85, 86, 91, 92, 95, 99, 102, 103, 105, 106, 109, 114, 115, 120, 121, 124, 128, 131, 132, 138, 146, 147, 150, 155, 156, 161, 162, 165, 169, 172, 173, 179, 186, 191, 192, 194, 195, 200, 201, 203, 204, 211, 216, 217, 219, 220, 225, 226, 228, 229, 233, 234, 238, 239, 243, 244, 251, 256, 257, 258, 260, 261, 266, 277, 282, 283, 286, 287, 292, 293, 296, 300, 301, 303, 304, 305, 310, 326, 331, 332, 335, 336, 341, 342, 345, 349, 352, 353, 354, 359, 360, 363, 367, 368, 370, 371, 372, 373, 378, 381, 386, 391, 392, 394, 395, 396, 404, 409, 410, 412, 413, 414, 415, 416, 421, 426, 427, 429, 430, 435, 440, 441, 443, 444, 448, 453, 458, 459, 467, 471, 472, 474, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 534, 535, 540, 541, 544, 548, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 566, 571, 572, 573, 574, 575, 576, 577, 578, 579, 581, 603, 604, 605, 606, 607, 608, 609, 610, 615, 616, 617, 618, 619, 621, 626, 627, 628, 629, 630, 632, 637, 638, 639, 640, 641, 643, 649, 650, 653, 658, 659, 660, 666, 674, 675, 676, 677, 680, 685, 686, 687, 693, 702, 705, 710, 711, 712, 713, 715, 718, 722, 725, 731, 751, 752, 753, 754, 756, 757, 758, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 790, 793, 798, 799, 800, 801, 806, 807, 810, 811, 812, 817, 818, 821, 825, 826, 828, 834, 835, 845, 848, 853, 854, 855, 856, 861, 862, 863, 865, 871, 872, 901, 902, 903, 905, 906, 907, 908, 909, 910, 912, 913, 914, 916, 918, 919, 921, 924, 928, 931, 932, 933, 934, 936, 937, 940, 941, 942, 943, 945, 946, 947, 949, 950, 951, 952, 953, 984, 985, 986, 988, 989, 990, 991, 992, 993, 994, 996, 997, 998, 1001, 1002, 1003, 1004, 1005, 1007, 1008, 1009, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1021, 1022, 1023, 1066, 1067, 1068, 1069, 1070, 1072, 1073, 1074, 1077, 1078, 1079, 1080, 1082, 1083, 1084, 1087, 1088, 1089, 1090, 1091, 1096, 1097, 1098, 1099, 1101, 1106, 1107, 1108, 1109, 1110, 1113, 1114, 1115, 1116, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1153, 1154, 1158, 1159, 1160, 1162, 1165, 1166, 1171, 1172, 1173, 1174, 1188, 1191, 1196, 1197, 1198, 1199, 1201, 1204, 1208, 1211, 1217, 1234, 1237, 1242, 1243, 1244, 1245, 1247, 1250, 1254, 1257, 1258, 1259, 1261, 1264, 1268, 1271, 1272, 1273, 1275, 1278, 1282, 1285, 1291, 1296, 1301, 1302, 1304, 1305, 1306, 1310, 1311, 1318, 1319, 1322, 1324, 1325, 1347, 1348, 1353, 1354, 1355, 1360, 1361, 1364, 1365, 1370, 1371, 1372, 1377, 1378, 1380, 1381, 1386, 1387, 1389, 1390, 1391, 1393, 1394, 1399, 1400, 1401, 1406, 1407, 1413, 1416, 1420, 1423, 1427, 1430, 1434, 1437, 1441, 1444, 1448, 1451, 1455, 1458, 1462, 1465, 1469, 1472, 1476, 1479, 1483, 1486, 1490, 1493, 1497, 1500, 1504, 1507, 1511, 1514, 1518, 1521, 1525, 1528};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 46
new 0 23 46
assign 1 24 47
new 0 24 47
assign 1 25 48
new 0 25 48
assign 1 26 49
new 0 26 49
assign 1 28 50
assign 1 29 51
constantsGet 0 29 51
assign 1 30 52
ntypesGet 0 30 52
assign 1 31 53
TOKENGet 0 31 53
assign 1 32 54
new 0 32 54
assign 1 37 60
nlcGet 0 37 60
assign 1 37 61
copy 0 37 61
assign 1 38 62
nlecGet 0 38 62
assign 1 38 63
copy 0 38 63
assign 1 39 64
inClassNpGet 0 39 64
assign 1 40 65
inFileGet 0 40 65
assign 1 44 79
def 1 44 84
assign 1 44 85
firstGet 0 44 85
assign 1 44 86
def 1 44 91
assign 1 0 92
assign 1 0 95
assign 1 0 99
assign 1 45 102
firstGet 0 45 102
return 1 45 103
assign 1 47 105
nextPeerGet 0 47 105
assign 1 48 106
containerGet 0 48 106
assign 1 49 109
undef 1 49 114
assign 1 49 115
def 1 49 120
assign 1 0 121
assign 1 0 124
assign 1 0 128
assign 1 50 131
nextPeerGet 0 50 131
assign 1 51 132
containerGet 0 51 132
return 1 53 138
assign 1 57 146
nextPeerGet 0 57 146
assign 1 58 147
containerGet 0 58 147
assign 1 59 150
undef 1 59 155
assign 1 59 156
def 1 59 161
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 60 172
nextPeerGet 0 60 172
assign 1 61 173
containerGet 0 61 173
return 1 63 179
assign 1 67 186
undef 1 67 191
return 1 68 192
assign 1 70 194
nextGet 0 70 194
assign 1 71 195
undef 1 71 200
return 1 72 201
assign 1 74 203
heldGet 0 74 203
return 1 74 204
assign 1 78 211
undef 1 78 216
return 1 79 217
assign 1 81 219
priorGet 0 81 219
assign 1 82 220
undef 1 82 225
return 1 83 226
assign 1 85 228
heldGet 0 85 228
return 1 85 229
assign 1 89 233
firstGet 0 89 233
return 1 89 234
assign 1 93 238
secondGet 0 93 238
return 1 93 239
assign 1 97 243
thirdGet 0 97 243
return 1 97 244
assign 1 101 251
undef 1 101 256
assign 1 102 257
new 0 102 257
return 1 102 258
assign 1 104 260
priorGet 0 104 260
assign 1 104 261
undef 1 104 266
return 1 104 266
assign 1 108 277
undef 1 108 282
assign 1 0 283
assign 1 108 286
priorGet 0 108 286
assign 1 108 287
undef 1 108 292
assign 1 0 293
assign 1 0 296
assign 1 109 300
new 0 109 300
return 1 109 301
assign 1 111 303
priorGet 0 111 303
assign 1 111 304
priorGet 0 111 304
assign 1 111 305
undef 1 111 310
return 1 111 310
assign 1 115 326
undef 1 115 331
assign 1 0 332
assign 1 115 335
priorGet 0 115 335
assign 1 115 336
undef 1 115 341
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 115 352
priorGet 0 115 352
assign 1 115 353
priorGet 0 115 353
assign 1 115 354
undef 1 115 359
assign 1 0 360
assign 1 0 363
assign 1 116 367
new 0 116 367
return 1 116 368
assign 1 118 370
priorGet 0 118 370
assign 1 118 371
priorGet 0 118 371
assign 1 118 372
priorGet 0 118 372
assign 1 118 373
undef 1 118 378
return 1 118 378
assign 1 122 381
new 0 122 381
assign 1 126 386
undef 1 126 391
return 1 127 392
delete 0 129 394
containerSet 1 130 395
assign 1 131 396
assign 1 135 404
undef 1 135 409
return 1 136 410
assign 1 138 412
mylistGet 0 138 412
assign 1 138 413
newNode 1 138 413
insertBefore 1 138 414
assign 1 139 415
containerGet 0 139 415
containerSet 1 139 416
assign 1 143 421
undef 1 143 426
initContained 0 144 427
prepend 1 146 429
containerSet 1 147 430
assign 1 151 435
undef 1 151 440
initContained 0 152 441
addValue 1 154 443
containerSet 1 155 444
assign 1 159 448
new 0 159 448
assign 1 163 453
undef 1 163 458
assign 1 164 459
new 0 164 459
assign 1 171 467
toStringCompact 0 171 467
print 0 173 471
throw 1 174 472
return 1 176 474
assign 1 180 514
prefixGet 0 180 514
assign 1 181 515
new 0 181 515
assign 1 181 516
add 1 181 516
assign 1 181 517
toString 0 181 517
assign 1 181 518
add 1 181 518
assign 1 181 519
new 0 181 519
assign 1 181 520
add 1 181 520
assign 1 182 521
new 0 182 521
assign 1 182 522
newlineGet 0 182 522
assign 1 182 523
add 1 182 523
assign 1 182 524
add 1 182 524
assign 1 182 525
new 0 182 525
assign 1 182 526
add 1 182 526
assign 1 182 527
toString 0 182 527
assign 1 182 528
add 1 182 528
assign 1 183 529
def 1 183 534
assign 1 183 535
def 1 183 540
assign 1 0 541
assign 1 0 544
assign 1 0 548
assign 1 184 551
new 0 184 551
assign 1 184 552
newlineGet 0 184 552
assign 1 184 553
add 1 184 553
assign 1 184 554
add 1 184 554
assign 1 184 555
new 0 184 555
assign 1 184 556
add 1 184 556
assign 1 184 557
toString 0 184 557
assign 1 184 558
add 1 184 558
assign 1 184 559
new 0 184 559
assign 1 184 560
add 1 184 560
assign 1 184 561
add 1 184 561
assign 1 184 562
new 0 184 562
assign 1 184 563
newlineGet 0 184 563
assign 1 184 564
add 1 184 564
assign 1 186 566
def 1 186 571
assign 1 187 572
new 0 187 572
assign 1 187 573
newlineGet 0 187 573
assign 1 187 574
add 1 187 574
assign 1 187 575
add 1 187 575
assign 1 187 576
new 0 187 576
assign 1 187 577
add 1 187 577
assign 1 188 578
toString 0 188 578
assign 1 188 579
add 1 188 579
return 1 190 581
assign 1 194 603
prefixGet 0 194 603
assign 1 195 604
new 0 195 604
assign 1 195 605
add 1 195 605
assign 1 195 606
toString 0 195 606
assign 1 195 607
add 1 195 607
assign 1 195 608
new 0 195 608
assign 1 195 609
add 1 195 609
assign 1 196 610
def 1 196 615
assign 1 197 616
new 0 197 616
assign 1 197 617
add 1 197 617
assign 1 197 618
toString 0 197 618
assign 1 197 619
add 1 197 619
assign 1 199 621
def 1 199 626
assign 1 200 627
new 0 200 627
assign 1 200 628
add 1 200 628
assign 1 200 629
toString 0 200 629
assign 1 200 630
add 1 200 630
assign 1 202 632
def 1 202 637
assign 1 203 638
new 0 203 638
assign 1 203 639
add 1 203 639
assign 1 203 640
toString 0 203 640
assign 1 203 641
add 1 203 641
return 1 205 643
assign 1 209 649
new 0 209 649
assign 1 210 650
containerGet 0 210 650
assign 1 211 653
def 1 211 658
incrementValue 0 212 659
assign 1 213 660
containerGet 0 213 660
return 1 215 666
assign 1 219 674
depthGet 0 219 674
assign 1 220 675
new 0 220 675
assign 1 221 676
new 0 221 676
assign 1 222 677
new 0 222 677
assign 1 222 680
lesser 1 222 685
assign 1 223 686
add 1 223 686
incrementValue 0 222 687
return 1 225 693
assign 1 229 702
assign 1 230 705
def 1 230 710
assign 1 230 711
typenameGet 0 230 711
assign 1 230 712
TRANSUNITGet 0 230 712
assign 1 230 713
notEquals 1 230 713
assign 1 0 715
assign 1 0 718
assign 1 0 722
assign 1 231 725
containerGet 0 231 725
return 1 233 731
assign 1 237 751
scopeGet 0 237 751
assign 1 238 752
typenameGet 0 238 752
assign 1 238 753
METHODGet 0 238 753
assign 1 238 754
notEquals 1 238 754
assign 1 239 756
new 0 239 756
assign 1 239 757
new 2 239 757
throw 1 239 758
assign 1 241 760
heldGet 0 241 760
assign 1 241 761
tmpCntGet 0 241 761
assign 1 241 762
toString 0 241 762
assign 1 242 763
heldGet 0 242 763
assign 1 242 764
tmpCntGet 0 242 764
incrementValue 0 242 765
assign 1 243 766
new 0 243 766
assign 1 244 767
new 0 244 767
isTmpVarSet 1 244 768
assign 1 245 769
new 0 245 769
autoTypeSet 1 245 770
suffixSet 1 246 771
assign 1 247 772
new 0 247 772
assign 1 247 773
add 1 247 773
assign 1 247 774
add 1 247 774
nameSet 1 247 775
return 1 248 776
assign 1 252 790
containerGet 0 252 790
assign 1 253 793
def 1 253 798
assign 1 254 799
typenameGet 0 254 799
assign 1 254 800
SLOTSGet 0 254 800
assign 1 254 801
equals 1 254 806
assign 1 0 807
assign 1 254 810
typenameGet 0 254 810
assign 1 254 811
FIELDSGet 0 254 811
assign 1 254 812
equals 1 254 817
assign 1 0 818
assign 1 0 821
assign 1 255 825
new 0 255 825
return 1 255 826
assign 1 257 828
containerGet 0 257 828
assign 1 259 834
new 0 259 834
return 1 259 835
assign 1 263 845
containerGet 0 263 845
assign 1 264 848
def 1 264 853
assign 1 265 854
typenameGet 0 265 854
assign 1 265 855
SLOTSGet 0 265 855
assign 1 265 856
equals 1 265 861
assign 1 266 862
new 0 266 862
return 1 266 863
assign 1 268 865
containerGet 0 268 865
assign 1 270 871
new 0 270 871
return 1 270 872
assign 1 274 901
assign 1 275 902
isAddedGet 0 275 902
assign 1 275 903
not 0 275 903
assign 1 276 905
new 0 276 905
isAddedSet 1 276 906
assign 1 277 907
scopeGet 0 277 907
assign 1 278 908
typenameGet 0 278 908
assign 1 278 909
CLASSGet 0 278 909
assign 1 278 910
equals 1 278 910
assign 1 279 912
new 0 279 912
assign 1 279 913
new 2 279 913
throw 1 279 914
assign 1 281 916
inPropertiesGet 0 281 916
assign 1 281 918
isTmpVarGet 0 281 918
assign 1 281 919
not 0 281 919
assign 1 0 921
assign 1 0 924
assign 1 0 928
assign 1 282 931
classGet 0 282 931
assign 1 283 932
new 0 283 932
isPropertySet 1 283 933
assign 1 284 934
inSlotsGet 0 284 934
assign 1 285 936
new 0 285 936
isSlotSet 1 285 937
assign 1 288 940
heldGet 0 288 940
assign 1 289 941
anyMapGet 0 289 941
assign 1 289 942
nameGet 0 289 942
assign 1 289 943
has 1 289 943
assign 1 290 945
new 0 290 945
assign 1 290 946
new 2 290 946
throw 1 290 947
assign 1 292 949
anyMapGet 0 292 949
assign 1 292 950
nameGet 0 292 950
put 2 292 951
assign 1 293 952
orderedVarsGet 0 293 952
addValue 1 293 953
assign 1 298 984
assign 1 299 985
isAddedGet 0 299 985
assign 1 299 986
not 0 299 986
assign 1 300 988
new 0 300 988
isAddedSet 1 300 989
assign 1 301 990
scopeGet 0 301 990
assign 1 302 991
heldGet 0 302 991
assign 1 303 992
anyMapGet 0 303 992
assign 1 303 993
nameGet 0 303 993
assign 1 303 994
has 1 303 994
assign 1 304 996
anyMapGet 0 304 996
assign 1 304 997
nameGet 0 304 997
assign 1 304 998
get 1 304 998
assign 1 306 1001
classGet 0 306 1001
assign 1 306 1002
heldGet 0 306 1002
assign 1 307 1003
anyMapGet 0 307 1003
assign 1 307 1004
nameGet 0 307 1004
assign 1 307 1005
has 1 307 1005
assign 1 308 1007
anyMapGet 0 308 1007
assign 1 308 1008
nameGet 0 308 1008
assign 1 308 1009
get 1 308 1009
assign 1 310 1012
anyMapGet 0 310 1012
assign 1 310 1013
nameGet 0 310 1013
put 2 310 1014
assign 1 311 1015
orderedVarsGet 0 311 1015
addValue 1 311 1016
assign 1 312 1017
typenameGet 0 312 1017
assign 1 312 1018
CLASSGet 0 312 1018
assign 1 312 1019
equals 1 312 1019
assign 1 313 1021
new 0 313 1021
assign 1 313 1022
new 2 313 1022
throw 1 313 1023
assign 1 322 1066
assign 1 323 1067
scopeGet 0 323 1067
assign 1 323 1068
heldGet 0 323 1068
assign 1 324 1069
anyMapGet 0 324 1069
assign 1 324 1070
has 1 324 1070
assign 1 325 1072
anyMapGet 0 325 1072
assign 1 325 1073
get 1 325 1073
assign 1 325 1074
heldGet 0 325 1074
assign 1 327 1077
classGet 0 327 1077
assign 1 327 1078
heldGet 0 327 1078
assign 1 328 1079
anyMapGet 0 328 1079
assign 1 328 1080
has 1 328 1080
assign 1 329 1082
anyMapGet 0 329 1082
assign 1 329 1083
get 1 329 1083
assign 1 329 1084
heldGet 0 329 1084
assign 1 331 1087
transUnitGet 0 331 1087
assign 1 332 1088
heldGet 0 332 1088
assign 1 332 1089
aliasedGet 0 332 1089
assign 1 332 1090
get 1 332 1090
assign 1 333 1091
undef 1 333 1096
assign 1 334 1097
emitDataGet 0 334 1097
assign 1 334 1098
aliasedGet 0 334 1098
assign 1 334 1099
get 1 334 1099
assign 1 336 1101
def 1 336 1106
assign 1 337 1107
new 0 337 1107
assign 1 337 1108
add 1 337 1108
assign 1 337 1109
new 2 337 1109
throw 1 337 1110
assign 1 340 1113
new 0 340 1113
nameSet 1 341 1114
assign 1 342 1115
new 0 342 1115
assign 1 342 1116
equals 1 342 1116
assign 1 343 1118
assign 1 344 1119
new 0 344 1119
isTypedSet 1 344 1120
assign 1 345 1121
extendsGet 0 345 1121
namepathSet 1 345 1122
assign 1 346 1123
anyMapGet 0 346 1123
put 2 346 1124
assign 1 347 1125
orderedVarsGet 0 347 1125
addValue 1 347 1126
assign 1 349 1129
new 0 349 1129
isDeclaredSet 1 349 1130
assign 1 350 1131
new 0 350 1131
isPropertySet 1 350 1132
assign 1 351 1133
assign 1 352 1134
anyMapGet 0 352 1134
put 2 352 1135
assign 1 353 1136
orderedVarsGet 0 353 1136
addValue 1 353 1137
assign 1 361 1153
assign 1 362 1154
new 0 362 1154
assign 1 364 1158
anchorTypesGet 0 364 1158
assign 1 364 1159
typenameGet 0 364 1159
assign 1 364 1160
has 1 364 1160
return 1 365 1162
assign 1 367 1165
containerGet 0 367 1165
assign 1 368 1166
undef 1 368 1171
assign 1 369 1172
new 0 369 1172
assign 1 369 1173
new 2 369 1173
throw 1 369 1174
assign 1 377 1188
assign 1 378 1191
def 1 378 1196
assign 1 378 1197
typenameGet 0 378 1197
assign 1 378 1198
CLASSGet 0 378 1198
assign 1 378 1199
notEquals 1 378 1199
assign 1 0 1201
assign 1 0 1204
assign 1 0 1208
assign 1 379 1211
containerGet 0 379 1211
return 1 381 1217
assign 1 385 1234
assign 1 386 1237
def 1 386 1242
assign 1 386 1243
typenameGet 0 386 1243
assign 1 386 1244
CLASSGet 0 386 1244
assign 1 386 1245
notEquals 1 386 1245
assign 1 0 1247
assign 1 0 1250
assign 1 0 1254
assign 1 386 1257
typenameGet 0 386 1257
assign 1 386 1258
METHODGet 0 386 1258
assign 1 386 1259
notEquals 1 386 1259
assign 1 0 1261
assign 1 0 1264
assign 1 0 1268
assign 1 386 1271
typenameGet 0 386 1271
assign 1 386 1272
TRANSUNITGet 0 386 1272
assign 1 386 1273
notEquals 1 386 1273
assign 1 0 1275
assign 1 0 1278
assign 1 0 1282
assign 1 387 1285
containerGet 0 387 1285
return 1 389 1291
assign 1 393 1296
undef 1 393 1301
return 1 394 1302
assign 1 396 1304
containerGet 0 396 1304
containerSet 1 396 1305
heldSet 1 397 1306
delete 0 401 1310
addValue 1 402 1311
assign 1 406 1318
containedGet 0 406 1318
assign 1 407 1319
iteratorGet 0 407 1319
assign 1 407 1322
hasNextGet 0 407 1322
assign 1 408 1324
nextGet 0 408 1324
containerSet 1 409 1325
assign 1 415 1347
NAMEPATHGet 0 415 1347
assign 1 415 1348
equals 1 415 1353
assign 1 416 1354
assign 1 417 1355
def 1 417 1360
resolve 1 418 1361
assign 1 421 1364
CLASSGet 0 421 1364
assign 1 421 1365
equals 1 421 1370
assign 1 422 1371
namepathGet 0 422 1371
assign 1 423 1372
def 1 423 1377
resolve 1 424 1378
assign 1 426 1380
extendsGet 0 426 1380
assign 1 427 1381
def 1 427 1386
resolve 1 428 1387
assign 1 430 1389
namepathGet 0 430 1389
assign 1 430 1390
toString 0 430 1390
nameSet 1 430 1391
assign 1 432 1393
VARGet 0 432 1393
assign 1 432 1394
equals 1 432 1399
assign 1 433 1400
namepathGet 0 433 1400
assign 1 434 1401
def 1 434 1406
resolve 1 435 1407
return 1 0 1413
assign 1 0 1416
return 1 0 1420
assign 1 0 1423
return 1 0 1427
assign 1 0 1430
return 1 0 1434
assign 1 0 1437
return 1 0 1441
assign 1 0 1444
return 1 0 1448
assign 1 0 1451
return 1 0 1455
assign 1 0 1458
return 1 0 1462
assign 1 0 1465
return 1 0 1469
assign 1 0 1472
return 1 0 1476
assign 1 0 1479
return 1 0 1483
assign 1 0 1486
return 1 0 1490
assign 1 0 1493
return 1 0 1497
assign 1 0 1500
return 1 0 1504
assign 1 0 1507
return 1 0 1511
assign 1 0 1514
return 1 0 1518
assign 1 0 1521
return 1 0 1525
assign 1 0 1528
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1821063561: return bem_secondGet_0();
case -1466396646: return bem_toStringCompact_0();
case 2093609367: return bem_create_0();
case -461101261: return bem_syncAddVariable_0();
case -713135930: return bem_buildGet_0();
case -704125986: return bem_containedGet_0();
case 1631932912: return bem_containerGet_0();
case -2107472156: return bem_resolveNp_0();
case -1696436091: return bem_typenameGet_0();
case -177519175: return bem_scopeGet_0();
case 1167266718: return bem_nextPeerGet_0();
case 1703142777: return bem_ntypesGet_0();
case -559745977: return bem_inFileGet_0();
case 73280073: return bem_isSecondGet_0();
case -563455204: return bem_nlcGet_0();
case -527193773: return bem_isThirdGet_0();
case -1197979036: return bem_new_0();
case 418720082: return bem_classGet_0();
case 2027742703: return bem_nextDescendGet_0();
case -1167294521: return bem_condanyGet_0();
case -824513046: return bem_inSlotsGet_0();
case -602793295: return bem_nextAscendGet_0();
case 1909120093: return bem_toString_0();
case 888252305: return bem_nlecGet_0();
case 1652259488: return bem_typeDetailGet_0();
case -1238499046: return bem_hashGet_0();
case 2113116069: return bem_firstGet_0();
case 1685185310: return bem_transUnitGet_0();
case 534278045: return bem_priorPeerGet_0();
case -1924693366: return bem_copy_0();
case 1026250277: return bem_reInitContained_0();
case -499312877: return bem_delayDeleteGet_0();
case -178877152: return bem_heldByGet_0();
case 245203492: return bem_iteratorGet_0();
case -1984707404: return bem_constantsGet_0();
case 1903198317: return bem_delete_0();
case 558194024: return bem_inlinedGet_0();
case 1628920670: return bem_isFirstGet_0();
case 1307051427: return bem_wideStringGet_0();
case 2051599043: return bem_inPropertiesGet_0();
case 1070520147: return bem_toStringBig_0();
case 194152856: return bem_heldGet_0();
case -1287935555: return bem_thirdGet_0();
case 1701572521: return bem_addVariable_0();
case -541197399: return bem_initContained_0();
case -1456087276: return bem_depthGet_0();
case 1379963317: return bem_delayDelete_0();
case 311035308: return bem_anchorGet_0();
case 1242333619: return bem_prefixGet_0();
case 592950024: return bem_print_0();
case 1081739198: return bem_inClassNpGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1348482962: return bem_condanySet_1(bevd_0);
case -2037896391: return bem_inlinedSet_1(bevd_0);
case -1179923885: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case -893297997: return bem_typeDetailSet_1(bevd_0);
case 1300487374: return bem_heldBySet_1(bevd_0);
case -2118434388: return bem_undef_1(bevd_0);
case 1379496708: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case 2011698927: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case -1282190600: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case -1666566022: return bem_inFileSet_1(bevd_0);
case -189217733: return bem_delayDeleteSet_1(bevd_0);
case 1862796806: return bem_ntypesSet_1(bevd_0);
case -347954742: return bem_constantsSet_1(bevd_0);
case 1670945202: return bem_typenameSet_1(bevd_0);
case 901608681: return bem_containerSet_1(bevd_0);
case -182209343: return bem_heldSet_1(bevd_0);
case -1064682771: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case 439701217: return bem_nlcSet_1(bevd_0);
case 441346402: return bem_equals_1(bevd_0);
case -922408689: return bem_buildSet_1(bevd_0);
case 396826105: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case 1513933004: return bem_def_1(bevd_0);
case 2134559650: return bem_containedSet_1(bevd_0);
case -1308882044: return bem_notEquals_1(bevd_0);
case 2099400707: return bem_inClassNpSet_1(bevd_0);
case -430544344: return bem_nlecSet_1(bevd_0);
case 1886177185: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 897670506: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1606617628: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case 2111055900: return bem_copyTo_1(bevd_0);
case -142319625: return bem_wideStringSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1886463238: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1921786219: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1099747159: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -974323752: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1849592004: return bem_tmpVar_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_4_BuildNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst = (BEC_2_5_4_BuildNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_type;
}
}
