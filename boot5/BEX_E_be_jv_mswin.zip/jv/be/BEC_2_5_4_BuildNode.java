package be;
/* IO:File: source/build/Nodes.be */
public final class BEC_2_5_4_BuildNode extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
private static byte[] becc_BEC_2_5_4_BuildNode_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_2_5_4_BuildNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_0 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_1 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_5 = {0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_6 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_7 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_8, 7));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_9, 8));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_10 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_10, 1));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_11 = {0x20,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_11, 2));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_13 = {0x5F,0x74,0x6D,0x70,0x61,0x6E,0x79,0x5F};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_17, 18));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_5;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_6;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_7;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_8;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_9;
private static BEC_2_4_3_MathInt bece_BEC_2_5_4_BuildNode_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_inst;
public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_6_6_SystemObject bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_2_4_3_MathInt(0));
bevp_nlec = (new BEC_2_4_3_MathInt(0));
bevp_wideString = be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = bevt_0_tmpany_phold.bem_copy_0();
bevt_1_tmpany_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = bevt_1_tmpany_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (bevp_contained == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_4_tmpany_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 44 */
 else  /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 44 */ {
bevt_5_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_tmpany_phold;
} /* Line: 45 */
bevl_ret = bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 49 */ {
if (bevl_ret == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 49 */ {
if (bevl_con == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
 else  /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 49 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 51 */
 else  /* Line: 49 */ {
break;
} /* Line: 49 */
} /* Line: 49 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevl_ret = bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 59 */ {
if (bevl_ret == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 59 */ {
if (bevl_con == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 59 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 59 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 61 */
 else  /* Line: 59 */ {
break;
} /* Line: 59 */
} /* Line: 59 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 67 */ {
return null;
} /* Line: 68 */
bevl_hh = bevp_heldBy.bemd_0(-1274688402);
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 71 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 72 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(1943587046);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 78 */ {
return null;
} /* Line: 79 */
bevl_hh = bevp_heldBy.bemd_0(-624891040);
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 82 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 83 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(1943587046);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 101 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 102 */
bevt_3_tmpany_phold = bevp_heldBy.bemd_0(-624891040);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_3_tmpany_phold = bevp_heldBy.bemd_0(-624891040);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 109 */
bevt_7_tmpany_phold = bevp_heldBy.bemd_0(-624891040);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-624891040);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 115 */ {
bevt_4_tmpany_phold = bevp_heldBy.bemd_0(-624891040);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 115 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 115 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 115 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 115 */ {
bevt_7_tmpany_phold = bevp_heldBy.bemd_0(-624891040);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-624891040);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 115 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 115 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 115 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 116 */
bevt_12_tmpany_phold = bevp_heldBy.bemd_0(-624891040);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-624891040);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-624891040);
if (bevt_10_tmpany_phold == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 126 */ {
return null;
} /* Line: 127 */
bevp_heldBy.bemd_0(1825207979);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 135 */ {
return null;
} /* Line: 136 */
bevt_2_tmpany_phold = bevp_heldBy.bemd_0(1707242555);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(-1662542051, beva_x);
bevp_heldBy.bemd_1(-1734381542, bevt_1_tmpany_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 143 */ {
bem_initContained_0();
} /* Line: 144 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 151 */ {
bem_initContained_0();
} /* Line: 152 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 164 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try  /* Line: 170 */ {
bevl_res = bem_toStringCompact_0();
} /* Line: 171 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(741511465);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 174 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
bevl_prefix = bem_prefixGet_0();
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_2_tmpany_phold = bevl_prefix.bemd_1(-1681017212, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_typename.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(-1681017212, bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = bevt_1_tmpany_phold.bemd_1(-1681017212, bevt_5_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_newlineGet_0();
bevt_8_tmpany_phold = bevl_ret.bemd_1(-1681017212, bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(-1681017212, bevl_prefix);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_2));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(-1681017212, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bemd_1(-1681017212, bevt_12_tmpany_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 183 */ {
if (bevp_inFile == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 183 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 183 */
 else  /* Line: 183 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 183 */ {
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_newlineGet_0();
bevt_20_tmpany_phold = bevl_ret.bemd_1(-1681017212, bevt_21_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(-1681017212, bevl_prefix);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_3));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-1681017212, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(-1681017212, bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_4));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_1(-1681017212, bevt_25_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-1681017212, bevp_inFile);
bevt_27_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpany_phold.bemd_1(-1681017212, bevt_26_tmpany_phold);
} /* Line: 184 */
if (bevp_held == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_32_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_newlineGet_0();
bevt_30_tmpany_phold = bevl_ret.bemd_1(-1681017212, bevt_31_tmpany_phold);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_1(-1681017212, bevl_prefix);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevl_ret = bevt_29_tmpany_phold.bemd_1(-1681017212, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_held.bemd_0(-1194864649);
bevl_ret = bevl_ret.bemd_1(-1681017212, bevt_34_tmpany_phold);
} /* Line: 188 */
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
bevl_prefix = bem_prefixGet_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_6));
bevt_1_tmpany_phold = bevl_prefix.bemd_1(-1681017212, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_typename.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-1681017212, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_7));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(-1681017212, bevt_4_tmpany_phold);
if (bevp_nlc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_0;
bevt_6_tmpany_phold = bevl_ret.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 197 */
if (bevp_inClassNp == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_1;
bevt_10_tmpany_phold = bevl_ret.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
} /* Line: 200 */
if (bevp_held == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_2;
bevt_14_tmpany_phold = bevl_ret.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_held.bemd_0(-1194864649);
bevl_ret = bevt_14_tmpany_phold.bem_add_1(bevt_16_tmpany_phold);
} /* Line: 203 */
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = (new BEC_2_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 211 */ {
if (bevl_c == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 213 */
 else  /* Line: 211 */ {
break;
} /* Line: 211 */
} /* Line: 211 */
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = bem_depthGet_0();
bevl_p = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = bece_BEC_2_5_4_BuildNode_bevo_3;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 222 */ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 222 */
 else  /* Line: 222 */ {
break;
} /* Line: 222 */
} /* Line: 222 */
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 230 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(1401861296);
bevt_4_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1067421305, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 230 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 230 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 230 */
 else  /* Line: 230 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 230 */ {
bevl_targ = bevl_targ.bemd_0(49643355);
} /* Line: 231 */
 else  /* Line: 230 */ {
break;
} /* Line: 230 */
} /* Line: 230 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_clnode = bem_scopeGet_0();
bevt_1_tmpany_phold = bevl_clnode.bemd_0(1401861296);
bevt_2_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1067421305, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 238 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildNode_bels_12));
bevt_3_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 239 */
bevt_6_tmpany_phold = bevl_clnode.bemd_0(1943587046);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(395981296);
bevl_tmpanyn = bevt_5_tmpany_phold.bemd_0(-1194864649);
bevt_8_tmpany_phold = bevl_clnode.bemd_0(1943587046);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(395981296);
bevt_7_tmpany_phold.bemd_0(-1757811166);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(534549236, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(312207564, bevt_10_tmpany_phold);
bevl_tmpany.bemd_1(1460581858, beva_suffix);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_13));
bevt_12_tmpany_phold = bevl_tmpanyn.bemd_1(-1681017212, bevt_13_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(-1681017212, beva_suffix);
bevl_tmpany.bemd_1(-1661973764, bevt_11_tmpany_phold);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 253 */ {
if (bevl_con == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevt_2_tmpany_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 255 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 257 */
 else  /* Line: 253 */ {
break;
} /* Line: 253 */
} /* Line: 253 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevl_v = bevp_held;
bevt_2_tmpany_phold = bevl_v.bemd_0(1079333811);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 264 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1371074253, bevt_3_tmpany_phold);
bevl_sco = bem_scopeGet_0();
bevt_5_tmpany_phold = bevl_sco.bemd_0(1401861296);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(661372330, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 267 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_4_BuildNode_bels_14));
bevt_7_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 268 */
bevt_9_tmpany_phold = bem_inPropertiesGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_11_tmpany_phold = bevl_v.bemd_0(874385663);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 270 */ {
bevl_sco = bem_classGet_0();
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1321552040, bevt_12_tmpany_phold);
} /* Line: 272 */
bevl_sc = bevl_sco.bemd_0(1943587046);
bevt_14_tmpany_phold = bevl_sc.bemd_0(-346958285);
bevt_15_tmpany_phold = bevl_v.bemd_0(1536349614);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_1(486402499, bevt_15_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 275 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_4_BuildNode_bels_15));
bevt_16_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 276 */
bevt_18_tmpany_phold = bevl_sc.bemd_0(-346958285);
bevt_19_tmpany_phold = bevl_v.bemd_0(1536349614);
bevt_18_tmpany_phold.bemd_2(-343510156, bevt_19_tmpany_phold, this);
bevt_20_tmpany_phold = bevl_sc.bemd_0(-882235173);
bevt_20_tmpany_phold.bemd_1(-1584461232, this);
} /* Line: 279 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevl_v = bevp_held;
bevt_1_tmpany_phold = bevl_v.bemd_0(1079333811);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1371074253, bevt_2_tmpany_phold);
bevl_sco = bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(1943587046);
bevt_4_tmpany_phold = bevl_sc.bemd_0(-346958285);
bevt_5_tmpany_phold = bevl_v.bemd_0(1536349614);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(486402499, bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 289 */ {
bevt_6_tmpany_phold = bevl_sc.bemd_0(-346958285);
bevt_7_tmpany_phold = bevl_v.bemd_0(1536349614);
bevp_held = bevt_6_tmpany_phold.bemd_1(-90541311, bevt_7_tmpany_phold);
} /* Line: 290 */
 else  /* Line: 291 */ {
bevt_8_tmpany_phold = bem_classGet_0();
bevl_cl = bevt_8_tmpany_phold.bemd_0(1943587046);
bevt_10_tmpany_phold = bevl_cl.bemd_0(-346958285);
bevt_11_tmpany_phold = bevl_v.bemd_0(1536349614);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(486402499, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 293 */ {
bevt_12_tmpany_phold = bevl_cl.bemd_0(-346958285);
bevt_13_tmpany_phold = bevl_v.bemd_0(1536349614);
bevp_held = bevt_12_tmpany_phold.bemd_1(-90541311, bevt_13_tmpany_phold);
} /* Line: 294 */
 else  /* Line: 295 */ {
bevt_14_tmpany_phold = bevl_sc.bemd_0(-346958285);
bevt_15_tmpany_phold = bevl_v.bemd_0(1536349614);
bevt_14_tmpany_phold.bemd_2(-343510156, bevt_15_tmpany_phold, this);
bevt_16_tmpany_phold = bevl_sc.bemd_0(-882235173);
bevt_16_tmpany_phold.bemd_1(-1584461232, this);
bevt_18_tmpany_phold = bevl_sco.bemd_0(1401861296);
bevt_19_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(661372330, bevt_19_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 298 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_4_BuildNode_bels_16));
bevt_20_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 299 */
} /* Line: 298 */
} /* Line: 293 */
} /* Line: 289 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_13_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpany_phold = bem_scopeGet_0();
bevl_sc = bevt_0_tmpany_phold.bemd_0(1943587046);
bevt_2_tmpany_phold = bevl_sc.bemd_0(-346958285);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(486402499, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 310 */ {
bevt_4_tmpany_phold = bevl_sc.bemd_0(-346958285);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-90541311, bevl_vname);
bevp_held = bevt_3_tmpany_phold.bemd_0(1943587046);
} /* Line: 311 */
 else  /* Line: 312 */ {
bevt_5_tmpany_phold = bem_classGet_0();
bevl_cl = bevt_5_tmpany_phold.bemd_0(1943587046);
bevt_7_tmpany_phold = bevl_cl.bemd_0(-346958285);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(486402499, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 314 */ {
bevt_9_tmpany_phold = bevl_cl.bemd_0(-346958285);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_1(-90541311, bevl_vname);
bevp_held = bevt_8_tmpany_phold.bemd_0(1943587046);
} /* Line: 315 */
 else  /* Line: 316 */ {
bevl_tunode = bem_transUnitGet_0();
bevt_11_tmpany_phold = bevl_tunode.bemd_0(1943587046);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(379402393);
bevl_np = bevt_10_tmpany_phold.bemd_1(-90541311, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevt_14_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_aliasedGet_0();
bevl_np = bevt_13_tmpany_phold.bem_get_1(bevl_vname);
} /* Line: 320 */
if (bevl_np == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_18_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_4;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevl_np);
bevt_16_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 323 */
 else  /* Line: 324 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(-1661973764, bevl_vname);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_18));
bevt_19_tmpany_phold = bevl_vname.bemd_1(661372330, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_19_tmpany_phold).bevi_bool) /* Line: 328 */ {
bevp_held = bevl_v;
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(92674232, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevl_cl.bemd_0(1379450560);
bevl_v.bemd_1(-1772426484, bevt_22_tmpany_phold);
bevt_23_tmpany_phold = bevl_sc.bemd_0(-346958285);
bevt_23_tmpany_phold.bemd_2(-343510156, bevl_vname, this);
bevt_24_tmpany_phold = bevl_sc.bemd_0(-882235173);
bevt_24_tmpany_phold.bemd_1(-1584461232, this);
} /* Line: 333 */
 else  /* Line: 334 */ {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(525256476, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1321552040, bevt_26_tmpany_phold);
bevp_held = bevl_v;
bevt_27_tmpany_phold = bevl_cl.bemd_0(-346958285);
bevt_27_tmpany_phold.bemd_2(-343510156, bevl_vname, this);
bevt_28_tmpany_phold = bevl_cl.bemd_0(-882235173);
bevt_28_tmpany_phold.bemd_1(-1584461232, this);
} /* Line: 339 */
} /* Line: 328 */
} /* Line: 322 */
} /* Line: 314 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_node = this;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 348 */ {
while (true)
 /* Line: 349 */ {
bevt_2_tmpany_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpany_phold = bevl_node.bemd_0(1401861296);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_has_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 350 */ {
return bevl_node;
} /* Line: 351 */
 else  /* Line: 352 */ {
bevl_node = bevl_node.bemd_0(49643355);
if (bevl_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 354 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_19));
bevt_5_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 355 */
} /* Line: 354 */
} /* Line: 350 */
} /* Line: 349 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 364 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 364 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(1401861296);
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1067421305, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 364 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 364 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 364 */
 else  /* Line: 364 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 364 */ {
bevl_targ = bevl_targ.bemd_0(49643355);
} /* Line: 365 */
 else  /* Line: 364 */ {
break;
} /* Line: 364 */
} /* Line: 364 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 372 */ {
if (bevl_targ == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_5_tmpany_phold = bevl_targ.bemd_0(1401861296);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1067421305, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 372 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevt_8_tmpany_phold = bevl_targ.bemd_0(1401861296);
bevt_9_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(1067421305, bevt_9_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 372 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevt_11_tmpany_phold = bevl_targ.bemd_0(1401861296);
bevt_12_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(1067421305, bevt_12_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevl_targ = bevl_targ.bemd_0(49643355);
} /* Line: 373 */
 else  /* Line: 372 */ {
break;
} /* Line: 372 */
} /* Line: 372 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 379 */ {
return null;
} /* Line: 380 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(1867212667, beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 393 */ {
bevt_0_tmpany_phold = bevl_it.bemd_0(1044268871);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_i = bevl_it.bemd_0(-1274688402);
bevl_i.bemd_1(-377671183, this);
} /* Line: 395 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 403 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 404 */
} /* Line: 403 */
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 407 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(153614681);
if (bevl_np == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 410 */
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(1379450560);
if (bevl_np == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 413 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 414 */
bevt_8_tmpany_phold = bevp_held.bemd_0(153614681);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-1194864649);
bevp_held.bemd_1(-1661973764, bevt_7_tmpany_phold);
} /* Line: 416 */
bevt_10_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 418 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(153614681);
if (bevl_np == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 420 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 421 */
} /* Line: 420 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_callIsSafe_1(BEC_2_5_4_BuildNode beva_call) throws Throwable {
BEC_2_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses = null;
BEC_2_9_3_ContainerSet bevl_okCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses2 = null;
BEC_2_9_3_ContainerSet bevl_okCalls2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
bevt_2_tmpany_phold = beva_call.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1735635672);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 431 */ {
bevt_6_tmpany_phold = beva_call.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(597072809);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-1194864649);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_20));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(661372330, bevt_7_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 431 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 431 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 431 */
 else  /* Line: 431 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 431 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 432 */
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_5 == null) {
bece_BEC_2_5_4_BuildNode_bevo_5 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bece_BEC_2_5_4_BuildNode_bevo_5;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_6 == null) {
bece_BEC_2_5_4_BuildNode_bevo_6 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bece_BEC_2_5_4_BuildNode_bevo_6;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_7 == null) {
bece_BEC_2_5_4_BuildNode_bevo_7 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bece_BEC_2_5_4_BuildNode_bevo_7;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_8 == null) {
bece_BEC_2_5_4_BuildNode_bevo_8 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bece_BEC_2_5_4_BuildNode_bevo_8;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_9 == null) {
bece_BEC_2_5_4_BuildNode_bevo_9 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bece_BEC_2_5_4_BuildNode_bevo_9;
bevt_10_tmpany_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_10;
if (bevt_10_tmpany_phold.bevi_int == bevt_11_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 440 */ {
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_4_BuildNode_bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpany_phold);
} /* Line: 490 */
bevt_48_tmpany_phold = beva_call.bem_heldGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(1536349614);
bevt_46_tmpany_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpany_phold);
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 494 */ {
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_49_tmpany_phold;
} /* Line: 496 */
bevt_54_tmpany_phold = beva_call.bem_containedGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_firstGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(1943587046);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(-821404824);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 500 */ {
bevt_55_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_55_tmpany_phold;
} /* Line: 502 */
bevt_61_tmpany_phold = beva_call.bem_containedGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(1943587046);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(153614681);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(-1194864649);
bevt_56_tmpany_phold = bevl_okClasses.bem_has_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 510 */ {
bevt_64_tmpany_phold = beva_call.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(1536349614);
bevt_62_tmpany_phold = bevl_okCalls.bem_has_1(bevt_63_tmpany_phold);
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_65_tmpany_phold;
} /* Line: 513 */
 else  /* Line: 514 */ {
} /* Line: 514 */
} /* Line: 511 */
bevt_71_tmpany_phold = beva_call.bem_containedGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_firstGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_0(1943587046);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(153614681);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(-1194864649);
bevt_66_tmpany_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_74_tmpany_phold = beva_call.bem_heldGet_0();
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(1536349614);
bevt_72_tmpany_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpany_phold);
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 519 */ {
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_75_tmpany_phold;
} /* Line: 521 */
 else  /* Line: 522 */ {
} /* Line: 522 */
} /* Line: 519 */
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_76_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralOnceGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_BuildNode bevl_c0 = null;
BEC_2_5_4_BuildNode bevl_c1 = null;
BEC_2_5_4_BuildNode bevl_call = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevt_4_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevp_typename.bevi_int != bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 543 */
bevt_7_tmpany_phold = bevp_held.bemd_0(1383140727);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_55));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(661372330, bevt_8_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 544 */ {
bevl_c0 = (BEC_2_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_2_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 547 */ {
bevt_11_tmpany_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_11_tmpany_phold.bevi_int == bevt_12_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 547 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 547 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 547 */
 else  /* Line: 547 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 547 */ {
bevt_14_tmpany_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1099712379);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 548 */ {
bevt_17_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(-1583121965);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 548 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 548 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 548 */
 else  /* Line: 548 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 548 */ {
bevl_result = be.BECS_Runtime.boolTrue;
bevt_19_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(432559951);
bevt_0_tmpany_loop = bevt_18_tmpany_phold.bemd_0(-612311095);
while (true)
 /* Line: 550 */ {
bevt_20_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1044268871);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 550 */ {
bevl_call = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(-1274688402);
bevt_21_tmpany_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 551 */ {
bevt_23_tmpany_phold = bem_callIsSafe_1(bevl_call);
if (bevt_23_tmpany_phold.bevi_bool) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 552 */ {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_24_tmpany_phold;
} /* Line: 553 */
} /* Line: 552 */
} /* Line: 551 */
 else  /* Line: 550 */ {
break;
} /* Line: 550 */
} /* Line: 550 */
} /* Line: 550 */
} /* Line: 548 */
} /* Line: 547 */
return bevl_result;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heldBy = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() throws Throwable {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_condany = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeDetail = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 37, 37, 38, 38, 39, 40, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 47, 48, 49, 49, 49, 49, 0, 0, 0, 50, 51, 53, 57, 58, 59, 59, 59, 59, 0, 0, 0, 60, 61, 63, 67, 67, 68, 70, 71, 71, 72, 74, 74, 78, 78, 79, 81, 82, 82, 83, 85, 85, 89, 89, 93, 93, 97, 97, 101, 101, 102, 102, 104, 104, 104, 108, 108, 0, 108, 108, 108, 0, 0, 109, 109, 111, 111, 111, 111, 115, 115, 0, 115, 115, 115, 0, 0, 0, 115, 115, 115, 115, 0, 0, 116, 116, 118, 118, 118, 118, 118, 122, 126, 126, 127, 129, 130, 131, 135, 135, 136, 138, 138, 138, 139, 143, 143, 144, 146, 147, 151, 151, 152, 154, 155, 159, 163, 163, 164, 171, 173, 174, 176, 180, 181, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 0, 0, 0, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 187, 187, 188, 188, 190, 194, 195, 195, 195, 195, 195, 195, 196, 196, 197, 197, 197, 197, 199, 199, 200, 200, 200, 200, 202, 202, 203, 203, 203, 203, 205, 209, 210, 211, 211, 212, 213, 215, 219, 220, 221, 222, 222, 222, 223, 222, 225, 229, 230, 230, 230, 230, 230, 0, 0, 0, 231, 233, 237, 238, 238, 238, 239, 239, 239, 241, 241, 241, 242, 242, 242, 243, 244, 244, 245, 245, 246, 247, 247, 247, 247, 248, 252, 253, 253, 254, 254, 254, 254, 255, 255, 257, 259, 259, 263, 264, 264, 265, 265, 266, 267, 267, 267, 268, 268, 268, 270, 270, 270, 0, 0, 0, 271, 272, 272, 274, 275, 275, 275, 276, 276, 276, 278, 278, 278, 279, 279, 284, 285, 285, 286, 286, 287, 288, 289, 289, 289, 290, 290, 290, 292, 292, 293, 293, 293, 294, 294, 294, 296, 296, 296, 297, 297, 298, 298, 298, 299, 299, 299, 308, 309, 309, 310, 310, 311, 311, 311, 313, 313, 314, 314, 315, 315, 315, 317, 318, 318, 318, 319, 319, 320, 320, 320, 322, 322, 323, 323, 323, 323, 326, 327, 328, 328, 329, 330, 330, 331, 331, 332, 332, 333, 333, 335, 335, 336, 336, 337, 338, 338, 339, 339, 347, 348, 350, 350, 350, 351, 353, 354, 354, 355, 355, 355, 363, 364, 364, 364, 364, 364, 0, 0, 0, 365, 367, 371, 372, 372, 372, 372, 372, 0, 0, 0, 372, 372, 372, 0, 0, 0, 372, 372, 372, 0, 0, 0, 373, 375, 379, 379, 380, 382, 383, 387, 388, 392, 393, 393, 394, 395, 401, 401, 401, 402, 403, 403, 404, 407, 407, 407, 408, 409, 409, 410, 412, 413, 413, 414, 416, 416, 416, 418, 418, 418, 419, 420, 420, 421, 431, 431, 431, 431, 431, 431, 431, 0, 0, 0, 432, 432, 435, 436, 437, 438, 439, 440, 440, 440, 440, 447, 447, 450, 450, 451, 451, 453, 453, 454, 454, 455, 455, 456, 456, 457, 457, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 473, 473, 474, 474, 475, 475, 476, 476, 477, 477, 481, 481, 482, 482, 483, 483, 484, 484, 489, 489, 490, 490, 494, 494, 494, 496, 496, 500, 500, 500, 500, 500, 502, 502, 510, 510, 510, 510, 510, 510, 511, 511, 511, 513, 513, 518, 518, 518, 518, 518, 518, 519, 519, 519, 521, 521, 527, 527, 538, 543, 543, 543, 543, 543, 544, 544, 544, 545, 546, 547, 547, 547, 547, 547, 547, 0, 0, 0, 548, 548, 548, 548, 548, 0, 0, 0, 549, 550, 550, 550, 0, 550, 550, 551, 552, 552, 552, 553, 553, 564, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {93, 94, 95, 96, 97, 98, 99, 100, 101, 107, 108, 109, 110, 111, 112, 126, 131, 132, 133, 138, 139, 142, 146, 149, 150, 152, 153, 156, 161, 162, 167, 168, 171, 175, 178, 179, 185, 193, 194, 197, 202, 203, 208, 209, 212, 216, 219, 220, 226, 233, 238, 239, 241, 242, 247, 248, 250, 251, 258, 263, 264, 266, 267, 272, 273, 275, 276, 280, 281, 285, 286, 290, 291, 298, 303, 304, 305, 307, 308, 313, 324, 329, 330, 333, 334, 339, 340, 343, 347, 348, 350, 351, 352, 357, 373, 378, 379, 382, 383, 388, 389, 392, 396, 399, 400, 401, 406, 407, 410, 414, 415, 417, 418, 419, 420, 425, 428, 433, 438, 439, 441, 442, 443, 450, 455, 456, 458, 459, 460, 461, 466, 471, 472, 474, 475, 480, 485, 486, 488, 489, 493, 498, 503, 504, 512, 516, 517, 519, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 579, 580, 585, 586, 589, 593, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 611, 616, 617, 618, 619, 620, 621, 622, 623, 624, 626, 648, 649, 650, 651, 652, 653, 654, 655, 660, 661, 662, 663, 664, 666, 671, 672, 673, 674, 675, 677, 682, 683, 684, 685, 686, 688, 694, 695, 698, 703, 704, 705, 711, 719, 720, 721, 722, 725, 730, 731, 732, 738, 747, 750, 755, 756, 757, 758, 760, 763, 767, 770, 776, 796, 797, 798, 799, 801, 802, 803, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 831, 834, 839, 840, 841, 842, 847, 848, 849, 851, 857, 858, 885, 886, 887, 889, 890, 891, 892, 893, 894, 896, 897, 898, 900, 902, 903, 905, 908, 912, 915, 916, 917, 919, 920, 921, 922, 924, 925, 926, 928, 929, 930, 931, 932, 963, 964, 965, 967, 968, 969, 970, 971, 972, 973, 975, 976, 977, 980, 981, 982, 983, 984, 986, 987, 988, 991, 992, 993, 994, 995, 996, 997, 998, 1000, 1001, 1002, 1045, 1046, 1047, 1048, 1049, 1051, 1052, 1053, 1056, 1057, 1058, 1059, 1061, 1062, 1063, 1066, 1067, 1068, 1069, 1070, 1075, 1076, 1077, 1078, 1080, 1085, 1086, 1087, 1088, 1089, 1092, 1093, 1094, 1095, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 1116, 1132, 1133, 1137, 1138, 1139, 1141, 1144, 1145, 1150, 1151, 1152, 1153, 1167, 1170, 1175, 1176, 1177, 1178, 1180, 1183, 1187, 1190, 1196, 1213, 1216, 1221, 1222, 1223, 1224, 1226, 1229, 1233, 1236, 1237, 1238, 1240, 1243, 1247, 1250, 1251, 1252, 1254, 1257, 1261, 1264, 1270, 1274, 1279, 1280, 1282, 1283, 1287, 1288, 1295, 1296, 1299, 1301, 1302, 1324, 1325, 1330, 1331, 1332, 1337, 1338, 1341, 1342, 1347, 1348, 1349, 1354, 1355, 1357, 1358, 1363, 1364, 1366, 1367, 1368, 1370, 1371, 1376, 1377, 1378, 1383, 1384, 1472, 1473, 1475, 1476, 1477, 1478, 1479, 1481, 1484, 1488, 1491, 1492, 1494, 1500, 1506, 1512, 1518, 1524, 1525, 1526, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1597, 1598, 1599, 1601, 1602, 1603, 1605, 1606, 1608, 1609, 1610, 1611, 1612, 1614, 1615, 1617, 1618, 1619, 1620, 1621, 1622, 1624, 1625, 1626, 1628, 1629, 1634, 1635, 1636, 1637, 1638, 1639, 1641, 1642, 1643, 1645, 1646, 1651, 1652, 1684, 1685, 1686, 1691, 1692, 1693, 1695, 1696, 1697, 1699, 1700, 1701, 1706, 1707, 1708, 1709, 1714, 1715, 1718, 1722, 1725, 1726, 1728, 1729, 1730, 1732, 1735, 1739, 1742, 1743, 1744, 1745, 1745, 1748, 1750, 1751, 1753, 1754, 1759, 1760, 1761, 1772, 1775, 1778, 1782, 1785, 1789, 1792, 1796, 1799, 1803, 1806, 1810, 1813, 1817, 1820, 1824, 1827, 1831, 1834, 1838, 1841, 1845, 1848, 1852, 1855, 1859, 1862, 1866, 1869, 1873, 1876, 1880, 1883, 1887, 1890};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 93
new 0 23 93
assign 1 24 94
new 0 24 94
assign 1 25 95
new 0 25 95
assign 1 26 96
new 0 26 96
assign 1 28 97
assign 1 29 98
constantsGet 0 29 98
assign 1 30 99
ntypesGet 0 30 99
assign 1 31 100
TOKENGet 0 31 100
assign 1 32 101
new 0 32 101
assign 1 37 107
nlcGet 0 37 107
assign 1 37 108
copy 0 37 108
assign 1 38 109
nlecGet 0 38 109
assign 1 38 110
copy 0 38 110
assign 1 39 111
inClassNpGet 0 39 111
assign 1 40 112
inFileGet 0 40 112
assign 1 44 126
def 1 44 131
assign 1 44 132
firstGet 0 44 132
assign 1 44 133
def 1 44 138
assign 1 0 139
assign 1 0 142
assign 1 0 146
assign 1 45 149
firstGet 0 45 149
return 1 45 150
assign 1 47 152
nextPeerGet 0 47 152
assign 1 48 153
assign 1 49 156
undef 1 49 161
assign 1 49 162
def 1 49 167
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 50 178
nextPeerGet 0 50 178
assign 1 51 179
containerGet 0 51 179
return 1 53 185
assign 1 57 193
nextPeerGet 0 57 193
assign 1 58 194
assign 1 59 197
undef 1 59 202
assign 1 59 203
def 1 59 208
assign 1 0 209
assign 1 0 212
assign 1 0 216
assign 1 60 219
nextPeerGet 0 60 219
assign 1 61 220
containerGet 0 61 220
return 1 63 226
assign 1 67 233
undef 1 67 238
return 1 68 239
assign 1 70 241
nextGet 0 70 241
assign 1 71 242
undef 1 71 247
return 1 72 248
assign 1 74 250
heldGet 0 74 250
return 1 74 251
assign 1 78 258
undef 1 78 263
return 1 79 264
assign 1 81 266
priorGet 0 81 266
assign 1 82 267
undef 1 82 272
return 1 83 273
assign 1 85 275
heldGet 0 85 275
return 1 85 276
assign 1 89 280
firstGet 0 89 280
return 1 89 281
assign 1 93 285
secondGet 0 93 285
return 1 93 286
assign 1 97 290
thirdGet 0 97 290
return 1 97 291
assign 1 101 298
undef 1 101 303
assign 1 102 304
new 0 102 304
return 1 102 305
assign 1 104 307
priorGet 0 104 307
assign 1 104 308
undef 1 104 313
return 1 104 313
assign 1 108 324
undef 1 108 329
assign 1 0 330
assign 1 108 333
priorGet 0 108 333
assign 1 108 334
undef 1 108 339
assign 1 0 340
assign 1 0 343
assign 1 109 347
new 0 109 347
return 1 109 348
assign 1 111 350
priorGet 0 111 350
assign 1 111 351
priorGet 0 111 351
assign 1 111 352
undef 1 111 357
return 1 111 357
assign 1 115 373
undef 1 115 378
assign 1 0 379
assign 1 115 382
priorGet 0 115 382
assign 1 115 383
undef 1 115 388
assign 1 0 389
assign 1 0 392
assign 1 0 396
assign 1 115 399
priorGet 0 115 399
assign 1 115 400
priorGet 0 115 400
assign 1 115 401
undef 1 115 406
assign 1 0 407
assign 1 0 410
assign 1 116 414
new 0 116 414
return 1 116 415
assign 1 118 417
priorGet 0 118 417
assign 1 118 418
priorGet 0 118 418
assign 1 118 419
priorGet 0 118 419
assign 1 118 420
undef 1 118 425
return 1 118 425
assign 1 122 428
new 0 122 428
assign 1 126 433
undef 1 126 438
return 1 127 439
delete 0 129 441
assign 1 130 442
assign 1 131 443
assign 1 135 450
undef 1 135 455
return 1 136 456
assign 1 138 458
mylistGet 0 138 458
assign 1 138 459
newNode 1 138 459
insertBefore 1 138 460
containerSet 1 139 461
assign 1 143 466
undef 1 143 471
initContained 0 144 472
prepend 1 146 474
containerSet 1 147 475
assign 1 151 480
undef 1 151 485
initContained 0 152 486
addValue 1 154 488
containerSet 1 155 489
assign 1 159 493
new 0 159 493
assign 1 163 498
undef 1 163 503
assign 1 164 504
new 0 164 504
assign 1 171 512
toStringCompact 0 171 512
print 0 173 516
throw 1 174 517
return 1 176 519
assign 1 180 559
prefixGet 0 180 559
assign 1 181 560
new 0 181 560
assign 1 181 561
add 1 181 561
assign 1 181 562
toString 0 181 562
assign 1 181 563
add 1 181 563
assign 1 181 564
new 0 181 564
assign 1 181 565
add 1 181 565
assign 1 182 566
new 0 182 566
assign 1 182 567
newlineGet 0 182 567
assign 1 182 568
add 1 182 568
assign 1 182 569
add 1 182 569
assign 1 182 570
new 0 182 570
assign 1 182 571
add 1 182 571
assign 1 182 572
toString 0 182 572
assign 1 182 573
add 1 182 573
assign 1 183 574
def 1 183 579
assign 1 183 580
def 1 183 585
assign 1 0 586
assign 1 0 589
assign 1 0 593
assign 1 184 596
new 0 184 596
assign 1 184 597
newlineGet 0 184 597
assign 1 184 598
add 1 184 598
assign 1 184 599
add 1 184 599
assign 1 184 600
new 0 184 600
assign 1 184 601
add 1 184 601
assign 1 184 602
toString 0 184 602
assign 1 184 603
add 1 184 603
assign 1 184 604
new 0 184 604
assign 1 184 605
add 1 184 605
assign 1 184 606
add 1 184 606
assign 1 184 607
new 0 184 607
assign 1 184 608
newlineGet 0 184 608
assign 1 184 609
add 1 184 609
assign 1 186 611
def 1 186 616
assign 1 187 617
new 0 187 617
assign 1 187 618
newlineGet 0 187 618
assign 1 187 619
add 1 187 619
assign 1 187 620
add 1 187 620
assign 1 187 621
new 0 187 621
assign 1 187 622
add 1 187 622
assign 1 188 623
toString 0 188 623
assign 1 188 624
add 1 188 624
return 1 190 626
assign 1 194 648
prefixGet 0 194 648
assign 1 195 649
new 0 195 649
assign 1 195 650
add 1 195 650
assign 1 195 651
toString 0 195 651
assign 1 195 652
add 1 195 652
assign 1 195 653
new 0 195 653
assign 1 195 654
add 1 195 654
assign 1 196 655
def 1 196 660
assign 1 197 661
new 0 197 661
assign 1 197 662
add 1 197 662
assign 1 197 663
toString 0 197 663
assign 1 197 664
add 1 197 664
assign 1 199 666
def 1 199 671
assign 1 200 672
new 0 200 672
assign 1 200 673
add 1 200 673
assign 1 200 674
toString 0 200 674
assign 1 200 675
add 1 200 675
assign 1 202 677
def 1 202 682
assign 1 203 683
new 0 203 683
assign 1 203 684
add 1 203 684
assign 1 203 685
toString 0 203 685
assign 1 203 686
add 1 203 686
return 1 205 688
assign 1 209 694
new 0 209 694
assign 1 210 695
assign 1 211 698
def 1 211 703
incrementValue 0 212 704
assign 1 213 705
containerGet 0 213 705
return 1 215 711
assign 1 219 719
depthGet 0 219 719
assign 1 220 720
new 0 220 720
assign 1 221 721
new 0 221 721
assign 1 222 722
new 0 222 722
assign 1 222 725
lesser 1 222 730
assign 1 223 731
add 1 223 731
incrementValue 0 222 732
return 1 225 738
assign 1 229 747
assign 1 230 750
def 1 230 755
assign 1 230 756
typenameGet 0 230 756
assign 1 230 757
TRANSUNITGet 0 230 757
assign 1 230 758
notEquals 1 230 758
assign 1 0 760
assign 1 0 763
assign 1 0 767
assign 1 231 770
containerGet 0 231 770
return 1 233 776
assign 1 237 796
scopeGet 0 237 796
assign 1 238 797
typenameGet 0 238 797
assign 1 238 798
METHODGet 0 238 798
assign 1 238 799
notEquals 1 238 799
assign 1 239 801
new 0 239 801
assign 1 239 802
new 2 239 802
throw 1 239 803
assign 1 241 805
heldGet 0 241 805
assign 1 241 806
tmpCntGet 0 241 806
assign 1 241 807
toString 0 241 807
assign 1 242 808
heldGet 0 242 808
assign 1 242 809
tmpCntGet 0 242 809
incrementValue 0 242 810
assign 1 243 811
new 0 243 811
assign 1 244 812
new 0 244 812
isTmpVarSet 1 244 813
assign 1 245 814
new 0 245 814
autoTypeSet 1 245 815
suffixSet 1 246 816
assign 1 247 817
new 0 247 817
assign 1 247 818
add 1 247 818
assign 1 247 819
add 1 247 819
nameSet 1 247 820
return 1 248 821
assign 1 252 831
assign 1 253 834
def 1 253 839
assign 1 254 840
typenameGet 0 254 840
assign 1 254 841
PROPERTIESGet 0 254 841
assign 1 254 842
equals 1 254 847
assign 1 255 848
new 0 255 848
return 1 255 849
assign 1 257 851
containerGet 0 257 851
assign 1 259 857
new 0 259 857
return 1 259 858
assign 1 263 885
assign 1 264 886
isAddedGet 0 264 886
assign 1 264 887
not 0 264 887
assign 1 265 889
new 0 265 889
isAddedSet 1 265 890
assign 1 266 891
scopeGet 0 266 891
assign 1 267 892
typenameGet 0 267 892
assign 1 267 893
CLASSGet 0 267 893
assign 1 267 894
equals 1 267 894
assign 1 268 896
new 0 268 896
assign 1 268 897
new 2 268 897
throw 1 268 898
assign 1 270 900
inPropertiesGet 0 270 900
assign 1 270 902
isTmpVarGet 0 270 902
assign 1 270 903
not 0 270 903
assign 1 0 905
assign 1 0 908
assign 1 0 912
assign 1 271 915
classGet 0 271 915
assign 1 272 916
new 0 272 916
isPropertySet 1 272 917
assign 1 274 919
heldGet 0 274 919
assign 1 275 920
anyMapGet 0 275 920
assign 1 275 921
nameGet 0 275 921
assign 1 275 922
has 1 275 922
assign 1 276 924
new 0 276 924
assign 1 276 925
new 2 276 925
throw 1 276 926
assign 1 278 928
anyMapGet 0 278 928
assign 1 278 929
nameGet 0 278 929
put 2 278 930
assign 1 279 931
orderedVarsGet 0 279 931
addValue 1 279 932
assign 1 284 963
assign 1 285 964
isAddedGet 0 285 964
assign 1 285 965
not 0 285 965
assign 1 286 967
new 0 286 967
isAddedSet 1 286 968
assign 1 287 969
scopeGet 0 287 969
assign 1 288 970
heldGet 0 288 970
assign 1 289 971
anyMapGet 0 289 971
assign 1 289 972
nameGet 0 289 972
assign 1 289 973
has 1 289 973
assign 1 290 975
anyMapGet 0 290 975
assign 1 290 976
nameGet 0 290 976
assign 1 290 977
get 1 290 977
assign 1 292 980
classGet 0 292 980
assign 1 292 981
heldGet 0 292 981
assign 1 293 982
anyMapGet 0 293 982
assign 1 293 983
nameGet 0 293 983
assign 1 293 984
has 1 293 984
assign 1 294 986
anyMapGet 0 294 986
assign 1 294 987
nameGet 0 294 987
assign 1 294 988
get 1 294 988
assign 1 296 991
anyMapGet 0 296 991
assign 1 296 992
nameGet 0 296 992
put 2 296 993
assign 1 297 994
orderedVarsGet 0 297 994
addValue 1 297 995
assign 1 298 996
typenameGet 0 298 996
assign 1 298 997
CLASSGet 0 298 997
assign 1 298 998
equals 1 298 998
assign 1 299 1000
new 0 299 1000
assign 1 299 1001
new 2 299 1001
throw 1 299 1002
assign 1 308 1045
assign 1 309 1046
scopeGet 0 309 1046
assign 1 309 1047
heldGet 0 309 1047
assign 1 310 1048
anyMapGet 0 310 1048
assign 1 310 1049
has 1 310 1049
assign 1 311 1051
anyMapGet 0 311 1051
assign 1 311 1052
get 1 311 1052
assign 1 311 1053
heldGet 0 311 1053
assign 1 313 1056
classGet 0 313 1056
assign 1 313 1057
heldGet 0 313 1057
assign 1 314 1058
anyMapGet 0 314 1058
assign 1 314 1059
has 1 314 1059
assign 1 315 1061
anyMapGet 0 315 1061
assign 1 315 1062
get 1 315 1062
assign 1 315 1063
heldGet 0 315 1063
assign 1 317 1066
transUnitGet 0 317 1066
assign 1 318 1067
heldGet 0 318 1067
assign 1 318 1068
aliasedGet 0 318 1068
assign 1 318 1069
get 1 318 1069
assign 1 319 1070
undef 1 319 1075
assign 1 320 1076
emitDataGet 0 320 1076
assign 1 320 1077
aliasedGet 0 320 1077
assign 1 320 1078
get 1 320 1078
assign 1 322 1080
def 1 322 1085
assign 1 323 1086
new 0 323 1086
assign 1 323 1087
add 1 323 1087
assign 1 323 1088
new 2 323 1088
throw 1 323 1089
assign 1 326 1092
new 0 326 1092
nameSet 1 327 1093
assign 1 328 1094
new 0 328 1094
assign 1 328 1095
equals 1 328 1095
assign 1 329 1097
assign 1 330 1098
new 0 330 1098
isTypedSet 1 330 1099
assign 1 331 1100
extendsGet 0 331 1100
namepathSet 1 331 1101
assign 1 332 1102
anyMapGet 0 332 1102
put 2 332 1103
assign 1 333 1104
orderedVarsGet 0 333 1104
addValue 1 333 1105
assign 1 335 1108
new 0 335 1108
isDeclaredSet 1 335 1109
assign 1 336 1110
new 0 336 1110
isPropertySet 1 336 1111
assign 1 337 1112
assign 1 338 1113
anyMapGet 0 338 1113
put 2 338 1114
assign 1 339 1115
orderedVarsGet 0 339 1115
addValue 1 339 1116
assign 1 347 1132
assign 1 348 1133
new 0 348 1133
assign 1 350 1137
anchorTypesGet 0 350 1137
assign 1 350 1138
typenameGet 0 350 1138
assign 1 350 1139
has 1 350 1139
return 1 351 1141
assign 1 353 1144
containerGet 0 353 1144
assign 1 354 1145
undef 1 354 1150
assign 1 355 1151
new 0 355 1151
assign 1 355 1152
new 2 355 1152
throw 1 355 1153
assign 1 363 1167
assign 1 364 1170
def 1 364 1175
assign 1 364 1176
typenameGet 0 364 1176
assign 1 364 1177
CLASSGet 0 364 1177
assign 1 364 1178
notEquals 1 364 1178
assign 1 0 1180
assign 1 0 1183
assign 1 0 1187
assign 1 365 1190
containerGet 0 365 1190
return 1 367 1196
assign 1 371 1213
assign 1 372 1216
def 1 372 1221
assign 1 372 1222
typenameGet 0 372 1222
assign 1 372 1223
CLASSGet 0 372 1223
assign 1 372 1224
notEquals 1 372 1224
assign 1 0 1226
assign 1 0 1229
assign 1 0 1233
assign 1 372 1236
typenameGet 0 372 1236
assign 1 372 1237
METHODGet 0 372 1237
assign 1 372 1238
notEquals 1 372 1238
assign 1 0 1240
assign 1 0 1243
assign 1 0 1247
assign 1 372 1250
typenameGet 0 372 1250
assign 1 372 1251
TRANSUNITGet 0 372 1251
assign 1 372 1252
notEquals 1 372 1252
assign 1 0 1254
assign 1 0 1257
assign 1 0 1261
assign 1 373 1264
containerGet 0 373 1264
return 1 375 1270
assign 1 379 1274
undef 1 379 1279
return 1 380 1280
containerSet 1 382 1282
heldSet 1 383 1283
delete 0 387 1287
addValue 1 388 1288
assign 1 392 1295
containedGet 0 392 1295
assign 1 393 1296
iteratorGet 0 393 1296
assign 1 393 1299
hasNextGet 0 393 1299
assign 1 394 1301
nextGet 0 394 1301
containerSet 1 395 1302
assign 1 401 1324
NAMEPATHGet 0 401 1324
assign 1 401 1325
equals 1 401 1330
assign 1 402 1331
assign 1 403 1332
def 1 403 1337
resolve 1 404 1338
assign 1 407 1341
CLASSGet 0 407 1341
assign 1 407 1342
equals 1 407 1347
assign 1 408 1348
namepathGet 0 408 1348
assign 1 409 1349
def 1 409 1354
resolve 1 410 1355
assign 1 412 1357
extendsGet 0 412 1357
assign 1 413 1358
def 1 413 1363
resolve 1 414 1364
assign 1 416 1366
namepathGet 0 416 1366
assign 1 416 1367
toString 0 416 1367
nameSet 1 416 1368
assign 1 418 1370
VARGet 0 418 1370
assign 1 418 1371
equals 1 418 1376
assign 1 419 1377
namepathGet 0 419 1377
assign 1 420 1378
def 1 420 1383
resolve 1 421 1384
assign 1 431 1472
heldGet 0 431 1472
assign 1 431 1473
isConstructGet 0 431 1473
assign 1 431 1475
heldGet 0 431 1475
assign 1 431 1476
newNpGet 0 431 1476
assign 1 431 1477
toString 0 431 1477
assign 1 431 1478
new 0 431 1478
assign 1 431 1479
equals 1 431 1479
assign 1 0 1481
assign 1 0 1484
assign 1 0 1488
assign 1 432 1491
new 0 432 1491
return 1 432 1492
assign 1 435 1494
new 0 435 1494
assign 1 436 1500
new 0 436 1500
assign 1 437 1506
new 0 437 1506
assign 1 438 1512
new 0 438 1512
assign 1 439 1518
new 0 439 1518
assign 1 440 1524
sizeGet 0 440 1524
assign 1 440 1525
new 0 440 1525
assign 1 440 1526
equals 1 440 1531
assign 1 447 1532
new 0 447 1532
put 1 447 1533
assign 1 450 1534
new 0 450 1534
put 1 450 1535
assign 1 451 1536
new 0 451 1536
put 1 451 1537
assign 1 453 1538
new 0 453 1538
put 1 453 1539
assign 1 454 1540
new 0 454 1540
put 1 454 1541
assign 1 455 1542
new 0 455 1542
put 1 455 1543
assign 1 456 1544
new 0 456 1544
put 1 456 1545
assign 1 457 1546
new 0 457 1546
put 1 457 1547
assign 1 458 1548
new 0 458 1548
put 1 458 1549
assign 1 459 1550
new 0 459 1550
put 1 459 1551
assign 1 460 1552
new 0 460 1552
put 1 460 1553
assign 1 461 1554
new 0 461 1554
put 1 461 1555
assign 1 462 1556
new 0 462 1556
put 1 462 1557
assign 1 463 1558
new 0 463 1558
put 1 463 1559
assign 1 464 1560
new 0 464 1560
put 1 464 1561
assign 1 465 1562
new 0 465 1562
put 1 465 1563
assign 1 466 1564
new 0 466 1564
put 1 466 1565
assign 1 467 1566
new 0 467 1566
put 1 467 1567
assign 1 468 1568
new 0 468 1568
put 1 468 1569
assign 1 469 1570
new 0 469 1570
put 1 469 1571
assign 1 470 1572
new 0 470 1572
put 1 470 1573
assign 1 471 1574
new 0 471 1574
put 1 471 1575
assign 1 472 1576
new 0 472 1576
put 1 472 1577
assign 1 473 1578
new 0 473 1578
put 1 473 1579
assign 1 474 1580
new 0 474 1580
put 1 474 1581
assign 1 475 1582
new 0 475 1582
put 1 475 1583
assign 1 476 1584
new 0 476 1584
put 1 476 1585
assign 1 477 1586
new 0 477 1586
put 1 477 1587
assign 1 481 1588
new 0 481 1588
put 1 481 1589
assign 1 482 1590
new 0 482 1590
put 1 482 1591
assign 1 483 1592
new 0 483 1592
put 1 483 1593
assign 1 484 1594
new 0 484 1594
put 1 484 1595
assign 1 489 1596
new 0 489 1596
put 1 489 1597
assign 1 490 1598
new 0 490 1598
put 1 490 1599
assign 1 494 1601
heldGet 0 494 1601
assign 1 494 1602
nameGet 0 494 1602
assign 1 494 1603
has 1 494 1603
assign 1 496 1605
new 0 496 1605
return 1 496 1606
assign 1 500 1608
containedGet 0 500 1608
assign 1 500 1609
firstGet 0 500 1609
assign 1 500 1610
heldGet 0 500 1610
assign 1 500 1611
isTypedGet 0 500 1611
assign 1 500 1612
not 0 500 1612
assign 1 502 1614
new 0 502 1614
return 1 502 1615
assign 1 510 1617
containedGet 0 510 1617
assign 1 510 1618
firstGet 0 510 1618
assign 1 510 1619
heldGet 0 510 1619
assign 1 510 1620
namepathGet 0 510 1620
assign 1 510 1621
toString 0 510 1621
assign 1 510 1622
has 1 510 1622
assign 1 511 1624
heldGet 0 511 1624
assign 1 511 1625
nameGet 0 511 1625
assign 1 511 1626
has 1 511 1626
assign 1 513 1628
new 0 513 1628
return 1 513 1629
assign 1 518 1634
containedGet 0 518 1634
assign 1 518 1635
firstGet 0 518 1635
assign 1 518 1636
heldGet 0 518 1636
assign 1 518 1637
namepathGet 0 518 1637
assign 1 518 1638
toString 0 518 1638
assign 1 518 1639
has 1 518 1639
assign 1 519 1641
heldGet 0 519 1641
assign 1 519 1642
nameGet 0 519 1642
assign 1 519 1643
has 1 519 1643
assign 1 521 1645
new 0 521 1645
return 1 521 1646
assign 1 527 1651
new 0 527 1651
return 1 527 1652
assign 1 538 1684
new 0 538 1684
assign 1 543 1685
CALLGet 0 543 1685
assign 1 543 1686
notEquals 1 543 1691
assign 1 543 1692
new 0 543 1692
return 1 543 1693
assign 1 544 1695
orgNameGet 0 544 1695
assign 1 544 1696
new 0 544 1696
assign 1 544 1697
equals 1 544 1697
assign 1 545 1699
firstGet 0 545 1699
assign 1 546 1700
secondGet 0 546 1700
assign 1 547 1701
def 1 547 1706
assign 1 547 1707
typenameGet 0 547 1707
assign 1 547 1708
CALLGet 0 547 1708
assign 1 547 1709
equals 1 547 1714
assign 1 0 1715
assign 1 0 1718
assign 1 0 1722
assign 1 548 1725
heldGet 0 548 1725
assign 1 548 1726
isLiteralGet 0 548 1726
assign 1 548 1728
heldGet 0 548 1728
assign 1 548 1729
isPropertyGet 0 548 1729
assign 1 548 1730
not 0 548 1730
assign 1 0 1732
assign 1 0 1735
assign 1 0 1739
assign 1 549 1742
new 0 549 1742
assign 1 550 1743
heldGet 0 550 1743
assign 1 550 1744
allCallsGet 0 550 1744
assign 1 550 1745
iteratorGet 0 0 1745
assign 1 550 1748
hasNextGet 0 550 1748
assign 1 550 1750
nextGet 0 550 1750
assign 1 551 1751
notEquals 1 551 1751
assign 1 552 1753
callIsSafe 1 552 1753
assign 1 552 1754
not 0 552 1759
assign 1 553 1760
new 0 553 1760
return 1 553 1761
return 1 564 1772
return 1 0 1775
assign 1 0 1778
return 1 0 1782
assign 1 0 1785
return 1 0 1789
assign 1 0 1792
return 1 0 1796
assign 1 0 1799
return 1 0 1803
assign 1 0 1806
return 1 0 1810
assign 1 0 1813
return 1 0 1817
assign 1 0 1820
return 1 0 1824
assign 1 0 1827
return 1 0 1831
assign 1 0 1834
return 1 0 1838
assign 1 0 1841
return 1 0 1845
assign 1 0 1848
return 1 0 1852
assign 1 0 1855
return 1 0 1859
assign 1 0 1862
return 1 0 1866
assign 1 0 1869
return 1 0 1873
assign 1 0 1876
return 1 0 1880
assign 1 0 1883
return 1 0 1887
assign 1 0 1890
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -223604944: return bem_inFileGet_0();
case -1988392847: return bem_fieldIteratorGet_0();
case 49643355: return bem_containerGet_0();
case 1837464714: return bem_isFirstGet_0();
case 774484188: return bem_condanyGet_0();
case 901060004: return bem_copy_0();
case -1601492406: return bem_new_0();
case 548827371: return bem_delayDeleteGet_0();
case 741511465: return bem_print_0();
case 1825207979: return bem_delete_0();
case 1087786397: return bem_deserializeClassNameGet_0();
case 1269150062: return bem_wideStringGet_0();
case 1401861296: return bem_typenameGet_0();
case -1194864649: return bem_toString_0();
case 769621804: return bem_nextDescendGet_0();
case -1615655540: return bem_buildGet_0();
case 1869713164: return bem_transUnitGet_0();
case -570363758: return bem_serializationIteratorGet_0();
case 1387595522: return bem_toAny_0();
case -961535531: return bem_hashGet_0();
case -231928036: return bem_nextAscendGet_0();
case 119391370: return bem_toStringBig_0();
case 730619711: return bem_many_0();
case -1926181445: return bem_inlinedGet_0();
case 1400602616: return bem_isThirdGet_0();
case -96915735: return bem_prefixGet_0();
case 1278732754: return bem_create_0();
case -1721108942: return bem_heldByGet_0();
case 1048018668: return bem_constantsGet_0();
case 2101024158: return bem_nextPeerGet_0();
case 510205692: return bem_priorPeerGet_0();
case -1653328214: return bem_initContained_0();
case 314603473: return bem_inPropertiesGet_0();
case 289960613: return bem_toStringCompact_0();
case -1411800865: return bem_nlecGet_0();
case 793519474: return bem_inClassNpGet_0();
case 144613256: return bem_serializeContents_0();
case 1198276971: return bem_depthGet_0();
case 67969809: return bem_thirdGet_0();
case 1234289396: return bem_tagGet_0();
case -558330064: return bem_typeDetailGet_0();
case 1903314865: return bem_firstGet_0();
case -306765275: return bem_addVariable_0();
case -1483056837: return bem_isLiteralOnceGet_0();
case 1359373450: return bem_echo_0();
case -1084705067: return bem_reInitContained_0();
case 305137971: return bem_classNameGet_0();
case 1754138735: return bem_isSecondGet_0();
case 627086221: return bem_once_0();
case -576222227: return bem_delayDelete_0();
case 64442602: return bem_ntypesGet_0();
case 1997603557: return bem_secondGet_0();
case 1505938490: return bem_classGet_0();
case 436412028: return bem_sourceFileNameGet_0();
case -618272712: return bem_containedGet_0();
case -1202148797: return bem_anchorGet_0();
case -731544773: return bem_scopeGet_0();
case -1780056966: return bem_nlcGet_0();
case -1550372712: return bem_serializeToString_0();
case 1997768772: return bem_resolveNp_0();
case 1775327673: return bem_syncAddVariable_0();
case -612311095: return bem_iteratorGet_0();
case 1943587046: return bem_heldGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1001249520: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1484813727: return bem_typenameSet_1(bevd_0);
case -2033049774: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case -1903482804: return bem_otherClass_1(bevd_0);
case -1023168427: return bem_sameClass_1(bevd_0);
case 756285563: return bem_typeDetailSet_1(bevd_0);
case -686450804: return bem_defined_1(bevd_0);
case 1632896297: return bem_inFileSet_1(bevd_0);
case -1568064603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1474265413: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case -481563534: return bem_constantsSet_1(bevd_0);
case -1476531338: return bem_nlcSet_1(bevd_0);
case -309742024: return bem_def_1(bevd_0);
case 1338201402: return bem_containedSet_1(bevd_0);
case -596533003: return bem_otherType_1(bevd_0);
case -534781062: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case -342503007: return bem_heldBySet_1(bevd_0);
case 969649139: return bem_inlinedSet_1(bevd_0);
case -1633632376: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1540044070: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case -1901677144: return bem_condanySet_1(bevd_0);
case 1867212667: return bem_heldSet_1(bevd_0);
case -1718194680: return bem_undefined_1(bevd_0);
case 1219069542: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case -377671183: return bem_containerSet_1(bevd_0);
case 1067421305: return bem_notEquals_1(bevd_0);
case 661372330: return bem_equals_1(bevd_0);
case 457153382: return bem_copyTo_1(bevd_0);
case 1717289899: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1420318580: return bem_sameType_1(bevd_0);
case 910000225: return bem_ntypesSet_1(bevd_0);
case 832868156: return bem_callIsSafe_1((BEC_2_5_4_BuildNode) bevd_0);
case 972846723: return bem_wideStringSet_1(bevd_0);
case -2049241562: return bem_sameObject_1(bevd_0);
case 1883383203: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case 266931166: return bem_undef_1(bevd_0);
case 871884670: return bem_delayDeleteSet_1(bevd_0);
case 385185820: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -215591216: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case -1687924341: return bem_nlecSet_1(bevd_0);
case -1584461232: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case -1714995105: return bem_buildSet_1(bevd_0);
case -67906202: return bem_inClassNpSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1068549042: return bem_tmpVar_2(bevd_0, bevd_1);
case 1461540614: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513720300: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 224164494: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2129126272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 88269440: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -366737409: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -666768572: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_4_BuildNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst = (BEC_2_5_4_BuildNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst;
}
}
