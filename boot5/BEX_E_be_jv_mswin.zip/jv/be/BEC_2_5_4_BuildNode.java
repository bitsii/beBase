package be;
/* IO:File: source/build/Nodes.be */
public final class BEC_2_5_4_BuildNode extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
private static byte[] becc_BEC_2_5_4_BuildNode_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_2_5_4_BuildNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_0 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_1 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_5 = {0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_6 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_7 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_8, 7));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_9, 8));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_10 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_10, 1));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_11 = {0x20,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_11, 2));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_13 = {0x5F,0x74,0x6D,0x70,0x61,0x6E,0x79,0x5F};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_17, 18));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_5;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_6;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_7;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_8;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_9;
private static BEC_2_4_3_MathInt bece_BEC_2_5_4_BuildNode_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_inst;

public static BET_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_type;

public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_6_6_SystemObject bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_2_4_3_MathInt(0));
bevp_nlec = (new BEC_2_4_3_MathInt(0));
bevp_wideString = be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = bevt_0_tmpany_phold.bem_copy_0();
bevt_1_tmpany_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = bevt_1_tmpany_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (bevp_contained == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_4_tmpany_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 44 */
 else  /* Line: 44 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 44 */ {
bevt_5_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_tmpany_phold;
} /* Line: 45 */
bevl_ret = bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 49 */ {
if (bevl_ret == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 49 */ {
if (bevl_con == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
 else  /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 49 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 51 */
 else  /* Line: 49 */ {
break;
} /* Line: 49 */
} /* Line: 49 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevl_ret = bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 59 */ {
if (bevl_ret == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 59 */ {
if (bevl_con == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 59 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 59 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 61 */
 else  /* Line: 59 */ {
break;
} /* Line: 59 */
} /* Line: 59 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 67 */ {
return null;
} /* Line: 68 */
bevl_hh = bevp_heldBy.bemd_0(-1947306340);
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 71 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 72 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(-1200745202);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 78 */ {
return null;
} /* Line: 79 */
bevl_hh = bevp_heldBy.bemd_0(-471411300);
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 82 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 83 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(-1200745202);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 101 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 102 */
bevt_3_tmpany_phold = bevp_heldBy.bemd_0(-471411300);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_3_tmpany_phold = bevp_heldBy.bemd_0(-471411300);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 109 */
bevt_7_tmpany_phold = bevp_heldBy.bemd_0(-471411300);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-471411300);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 115 */ {
bevt_4_tmpany_phold = bevp_heldBy.bemd_0(-471411300);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 115 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 115 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 115 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 115 */ {
bevt_7_tmpany_phold = bevp_heldBy.bemd_0(-471411300);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-471411300);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 115 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 115 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 115 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 116 */
bevt_12_tmpany_phold = bevp_heldBy.bemd_0(-471411300);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-471411300);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-471411300);
if (bevt_10_tmpany_phold == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 126 */ {
return null;
} /* Line: 127 */
bevp_heldBy.bemd_0(422356544);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 135 */ {
return null;
} /* Line: 136 */
bevt_2_tmpany_phold = bevp_heldBy.bemd_0(-1875033857);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(298062576, beva_x);
bevp_heldBy.bemd_1(1035789005, bevt_1_tmpany_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 143 */ {
bem_initContained_0();
} /* Line: 144 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 151 */ {
bem_initContained_0();
} /* Line: 152 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 164 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try  /* Line: 170 */ {
bevl_res = bem_toStringCompact_0();
} /* Line: 171 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(321704245);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 174 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
bevl_prefix = bem_prefixGet_0();
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_2_tmpany_phold = bevl_prefix.bemd_1(2044454682, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_typename.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(2044454682, bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = bevt_1_tmpany_phold.bemd_1(2044454682, bevt_5_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_newlineGet_0();
bevt_8_tmpany_phold = bevl_ret.bemd_1(2044454682, bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(2044454682, bevl_prefix);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_2));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(2044454682, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bemd_1(2044454682, bevt_12_tmpany_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 183 */ {
if (bevp_inFile == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 183 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 183 */
 else  /* Line: 183 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 183 */ {
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_newlineGet_0();
bevt_20_tmpany_phold = bevl_ret.bemd_1(2044454682, bevt_21_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(2044454682, bevl_prefix);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_3));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(2044454682, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(2044454682, bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_4));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_1(2044454682, bevt_25_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(2044454682, bevp_inFile);
bevt_27_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpany_phold.bemd_1(2044454682, bevt_26_tmpany_phold);
} /* Line: 184 */
if (bevp_held == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_32_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_newlineGet_0();
bevt_30_tmpany_phold = bevl_ret.bemd_1(2044454682, bevt_31_tmpany_phold);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_1(2044454682, bevl_prefix);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevl_ret = bevt_29_tmpany_phold.bemd_1(2044454682, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_held.bemd_0(-2069102102);
bevl_ret = bevl_ret.bemd_1(2044454682, bevt_34_tmpany_phold);
} /* Line: 188 */
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
bevl_prefix = bem_prefixGet_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_6));
bevt_1_tmpany_phold = bevl_prefix.bemd_1(2044454682, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_typename.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(2044454682, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_7));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(2044454682, bevt_4_tmpany_phold);
if (bevp_nlc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_0;
bevt_6_tmpany_phold = bevl_ret.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 197 */
if (bevp_inClassNp == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_1;
bevt_10_tmpany_phold = bevl_ret.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
} /* Line: 200 */
if (bevp_held == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_2;
bevt_14_tmpany_phold = bevl_ret.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_held.bemd_0(-2069102102);
bevl_ret = bevt_14_tmpany_phold.bem_add_1(bevt_16_tmpany_phold);
} /* Line: 203 */
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = (new BEC_2_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 211 */ {
if (bevl_c == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 213 */
 else  /* Line: 211 */ {
break;
} /* Line: 211 */
} /* Line: 211 */
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = bem_depthGet_0();
bevl_p = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = bece_BEC_2_5_4_BuildNode_bevo_3;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 222 */ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 222 */
 else  /* Line: 222 */ {
break;
} /* Line: 222 */
} /* Line: 222 */
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 230 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(1878699153);
bevt_4_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(650080222, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 230 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 230 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 230 */
 else  /* Line: 230 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 230 */ {
bevl_targ = bevl_targ.bemd_0(1043829581);
} /* Line: 231 */
 else  /* Line: 230 */ {
break;
} /* Line: 230 */
} /* Line: 230 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_clnode = bem_scopeGet_0();
bevt_1_tmpany_phold = bevl_clnode.bemd_0(1878699153);
bevt_2_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(650080222, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 238 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildNode_bels_12));
bevt_3_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 239 */
bevt_6_tmpany_phold = bevl_clnode.bemd_0(-1200745202);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-492305021);
bevl_tmpanyn = bevt_5_tmpany_phold.bemd_0(-2069102102);
bevt_8_tmpany_phold = bevl_clnode.bemd_0(-1200745202);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-492305021);
bevt_7_tmpany_phold.bemd_0(-1817476501);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(2090940986, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(-1236115904, bevt_10_tmpany_phold);
bevl_tmpany.bemd_1(2094127207, beva_suffix);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_13));
bevt_12_tmpany_phold = bevl_tmpanyn.bemd_1(2044454682, bevt_13_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(2044454682, beva_suffix);
bevl_tmpany.bemd_1(489040096, bevt_11_tmpany_phold);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 253 */ {
if (bevl_con == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevt_2_tmpany_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 255 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 257 */
 else  /* Line: 253 */ {
break;
} /* Line: 253 */
} /* Line: 253 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevl_v = bevp_held;
bevt_2_tmpany_phold = bevl_v.bemd_0(1302490168);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(964413679);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 264 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-955160237, bevt_3_tmpany_phold);
bevl_sco = bem_scopeGet_0();
bevt_5_tmpany_phold = bevl_sco.bemd_0(1878699153);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1602696702, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 267 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_4_BuildNode_bels_14));
bevt_7_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 268 */
bevt_9_tmpany_phold = bem_inPropertiesGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_11_tmpany_phold = bevl_v.bemd_0(1584542113);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(964413679);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 270 */ {
bevl_sco = bem_classGet_0();
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1524090009, bevt_12_tmpany_phold);
} /* Line: 272 */
bevl_sc = bevl_sco.bemd_0(-1200745202);
bevt_14_tmpany_phold = bevl_sc.bemd_0(-807781558);
bevt_15_tmpany_phold = bevl_v.bemd_0(-1447107675);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_1(-2124473894, bevt_15_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 275 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_4_BuildNode_bels_15));
bevt_16_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 276 */
bevt_18_tmpany_phold = bevl_sc.bemd_0(-807781558);
bevt_19_tmpany_phold = bevl_v.bemd_0(-1447107675);
bevt_18_tmpany_phold.bemd_2(1063407899, bevt_19_tmpany_phold, this);
bevt_20_tmpany_phold = bevl_sc.bemd_0(1323022490);
bevt_20_tmpany_phold.bemd_1(893770658, this);
} /* Line: 279 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevl_v = bevp_held;
bevt_1_tmpany_phold = bevl_v.bemd_0(1302490168);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(964413679);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-955160237, bevt_2_tmpany_phold);
bevl_sco = bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(-1200745202);
bevt_4_tmpany_phold = bevl_sc.bemd_0(-807781558);
bevt_5_tmpany_phold = bevl_v.bemd_0(-1447107675);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-2124473894, bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 289 */ {
bevt_6_tmpany_phold = bevl_sc.bemd_0(-807781558);
bevt_7_tmpany_phold = bevl_v.bemd_0(-1447107675);
bevp_held = bevt_6_tmpany_phold.bemd_1(-458823177, bevt_7_tmpany_phold);
} /* Line: 290 */
 else  /* Line: 291 */ {
bevt_8_tmpany_phold = bem_classGet_0();
bevl_cl = bevt_8_tmpany_phold.bemd_0(-1200745202);
bevt_10_tmpany_phold = bevl_cl.bemd_0(-807781558);
bevt_11_tmpany_phold = bevl_v.bemd_0(-1447107675);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(-2124473894, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 293 */ {
bevt_12_tmpany_phold = bevl_cl.bemd_0(-807781558);
bevt_13_tmpany_phold = bevl_v.bemd_0(-1447107675);
bevp_held = bevt_12_tmpany_phold.bemd_1(-458823177, bevt_13_tmpany_phold);
} /* Line: 294 */
 else  /* Line: 295 */ {
bevt_14_tmpany_phold = bevl_sc.bemd_0(-807781558);
bevt_15_tmpany_phold = bevl_v.bemd_0(-1447107675);
bevt_14_tmpany_phold.bemd_2(1063407899, bevt_15_tmpany_phold, this);
bevt_16_tmpany_phold = bevl_sc.bemd_0(1323022490);
bevt_16_tmpany_phold.bemd_1(893770658, this);
bevt_18_tmpany_phold = bevl_sco.bemd_0(1878699153);
bevt_19_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(1602696702, bevt_19_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 298 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_4_BuildNode_bels_16));
bevt_20_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 299 */
} /* Line: 298 */
} /* Line: 293 */
} /* Line: 289 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_13_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpany_phold = bem_scopeGet_0();
bevl_sc = bevt_0_tmpany_phold.bemd_0(-1200745202);
bevt_2_tmpany_phold = bevl_sc.bemd_0(-807781558);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(-2124473894, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 310 */ {
bevt_4_tmpany_phold = bevl_sc.bemd_0(-807781558);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-458823177, bevl_vname);
bevp_held = bevt_3_tmpany_phold.bemd_0(-1200745202);
} /* Line: 311 */
 else  /* Line: 312 */ {
bevt_5_tmpany_phold = bem_classGet_0();
bevl_cl = bevt_5_tmpany_phold.bemd_0(-1200745202);
bevt_7_tmpany_phold = bevl_cl.bemd_0(-807781558);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(-2124473894, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 314 */ {
bevt_9_tmpany_phold = bevl_cl.bemd_0(-807781558);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_1(-458823177, bevl_vname);
bevp_held = bevt_8_tmpany_phold.bemd_0(-1200745202);
} /* Line: 315 */
 else  /* Line: 316 */ {
bevl_tunode = bem_transUnitGet_0();
bevt_11_tmpany_phold = bevl_tunode.bemd_0(-1200745202);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(547562227);
bevl_np = bevt_10_tmpany_phold.bemd_1(-458823177, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevt_14_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_aliasedGet_0();
bevl_np = bevt_13_tmpany_phold.bem_get_1(bevl_vname);
} /* Line: 320 */
if (bevl_np == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_18_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_4;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevl_np);
bevt_16_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 323 */
 else  /* Line: 324 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(489040096, bevl_vname);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_18));
bevt_19_tmpany_phold = bevl_vname.bemd_1(1602696702, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_19_tmpany_phold).bevi_bool) /* Line: 328 */ {
bevp_held = bevl_v;
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1173707637, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevl_cl.bemd_0(2011682755);
bevl_v.bemd_1(-1091664300, bevt_22_tmpany_phold);
bevt_23_tmpany_phold = bevl_sc.bemd_0(-807781558);
bevt_23_tmpany_phold.bemd_2(1063407899, bevl_vname, this);
bevt_24_tmpany_phold = bevl_sc.bemd_0(1323022490);
bevt_24_tmpany_phold.bemd_1(893770658, this);
} /* Line: 333 */
 else  /* Line: 334 */ {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(156373073, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1524090009, bevt_26_tmpany_phold);
bevp_held = bevl_v;
bevt_27_tmpany_phold = bevl_cl.bemd_0(-807781558);
bevt_27_tmpany_phold.bemd_2(1063407899, bevl_vname, this);
bevt_28_tmpany_phold = bevl_cl.bemd_0(1323022490);
bevt_28_tmpany_phold.bemd_1(893770658, this);
} /* Line: 339 */
} /* Line: 328 */
} /* Line: 322 */
} /* Line: 314 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_node = this;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 348 */ {
while (true)
 /* Line: 349 */ {
bevt_2_tmpany_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpany_phold = bevl_node.bemd_0(1878699153);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_has_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 350 */ {
return bevl_node;
} /* Line: 351 */
 else  /* Line: 352 */ {
bevl_node = bevl_node.bemd_0(1043829581);
if (bevl_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 354 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_19));
bevt_5_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 355 */
} /* Line: 354 */
} /* Line: 350 */
} /* Line: 349 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 364 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 364 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(1878699153);
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(650080222, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 364 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 364 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 364 */
 else  /* Line: 364 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 364 */ {
bevl_targ = bevl_targ.bemd_0(1043829581);
} /* Line: 365 */
 else  /* Line: 364 */ {
break;
} /* Line: 364 */
} /* Line: 364 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 372 */ {
if (bevl_targ == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_5_tmpany_phold = bevl_targ.bemd_0(1878699153);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(650080222, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 372 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevt_8_tmpany_phold = bevl_targ.bemd_0(1878699153);
bevt_9_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(650080222, bevt_9_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 372 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevt_11_tmpany_phold = bevl_targ.bemd_0(1878699153);
bevt_12_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(650080222, bevt_12_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevl_targ = bevl_targ.bemd_0(1043829581);
} /* Line: 373 */
 else  /* Line: 372 */ {
break;
} /* Line: 372 */
} /* Line: 372 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 379 */ {
return null;
} /* Line: 380 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(1901148596, beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 393 */ {
bevt_0_tmpany_phold = bevl_it.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_i = bevl_it.bemd_0(-1947306340);
bevl_i.bemd_1(1334503366, this);
} /* Line: 395 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 403 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 404 */
} /* Line: 403 */
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 407 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(112811732);
if (bevl_np == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 410 */
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(2011682755);
if (bevl_np == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 413 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 414 */
bevt_8_tmpany_phold = bevp_held.bemd_0(112811732);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-2069102102);
bevp_held.bemd_1(489040096, bevt_7_tmpany_phold);
} /* Line: 416 */
bevt_10_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 418 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(112811732);
if (bevl_np == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 420 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 421 */
} /* Line: 420 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_callIsSafe_1(BEC_2_5_4_BuildNode beva_call) throws Throwable {
BEC_2_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses = null;
BEC_2_9_3_ContainerSet bevl_okCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses2 = null;
BEC_2_9_3_ContainerSet bevl_okCalls2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
bevt_2_tmpany_phold = beva_call.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-66942538);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 431 */ {
bevt_6_tmpany_phold = beva_call.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1269772965);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-2069102102);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_20));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1602696702, bevt_7_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 431 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 431 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 431 */
 else  /* Line: 431 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 431 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 432 */
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_5 == null) {
bece_BEC_2_5_4_BuildNode_bevo_5 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bece_BEC_2_5_4_BuildNode_bevo_5;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_6 == null) {
bece_BEC_2_5_4_BuildNode_bevo_6 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bece_BEC_2_5_4_BuildNode_bevo_6;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_7 == null) {
bece_BEC_2_5_4_BuildNode_bevo_7 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bece_BEC_2_5_4_BuildNode_bevo_7;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_8 == null) {
bece_BEC_2_5_4_BuildNode_bevo_8 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bece_BEC_2_5_4_BuildNode_bevo_8;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bece_BEC_2_5_4_BuildNode_bevo_9 == null) {
bece_BEC_2_5_4_BuildNode_bevo_9 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bece_BEC_2_5_4_BuildNode_bevo_9;
bevt_10_tmpany_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_10;
if (bevt_10_tmpany_phold.bevi_int == bevt_11_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 440 */ {
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_4_BuildNode_bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpany_phold);
} /* Line: 490 */
bevt_48_tmpany_phold = beva_call.bem_heldGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(-1447107675);
bevt_46_tmpany_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpany_phold);
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 494 */ {
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_49_tmpany_phold;
} /* Line: 496 */
bevt_54_tmpany_phold = beva_call.bem_containedGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_firstGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(-1200745202);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(1046330604);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_0(964413679);
if (((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 500 */ {
bevt_55_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_55_tmpany_phold;
} /* Line: 502 */
bevt_61_tmpany_phold = beva_call.bem_containedGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-1200745202);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(112811732);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(-2069102102);
bevt_56_tmpany_phold = bevl_okClasses.bem_has_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 510 */ {
bevt_64_tmpany_phold = beva_call.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1447107675);
bevt_62_tmpany_phold = bevl_okCalls.bem_has_1(bevt_63_tmpany_phold);
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_65_tmpany_phold;
} /* Line: 513 */
 else  /* Line: 514 */ {
} /* Line: 514 */
} /* Line: 511 */
bevt_71_tmpany_phold = beva_call.bem_containedGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_firstGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_0(-1200745202);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(112811732);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(-2069102102);
bevt_66_tmpany_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_74_tmpany_phold = beva_call.bem_heldGet_0();
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(-1447107675);
bevt_72_tmpany_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpany_phold);
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 519 */ {
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_75_tmpany_phold;
} /* Line: 521 */
 else  /* Line: 522 */ {
} /* Line: 522 */
} /* Line: 519 */
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_76_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralOnceGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_BuildNode bevl_c0 = null;
BEC_2_5_4_BuildNode bevl_c1 = null;
BEC_2_5_4_BuildNode bevl_call = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevt_4_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevp_typename.bevi_int != bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 543 */
bevt_7_tmpany_phold = bevp_held.bemd_0(-1434588826);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_55));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(1602696702, bevt_8_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 544 */ {
bevl_c0 = (BEC_2_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_2_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 547 */ {
bevt_11_tmpany_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_11_tmpany_phold.bevi_int == bevt_12_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 547 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 547 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 547 */
 else  /* Line: 547 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 547 */ {
bevt_14_tmpany_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-457110241);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 548 */ {
bevt_17_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(-1024129935);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(964413679);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 548 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 548 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 548 */
 else  /* Line: 548 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 548 */ {
bevl_result = be.BECS_Runtime.boolTrue;
bevt_19_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(842239647);
bevt_0_tmpany_loop = bevt_18_tmpany_phold.bemd_0(-1232907801);
while (true)
 /* Line: 550 */ {
bevt_20_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 550 */ {
bevl_call = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(-1947306340);
bevt_21_tmpany_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 551 */ {
bevt_23_tmpany_phold = bem_callIsSafe_1(bevl_call);
if (bevt_23_tmpany_phold.bevi_bool) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 552 */ {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_24_tmpany_phold;
} /* Line: 553 */
} /* Line: 552 */
} /* Line: 551 */
 else  /* Line: 550 */ {
break;
} /* Line: 550 */
} /* Line: 550 */
} /* Line: 550 */
} /* Line: 548 */
} /* Line: 547 */
return bevl_result;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public final BEC_2_9_8_ContainerNodeList bem_containedGetDirect_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_heldGetDirect_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_heldByGetDirect_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heldBy = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_heldBySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heldBy = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() throws Throwable {
return bevp_condany;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_condanyGetDirect_0() throws Throwable {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_condany = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_condanySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_condany = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public final BEC_2_4_6_TextString bem_inFileGetDirect_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_typeDetailGetDirect_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeDetail = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_typeDetailSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeDetail = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_delayDeleteGetDirect_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_delayDeleteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nlcGetDirect_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_nlcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nlecGetDirect_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_nlecSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_wideStringGetDirect_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_wideStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildGetDirect_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public final BEC_2_4_3_MathInt bem_typenameGetDirect_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_typenameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_inlinedGetDirect_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inlinedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 37, 37, 38, 38, 39, 40, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 47, 48, 49, 49, 49, 49, 0, 0, 0, 50, 51, 53, 57, 58, 59, 59, 59, 59, 0, 0, 0, 60, 61, 63, 67, 67, 68, 70, 71, 71, 72, 74, 74, 78, 78, 79, 81, 82, 82, 83, 85, 85, 89, 89, 93, 93, 97, 97, 101, 101, 102, 102, 104, 104, 104, 108, 108, 0, 108, 108, 108, 0, 0, 109, 109, 111, 111, 111, 111, 115, 115, 0, 115, 115, 115, 0, 0, 0, 115, 115, 115, 115, 0, 0, 116, 116, 118, 118, 118, 118, 118, 122, 126, 126, 127, 129, 130, 131, 135, 135, 136, 138, 138, 138, 139, 143, 143, 144, 146, 147, 151, 151, 152, 154, 155, 159, 163, 163, 164, 171, 173, 174, 176, 180, 181, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 0, 0, 0, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 187, 187, 188, 188, 190, 194, 195, 195, 195, 195, 195, 195, 196, 196, 197, 197, 197, 197, 199, 199, 200, 200, 200, 200, 202, 202, 203, 203, 203, 203, 205, 209, 210, 211, 211, 212, 213, 215, 219, 220, 221, 222, 222, 222, 223, 222, 225, 229, 230, 230, 230, 230, 230, 0, 0, 0, 231, 233, 237, 238, 238, 238, 239, 239, 239, 241, 241, 241, 242, 242, 242, 243, 244, 244, 245, 245, 246, 247, 247, 247, 247, 248, 252, 253, 253, 254, 254, 254, 254, 255, 255, 257, 259, 259, 263, 264, 264, 265, 265, 266, 267, 267, 267, 268, 268, 268, 270, 270, 270, 0, 0, 0, 271, 272, 272, 274, 275, 275, 275, 276, 276, 276, 278, 278, 278, 279, 279, 284, 285, 285, 286, 286, 287, 288, 289, 289, 289, 290, 290, 290, 292, 292, 293, 293, 293, 294, 294, 294, 296, 296, 296, 297, 297, 298, 298, 298, 299, 299, 299, 308, 309, 309, 310, 310, 311, 311, 311, 313, 313, 314, 314, 315, 315, 315, 317, 318, 318, 318, 319, 319, 320, 320, 320, 322, 322, 323, 323, 323, 323, 326, 327, 328, 328, 329, 330, 330, 331, 331, 332, 332, 333, 333, 335, 335, 336, 336, 337, 338, 338, 339, 339, 347, 348, 350, 350, 350, 351, 353, 354, 354, 355, 355, 355, 363, 364, 364, 364, 364, 364, 0, 0, 0, 365, 367, 371, 372, 372, 372, 372, 372, 0, 0, 0, 372, 372, 372, 0, 0, 0, 372, 372, 372, 0, 0, 0, 373, 375, 379, 379, 380, 382, 383, 387, 388, 392, 393, 393, 394, 395, 401, 401, 401, 402, 403, 403, 404, 407, 407, 407, 408, 409, 409, 410, 412, 413, 413, 414, 416, 416, 416, 418, 418, 418, 419, 420, 420, 421, 431, 431, 431, 431, 431, 431, 431, 0, 0, 0, 432, 432, 435, 436, 437, 438, 439, 440, 440, 440, 440, 447, 447, 450, 450, 451, 451, 453, 453, 454, 454, 455, 455, 456, 456, 457, 457, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 473, 473, 474, 474, 475, 475, 476, 476, 477, 477, 481, 481, 482, 482, 483, 483, 484, 484, 489, 489, 490, 490, 494, 494, 494, 496, 496, 500, 500, 500, 500, 500, 502, 502, 510, 510, 510, 510, 510, 510, 511, 511, 511, 513, 513, 518, 518, 518, 518, 518, 518, 519, 519, 519, 521, 521, 527, 527, 538, 543, 543, 543, 543, 543, 544, 544, 544, 545, 546, 547, 547, 547, 547, 547, 547, 0, 0, 0, 548, 548, 548, 548, 548, 0, 0, 0, 549, 550, 550, 550, 0, 550, 550, 551, 552, 552, 552, 553, 553, 564, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {96, 97, 98, 99, 100, 101, 102, 103, 104, 110, 111, 112, 113, 114, 115, 129, 134, 135, 136, 141, 142, 145, 149, 152, 153, 155, 156, 159, 164, 165, 170, 171, 174, 178, 181, 182, 188, 196, 197, 200, 205, 206, 211, 212, 215, 219, 222, 223, 229, 236, 241, 242, 244, 245, 250, 251, 253, 254, 261, 266, 267, 269, 270, 275, 276, 278, 279, 283, 284, 288, 289, 293, 294, 301, 306, 307, 308, 310, 311, 316, 327, 332, 333, 336, 337, 342, 343, 346, 350, 351, 353, 354, 355, 360, 376, 381, 382, 385, 386, 391, 392, 395, 399, 402, 403, 404, 409, 410, 413, 417, 418, 420, 421, 422, 423, 428, 431, 436, 441, 442, 444, 445, 446, 453, 458, 459, 461, 462, 463, 464, 469, 474, 475, 477, 478, 483, 488, 489, 491, 492, 496, 501, 506, 507, 515, 519, 520, 522, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 582, 583, 588, 589, 592, 596, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 614, 619, 620, 621, 622, 623, 624, 625, 626, 627, 629, 651, 652, 653, 654, 655, 656, 657, 658, 663, 664, 665, 666, 667, 669, 674, 675, 676, 677, 678, 680, 685, 686, 687, 688, 689, 691, 697, 698, 701, 706, 707, 708, 714, 722, 723, 724, 725, 728, 733, 734, 735, 741, 750, 753, 758, 759, 760, 761, 763, 766, 770, 773, 779, 799, 800, 801, 802, 804, 805, 806, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 834, 837, 842, 843, 844, 845, 850, 851, 852, 854, 860, 861, 888, 889, 890, 892, 893, 894, 895, 896, 897, 899, 900, 901, 903, 905, 906, 908, 911, 915, 918, 919, 920, 922, 923, 924, 925, 927, 928, 929, 931, 932, 933, 934, 935, 966, 967, 968, 970, 971, 972, 973, 974, 975, 976, 978, 979, 980, 983, 984, 985, 986, 987, 989, 990, 991, 994, 995, 996, 997, 998, 999, 1000, 1001, 1003, 1004, 1005, 1048, 1049, 1050, 1051, 1052, 1054, 1055, 1056, 1059, 1060, 1061, 1062, 1064, 1065, 1066, 1069, 1070, 1071, 1072, 1073, 1078, 1079, 1080, 1081, 1083, 1088, 1089, 1090, 1091, 1092, 1095, 1096, 1097, 1098, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1111, 1112, 1113, 1114, 1115, 1116, 1117, 1118, 1119, 1135, 1136, 1140, 1141, 1142, 1144, 1147, 1148, 1153, 1154, 1155, 1156, 1170, 1173, 1178, 1179, 1180, 1181, 1183, 1186, 1190, 1193, 1199, 1216, 1219, 1224, 1225, 1226, 1227, 1229, 1232, 1236, 1239, 1240, 1241, 1243, 1246, 1250, 1253, 1254, 1255, 1257, 1260, 1264, 1267, 1273, 1277, 1282, 1283, 1285, 1286, 1290, 1291, 1298, 1299, 1302, 1304, 1305, 1327, 1328, 1333, 1334, 1335, 1340, 1341, 1344, 1345, 1350, 1351, 1352, 1357, 1358, 1360, 1361, 1366, 1367, 1369, 1370, 1371, 1373, 1374, 1379, 1380, 1381, 1386, 1387, 1475, 1476, 1478, 1479, 1480, 1481, 1482, 1484, 1487, 1491, 1494, 1495, 1497, 1503, 1509, 1515, 1521, 1527, 1528, 1529, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1602, 1604, 1605, 1606, 1608, 1609, 1611, 1612, 1613, 1614, 1615, 1617, 1618, 1620, 1621, 1622, 1623, 1624, 1625, 1627, 1628, 1629, 1631, 1632, 1637, 1638, 1639, 1640, 1641, 1642, 1644, 1645, 1646, 1648, 1649, 1654, 1655, 1687, 1688, 1689, 1694, 1695, 1696, 1698, 1699, 1700, 1702, 1703, 1704, 1709, 1710, 1711, 1712, 1717, 1718, 1721, 1725, 1728, 1729, 1731, 1732, 1733, 1735, 1738, 1742, 1745, 1746, 1747, 1748, 1748, 1751, 1753, 1754, 1756, 1757, 1762, 1763, 1764, 1775, 1778, 1781, 1784, 1788, 1792, 1795, 1798, 1802, 1806, 1809, 1812, 1816, 1820, 1823, 1826, 1830, 1834, 1837, 1840, 1844, 1848, 1851, 1854, 1858, 1862, 1865, 1868, 1872, 1876, 1879, 1882, 1886, 1890, 1893, 1896, 1900, 1904, 1907, 1910, 1914, 1918, 1921, 1924, 1928, 1932, 1935, 1938, 1942, 1946, 1949, 1952, 1956, 1960, 1963, 1966, 1970, 1974, 1977, 1980, 1984, 1988, 1991, 1994, 1998, 2002, 2005, 2008, 2012};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 96
new 0 23 96
assign 1 24 97
new 0 24 97
assign 1 25 98
new 0 25 98
assign 1 26 99
new 0 26 99
assign 1 28 100
assign 1 29 101
constantsGet 0 29 101
assign 1 30 102
ntypesGet 0 30 102
assign 1 31 103
TOKENGet 0 31 103
assign 1 32 104
new 0 32 104
assign 1 37 110
nlcGet 0 37 110
assign 1 37 111
copy 0 37 111
assign 1 38 112
nlecGet 0 38 112
assign 1 38 113
copy 0 38 113
assign 1 39 114
inClassNpGet 0 39 114
assign 1 40 115
inFileGet 0 40 115
assign 1 44 129
def 1 44 134
assign 1 44 135
firstGet 0 44 135
assign 1 44 136
def 1 44 141
assign 1 0 142
assign 1 0 145
assign 1 0 149
assign 1 45 152
firstGet 0 45 152
return 1 45 153
assign 1 47 155
nextPeerGet 0 47 155
assign 1 48 156
assign 1 49 159
undef 1 49 164
assign 1 49 165
def 1 49 170
assign 1 0 171
assign 1 0 174
assign 1 0 178
assign 1 50 181
nextPeerGet 0 50 181
assign 1 51 182
containerGet 0 51 182
return 1 53 188
assign 1 57 196
nextPeerGet 0 57 196
assign 1 58 197
assign 1 59 200
undef 1 59 205
assign 1 59 206
def 1 59 211
assign 1 0 212
assign 1 0 215
assign 1 0 219
assign 1 60 222
nextPeerGet 0 60 222
assign 1 61 223
containerGet 0 61 223
return 1 63 229
assign 1 67 236
undef 1 67 241
return 1 68 242
assign 1 70 244
nextGet 0 70 244
assign 1 71 245
undef 1 71 250
return 1 72 251
assign 1 74 253
heldGet 0 74 253
return 1 74 254
assign 1 78 261
undef 1 78 266
return 1 79 267
assign 1 81 269
priorGet 0 81 269
assign 1 82 270
undef 1 82 275
return 1 83 276
assign 1 85 278
heldGet 0 85 278
return 1 85 279
assign 1 89 283
firstGet 0 89 283
return 1 89 284
assign 1 93 288
secondGet 0 93 288
return 1 93 289
assign 1 97 293
thirdGet 0 97 293
return 1 97 294
assign 1 101 301
undef 1 101 306
assign 1 102 307
new 0 102 307
return 1 102 308
assign 1 104 310
priorGet 0 104 310
assign 1 104 311
undef 1 104 316
return 1 104 316
assign 1 108 327
undef 1 108 332
assign 1 0 333
assign 1 108 336
priorGet 0 108 336
assign 1 108 337
undef 1 108 342
assign 1 0 343
assign 1 0 346
assign 1 109 350
new 0 109 350
return 1 109 351
assign 1 111 353
priorGet 0 111 353
assign 1 111 354
priorGet 0 111 354
assign 1 111 355
undef 1 111 360
return 1 111 360
assign 1 115 376
undef 1 115 381
assign 1 0 382
assign 1 115 385
priorGet 0 115 385
assign 1 115 386
undef 1 115 391
assign 1 0 392
assign 1 0 395
assign 1 0 399
assign 1 115 402
priorGet 0 115 402
assign 1 115 403
priorGet 0 115 403
assign 1 115 404
undef 1 115 409
assign 1 0 410
assign 1 0 413
assign 1 116 417
new 0 116 417
return 1 116 418
assign 1 118 420
priorGet 0 118 420
assign 1 118 421
priorGet 0 118 421
assign 1 118 422
priorGet 0 118 422
assign 1 118 423
undef 1 118 428
return 1 118 428
assign 1 122 431
new 0 122 431
assign 1 126 436
undef 1 126 441
return 1 127 442
delete 0 129 444
assign 1 130 445
assign 1 131 446
assign 1 135 453
undef 1 135 458
return 1 136 459
assign 1 138 461
mylistGet 0 138 461
assign 1 138 462
newNode 1 138 462
insertBefore 1 138 463
containerSet 1 139 464
assign 1 143 469
undef 1 143 474
initContained 0 144 475
prepend 1 146 477
containerSet 1 147 478
assign 1 151 483
undef 1 151 488
initContained 0 152 489
addValue 1 154 491
containerSet 1 155 492
assign 1 159 496
new 0 159 496
assign 1 163 501
undef 1 163 506
assign 1 164 507
new 0 164 507
assign 1 171 515
toStringCompact 0 171 515
print 0 173 519
throw 1 174 520
return 1 176 522
assign 1 180 562
prefixGet 0 180 562
assign 1 181 563
new 0 181 563
assign 1 181 564
add 1 181 564
assign 1 181 565
toString 0 181 565
assign 1 181 566
add 1 181 566
assign 1 181 567
new 0 181 567
assign 1 181 568
add 1 181 568
assign 1 182 569
new 0 182 569
assign 1 182 570
newlineGet 0 182 570
assign 1 182 571
add 1 182 571
assign 1 182 572
add 1 182 572
assign 1 182 573
new 0 182 573
assign 1 182 574
add 1 182 574
assign 1 182 575
toString 0 182 575
assign 1 182 576
add 1 182 576
assign 1 183 577
def 1 183 582
assign 1 183 583
def 1 183 588
assign 1 0 589
assign 1 0 592
assign 1 0 596
assign 1 184 599
new 0 184 599
assign 1 184 600
newlineGet 0 184 600
assign 1 184 601
add 1 184 601
assign 1 184 602
add 1 184 602
assign 1 184 603
new 0 184 603
assign 1 184 604
add 1 184 604
assign 1 184 605
toString 0 184 605
assign 1 184 606
add 1 184 606
assign 1 184 607
new 0 184 607
assign 1 184 608
add 1 184 608
assign 1 184 609
add 1 184 609
assign 1 184 610
new 0 184 610
assign 1 184 611
newlineGet 0 184 611
assign 1 184 612
add 1 184 612
assign 1 186 614
def 1 186 619
assign 1 187 620
new 0 187 620
assign 1 187 621
newlineGet 0 187 621
assign 1 187 622
add 1 187 622
assign 1 187 623
add 1 187 623
assign 1 187 624
new 0 187 624
assign 1 187 625
add 1 187 625
assign 1 188 626
toString 0 188 626
assign 1 188 627
add 1 188 627
return 1 190 629
assign 1 194 651
prefixGet 0 194 651
assign 1 195 652
new 0 195 652
assign 1 195 653
add 1 195 653
assign 1 195 654
toString 0 195 654
assign 1 195 655
add 1 195 655
assign 1 195 656
new 0 195 656
assign 1 195 657
add 1 195 657
assign 1 196 658
def 1 196 663
assign 1 197 664
new 0 197 664
assign 1 197 665
add 1 197 665
assign 1 197 666
toString 0 197 666
assign 1 197 667
add 1 197 667
assign 1 199 669
def 1 199 674
assign 1 200 675
new 0 200 675
assign 1 200 676
add 1 200 676
assign 1 200 677
toString 0 200 677
assign 1 200 678
add 1 200 678
assign 1 202 680
def 1 202 685
assign 1 203 686
new 0 203 686
assign 1 203 687
add 1 203 687
assign 1 203 688
toString 0 203 688
assign 1 203 689
add 1 203 689
return 1 205 691
assign 1 209 697
new 0 209 697
assign 1 210 698
assign 1 211 701
def 1 211 706
incrementValue 0 212 707
assign 1 213 708
containerGet 0 213 708
return 1 215 714
assign 1 219 722
depthGet 0 219 722
assign 1 220 723
new 0 220 723
assign 1 221 724
new 0 221 724
assign 1 222 725
new 0 222 725
assign 1 222 728
lesser 1 222 733
assign 1 223 734
add 1 223 734
incrementValue 0 222 735
return 1 225 741
assign 1 229 750
assign 1 230 753
def 1 230 758
assign 1 230 759
typenameGet 0 230 759
assign 1 230 760
TRANSUNITGet 0 230 760
assign 1 230 761
notEquals 1 230 761
assign 1 0 763
assign 1 0 766
assign 1 0 770
assign 1 231 773
containerGet 0 231 773
return 1 233 779
assign 1 237 799
scopeGet 0 237 799
assign 1 238 800
typenameGet 0 238 800
assign 1 238 801
METHODGet 0 238 801
assign 1 238 802
notEquals 1 238 802
assign 1 239 804
new 0 239 804
assign 1 239 805
new 2 239 805
throw 1 239 806
assign 1 241 808
heldGet 0 241 808
assign 1 241 809
tmpCntGet 0 241 809
assign 1 241 810
toString 0 241 810
assign 1 242 811
heldGet 0 242 811
assign 1 242 812
tmpCntGet 0 242 812
incrementValue 0 242 813
assign 1 243 814
new 0 243 814
assign 1 244 815
new 0 244 815
isTmpVarSet 1 244 816
assign 1 245 817
new 0 245 817
autoTypeSet 1 245 818
suffixSet 1 246 819
assign 1 247 820
new 0 247 820
assign 1 247 821
add 1 247 821
assign 1 247 822
add 1 247 822
nameSet 1 247 823
return 1 248 824
assign 1 252 834
assign 1 253 837
def 1 253 842
assign 1 254 843
typenameGet 0 254 843
assign 1 254 844
PROPERTIESGet 0 254 844
assign 1 254 845
equals 1 254 850
assign 1 255 851
new 0 255 851
return 1 255 852
assign 1 257 854
containerGet 0 257 854
assign 1 259 860
new 0 259 860
return 1 259 861
assign 1 263 888
assign 1 264 889
isAddedGet 0 264 889
assign 1 264 890
not 0 264 890
assign 1 265 892
new 0 265 892
isAddedSet 1 265 893
assign 1 266 894
scopeGet 0 266 894
assign 1 267 895
typenameGet 0 267 895
assign 1 267 896
CLASSGet 0 267 896
assign 1 267 897
equals 1 267 897
assign 1 268 899
new 0 268 899
assign 1 268 900
new 2 268 900
throw 1 268 901
assign 1 270 903
inPropertiesGet 0 270 903
assign 1 270 905
isTmpVarGet 0 270 905
assign 1 270 906
not 0 270 906
assign 1 0 908
assign 1 0 911
assign 1 0 915
assign 1 271 918
classGet 0 271 918
assign 1 272 919
new 0 272 919
isPropertySet 1 272 920
assign 1 274 922
heldGet 0 274 922
assign 1 275 923
anyMapGet 0 275 923
assign 1 275 924
nameGet 0 275 924
assign 1 275 925
has 1 275 925
assign 1 276 927
new 0 276 927
assign 1 276 928
new 2 276 928
throw 1 276 929
assign 1 278 931
anyMapGet 0 278 931
assign 1 278 932
nameGet 0 278 932
put 2 278 933
assign 1 279 934
orderedVarsGet 0 279 934
addValue 1 279 935
assign 1 284 966
assign 1 285 967
isAddedGet 0 285 967
assign 1 285 968
not 0 285 968
assign 1 286 970
new 0 286 970
isAddedSet 1 286 971
assign 1 287 972
scopeGet 0 287 972
assign 1 288 973
heldGet 0 288 973
assign 1 289 974
anyMapGet 0 289 974
assign 1 289 975
nameGet 0 289 975
assign 1 289 976
has 1 289 976
assign 1 290 978
anyMapGet 0 290 978
assign 1 290 979
nameGet 0 290 979
assign 1 290 980
get 1 290 980
assign 1 292 983
classGet 0 292 983
assign 1 292 984
heldGet 0 292 984
assign 1 293 985
anyMapGet 0 293 985
assign 1 293 986
nameGet 0 293 986
assign 1 293 987
has 1 293 987
assign 1 294 989
anyMapGet 0 294 989
assign 1 294 990
nameGet 0 294 990
assign 1 294 991
get 1 294 991
assign 1 296 994
anyMapGet 0 296 994
assign 1 296 995
nameGet 0 296 995
put 2 296 996
assign 1 297 997
orderedVarsGet 0 297 997
addValue 1 297 998
assign 1 298 999
typenameGet 0 298 999
assign 1 298 1000
CLASSGet 0 298 1000
assign 1 298 1001
equals 1 298 1001
assign 1 299 1003
new 0 299 1003
assign 1 299 1004
new 2 299 1004
throw 1 299 1005
assign 1 308 1048
assign 1 309 1049
scopeGet 0 309 1049
assign 1 309 1050
heldGet 0 309 1050
assign 1 310 1051
anyMapGet 0 310 1051
assign 1 310 1052
has 1 310 1052
assign 1 311 1054
anyMapGet 0 311 1054
assign 1 311 1055
get 1 311 1055
assign 1 311 1056
heldGet 0 311 1056
assign 1 313 1059
classGet 0 313 1059
assign 1 313 1060
heldGet 0 313 1060
assign 1 314 1061
anyMapGet 0 314 1061
assign 1 314 1062
has 1 314 1062
assign 1 315 1064
anyMapGet 0 315 1064
assign 1 315 1065
get 1 315 1065
assign 1 315 1066
heldGet 0 315 1066
assign 1 317 1069
transUnitGet 0 317 1069
assign 1 318 1070
heldGet 0 318 1070
assign 1 318 1071
aliasedGet 0 318 1071
assign 1 318 1072
get 1 318 1072
assign 1 319 1073
undef 1 319 1078
assign 1 320 1079
emitDataGet 0 320 1079
assign 1 320 1080
aliasedGet 0 320 1080
assign 1 320 1081
get 1 320 1081
assign 1 322 1083
def 1 322 1088
assign 1 323 1089
new 0 323 1089
assign 1 323 1090
add 1 323 1090
assign 1 323 1091
new 2 323 1091
throw 1 323 1092
assign 1 326 1095
new 0 326 1095
nameSet 1 327 1096
assign 1 328 1097
new 0 328 1097
assign 1 328 1098
equals 1 328 1098
assign 1 329 1100
assign 1 330 1101
new 0 330 1101
isTypedSet 1 330 1102
assign 1 331 1103
extendsGet 0 331 1103
namepathSet 1 331 1104
assign 1 332 1105
anyMapGet 0 332 1105
put 2 332 1106
assign 1 333 1107
orderedVarsGet 0 333 1107
addValue 1 333 1108
assign 1 335 1111
new 0 335 1111
isDeclaredSet 1 335 1112
assign 1 336 1113
new 0 336 1113
isPropertySet 1 336 1114
assign 1 337 1115
assign 1 338 1116
anyMapGet 0 338 1116
put 2 338 1117
assign 1 339 1118
orderedVarsGet 0 339 1118
addValue 1 339 1119
assign 1 347 1135
assign 1 348 1136
new 0 348 1136
assign 1 350 1140
anchorTypesGet 0 350 1140
assign 1 350 1141
typenameGet 0 350 1141
assign 1 350 1142
has 1 350 1142
return 1 351 1144
assign 1 353 1147
containerGet 0 353 1147
assign 1 354 1148
undef 1 354 1153
assign 1 355 1154
new 0 355 1154
assign 1 355 1155
new 2 355 1155
throw 1 355 1156
assign 1 363 1170
assign 1 364 1173
def 1 364 1178
assign 1 364 1179
typenameGet 0 364 1179
assign 1 364 1180
CLASSGet 0 364 1180
assign 1 364 1181
notEquals 1 364 1181
assign 1 0 1183
assign 1 0 1186
assign 1 0 1190
assign 1 365 1193
containerGet 0 365 1193
return 1 367 1199
assign 1 371 1216
assign 1 372 1219
def 1 372 1224
assign 1 372 1225
typenameGet 0 372 1225
assign 1 372 1226
CLASSGet 0 372 1226
assign 1 372 1227
notEquals 1 372 1227
assign 1 0 1229
assign 1 0 1232
assign 1 0 1236
assign 1 372 1239
typenameGet 0 372 1239
assign 1 372 1240
METHODGet 0 372 1240
assign 1 372 1241
notEquals 1 372 1241
assign 1 0 1243
assign 1 0 1246
assign 1 0 1250
assign 1 372 1253
typenameGet 0 372 1253
assign 1 372 1254
TRANSUNITGet 0 372 1254
assign 1 372 1255
notEquals 1 372 1255
assign 1 0 1257
assign 1 0 1260
assign 1 0 1264
assign 1 373 1267
containerGet 0 373 1267
return 1 375 1273
assign 1 379 1277
undef 1 379 1282
return 1 380 1283
containerSet 1 382 1285
heldSet 1 383 1286
delete 0 387 1290
addValue 1 388 1291
assign 1 392 1298
containedGet 0 392 1298
assign 1 393 1299
iteratorGet 0 393 1299
assign 1 393 1302
hasNextGet 0 393 1302
assign 1 394 1304
nextGet 0 394 1304
containerSet 1 395 1305
assign 1 401 1327
NAMEPATHGet 0 401 1327
assign 1 401 1328
equals 1 401 1333
assign 1 402 1334
assign 1 403 1335
def 1 403 1340
resolve 1 404 1341
assign 1 407 1344
CLASSGet 0 407 1344
assign 1 407 1345
equals 1 407 1350
assign 1 408 1351
namepathGet 0 408 1351
assign 1 409 1352
def 1 409 1357
resolve 1 410 1358
assign 1 412 1360
extendsGet 0 412 1360
assign 1 413 1361
def 1 413 1366
resolve 1 414 1367
assign 1 416 1369
namepathGet 0 416 1369
assign 1 416 1370
toString 0 416 1370
nameSet 1 416 1371
assign 1 418 1373
VARGet 0 418 1373
assign 1 418 1374
equals 1 418 1379
assign 1 419 1380
namepathGet 0 419 1380
assign 1 420 1381
def 1 420 1386
resolve 1 421 1387
assign 1 431 1475
heldGet 0 431 1475
assign 1 431 1476
isConstructGet 0 431 1476
assign 1 431 1478
heldGet 0 431 1478
assign 1 431 1479
newNpGet 0 431 1479
assign 1 431 1480
toString 0 431 1480
assign 1 431 1481
new 0 431 1481
assign 1 431 1482
equals 1 431 1482
assign 1 0 1484
assign 1 0 1487
assign 1 0 1491
assign 1 432 1494
new 0 432 1494
return 1 432 1495
assign 1 435 1497
new 0 435 1497
assign 1 436 1503
new 0 436 1503
assign 1 437 1509
new 0 437 1509
assign 1 438 1515
new 0 438 1515
assign 1 439 1521
new 0 439 1521
assign 1 440 1527
sizeGet 0 440 1527
assign 1 440 1528
new 0 440 1528
assign 1 440 1529
equals 1 440 1534
assign 1 447 1535
new 0 447 1535
put 1 447 1536
assign 1 450 1537
new 0 450 1537
put 1 450 1538
assign 1 451 1539
new 0 451 1539
put 1 451 1540
assign 1 453 1541
new 0 453 1541
put 1 453 1542
assign 1 454 1543
new 0 454 1543
put 1 454 1544
assign 1 455 1545
new 0 455 1545
put 1 455 1546
assign 1 456 1547
new 0 456 1547
put 1 456 1548
assign 1 457 1549
new 0 457 1549
put 1 457 1550
assign 1 458 1551
new 0 458 1551
put 1 458 1552
assign 1 459 1553
new 0 459 1553
put 1 459 1554
assign 1 460 1555
new 0 460 1555
put 1 460 1556
assign 1 461 1557
new 0 461 1557
put 1 461 1558
assign 1 462 1559
new 0 462 1559
put 1 462 1560
assign 1 463 1561
new 0 463 1561
put 1 463 1562
assign 1 464 1563
new 0 464 1563
put 1 464 1564
assign 1 465 1565
new 0 465 1565
put 1 465 1566
assign 1 466 1567
new 0 466 1567
put 1 466 1568
assign 1 467 1569
new 0 467 1569
put 1 467 1570
assign 1 468 1571
new 0 468 1571
put 1 468 1572
assign 1 469 1573
new 0 469 1573
put 1 469 1574
assign 1 470 1575
new 0 470 1575
put 1 470 1576
assign 1 471 1577
new 0 471 1577
put 1 471 1578
assign 1 472 1579
new 0 472 1579
put 1 472 1580
assign 1 473 1581
new 0 473 1581
put 1 473 1582
assign 1 474 1583
new 0 474 1583
put 1 474 1584
assign 1 475 1585
new 0 475 1585
put 1 475 1586
assign 1 476 1587
new 0 476 1587
put 1 476 1588
assign 1 477 1589
new 0 477 1589
put 1 477 1590
assign 1 481 1591
new 0 481 1591
put 1 481 1592
assign 1 482 1593
new 0 482 1593
put 1 482 1594
assign 1 483 1595
new 0 483 1595
put 1 483 1596
assign 1 484 1597
new 0 484 1597
put 1 484 1598
assign 1 489 1599
new 0 489 1599
put 1 489 1600
assign 1 490 1601
new 0 490 1601
put 1 490 1602
assign 1 494 1604
heldGet 0 494 1604
assign 1 494 1605
nameGet 0 494 1605
assign 1 494 1606
has 1 494 1606
assign 1 496 1608
new 0 496 1608
return 1 496 1609
assign 1 500 1611
containedGet 0 500 1611
assign 1 500 1612
firstGet 0 500 1612
assign 1 500 1613
heldGet 0 500 1613
assign 1 500 1614
isTypedGet 0 500 1614
assign 1 500 1615
not 0 500 1615
assign 1 502 1617
new 0 502 1617
return 1 502 1618
assign 1 510 1620
containedGet 0 510 1620
assign 1 510 1621
firstGet 0 510 1621
assign 1 510 1622
heldGet 0 510 1622
assign 1 510 1623
namepathGet 0 510 1623
assign 1 510 1624
toString 0 510 1624
assign 1 510 1625
has 1 510 1625
assign 1 511 1627
heldGet 0 511 1627
assign 1 511 1628
nameGet 0 511 1628
assign 1 511 1629
has 1 511 1629
assign 1 513 1631
new 0 513 1631
return 1 513 1632
assign 1 518 1637
containedGet 0 518 1637
assign 1 518 1638
firstGet 0 518 1638
assign 1 518 1639
heldGet 0 518 1639
assign 1 518 1640
namepathGet 0 518 1640
assign 1 518 1641
toString 0 518 1641
assign 1 518 1642
has 1 518 1642
assign 1 519 1644
heldGet 0 519 1644
assign 1 519 1645
nameGet 0 519 1645
assign 1 519 1646
has 1 519 1646
assign 1 521 1648
new 0 521 1648
return 1 521 1649
assign 1 527 1654
new 0 527 1654
return 1 527 1655
assign 1 538 1687
new 0 538 1687
assign 1 543 1688
CALLGet 0 543 1688
assign 1 543 1689
notEquals 1 543 1694
assign 1 543 1695
new 0 543 1695
return 1 543 1696
assign 1 544 1698
orgNameGet 0 544 1698
assign 1 544 1699
new 0 544 1699
assign 1 544 1700
equals 1 544 1700
assign 1 545 1702
firstGet 0 545 1702
assign 1 546 1703
secondGet 0 546 1703
assign 1 547 1704
def 1 547 1709
assign 1 547 1710
typenameGet 0 547 1710
assign 1 547 1711
CALLGet 0 547 1711
assign 1 547 1712
equals 1 547 1717
assign 1 0 1718
assign 1 0 1721
assign 1 0 1725
assign 1 548 1728
heldGet 0 548 1728
assign 1 548 1729
isLiteralGet 0 548 1729
assign 1 548 1731
heldGet 0 548 1731
assign 1 548 1732
isPropertyGet 0 548 1732
assign 1 548 1733
not 0 548 1733
assign 1 0 1735
assign 1 0 1738
assign 1 0 1742
assign 1 549 1745
new 0 549 1745
assign 1 550 1746
heldGet 0 550 1746
assign 1 550 1747
allCallsGet 0 550 1747
assign 1 550 1748
iteratorGet 0 0 1748
assign 1 550 1751
hasNextGet 0 550 1751
assign 1 550 1753
nextGet 0 550 1753
assign 1 551 1754
notEquals 1 551 1754
assign 1 552 1756
callIsSafe 1 552 1756
assign 1 552 1757
not 0 552 1762
assign 1 553 1763
new 0 553 1763
return 1 553 1764
return 1 564 1775
return 1 0 1778
return 1 0 1781
assign 1 0 1784
assign 1 0 1788
return 1 0 1792
return 1 0 1795
assign 1 0 1798
assign 1 0 1802
return 1 0 1806
return 1 0 1809
assign 1 0 1812
assign 1 0 1816
return 1 0 1820
return 1 0 1823
assign 1 0 1826
assign 1 0 1830
return 1 0 1834
return 1 0 1837
assign 1 0 1840
assign 1 0 1844
return 1 0 1848
return 1 0 1851
assign 1 0 1854
assign 1 0 1858
return 1 0 1862
return 1 0 1865
assign 1 0 1868
assign 1 0 1872
return 1 0 1876
return 1 0 1879
assign 1 0 1882
assign 1 0 1886
return 1 0 1890
return 1 0 1893
assign 1 0 1896
assign 1 0 1900
return 1 0 1904
return 1 0 1907
assign 1 0 1910
assign 1 0 1914
return 1 0 1918
return 1 0 1921
assign 1 0 1924
assign 1 0 1928
return 1 0 1932
return 1 0 1935
assign 1 0 1938
assign 1 0 1942
return 1 0 1946
return 1 0 1949
assign 1 0 1952
assign 1 0 1956
return 1 0 1960
return 1 0 1963
assign 1 0 1966
assign 1 0 1970
return 1 0 1974
return 1 0 1977
assign 1 0 1980
assign 1 0 1984
return 1 0 1988
return 1 0 1991
assign 1 0 1994
assign 1 0 1998
return 1 0 2002
return 1 0 2005
assign 1 0 2008
assign 1 0 2012
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 924190926: return bem_containerGetDirect_0();
case 123215117: return bem_isFirstGet_0();
case 2117639469: return bem_echo_0();
case -1167192385: return bem_inClassNpGet_0();
case 1043829581: return bem_containerGet_0();
case 944233434: return bem_constantsGet_0();
case -116496094: return bem_isThirdGet_0();
case -833803632: return bem_containedGetDirect_0();
case -1055677288: return bem_fieldIteratorGet_0();
case 156504792: return bem_nextDescendGet_0();
case 820384065: return bem_heldByGetDirect_0();
case -1055849953: return bem_nlecGetDirect_0();
case 1835292164: return bem_classGet_0();
case -1301687703: return bem_anchorGet_0();
case -1997816109: return bem_syncAddVariable_0();
case 127395247: return bem_transUnitGet_0();
case -1691017758: return bem_scopeGet_0();
case 1215735159: return bem_classNameGet_0();
case -653192157: return bem_delayDeleteGetDirect_0();
case -2069102102: return bem_toString_0();
case -1561145816: return bem_hashGet_0();
case -2126459888: return bem_nextPeerGet_0();
case -481792371: return bem_delayDelete_0();
case 1644000934: return bem_copy_0();
case -134231219: return bem_inClassNpGetDirect_0();
case -1671300531: return bem_nlcGet_0();
case -785645664: return bem_condanyGet_0();
case -1428198119: return bem_resolveNp_0();
case 982029777: return bem_addVariable_0();
case -1200745202: return bem_heldGet_0();
case -1953085318: return bem_thirdGet_0();
case 1029860087: return bem_fieldNamesGet_0();
case 55315205: return bem_many_0();
case -284999675: return bem_toAny_0();
case -2110866714: return bem_nlecGet_0();
case 1636272941: return bem_isLiteralOnceGet_0();
case -724111512: return bem_depthGet_0();
case -365679348: return bem_heldGetDirect_0();
case -1619326576: return bem_reInitContained_0();
case 545941176: return bem_toStringCompact_0();
case -401514376: return bem_initContained_0();
case -1098348762: return bem_ntypesGetDirect_0();
case -514438515: return bem_buildGetDirect_0();
case -1677419910: return bem_create_0();
case 57159682: return bem_new_0();
case -1052235287: return bem_nextAscendGet_0();
case 1705364850: return bem_priorPeerGet_0();
case 1878699153: return bem_typenameGet_0();
case 124461672: return bem_heldByGet_0();
case -1620615817: return bem_isSecondGet_0();
case 271183748: return bem_typeDetailGetDirect_0();
case -363953501: return bem_inlinedGet_0();
case 1129503343: return bem_once_0();
case -811468541: return bem_delayDeleteGet_0();
case 602097122: return bem_deserializeClassNameGet_0();
case 712789805: return bem_secondGet_0();
case -966696442: return bem_buildGet_0();
case -1499145551: return bem_firstGet_0();
case 1703226864: return bem_ntypesGet_0();
case -1904322577: return bem_inPropertiesGet_0();
case -1232907801: return bem_iteratorGet_0();
case 321704245: return bem_print_0();
case -429437759: return bem_sourceFileNameGet_0();
case -1296101467: return bem_constantsGetDirect_0();
case 1921783745: return bem_inFileGetDirect_0();
case -956590613: return bem_inlinedGetDirect_0();
case -1437550559: return bem_serializeContents_0();
case 900626196: return bem_typenameGetDirect_0();
case 738461469: return bem_toStringBig_0();
case 890797049: return bem_wideStringGet_0();
case 1649954317: return bem_serializeToString_0();
case -1605431584: return bem_tagGet_0();
case 1529738880: return bem_prefixGet_0();
case 1707915452: return bem_condanyGetDirect_0();
case 532971458: return bem_wideStringGetDirect_0();
case 918816723: return bem_containedGet_0();
case -1252208724: return bem_nlcGetDirect_0();
case 422356544: return bem_delete_0();
case -1596338036: return bem_inFileGet_0();
case 444831026: return bem_serializationIteratorGet_0();
case -260942951: return bem_typeDetailGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1034838950: return bem_constantsSetDirect_1(bevd_0);
case 427349405: return bem_nlecSet_1(bevd_0);
case -2064623047: return bem_typenameSetDirect_1(bevd_0);
case -756536057: return bem_otherClass_1(bevd_0);
case -740299402: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1178095818: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1334503366: return bem_containerSet_1(bevd_0);
case 1443301838: return bem_buildSet_1(bevd_0);
case -1453658938: return bem_inFileSet_1(bevd_0);
case 1143741090: return bem_heldBySetDirect_1(bevd_0);
case -1622114690: return bem_nlcSetDirect_1(bevd_0);
case -97426471: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1719096215: return bem_defined_1(bevd_0);
case -1171471101: return bem_heldSetDirect_1(bevd_0);
case 1071473583: return bem_inClassNpSet_1(bevd_0);
case -1371671937: return bem_undefined_1(bevd_0);
case 1406355920: return bem_inlinedSetDirect_1(bevd_0);
case 2027324655: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case 1521573585: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 843381471: return bem_ntypesSet_1(bevd_0);
case 746293967: return bem_delayDeleteSetDirect_1(bevd_0);
case 558514844: return bem_heldBySet_1(bevd_0);
case -1656006265: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1602696702: return bem_equals_1(bevd_0);
case -590532912: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -85025167: return bem_wideStringSet_1(bevd_0);
case 1901148596: return bem_heldSet_1(bevd_0);
case 1178220548: return bem_sameType_1(bevd_0);
case 650080222: return bem_notEquals_1(bevd_0);
case 893770658: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case -1192863303: return bem_typeDetailSet_1(bevd_0);
case 224102430: return bem_ntypesSetDirect_1(bevd_0);
case -2097661228: return bem_buildSetDirect_1(bevd_0);
case -2129394226: return bem_callIsSafe_1((BEC_2_5_4_BuildNode) bevd_0);
case -1236154696: return bem_delayDeleteSet_1(bevd_0);
case 378438327: return bem_condanySetDirect_1(bevd_0);
case 2047289151: return bem_typeDetailSetDirect_1(bevd_0);
case 1366553936: return bem_undef_1(bevd_0);
case -1988005274: return bem_sameObject_1(bevd_0);
case -2128352822: return bem_condanySet_1(bevd_0);
case 2089825688: return bem_inlinedSet_1(bevd_0);
case -1558601067: return bem_constantsSet_1(bevd_0);
case -958696643: return bem_inClassNpSetDirect_1(bevd_0);
case 203780305: return bem_wideStringSetDirect_1(bevd_0);
case -962669917: return bem_otherType_1(bevd_0);
case 1580450743: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case -1076276766: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case 870178787: return bem_typenameSet_1(bevd_0);
case -1341830476: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case 208310867: return bem_def_1(bevd_0);
case -1513122466: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case -507136920: return bem_containedSet_1(bevd_0);
case -1422291148: return bem_sameClass_1(bevd_0);
case -1039817436: return bem_nlcSet_1(bevd_0);
case 493426545: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 569440952: return bem_containedSetDirect_1(bevd_0);
case -858479212: return bem_inFileSetDirect_1(bevd_0);
case -1271094360: return bem_containerSetDirect_1(bevd_0);
case 1484718882: return bem_copyTo_1(bevd_0);
case -331716880: return bem_nlecSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1959141176: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1950811501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 36705687: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 95968616: return bem_tmpVar_2(bevd_0, bevd_1);
case 220358760: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -533377424: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -12510800: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281973651: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_4_BuildNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst = (BEC_2_5_4_BuildNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_type;
}
}
