package be;
public class BET_2_6_7_SystemCommand extends BETS_Object {
public BET_2_6_7_SystemCommand() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "listNew_1", "run_1", "run_0", "open_0", "outputGet_0", "closeOutput_0", "close_0", "outputContentGet_0", "commandGet_0", "commandSet_1", "commandsGet_0", "commandsSet_1", "outputReaderGet_0", "outputReaderSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "command", "commands", "outputReader" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_7_SystemCommand();
}
}
