package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_3_6_10_7_SystemSerializerSession extends BEC_2_6_6_SystemObject {
public BEC_3_6_10_7_SystemSerializerSession() { }
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x3A,0x53,0x65,0x73,0x73,0x69,0x6F,0x6E};
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static BEC_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;

public static BET_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;

public BEC_2_9_3_ContainerMap bevp_classTagMap;
public BEC_2_4_3_MathInt bevp_classTagCount;
public BEC_2_4_3_MathInt bevp_serialCount;
public BEC_2_9_11_ContainerIdentityMap bevp_unique;
public BEC_2_6_6_SystemObject bevp_instWriter;
public BEC_3_6_10_7_SystemSerializerSession bem_new_0() throws Throwable {
bevp_classTagMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classTagCount = (new BEC_2_4_3_MathInt(1));
bevp_serialCount = (new BEC_2_4_3_MathInt(1));
bevp_unique = (new BEC_2_9_11_ContainerIdentityMap()).bem_new_0();
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_new_1(BEC_2_6_6_SystemObject beva__instWriter) throws Throwable {
bem_new_0();
bevp_instWriter = beva__instWriter;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classTagMapGet_0() throws Throwable {
return bevp_classTagMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_classTagMapGetDirect_0() throws Throwable {
return bevp_classTagMap;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_classTagCountGet_0() throws Throwable {
return bevp_classTagCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_classTagCountGetDirect_0() throws Throwable {
return bevp_classTagCount;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_serialCountGet_0() throws Throwable {
return bevp_serialCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_serialCountGetDirect_0() throws Throwable {
return bevp_serialCount;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_serialCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_serialCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_uniqueGet_0() throws Throwable {
return bevp_unique;
} /*method end*/
public final BEC_2_9_11_ContainerIdentityMap bem_uniqueGetDirect_0() throws Throwable {
return bevp_unique;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_uniqueSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_uniqueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instWriterGet_0() throws Throwable {
return bevp_instWriter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_instWriterGetDirect_0() throws Throwable {
return bevp_instWriter;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_instWriterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_instWriter = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_instWriterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_instWriter = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {29, 30, 31, 32, 38, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 20, 24, 25, 29, 32, 35, 39, 43, 46, 49, 53, 57, 60, 63, 67, 71, 74, 77, 81, 85, 88, 91, 95};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 29 17
new 0 29 17
assign 1 30 18
new 0 30 18
assign 1 31 19
new 0 31 19
assign 1 32 20
new 0 32 20
new 0 38 24
assign 1 39 25
return 1 0 29
return 1 0 32
assign 1 0 35
assign 1 0 39
return 1 0 43
return 1 0 46
assign 1 0 49
assign 1 0 53
return 1 0 57
return 1 0 60
assign 1 0 63
assign 1 0 67
return 1 0 71
return 1 0 74
assign 1 0 77
assign 1 0 81
return 1 0 85
return 1 0 88
assign 1 0 91
assign 1 0 95
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 254283761: return bem_classNameGet_0();
case 32986096: return bem_tagGet_0();
case 255547376: return bem_serialCountGet_0();
case 1409837093: return bem_classTagMapGetDirect_0();
case 1337499076: return bem_fieldIteratorGet_0();
case -434766936: return bem_many_0();
case -1193538733: return bem_echo_0();
case 2128819446: return bem_classTagMapGet_0();
case -1235837036: return bem_uniqueGet_0();
case -1325426262: return bem_classTagCountGetDirect_0();
case -1667230363: return bem_new_0();
case -2068645774: return bem_toString_0();
case 656174411: return bem_iteratorGet_0();
case 1258540231: return bem_print_0();
case 1173115449: return bem_classTagCountGet_0();
case 1551090683: return bem_serialCountGetDirect_0();
case 181316061: return bem_serializeContents_0();
case -1379358469: return bem_uniqueGetDirect_0();
case 1333189262: return bem_copy_0();
case -1134589630: return bem_serializeToString_0();
case 1887791078: return bem_toAny_0();
case 1104438617: return bem_serializationIteratorGet_0();
case -810892117: return bem_sourceFileNameGet_0();
case 238716313: return bem_once_0();
case -565293250: return bem_instWriterGet_0();
case -1916545082: return bem_hashGet_0();
case -535743987: return bem_instWriterGetDirect_0();
case 470335985: return bem_fieldNamesGet_0();
case 1422294520: return bem_create_0();
case 1433312714: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 424030808: return bem_serialCountSetDirect_1(bevd_0);
case 1346224345: return bem_classTagCountSet_1(bevd_0);
case -1101562796: return bem_uniqueSetDirect_1(bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case -158747798: return bem_instWriterSet_1(bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case 880933392: return bem_classTagMapSetDirect_1(bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case 1290216463: return bem_def_1(bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case 279283833: return bem_instWriterSetDirect_1(bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case -430488466: return bem_uniqueSet_1(bevd_0);
case 1948301764: return bem_new_1(bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case 236260785: return bem_classTagCountSetDirect_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case -2093873998: return bem_classTagMapSet_1(bevd_0);
case -1795094941: return bem_serialCountSet_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_6_10_7_SystemSerializerSession_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_3_6_10_7_SystemSerializerSession_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_10_7_SystemSerializerSession();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst = (BEC_3_6_10_7_SystemSerializerSession) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;
}
}
