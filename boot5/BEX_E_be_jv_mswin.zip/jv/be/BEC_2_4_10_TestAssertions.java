package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_10_TestAssertions extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_TestAssertions() { }
private static byte[] becc_BEC_2_4_10_TestAssertions_clname = {0x54,0x65,0x73,0x74,0x3A,0x41,0x73,0x73,0x65,0x72,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_2_4_10_TestAssertions_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_0 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_1 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_2 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_3 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_4 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_5 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_6 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_7 = {0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_8 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x55,0x4E,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_9 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_10 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x4F,0x54,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_11 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x54,0x52,0x55,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_12 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x46,0x41,0x4C,0x53,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
public static BEC_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_inst;

public static BET_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_type;

public BEC_2_4_10_TestAssertions bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_7_TestFailure bevt_10_ta_ph = null;
bevt_2_ta_ph = beva_v1.bemd_1(-1412823423, beva_v2);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1027205593);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 32*/ {
bevl_msg = (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_0));
if (beva_v1 == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 34*/ {
if (beva_v2 == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 34*/
 else /* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 34*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_7_ta_ph = bevl_msg.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(beva_v1);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_5_ta_ph.bem_addValue_1(beva_v2);
} /* Line: 35*/
bevt_10_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 37*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_7_TestFailure bevt_9_ta_ph = null;
bevt_1_ta_ph = beva_v1.bemd_1(-1412823423, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 41*/ {
bevl_msg = (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_3));
if (beva_v1 == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 43*/ {
if (beva_v2 == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 43*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 43*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 43*/
 else /* Line: 43*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 43*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_6_ta_ph = bevl_msg.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(beva_v1);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(beva_v2);
} /* Line: 44*/
bevt_9_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_9_ta_ph);
} /* Line: 46*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_10_TestAssertions bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_assertEqual_2(beva_v1, beva_v2);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertNotEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_10_TestAssertions bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_assertNotEqual_2(beva_v1, beva_v2);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_v1v = null;
BEC_2_4_6_TextString bevl_v2v = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_7_TestFailure bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (beva_v1 == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 56*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(56, bece_BEC_2_4_10_TestAssertions_bels_4));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 57*/
bevt_3_ta_ph = beva_v1.bemd_1(-900715304, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 59*/ {
if (beva_v1 == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 60*/ {
bevl_v1v = (BEC_2_4_6_TextString) beva_v1.bemd_0(-334139513);
} /* Line: 61*/
 else /* Line: 62*/ {
bevl_v1v = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_5));
} /* Line: 63*/
if (beva_v2 == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 65*/ {
bevl_v2v = (BEC_2_4_6_TextString) beva_v2.bemd_0(-334139513);
} /* Line: 66*/
 else /* Line: 67*/ {
bevl_v2v = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_5));
} /* Line: 68*/
bevt_10_ta_ph = (new BEC_2_4_6_TextString(36, bece_BEC_2_4_10_TestAssertions_bels_6));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_v1v);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_TestAssertions_bels_7));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_v2v);
bevt_6_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_7_ta_ph);
throw new be.BECS_ThrowBack(bevt_6_ta_ph);
} /* Line: 70*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = beva_v1.bemd_1(-1441152686, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 74*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(36, bece_BEC_2_4_10_TestAssertions_bels_8));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 75*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_v == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 79*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_9));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 80*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertIsNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_v == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 84*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_9));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 85*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertNotNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_v == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 89*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_4_10_TestAssertions_bels_10));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 90*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertTrue_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TestFailure bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = beva_v.bemd_0(-1027205593);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 94*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_11));
bevt_1_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 95*/
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_assertFalse_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_4_7_TestFailure bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (((BEC_2_5_4_LogicBool) beva_v).bevi_bool)/* Line: 99*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_4_10_TestAssertions_bels_12));
bevt_0_ta_ph = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_1_ta_ph);
throw new be.BECS_ThrowBack(bevt_0_ta_ph);
} /* Line: 100*/
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {32, 32, 33, 34, 34, 34, 34, 0, 0, 0, 35, 35, 35, 35, 35, 35, 37, 37, 41, 42, 43, 43, 43, 43, 0, 0, 0, 44, 44, 44, 44, 44, 44, 46, 46, 50, 50, 53, 53, 56, 56, 57, 57, 57, 59, 60, 60, 61, 63, 65, 65, 66, 68, 70, 70, 70, 70, 70, 70, 70, 74, 75, 75, 75, 79, 79, 80, 80, 80, 84, 84, 85, 85, 85, 89, 89, 90, 90, 90, 94, 95, 95, 95, 100, 100, 100};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {43, 44, 46, 47, 52, 53, 58, 59, 62, 66, 69, 70, 71, 72, 73, 74, 76, 77, 93, 95, 96, 101, 102, 107, 108, 111, 115, 118, 119, 120, 121, 122, 123, 125, 126, 132, 133, 137, 138, 155, 160, 161, 162, 163, 165, 167, 172, 173, 176, 178, 183, 184, 187, 189, 190, 191, 192, 193, 194, 195, 203, 205, 206, 207, 215, 220, 221, 222, 223, 231, 236, 237, 238, 239, 247, 252, 253, 254, 255, 263, 265, 266, 267, 275, 276, 277};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 32 43
has 1 32 43
assign 1 32 44
not 0 32 44
assign 1 33 46
new 0 33 46
assign 1 34 47
def 1 34 52
assign 1 34 53
def 1 34 58
assign 1 0 59
assign 1 0 62
assign 1 0 66
assign 1 35 69
new 0 35 69
assign 1 35 70
addValue 1 35 70
assign 1 35 71
addValue 1 35 71
assign 1 35 72
new 0 35 72
assign 1 35 73
addValue 1 35 73
addValue 1 35 74
assign 1 37 76
new 1 37 76
throw 1 37 77
assign 1 41 93
has 1 41 93
assign 1 42 95
new 0 42 95
assign 1 43 96
def 1 43 101
assign 1 43 102
def 1 43 107
assign 1 0 108
assign 1 0 111
assign 1 0 115
assign 1 44 118
new 0 44 118
assign 1 44 119
addValue 1 44 119
assign 1 44 120
addValue 1 44 120
assign 1 44 121
new 0 44 121
assign 1 44 122
addValue 1 44 122
addValue 1 44 123
assign 1 46 125
new 1 46 125
throw 1 46 126
assign 1 50 132
assertEqual 2 50 132
return 1 50 133
assign 1 53 137
assertNotEqual 2 53 137
return 1 53 138
assign 1 56 155
undef 1 56 160
assign 1 57 161
new 0 57 161
assign 1 57 162
new 1 57 162
throw 1 57 163
assign 1 59 165
notEquals 1 59 165
assign 1 60 167
def 1 60 172
assign 1 61 173
toString 0 61 173
assign 1 63 176
new 0 63 176
assign 1 65 178
def 1 65 183
assign 1 66 184
toString 0 66 184
assign 1 68 187
new 0 68 187
assign 1 70 189
new 0 70 189
assign 1 70 190
add 1 70 190
assign 1 70 191
new 0 70 191
assign 1 70 192
add 1 70 192
assign 1 70 193
add 1 70 193
assign 1 70 194
new 1 70 194
throw 1 70 195
assign 1 74 203
equals 1 74 203
assign 1 75 205
new 0 75 205
assign 1 75 206
new 1 75 206
throw 1 75 207
assign 1 79 215
def 1 79 220
assign 1 80 221
new 0 80 221
assign 1 80 222
new 1 80 222
throw 1 80 223
assign 1 84 231
def 1 84 236
assign 1 85 237
new 0 85 237
assign 1 85 238
new 1 85 238
throw 1 85 239
assign 1 89 247
undef 1 89 252
assign 1 90 253
new 0 90 253
assign 1 90 254
new 1 90 254
throw 1 90 255
assign 1 94 263
not 0 94 263
assign 1 95 265
new 0 95 265
assign 1 95 266
new 1 95 266
throw 1 95 267
assign 1 100 275
new 0 100 275
assign 1 100 276
new 1 100 276
throw 1 100 277
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1904974225: return bem_print_0();
case -485663586: return bem_default_0();
case -582936884: return bem_copy_0();
case -334139513: return bem_toString_0();
case -507985549: return bem_new_0();
case -1277691905: return bem_create_0();
case 323586228: return bem_hashGet_0();
case 1406439869: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1068510415: return bem_assertNull_1(bevd_0);
case -1564500571: return bem_def_1(bevd_0);
case -277521797: return bem_assertIsNull_1(bevd_0);
case 2083304692: return bem_copyTo_1(bevd_0);
case -1441152686: return bem_equals_1(bevd_0);
case 1652610278: return bem_assertNotNull_1(bevd_0);
case 2048084281: return bem_assertTrue_1(bevd_0);
case 1894221943: return bem_undef_1(bevd_0);
case -1426197570: return bem_assertFalse_1(bevd_0);
case -900715304: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1280428261: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1170875190: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -506946318: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 221355997: return bem_assertEquals_2(bevd_0, bevd_1);
case 1702257668: return bem_assertNotEqual_2(bevd_0, bevd_1);
case 1546000001: return bem_assertNotHas_2(bevd_0, bevd_1);
case 1834047895: return bem_assertHas_2(bevd_0, bevd_1);
case -941355214: return bem_assertNotEquals_2(bevd_0, bevd_1);
case -138720468: return bem_assertEqual_2(bevd_0, bevd_1);
case 2064104272: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_TestAssertions_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_10_TestAssertions_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_TestAssertions();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst = (BEC_2_4_10_TestAssertions) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_type;
}
}
