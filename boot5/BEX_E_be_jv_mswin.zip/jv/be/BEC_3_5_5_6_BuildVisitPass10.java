package be;
/* IO:File: source/build/Pass10.be */
public final class BEC_3_5_5_6_BuildVisitPass10 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass10() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x30};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x30,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitPass10_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_1 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_2 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_3 = {0x61,0x6E,0x63,0x68,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
public static BEC_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;

public static BET_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;

public BEC_2_6_6_SystemObject bem_condCall_2(BEC_2_6_6_SystemObject beva_condany, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_acc = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_5_4_BuildCall bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_ta_ph = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_cnode.bemd_1(956154773, bevt_0_ta_ph);
bevt_1_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_cnode.bemd_1(-521914239, bevt_1_ta_ph);
bevl_acc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_acc.bemd_1(-521914239, bevt_2_ta_ph);
bevl_acc.bemd_1(956154773, beva_condany);
bevl_cnode.bemd_1(1513347703, bevl_acc);
bevt_3_ta_ph = bevl_cnode.bemd_0(345872792);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_0));
bevt_3_ta_ph.bemd_1(2129533417, bevt_4_ta_ph);
bevl_nnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nnode.bemd_1(-521914239, beva_value);
bevl_cnode.bemd_1(1513347703, bevl_nnode);
return bevl_cnode;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_anchor = null;
BEC_2_6_6_SystemObject bevl_condany = null;
BEC_2_6_6_SystemObject bevl_cvnp = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_rinode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_BuildNode bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_5_4_BuildNode bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_5_4_BuildNode bevt_77_ta_ph = null;
bevt_4_ta_ph = beva_node.bem_typenameGet_0();
bevt_5_ta_ph = bevp_ntypes.bem_PARENSGet_0();
if (bevt_4_ta_ph.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_8_ta_ph = beva_node.bem_containedGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_lengthGet_0();
bevt_9_ta_ph = bece_BEC_3_5_5_6_BuildVisitPass10_bevo_0;
if (bevt_7_ta_ph.bevi_int == bevt_9_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
 else /* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_13_ta_ph = beva_node.bem_containedGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_firstGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(1863628936);
bevt_14_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(-420475689, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
 else /* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_16_ta_ph = beva_node.bem_containedGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bem_firstGet_0();
beva_node.bem_takeContents_1((BEC_2_5_4_BuildNode) bevt_15_ta_ph );
return beva_node;
} /* Line: 33*/
bevt_18_ta_ph = beva_node.bem_typenameGet_0();
bevt_19_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_18_ta_ph.bevi_int == bevt_19_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_20_ta_ph = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_20_ta_ph);
beva_node.bem_syncVariable_1(this);
} /* Line: 38*/
bevt_22_ta_ph = beva_node.bem_typenameGet_0();
bevt_23_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_22_ta_ph.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 41*/ {
bevt_26_ta_ph = beva_node.bem_heldGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(690554068);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(-420475689, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 41*/ {
bevt_30_ta_ph = beva_node.bem_heldGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(690554068);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_2));
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(-420475689, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 41*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 41*/
 else /* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 41*/ {
bevl_anchor = beva_node.bem_anchorGet_0();
bevl_condany = bevl_anchor.bemd_0(-550666317);
if (bevl_condany == null) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 46*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_3));
bevl_condany = bevl_anchor.bemd_2(1790175797, bevt_33_ta_ph, bevp_build);
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
bevl_condany.bemd_1(-1313118960, bevt_34_ta_ph);
bevl_cvnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_4));
bevl_cvnp.bemd_1(-1580110729, bevt_35_ta_ph);
bevl_condany.bemd_1(-1510394643, bevl_cvnp);
bevl_anchor.bemd_1(369043020, bevl_condany);
} /* Line: 52*/
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_36_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-521914239, bevt_36_ta_ph);
bevl_inode.bemd_1(382192229, beva_node);
bevl_rinode = bevl_inode;
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(382192229, beva_node);
bevt_37_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-521914239, bevt_37_ta_ph);
bevl_inode.bemd_1(1513347703, bevl_pnode);
bevt_39_ta_ph = beva_node.bem_containedGet_0();
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevl_pnode.bemd_1(1513347703, bevt_38_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(382192229, beva_node);
bevt_40_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-521914239, bevt_40_ta_ph);
bevl_inode.bemd_1(1513347703, bevl_bnode);
bevt_43_ta_ph = beva_node.bem_heldGet_0();
bevt_42_ta_ph = bevt_43_ta_ph.bemd_0(690554068);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(-420475689, bevt_44_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 73*/ {
bevt_46_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_45_ta_ph = bem_condCall_2(bevl_condany, bevt_46_ta_ph);
bevl_bnode.bemd_1(1513347703, bevt_45_ta_ph);
} /* Line: 74*/
 else /* Line: 76*/ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(382192229, beva_node);
bevt_47_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-521914239, bevt_47_ta_ph);
bevl_inode.bemd_1(369043020, bevl_condany);
bevl_bnode.bemd_1(1513347703, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(382192229, beva_node);
bevt_48_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-521914239, bevt_48_ta_ph);
bevl_inode.bemd_1(1513347703, bevl_pnode);
bevt_49_ta_ph = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(1513347703, bevt_49_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(382192229, beva_node);
bevt_50_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-521914239, bevt_50_ta_ph);
bevl_inode.bemd_1(1513347703, bevl_bnode);
bevt_52_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_51_ta_ph = bem_condCall_2(bevl_condany, bevt_52_ta_ph);
bevl_bnode.bemd_1(1513347703, bevt_51_ta_ph);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(382192229, beva_node);
bevt_53_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-521914239, bevt_53_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(382192229, beva_node);
bevt_54_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-521914239, bevt_54_ta_ph);
bevt_56_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_55_ta_ph = bem_condCall_2(bevl_condany, bevt_56_ta_ph);
bevl_bnode.bemd_1(1513347703, bevt_55_ta_ph);
bevl_enode.bemd_1(1513347703, bevl_bnode);
bevl_inode.bemd_1(1513347703, bevl_enode);
} /* Line: 103*/
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(382192229, beva_node);
bevt_57_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-521914239, bevt_57_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(382192229, beva_node);
bevt_58_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-521914239, bevt_58_ta_ph);
bevl_rinode.bemd_1(1513347703, bevl_enode);
bevl_enode.bemd_1(1513347703, bevl_bnode);
bevt_61_ta_ph = beva_node.bem_heldGet_0();
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(690554068);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_59_ta_ph = bevt_60_ta_ph.bemd_1(-420475689, bevt_62_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 115*/ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(382192229, beva_node);
bevt_63_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-521914239, bevt_63_ta_ph);
bevl_inode.bemd_1(369043020, bevl_condany);
bevl_bnode.bemd_1(1513347703, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(382192229, beva_node);
bevt_64_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-521914239, bevt_64_ta_ph);
bevl_inode.bemd_1(1513347703, bevl_pnode);
bevt_65_ta_ph = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(1513347703, bevt_65_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(382192229, beva_node);
bevt_66_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-521914239, bevt_66_ta_ph);
bevl_inode.bemd_1(1513347703, bevl_bnode);
bevt_68_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_67_ta_ph = bem_condCall_2(bevl_condany, bevt_68_ta_ph);
bevl_bnode.bemd_1(1513347703, bevt_67_ta_ph);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(382192229, beva_node);
bevt_69_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-521914239, bevt_69_ta_ph);
bevl_inode.bemd_1(1513347703, bevl_enode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(382192229, beva_node);
bevt_70_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-521914239, bevt_70_ta_ph);
bevt_72_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_71_ta_ph = bem_condCall_2(bevl_condany, bevt_72_ta_ph);
bevl_bnode.bemd_1(1513347703, bevt_71_ta_ph);
bevl_enode.bemd_1(1513347703, bevl_bnode);
} /* Line: 141*/
 else /* Line: 142*/ {
bevt_74_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_73_ta_ph = bem_condCall_2(bevl_condany, bevt_74_ta_ph);
bevl_bnode.bemd_1(1513347703, bevt_73_ta_ph);
} /* Line: 143*/
bevl_anchor.bemd_1(-127333753, bevl_rinode);
beva_node.bem_containedSet_1(null);
bevt_75_ta_ph = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_75_ta_ph);
beva_node.bem_heldSet_1(bevl_condany);
beva_node.bem_syncAddVariable_0();
bevt_76_ta_ph = bevl_rinode.bemd_0(-1963517684);
return (BEC_2_5_4_BuildNode) bevt_76_ta_ph;
} /* Line: 152*/
bevt_77_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_77_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 17, 18, 18, 19, 20, 20, 21, 22, 23, 23, 23, 24, 25, 26, 27, 31, 31, 31, 31, 31, 31, 31, 31, 31, 0, 0, 0, 31, 31, 31, 31, 31, 0, 0, 0, 32, 32, 32, 33, 36, 36, 36, 36, 37, 37, 38, 41, 41, 41, 41, 41, 41, 41, 41, 0, 41, 41, 41, 41, 0, 0, 0, 0, 0, 43, 44, 46, 46, 47, 47, 48, 48, 49, 50, 50, 51, 52, 55, 56, 56, 57, 59, 61, 62, 63, 63, 64, 66, 66, 66, 68, 69, 70, 70, 71, 73, 73, 73, 73, 74, 74, 74, 78, 79, 80, 80, 81, 82, 84, 85, 86, 86, 87, 88, 88, 89, 90, 91, 91, 92, 93, 93, 93, 95, 96, 97, 97, 98, 99, 100, 100, 101, 101, 101, 102, 103, 106, 107, 108, 108, 109, 110, 111, 111, 112, 113, 115, 115, 115, 115, 116, 117, 118, 118, 119, 120, 122, 123, 124, 124, 125, 126, 126, 127, 128, 129, 129, 130, 131, 131, 131, 133, 134, 135, 135, 136, 137, 138, 139, 139, 140, 140, 140, 141, 143, 143, 143, 147, 148, 149, 149, 150, 151, 152, 152, 155, 155};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 131, 132, 133, 138, 139, 140, 141, 142, 147, 148, 151, 155, 158, 159, 160, 161, 162, 164, 167, 171, 174, 175, 176, 177, 179, 180, 181, 186, 187, 188, 189, 191, 192, 193, 198, 199, 200, 201, 202, 204, 207, 208, 209, 210, 212, 215, 219, 222, 226, 229, 230, 231, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 270, 271, 272, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 361, 362, 363, 365, 366, 367, 368, 369, 370, 371, 372, 374, 375};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 26
new 1 16 26
assign 1 17 27
new 0 17 27
heldSet 1 17 28
assign 1 18 29
CALLGet 0 18 29
typenameSet 1 18 30
assign 1 19 31
new 1 19 31
assign 1 20 32
VARGet 0 20 32
typenameSet 1 20 33
heldSet 1 21 34
addValue 1 22 35
assign 1 23 36
heldGet 0 23 36
assign 1 23 37
new 0 23 37
nameSet 1 23 38
assign 1 24 39
new 1 24 39
typenameSet 1 25 40
addValue 1 26 41
return 1 27 42
assign 1 31 131
typenameGet 0 31 131
assign 1 31 132
PARENSGet 0 31 132
assign 1 31 133
equals 1 31 138
assign 1 31 139
containedGet 0 31 139
assign 1 31 140
lengthGet 0 31 140
assign 1 31 141
new 0 31 141
assign 1 31 142
equals 1 31 147
assign 1 0 148
assign 1 0 151
assign 1 0 155
assign 1 31 158
containedGet 0 31 158
assign 1 31 159
firstGet 0 31 159
assign 1 31 160
typenameGet 0 31 160
assign 1 31 161
PARENSGet 0 31 161
assign 1 31 162
equals 1 31 162
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 32 174
containedGet 0 32 174
assign 1 32 175
firstGet 0 32 175
takeContents 1 32 176
return 1 33 177
assign 1 36 179
typenameGet 0 36 179
assign 1 36 180
IDGet 0 36 180
assign 1 36 181
equals 1 36 186
assign 1 37 187
VARGet 0 37 187
typenameSet 1 37 188
syncVariable 1 38 189
assign 1 41 191
typenameGet 0 41 191
assign 1 41 192
CALLGet 0 41 192
assign 1 41 193
equals 1 41 198
assign 1 41 199
heldGet 0 41 199
assign 1 41 200
nameGet 0 41 200
assign 1 41 201
new 0 41 201
assign 1 41 202
equals 1 41 202
assign 1 0 204
assign 1 41 207
heldGet 0 41 207
assign 1 41 208
nameGet 0 41 208
assign 1 41 209
new 0 41 209
assign 1 41 210
equals 1 41 210
assign 1 0 212
assign 1 0 215
assign 1 0 219
assign 1 0 222
assign 1 0 226
assign 1 43 229
anchorGet 0 43 229
assign 1 44 230
condanyGet 0 44 230
assign 1 46 231
undef 1 46 236
assign 1 47 237
new 0 47 237
assign 1 47 238
tmpVar 2 47 238
assign 1 48 239
new 0 48 239
isTypedSet 1 48 240
assign 1 49 241
new 0 49 241
assign 1 50 242
new 0 50 242
fromString 1 50 243
namepathSet 1 51 244
condanySet 1 52 245
assign 1 55 247
new 1 55 247
assign 1 56 248
IFGet 0 56 248
typenameSet 1 56 249
copyLoc 1 57 250
assign 1 59 251
assign 1 61 252
new 1 61 252
copyLoc 1 62 253
assign 1 63 254
PARENSGet 0 63 254
typenameSet 1 63 255
addValue 1 64 256
assign 1 66 257
containedGet 0 66 257
assign 1 66 258
firstGet 0 66 258
addValue 1 66 259
assign 1 68 260
new 1 68 260
copyLoc 1 69 261
assign 1 70 262
BRACESGet 0 70 262
typenameSet 1 70 263
addValue 1 71 264
assign 1 73 265
heldGet 0 73 265
assign 1 73 266
nameGet 0 73 266
assign 1 73 267
new 0 73 267
assign 1 73 268
equals 1 73 268
assign 1 74 270
TRUEGet 0 74 270
assign 1 74 271
condCall 2 74 271
addValue 1 74 272
assign 1 78 275
new 1 78 275
copyLoc 1 79 276
assign 1 80 277
IFGet 0 80 277
typenameSet 1 80 278
condanySet 1 81 279
addValue 1 82 280
assign 1 84 281
new 1 84 281
copyLoc 1 85 282
assign 1 86 283
PARENSGet 0 86 283
typenameSet 1 86 284
addValue 1 87 285
assign 1 88 286
secondGet 0 88 286
addValue 1 88 287
assign 1 89 288
new 1 89 288
copyLoc 1 90 289
assign 1 91 290
BRACESGet 0 91 290
typenameSet 1 91 291
addValue 1 92 292
assign 1 93 293
TRUEGet 0 93 293
assign 1 93 294
condCall 2 93 294
addValue 1 93 295
assign 1 95 296
new 1 95 296
copyLoc 1 96 297
assign 1 97 298
ELSEGet 0 97 298
typenameSet 1 97 299
assign 1 98 300
new 1 98 300
copyLoc 1 99 301
assign 1 100 302
BRACESGet 0 100 302
typenameSet 1 100 303
assign 1 101 304
FALSEGet 0 101 304
assign 1 101 305
condCall 2 101 305
addValue 1 101 306
addValue 1 102 307
addValue 1 103 308
assign 1 106 310
new 1 106 310
copyLoc 1 107 311
assign 1 108 312
ELSEGet 0 108 312
typenameSet 1 108 313
assign 1 109 314
new 1 109 314
copyLoc 1 110 315
assign 1 111 316
BRACESGet 0 111 316
typenameSet 1 111 317
addValue 1 112 318
addValue 1 113 319
assign 1 115 320
heldGet 0 115 320
assign 1 115 321
nameGet 0 115 321
assign 1 115 322
new 0 115 322
assign 1 115 323
equals 1 115 323
assign 1 116 325
new 1 116 325
copyLoc 1 117 326
assign 1 118 327
IFGet 0 118 327
typenameSet 1 118 328
condanySet 1 119 329
addValue 1 120 330
assign 1 122 331
new 1 122 331
copyLoc 1 123 332
assign 1 124 333
PARENSGet 0 124 333
typenameSet 1 124 334
addValue 1 125 335
assign 1 126 336
secondGet 0 126 336
addValue 1 126 337
assign 1 127 338
new 1 127 338
copyLoc 1 128 339
assign 1 129 340
BRACESGet 0 129 340
typenameSet 1 129 341
addValue 1 130 342
assign 1 131 343
TRUEGet 0 131 343
assign 1 131 344
condCall 2 131 344
addValue 1 131 345
assign 1 133 346
new 1 133 346
copyLoc 1 134 347
assign 1 135 348
ELSEGet 0 135 348
typenameSet 1 135 349
addValue 1 136 350
assign 1 137 351
new 1 137 351
copyLoc 1 138 352
assign 1 139 353
BRACESGet 0 139 353
typenameSet 1 139 354
assign 1 140 355
FALSEGet 0 140 355
assign 1 140 356
condCall 2 140 356
addValue 1 140 357
addValue 1 141 358
assign 1 143 361
FALSEGet 0 143 361
assign 1 143 362
condCall 2 143 362
addValue 1 143 363
beforeInsert 1 147 365
containedSet 1 148 366
assign 1 149 367
VARGet 0 149 367
typenameSet 1 149 368
heldSet 1 150 369
syncAddVariable 0 151 370
assign 1 152 371
nextDescendGet 0 152 371
return 1 152 372
assign 1 155 374
nextDescendGet 0 155 374
return 1 155 375
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 254283761: return bem_classNameGet_0();
case 32986096: return bem_tagGet_0();
case -1385380140: return bem_constGet_0();
case 1337499076: return bem_fieldIteratorGet_0();
case -434766936: return bem_many_0();
case -1193538733: return bem_echo_0();
case 151131677: return bem_buildGetDirect_0();
case 1993725787: return bem_buildGet_0();
case -1667230363: return bem_new_0();
case -2068645774: return bem_toString_0();
case 656174411: return bem_iteratorGet_0();
case 1258540231: return bem_print_0();
case 1724284574: return bem_constGetDirect_0();
case 840272884: return bem_ntypesGet_0();
case 181316061: return bem_serializeContents_0();
case 1891960843: return bem_transGet_0();
case 1333189262: return bem_copy_0();
case -1134589630: return bem_serializeToString_0();
case 1887791078: return bem_toAny_0();
case 1104438617: return bem_serializationIteratorGet_0();
case -810892117: return bem_sourceFileNameGet_0();
case 238716313: return bem_once_0();
case -1916545082: return bem_hashGet_0();
case -1418943130: return bem_ntypesGetDirect_0();
case 470335985: return bem_fieldNamesGet_0();
case 465992683: return bem_transGetDirect_0();
case 1422294520: return bem_create_0();
case 1433312714: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1290216463: return bem_def_1(bevd_0);
case -608231493: return bem_buildSetDirect_1(bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case -570491086: return bem_transSetDirect_1(bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1914536347: return bem_transSet_1(bevd_0);
case -483224371: return bem_end_1(bevd_0);
case -1024351632: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case 129810800: return bem_ntypesSet_1(bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case 1641712379: return bem_buildSet_1(bevd_0);
case 1892842053: return bem_constSetDirect_1(bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case 100560712: return bem_constSet_1(bevd_0);
case 1675566006: return bem_begin_1(bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case 2099765945: return bem_ntypesSetDirect_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 326822733: return bem_condCall_2(bevd_0, bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass10_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass10_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass10();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst = (BEC_3_5_5_6_BuildVisitPass10) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;
}
}
