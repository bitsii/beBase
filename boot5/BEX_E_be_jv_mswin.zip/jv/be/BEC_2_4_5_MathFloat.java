package be;
/* IO:File: source/base/Float.be */
public final class BEC_2_4_5_MathFloat extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
public static BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) throws Throwable {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_5_MathFloat bevt_21_ta_ph = null;
BEC_2_4_5_MathFloat bevt_22_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_ta_ph = beva_si.bemd_1(1830043680, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 88*/ {
bevl_neg = be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(-976389765, bevt_2_ta_ph);
} /* Line: 90*/
 else /* Line: 91*/ {
bevl_neg = be.BECS_Runtime.boolFalse;
} /* Line: 92*/
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(-1142176750, bevt_3_ta_ph);
if (bevl_dec == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_dec.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 96*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_7_ta_ph = beva_si.bemd_2(-1343546291, bevt_8_ta_ph, bevl_dec);
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_ta_ph);
} /* Line: 97*/
 else /* Line: 98*/ {
bevl_lhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 99*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_10_ta_ph = bevl_dec.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = beva_si.bemd_0(-905156598);
bevt_9_ta_ph = bevt_10_ta_ph.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_ta_ph );
if (bevt_9_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_14_ta_ph = bevl_dec.bem_add_1(bevt_15_ta_ph);
bevt_13_ta_ph = beva_si.bemd_1(-976389765, bevt_14_ta_ph);
bevl_rhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_ta_ph);
} /* Line: 102*/
 else /* Line: 103*/ {
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 104*/
} /* Line: 101*/
 else /* Line: 106*/ {
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 108*/
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_18_ta_ph = bevl_rhs.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_lengthGet_0();
bevl_divby = bevt_16_ta_ph.bem_power_1(bevt_17_ta_ph);
if (bevl_neg.bevi_bool)/* Line: 111*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_ta_ph);
} /* Line: 113*/
bevt_21_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_rhs);
bevt_22_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_divby);
bevl_rhsf = bevt_21_ta_ph.bem_divide_1(bevt_22_ta_ph);
bevl_lhsf = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_lhs);
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_intNew_1(BEC_2_4_3_MathInt beva_int) throws Throwable {

      bevi_float = (float) beva_int.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_create_0() throws Throwable {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_4_5_MathFloat) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (new BEC_2_4_3_MathInt());

      bevl_ii.bevi_int = (int) bevi_float;
      return bevl_ii;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toInt_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
BEC_2_4_5_MathFloat bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_lhi = bem_toInt_0();
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_lhi);
bevl_rh = bem_subtract_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_ta_ph);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_ta_ph = bevl_lhi.bem_toString_0();
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = bevl_rhi.bem_toString_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_incrementValue_0() throws Throwable {

                bevi_float = this.bevi_float + 1;
            return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrementValue_0() throws Throwable {

                bevi_float = this.bevi_float - 1;
            return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_xi == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 319*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 319*/

      if (this.bevi_float == ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_xi == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 362*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 362*/

      if (this.bevi_float != ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {88, 88, 89, 90, 90, 92, 94, 94, 95, 95, 96, 96, 96, 97, 97, 97, 99, 101, 101, 101, 101, 102, 102, 102, 102, 104, 107, 108, 110, 110, 110, 110, 112, 112, 113, 113, 115, 115, 115, 116, 117, 118, 140, 140, 143, 143, 147, 151, 151, 162, 185, 190, 190, 194, 195, 195, 196, 196, 197, 198, 198, 198, 198, 198, 198, 233, 244, 253, 264, 273, 284, 293, 304, 312, 312, 319, 319, 319, 319, 355, 355, 362, 362, 362, 362, 398, 398, 426, 426, 454, 454, 482, 482, 510, 510};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {59, 60, 62, 63, 64, 67, 69, 70, 71, 76, 77, 78, 83, 84, 85, 86, 89, 91, 92, 93, 94, 96, 97, 98, 99, 102, 106, 107, 109, 110, 111, 112, 114, 115, 116, 117, 119, 120, 121, 122, 123, 124, 133, 134, 138, 139, 142, 147, 148, 152, 155, 159, 160, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 198, 201, 205, 208, 212, 215, 219, 222, 226, 227, 233, 238, 239, 240, 246, 247, 253, 258, 259, 260, 266, 267, 275, 276, 284, 285, 293, 294, 302, 303};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 88 59
new 0 88 59
assign 1 88 60
begins 1 88 60
assign 1 89 62
new 0 89 62
assign 1 90 63
new 0 90 63
assign 1 90 64
substring 1 90 64
assign 1 92 67
new 0 92 67
assign 1 94 69
new 0 94 69
assign 1 94 70
find 1 94 70
assign 1 95 71
def 1 95 76
assign 1 96 77
new 0 96 77
assign 1 96 78
greater 1 96 83
assign 1 97 84
new 0 97 84
assign 1 97 85
substring 2 97 85
assign 1 97 86
new 1 97 86
assign 1 99 89
new 0 99 89
assign 1 101 91
new 0 101 91
assign 1 101 92
add 1 101 92
assign 1 101 93
lengthGet 0 101 93
assign 1 101 94
lesser 1 101 94
assign 1 102 96
new 0 102 96
assign 1 102 97
add 1 102 97
assign 1 102 98
substring 1 102 98
assign 1 102 99
new 1 102 99
assign 1 104 102
new 0 104 102
assign 1 107 106
new 1 107 106
assign 1 108 107
new 0 108 107
assign 1 110 109
new 0 110 109
assign 1 110 110
toString 0 110 110
assign 1 110 111
lengthGet 0 110 111
assign 1 110 112
power 1 110 112
assign 1 112 114
new 0 112 114
multiplyValue 1 112 115
assign 1 113 116
new 0 113 116
multiplyValue 1 113 117
assign 1 115 119
intNew 1 115 119
assign 1 115 120
intNew 1 115 120
assign 1 115 121
divide 1 115 121
assign 1 116 122
intNew 1 116 122
assign 1 117 123
add 1 117 123
return 1 118 124
assign 1 140 133
new 0 140 133
return 1 140 134
assign 1 143 138
toString 0 143 138
return 1 143 139
new 1 147 142
assign 1 151 147
new 0 151 147
return 1 151 148
assign 1 162 152
new 0 162 152
return 1 185 155
assign 1 190 159
toInt 0 190 159
return 1 190 160
assign 1 194 173
toInt 0 194 173
assign 1 195 174
intNew 1 195 174
assign 1 195 175
subtract 1 195 175
assign 1 196 176
new 0 196 176
assign 1 196 177
multiply 1 196 177
assign 1 197 178
toInt 0 197 178
assign 1 198 179
toString 0 198 179
assign 1 198 180
new 0 198 180
assign 1 198 181
add 1 198 181
assign 1 198 182
toString 0 198 182
assign 1 198 183
add 1 198 183
return 1 198 184
assign 1 233 198
new 0 233 198
return 1 244 201
assign 1 253 205
new 0 253 205
return 1 264 208
assign 1 273 212
new 0 273 212
return 1 284 215
assign 1 293 219
new 0 293 219
return 1 304 222
assign 1 312 226
new 0 312 226
return 1 312 227
assign 1 319 233
undef 1 319 238
assign 1 319 239
new 0 319 239
return 1 319 240
assign 1 355 246
new 0 355 246
return 1 355 247
assign 1 362 253
undef 1 362 258
assign 1 362 259
new 0 362 259
return 1 362 260
assign 1 398 266
new 0 398 266
return 1 398 267
assign 1 426 275
new 0 426 275
return 1 426 276
assign 1 454 284
new 0 454 284
return 1 454 285
assign 1 482 293
new 0 482 293
return 1 482 294
assign 1 510 302
new 0 510 302
return 1 510 303
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2049866325: return bem_incrementValue_0();
case -887836447: return bem_serializeContentsGet_0();
case -496842367: return bem_new_0();
case 1355937742: return bem_decrementValue_0();
case 1063348506: return bem_vfloatSet_0();
case -355672893: return bem_hashGet_0();
case 1439653353: return bem_create_0();
case -1049146386: return bem_serializeToString_0();
case -777617664: return bem_iteratorGet_0();
case 1630760726: return bem_toString_0();
case -1339737103: return bem_vfloatGet_0();
case 2006182017: return bem_toInt_0();
case 1152967006: return bem_copy_0();
case 1103672703: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1282459217: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case 991833408: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case 1288698839: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case -1519841444: return bem_intNew_1((BEC_2_4_3_MathInt) bevd_0);
case -1250946597: return bem_print_1(bevd_0);
case 445187513: return bem_equals_1(bevd_0);
case -1109268004: return bem_new_1(bevd_0);
case -287604400: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case 152724600: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case -903889652: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case -1482846215: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -220436972: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 863284586: return bem_notEquals_1(bevd_0);
case -1721047471: return bem_def_1(bevd_0);
case -938105188: return bem_undef_1(bevd_0);
case -587753182: return bem_copyTo_1(bevd_0);
case -677123304: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -107313281: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -558969549: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2056786157: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2082389725: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1197567931: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_MathFloat();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
