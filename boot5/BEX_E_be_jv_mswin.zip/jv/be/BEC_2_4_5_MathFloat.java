package be;
/* IO:File: source/base/Float.be */
public final class BEC_2_4_5_MathFloat extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
public static BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) throws Throwable {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_5_MathFloat bevt_21_ta_ph = null;
BEC_2_4_5_MathFloat bevt_22_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_ta_ph = beva_si.bemd_1(-2111479010, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 64*/ {
bevl_neg = be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(1873636265, bevt_2_ta_ph);
} /* Line: 66*/
 else /* Line: 67*/ {
bevl_neg = be.BECS_Runtime.boolFalse;
} /* Line: 68*/
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(-81272345, bevt_3_ta_ph);
if (bevl_dec == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_dec.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_7_ta_ph = beva_si.bemd_2(1197272072, bevt_8_ta_ph, bevl_dec);
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_ta_ph);
} /* Line: 73*/
 else /* Line: 74*/ {
bevl_lhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 75*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_10_ta_ph = bevl_dec.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = beva_si.bemd_0(-236660065);
bevt_9_ta_ph = bevt_10_ta_ph.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_ta_ph );
if (bevt_9_ta_ph.bevi_bool)/* Line: 77*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_14_ta_ph = bevl_dec.bem_add_1(bevt_15_ta_ph);
bevt_13_ta_ph = beva_si.bemd_1(1873636265, bevt_14_ta_ph);
bevl_rhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_ta_ph);
} /* Line: 78*/
 else /* Line: 79*/ {
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 80*/
} /* Line: 77*/
 else /* Line: 82*/ {
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 84*/
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_18_ta_ph = bevl_rhs.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_sizeGet_0();
bevl_divby = bevt_16_ta_ph.bem_power_1(bevt_17_ta_ph);
if (bevl_neg.bevi_bool)/* Line: 87*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_ta_ph);
} /* Line: 89*/
bevt_21_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_rhs);
bevt_22_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_divby);
bevl_rhsf = bevt_21_ta_ph.bem_divide_1(bevt_22_ta_ph);
bevl_lhsf = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_lhs);
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_intNew_1(BEC_2_4_3_MathInt beva_int) throws Throwable {

      bevi_float = (float) beva_int.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_create_0() throws Throwable {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_4_5_MathFloat) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toInt_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
BEC_2_4_5_MathFloat bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_lhi = bem_toInt_0();
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_lhi);
bevl_rh = bem_subtract_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_ta_ph);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_ta_ph = bevl_lhi.bem_toString_0();
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = bevl_rhi.bem_toString_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 163*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 175*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 183*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 195*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 203*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 215*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 223*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 235*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 243*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 255*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 263*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 275*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float == ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float != ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {64, 64, 65, 66, 66, 68, 70, 70, 71, 71, 72, 72, 72, 73, 73, 73, 75, 77, 77, 77, 77, 78, 78, 78, 78, 80, 83, 84, 86, 86, 86, 86, 88, 88, 89, 89, 91, 91, 91, 92, 93, 94, 116, 116, 119, 119, 123, 127, 127, 138, 146, 151, 151, 155, 156, 156, 157, 157, 158, 159, 159, 159, 159, 159, 159, 164, 175, 184, 195, 204, 215, 224, 235, 244, 255, 264, 275, 283, 283, 325, 325, 367, 367, 395, 395, 423, 423, 451, 451, 479, 479};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {59, 60, 62, 63, 64, 67, 69, 70, 71, 76, 77, 78, 83, 84, 85, 86, 89, 91, 92, 93, 94, 96, 97, 98, 99, 102, 106, 107, 109, 110, 111, 112, 114, 115, 116, 117, 119, 120, 121, 122, 123, 124, 133, 134, 138, 139, 142, 147, 148, 152, 153, 157, 158, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 188, 191, 198, 201, 208, 211, 218, 221, 228, 231, 238, 241, 246, 247, 256, 257, 266, 267, 276, 277, 286, 287, 296, 297, 306, 307};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 64 59
new 0 64 59
assign 1 64 60
begins 1 64 60
assign 1 65 62
new 0 65 62
assign 1 66 63
new 0 66 63
assign 1 66 64
substring 1 66 64
assign 1 68 67
new 0 68 67
assign 1 70 69
new 0 70 69
assign 1 70 70
find 1 70 70
assign 1 71 71
def 1 71 76
assign 1 72 77
new 0 72 77
assign 1 72 78
greater 1 72 83
assign 1 73 84
new 0 73 84
assign 1 73 85
substring 2 73 85
assign 1 73 86
new 1 73 86
assign 1 75 89
new 0 75 89
assign 1 77 91
new 0 77 91
assign 1 77 92
add 1 77 92
assign 1 77 93
sizeGet 0 77 93
assign 1 77 94
lesser 1 77 94
assign 1 78 96
new 0 78 96
assign 1 78 97
add 1 78 97
assign 1 78 98
substring 1 78 98
assign 1 78 99
new 1 78 99
assign 1 80 102
new 0 80 102
assign 1 83 106
new 1 83 106
assign 1 84 107
new 0 84 107
assign 1 86 109
new 0 86 109
assign 1 86 110
toString 0 86 110
assign 1 86 111
sizeGet 0 86 111
assign 1 86 112
power 1 86 112
assign 1 88 114
new 0 88 114
multiplyValue 1 88 115
assign 1 89 116
new 0 89 116
multiplyValue 1 89 117
assign 1 91 119
intNew 1 91 119
assign 1 91 120
intNew 1 91 120
assign 1 91 121
divide 1 91 121
assign 1 92 122
intNew 1 92 122
assign 1 93 123
add 1 93 123
return 1 94 124
assign 1 116 133
new 0 116 133
return 1 116 134
assign 1 119 138
toString 0 119 138
return 1 119 139
new 1 123 142
assign 1 127 147
new 0 127 147
return 1 127 148
assign 1 138 152
new 0 138 152
return 1 146 153
assign 1 151 157
toInt 0 151 157
return 1 151 158
assign 1 155 171
toInt 0 155 171
assign 1 156 172
intNew 1 156 172
assign 1 156 173
subtract 1 156 173
assign 1 157 174
new 0 157 174
assign 1 157 175
multiply 1 157 175
assign 1 158 176
toInt 0 158 176
assign 1 159 177
toString 0 159 177
assign 1 159 178
new 0 159 178
assign 1 159 179
add 1 159 179
assign 1 159 180
toString 0 159 180
assign 1 159 181
add 1 159 181
return 1 159 182
assign 1 164 188
new 0 164 188
return 1 175 191
assign 1 184 198
new 0 184 198
return 1 195 201
assign 1 204 208
new 0 204 208
return 1 215 211
assign 1 224 218
new 0 224 218
return 1 235 221
assign 1 244 228
new 0 244 228
return 1 255 231
assign 1 264 238
new 0 264 238
return 1 275 241
assign 1 283 246
new 0 283 246
return 1 283 247
assign 1 325 256
new 0 325 256
return 1 325 257
assign 1 367 266
new 0 367 266
return 1 367 267
assign 1 395 276
new 0 395 276
return 1 395 277
assign 1 423 286
new 0 423 286
return 1 423 287
assign 1 451 296
new 0 451 296
return 1 451 297
assign 1 479 306
new 0 479 306
return 1 479 307
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1581478205: return bem_iteratorGet_0();
case 448996129: return bem_classNameGet_0();
case 1620426785: return bem_fieldIteratorGet_0();
case -1243764713: return bem_sourceFileNameGet_0();
case -1564435804: return bem_new_0();
case -2046304502: return bem_create_0();
case 487655943: return bem_hashGet_0();
case 1357625949: return bem_vfloatSet_0();
case -1777728299: return bem_toInt_0();
case 440169444: return bem_tagGet_0();
case -1633309881: return bem_echo_0();
case 1998804429: return bem_deserializeClassNameGet_0();
case -2033056683: return bem_serializeToString_0();
case 526963448: return bem_vfloatGet_0();
case 1149432621: return bem_decrement_0();
case -1624889671: return bem_copy_0();
case 1308078070: return bem_increment_0();
case -1318471451: return bem_toString_0();
case -737828887: return bem_serializeContents_0();
case 1483871301: return bem_print_0();
case 1177953347: return bem_fieldNamesGet_0();
case -1142809906: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1724702365: return bem_copyTo_1(bevd_0);
case -26119566: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case -1900502363: return bem_def_1(bevd_0);
case -1767763000: return bem_sameObject_1(bevd_0);
case -1217337757: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -694118404: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case 219956342: return bem_intNew_1((BEC_2_4_3_MathInt) bevd_0);
case 965946056: return bem_sameClass_1(bevd_0);
case -245244277: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
case -48526213: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1655576193: return bem_undef_1(bevd_0);
case -1801363800: return bem_sameType_1(bevd_0);
case 574791496: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case -2082849717: return bem_new_1(bevd_0);
case 1313246293: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case -40889849: return bem_equals_1(bevd_0);
case 887328988: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -983339539: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -776802815: return bem_notEquals_1(bevd_0);
case -1344612916: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1601506198: return bem_otherClass_1(bevd_0);
case 1276126874: return bem_otherType_1(bevd_0);
case 1182018993: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case -989002532: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -180551001: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -984805442: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 162928067: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -336527550: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1644303351: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_MathFloat();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
