package be;
public class BET_2_6_19_SystemExceptionTranslator extends BETS_Object {
public BET_2_6_19_SystemExceptionTranslator() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameType_1", "otherType_1", "default_0", "translateEmittedException_1", "translateEmittedExceptionInner_1", "getSourceFileName_1", "extractKlassLib_1", "extractKlass_1", "extractKlassInner_1", "extractMethod_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] {  };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_19_SystemExceptionTranslator();
}
}
