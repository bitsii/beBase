package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_4_LogicBool extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }

   
    public boolean bevi_bool;
    public BEC_2_5_4_LogicBool(boolean bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x66,0x61,0x6C,0x73,0x65};
public static BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;

public static BET_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_type;

public BEC_2_5_4_LogicBool bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_ta_ph = beva_str.bemd_1(-257664443, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 50*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 51*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_2_ta_ph = beva_str.bemd_1(-257664443, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 57*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
 else /* Line: 57*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 58*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 68*/ {
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_1));
return bevt_0_ta_ph;
} /* Line: 69*/
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 79*/ {
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
return bevt_0_ta_ph;
} /* Line: 80*/
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 94*/ {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /* Line: 95*/
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 101*/ {
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
return bevt_0_ta_ph;
} /* Line: 102*/
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copy_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 50, 51, 51, 53, 53, 57, 57, 57, 57, 0, 0, 0, 58, 58, 60, 60, 64, 64, 69, 69, 71, 71, 75, 75, 80, 80, 82, 82, 86, 86, 90, 90, 95, 95, 97, 97, 102, 102, 104, 104, 108};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 30, 32, 33, 35, 36, 45, 50, 51, 52, 54, 57, 61, 64, 65, 67, 68, 72, 73, 79, 80, 82, 83, 87, 88, 94, 95, 97, 98, 102, 103, 107, 108, 114, 115, 117, 118, 124, 125, 127, 128, 131};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 29
new 0 50 29
assign 1 50 30
equals 1 50 30
assign 1 51 32
new 0 51 32
return 1 51 33
assign 1 53 35
new 0 53 35
return 1 53 36
assign 1 57 45
def 1 57 50
assign 1 57 51
new 0 57 51
assign 1 57 52
equals 1 57 52
assign 1 0 54
assign 1 0 57
assign 1 0 61
assign 1 58 64
new 0 58 64
return 1 58 65
assign 1 60 67
new 0 60 67
return 1 60 68
assign 1 64 72
new 0 64 72
return 1 64 73
assign 1 69 79
new 0 69 79
return 1 69 80
assign 1 71 82
new 0 71 82
return 1 71 83
assign 1 75 87
new 0 75 87
return 1 75 88
assign 1 80 94
new 0 80 94
return 1 80 95
assign 1 82 97
new 0 82 97
return 1 82 98
assign 1 86 102
new 0 86 102
return 1 86 103
assign 1 90 107
new 0 90 107
return 1 90 108
assign 1 95 114
new 0 95 114
return 1 95 115
assign 1 97 117
new 0 97 117
return 1 97 118
assign 1 102 124
new 0 102 124
return 1 102 125
assign 1 104 127
new 0 104 127
return 1 104 128
return 1 108 131
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 375906561: return bem_not_0();
case -509281348: return bem_new_0();
case 1606373658: return bem_deserializeClassNameGet_0();
case 916511308: return bem_print_0();
case 44585445: return bem_increment_0();
case -1436588716: return bem_copy_0();
case 1377393171: return bem_iteratorGet_0();
case 572942595: return bem_create_0();
case 341497811: return bem_serializeContentsGet_0();
case 593600550: return bem_toString_0();
case 1865434236: return bem_serializeToString_0();
case -593179039: return bem_hashGet_0();
case 658690764: return bem_decrement_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1008582343: return bem_new_1(bevd_0);
case 152454017: return bem_def_1(bevd_0);
case -1239385327: return bem_undef_1(bevd_0);
case 122570625: return bem_checkDefNew_1(bevd_0);
case 740081825: return bem_notEquals_1(bevd_0);
case -257664443: return bem_equals_1(bevd_0);
case -1490966740: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 376456972: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2087906856: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 426315431: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -840314986: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_LogicBool();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_type;
}
}
