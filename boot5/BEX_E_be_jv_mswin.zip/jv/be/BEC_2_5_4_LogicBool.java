package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_4_LogicBool extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }

   
    public boolean bevi_bool;
    public BEC_2_5_4_LogicBool(boolean bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x66,0x61,0x6C,0x73,0x65};
public static BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;

public static BET_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_type;

public BEC_2_5_4_LogicBool bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_ta_ph = beva_str.bemd_1(-1441152686, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 56*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 57*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 63*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_2_ta_ph = beva_str.bemd_1(-1441152686, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 63*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 63*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 63*/
 else /* Line: 63*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 63*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 64*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 74*/ {
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_1));
return bevt_0_ta_ph;
} /* Line: 75*/
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 85*/ {
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
return bevt_0_ta_ph;
} /* Line: 86*/
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 100*/ {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /* Line: 101*/
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 107*/ {
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
return bevt_0_ta_ph;
} /* Line: 108*/
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copy_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {56, 56, 57, 57, 59, 59, 63, 63, 63, 63, 0, 0, 0, 64, 64, 66, 66, 70, 70, 75, 75, 77, 77, 81, 81, 86, 86, 88, 88, 92, 92, 96, 96, 101, 101, 103, 103, 108, 108, 110, 110, 114};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 30, 32, 33, 35, 36, 45, 50, 51, 52, 54, 57, 61, 64, 65, 67, 68, 72, 73, 79, 80, 82, 83, 87, 88, 94, 95, 97, 98, 102, 103, 107, 108, 114, 115, 117, 118, 124, 125, 127, 128, 131};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 56 29
new 0 56 29
assign 1 56 30
equals 1 56 30
assign 1 57 32
new 0 57 32
return 1 57 33
assign 1 59 35
new 0 59 35
return 1 59 36
assign 1 63 45
def 1 63 50
assign 1 63 51
new 0 63 51
assign 1 63 52
equals 1 63 52
assign 1 0 54
assign 1 0 57
assign 1 0 61
assign 1 64 64
new 0 64 64
return 1 64 65
assign 1 66 67
new 0 66 67
return 1 66 68
assign 1 70 72
new 0 70 72
return 1 70 73
assign 1 75 79
new 0 75 79
return 1 75 80
assign 1 77 82
new 0 77 82
return 1 77 83
assign 1 81 87
new 0 81 87
return 1 81 88
assign 1 86 94
new 0 86 94
return 1 86 95
assign 1 88 97
new 0 88 97
return 1 88 98
assign 1 92 102
new 0 92 102
return 1 92 103
assign 1 96 107
new 0 96 107
return 1 96 108
assign 1 101 114
new 0 101 114
return 1 101 115
assign 1 103 117
new 0 103 117
return 1 103 118
assign 1 108 124
new 0 108 124
return 1 108 125
assign 1 110 127
new 0 110 127
return 1 110 128
return 1 114 131
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 760510101: return bem_serializeContentsGet_0();
case 1609182452: return bem_deserializeClassNameGet_0();
case -1277691905: return bem_create_0();
case -334139513: return bem_toString_0();
case 1406439869: return bem_iteratorGet_0();
case -1904974225: return bem_print_0();
case 323586228: return bem_hashGet_0();
case 1603718079: return bem_decrement_0();
case -582936884: return bem_copy_0();
case -1109080542: return bem_serializeToString_0();
case -1027205593: return bem_not_0();
case 2029463497: return bem_increment_0();
case -507985549: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -259329005: return bem_new_1(bevd_0);
case -900715304: return bem_notEquals_1(bevd_0);
case -1441152686: return bem_equals_1(bevd_0);
case -1564500571: return bem_def_1(bevd_0);
case 2083304692: return bem_copyTo_1(bevd_0);
case 1894221943: return bem_undef_1(bevd_0);
case -1319686455: return bem_checkDefNew_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1170875190: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -506946318: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1280428261: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2064104272: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_LogicBool();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_type;
}
}
