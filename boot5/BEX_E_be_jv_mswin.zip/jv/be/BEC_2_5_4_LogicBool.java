package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_4_LogicBool extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }

   
    public boolean bevi_bool;
    public BEC_2_5_4_LogicBool(boolean bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_5 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_6 = {0x66,0x61,0x6C,0x73,0x65};
public static BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;

public static BET_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_type;

public BEC_2_5_4_LogicBool bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(1077702335, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 43 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 44 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(1077702335, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 51 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 61 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_0_tmpany_phold;
} /* Line: 62 */
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 72 */ {
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 73 */
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 88 */
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_5));
return bevt_0_tmpany_phold;
} /* Line: 95 */
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_6));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copy_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {43, 43, 44, 44, 46, 46, 50, 50, 50, 50, 0, 0, 0, 51, 51, 53, 53, 57, 57, 62, 62, 64, 64, 68, 68, 73, 73, 75, 75, 79, 79, 83, 83, 88, 88, 90, 90, 95, 95, 97, 97, 101};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 34, 35, 37, 38, 47, 52, 53, 54, 56, 59, 63, 66, 67, 69, 70, 74, 75, 81, 82, 84, 85, 89, 90, 96, 97, 99, 100, 104, 105, 109, 110, 116, 117, 119, 120, 126, 127, 129, 130, 133};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 43 31
new 0 43 31
assign 1 43 32
equals 1 43 32
assign 1 44 34
new 0 44 34
return 1 44 35
assign 1 46 37
new 0 46 37
return 1 46 38
assign 1 50 47
def 1 50 52
assign 1 50 53
new 0 50 53
assign 1 50 54
equals 1 50 54
assign 1 0 56
assign 1 0 59
assign 1 0 63
assign 1 51 66
new 0 51 66
return 1 51 67
assign 1 53 69
new 0 53 69
return 1 53 70
assign 1 57 74
new 0 57 74
return 1 57 75
assign 1 62 81
new 0 62 81
return 1 62 82
assign 1 64 84
new 0 64 84
return 1 64 85
assign 1 68 89
new 0 68 89
return 1 68 90
assign 1 73 96
new 0 73 96
return 1 73 97
assign 1 75 99
new 0 75 99
return 1 75 100
assign 1 79 104
new 0 79 104
return 1 79 105
assign 1 83 109
new 0 83 109
return 1 83 110
assign 1 88 116
new 0 88 116
return 1 88 117
assign 1 90 119
new 0 90 119
return 1 90 120
assign 1 95 126
new 0 95 126
return 1 95 127
assign 1 97 129
new 0 97 129
return 1 97 130
return 1 101 133
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1891870089: return bem_print_0();
case -479209354: return bem_hashGet_0();
case -2026346603: return bem_new_0();
case 269301519: return bem_once_0();
case -415539380: return bem_many_0();
case 1663979256: return bem_iteratorGet_0();
case -1255628091: return bem_tagGet_0();
case -1084760201: return bem_create_0();
case -1531622162: return bem_copy_0();
case 430693877: return bem_not_0();
case -127984856: return bem_deserializeClassNameGet_0();
case 327775353: return bem_increment_0();
case 1964378555: return bem_serializeContents_0();
case 1092154910: return bem_classNameGet_0();
case -2092271774: return bem_echo_0();
case 102887971: return bem_fieldIteratorGet_0();
case 2115120452: return bem_serializeToString_0();
case -1116557455: return bem_decrement_0();
case 1670566168: return bem_sourceFileNameGet_0();
case -333394073: return bem_toString_0();
case 1154933275: return bem_serializationIteratorGet_0();
case -911546686: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2027519443: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1139979118: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1133099499: return bem_new_1(bevd_0);
case -2088579865: return bem_otherType_1(bevd_0);
case 1674374988: return bem_sameObject_1(bevd_0);
case -326579864: return bem_sameClass_1(bevd_0);
case -1574704139: return bem_copyTo_1(bevd_0);
case -266225430: return bem_notEquals_1(bevd_0);
case -1020405356: return bem_otherClass_1(bevd_0);
case -2035847518: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1077702335: return bem_equals_1(bevd_0);
case 306243422: return bem_checkDefNew_1(bevd_0);
case -605366432: return bem_defined_1(bevd_0);
case -834006616: return bem_sameType_1(bevd_0);
case -2109819584: return bem_def_1(bevd_0);
case 1980041008: return bem_undefined_1(bevd_0);
case 8626873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -91281186: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 926020368: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1571889490: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -730327046: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1129799281: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -783330142: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1456214761: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743986647: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_LogicBool();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_type;
}
}
