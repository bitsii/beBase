package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildEmit extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildEmit() { }
private static byte[] becc_BEC_2_5_4_BuildEmit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74};
private static byte[] becc_BEC_2_5_4_BuildEmit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_inst;

public static BET_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_type;

public BEC_2_4_6_TextString bevp_text;
public BEC_2_9_3_ContainerSet bevp_langs;
public BEC_2_5_4_BuildEmit bem_new_2(BEC_2_4_6_TextString beva__text, BEC_2_9_3_ContainerSet beva__langs) throws Throwable {
bevp_text = beva__text;
bevp_langs = beva__langs;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_textGet_0() throws Throwable {
return bevp_text;
} /*method end*/
public final BEC_2_4_6_TextString bem_textGetDirect_0() throws Throwable {
return bevp_text;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_text = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildEmit bem_textSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_text = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGet_0() throws Throwable {
return bevp_langs;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_langsGetDirect_0() throws Throwable {
return bevp_langs;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildEmit bem_langsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {73, 74, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 19, 22, 25, 29, 33, 36, 39, 43};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 73 14
assign 1 74 15
return 1 0 19
return 1 0 22
assign 1 0 25
assign 1 0 29
return 1 0 33
return 1 0 36
assign 1 0 39
assign 1 0 43
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -568575955: return bem_hashGet_0();
case -949462495: return bem_textGetDirect_0();
case -220602072: return bem_echo_0();
case 774721401: return bem_serializeToString_0();
case 881754957: return bem_deserializeClassNameGet_0();
case -674491561: return bem_sourceFileNameGet_0();
case -829315536: return bem_classNameGet_0();
case -1111250456: return bem_fieldNamesGet_0();
case 349052262: return bem_langsGet_0();
case 234248288: return bem_copy_0();
case -437991849: return bem_toString_0();
case -763928014: return bem_create_0();
case -419834598: return bem_print_0();
case 908703366: return bem_langsGetDirect_0();
case -1814783732: return bem_serializationIteratorGet_0();
case -18123974: return bem_new_0();
case 1087832621: return bem_tagGet_0();
case 2087607686: return bem_iteratorGet_0();
case 1126911928: return bem_serializeContents_0();
case -1454950260: return bem_fieldIteratorGet_0();
case 1816812964: return bem_textGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -643713889: return bem_notEquals_1(bevd_0);
case 453102913: return bem_langsSetDirect_1(bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case 1473652332: return bem_textSetDirect_1(bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case 1215174449: return bem_textSet_1(bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
case -24636815: return bem_langsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -243179285: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_3_ContainerSet) bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildEmit_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildEmit_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildEmit();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst = (BEC_2_5_4_BuildEmit) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_type;
}
}
