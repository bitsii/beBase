package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildEmit extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildEmit() { }
private static byte[] becc_BEC_2_5_4_BuildEmit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74};
private static byte[] becc_BEC_2_5_4_BuildEmit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_inst;

public static BET_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_type;

public BEC_2_4_6_TextString bevp_text;
public BEC_2_9_3_ContainerSet bevp_langs;
public BEC_2_5_4_BuildEmit bem_new_2(BEC_2_4_6_TextString beva__text, BEC_2_9_3_ContainerSet beva__langs) throws Throwable {
bevp_text = beva__text;
bevp_langs = beva__langs;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_textGet_0() throws Throwable {
return bevp_text;
} /*method end*/
public final BEC_2_4_6_TextString bem_textGetDirect_0() throws Throwable {
return bevp_text;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_text = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildEmit bem_textSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_text = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGet_0() throws Throwable {
return bevp_langs;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_langsGetDirect_0() throws Throwable {
return bevp_langs;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildEmit bem_langsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {73, 74, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 19, 22, 25, 29, 33, 36, 39, 43};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 73 14
assign 1 74 15
return 1 0 19
return 1 0 22
assign 1 0 25
assign 1 0 29
return 1 0 33
return 1 0 36
assign 1 0 39
assign 1 0 43
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1551415145: return bem_toAny_0();
case -1966626789: return bem_hashGet_0();
case 983736684: return bem_serializationIteratorGet_0();
case 247075507: return bem_fieldNamesGet_0();
case 750271816: return bem_textGetDirect_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case -2085574720: return bem_langsGet_0();
case 2084331281: return bem_new_0();
case -1522610135: return bem_serializeToString_0();
case -738439163: return bem_copy_0();
case 484635838: return bem_tagGet_0();
case 320622940: return bem_echo_0();
case 1969080256: return bem_once_0();
case -576502505: return bem_create_0();
case -890719598: return bem_sourceFileNameGet_0();
case 2033856471: return bem_textGet_0();
case -753430171: return bem_fieldIteratorGet_0();
case 101762581: return bem_serializeContents_0();
case -1313098664: return bem_toString_0();
case 645211302: return bem_iteratorGet_0();
case -1154464332: return bem_langsGetDirect_0();
case -2005156683: return bem_classNameGet_0();
case 690609043: return bem_print_0();
case -357139526: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1293366197: return bem_langsSet_1(bevd_0);
case -670773723: return bem_sameType_1(bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case 1327776826: return bem_langsSetDirect_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2119024237: return bem_textSet_1(bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 758604875: return bem_def_1(bevd_0);
case -559803890: return bem_notEquals_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case 538021550: return bem_textSetDirect_1(bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1910191709: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_3_ContainerSet) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildEmit_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildEmit_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildEmit();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst = (BEC_2_5_4_BuildEmit) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_type;
}
}
