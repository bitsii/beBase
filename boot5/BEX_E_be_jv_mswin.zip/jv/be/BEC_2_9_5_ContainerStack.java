package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
private static byte[] becc_BEC_2_9_5_ContainerStack_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_BEC_2_9_5_ContainerStack_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_inst;

public static BET_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_5_ContainerStack bem_new_0() throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_push_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
if (bevp_holder == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 41 */
 else  /* Line: 42 */ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 44 */
} /* Line: 40 */
 else  /* Line: 39 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_4_tmpany_phold = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 49 */
 else  /* Line: 50 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 51 */
} /* Line: 39 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_pop_0() throws Throwable {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
return bevp_top;
} /* Line: 59 */
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 63 */ {
bevp_holder = bevl_last;
} /* Line: 64 */
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
return null;
} /* Line: 67 */
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_2_6_6_SystemObject bem_peek_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 76 */ {
return bevp_top;
} /* Line: 77 */
bevt_1_tmpany_phold = bevp_top.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_pop_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_pop.bevi_bool) /* Line: 95 */ {
bevt_0_tmpany_phold = bem_pop_0();
return bevt_0_tmpany_phold;
} /* Line: 96 */
bevt_1_tmpany_phold = bem_peek_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_topGetDirect_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerStack bem_topSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() throws Throwable {
return bevp_holder;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_holderGetDirect_0() throws Throwable {
return bevp_holder;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerStack bem_holderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerStack bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {33, 39, 39, 40, 40, 41, 43, 44, 46, 46, 46, 47, 47, 48, 48, 49, 51, 53, 54, 58, 58, 59, 61, 62, 63, 63, 64, 66, 66, 67, 69, 70, 71, 72, 76, 76, 77, 79, 79, 83, 83, 87, 91, 91, 96, 96, 98, 98, 102, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 25, 30, 31, 36, 37, 40, 41, 45, 46, 51, 52, 53, 54, 55, 56, 59, 62, 63, 72, 77, 78, 80, 81, 82, 87, 88, 90, 95, 96, 98, 99, 100, 101, 106, 111, 112, 114, 115, 119, 124, 127, 132, 133, 139, 140, 142, 143, 146, 150, 153, 156, 160, 164, 167, 170, 174, 178, 181, 184, 188};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 33 15
new 0 33 15
assign 1 39 25
undef 1 39 30
assign 1 40 31
undef 1 40 36
assign 1 41 37
new 0 41 37
assign 1 43 40
assign 1 44 41
assign 1 46 45
nextGet 0 46 45
assign 1 46 46
undef 1 46 51
assign 1 47 52
new 0 47 52
nextSet 1 47 53
assign 1 48 54
nextGet 0 48 54
priorSet 1 48 55
assign 1 49 56
nextGet 0 49 56
assign 1 51 59
nextGet 0 51 59
heldSet 1 53 62
assign 1 54 63
increment 0 54 63
assign 1 58 72
undef 1 58 77
return 1 59 78
assign 1 61 80
assign 1 62 81
priorGet 0 62 81
assign 1 63 82
undef 1 63 87
assign 1 64 88
assign 1 66 90
undef 1 66 95
return 1 67 96
assign 1 69 98
heldGet 0 69 98
heldSet 1 70 99
assign 1 71 100
decrement 0 71 100
return 1 72 101
assign 1 76 106
undef 1 76 111
return 1 77 112
assign 1 79 114
heldGet 0 79 114
return 1 79 115
assign 1 83 119
undef 1 83 124
return 1 83 124
push 1 87 127
assign 1 91 132
pop 0 91 132
return 1 91 133
assign 1 96 139
pop 0 96 139
return 1 96 140
assign 1 98 142
peek 0 98 142
return 1 98 143
push 1 102 146
return 1 0 150
return 1 0 153
assign 1 0 156
assign 1 0 160
return 1 0 164
return 1 0 167
assign 1 0 170
assign 1 0 174
return 1 0 178
return 1 0 181
assign 1 0 184
assign 1 0 188
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1439777293: return bem_hashGet_0();
case -1476019175: return bem_toString_0();
case 1935136194: return bem_classNameGet_0();
case 117483359: return bem_pop_0();
case -2078446374: return bem_holderGet_0();
case 742371580: return bem_serializeToString_0();
case 944362296: return bem_peek_0();
case 1516161879: return bem_fieldNamesGet_0();
case -2054232949: return bem_isEmptyGet_0();
case -1992389260: return bem_sizeGetDirect_0();
case -1750213491: return bem_sourceFileNameGet_0();
case 1385408840: return bem_topGetDirect_0();
case -2070113098: return bem_create_0();
case -1034105613: return bem_sizeGet_0();
case -61288189: return bem_serializationIteratorGet_0();
case -1270658169: return bem_get_0();
case 1660533487: return bem_serializeContents_0();
case -1294783770: return bem_holderGetDirect_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case 1830640205: return bem_topGet_0();
case 1730802409: return bem_echo_0();
case 1326542704: return bem_tagGet_0();
case -948982310: return bem_many_0();
case 1070146794: return bem_toAny_0();
case 450230894: return bem_print_0();
case 623957818: return bem_once_0();
case -2073027086: return bem_fieldIteratorGet_0();
case -897350462: return bem_iteratorGet_0();
case 1172450247: return bem_copy_0();
case -1556712456: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -299391132: return bem_equals_1(bevd_0);
case -645884100: return bem_sizeSetDirect_1(bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case 208170341: return bem_sizeSet_1(bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -957438933: return bem_undef_1(bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1650911412: return bem_topSetDirect_1(bevd_0);
case 1686794148: return bem_addValue_1(bevd_0);
case -1944182839: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case 1872675791: return bem_topSet_1(bevd_0);
case -2129940862: return bem_holderSet_1(bevd_0);
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -42191711: return bem_push_1(bevd_0);
case -41846578: return bem_holderSetDirect_1(bevd_0);
case 137404796: return bem_put_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerStack_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerStack_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerStack();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst = (BEC_2_9_5_ContainerStack) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_type;
}
}
