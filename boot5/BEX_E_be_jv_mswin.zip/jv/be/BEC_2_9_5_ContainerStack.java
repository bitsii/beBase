package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
private static byte[] becc_BEC_2_9_5_ContainerStack_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_BEC_2_9_5_ContainerStack_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_inst;

public static BET_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_9_5_ContainerStack bem_new_0() throws Throwable {
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_push_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevp_holder == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 45*/ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 46*/
 else /* Line: 47*/ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 49*/
} /* Line: 45*/
 else /* Line: 44*/ {
bevt_3_ta_ph = bevp_top.bem_nextGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_4_ta_ph = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_ta_ph);
bevt_5_ta_ph = bevp_top.bem_nextGet_0();
bevt_5_ta_ph.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 54*/
 else /* Line: 55*/ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 56*/
} /* Line: 44*/
bevp_top.bem_heldSet_1(beva_item);
bevp_length.bevi_int++;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_pop_0() throws Throwable {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 63*/ {
return bevp_top;
} /* Line: 64*/
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 68*/ {
bevp_holder = bevl_last;
} /* Line: 69*/
if (bevl_last == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 71*/ {
return null;
} /* Line: 72*/
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_length = bevp_length.bem_subtract_1(bevt_3_ta_ph);
return bevl_item;
} /*method end*/
public BEC_2_6_6_SystemObject bem_peek_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 81*/ {
return bevp_top;
} /* Line: 82*/
bevt_1_ta_ph = bevp_top.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_pop_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_pop.bevi_bool)/* Line: 100*/ {
bevt_0_ta_ph = bem_pop_0();
return bevt_0_ta_ph;
} /* Line: 101*/
bevt_1_ta_ph = bem_peek_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() throws Throwable {
return bevp_holder;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_lengthSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 44, 44, 45, 45, 46, 48, 49, 51, 51, 51, 52, 52, 53, 53, 54, 56, 58, 59, 63, 63, 64, 66, 67, 68, 68, 69, 71, 71, 72, 74, 75, 76, 76, 77, 81, 81, 82, 84, 84, 88, 88, 92, 96, 96, 101, 101, 103, 103, 107, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 25, 30, 31, 36, 37, 40, 41, 45, 46, 51, 52, 53, 54, 55, 56, 59, 62, 63, 73, 78, 79, 81, 82, 83, 88, 89, 91, 96, 97, 99, 100, 101, 102, 103, 108, 113, 114, 116, 117, 121, 126, 129, 134, 135, 141, 142, 144, 145, 148, 152, 155, 159, 162, 166, 169};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 38 15
new 0 38 15
assign 1 44 25
undef 1 44 30
assign 1 45 31
undef 1 45 36
assign 1 46 37
new 0 46 37
assign 1 48 40
assign 1 49 41
assign 1 51 45
nextGet 0 51 45
assign 1 51 46
undef 1 51 51
assign 1 52 52
new 0 52 52
nextSet 1 52 53
assign 1 53 54
nextGet 0 53 54
priorSet 1 53 55
assign 1 54 56
nextGet 0 54 56
assign 1 56 59
nextGet 0 56 59
heldSet 1 58 62
incrementValue 0 59 63
assign 1 63 73
undef 1 63 78
return 1 64 79
assign 1 66 81
assign 1 67 82
priorGet 0 67 82
assign 1 68 83
undef 1 68 88
assign 1 69 89
assign 1 71 91
undef 1 71 96
return 1 72 97
assign 1 74 99
heldGet 0 74 99
heldSet 1 75 100
assign 1 76 101
new 0 76 101
assign 1 76 102
subtract 1 76 102
return 1 77 103
assign 1 81 108
undef 1 81 113
return 1 82 114
assign 1 84 116
heldGet 0 84 116
return 1 84 117
assign 1 88 121
undef 1 88 126
return 1 88 126
push 1 92 129
assign 1 96 134
pop 0 96 134
return 1 96 135
assign 1 101 141
pop 0 101 141
return 1 101 142
assign 1 103 144
peek 0 103 144
return 1 103 145
push 1 107 148
return 1 0 152
assign 1 0 155
return 1 0 159
assign 1 0 162
return 1 0 166
assign 1 0 169
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 27114394: return bem_print_0();
case -1998646518: return bem_peek_0();
case -1660233505: return bem_pop_0();
case 1355394891: return bem_isEmptyGet_0();
case -1210391199: return bem_hashGet_0();
case -422301686: return bem_topGet_0();
case -3696567: return bem_toString_0();
case 1384394184: return bem_get_0();
case 468526570: return bem_create_0();
case 175319242: return bem_new_0();
case 1297936052: return bem_copy_0();
case -1129764700: return bem_iteratorGet_0();
case 776623109: return bem_holderGet_0();
case -2142154812: return bem_lengthGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1641668784: return bem_undef_1(bevd_0);
case 330128663: return bem_equals_1(bevd_0);
case 1648438907: return bem_push_1(bevd_0);
case -533272258: return bem_lengthSet_1(bevd_0);
case 1819590399: return bem_put_1(bevd_0);
case -1530235192: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case 154638958: return bem_addValue_1(bevd_0);
case 1008927034: return bem_holderSet_1(bevd_0);
case -157602172: return bem_def_1(bevd_0);
case -1744328658: return bem_copyTo_1(bevd_0);
case -5249142: return bem_print_1(bevd_0);
case 855772472: return bem_topSet_1(bevd_0);
case -1580502557: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 649083490: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -246805044: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 449759328: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1978266947: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerStack_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerStack_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerStack();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst = (BEC_2_9_5_ContainerStack) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_type;
}
}
