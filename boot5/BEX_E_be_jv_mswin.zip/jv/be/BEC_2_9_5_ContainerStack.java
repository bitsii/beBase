package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
private static byte[] becc_BEC_2_9_5_ContainerStack_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_BEC_2_9_5_ContainerStack_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_inst;

public static BET_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_5_ContainerStack bem_new_0() throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_push_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 38*/ {
if (bevp_holder == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 39*/ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 40*/
 else /* Line: 41*/ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 43*/
} /* Line: 39*/
 else /* Line: 38*/ {
bevt_3_ta_ph = bevp_top.bem_nextGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 45*/ {
bevt_4_ta_ph = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_ta_ph);
bevt_5_ta_ph = bevp_top.bem_nextGet_0();
bevt_5_ta_ph.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 48*/
 else /* Line: 49*/ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 50*/
} /* Line: 38*/
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_pop_0() throws Throwable {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 57*/ {
return bevp_top;
} /* Line: 58*/
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 62*/ {
bevp_holder = bevl_last;
} /* Line: 63*/
if (bevl_last == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 65*/ {
return null;
} /* Line: 66*/
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_2_6_6_SystemObject bem_peek_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 75*/ {
return bevp_top;
} /* Line: 76*/
bevt_1_ta_ph = bevp_top.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_pop_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_pop.bevi_bool)/* Line: 94*/ {
bevt_0_ta_ph = bem_pop_0();
return bevt_0_ta_ph;
} /* Line: 95*/
bevt_1_ta_ph = bem_peek_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() throws Throwable {
return bevp_holder;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {32, 38, 38, 39, 39, 40, 42, 43, 45, 45, 45, 46, 46, 47, 47, 48, 50, 52, 53, 57, 57, 58, 60, 61, 62, 62, 63, 65, 65, 66, 68, 69, 70, 71, 75, 75, 76, 78, 78, 82, 82, 86, 90, 90, 95, 95, 97, 97, 101, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 25, 30, 31, 36, 37, 40, 41, 45, 46, 51, 52, 53, 54, 55, 56, 59, 62, 63, 72, 77, 78, 80, 81, 82, 87, 88, 90, 95, 96, 98, 99, 100, 101, 106, 111, 112, 114, 115, 119, 124, 127, 132, 133, 139, 140, 142, 143, 146, 150, 153, 157, 160, 164, 167};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 32 15
new 0 32 15
assign 1 38 25
undef 1 38 30
assign 1 39 31
undef 1 39 36
assign 1 40 37
new 0 40 37
assign 1 42 40
assign 1 43 41
assign 1 45 45
nextGet 0 45 45
assign 1 45 46
undef 1 45 51
assign 1 46 52
new 0 46 52
nextSet 1 46 53
assign 1 47 54
nextGet 0 47 54
priorSet 1 47 55
assign 1 48 56
nextGet 0 48 56
assign 1 50 59
nextGet 0 50 59
heldSet 1 52 62
assign 1 53 63
increment 0 53 63
assign 1 57 72
undef 1 57 77
return 1 58 78
assign 1 60 80
assign 1 61 81
priorGet 0 61 81
assign 1 62 82
undef 1 62 87
assign 1 63 88
assign 1 65 90
undef 1 65 95
return 1 66 96
assign 1 68 98
heldGet 0 68 98
heldSet 1 69 99
assign 1 70 100
decrement 0 70 100
return 1 71 101
assign 1 75 106
undef 1 75 111
return 1 76 112
assign 1 78 114
heldGet 0 78 114
return 1 78 115
assign 1 82 119
undef 1 82 124
return 1 82 124
push 1 86 127
assign 1 90 132
pop 0 90 132
return 1 90 133
assign 1 95 139
pop 0 95 139
return 1 95 140
assign 1 97 142
peek 0 97 142
return 1 97 143
push 1 101 146
return 1 0 150
assign 1 0 153
return 1 0 157
assign 1 0 160
return 1 0 164
assign 1 0 167
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1123564946: return bem_create_0();
case 258048906: return bem_get_0();
case -1288085492: return bem_copy_0();
case 900720046: return bem_tagGet_0();
case -39207367: return bem_sizeGet_0();
case -547430364: return bem_toString_0();
case -330424784: return bem_hashGet_0();
case 638877279: return bem_peek_0();
case -372838528: return bem_new_0();
case 1296887765: return bem_classNameGet_0();
case 324152124: return bem_print_0();
case 573468328: return bem_pop_0();
case 191100016: return bem_topGet_0();
case -1749538708: return bem_isEmptyGet_0();
case 1315317601: return bem_fieldNamesGet_0();
case 5608928: return bem_holderGet_0();
case 884317404: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1290374989: return bem_undef_1(bevd_0);
case 1912890932: return bem_equals_1(bevd_0);
case -1131970751: return bem_addValue_1(bevd_0);
case 113467266: return bem_holderSet_1(bevd_0);
case 592595513: return bem_sameType_1(bevd_0);
case -1825986767: return bem_otherType_1(bevd_0);
case -326004565: return bem_sizeSet_1(bevd_0);
case 1863587245: return bem_notEquals_1(bevd_0);
case -2119494398: return bem_def_1(bevd_0);
case -1799609678: return bem_sameObject_1(bevd_0);
case -158673770: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1862342797: return bem_copyTo_1(bevd_0);
case 1043421567: return bem_push_1(bevd_0);
case 1040579525: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case 475200360: return bem_put_1(bevd_0);
case -1578741561: return bem_topSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1154474937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1719469512: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 3383792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -601625846: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826572174: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerStack_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerStack_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerStack();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst = (BEC_2_9_5_ContainerStack) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_type;
}
}
