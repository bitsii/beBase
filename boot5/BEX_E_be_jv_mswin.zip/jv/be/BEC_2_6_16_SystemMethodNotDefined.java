package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_16_SystemMethodNotDefined extends BEC_2_6_9_SystemException {
public BEC_2_6_16_SystemMethodNotDefined() { }
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;

public static BET_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1585508844: return bem_lineNumberGetDirect_0();
case 1645085472: return bem_translateEmittedExceptionInner_0();
case 1677978563: return bem_lineNumberGet_0();
case 1215735159: return bem_classNameGet_0();
case -104397235: return bem_descriptionGet_0();
case -645319300: return bem_translatedGet_0();
case 1129503343: return bem_once_0();
case 1873437475: return bem_framesGet_0();
case 1696646828: return bem_translatedGetDirect_0();
case 1333639477: return bem_emitLangGetDirect_0();
case -1677419910: return bem_create_0();
case -1437550559: return bem_serializeContents_0();
case 2074989171: return bem_emitLangGet_0();
case -284999675: return bem_toAny_0();
case -1605431584: return bem_tagGet_0();
case -1877710991: return bem_langGet_0();
case -429437759: return bem_sourceFileNameGet_0();
case -1598978019: return bem_fileNameGet_0();
case -2069102102: return bem_toString_0();
case -1963445824: return bem_framesTextGet_0();
case 1649909626: return bem_klassNameGet_0();
case -1273555059: return bem_methodNameGet_0();
case -1401919433: return bem_descriptionGetDirect_0();
case -1232907801: return bem_iteratorGet_0();
case 1128309210: return bem_vvGetDirect_0();
case -104046264: return bem_framesGetDirect_0();
case 1029860087: return bem_fieldNamesGet_0();
case 1649954317: return bem_serializeToString_0();
case 338981101: return bem_klassNameGetDirect_0();
case -807136087: return bem_translateEmittedException_0();
case 321704245: return bem_print_0();
case 2117639469: return bem_echo_0();
case -1561145816: return bem_hashGet_0();
case 602097122: return bem_deserializeClassNameGet_0();
case 444831026: return bem_serializationIteratorGet_0();
case -1055677288: return bem_fieldIteratorGet_0();
case 57159682: return bem_new_0();
case 1644000934: return bem_copy_0();
case -368755902: return bem_fileNameGetDirect_0();
case 682888081: return bem_langGetDirect_0();
case -1950549268: return bem_framesTextGetDirect_0();
case 1040034753: return bem_methodNameGetDirect_0();
case 55315205: return bem_many_0();
case 843299757: return bem_vvGet_0();
case -740459199: return bem_getFrameText_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 784639112: return bem_descriptionSetDirect_1(bevd_0);
case -334037027: return bem_methodNameSet_1(bevd_0);
case -1063896747: return bem_translatedSetDirect_1(bevd_0);
case -962669917: return bem_otherType_1(bevd_0);
case -1744011203: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 261567939: return bem_descriptionSet_1(bevd_0);
case -1988005274: return bem_sameObject_1(bevd_0);
case 493426545: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1780672244: return bem_framesTextSetDirect_1(bevd_0);
case -740299402: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1366553936: return bem_undef_1(bevd_0);
case -1991826429: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -538924443: return bem_framesSetDirect_1(bevd_0);
case 1375171854: return bem_fileNameSet_1(bevd_0);
case 1251069176: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -278045884: return bem_langSetDirect_1(bevd_0);
case -1371671937: return bem_undefined_1(bevd_0);
case 442724165: return bem_methodNameSetDirect_1(bevd_0);
case 1203750424: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -428476289: return bem_framesTextSet_1(bevd_0);
case -1344358690: return bem_vvSet_1(bevd_0);
case 208310867: return bem_def_1(bevd_0);
case -2054826081: return bem_langSet_1(bevd_0);
case -1846874299: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -756536057: return bem_otherClass_1(bevd_0);
case -819039527: return bem_framesSet_1(bevd_0);
case -1469684100: return bem_translatedSet_1(bevd_0);
case -590532912: return bem_new_1(bevd_0);
case 1170989639: return bem_fileNameSetDirect_1(bevd_0);
case -2016639297: return bem_vvSetDirect_1(bevd_0);
case 650080222: return bem_notEquals_1(bevd_0);
case -1675438428: return bem_lineNumberSet_1(bevd_0);
case -1708339679: return bem_emitLangSet_1(bevd_0);
case -1422291148: return bem_sameClass_1(bevd_0);
case 353356681: return bem_lineNumberSetDirect_1(bevd_0);
case 224267579: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -97426471: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 38769398: return bem_klassNameSet_1(bevd_0);
case 91348: return bem_emitLangSetDirect_1(bevd_0);
case 1521573585: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1484718882: return bem_copyTo_1(bevd_0);
case 1178220548: return bem_sameType_1(bevd_0);
case 1602696702: return bem_equals_1(bevd_0);
case -931172109: return bem_klassNameSetDirect_1(bevd_0);
case 1719096215: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1950811501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959141176: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281973651: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -12510800: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220358760: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 36705687: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -533377424: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1136323837: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemMethodNotDefined_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemMethodNotDefined_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemMethodNotDefined();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst = (BEC_2_6_16_SystemMethodNotDefined) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;
}
}
