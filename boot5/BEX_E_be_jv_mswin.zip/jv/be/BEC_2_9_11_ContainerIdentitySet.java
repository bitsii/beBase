package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet extends BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public BEC_2_9_11_ContainerIdentitySet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentitySet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {198, 198, 202, 203, 204, 205, 206, 207};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 198 13
new 0 198 13
new 1 198 14
assign 1 202 18
new 1 202 18
assign 1 203 19
assign 1 204 20
new 0 204 20
assign 1 205 21
new 0 205 21
assign 1 206 22
new 0 206 22
assign 1 207 23
new 0 207 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1574006018: return bem_new_0();
case 1400956038: return bem_iteratorGet_0();
case -338202822: return bem_deserializeClassNameGet_0();
case -63388045: return bem_innerPutAddedGet_0();
case -931704592: return bem_nodeIteratorGet_0();
case 1221020955: return bem_multiGet_0();
case -1772053083: return bem_slotsGetDirect_0();
case -353923806: return bem_setIteratorGet_0();
case 1982260447: return bem_copy_0();
case 64969569: return bem_isEmptyGet_0();
case -436425250: return bem_sourceFileNameGet_0();
case -153348132: return bem_clear_0();
case 1375821928: return bem_serializeToString_0();
case 55049320: return bem_print_0();
case -426939704: return bem_keysGet_0();
case -2063813825: return bem_relGetDirect_0();
case 1940846657: return bem_nodesGet_0();
case 411688773: return bem_toString_0();
case -1045716169: return bem_baseNodeGetDirect_0();
case 879231054: return bem_classNameGet_0();
case -74182749: return bem_serializationIteratorGet_0();
case -464277223: return bem_sizeGetDirect_0();
case -272002283: return bem_serializeContents_0();
case 1862506291: return bem_notEmptyGet_0();
case -1609947385: return bem_echo_0();
case 1843425914: return bem_multiGetDirect_0();
case 2111340989: return bem_moduGet_0();
case 115209925: return bem_fieldIteratorGet_0();
case -2019788295: return bem_fieldNamesGet_0();
case 2127162183: return bem_relGet_0();
case 241030035: return bem_innerPutAddedGetDirect_0();
case -1273376981: return bem_keyIteratorGet_0();
case -1188577496: return bem_sizeGet_0();
case -1370457182: return bem_tagGet_0();
case 2045133666: return bem_moduGetDirect_0();
case 77682213: return bem_hashGet_0();
case -1445643632: return bem_baseNodeGet_0();
case -660861106: return bem_create_0();
case 516529341: return bem_slotsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1186857031: return bem_slotsSetDirect_1(bevd_0);
case -1903892968: return bem_equals_1(bevd_0);
case 943901544: return bem_baseNodeSet_1(bevd_0);
case -318666284: return bem_addValue_1(bevd_0);
case 138356423: return bem_innerPutAddedSet_1(bevd_0);
case 1277553622: return bem_def_1(bevd_0);
case -292252818: return bem_undef_1(bevd_0);
case 1716403917: return bem_relSet_1(bevd_0);
case -643607421: return bem_relSetDirect_1(bevd_0);
case 1724041773: return bem_notEquals_1(bevd_0);
case 691163553: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1020423162: return bem_otherClass_1(bevd_0);
case 843541338: return bem_sameObject_1(bevd_0);
case 103695285: return bem_has_1(bevd_0);
case 699493009: return bem_put_1(bevd_0);
case 1353776886: return bem_delete_1(bevd_0);
case -1547233575: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1386418824: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 420068993: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -545796780: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1253673578: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1030354071: return bem_moduSet_1(bevd_0);
case -1937138440: return bem_moduSetDirect_1(bevd_0);
case 1279545719: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1345869400: return bem_multiSet_1(bevd_0);
case 1560006190: return bem_copyTo_1(bevd_0);
case 1541786617: return bem_multiSetDirect_1(bevd_0);
case 1706172624: return bem_sameType_1(bevd_0);
case 462653776: return bem_sameClass_1(bevd_0);
case -1599697707: return bem_get_1(bevd_0);
case -1598460472: return bem_slotsSet_1(bevd_0);
case -2028195342: return bem_sizeSet_1(bevd_0);
case 1531126746: return bem_otherType_1(bevd_0);
case 1423522577: return bem_sizeSetDirect_1(bevd_0);
case -896451798: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 862684889: return bem_baseNodeSetDirect_1(bevd_0);
case -850580322: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -615227441: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1397786085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1432975146: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 861664880: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 53516876: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -860737988: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1645563126: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1362496456: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentitySet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
