package be;
/* IO:File: source/extended/IdentityMap.be */
public class BEC_2_9_11_ContainerIdentitySet extends BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public BEC_2_9_11_ContainerIdentitySet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentitySet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {53, 53, 57, 58, 59, 60, 61, 62};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 53 13
new 0 53 13
new 1 53 14
assign 1 57 18
new 1 57 18
assign 1 58 19
assign 1 59 20
new 0 59 20
assign 1 60 21
new 0 60 21
assign 1 61 22
new 0 61 22
assign 1 62 23
new 0 62 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1171263176: return bem_keyIteratorGet_0();
case -194091656: return bem_lengthGet_0();
case -2099206744: return bem_bucketsGet_0();
case -726695576: return bem_nodesGet_0();
case 1813340744: return bem_clear_0();
case 1734159100: return bem_new_0();
case -1492973205: return bem_print_0();
case 1684487791: return bem_notEmptyGet_0();
case -141337529: return bem_keysGet_0();
case -1353502575: return bem_serializeToString_0();
case -1868791417: return bem_create_0();
case -1378154513: return bem_copy_0();
case -844392836: return bem_isEmptyGet_0();
case 1262062337: return bem_serializationIteratorGet_0();
case 515382575: return bem_setIteratorGet_0();
case -341701962: return bem_iteratorGet_0();
case 1394706579: return bem_hashGet_0();
case -1251189415: return bem_toString_0();
case -1765713317: return bem_nodeIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1157425186: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 224732862: return bem_notEquals_1(bevd_0);
case 1390175952: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -572955748: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -41647352: return bem_def_1(bevd_0);
case 764483733: return bem_equals_1(bevd_0);
case -1228751490: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1504859590: return bem_copyTo_1(bevd_0);
case 793234925: return bem_has_1(bevd_0);
case -713228789: return bem_remove_1(bevd_0);
case 131379166: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 204667868: return bem_lengthSet_1(bevd_0);
case 404631763: return bem_undef_1(bevd_0);
case 212925280: return bem_print_1(bevd_0);
case 893493600: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1249996495: return bem_get_1(bevd_0);
case -589620627: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -353931520: return bem_put_1(bevd_0);
case 1860522272: return bem_bucketsSet_1(bevd_0);
case -1974808983: return bem_addValue_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 248233783: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 717909815: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1423582782: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -418624509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -861820000: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1951287585: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentitySet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
