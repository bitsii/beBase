package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_10_SystemCallOnNull extends BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public BEC_2_6_10_SystemCallOnNull bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {366};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 366 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1222234212: return bem_once_0();
case 1045311106: return bem_methodNameGetDirect_0();
case 667228902: return bem_create_0();
case -631740911: return bem_toAny_0();
case -675749221: return bem_deserializeClassNameGet_0();
case 1532059915: return bem_hashGet_0();
case -372207069: return bem_echo_0();
case -452044496: return bem_lineNumberGet_0();
case 1825844278: return bem_translateEmittedException_0();
case -2035861766: return bem_descriptionGetDirect_0();
case -1706263574: return bem_translatedGet_0();
case -1434554234: return bem_serializeToString_0();
case 2131047963: return bem_klassNameGetDirect_0();
case 903242673: return bem_serializeContents_0();
case -808119328: return bem_print_0();
case -181121720: return bem_new_0();
case 1731345338: return bem_tagGet_0();
case 1349762673: return bem_langGetDirect_0();
case -1308664059: return bem_emitLangGet_0();
case 1436371059: return bem_translatedGetDirect_0();
case -308219819: return bem_langGet_0();
case -1204329180: return bem_fileNameGet_0();
case 790896694: return bem_framesGet_0();
case 731931174: return bem_methodNameGet_0();
case -1501498652: return bem_vvGet_0();
case 1563841630: return bem_descriptionGet_0();
case 116064121: return bem_fieldIteratorGet_0();
case -85003513: return bem_klassNameGet_0();
case -160388737: return bem_framesTextGetDirect_0();
case 201401408: return bem_iteratorGet_0();
case 1443369362: return bem_copy_0();
case 1497839510: return bem_classNameGet_0();
case -1910957235: return bem_lineNumberGetDirect_0();
case -1055231588: return bem_getFrameText_0();
case 1450313765: return bem_framesGetDirect_0();
case -1472143729: return bem_emitLangGetDirect_0();
case 1437342193: return bem_many_0();
case 1365890250: return bem_serializationIteratorGet_0();
case -584480983: return bem_translateEmittedExceptionInner_0();
case -1748499168: return bem_framesTextGet_0();
case -1443677114: return bem_vvGetDirect_0();
case -213179861: return bem_fieldNamesGet_0();
case -267998581: return bem_fileNameGetDirect_0();
case 1218813014: return bem_sourceFileNameGet_0();
case 304904756: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1286672064: return bem_methodNameSetDirect_1(bevd_0);
case -1960916636: return bem_notEquals_1(bevd_0);
case 1184383242: return bem_framesSet_1(bevd_0);
case 602159275: return bem_emitLangSet_1(bevd_0);
case -978418301: return bem_klassNameSet_1(bevd_0);
case 485277844: return bem_undef_1(bevd_0);
case 317083389: return bem_vvSet_1(bevd_0);
case -1766567016: return bem_methodNameSet_1(bevd_0);
case 381288505: return bem_def_1(bevd_0);
case 1477350298: return bem_otherType_1(bevd_0);
case -1752785187: return bem_langSet_1(bevd_0);
case -762080958: return bem_translatedSet_1(bevd_0);
case -1783793084: return bem_langSetDirect_1(bevd_0);
case -476647557: return bem_translatedSetDirect_1(bevd_0);
case -349869299: return bem_descriptionSetDirect_1(bevd_0);
case -1397213195: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1674224941: return bem_undefined_1(bevd_0);
case 1801074654: return bem_sameType_1(bevd_0);
case -1883300982: return bem_defined_1(bevd_0);
case -1112415428: return bem_otherClass_1(bevd_0);
case 1237765671: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1464177031: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 985980328: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 48512687: return bem_equals_1(bevd_0);
case 1292810160: return bem_vvSetDirect_1(bevd_0);
case -6903784: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1838294238: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1371778661: return bem_framesSetDirect_1(bevd_0);
case 1485967678: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1755663349: return bem_new_1(bevd_0);
case 153923337: return bem_klassNameSetDirect_1(bevd_0);
case 1083465259: return bem_emitLangSetDirect_1(bevd_0);
case -1661813372: return bem_lineNumberSet_1(bevd_0);
case -888106488: return bem_fileNameSetDirect_1(bevd_0);
case 1052252305: return bem_framesTextSetDirect_1(bevd_0);
case -1771325326: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1045546721: return bem_sameObject_1(bevd_0);
case -1186867352: return bem_sameClass_1(bevd_0);
case 853807694: return bem_fileNameSet_1(bevd_0);
case -1394542869: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -71227052: return bem_copyTo_1(bevd_0);
case -980861284: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -276994568: return bem_lineNumberSetDirect_1(bevd_0);
case 1786672918: return bem_descriptionSet_1(bevd_0);
case 1363002352: return bem_framesTextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2106641120: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 219701968: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 859481713: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1909968647: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -803774767: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -545558457: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116867693: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 184485274: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemCallOnNull();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
