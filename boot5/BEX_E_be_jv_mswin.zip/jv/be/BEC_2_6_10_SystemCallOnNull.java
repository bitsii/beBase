package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_10_SystemCallOnNull extends BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public BEC_2_6_10_SystemCallOnNull bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {366};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 366 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -898304671: return bem_fieldNamesGet_0();
case -863525225: return bem_translateEmittedException_0();
case 1316670529: return bem_classNameGet_0();
case 1903226604: return bem_langGetDirect_0();
case 1792226311: return bem_getFrameText_0();
case -1730322823: return bem_klassNameGet_0();
case -93449420: return bem_once_0();
case -1836675075: return bem_hashGet_0();
case 1624463967: return bem_langGet_0();
case -2000869502: return bem_deserializeClassNameGet_0();
case -312557248: return bem_copy_0();
case -904008064: return bem_serializationIteratorGet_0();
case -2054180438: return bem_tagGet_0();
case -1345920383: return bem_serializeToString_0();
case -1166316372: return bem_methodNameGetDirect_0();
case 2117203114: return bem_framesGetDirect_0();
case 803852462: return bem_framesTextGetDirect_0();
case -1342098450: return bem_emitLangGetDirect_0();
case 1625612669: return bem_translatedGet_0();
case -1370488335: return bem_toString_0();
case 2077899298: return bem_print_0();
case 1022025389: return bem_emitLangGet_0();
case 674241091: return bem_iteratorGet_0();
case 1222739605: return bem_klassNameGetDirect_0();
case 1881905203: return bem_fileNameGetDirect_0();
case 785988623: return bem_vvGet_0();
case 1629480637: return bem_framesTextGet_0();
case -495078683: return bem_lineNumberGet_0();
case 1921834118: return bem_sourceFileNameGet_0();
case -786839283: return bem_fileNameGet_0();
case 1144594612: return bem_toAny_0();
case -1223303034: return bem_serializeContents_0();
case 286661224: return bem_descriptionGetDirect_0();
case 716443142: return bem_framesGet_0();
case 1670974898: return bem_methodNameGet_0();
case 1923816180: return bem_create_0();
case -740958985: return bem_echo_0();
case -538312537: return bem_fieldIteratorGet_0();
case 828559917: return bem_descriptionGet_0();
case 246106171: return bem_lineNumberGetDirect_0();
case -1463210484: return bem_new_0();
case -941978129: return bem_vvGetDirect_0();
case 811099383: return bem_translateEmittedExceptionInner_0();
case 1544079043: return bem_many_0();
case -2124926891: return bem_translatedGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 729928312: return bem_translatedSet_1(bevd_0);
case 1297297623: return bem_lineNumberSetDirect_1(bevd_0);
case 942435111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -249106311: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 532034178: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1252379441: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 2097773822: return bem_framesSet_1(bevd_0);
case 435359643: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 905739562: return bem_vvSetDirect_1(bevd_0);
case 989265354: return bem_descriptionSetDirect_1(bevd_0);
case -640296056: return bem_notEquals_1(bevd_0);
case -1293937271: return bem_new_1(bevd_0);
case 547127118: return bem_emitLangSet_1(bevd_0);
case 247984224: return bem_fileNameSet_1(bevd_0);
case -326265603: return bem_translatedSetDirect_1(bevd_0);
case 675409179: return bem_sameObject_1(bevd_0);
case 1761949929: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1653391659: return bem_framesTextSetDirect_1(bevd_0);
case -725822739: return bem_methodNameSet_1(bevd_0);
case 1893585148: return bem_sameType_1(bevd_0);
case -1086398098: return bem_defined_1(bevd_0);
case -1467788359: return bem_fileNameSetDirect_1(bevd_0);
case -1120344169: return bem_def_1(bevd_0);
case -996843138: return bem_framesSetDirect_1(bevd_0);
case 695119577: return bem_emitLangSetDirect_1(bevd_0);
case -164720496: return bem_sameClass_1(bevd_0);
case -1755509471: return bem_otherClass_1(bevd_0);
case 1721403717: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1411392795: return bem_undefined_1(bevd_0);
case 1305486032: return bem_equals_1(bevd_0);
case -1074844967: return bem_methodNameSetDirect_1(bevd_0);
case 1667139549: return bem_descriptionSet_1(bevd_0);
case -1210302515: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -142570143: return bem_framesTextSet_1(bevd_0);
case 1454233311: return bem_langSetDirect_1(bevd_0);
case -1491655860: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -588775114: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -816354501: return bem_klassNameSetDirect_1(bevd_0);
case -227789211: return bem_copyTo_1(bevd_0);
case 2102873722: return bem_lineNumberSet_1(bevd_0);
case 1136905977: return bem_undef_1(bevd_0);
case -257057695: return bem_otherType_1(bevd_0);
case 355489083: return bem_langSet_1(bevd_0);
case -1045508782: return bem_klassNameSet_1(bevd_0);
case -1764937516: return bem_vvSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -882013396: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 265265077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1327331293: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -305196806: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 341335680: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2006332895: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1214675142: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -815093120: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemCallOnNull();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
