package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_10_SystemCallOnNull extends BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public BEC_2_6_10_SystemCallOnNull bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {391};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 391 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -381740729: return bem_deserializeClassNameGet_0();
case 322973431: return bem_print_0();
case -769089970: return bem_framesGet_0();
case -1569222986: return bem_fieldIteratorGet_0();
case -1696513818: return bem_emitLangGetDirect_0();
case -2020124976: return bem_lineNumberGetDirect_0();
case 678571136: return bem_many_0();
case -753644705: return bem_hashGet_0();
case 364235321: return bem_echo_0();
case 154418075: return bem_vvGet_0();
case 422642132: return bem_klassNameGet_0();
case -1101326644: return bem_serializeContents_0();
case 1846269230: return bem_translateEmittedException_0();
case -304415890: return bem_classNameGet_0();
case -1087766017: return bem_serializeToString_0();
case 677802126: return bem_framesTextGet_0();
case -410783155: return bem_new_0();
case -636821037: return bem_langGet_0();
case 635628883: return bem_fileNameGet_0();
case 1248696162: return bem_langGetDirect_0();
case -545885409: return bem_fieldNamesGet_0();
case 1954751090: return bem_emitLangGet_0();
case 291309239: return bem_once_0();
case -1784444008: return bem_translateEmittedExceptionInner_0();
case 305613993: return bem_sourceFileNameGet_0();
case -1758437838: return bem_framesTextGetDirect_0();
case -1795520287: return bem_translatedGet_0();
case 1626134398: return bem_fileNameGetDirect_0();
case 426326672: return bem_vvGetDirect_0();
case 2050059376: return bem_iteratorGet_0();
case 316048671: return bem_descriptionGet_0();
case 597357534: return bem_tagGet_0();
case 1461724031: return bem_copy_0();
case -1830921487: return bem_descriptionGetDirect_0();
case -49453179: return bem_framesGetDirect_0();
case -43502949: return bem_toAny_0();
case 1899466562: return bem_lineNumberGet_0();
case 554254527: return bem_klassNameGetDirect_0();
case 806958221: return bem_methodNameGetDirect_0();
case 1851036145: return bem_serializationIteratorGet_0();
case -590081480: return bem_getFrameText_0();
case -1056861999: return bem_methodNameGet_0();
case 625547167: return bem_toString_0();
case -909675958: return bem_create_0();
case -140305261: return bem_translatedGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1487160694: return bem_methodNameSetDirect_1(bevd_0);
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2082305069: return bem_fileNameSetDirect_1(bevd_0);
case -829081069: return bem_descriptionSetDirect_1(bevd_0);
case 1702404235: return bem_framesTextSetDirect_1(bevd_0);
case -679147748: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -472252792: return bem_emitLangSetDirect_1(bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case 1130018524: return bem_fileNameSet_1(bevd_0);
case -186793001: return bem_new_1(bevd_0);
case 160603263: return bem_klassNameSet_1(bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
case 761990501: return bem_lineNumberSetDirect_1(bevd_0);
case 1004404678: return bem_translatedSetDirect_1(bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case 555785089: return bem_lineNumberSet_1(bevd_0);
case -775025963: return bem_descriptionSet_1(bevd_0);
case 1161329678: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1490278032: return bem_langSet_1(bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case -396262823: return bem_framesSet_1(bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case -439050613: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 572848636: return bem_translatedSet_1(bevd_0);
case -252691757: return bem_vvSet_1(bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -949389725: return bem_def_1(bevd_0);
case 396004640: return bem_klassNameSetDirect_1(bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case 372097475: return bem_langSetDirect_1(bevd_0);
case 68738837: return bem_vvSetDirect_1(bevd_0);
case 1750264409: return bem_emitLangSet_1(bevd_0);
case 1649792891: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1486350599: return bem_framesSetDirect_1(bevd_0);
case -1885962587: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1579959053: return bem_methodNameSet_1(bevd_0);
case -1498887545: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1751864769: return bem_framesTextSet_1(bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -660448610: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemCallOnNull();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
