package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_10_SystemCallOnNull extends BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public BEC_2_6_10_SystemCallOnNull bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {366};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 366 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -201292676: return bem_create_0();
case 1379200508: return bem_emitLangGetDirect_0();
case 1400943249: return bem_fileNameGetDirect_0();
case 560233043: return bem_descriptionGetDirect_0();
case -2065475128: return bem_tagGet_0();
case -507248646: return bem_toString_0();
case -479220991: return bem_echo_0();
case 382312819: return bem_fileNameGet_0();
case -582126333: return bem_framesGetDirect_0();
case -1787306417: return bem_descriptionGet_0();
case -748781877: return bem_klassNameGet_0();
case -335834663: return bem_translateEmittedException_0();
case -1882858230: return bem_klassNameGetDirect_0();
case 67894489: return bem_sourceFileNameGet_0();
case 102769343: return bem_lineNumberGetDirect_0();
case 1509454415: return bem_fieldNamesGet_0();
case -755857848: return bem_serializeToString_0();
case 1886951645: return bem_lineNumberGet_0();
case 90392283: return bem_translatedGet_0();
case -842698583: return bem_print_0();
case -2040343713: return bem_translateEmittedExceptionInner_0();
case 960761061: return bem_methodNameGet_0();
case 1063227311: return bem_framesTextGet_0();
case 998521503: return bem_framesTextGetDirect_0();
case 1990896712: return bem_vvGet_0();
case -1011972693: return bem_classNameGet_0();
case 1834429874: return bem_langGetDirect_0();
case -1312089850: return bem_serializationIteratorGet_0();
case 116405623: return bem_once_0();
case 838598675: return bem_deserializeClassNameGet_0();
case 1538222799: return bem_vvGetDirect_0();
case 2027881489: return bem_new_0();
case -1817966493: return bem_iteratorGet_0();
case 66023749: return bem_copy_0();
case -1126201092: return bem_translatedGetDirect_0();
case 1767145499: return bem_toAny_0();
case 2053312536: return bem_getFrameText_0();
case 1880418594: return bem_many_0();
case 2060533536: return bem_methodNameGetDirect_0();
case 1299776966: return bem_framesGet_0();
case 1334238154: return bem_hashGet_0();
case 1292255745: return bem_fieldIteratorGet_0();
case -1023893291: return bem_emitLangGet_0();
case 864393849: return bem_langGet_0();
case 1319463124: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2100095237: return bem_vvSetDirect_1(bevd_0);
case 1902941795: return bem_defined_1(bevd_0);
case -1483817890: return bem_undef_1(bevd_0);
case 1537391679: return bem_langSet_1(bevd_0);
case 1201016043: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 830714796: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1246278086: return bem_langSetDirect_1(bevd_0);
case -1175297722: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -890367556: return bem_undefined_1(bevd_0);
case -1593220056: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1968558358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1328502463: return bem_equals_1(bevd_0);
case -1836915633: return bem_framesSet_1(bevd_0);
case 208841568: return bem_vvSet_1(bevd_0);
case 440989655: return bem_copyTo_1(bevd_0);
case -697364376: return bem_new_1(bevd_0);
case -1890627721: return bem_notEquals_1(bevd_0);
case 1690093584: return bem_lineNumberSet_1(bevd_0);
case -737237761: return bem_sameObject_1(bevd_0);
case 980187088: return bem_framesSetDirect_1(bevd_0);
case 1751676394: return bem_otherType_1(bevd_0);
case 824292706: return bem_sameType_1(bevd_0);
case -1371321292: return bem_klassNameSetDirect_1(bevd_0);
case 1317453949: return bem_sameClass_1(bevd_0);
case -720849035: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 879743659: return bem_emitLangSetDirect_1(bevd_0);
case -1264396650: return bem_framesTextSet_1(bevd_0);
case -1110705445: return bem_fileNameSetDirect_1(bevd_0);
case 236521366: return bem_def_1(bevd_0);
case -977891687: return bem_methodNameSetDirect_1(bevd_0);
case 1946884923: return bem_lineNumberSetDirect_1(bevd_0);
case -1514476203: return bem_emitLangSet_1(bevd_0);
case 358154948: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1508117625: return bem_otherClass_1(bevd_0);
case -368139293: return bem_descriptionSetDirect_1(bevd_0);
case -1611134635: return bem_klassNameSet_1(bevd_0);
case -237467984: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 809133276: return bem_descriptionSet_1(bevd_0);
case 1751444385: return bem_methodNameSet_1(bevd_0);
case 859368767: return bem_fileNameSet_1(bevd_0);
case -1326259291: return bem_translatedSetDirect_1(bevd_0);
case -1067925872: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 423512502: return bem_framesTextSetDirect_1(bevd_0);
case 931801515: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1321441711: return bem_translatedSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 77948450: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1008558996: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 139476281: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1704645214: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1221915514: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -778494517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1737168375: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1290695778: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemCallOnNull();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
