package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_9_ContainerLinkedListAwareNode extends BEC_3_9_10_4_ContainerLinkedListNode {
public BEC_3_9_10_9_ContainerLinkedListAwareNode() { }
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x41,0x77,0x61,0x72,0x65,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;

public static BET_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;

public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) throws Throwable {
bevp_held = beva__held;
bevp_held.bemd_1(1234265833, this);
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldSet_1(BEC_2_6_6_SystemObject beva__held) throws Throwable {
bevp_held = beva__held;
bevp_held.bemd_1(1234265833, this);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {103, 104, 105, 109, 110};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 13, 14, 18, 19};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 103 12
heldBySet 1 104 13
assign 1 105 14
assign 1 109 18
heldBySet 1 110 19
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1225605186: return bem_hashGet_0();
case 229728232: return bem_iteratorGet_0();
case 1855989374: return bem_nextGet_0();
case 1626371085: return bem_toString_0();
case 468079586: return bem_delete_0();
case -2073108482: return bem_priorGet_0();
case 2106352499: return bem_heldGet_0();
case -846806835: return bem_new_0();
case 1864827271: return bem_copy_0();
case 947107817: return bem_print_0();
case -1093672743: return bem_create_0();
case -501734856: return bem_mylistGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1525061898: return bem_mylistSet_1(bevd_0);
case 1900577541: return bem_nextSet_1(bevd_0);
case -572753341: return bem_insertBefore_1(bevd_0);
case 1989225985: return bem_equals_1(bevd_0);
case 2094676964: return bem_def_1(bevd_0);
case -1872897187: return bem_heldSet_1(bevd_0);
case 528899434: return bem_notEquals_1(bevd_0);
case -1589025417: return bem_priorSet_1(bevd_0);
case 1221468677: return bem_print_1(bevd_0);
case -1068220991: return bem_copyTo_1(bevd_0);
case 430148712: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -203428159: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -581305477: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 306866874: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 308737512: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 1901538121: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_9_ContainerLinkedListAwareNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst = (BEC_3_9_10_9_ContainerLinkedListAwareNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;
}
}
