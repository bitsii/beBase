package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_9_ContainerLinkedListAwareNode extends BEC_3_9_10_4_ContainerLinkedListNode {
public BEC_3_9_10_9_ContainerLinkedListAwareNode() { }
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x41,0x77,0x61,0x72,0x65,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;

public static BET_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;

public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) throws Throwable {
bevp_held = beva__held;
bevp_held.bemd_1(756402308, this);
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldSet_1(BEC_2_6_6_SystemObject beva__held) throws Throwable {
bevp_held = beva__held;
bevp_held.bemd_1(756402308, this);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {103, 104, 105, 109, 110};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 13, 14, 18, 19};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 103 12
heldBySet 1 104 13
assign 1 105 14
assign 1 109 18
heldBySet 1 110 19
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1167108907: return bem_priorGet_0();
case 323586228: return bem_hashGet_0();
case 1126990596: return bem_heldGet_0();
case -1277691905: return bem_create_0();
case 1857517281: return bem_mylistGet_0();
case 1406439869: return bem_iteratorGet_0();
case 571416905: return bem_nextGet_0();
case -582936884: return bem_copy_0();
case -1904974225: return bem_print_0();
case 111880483: return bem_delete_0();
case -334139513: return bem_toString_0();
case -507985549: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1031108856: return bem_insertBefore_1(bevd_0);
case 2083304692: return bem_copyTo_1(bevd_0);
case -1170733757: return bem_heldSet_1(bevd_0);
case 1894221943: return bem_undef_1(bevd_0);
case -900715304: return bem_notEquals_1(bevd_0);
case -1441152686: return bem_equals_1(bevd_0);
case 1819873337: return bem_nextSet_1(bevd_0);
case -1564500571: return bem_def_1(bevd_0);
case 91145876: return bem_mylistSet_1(bevd_0);
case -554183447: return bem_priorSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1506086904: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -1170875190: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -506946318: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1280428261: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2064104272: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_9_ContainerLinkedListAwareNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst = (BEC_3_9_10_9_ContainerLinkedListAwareNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;
}
}
