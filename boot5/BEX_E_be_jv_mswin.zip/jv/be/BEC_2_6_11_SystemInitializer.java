package be;
/* IO:File: source/base/Initializer.be */
public final class BEC_2_6_11_SystemInitializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemInitializer() { }
private static byte[] becc_BEC_2_6_11_SystemInitializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_11_SystemInitializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_11_SystemInitializer_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
public static BEC_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_inst;

public static BET_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_type;

public BEC_2_6_6_SystemObject bem_initializeIfShould_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = beva_inst.bemd_2(-418624509, bevt_1_ta_ph, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 14*/ {
bevt_3_ta_ph = bem_initializeIt_1(beva_inst);
return bevt_3_ta_ph;
} /* Line: 15*/
bevt_4_ta_ph = beva_inst.bemd_0(1734159100);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitConstruct_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 35*/ {
bevl_init = beva_inst;

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 42*/
return bevl_init;
} /*method end*/
public BEC_2_6_11_SystemInitializer bem_notNullInitDefault_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;

      bevl_init = beva_inst.bemc_getInitial();
      bevl_init.bemd_0(-660543521);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitIt_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 88*/ {
bevl_init = beva_inst;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = bevl_init.bemd_2(-418624509, bevt_2_ta_ph, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 90*/ {
bevl_init.bemd_0(-660543521);
} /* Line: 91*/

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 99*/
return bevl_init;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initializeIt_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 128*/ {
bevl_init = beva_inst;
bevl_init.bemd_0(-660543521);

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 137*/
return bevl_init;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 14, 14, 15, 15, 17, 17, 35, 35, 36, 48, 64, 88, 88, 89, 90, 90, 90, 91, 105, 128, 128, 129, 130, 143};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 22, 23, 25, 26, 33, 38, 39, 43, 49, 60, 65, 66, 67, 68, 69, 71, 76, 83, 88, 89, 90, 94};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 18
new 0 14 18
assign 1 14 19
new 0 14 19
assign 1 14 20
can 2 14 20
assign 1 15 22
initializeIt 1 15 22
return 1 15 23
assign 1 17 25
new 0 17 25
return 1 17 26
assign 1 35 33
undef 1 35 38
assign 1 36 39
return 1 48 43
default 0 64 49
assign 1 88 60
undef 1 88 65
assign 1 89 66
assign 1 90 67
new 0 90 67
assign 1 90 68
new 0 90 68
assign 1 90 69
can 2 90 69
default 0 91 71
return 1 105 76
assign 1 128 83
undef 1 128 88
assign 1 129 89
default 0 130 90
return 1 143 94
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1394706579: return bem_hashGet_0();
case 1734159100: return bem_new_0();
case -1492973205: return bem_print_0();
case -1251189415: return bem_toString_0();
case -1378154513: return bem_copy_0();
case -341701962: return bem_iteratorGet_0();
case -1868791417: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 224732862: return bem_notEquals_1(bevd_0);
case 414174756: return bem_initializeIfShould_1(bevd_0);
case 764483733: return bem_equals_1(bevd_0);
case 397001831: return bem_notNullInitConstruct_1(bevd_0);
case 404631763: return bem_undef_1(bevd_0);
case -41647352: return bem_def_1(bevd_0);
case -1320351492: return bem_notNullInitIt_1(bevd_0);
case 2104413237: return bem_initializeIt_1(bevd_0);
case 1894087300: return bem_notNullInitDefault_1(bevd_0);
case -1504859590: return bem_copyTo_1(bevd_0);
case 212925280: return bem_print_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 717909815: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1423582782: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -418624509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -861820000: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemInitializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_11_SystemInitializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_11_SystemInitializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst = (BEC_2_6_11_SystemInitializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_type;
}
}
