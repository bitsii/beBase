package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_11_SystemInitializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemInitializer() { }
private static byte[] becc_BEC_2_6_11_SystemInitializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_11_SystemInitializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_11_SystemInitializer_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
private static byte[] bece_BEC_2_6_11_SystemInitializer_bels_1 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
public static BEC_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_inst;
public BEC_2_6_6_SystemObject bem_initializeIfShould_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_inst.bemd_2(795294323, bevt_1_tmpany_phold, bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 45 */ {
bevt_3_tmpany_phold = bem_initializeIt_1(beva_inst);
return bevt_3_tmpany_phold;
} /* Line: 46 */
bevt_4_tmpany_phold = beva_inst.bemd_0(386788561);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitConstruct_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevl_init = beva_inst;

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 81 */
return bevl_init;
} /*method end*/
public BEC_2_6_11_SystemInitializer bem_notNullInitDefault_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;

      bevl_init = beva_inst.bemc_getInitial();
      bevl_init.bemd_0(927302394);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitIt_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevl_init = beva_inst;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_1));
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_1_tmpany_phold = bevl_init.bemd_2(795294323, bevt_2_tmpany_phold, bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevl_init.bemd_0(927302394);
} /* Line: 137 */

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 145 */
return bevl_init;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initializeIt_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevl_init = beva_inst;
bevl_init.bemd_0(927302394);

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 183 */
return bevl_init;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {45, 45, 45, 46, 46, 48, 48, 73, 73, 74, 87, 110, 134, 134, 135, 136, 136, 136, 137, 151, 174, 174, 175, 176, 189};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 22, 23, 25, 26, 33, 38, 39, 43, 49, 60, 65, 66, 67, 68, 69, 71, 76, 83, 88, 89, 90, 94};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 45 18
new 0 45 18
assign 1 45 19
new 0 45 19
assign 1 45 20
can 2 45 20
assign 1 46 22
initializeIt 1 46 22
return 1 46 23
assign 1 48 25
new 0 48 25
return 1 48 26
assign 1 73 33
undef 1 73 38
assign 1 74 39
return 1 87 43
default 0 110 49
assign 1 134 60
undef 1 134 65
assign 1 135 66
assign 1 136 67
new 0 136 67
assign 1 136 68
new 0 136 68
assign 1 136 69
can 2 136 69
default 0 137 71
return 1 151 76
assign 1 174 83
undef 1 174 88
assign 1 175 89
default 0 176 90
return 1 189 94
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2092326455: return bem_many_0();
case 65678538: return bem_echo_0();
case -1620819332: return bem_once_0();
case 1342246094: return bem_print_0();
case -117420215: return bem_serializeContents_0();
case -1197182710: return bem_serializeToString_0();
case 1637405965: return bem_toString_0();
case -261636586: return bem_classNameGet_0();
case 1053098123: return bem_hashGet_0();
case -1975952737: return bem_tagGet_0();
case 386788561: return bem_new_0();
case 866679447: return bem_serializationIteratorGet_0();
case 168705805: return bem_iteratorGet_0();
case 845917022: return bem_fieldIteratorGet_0();
case 582818432: return bem_create_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case -1712633963: return bem_toAny_0();
case -935771084: return bem_sourceFileNameGet_0();
case 1449516553: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case -1921133350: return bem_defined_1(bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2123636132: return bem_initializeIt_1(bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case -493979725: return bem_notNullInitConstruct_1(bevd_0);
case 1962667896: return bem_initializeIfShould_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1473414742: return bem_notNullInitIt_1(bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case 1630963641: return bem_notNullInitDefault_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemInitializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_11_SystemInitializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_11_SystemInitializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst = (BEC_2_6_11_SystemInitializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst;
}
}
