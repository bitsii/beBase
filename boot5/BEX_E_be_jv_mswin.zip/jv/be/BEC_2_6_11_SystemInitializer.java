package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_11_SystemInitializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemInitializer() { }
private static byte[] becc_BEC_2_6_11_SystemInitializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_11_SystemInitializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_11_SystemInitializer_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
private static byte[] bece_BEC_2_6_11_SystemInitializer_bels_1 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
public static BEC_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_inst;
public BEC_2_6_6_SystemObject bem_initializeIfShould_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_inst.bemd_2(2093180987, bevt_1_tmpany_phold, bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 45 */ {
bevt_3_tmpany_phold = bem_initializeIt_1(beva_inst);
return bevt_3_tmpany_phold;
} /* Line: 46 */
bevt_4_tmpany_phold = beva_inst.bemd_0(-124916815);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitConstruct_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevl_init = beva_inst;

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 81 */
return bevl_init;
} /*method end*/
public BEC_2_6_11_SystemInitializer bem_notNullInitDefault_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;

      bevl_init = beva_inst.bemc_getInitial();
      bevl_init.bemd_0(313469553);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitIt_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevl_init = beva_inst;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_1));
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_1_tmpany_phold = bevl_init.bemd_2(2093180987, bevt_2_tmpany_phold, bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevl_init.bemd_0(313469553);
} /* Line: 137 */

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 145 */
return bevl_init;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initializeIt_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevl_init = beva_inst;
bevl_init.bemd_0(313469553);

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 183 */
return bevl_init;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {45, 45, 45, 46, 46, 48, 48, 73, 73, 74, 87, 110, 134, 134, 135, 136, 136, 136, 137, 151, 174, 174, 175, 176, 189};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 22, 23, 25, 26, 33, 38, 39, 43, 49, 60, 65, 66, 67, 68, 69, 71, 76, 83, 88, 89, 90, 94};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 45 18
new 0 45 18
assign 1 45 19
new 0 45 19
assign 1 45 20
can 2 45 20
assign 1 46 22
initializeIt 1 46 22
return 1 46 23
assign 1 48 25
new 0 48 25
return 1 48 26
assign 1 73 33
undef 1 73 38
assign 1 74 39
return 1 87 43
default 0 110 49
assign 1 134 60
undef 1 134 65
assign 1 135 66
assign 1 136 67
new 0 136 67
assign 1 136 68
new 0 136 68
assign 1 136 69
can 2 136 69
default 0 137 71
return 1 151 76
assign 1 174 83
undef 1 174 88
assign 1 175 89
default 0 176 90
return 1 189 94
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -149632320: return bem_toAny_0();
case -93701646: return bem_fieldIteratorGet_0();
case -748319096: return bem_print_0();
case -29400896: return bem_create_0();
case -1052800757: return bem_echo_0();
case -801589503: return bem_tagGet_0();
case -794227383: return bem_copy_0();
case 861710738: return bem_many_0();
case -7634332: return bem_classNameGet_0();
case 900978335: return bem_serializeToString_0();
case 1338975369: return bem_sourceFileNameGet_0();
case -14402816: return bem_serializeContents_0();
case -1674098047: return bem_once_0();
case -1701242685: return bem_serializationIteratorGet_0();
case -258597009: return bem_hashGet_0();
case -51803385: return bem_toString_0();
case -124916815: return bem_new_0();
case -1749103224: return bem_iteratorGet_0();
case -467186719: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 1518481031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -983540661: return bem_undefined_1(bevd_0);
case -73997568: return bem_equals_1(bevd_0);
case 1970850163: return bem_sameType_1(bevd_0);
case 2050063687: return bem_initializeIt_1(bevd_0);
case 616348580: return bem_undef_1(bevd_0);
case -271716565: return bem_copyTo_1(bevd_0);
case -2092712540: return bem_def_1(bevd_0);
case 642489795: return bem_otherType_1(bevd_0);
case -93273669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 550176080: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1066263118: return bem_notNullInitDefault_1(bevd_0);
case -20159434: return bem_sameClass_1(bevd_0);
case -218714893: return bem_otherClass_1(bevd_0);
case -1391202250: return bem_defined_1(bevd_0);
case 1135050111: return bem_notNullInitConstruct_1(bevd_0);
case -183731731: return bem_notNullInitIt_1(bevd_0);
case 2036979549: return bem_notEquals_1(bevd_0);
case 23348964: return bem_initializeIfShould_1(bevd_0);
case -1474467614: return bem_sameObject_1(bevd_0);
case 226940097: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case -66460559: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1367679335: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1031466779: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2131321099: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 292502272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2093180987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -323049121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemInitializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_11_SystemInitializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_11_SystemInitializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst = (BEC_2_6_11_SystemInitializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst;
}
}
