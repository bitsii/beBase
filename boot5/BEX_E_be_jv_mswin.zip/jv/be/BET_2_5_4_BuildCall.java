package be;
public class BET_2_5_4_BuildCall extends BETS_Object {
public BET_2_5_4_BuildCall() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "toAccessorName_0", "nameGet_0", "nameSet_1", "orgNameGet_0", "orgNameSet_1", "accessorTypeGet_0", "accessorTypeSet_1", "numargsGet_0", "numargsSet_1", "literalValueGet_0", "literalValueSet_1", "newNpGet_0", "newNpSet_1", "cposGet_0", "cposSet_1", "isConstructGet_0", "isConstructSet_1", "boundGet_0", "boundSet_1", "wasBoundGet_0", "wasBoundSet_1", "wasAccessorGet_0", "wasAccessorSet_1", "wasOperGet_0", "wasOperSet_1", "isLiteralGet_0", "isLiteralSet_1", "checkTypesGet_0", "checkTypesSet_1", "checkTypesTypeGet_0", "checkTypesTypeSet_1", "superCallGet_0", "superCallSet_1", "wasImpliedConstructGet_0", "wasImpliedConstructSet_1", "wasForeachGennedGet_0", "wasForeachGennedSet_1", "untypedGet_0", "untypedSet_1", "isForwardGet_0", "isForwardSet_1", "argCastsGet_0", "argCastsSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "name", "orgName", "accessorType", "numargs", "literalValue", "newNp", "cpos", "isConstruct", "bound", "wasBound", "wasAccessor", "wasOper", "isLiteral", "checkTypes", "checkTypesType", "superCall", "wasImpliedConstruct", "wasForeachGenned", "untyped", "isForward", "argCasts" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_4_BuildCall();
}
}
