package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure extends BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public BEC_2_4_7_TestFailure bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
super.bem_new_1(beva_descr);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 14 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1371476528: return bem_descriptionGet_0();
case -96677338: return bem_copy_0();
case -395536224: return bem_iteratorGet_0();
case 1391260772: return bem_methodNameGet_0();
case 1609224497: return bem_framesGet_0();
case 299271022: return bem_hashGet_0();
case 1598372560: return bem_framesTextGet_0();
case 1884194420: return bem_print_0();
case -656948803: return bem_langGet_0();
case -950996711: return bem_klassNameGet_0();
case 1799552386: return bem_new_0();
case 1116386207: return bem_getFrameText_0();
case -957222543: return bem_fileNameGet_0();
case 1754502728: return bem_lineNumberGet_0();
case 1498797695: return bem_emitLangGet_0();
case 1341364362: return bem_create_0();
case -1152814540: return bem_toString_0();
case 241040643: return bem_translatedGet_0();
case 2044143116: return bem_vvGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 270193694: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -158441044: return bem_def_1(bevd_0);
case 25777534: return bem_notEquals_1(bevd_0);
case 149496997: return bem_klassNameSet_1(bevd_0);
case -659088107: return bem_equals_1(bevd_0);
case -302199064: return bem_new_1(bevd_0);
case -1103346635: return bem_lineNumberSet_1(bevd_0);
case 1944057208: return bem_framesSet_1(bevd_0);
case -1690312963: return bem_vvSet_1(bevd_0);
case 243616680: return bem_methodNameSet_1(bevd_0);
case 1628834191: return bem_translatedSet_1(bevd_0);
case -904751583: return bem_undef_1(bevd_0);
case -1591475872: return bem_descriptionSet_1(bevd_0);
case 70294508: return bem_framesTextSet_1(bevd_0);
case 695026312: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1292080003: return bem_copyTo_1(bevd_0);
case -1926929684: return bem_emitLangSet_1(bevd_0);
case 1492232795: return bem_langSet_1(bevd_0);
case 393388307: return bem_fileNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -869432918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 617695149: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 70167069: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -94082723: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1102317820: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1379488834: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TestFailure();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
