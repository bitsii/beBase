package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure extends BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public BEC_2_4_7_TestFailure bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
super.bem_new_1(beva_descr);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 20 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -227977009: return bem_framesTextGet_0();
case -1528559952: return bem_new_0();
case 1879964188: return bem_framesGet_0();
case -733487718: return bem_getFrameText_0();
case -1469940816: return bem_hashGet_0();
case -817805991: return bem_copy_0();
case 404904258: return bem_vvGet_0();
case -732449519: return bem_methodNameGet_0();
case 1797379901: return bem_toString_0();
case -1388133126: return bem_langGet_0();
case -1109896529: return bem_translatedGet_0();
case -1764331563: return bem_print_0();
case -241347086: return bem_create_0();
case -175919003: return bem_klassNameGet_0();
case 789960107: return bem_descriptionGet_0();
case -583517819: return bem_emitLangGet_0();
case 592621187: return bem_fileNameGet_0();
case 62063643: return bem_iteratorGet_0();
case 745960956: return bem_lineNumberGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -402753267: return bem_equals_1(bevd_0);
case -48017045: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -2010351560: return bem_fileNameSet_1(bevd_0);
case 2021238493: return bem_new_1(bevd_0);
case 276051135: return bem_descriptionSet_1(bevd_0);
case -758029599: return bem_translatedSet_1(bevd_0);
case 1051624436: return bem_notEquals_1(bevd_0);
case -658652372: return bem_framesTextSet_1(bevd_0);
case -1062543098: return bem_framesSet_1(bevd_0);
case 1097889724: return bem_emitLangSet_1(bevd_0);
case 1987722462: return bem_klassNameSet_1(bevd_0);
case -1456108211: return bem_lineNumberSet_1(bevd_0);
case -125080499: return bem_vvSet_1(bevd_0);
case 1952840823: return bem_undef_1(bevd_0);
case -1988651271: return bem_copyTo_1(bevd_0);
case 527456055: return bem_def_1(bevd_0);
case 1825425594: return bem_methodNameSet_1(bevd_0);
case 188277212: return bem_langSet_1(bevd_0);
case -595547710: return bem_print_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -507977338: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1843730802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1382402033: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1317838948: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1958686290: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TestFailure();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
