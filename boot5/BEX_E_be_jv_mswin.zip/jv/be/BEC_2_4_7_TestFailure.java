package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure extends BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public BEC_2_4_7_TestFailure bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
super.bem_new_1(beva_descr);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 15 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -413288025: return bem_emitLangGet_0();
case -2076277089: return bem_vvGetDirect_0();
case -1750213491: return bem_sourceFileNameGet_0();
case -1586484060: return bem_emitLangGetDirect_0();
case -2070113098: return bem_create_0();
case -1218779937: return bem_getFrameText_0();
case -1834771479: return bem_framesGet_0();
case -384810082: return bem_framesTextGet_0();
case 1724306645: return bem_methodNameGet_0();
case 1516161879: return bem_fieldNamesGet_0();
case -35411497: return bem_klassNameGetDirect_0();
case 2037638992: return bem_klassNameGet_0();
case 2135770496: return bem_lineNumberGetDirect_0();
case -476760037: return bem_fileNameGet_0();
case -726897339: return bem_methodNameGetDirect_0();
case -300378972: return bem_descriptionGetDirect_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case -2092945760: return bem_vvGet_0();
case 1730802409: return bem_echo_0();
case 1175367387: return bem_lineNumberGet_0();
case -2073027086: return bem_fieldIteratorGet_0();
case -61288189: return bem_serializationIteratorGet_0();
case -1556712456: return bem_new_0();
case -1553162059: return bem_translateEmittedExceptionInner_0();
case -1828225043: return bem_translatedGetDirect_0();
case -631649167: return bem_langGetDirect_0();
case -1656371030: return bem_framesGetDirect_0();
case 1660533487: return bem_serializeContents_0();
case 1768909851: return bem_fileNameGetDirect_0();
case 450230894: return bem_print_0();
case -897350462: return bem_iteratorGet_0();
case -948982310: return bem_many_0();
case -1439777293: return bem_hashGet_0();
case -1603672570: return bem_translateEmittedException_0();
case 623957818: return bem_once_0();
case -651400563: return bem_descriptionGet_0();
case 1172450247: return bem_copy_0();
case 129073609: return bem_langGet_0();
case -1758960402: return bem_translatedGet_0();
case 1935136194: return bem_classNameGet_0();
case 1070146794: return bem_toAny_0();
case -1623116451: return bem_framesTextGetDirect_0();
case -1476019175: return bem_toString_0();
case 1326542704: return bem_tagGet_0();
case 742371580: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1987418210: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case -1488781414: return bem_klassNameSet_1(bevd_0);
case -841793729: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -133894103: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -2080952897: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -816511295: return bem_translatedSetDirect_1(bevd_0);
case 1540886502: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1508928899: return bem_framesSetDirect_1(bevd_0);
case -299391132: return bem_equals_1(bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case 946417952: return bem_framesSet_1(bevd_0);
case 575951320: return bem_fileNameSetDirect_1(bevd_0);
case 942792215: return bem_methodNameSetDirect_1(bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case 1745893339: return bem_fileNameSet_1(bevd_0);
case 639676921: return bem_framesTextSetDirect_1(bevd_0);
case -922430526: return bem_vvSet_1(bevd_0);
case 1373825577: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -191811077: return bem_translatedSet_1(bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case 258994669: return bem_descriptionSet_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1468211453: return bem_methodNameSet_1(bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case -203976329: return bem_lineNumberSet_1(bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case -735526765: return bem_framesTextSet_1(bevd_0);
case 963046929: return bem_vvSetDirect_1(bevd_0);
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1363641320: return bem_lineNumberSetDirect_1(bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case -636705865: return bem_descriptionSetDirect_1(bevd_0);
case 59847925: return bem_emitLangSetDirect_1(bevd_0);
case -1893487788: return bem_emitLangSet_1(bevd_0);
case 1798174511: return bem_langSet_1(bevd_0);
case 1693468627: return bem_klassNameSetDirect_1(bevd_0);
case 229070821: return bem_new_1(bevd_0);
case -957438933: return bem_undef_1(bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case 1728639532: return bem_langSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1937159265: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TestFailure();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
