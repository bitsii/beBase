package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_18_SystemStartupIfArguments extends BEC_2_6_6_SystemObject {
public BEC_2_6_18_SystemStartupIfArguments() { }
private static byte[] becc_BEC_2_6_18_SystemStartupIfArguments_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x49,0x66,0x41,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_6_18_SystemStartupIfArguments_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
public static BEC_2_6_18_SystemStartupIfArguments bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst;

public static BET_2_6_18_SystemStartupIfArguments bece_BEC_2_6_18_SystemStartupIfArguments_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_18_SystemStartupIfArguments bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_18_SystemStartupIfArguments bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_ta_ph.bem_argsGet_0();
bevt_2_ta_ph = bevp_args.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_2_ta_ph.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_5_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = bevp_args.bem_get_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_createInstance_1((BEC_2_4_6_TextString) bevt_6_ta_ph );
bevl_x = bevt_4_ta_ph.bemd_0(485745298);
bevt_8_ta_ph = bevl_x.bemd_0(-213871784);
return bevt_8_ta_ph;
} /* Line: 53*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_18_SystemStartupIfArguments bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 50, 51, 51, 51, 51, 52, 52, 52, 52, 52, 53, 53, 55, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 30, 31, 32, 33, 38, 39, 40, 41, 42, 43, 44, 45, 47, 50, 53};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 29
new 0 50 29
assign 1 50 30
argsGet 0 50 30
assign 1 51 31
sizeGet 0 51 31
assign 1 51 32
new 0 51 32
assign 1 51 33
greater 1 51 38
assign 1 52 39
new 0 52 39
assign 1 52 40
new 0 52 40
assign 1 52 41
get 1 52 41
assign 1 52 42
createInstance 1 52 42
assign 1 52 43
new 0 52 43
assign 1 53 44
main 0 53 44
return 1 53 45
return 1 55 47
return 1 0 50
assign 1 0 53
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1873540986: return bem_hashGet_0();
case 485745298: return bem_new_0();
case -1900847811: return bem_print_0();
case -213871784: return bem_main_0();
case -121033251: return bem_create_0();
case 993904896: return bem_copy_0();
case 348103798: return bem_iteratorGet_0();
case 912791834: return bem_default_0();
case -14706576: return bem_argsGet_0();
case -869004384: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1764807072: return bem_argsSet_1(bevd_0);
case 887202309: return bem_notEquals_1(bevd_0);
case -554072871: return bem_def_1(bevd_0);
case 916259092: return bem_copyTo_1(bevd_0);
case 1218368508: return bem_undef_1(bevd_0);
case -596585082: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1669355053: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1189844441: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 87795638: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 14330381: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_18_SystemStartupIfArguments_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_18_SystemStartupIfArguments_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_18_SystemStartupIfArguments();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst = (BEC_2_6_18_SystemStartupIfArguments) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_type;
}
}
