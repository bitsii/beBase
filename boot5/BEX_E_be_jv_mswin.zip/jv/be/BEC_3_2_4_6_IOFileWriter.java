package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileWriter extends BEC_2_2_6_IOWriter {
public BEC_3_2_4_6_IOFileWriter() { }
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_0 = {0x77,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_1 = {0x61,0x62};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileWriter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileWriter_bels_1, 2));
public static BEC_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;

public static BET_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_3_2_4_6_IOFileWriter bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevp_isClosed = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_openTruncate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_openAppend_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_open_1(BEC_2_4_6_TextString beva_mode) throws Throwable {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevl_append = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_fhpatha = bevp_path.bem_toString_0();
 /* Line: 428 */ {
if (beva_mode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_3_tmpany_phold = bece_BEC_3_2_4_6_IOFileWriter_bevo_0;
bevt_2_tmpany_phold = beva_mode.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 429 */
 else  /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 429 */ {
bevl_append = be.BECS_Runtime.boolTrue;
} /* Line: 430 */
 else  /* Line: 431 */ {
bevl_append = be.BECS_Runtime.boolFalse;
} /* Line: 432 */
} /* Line: 429 */

      if (this.bevi_os == null) {
        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        this.bevi_os = new java.io.FileOutputStream(bevls_f, bevl_append.bevi_bool);
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {388, 389, 389, 393, 393, 397, 397, 401, 401, 412, 429, 429, 429, 429, 0, 0, 0, 430, 432, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 24, 25, 30, 31, 36, 37, 53, 55, 60, 61, 62, 64, 67, 71, 74, 77, 89, 92, 95, 99};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 388 17
new 0 388 17
assign 1 389 18
new 1 389 18
pathSet 1 389 19
assign 1 393 24
new 0 393 24
open 1 393 25
assign 1 397 30
new 0 397 30
open 1 397 31
assign 1 401 36
new 0 401 36
open 1 401 37
assign 1 412 53
toString 0 412 53
assign 1 429 55
def 1 429 60
assign 1 429 61
new 0 429 61
assign 1 429 62
equals 1 429 62
assign 1 0 64
assign 1 0 67
assign 1 0 71
assign 1 430 74
new 0 430 74
assign 1 432 77
new 0 432 77
return 1 0 89
return 1 0 92
assign 1 0 95
assign 1 0 99
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1551415145: return bem_toAny_0();
case 101122454: return bem_vfileGet_0();
case -1430124856: return bem_openTruncate_0();
case 1936584039: return bem_close_0();
case -660733154: return bem_extOpen_0();
case 1413082515: return bem_pathGet_0();
case 690609043: return bem_print_0();
case -1522610135: return bem_serializeToString_0();
case -2005156683: return bem_classNameGet_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case -753430171: return bem_fieldIteratorGet_0();
case 983736684: return bem_serializationIteratorGet_0();
case 1178964645: return bem_vfileGetDirect_0();
case 247075507: return bem_fieldNamesGet_0();
case 785416079: return bem_pathGetDirect_0();
case -576502505: return bem_create_0();
case 2084331281: return bem_new_0();
case 320622940: return bem_echo_0();
case -738439163: return bem_copy_0();
case 1686045927: return bem_isClosedGet_0();
case 1969080256: return bem_once_0();
case -1966626789: return bem_hashGet_0();
case 1427535989: return bem_open_0();
case -1313098664: return bem_toString_0();
case 101762581: return bem_serializeContents_0();
case 645211302: return bem_iteratorGet_0();
case 197322008: return bem_openAppend_0();
case -890719598: return bem_sourceFileNameGet_0();
case -1100437545: return bem_isClosedGetDirect_0();
case 484635838: return bem_tagGet_0();
case -357139526: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1321495600: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 1082747015: return bem_pathSetDirect_1(bevd_0);
case -670773723: return bem_sameType_1(bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case -1430108636: return bem_isClosedSet_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -994409784: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case 1881647183: return bem_vfileSet_1(bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 758604875: return bem_def_1(bevd_0);
case 195095940: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -1363611238: return bem_pathSet_1(bevd_0);
case -559803890: return bem_notEquals_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 1353906706: return bem_isClosedSetDirect_1(bevd_0);
case -28560571: return bem_vfileSetDirect_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1865671550: return bem_new_1(bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileWriter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileWriter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_6_IOFileWriter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst = (BEC_3_2_4_6_IOFileWriter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_type;
}
}
