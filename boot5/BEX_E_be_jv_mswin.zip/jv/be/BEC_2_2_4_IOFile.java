package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
private static byte[] becc_BEC_2_2_4_IOFile_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_2_4_IOFile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_inst;

public static BET_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public BEC_2_2_4_IOFile bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) throws Throwable {
bem_pathSet_1(beva__path);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 59 */
return bevp_reader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_writer == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 65 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 66 */
return bevp_writer;
} /*method end*/
public BEC_2_2_4_IOFile bem_delete_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_llpath = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 82 */ {

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.delete();
         } /* Line: 108 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bemd_0(472302085);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1405006096);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(463528274);
bevt_0_tmpany_phold.bemd_0(-1320337156);
bevt_3_tmpany_phold = beva_other.bemd_0(-919678965);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_tmpany_phold.bemd_0(-718845534);
bevt_4_tmpany_phold = bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_tmpany_phold.bemd_0(-718845534);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_mkdirs_0() throws Throwable {
bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_mkdir_0() throws Throwable {
bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_makeDirs_0() throws Throwable {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = be.BECS_Runtime.boolFalse;
bevl_t = be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevl_strn.bemd_0(-1539763567);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_5_tmpany_phold = bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 150 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 150 */
 else  /* Line: 150 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 150 */ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_tmpany_phold = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 152 */ {
return this;
} /* Line: 154 */
bevt_7_tmpany_phold = bevl_parentpath.bemd_0(463528274);
bevt_7_tmpany_phold.bemd_0(-1320337156);

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.mkdir();
          /* Line: 185 */ {
} /* Line: 186 */
} /* Line: 195 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirectoryGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isDirGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_lastUpdatedGet_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_lu = null;
bevl_lu = (new BEC_2_4_8_TimeInterval()).bem_new_0();

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        long ctm = bevls_f.lastModified();
        bevl_lu.bevp_secs.bevi_int = (int) (ctm / 1000);
        bevl_lu.bevp_millis.bevi_int = (int) (ctm % 1000);
        return bevl_lu;
} /*method end*/
public BEC_2_2_4_IOFile bem_lastUpdatedSet_1(BEC_2_4_8_TimeInterval beva_lu) throws Throwable {

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        long ts = ((long)(beva_lu.bevp_secs.bevi_int)) * 1000L;
        ts = ts + beva_lu.bevp_millis.bevi_int;
        bevls_f.setLastModified(ts);
        return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 274 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isDirectory()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 307 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFileGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 331 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isFile()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 364 */
return bevl_result;
} /*method end*/
public BEC_2_2_4_IOFile bem_makeFile_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_writerGet_0();
bevt_0_tmpany_phold.bemd_0(-718845534);
bevt_1_tmpany_phold = bem_writerGet_0();
bevt_1_tmpany_phold.bemd_0(2142572680);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 383 */ {
return null;
} /* Line: 384 */
bevt_2_tmpany_phold = bem_contentsNoCheckGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsNoCheckGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ps = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
 /* Line: 400 */ {
bevl_r = bem_readerGet_0();
bevl_r.bemd_0(-718845534);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(-1018795891);
bevl_r.bemd_0(2142572680);
} /* Line: 404 */
return bevl_res;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
bevt_4_tmpany_phold = bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_parentGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevt_7_tmpany_phold = bem_pathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 411 */
bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_4_6_TextString bevl_ps = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_6_6_SystemObject bevl_w = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
 /* Line: 426 */ {
bevl_w = bem_writerGet_0();
bevl_w.bemd_0(-718845534);
bevl_w.bemd_1(-1687724907, beva_contents);
bevl_w.bemd_0(2142572680);
} /* Line: 430 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (new BEC_2_4_3_MathInt());

    java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
    bevl_sz.bevi_int = (int) bevls_f.length();
    return bevl_sz;
} /*method end*/
public BEC_2_5_4_LogicBool bem_existsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_tvala = be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
      if (bevls_f.exists()) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
       /* Line: 482 */ {
} /* Line: 483 */
return bevl_tvala;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_absPathGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;
 /* Line: 522 */ {

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        //bevl_abstr = new BEC_2_4_6_TextString(bevls_f.toPath().toRealPath().toString());
        bevl_abstr = new BEC_2_4_6_TextString(bevls_f.getCanonicalPath());
        } /* Line: 523 */
bevl_absp = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public BEC_2_2_4_IOFile bem_close_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 539 */ {
bevp_reader.bemd_0(2142572680);
} /* Line: 540 */
if (bevp_writer == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 542 */ {
bevp_writer.bemd_0(2142572680);
} /* Line: 543 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOFile bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_readerGetDirect_0() throws Throwable {
return bevp_reader;
} /*method end*/
public BEC_2_2_4_IOFile bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOFile bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_writerGetDirect_0() throws Throwable {
return bevp_writer;
} /*method end*/
public BEC_2_2_4_IOFile bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOFile bem_writerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {46, 46, 50, 50, 54, 58, 58, 59, 59, 61, 65, 65, 66, 66, 68, 82, 121, 121, 121, 121, 122, 122, 123, 123, 124, 125, 126, 127, 127, 132, 135, 146, 147, 148, 149, 150, 150, 150, 150, 150, 150, 0, 0, 0, 151, 152, 154, 156, 156, 212, 212, 217, 236, 272, 273, 274, 317, 329, 330, 331, 374, 378, 378, 379, 379, 383, 383, 383, 384, 386, 386, 401, 402, 403, 404, 406, 410, 410, 410, 410, 410, 410, 411, 411, 411, 411, 413, 427, 428, 429, 430, 436, 443, 455, 456, 514, 534, 535, 539, 539, 540, 542, 542, 543, 548, 548, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 27, 28, 32, 38, 43, 44, 45, 47, 52, 57, 58, 59, 61, 69, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 101, 105, 125, 126, 127, 128, 129, 130, 131, 133, 134, 139, 140, 143, 147, 150, 151, 153, 155, 156, 167, 168, 172, 178, 192, 193, 194, 202, 208, 209, 210, 218, 223, 224, 225, 226, 233, 234, 239, 240, 242, 243, 252, 253, 254, 255, 257, 268, 269, 270, 271, 272, 277, 278, 279, 280, 281, 283, 295, 296, 297, 298, 304, 308, 316, 317, 325, 336, 337, 342, 347, 348, 350, 355, 356, 362, 363, 366, 369, 372, 376, 380, 383, 387, 391, 394, 398};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 46 21
new 1 46 21
pathSet 1 46 22
assign 1 50 27
apNew 1 50 27
pathSet 1 50 28
pathSet 1 54 32
assign 1 58 38
undef 1 58 43
assign 1 59 44
toString 0 59 44
assign 1 59 45
new 1 59 45
return 1 61 47
assign 1 65 52
undef 1 65 57
assign 1 66 58
toString 0 66 58
assign 1 66 59
new 1 66 59
return 1 68 61
assign 1 82 69
existsGet 0 82 69
assign 1 121 86
pathGet 0 121 86
assign 1 121 87
parentGet 0 121 87
assign 1 121 88
fileGet 0 121 88
makeDirs 0 121 89
assign 1 122 90
writerGet 0 122 90
assign 1 122 91
open 0 122 91
assign 1 123 92
readerGet 0 123 92
assign 1 123 93
open 0 123 93
copyData 1 124 94
close 0 125 95
close 0 126 96
assign 1 127 97
new 0 127 97
return 1 127 98
makeDirs 0 132 101
makeDirs 0 135 105
assign 1 146 125
toString 0 146 125
assign 1 147 126
new 0 147 126
assign 1 148 127
new 0 148 127
assign 1 149 128
new 0 149 128
assign 1 150 129
toString 0 150 129
assign 1 150 130
emptyGet 0 150 130
assign 1 150 131
notEquals 1 150 131
assign 1 150 133
existsGet 0 150 133
assign 1 150 134
not 0 150 139
assign 1 0 140
assign 1 0 143
assign 1 0 147
assign 1 151 150
parentGet 0 151 150
assign 1 152 151
equals 1 152 151
return 1 154 153
assign 1 156 155
fileGet 0 156 155
makeDirs 0 156 156
assign 1 212 167
isDirGet 0 212 167
return 1 212 168
assign 1 217 172
new 0 217 172
return 1 236 178
assign 1 272 192
new 0 272 192
assign 1 273 193
toString 0 273 193
assign 1 274 194
existsGet 0 274 194
return 1 317 202
assign 1 329 208
new 0 329 208
assign 1 330 209
toString 0 330 209
assign 1 331 210
existsGet 0 331 210
return 1 374 218
assign 1 378 223
writerGet 0 378 223
open 0 378 224
assign 1 379 225
writerGet 0 379 225
close 0 379 226
assign 1 383 233
existsGet 0 383 233
assign 1 383 234
not 0 383 239
return 1 384 240
assign 1 386 242
contentsNoCheckGet 0 386 242
return 1 386 243
assign 1 401 252
readerGet 0 401 252
open 0 402 253
assign 1 403 254
readString 0 403 254
close 0 404 255
return 1 406 257
assign 1 410 268
pathGet 0 410 268
assign 1 410 269
parentGet 0 410 269
assign 1 410 270
fileGet 0 410 270
assign 1 410 271
existsGet 0 410 271
assign 1 410 272
not 0 410 277
assign 1 411 278
pathGet 0 411 278
assign 1 411 279
parentGet 0 411 279
assign 1 411 280
fileGet 0 411 280
makeDirs 0 411 281
contentsNoCheckSet 1 413 283
assign 1 427 295
writerGet 0 427 295
open 0 428 296
write 1 429 297
close 0 430 298
assign 1 436 304
new 0 436 304
return 1 443 308
assign 1 455 316
new 0 455 316
assign 1 456 317
toString 0 456 317
return 1 514 325
assign 1 534 336
apNew 1 534 336
return 1 535 337
assign 1 539 342
def 1 539 347
close 0 540 348
assign 1 542 350
def 1 542 355
close 0 543 356
assign 1 548 362
new 1 548 362
return 1 548 363
return 1 0 366
return 1 0 369
assign 1 0 372
assign 1 0 376
return 1 0 380
assign 1 0 383
assign 1 0 387
return 1 0 391
assign 1 0 394
assign 1 0 398
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -653750385: return bem_create_0();
case -124285366: return bem_once_0();
case 1669981631: return bem_isDirectoryGet_0();
case 2145418160: return bem_writerGetDirect_0();
case 196722112: return bem_readerGet_0();
case -634018133: return bem_tagGet_0();
case 1953121539: return bem_lastUpdatedGet_0();
case 40029875: return bem_pathGetDirect_0();
case 214466503: return bem_isFileGet_0();
case 848259769: return bem_delete_0();
case -919678965: return bem_writerGet_0();
case 740892297: return bem_sizeGet_0();
case 148544119: return bem_toString_0();
case -1092510954: return bem_copy_0();
case 1415454433: return bem_mkdirs_0();
case -916310564: return bem_readerGetDirect_0();
case 971841201: return bem_fieldIteratorGet_0();
case -1011040198: return bem_isDirGet_0();
case -1770827591: return bem_contentsNoCheckGet_0();
case 2146604653: return bem_new_0();
case -2007275567: return bem_many_0();
case 393738758: return bem_serializeToString_0();
case -1750720088: return bem_hashGet_0();
case 2144693643: return bem_deserializeClassNameGet_0();
case -212742483: return bem_echo_0();
case 908678857: return bem_print_0();
case 2142572680: return bem_close_0();
case -881577546: return bem_classNameGet_0();
case 1782351683: return bem_serializeContents_0();
case -224465120: return bem_sourceFileNameGet_0();
case 1099447992: return bem_fieldNamesGet_0();
case -2026540930: return bem_contentsGet_0();
case 625155651: return bem_existsGet_0();
case 156027127: return bem_makeFile_0();
case -1320337156: return bem_makeDirs_0();
case 472302085: return bem_pathGet_0();
case 569361306: return bem_iteratorGet_0();
case 641839943: return bem_toAny_0();
case -2031839191: return bem_serializationIteratorGet_0();
case -1762483507: return bem_mkdir_0();
case 829866417: return bem_absPathGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -448360789: return bem_otherClass_1(bevd_0);
case 1703616583: return bem_notEquals_1(bevd_0);
case 1367146792: return bem_sameClass_1(bevd_0);
case -1903947921: return bem_readerSet_1(bevd_0);
case 970786455: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1586811529: return bem_undefined_1(bevd_0);
case -221890006: return bem_writerSetDirect_1(bevd_0);
case -1519516879: return bem_equals_1(bevd_0);
case 1396531004: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
case -884607798: return bem_def_1(bevd_0);
case 266554874: return bem_writerSet_1(bevd_0);
case -359346681: return bem_sameType_1(bevd_0);
case -1565662060: return bem_sameObject_1(bevd_0);
case 1730397553: return bem_undef_1(bevd_0);
case 1236734559: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1928510621: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1749773511: return bem_copyFile_1(bevd_0);
case 1423794511: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case -680043600: return bem_pathSet_1(bevd_0);
case -249326151: return bem_copyTo_1(bevd_0);
case 389340449: return bem_otherType_1(bevd_0);
case 1446250233: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1037542647: return bem_apNew_1(bevd_0);
case -872115670: return bem_defined_1(bevd_0);
case 326949551: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1869560208: return bem_readerSetDirect_1(bevd_0);
case 337428758: return bem_lastUpdatedSet_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1118568526: return bem_pathSetDirect_1(bevd_0);
case 338229476: return bem_new_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 29395685: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 827793836: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1899980628: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1061986002: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1194360433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -454033656: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 696322560: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOFile_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_2_4_IOFile_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOFile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst = (BEC_2_2_4_IOFile) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_type;
}
}
