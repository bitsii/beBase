package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
private static byte[] becc_BEC_2_2_4_IOFile_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_2_4_IOFile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_inst;

public static BET_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public BEC_2_2_4_IOFile bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) throws Throwable {
bem_pathSet_1(beva__path);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 60 */
return bevp_reader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_writer == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 67 */
return bevp_writer;
} /*method end*/
public BEC_2_2_4_IOFile bem_delete_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_llpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.delete();
         } /* Line: 96 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bemd_0(942364087);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1610402342);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1118651740);
bevt_0_tmpany_phold.bemd_0(-1104471287);
bevt_3_tmpany_phold = beva_other.bemd_0(-1598799253);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_tmpany_phold.bemd_0(2102998497);
bevt_4_tmpany_phold = bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_tmpany_phold.bemd_0(2102998497);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_mkdirs_0() throws Throwable {
bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_mkdir_0() throws Throwable {
bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_makeDirs_0() throws Throwable {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = be.BECS_Runtime.boolFalse;
bevl_t = be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevl_strn.bemd_0(-1019354711);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_5_tmpany_phold = bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_tmpany_phold = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 137 */ {
return this;
} /* Line: 139 */
bevt_7_tmpany_phold = bevl_parentpath.bemd_0(-1118651740);
bevt_7_tmpany_phold.bemd_0(-1104471287);

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.mkdir();
         } /* Line: 164 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirectoryGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isDirGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isDirectory()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 216 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFileGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 239 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isFile()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 264 */
return bevl_result;
} /*method end*/
public BEC_2_2_4_IOFile bem_makeFile_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_writerGet_0();
bevt_0_tmpany_phold.bemd_0(2102998497);
bevt_1_tmpany_phold = bem_writerGet_0();
bevt_1_tmpany_phold.bemd_0(1691942809);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 282 */ {
return null;
} /* Line: 283 */
bevt_2_tmpany_phold = bem_contentsNoCheckGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsNoCheckGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_res = null;
bevl_r = bem_readerGet_0();
bevl_r.bemd_0(2102998497);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(775395299);
bevl_r.bemd_0(1691942809);
return bevl_res;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
bevt_4_tmpany_phold = bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_parentGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_7_tmpany_phold = bem_pathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 298 */
bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_6_6_SystemObject bevl_w = null;
bevl_w = bem_writerGet_0();
bevl_w.bemd_0(2102998497);
bevl_w.bemd_1(-302899365, beva_contents);
bevl_w.bemd_0(1691942809);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (new BEC_2_4_3_MathInt());

    java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
    bevl_sz.bevi_int = (int) bevls_f.length();
    return bevl_sz;
} /*method end*/
public BEC_2_5_4_LogicBool bem_existsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
bevl_tvala = be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
      if (bevls_f.exists()) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
      return bevl_tvala;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_absPathGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;
 /* Line: 374 */ {

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        //bevl_abstr = new BEC_2_4_6_TextString(bevls_f.toPath().toRealPath().toString());
        bevl_abstr = new BEC_2_4_6_TextString(bevls_f.getCanonicalPath());
        } /* Line: 375 */
bevl_absp = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public BEC_2_2_4_IOFile bem_close_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevp_reader.bemd_0(1691942809);
} /* Line: 392 */
if (bevp_writer == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevp_writer.bemd_0(1691942809);
} /* Line: 395 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {47, 47, 51, 51, 55, 59, 59, 60, 60, 62, 66, 66, 67, 67, 69, 83, 106, 106, 106, 106, 107, 107, 108, 108, 109, 110, 111, 112, 112, 117, 120, 131, 132, 133, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 136, 137, 139, 141, 141, 177, 177, 189, 190, 191, 225, 237, 238, 239, 273, 277, 277, 278, 278, 282, 282, 282, 283, 285, 285, 289, 290, 291, 292, 293, 297, 297, 297, 297, 297, 297, 298, 298, 298, 298, 300, 304, 305, 306, 307, 312, 319, 331, 332, 366, 386, 387, 391, 391, 392, 394, 394, 395, 400, 400, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 27, 28, 32, 38, 43, 44, 45, 47, 52, 57, 58, 59, 61, 66, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 98, 102, 119, 120, 121, 122, 123, 124, 125, 127, 128, 133, 134, 137, 141, 144, 145, 147, 149, 150, 159, 160, 166, 167, 168, 176, 182, 183, 184, 192, 197, 198, 199, 200, 207, 208, 213, 214, 216, 217, 222, 223, 224, 225, 226, 237, 238, 239, 240, 241, 246, 247, 248, 249, 250, 252, 257, 258, 259, 260, 265, 269, 274, 275, 281, 292, 293, 298, 303, 304, 306, 311, 312, 318, 319, 322, 325, 329, 333};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 47 21
new 1 47 21
pathSet 1 47 22
assign 1 51 27
apNew 1 51 27
pathSet 1 51 28
pathSet 1 55 32
assign 1 59 38
undef 1 59 43
assign 1 60 44
toString 0 60 44
assign 1 60 45
new 1 60 45
return 1 62 47
assign 1 66 52
undef 1 66 57
assign 1 67 58
toString 0 67 58
assign 1 67 59
new 1 67 59
return 1 69 61
assign 1 83 66
existsGet 0 83 66
assign 1 106 83
pathGet 0 106 83
assign 1 106 84
parentGet 0 106 84
assign 1 106 85
fileGet 0 106 85
makeDirs 0 106 86
assign 1 107 87
writerGet 0 107 87
assign 1 107 88
open 0 107 88
assign 1 108 89
readerGet 0 108 89
assign 1 108 90
open 0 108 90
copyData 1 109 91
close 0 110 92
close 0 111 93
assign 1 112 94
new 0 112 94
return 1 112 95
makeDirs 0 117 98
makeDirs 0 120 102
assign 1 131 119
toString 0 131 119
assign 1 132 120
new 0 132 120
assign 1 133 121
new 0 133 121
assign 1 134 122
new 0 134 122
assign 1 135 123
toString 0 135 123
assign 1 135 124
emptyGet 0 135 124
assign 1 135 125
notEquals 1 135 125
assign 1 135 127
existsGet 0 135 127
assign 1 135 128
not 0 135 133
assign 1 0 134
assign 1 0 137
assign 1 0 141
assign 1 136 144
parentGet 0 136 144
assign 1 137 145
equals 1 137 145
return 1 139 147
assign 1 141 149
fileGet 0 141 149
makeDirs 0 141 150
assign 1 177 159
isDirGet 0 177 159
return 1 177 160
assign 1 189 166
new 0 189 166
assign 1 190 167
toString 0 190 167
assign 1 191 168
existsGet 0 191 168
return 1 225 176
assign 1 237 182
new 0 237 182
assign 1 238 183
toString 0 238 183
assign 1 239 184
existsGet 0 239 184
return 1 273 192
assign 1 277 197
writerGet 0 277 197
open 0 277 198
assign 1 278 199
writerGet 0 278 199
close 0 278 200
assign 1 282 207
existsGet 0 282 207
assign 1 282 208
not 0 282 213
return 1 283 214
assign 1 285 216
contentsNoCheckGet 0 285 216
return 1 285 217
assign 1 289 222
readerGet 0 289 222
open 0 290 223
assign 1 291 224
readString 0 291 224
close 0 292 225
return 1 293 226
assign 1 297 237
pathGet 0 297 237
assign 1 297 238
parentGet 0 297 238
assign 1 297 239
fileGet 0 297 239
assign 1 297 240
existsGet 0 297 240
assign 1 297 241
not 0 297 246
assign 1 298 247
pathGet 0 298 247
assign 1 298 248
parentGet 0 298 248
assign 1 298 249
fileGet 0 298 249
makeDirs 0 298 250
contentsNoCheckSet 1 300 252
assign 1 304 257
writerGet 0 304 257
open 0 305 258
write 1 306 259
close 0 307 260
assign 1 312 265
new 0 312 265
return 1 319 269
assign 1 331 274
new 0 331 274
assign 1 332 275
toString 0 332 275
return 1 366 281
assign 1 386 292
apNew 1 386 292
return 1 387 293
assign 1 391 298
def 1 391 303
close 0 392 304
assign 1 394 306
def 1 394 311
close 0 395 312
assign 1 400 318
new 1 400 318
return 1 400 319
return 1 0 322
assign 1 0 325
assign 1 0 329
assign 1 0 333
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1997287327: return bem_iteratorGet_0();
case 426147: return bem_serializeContents_0();
case 1691942809: return bem_close_0();
case 1467647863: return bem_delete_0();
case -2123651968: return bem_makeFile_0();
case 1807708471: return bem_deserializeClassNameGet_0();
case -1104471287: return bem_makeDirs_0();
case 733491707: return bem_many_0();
case -2031797883: return bem_tagGet_0();
case 949159367: return bem_existsGet_0();
case -1969378987: return bem_toString_0();
case 1004296963: return bem_serializeToString_0();
case 1539306089: return bem_mkdir_0();
case 862230245: return bem_new_0();
case 441410739: return bem_mkdirs_0();
case -660446647: return bem_toAny_0();
case -964698991: return bem_sourceFileNameGet_0();
case -1508340427: return bem_absPathGet_0();
case 1198691422: return bem_echo_0();
case 264273241: return bem_create_0();
case 1250534894: return bem_contentsGet_0();
case -394014223: return bem_copy_0();
case 942364087: return bem_pathGet_0();
case -1402463163: return bem_classNameGet_0();
case -1599200223: return bem_contentsNoCheckGet_0();
case -950028708: return bem_fieldIteratorGet_0();
case 1640093839: return bem_print_0();
case -683692383: return bem_once_0();
case -44812979: return bem_readerGet_0();
case 625566790: return bem_sizeGet_0();
case -555435802: return bem_isFileGet_0();
case -736863918: return bem_isDirGet_0();
case 807677764: return bem_hashGet_0();
case 1024738309: return bem_serializationIteratorGet_0();
case -1598799253: return bem_writerGet_0();
case -976290499: return bem_isDirectoryGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1738186539: return bem_defined_1(bevd_0);
case 1701275297: return bem_apNew_1(bevd_0);
case -1485851211: return bem_copyTo_1(bevd_0);
case -1533142564: return bem_def_1(bevd_0);
case 284495540: return bem_sameType_1(bevd_0);
case -933363441: return bem_otherType_1(bevd_0);
case 2009511097: return bem_otherClass_1(bevd_0);
case 1798139923: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case 985286403: return bem_pathSet_1(bevd_0);
case 1477835530: return bem_notEquals_1(bevd_0);
case -517369990: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2088975267: return bem_readerSet_1(bevd_0);
case 1379952308: return bem_new_1(bevd_0);
case -154311710: return bem_writerSet_1(bevd_0);
case -1099214878: return bem_undef_1(bevd_0);
case -1309038751: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 297958587: return bem_undefined_1(bevd_0);
case -1436473197: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
case -2119284853: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -340932754: return bem_sameClass_1(bevd_0);
case -304656156: return bem_sameObject_1(bevd_0);
case -1277931163: return bem_copyFile_1(bevd_0);
case -1903807556: return bem_equals_1(bevd_0);
case -1453873354: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 9381579: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -345291091: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -152953595: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1468601573: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 133687058: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1813133765: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1806695675: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1845241032: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOFile_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_2_4_IOFile_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOFile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst = (BEC_2_2_4_IOFile) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_type;
}
}
