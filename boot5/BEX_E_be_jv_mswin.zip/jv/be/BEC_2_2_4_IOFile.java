package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
private static byte[] becc_BEC_2_2_4_IOFile_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_2_4_IOFile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_inst;
public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public BEC_2_2_4_IOFile bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) throws Throwable {
bem_pathSet_1(beva__path);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 60 */
return bevp_reader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_writer == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 67 */
return bevp_writer;
} /*method end*/
public BEC_2_2_4_IOFile bem_delete_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_llpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.delete();
         } /* Line: 96 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bemd_0(-903440535);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-327144085);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1820222002);
bevt_0_tmpany_phold.bemd_0(-1360537257);
bevt_3_tmpany_phold = beva_other.bemd_0(-1942907448);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_tmpany_phold.bemd_0(-414999694);
bevt_4_tmpany_phold = bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_tmpany_phold.bemd_0(-414999694);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_mkdirs_0() throws Throwable {
bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_mkdir_0() throws Throwable {
bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_makeDirs_0() throws Throwable {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = be.BECS_Runtime.boolFalse;
bevl_t = be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevl_strn.bemd_0(-48715651);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_5_tmpany_phold = bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_tmpany_phold = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 137 */ {
return this;
} /* Line: 139 */
bevt_7_tmpany_phold = bevl_parentpath.bemd_0(-1820222002);
bevt_7_tmpany_phold.bemd_0(-1360537257);

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.mkdir();
         } /* Line: 164 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirectoryGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isDirGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isDirectory()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 216 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFileGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 239 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isFile()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 264 */
return bevl_result;
} /*method end*/
public BEC_2_2_4_IOFile bem_makeFile_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_writerGet_0();
bevt_0_tmpany_phold.bemd_0(-414999694);
bevt_1_tmpany_phold = bem_writerGet_0();
bevt_1_tmpany_phold.bemd_0(-408108305);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 282 */ {
return null;
} /* Line: 283 */
bevt_2_tmpany_phold = bem_contentsNoCheckGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsNoCheckGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_res = null;
bevl_r = bem_readerGet_0();
bevl_r.bemd_0(-414999694);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(1535696290);
bevl_r.bemd_0(-408108305);
return bevl_res;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
bevt_4_tmpany_phold = bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_parentGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_7_tmpany_phold = bem_pathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 298 */
bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_6_6_SystemObject bevl_w = null;
bevl_w = bem_writerGet_0();
bevl_w.bemd_0(-414999694);
bevl_w.bemd_1(-110686327, beva_contents);
bevl_w.bemd_0(-408108305);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (new BEC_2_4_3_MathInt());

    java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
    bevl_sz.bevi_int = (int) bevls_f.length();
    return bevl_sz;
} /*method end*/
public BEC_2_5_4_LogicBool bem_existsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
bevl_tvala = be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
      if (bevls_f.exists()) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
      return bevl_tvala;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_absPathGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;
 /* Line: 374 */ {

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        //bevl_abstr = new BEC_2_4_6_TextString(bevls_f.toPath().toRealPath().toString());
        bevl_abstr = new BEC_2_4_6_TextString(bevls_f.getCanonicalPath());
        } /* Line: 375 */
bevl_absp = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public BEC_2_2_4_IOFile bem_close_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevp_reader.bemd_0(-408108305);
} /* Line: 392 */
if (bevp_writer == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevp_writer.bemd_0(-408108305);
} /* Line: 395 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {47, 47, 51, 51, 55, 59, 59, 60, 60, 62, 66, 66, 67, 67, 69, 83, 106, 106, 106, 106, 107, 107, 108, 108, 109, 110, 111, 112, 112, 117, 120, 131, 132, 133, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 136, 137, 139, 141, 141, 177, 177, 189, 190, 191, 225, 237, 238, 239, 273, 277, 277, 278, 278, 282, 282, 282, 283, 285, 285, 289, 290, 291, 292, 293, 297, 297, 297, 297, 297, 297, 298, 298, 298, 298, 300, 304, 305, 306, 307, 312, 319, 331, 332, 366, 386, 387, 391, 391, 392, 394, 394, 395, 400, 400, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 24, 25, 29, 35, 40, 41, 42, 44, 49, 54, 55, 56, 58, 63, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 95, 99, 116, 117, 118, 119, 120, 121, 122, 124, 125, 130, 131, 134, 138, 141, 142, 144, 146, 147, 156, 157, 163, 164, 165, 173, 179, 180, 181, 189, 194, 195, 196, 197, 204, 205, 210, 211, 213, 214, 219, 220, 221, 222, 223, 234, 235, 236, 237, 238, 243, 244, 245, 246, 247, 249, 254, 255, 256, 257, 262, 266, 271, 272, 278, 289, 290, 295, 300, 301, 303, 308, 309, 315, 316, 319, 322, 326, 330};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 47 18
new 1 47 18
pathSet 1 47 19
assign 1 51 24
apNew 1 51 24
pathSet 1 51 25
pathSet 1 55 29
assign 1 59 35
undef 1 59 40
assign 1 60 41
toString 0 60 41
assign 1 60 42
new 1 60 42
return 1 62 44
assign 1 66 49
undef 1 66 54
assign 1 67 55
toString 0 67 55
assign 1 67 56
new 1 67 56
return 1 69 58
assign 1 83 63
existsGet 0 83 63
assign 1 106 80
pathGet 0 106 80
assign 1 106 81
parentGet 0 106 81
assign 1 106 82
fileGet 0 106 82
makeDirs 0 106 83
assign 1 107 84
writerGet 0 107 84
assign 1 107 85
open 0 107 85
assign 1 108 86
readerGet 0 108 86
assign 1 108 87
open 0 108 87
copyData 1 109 88
close 0 110 89
close 0 111 90
assign 1 112 91
new 0 112 91
return 1 112 92
makeDirs 0 117 95
makeDirs 0 120 99
assign 1 131 116
toString 0 131 116
assign 1 132 117
new 0 132 117
assign 1 133 118
new 0 133 118
assign 1 134 119
new 0 134 119
assign 1 135 120
toString 0 135 120
assign 1 135 121
emptyGet 0 135 121
assign 1 135 122
notEquals 1 135 122
assign 1 135 124
existsGet 0 135 124
assign 1 135 125
not 0 135 130
assign 1 0 131
assign 1 0 134
assign 1 0 138
assign 1 136 141
parentGet 0 136 141
assign 1 137 142
equals 1 137 142
return 1 139 144
assign 1 141 146
fileGet 0 141 146
makeDirs 0 141 147
assign 1 177 156
isDirGet 0 177 156
return 1 177 157
assign 1 189 163
new 0 189 163
assign 1 190 164
toString 0 190 164
assign 1 191 165
existsGet 0 191 165
return 1 225 173
assign 1 237 179
new 0 237 179
assign 1 238 180
toString 0 238 180
assign 1 239 181
existsGet 0 239 181
return 1 273 189
assign 1 277 194
writerGet 0 277 194
open 0 277 195
assign 1 278 196
writerGet 0 278 196
close 0 278 197
assign 1 282 204
existsGet 0 282 204
assign 1 282 205
not 0 282 210
return 1 283 211
assign 1 285 213
contentsNoCheckGet 0 285 213
return 1 285 214
assign 1 289 219
readerGet 0 289 219
open 0 290 220
assign 1 291 221
readString 0 291 221
close 0 292 222
return 1 293 223
assign 1 297 234
pathGet 0 297 234
assign 1 297 235
parentGet 0 297 235
assign 1 297 236
fileGet 0 297 236
assign 1 297 237
existsGet 0 297 237
assign 1 297 238
not 0 297 243
assign 1 298 244
pathGet 0 298 244
assign 1 298 245
parentGet 0 298 245
assign 1 298 246
fileGet 0 298 246
makeDirs 0 298 247
contentsNoCheckSet 1 300 249
assign 1 304 254
writerGet 0 304 254
open 0 305 255
write 1 306 256
close 0 307 257
assign 1 312 262
new 0 312 262
return 1 319 266
assign 1 331 271
new 0 331 271
assign 1 332 272
toString 0 332 272
return 1 366 278
assign 1 386 289
apNew 1 386 289
return 1 387 290
assign 1 391 295
def 1 391 300
close 0 392 301
assign 1 394 303
def 1 394 308
close 0 395 309
assign 1 400 315
new 1 400 315
return 1 400 316
return 1 0 319
assign 1 0 322
assign 1 0 326
assign 1 0 330
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case 1247425014: return bem_mkdir_0();
case -92000884: return bem_contentsGet_0();
case -748319096: return bem_print_0();
case -258597009: return bem_hashGet_0();
case 900978335: return bem_serializeToString_0();
case -903440535: return bem_pathGet_0();
case -716540747: return bem_sizeGet_0();
case -1674098047: return bem_once_0();
case 1338975369: return bem_sourceFileNameGet_0();
case -149632320: return bem_toAny_0();
case -1942907448: return bem_writerGet_0();
case -7634332: return bem_classNameGet_0();
case 1824406478: return bem_readerGet_0();
case -29400896: return bem_create_0();
case -14402816: return bem_serializeContents_0();
case -48080710: return bem_isDirectoryGet_0();
case -1749103224: return bem_iteratorGet_0();
case -93701646: return bem_fieldIteratorGet_0();
case 861710738: return bem_many_0();
case -794227383: return bem_copy_0();
case 1598317335: return bem_makeFile_0();
case 156286248: return bem_isDirGet_0();
case 1852861322: return bem_isFileGet_0();
case -1550989834: return bem_mkdirs_0();
case -1514191588: return bem_delete_0();
case 36729806: return bem_absPathGet_0();
case -801589503: return bem_tagGet_0();
case -408108305: return bem_close_0();
case -1360537257: return bem_makeDirs_0();
case -124916815: return bem_new_0();
case -1701242685: return bem_serializationIteratorGet_0();
case -467186719: return bem_deserializeClassNameGet_0();
case -1052800757: return bem_echo_0();
case 837144761: return bem_existsGet_0();
case -353526653: return bem_contentsNoCheckGet_0();
case -51803385: return bem_toString_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case -1474467614: return bem_sameObject_1(bevd_0);
case 1271330536: return bem_apNew_1(bevd_0);
case 642489795: return bem_otherType_1(bevd_0);
case -223966486: return bem_new_1(bevd_0);
case 616348580: return bem_undef_1(bevd_0);
case -2047687746: return bem_readerSet_1(bevd_0);
case -73997568: return bem_equals_1(bevd_0);
case 1518481031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2036979549: return bem_notEquals_1(bevd_0);
case 550176080: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -983540661: return bem_undefined_1(bevd_0);
case 1970850163: return bem_sameType_1(bevd_0);
case -1391202250: return bem_defined_1(bevd_0);
case 226940097: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 706656041: return bem_pathSet_1(bevd_0);
case -271716565: return bem_copyTo_1(bevd_0);
case 1963600206: return bem_copyFile_1(bevd_0);
case 1187844877: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -2092712540: return bem_def_1(bevd_0);
case -93273669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -189727554: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case -218714893: return bem_otherClass_1(bevd_0);
case -1461384289: return bem_writerSet_1(bevd_0);
case -20159434: return bem_sameClass_1(bevd_0);
case -1497547399: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case -66460559: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1367679335: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1031466779: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2131321099: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 292502272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2093180987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -323049121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOFile_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_2_4_IOFile_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOFile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst = (BEC_2_2_4_IOFile) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst;
}
}
