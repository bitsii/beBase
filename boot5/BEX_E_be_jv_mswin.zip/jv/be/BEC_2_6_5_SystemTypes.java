package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_5_SystemTypes extends BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemTypes() { }
private static byte[] becc_BEC_2_6_5_SystemTypes_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_6_5_SystemTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_inst;

public static BET_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_bool;
public BEC_2_4_5_MathFloat bevp_float;
public BEC_2_6_5_SystemThing bevp_thing;
public BEC_2_4_6_TextString bevp_string;
public BEC_2_4_6_TextString bevp_byteBuffer;
public BEC_2_6_5_SystemTypes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_default_0() throws Throwable {
bevp_int = (new BEC_2_4_3_MathInt());
bevp_bool = be.BECS_Runtime.boolFalse;
bevp_float = (new BEC_2_4_5_MathFloat()).bem_new_0();
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_string = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_byteBuffer = (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_4_3_MathInt bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGet_0() throws Throwable {
return bevp_bool;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_boolGetDirect_0() throws Throwable {
return bevp_bool;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_boolSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGet_0() throws Throwable {
return bevp_float;
} /*method end*/
public final BEC_2_4_5_MathFloat bem_floatGetDirect_0() throws Throwable {
return bevp_float;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_floatSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGet_0() throws Throwable {
return bevp_thing;
} /*method end*/
public final BEC_2_6_5_SystemThing bem_thingGetDirect_0() throws Throwable {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGet_0() throws Throwable {
return bevp_string;
} /*method end*/
public final BEC_2_4_6_TextString bem_stringGetDirect_0() throws Throwable {
return bevp_string;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_string = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_stringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_string = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGet_0() throws Throwable {
return bevp_byteBuffer;
} /*method end*/
public final BEC_2_4_6_TextString bem_byteBufferGetDirect_0() throws Throwable {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_byteBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {309, 310, 311, 312, 313, 314, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 28, 32, 35, 38, 42, 46, 49, 52, 56, 60, 63, 66, 70, 74, 77, 80, 84, 88, 91, 94, 98, 102, 105, 108, 112};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 309 23
new 0 309 23
assign 1 310 24
new 0 310 24
assign 1 311 25
new 0 311 25
assign 1 312 26
new 0 312 26
assign 1 313 27
new 0 313 27
assign 1 314 28
new 0 314 28
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
return 1 0 74
return 1 0 77
assign 1 0 80
assign 1 0 84
return 1 0 88
return 1 0 91
assign 1 0 94
assign 1 0 98
return 1 0 102
return 1 0 105
assign 1 0 108
assign 1 0 112
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1370488335: return bem_toString_0();
case -1223303034: return bem_serializeContents_0();
case 1969920483: return bem_intGet_0();
case -93449420: return bem_once_0();
case -1716598520: return bem_boolGetDirect_0();
case 2077899298: return bem_print_0();
case -2000869502: return bem_deserializeClassNameGet_0();
case 1035238963: return bem_floatGet_0();
case -1688503329: return bem_intGetDirect_0();
case -740958985: return bem_echo_0();
case -312557248: return bem_copy_0();
case 1144594612: return bem_toAny_0();
case -1654796577: return bem_byteBufferGet_0();
case -904008064: return bem_serializationIteratorGet_0();
case -177347555: return bem_floatGetDirect_0();
case -1043917515: return bem_boolGet_0();
case -980019477: return bem_thingGet_0();
case -1075334878: return bem_stringGetDirect_0();
case 169495728: return bem_byteBufferGetDirect_0();
case 1544079043: return bem_many_0();
case -1463210484: return bem_new_0();
case 1923816180: return bem_create_0();
case 674241091: return bem_iteratorGet_0();
case -898304671: return bem_fieldNamesGet_0();
case -538312537: return bem_fieldIteratorGet_0();
case 1316670529: return bem_classNameGet_0();
case 1921834118: return bem_sourceFileNameGet_0();
case -1836675075: return bem_hashGet_0();
case -638250551: return bem_default_0();
case 503646675: return bem_thingGetDirect_0();
case 717529486: return bem_stringGet_0();
case -2054180438: return bem_tagGet_0();
case -1345920383: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1244811184: return bem_stringSetDirect_1(bevd_0);
case -1755509471: return bem_otherClass_1(bevd_0);
case 1411392795: return bem_undefined_1(bevd_0);
case 2000083269: return bem_byteBufferSet_1(bevd_0);
case -1086398098: return bem_defined_1(bevd_0);
case 747292122: return bem_boolSetDirect_1(bevd_0);
case -588775114: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1329302364: return bem_floatSet_1(bevd_0);
case 942435111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 532034178: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 74030122: return bem_boolSet_1(bevd_0);
case -1120344169: return bem_def_1(bevd_0);
case 1136905977: return bem_undef_1(bevd_0);
case 1893585148: return bem_sameType_1(bevd_0);
case -640296056: return bem_notEquals_1(bevd_0);
case 1305486032: return bem_equals_1(bevd_0);
case 573294422: return bem_floatSetDirect_1(bevd_0);
case 1343586726: return bem_byteBufferSetDirect_1(bevd_0);
case -227789211: return bem_copyTo_1(bevd_0);
case 1195674453: return bem_stringSet_1(bevd_0);
case 1002778593: return bem_thingSetDirect_1(bevd_0);
case 675409179: return bem_sameObject_1(bevd_0);
case 1761949929: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -661924012: return bem_intSet_1(bevd_0);
case -1341114671: return bem_thingSet_1(bevd_0);
case -257057695: return bem_otherType_1(bevd_0);
case -437149119: return bem_intSetDirect_1(bevd_0);
case -164720496: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -882013396: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 265265077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1327331293: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -305196806: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 341335680: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2006332895: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1214675142: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemTypes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_5_SystemTypes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_5_SystemTypes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst = (BEC_2_6_5_SystemTypes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_type;
}
}
