package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_5_SystemTypes extends BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemTypes() { }
private static byte[] becc_BEC_2_6_5_SystemTypes_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_6_5_SystemTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_inst;

public static BET_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_bool;
public BEC_2_4_5_MathFloat bevp_float;
public BEC_2_6_5_SystemThing bevp_thing;
public BEC_2_4_6_TextString bevp_string;
public BEC_2_4_6_TextString bevp_byteBuffer;
public BEC_2_6_5_SystemTypes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_default_0() throws Throwable {
bevp_int = (new BEC_2_4_3_MathInt());
bevp_bool = be.BECS_Runtime.boolFalse;
bevp_float = (new BEC_2_4_5_MathFloat()).bem_new_0();
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_string = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_byteBuffer = (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_4_3_MathInt bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGet_0() throws Throwable {
return bevp_bool;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_boolGetDirect_0() throws Throwable {
return bevp_bool;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_boolSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGet_0() throws Throwable {
return bevp_float;
} /*method end*/
public final BEC_2_4_5_MathFloat bem_floatGetDirect_0() throws Throwable {
return bevp_float;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_floatSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGet_0() throws Throwable {
return bevp_thing;
} /*method end*/
public final BEC_2_6_5_SystemThing bem_thingGetDirect_0() throws Throwable {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGet_0() throws Throwable {
return bevp_string;
} /*method end*/
public final BEC_2_4_6_TextString bem_stringGetDirect_0() throws Throwable {
return bevp_string;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_string = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_stringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_string = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGet_0() throws Throwable {
return bevp_byteBuffer;
} /*method end*/
public final BEC_2_4_6_TextString bem_byteBufferGetDirect_0() throws Throwable {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_byteBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {42, 43, 44, 45, 46, 47, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 28, 32, 35, 38, 42, 46, 49, 52, 56, 60, 63, 66, 70, 74, 77, 80, 84, 88, 91, 94, 98, 102, 105, 108, 112};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 42 23
new 0 42 23
assign 1 43 24
new 0 43 24
assign 1 44 25
new 0 44 25
assign 1 45 26
new 0 45 26
assign 1 46 27
new 0 46 27
assign 1 47 28
new 0 47 28
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
return 1 0 74
return 1 0 77
assign 1 0 80
assign 1 0 84
return 1 0 88
return 1 0 91
assign 1 0 94
assign 1 0 98
return 1 0 102
return 1 0 105
assign 1 0 108
assign 1 0 112
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 254283761: return bem_classNameGet_0();
case 32986096: return bem_tagGet_0();
case -432104267: return bem_floatGet_0();
case 1337499076: return bem_fieldIteratorGet_0();
case -434766936: return bem_many_0();
case -1193538733: return bem_echo_0();
case -989477235: return bem_stringGetDirect_0();
case -1667230363: return bem_new_0();
case -2068645774: return bem_toString_0();
case 1730536659: return bem_thingGet_0();
case 656174411: return bem_iteratorGet_0();
case 1258540231: return bem_print_0();
case 1269936366: return bem_byteBufferGetDirect_0();
case 588536435: return bem_byteBufferGet_0();
case 1917320518: return bem_thingGetDirect_0();
case -224678489: return bem_boolGetDirect_0();
case 181316061: return bem_serializeContents_0();
case 262658837: return bem_default_0();
case 1333189262: return bem_copy_0();
case -1134589630: return bem_serializeToString_0();
case 1887791078: return bem_toAny_0();
case 455412310: return bem_stringGet_0();
case 1104438617: return bem_serializationIteratorGet_0();
case -810892117: return bem_sourceFileNameGet_0();
case 238716313: return bem_once_0();
case -1236615504: return bem_intGet_0();
case -1916545082: return bem_hashGet_0();
case -1971716232: return bem_intGetDirect_0();
case 1105083208: return bem_floatGetDirect_0();
case 762178918: return bem_boolGet_0();
case 470335985: return bem_fieldNamesGet_0();
case 1422294520: return bem_create_0();
case 1433312714: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case -1755943056: return bem_byteBufferSet_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1080562134: return bem_intSet_1(bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -300900943: return bem_floatSetDirect_1(bevd_0);
case -409487465: return bem_stringSet_1(bevd_0);
case -249998429: return bem_intSetDirect_1(bevd_0);
case 289095688: return bem_boolSetDirect_1(bevd_0);
case 835948559: return bem_thingSetDirect_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case -392939170: return bem_stringSetDirect_1(bevd_0);
case 1009384673: return bem_byteBufferSetDirect_1(bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case -1698062479: return bem_thingSet_1(bevd_0);
case 902696451: return bem_floatSet_1(bevd_0);
case 1290216463: return bem_def_1(bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case 1401014016: return bem_boolSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemTypes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_5_SystemTypes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_5_SystemTypes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst = (BEC_2_6_5_SystemTypes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_type;
}
}
