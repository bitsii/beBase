package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_10_JsonMarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_JsonMarshaller() { }
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x4D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_1 = {0x31,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_1 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_2 = {0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_2 = (new BEC_2_4_3_MathInt(4));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_3 = {0x37};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_4 = {0x33,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_5 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_7 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_6 = {0x5C,0x75};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_9 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_10 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_11 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_12 = (new BEC_2_4_3_MathInt(87));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_13 = (new BEC_2_4_3_MathInt(13));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_8 = {0x66,0x66,0x63,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_9 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_10 = {0x30,0x30,0x33,0x66,0x66};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_14 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_15 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_16 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_17 = (new BEC_2_4_3_MathInt(87));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_18 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_19 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_20 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_21 = (new BEC_2_4_3_MathInt(87));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_11 = {0x5B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_12 = {0x2C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_13 = {0x5D};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_14 = {0x7B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_15 = {0x3A};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_16 = {0x7D};
public static BEC_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_inst;

public static BET_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_9_4_ContainerList bevp_arr;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_boo;
public BEC_2_4_6_TextString bevp_q;
public BEC_2_4_17_TextMultiByteIterator bevp_mbi;
public BEC_2_4_6_TextString bevp_txtpt;
public BEC_2_4_6_TextString bevp_escaped;
public BEC_2_4_10_JsonMarshaller bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevp_str = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_arr = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
bevp_boo = (new BEC_2_5_4_LogicBool()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_q = bevt_1_ta_ph.bem_quoteGet_0();
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_0();
bevp_txtpt = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_escaped = (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_marshall_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_4_6_TextString bevl_bb = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 310*/ {
bem_new_0();
} /* Line: 311*/
bevl_bb = (new BEC_2_4_6_TextString()).bem_new_0();
bem_marshallWriteInst_2(beva_inst, bevl_bb);
bevt_1_ta_ph = bevl_bb.bem_toString_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWrite_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 319*/ {
bem_new_0();
} /* Line: 320*/
bem_marshallWriteInst_2(beva_inst, beva_writer);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteInst_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (beva_inst == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_0));
beva_writer.bemd_1(-1746699146, bevt_1_ta_ph);
} /* Line: 327*/
 else /* Line: 326*/ {
bevt_2_ta_ph = beva_inst.bemd_1(1621914759, bevp_str);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 328*/ {
bem_marshallWriteString_2((BEC_2_4_6_TextString) beva_inst , beva_writer);
} /* Line: 329*/
 else /* Line: 326*/ {
bevt_3_ta_ph = beva_inst.bemd_1(1621914759, bevp_arr);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 330*/ {
bem_marshallWriteList_2(beva_inst, beva_writer);
} /* Line: 331*/
 else /* Line: 326*/ {
bevt_4_ta_ph = beva_inst.bemd_1(1621914759, bevp_map);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 332*/ {
bem_marshallWriteMap_2(beva_inst, beva_writer);
} /* Line: 333*/
 else /* Line: 326*/ {
bevt_5_ta_ph = beva_inst.bemd_1(1621914759, bevp_int);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 334*/ {
bevt_6_ta_ph = beva_inst.bemd_0(-2068645774);
beva_writer.bemd_1(-1746699146, bevt_6_ta_ph);
} /* Line: 335*/
 else /* Line: 326*/ {
bevt_7_ta_ph = beva_inst.bemd_1(1621914759, bevp_boo);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 336*/ {
bevt_8_ta_ph = beva_inst.bemd_0(-2068645774);
beva_writer.bemd_1(-1746699146, bevt_8_ta_ph);
} /* Line: 337*/
 else /* Line: 338*/ {
bevt_9_ta_ph = beva_inst.bemd_0(-2068645774);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_9_ta_ph , beva_writer);
} /* Line: 339*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_jsonEscapePoint_2(BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_txt) throws Throwable {
BEC_2_4_3_MathInt bevl_rcap = null;
BEC_2_4_3_MathInt bevl_txtsznow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_u = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_7_JsonEscapes bevl_esc = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_first = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_4_3_MathInt bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_4_3_MathInt bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_4_3_MathInt bevt_92_ta_ph = null;
bevl_rcap = (new BEC_2_4_3_MathInt());
bevl_txtsznow = beva_txt.bem_sizeGet_0();
bevl_size = beva_txtpt.bem_sizeGet_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevl_u = beva_txtpt.bem_getInt_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevt_3_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_0;
if (bevl_size.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 352*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_1));
bevt_4_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_5_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_4_ta_ph);
} /* Line: 353*/
 else /* Line: 351*/ {
bevt_7_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_1;
if (bevl_size.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_2));
bevt_8_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_9_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_8_ta_ph);
} /* Line: 357*/
 else /* Line: 351*/ {
bevt_11_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_2;
if (bevl_size.bevi_int == bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 360*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_3));
bevt_12_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_13_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_12_ta_ph);
} /* Line: 361*/
} /* Line: 351*/
} /* Line: 351*/
bevt_15_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_3;
if (bevl_size.bevi_int > bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 363*/ {
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 364*/ {
if (bevl_i.bevi_int < bevl_size.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 365*/ {
beva_txtpt.bem_getInt_2(bevl_i, bevl_u);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_17_ta_ph = bevl_value.bem_shiftLeft_1(bevt_18_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_4));
bevt_20_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_21_ta_ph);
bevt_19_ta_ph = bevl_u.bem_and_1(bevt_20_ta_ph);
bevl_value = bevt_17_ta_ph.bem_add_1(bevt_19_ta_ph);
bevl_i.bevi_int++;
} /* Line: 364*/
 else /* Line: 364*/ {
break;
} /* Line: 364*/
} /* Line: 364*/
} /* Line: 364*/
bevt_23_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_4;
if (bevl_size.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 371*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(0));
} /* Line: 372*/
 else /* Line: 371*/ {
bevt_25_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_5;
if (bevl_size.bevi_int == bevt_25_ta_ph.bevi_int) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 373*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(2));
} /* Line: 374*/
 else /* Line: 375*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_27_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_28_ta_ph);
if (bevl_value.bevi_int < bevt_27_ta_ph.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 376*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(7));
} /* Line: 377*/
 else /* Line: 378*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(13));
} /* Line: 379*/
} /* Line: 376*/
} /* Line: 371*/
bevt_31_ta_ph = beva_txt.bem_capacityGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_subtract_1(bevl_txtsznow);
if (bevt_30_ta_ph.bevi_int < bevl_rcap.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_32_ta_ph = bevl_txtsznow.bem_add_1(bevl_rcap);
beva_txt.bem_capacitySet_1(bevt_32_ta_ph);
} /* Line: 384*/
bevt_34_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_6;
if (bevl_rcap.bevi_int == bevt_34_ta_ph.bevi_int) {
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 387*/ {
bevl_esc = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevt_35_ta_ph = bevl_esc.bem_toEscapesGet_0();
bevl_escval = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_get_1(beva_txtpt);
if (bevl_escval == null) {
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 391*/ {
beva_txt.bem_addValue_1(bevl_escval);
} /* Line: 392*/
 else /* Line: 393*/ {
beva_txt.bem_addValue_1(beva_txtpt);
} /* Line: 395*/
} /* Line: 391*/
 else /* Line: 387*/ {
bevt_38_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_7;
if (bevl_rcap.bevi_int > bevt_38_ta_ph.bevi_int) {
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 397*/ {
bevt_40_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_8;
if (bevl_rcap.bevi_int == bevt_40_ta_ph.bevi_int) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 398*/ {
bevt_42_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_41_ta_ph = beva_txt.bem_addValue_1(bevt_42_ta_ph);
bevt_46_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_9;
bevt_45_ta_ph = (BEC_2_4_3_MathInt) bevt_46_ta_ph.bem_once_0();
bevt_44_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_45_ta_ph);
bevt_48_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_10;
bevt_47_ta_ph = (BEC_2_4_3_MathInt) bevt_48_ta_ph.bem_once_0();
bevt_50_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_11;
bevt_49_ta_ph = (BEC_2_4_3_MathInt) bevt_50_ta_ph.bem_once_0();
bevt_52_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_12;
bevt_51_ta_ph = (BEC_2_4_3_MathInt) bevt_52_ta_ph.bem_once_0();
bevt_43_ta_ph = bevl_value.bem_toString_4(bevt_44_ta_ph, bevt_47_ta_ph, bevt_49_ta_ph, bevt_51_ta_ph);
bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
} /* Line: 399*/
 else /* Line: 398*/ {
bevt_54_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_13;
if (bevl_rcap.bevi_int == bevt_54_ta_ph.bevi_int) {
bevt_53_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_53_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_56_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_55_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_56_ta_ph);
bevl_value.bem_subtractValue_1(bevt_55_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_7));
bevt_57_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_58_ta_ph);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_8));
bevt_61_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_ta_ph);
bevt_60_ta_ph = bevl_value.bem_and_1(bevt_61_ta_ph);
bevt_63_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_59_ta_ph = bevt_60_ta_ph.bem_shiftRight_1(bevt_63_ta_ph);
bevl_first = bevt_57_ta_ph.bem_or_1(bevt_59_ta_ph);
bevt_65_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_9));
bevt_64_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_ta_ph);
bevt_68_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_10));
bevt_67_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_ta_ph);
bevt_66_ta_ph = bevl_value.bem_and_1(bevt_67_ta_ph);
bevl_last = bevt_64_ta_ph.bem_or_1(bevt_66_ta_ph);
bevt_70_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_69_ta_ph = beva_txt.bem_addValue_1(bevt_70_ta_ph);
bevt_74_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_14;
bevt_73_ta_ph = (BEC_2_4_3_MathInt) bevt_74_ta_ph.bem_once_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_73_ta_ph);
bevt_76_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_15;
bevt_75_ta_ph = (BEC_2_4_3_MathInt) bevt_76_ta_ph.bem_once_0();
bevt_78_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_16;
bevt_77_ta_ph = (BEC_2_4_3_MathInt) bevt_78_ta_ph.bem_once_0();
bevt_80_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_17;
bevt_79_ta_ph = (BEC_2_4_3_MathInt) bevt_80_ta_ph.bem_once_0();
bevt_71_ta_ph = bevl_first.bem_toString_4(bevt_72_ta_ph, bevt_75_ta_ph, bevt_77_ta_ph, bevt_79_ta_ph);
bevt_69_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_81_ta_ph = beva_txt.bem_addValue_1(bevt_82_ta_ph);
bevt_86_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_18;
bevt_85_ta_ph = (BEC_2_4_3_MathInt) bevt_86_ta_ph.bem_once_0();
bevt_84_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_85_ta_ph);
bevt_88_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_19;
bevt_87_ta_ph = (BEC_2_4_3_MathInt) bevt_88_ta_ph.bem_once_0();
bevt_90_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_20;
bevt_89_ta_ph = (BEC_2_4_3_MathInt) bevt_90_ta_ph.bem_once_0();
bevt_92_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_21;
bevt_91_ta_ph = (BEC_2_4_3_MathInt) bevt_92_ta_ph.bem_once_0();
bevt_83_ta_ph = bevl_last.bem_toString_4(bevt_84_ta_ph, bevt_87_ta_ph, bevt_89_ta_ph, bevt_91_ta_ph);
bevt_81_ta_ph.bem_addValue_1(bevt_83_ta_ph);
} /* Line: 405*/
} /* Line: 398*/
} /* Line: 398*/
} /* Line: 387*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_1(BEC_2_6_6_SystemObject beva_toEscape) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevp_escaped.bem_clear_0();
bevt_1_ta_ph = bevp_mbi.bem_new_1((BEC_2_4_6_TextString) beva_toEscape );
bevt_0_ta_ph = bem_jsonEscape_3(bevt_1_ta_ph, bevp_txtpt, bevp_escaped);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_3(BEC_2_4_17_TextMultiByteIterator beva_mbi, BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_escaped) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
while (true)
/* Line: 416*/ {
bevt_0_ta_ph = beva_mbi.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 416*/ {
beva_mbi.bem_next_1(beva_txtpt);
bem_jsonEscapePoint_2(beva_txtpt, beva_escaped);
} /* Line: 418*/
 else /* Line: 416*/ {
break;
} /* Line: 416*/
} /* Line: 416*/
return beva_escaped;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteString_2(BEC_2_4_6_TextString beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_writer.bemd_1(-1746699146, bevp_q);
bevt_0_ta_ph = bem_jsonEscape_1(beva_inst);
beva_writer.bemd_1(-1746699146, bevt_0_ta_ph);
beva_writer.bemd_1(-1746699146, bevp_q);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteList_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_instin = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_11));
beva_writer.bemd_1(-1746699146, bevt_1_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(656174411);
while (true)
/* Line: 432*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(-639931739);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 432*/ {
bevl_instin = bevt_0_ta_loop.bemd_0(1817051966);
if (bevl_first.bevi_bool)/* Line: 433*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 434*/
 else /* Line: 435*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(-1746699146, bevt_3_ta_ph);
} /* Line: 436*/
bem_marshallWriteInst_2(bevl_instin, beva_writer);
} /* Line: 438*/
 else /* Line: 432*/ {
break;
} /* Line: 432*/
} /* Line: 432*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_13));
beva_writer.bemd_1(-1746699146, bevt_4_ta_ph);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_14));
beva_writer.bemd_1(-1746699146, bevt_1_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(656174411);
while (true)
/* Line: 446*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(-639931739);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 446*/ {
bevl_kv = bevt_0_ta_loop.bemd_0(1817051966);
if (bevl_first.bevi_bool)/* Line: 448*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 449*/
 else /* Line: 450*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(-1746699146, bevt_3_ta_ph);
} /* Line: 451*/
bevt_4_ta_ph = bevl_kv.bemd_0(-1212460461);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_4_ta_ph , beva_writer);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_15));
beva_writer.bemd_1(-1746699146, bevt_5_ta_ph);
bevt_6_ta_ph = bevl_kv.bemd_0(1207517387);
bem_marshallWriteInst_2(bevt_6_ta_ph, beva_writer);
} /* Line: 455*/
 else /* Line: 446*/ {
break;
} /* Line: 446*/
} /* Line: 446*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_16));
beva_writer.bemd_1(-1746699146, bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public final BEC_2_4_6_TextString bem_strGetDirect_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_arrGet_0() throws Throwable {
return bevp_arr;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_arrGetDirect_0() throws Throwable {
return bevp_arr;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_arrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_arrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_mapGetDirect_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_4_3_MathInt bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_booGet_0() throws Throwable {
return bevp_boo;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_booGetDirect_0() throws Throwable {
return bevp_boo;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_booSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_booSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_qGet_0() throws Throwable {
return bevp_q;
} /*method end*/
public final BEC_2_4_6_TextString bem_qGetDirect_0() throws Throwable {
return bevp_q;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_qSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_q = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_qSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_q = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiGet_0() throws Throwable {
return bevp_mbi;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_mbiGetDirect_0() throws Throwable {
return bevp_mbi;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mbiSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_mbiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_txtptGet_0() throws Throwable {
return bevp_txtpt;
} /*method end*/
public final BEC_2_4_6_TextString bem_txtptGetDirect_0() throws Throwable {
return bevp_txtpt;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_txtptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_txtptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_escapedGet_0() throws Throwable {
return bevp_escaped;
} /*method end*/
public final BEC_2_4_6_TextString bem_escapedGetDirect_0() throws Throwable {
return bevp_escaped;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_escapedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_escapedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {291, 293, 293, 295, 297, 299, 301, 301, 303, 304, 305, 310, 310, 311, 313, 314, 315, 315, 319, 319, 320, 322, 326, 326, 327, 327, 328, 329, 330, 331, 332, 333, 334, 335, 335, 336, 337, 337, 339, 339, 344, 345, 347, 350, 350, 350, 351, 351, 351, 353, 353, 353, 355, 355, 355, 357, 357, 357, 359, 359, 359, 361, 361, 361, 363, 363, 363, 364, 364, 364, 366, 368, 368, 368, 368, 368, 368, 364, 371, 371, 371, 372, 373, 373, 373, 374, 376, 376, 376, 376, 377, 379, 383, 383, 383, 383, 384, 384, 387, 387, 387, 389, 390, 390, 391, 391, 392, 395, 397, 397, 397, 398, 398, 398, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 400, 400, 400, 401, 401, 401, 402, 402, 402, 402, 402, 402, 402, 402, 403, 403, 403, 403, 403, 403, 404, 404, 404, 404, 404, 404, 404, 404, 404, 404, 404, 404, 404, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 411, 412, 412, 412, 416, 417, 418, 420, 424, 425, 425, 426, 430, 430, 431, 432, 0, 432, 432, 434, 436, 436, 438, 440, 440, 444, 444, 445, 446, 0, 446, 446, 449, 451, 451, 453, 453, 454, 454, 455, 455, 457, 457, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 79, 84, 85, 87, 88, 89, 90, 94, 99, 100, 102, 116, 121, 122, 123, 126, 128, 131, 133, 136, 138, 141, 143, 144, 147, 149, 150, 153, 154, 267, 268, 269, 270, 271, 272, 273, 274, 279, 280, 281, 282, 285, 286, 291, 292, 293, 294, 297, 298, 303, 304, 305, 306, 310, 311, 316, 317, 320, 325, 326, 327, 328, 329, 330, 331, 332, 333, 340, 341, 346, 347, 350, 351, 356, 357, 360, 361, 362, 367, 368, 371, 375, 376, 377, 382, 383, 384, 386, 387, 392, 393, 394, 395, 396, 401, 402, 405, 409, 410, 415, 416, 417, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 438, 439, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 497, 498, 499, 500, 506, 508, 509, 515, 519, 520, 521, 522, 533, 534, 535, 536, 536, 539, 541, 543, 546, 547, 549, 555, 556, 570, 571, 572, 573, 573, 576, 578, 580, 583, 584, 586, 587, 588, 589, 590, 591, 597, 598, 602, 605, 608, 612, 616, 619, 622, 626, 630, 633, 636, 640, 644, 647, 650, 654, 658, 661, 664, 668, 672, 675, 678, 682, 686, 689, 692, 696, 700, 703, 706, 710, 714, 717, 720, 724};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 291 62
new 0 291 62
assign 1 293 63
new 0 293 63
assign 1 293 64
new 1 293 64
assign 1 295 65
new 0 295 65
assign 1 297 66
new 0 297 66
assign 1 299 67
new 0 299 67
assign 1 301 68
new 0 301 68
assign 1 301 69
quoteGet 0 301 69
assign 1 303 70
new 0 303 70
assign 1 304 71
new 0 304 71
assign 1 305 72
new 0 305 72
assign 1 310 79
undef 1 310 84
new 0 311 85
assign 1 313 87
new 0 313 87
marshallWriteInst 2 314 88
assign 1 315 89
toString 0 315 89
return 1 315 90
assign 1 319 94
undef 1 319 99
new 0 320 100
marshallWriteInst 2 322 102
assign 1 326 116
undef 1 326 121
assign 1 327 122
new 0 327 122
write 1 327 123
assign 1 328 126
sameType 1 328 126
marshallWriteString 2 329 128
assign 1 330 131
sameType 1 330 131
marshallWriteList 2 331 133
assign 1 332 136
sameType 1 332 136
marshallWriteMap 2 333 138
assign 1 334 141
sameType 1 334 141
assign 1 335 143
toString 0 335 143
write 1 335 144
assign 1 336 147
sameType 1 336 147
assign 1 337 149
toString 0 337 149
write 1 337 150
assign 1 339 153
toString 0 339 153
marshallWriteString 2 339 154
assign 1 344 267
new 0 344 267
assign 1 345 268
sizeGet 0 345 268
assign 1 347 269
sizeGet 0 347 269
assign 1 350 270
new 0 350 270
assign 1 350 271
new 0 350 271
assign 1 350 272
getInt 2 350 272
assign 1 351 273
new 0 351 273
assign 1 351 274
equals 1 351 279
assign 1 353 280
new 0 353 280
assign 1 353 281
hexNew 1 353 281
assign 1 353 282
and 1 353 282
assign 1 355 285
new 0 355 285
assign 1 355 286
equals 1 355 291
assign 1 357 292
new 0 357 292
assign 1 357 293
hexNew 1 357 293
assign 1 357 294
and 1 357 294
assign 1 359 297
new 0 359 297
assign 1 359 298
equals 1 359 303
assign 1 361 304
new 0 361 304
assign 1 361 305
hexNew 1 361 305
assign 1 361 306
and 1 361 306
assign 1 363 310
new 0 363 310
assign 1 363 311
greater 1 363 316
assign 1 364 317
new 0 364 317
assign 1 364 320
lesser 1 364 325
getInt 2 366 326
assign 1 368 327
new 0 368 327
assign 1 368 328
shiftLeft 1 368 328
assign 1 368 329
new 0 368 329
assign 1 368 330
hexNew 1 368 330
assign 1 368 331
and 1 368 331
assign 1 368 332
add 1 368 332
incrementValue 0 364 333
assign 1 371 340
new 0 371 340
assign 1 371 341
equals 1 371 346
assign 1 372 347
new 0 372 347
assign 1 373 350
new 0 373 350
assign 1 373 351
equals 1 373 356
assign 1 374 357
new 0 374 357
assign 1 376 360
new 0 376 360
assign 1 376 361
hexNew 1 376 361
assign 1 376 362
lesser 1 376 367
assign 1 377 368
new 0 377 368
assign 1 379 371
new 0 379 371
assign 1 383 375
capacityGet 0 383 375
assign 1 383 376
subtract 1 383 376
assign 1 383 377
lesser 1 383 382
assign 1 384 383
add 1 384 383
capacitySet 1 384 384
assign 1 387 386
new 0 387 386
assign 1 387 387
equals 1 387 392
assign 1 389 393
new 0 389 393
assign 1 390 394
toEscapesGet 0 390 394
assign 1 390 395
get 1 390 395
assign 1 391 396
def 1 391 401
addValue 1 392 402
addValue 1 395 405
assign 1 397 409
new 0 397 409
assign 1 397 410
greater 1 397 415
assign 1 398 416
new 0 398 416
assign 1 398 417
equals 1 398 422
assign 1 399 423
new 0 399 423
assign 1 399 424
addValue 1 399 424
assign 1 399 425
new 0 399 425
assign 1 399 426
once 0 399 426
assign 1 399 427
new 1 399 427
assign 1 399 428
new 0 399 428
assign 1 399 429
once 0 399 429
assign 1 399 430
new 0 399 430
assign 1 399 431
once 0 399 431
assign 1 399 432
new 0 399 432
assign 1 399 433
once 0 399 433
assign 1 399 434
toString 4 399 434
addValue 1 399 435
assign 1 400 438
new 0 400 438
assign 1 400 439
equals 1 400 444
assign 1 401 445
new 0 401 445
assign 1 401 446
hexNew 1 401 446
subtractValue 1 401 447
assign 1 402 448
new 0 402 448
assign 1 402 449
hexNew 1 402 449
assign 1 402 450
new 0 402 450
assign 1 402 451
hexNew 1 402 451
assign 1 402 452
and 1 402 452
assign 1 402 453
new 0 402 453
assign 1 402 454
shiftRight 1 402 454
assign 1 402 455
or 1 402 455
assign 1 403 456
new 0 403 456
assign 1 403 457
hexNew 1 403 457
assign 1 403 458
new 0 403 458
assign 1 403 459
hexNew 1 403 459
assign 1 403 460
and 1 403 460
assign 1 403 461
or 1 403 461
assign 1 404 462
new 0 404 462
assign 1 404 463
addValue 1 404 463
assign 1 404 464
new 0 404 464
assign 1 404 465
once 0 404 465
assign 1 404 466
new 1 404 466
assign 1 404 467
new 0 404 467
assign 1 404 468
once 0 404 468
assign 1 404 469
new 0 404 469
assign 1 404 470
once 0 404 470
assign 1 404 471
new 0 404 471
assign 1 404 472
once 0 404 472
assign 1 404 473
toString 4 404 473
addValue 1 404 474
assign 1 405 475
new 0 405 475
assign 1 405 476
addValue 1 405 476
assign 1 405 477
new 0 405 477
assign 1 405 478
once 0 405 478
assign 1 405 479
new 1 405 479
assign 1 405 480
new 0 405 480
assign 1 405 481
once 0 405 481
assign 1 405 482
new 0 405 482
assign 1 405 483
once 0 405 483
assign 1 405 484
new 0 405 484
assign 1 405 485
once 0 405 485
assign 1 405 486
toString 4 405 486
addValue 1 405 487
clear 0 411 497
assign 1 412 498
new 1 412 498
assign 1 412 499
jsonEscape 3 412 499
return 1 412 500
assign 1 416 506
hasNextGet 0 416 506
next 1 417 508
jsonEscapePoint 2 418 509
return 1 420 515
write 1 424 519
assign 1 425 520
jsonEscape 1 425 520
write 1 425 521
write 1 426 522
assign 1 430 533
new 0 430 533
write 1 430 534
assign 1 431 535
new 0 431 535
assign 1 432 536
iteratorGet 0 0 536
assign 1 432 539
hasNextGet 0 432 539
assign 1 432 541
nextGet 0 432 541
assign 1 434 543
new 0 434 543
assign 1 436 546
new 0 436 546
write 1 436 547
marshallWriteInst 2 438 549
assign 1 440 555
new 0 440 555
write 1 440 556
assign 1 444 570
new 0 444 570
write 1 444 571
assign 1 445 572
new 0 445 572
assign 1 446 573
iteratorGet 0 0 573
assign 1 446 576
hasNextGet 0 446 576
assign 1 446 578
nextGet 0 446 578
assign 1 449 580
new 0 449 580
assign 1 451 583
new 0 451 583
write 1 451 584
assign 1 453 586
keyGet 0 453 586
marshallWriteString 2 453 587
assign 1 454 588
new 0 454 588
write 1 454 589
assign 1 455 590
valueGet 0 455 590
marshallWriteInst 2 455 591
assign 1 457 597
new 0 457 597
write 1 457 598
return 1 0 602
return 1 0 605
assign 1 0 608
assign 1 0 612
return 1 0 616
return 1 0 619
assign 1 0 622
assign 1 0 626
return 1 0 630
return 1 0 633
assign 1 0 636
assign 1 0 640
return 1 0 644
return 1 0 647
assign 1 0 650
assign 1 0 654
return 1 0 658
return 1 0 661
assign 1 0 664
assign 1 0 668
return 1 0 672
return 1 0 675
assign 1 0 678
assign 1 0 682
return 1 0 686
return 1 0 689
assign 1 0 692
assign 1 0 696
return 1 0 700
return 1 0 703
assign 1 0 706
assign 1 0 710
return 1 0 714
return 1 0 717
assign 1 0 720
assign 1 0 724
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 470335985: return bem_fieldNamesGet_0();
case -434766936: return bem_many_0();
case 32986096: return bem_tagGet_0();
case 1655904311: return bem_arrGetDirect_0();
case -755526441: return bem_qGetDirect_0();
case -1193538733: return bem_echo_0();
case -1095891676: return bem_txtptGetDirect_0();
case -205860110: return bem_mapGet_0();
case -405716861: return bem_mbiGet_0();
case 656174411: return bem_iteratorGet_0();
case -2068645774: return bem_toString_0();
case 1410183204: return bem_booGet_0();
case -1302536571: return bem_arrGet_0();
case 1104438617: return bem_serializationIteratorGet_0();
case -1831488804: return bem_qGet_0();
case 487968426: return bem_txtptGet_0();
case 285825492: return bem_escapedGetDirect_0();
case 254283761: return bem_classNameGet_0();
case 1337499076: return bem_fieldIteratorGet_0();
case 238716313: return bem_once_0();
case 1022480841: return bem_strGetDirect_0();
case 1887791078: return bem_toAny_0();
case -810892117: return bem_sourceFileNameGet_0();
case -1667230363: return bem_new_0();
case -1134589630: return bem_serializeToString_0();
case 571608114: return bem_booGetDirect_0();
case 748376257: return bem_strGet_0();
case 181316061: return bem_serializeContents_0();
case 1258540231: return bem_print_0();
case 454788333: return bem_escapedGet_0();
case 1433312714: return bem_deserializeClassNameGet_0();
case -1916545082: return bem_hashGet_0();
case 1333189262: return bem_copy_0();
case -1971716232: return bem_intGetDirect_0();
case 2101072104: return bem_mapGetDirect_0();
case 1422294520: return bem_create_0();
case -1905426197: return bem_mbiGetDirect_0();
case -1236615504: return bem_intGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1833619020: return bem_booSetDirect_1(bevd_0);
case 1080562134: return bem_intSet_1(bevd_0);
case -1047275995: return bem_escapedSet_1(bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case -1976365461: return bem_strSetDirect_1(bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case -1068839703: return bem_marshall_1(bevd_0);
case 2134518081: return bem_mbiSet_1(bevd_0);
case 1183779180: return bem_jsonEscape_1(bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case 1165354248: return bem_mapSet_1(bevd_0);
case 1290216463: return bem_def_1(bevd_0);
case -249998429: return bem_intSetDirect_1(bevd_0);
case -1656060385: return bem_txtptSet_1(bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case 2105381453: return bem_booSet_1(bevd_0);
case 863204836: return bem_mapSetDirect_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case 2138548167: return bem_txtptSetDirect_1(bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case 1222334048: return bem_qSetDirect_1(bevd_0);
case -808565744: return bem_escapedSetDirect_1(bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case -1646460992: return bem_qSet_1(bevd_0);
case -894692129: return bem_mbiSetDirect_1(bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case -1391764897: return bem_arrSetDirect_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case 2130186236: return bem_arrSet_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
case 1550487021: return bem_strSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1615568668: return bem_marshallWriteInst_2(bevd_0, bevd_1);
case 1093178407: return bem_marshallWriteMap_2(bevd_0, bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -249674968: return bem_marshallWriteList_2(bevd_0, bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1454862711: return bem_jsonEscapePoint_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1880831134: return bem_marshallWrite_2(bevd_0, bevd_1);
case -1253079154: return bem_marshallWriteString_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1728829998: return bem_jsonEscape_3((BEC_2_4_17_TextMultiByteIterator) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_JsonMarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_10_JsonMarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_JsonMarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst = (BEC_2_4_10_JsonMarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_type;
}
}
