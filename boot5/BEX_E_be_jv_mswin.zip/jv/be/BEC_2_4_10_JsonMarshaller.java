package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_10_JsonMarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_JsonMarshaller() { }
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x4D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_1 = {0x31,0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_2 = {0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_3 = {0x37};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_4 = {0x33,0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_5 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_6 = {0x5C,0x75};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_8 = {0x66,0x66,0x63,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_9 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_10 = {0x30,0x30,0x33,0x66,0x66};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_11 = {0x5B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_12 = {0x2C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_13 = {0x5D};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_14 = {0x7B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_15 = {0x3A};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_16 = {0x7D};
public static BEC_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_inst;

public static BET_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_9_4_ContainerList bevp_arr;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_boo;
public BEC_2_4_6_TextString bevp_q;
public BEC_2_4_17_TextMultiByteIterator bevp_mbi;
public BEC_2_4_6_TextString bevp_txtpt;
public BEC_2_4_6_TextString bevp_escaped;
public BEC_2_4_10_JsonMarshaller bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevp_str = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_arr = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
bevp_boo = (new BEC_2_5_4_LogicBool()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_q = bevt_1_ta_ph.bem_quoteGet_0();
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_0();
bevp_txtpt = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_escaped = (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_marshall_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_4_6_TextString bevl_bb = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 310*/ {
bem_new_0();
} /* Line: 311*/
bevl_bb = (new BEC_2_4_6_TextString()).bem_new_0();
bem_marshallWriteInst_2(beva_inst, bevl_bb);
bevt_1_ta_ph = bevl_bb.bem_toString_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWrite_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 319*/ {
bem_new_0();
} /* Line: 320*/
bem_marshallWriteInst_2(beva_inst, beva_writer);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteInst_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (beva_inst == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_0));
beva_writer.bemd_1(135517263, bevt_1_ta_ph);
} /* Line: 327*/
 else /* Line: 326*/ {
bevt_2_ta_ph = beva_inst.bemd_1(-580813096, bevp_str);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 328*/ {
bem_marshallWriteString_2((BEC_2_4_6_TextString) beva_inst , beva_writer);
} /* Line: 329*/
 else /* Line: 326*/ {
bevt_3_ta_ph = beva_inst.bemd_1(-580813096, bevp_arr);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 330*/ {
bem_marshallWriteList_2(beva_inst, beva_writer);
} /* Line: 331*/
 else /* Line: 326*/ {
bevt_4_ta_ph = beva_inst.bemd_1(-580813096, bevp_map);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 332*/ {
bem_marshallWriteMap_2(beva_inst, beva_writer);
} /* Line: 333*/
 else /* Line: 326*/ {
bevt_5_ta_ph = beva_inst.bemd_1(-580813096, bevp_int);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 334*/ {
bevt_6_ta_ph = beva_inst.bemd_0(-1248679117);
beva_writer.bemd_1(135517263, bevt_6_ta_ph);
} /* Line: 335*/
 else /* Line: 326*/ {
bevt_7_ta_ph = beva_inst.bemd_1(-580813096, bevp_boo);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 336*/ {
bevt_8_ta_ph = beva_inst.bemd_0(-1248679117);
beva_writer.bemd_1(135517263, bevt_8_ta_ph);
} /* Line: 337*/
 else /* Line: 338*/ {
bevt_9_ta_ph = beva_inst.bemd_0(-1248679117);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_9_ta_ph , beva_writer);
} /* Line: 339*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_jsonEscapePoint_2(BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_txt) throws Throwable {
BEC_2_4_3_MathInt bevl_rcap = null;
BEC_2_4_3_MathInt bevl_txtsznow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_u = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_7_JsonEscapes bevl_esc = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_first = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_4_3_MathInt bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
bevl_rcap = (new BEC_2_4_3_MathInt());
bevl_txtsznow = beva_txt.bem_sizeGet_0();
bevl_size = beva_txtpt.bem_sizeGet_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevl_u = beva_txtpt.bem_getInt_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_size.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 352*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_1));
bevt_4_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_5_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_4_ta_ph);
} /* Line: 353*/
 else /* Line: 351*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(3));
if (bevl_size.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_2));
bevt_8_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_9_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_8_ta_ph);
} /* Line: 357*/
 else /* Line: 351*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(4));
if (bevl_size.bevi_int == bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 360*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_3));
bevt_12_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_13_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_12_ta_ph);
} /* Line: 361*/
} /* Line: 351*/
} /* Line: 351*/
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_size.bevi_int > bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 363*/ {
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 364*/ {
if (bevl_i.bevi_int < bevl_size.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 365*/ {
beva_txtpt.bem_getInt_2(bevl_i, bevl_u);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_17_ta_ph = bevl_value.bem_shiftLeft_1(bevt_18_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_4));
bevt_20_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_21_ta_ph);
bevt_19_ta_ph = bevl_u.bem_and_1(bevt_20_ta_ph);
bevl_value = bevt_17_ta_ph.bem_add_1(bevt_19_ta_ph);
bevl_i.bevi_int++;
} /* Line: 364*/
 else /* Line: 364*/ {
break;
} /* Line: 364*/
} /* Line: 364*/
} /* Line: 364*/
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_size.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 371*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(0));
} /* Line: 372*/
 else /* Line: 371*/ {
bevt_25_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_size.bevi_int == bevt_25_ta_ph.bevi_int) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 373*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(2));
} /* Line: 374*/
 else /* Line: 375*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_27_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_28_ta_ph);
if (bevl_value.bevi_int < bevt_27_ta_ph.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 376*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(7));
} /* Line: 377*/
 else /* Line: 378*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(13));
} /* Line: 379*/
} /* Line: 376*/
} /* Line: 371*/
bevt_31_ta_ph = beva_txt.bem_capacityGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_subtract_1(bevl_txtsznow);
if (bevt_30_ta_ph.bevi_int < bevl_rcap.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_32_ta_ph = bevl_txtsznow.bem_add_1(bevl_rcap);
beva_txt.bem_capacitySet_1(bevt_32_ta_ph);
} /* Line: 384*/
bevt_34_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_rcap.bevi_int == bevt_34_ta_ph.bevi_int) {
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 387*/ {
bevl_esc = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevt_35_ta_ph = bevl_esc.bem_toEscapesGet_0();
bevl_escval = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_get_1(beva_txtpt);
if (bevl_escval == null) {
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 391*/ {
beva_txt.bem_addValue_1(bevl_escval);
} /* Line: 392*/
 else /* Line: 393*/ {
beva_txt.bem_addValue_1(beva_txtpt);
} /* Line: 395*/
} /* Line: 391*/
 else /* Line: 387*/ {
bevt_38_ta_ph = (new BEC_2_4_3_MathInt(3));
if (bevl_rcap.bevi_int > bevt_38_ta_ph.bevi_int) {
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 397*/ {
bevt_40_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_rcap.bevi_int == bevt_40_ta_ph.bevi_int) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 398*/ {
bevt_42_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_41_ta_ph = beva_txt.bem_addValue_1(bevt_42_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_44_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_47_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_48_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_43_ta_ph = bevl_value.bem_toString_4(bevt_44_ta_ph, bevt_46_ta_ph, bevt_47_ta_ph, bevt_48_ta_ph);
bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
} /* Line: 399*/
 else /* Line: 398*/ {
bevt_50_ta_ph = (new BEC_2_4_3_MathInt(13));
if (bevl_rcap.bevi_int == bevt_50_ta_ph.bevi_int) {
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_51_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_52_ta_ph);
bevl_value.bem_subtractValue_1(bevt_51_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_7));
bevt_53_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_54_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_8));
bevt_57_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_58_ta_ph);
bevt_56_ta_ph = bevl_value.bem_and_1(bevt_57_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_55_ta_ph = bevt_56_ta_ph.bem_shiftRight_1(bevt_59_ta_ph);
bevl_first = bevt_53_ta_ph.bem_or_1(bevt_55_ta_ph);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_9));
bevt_60_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_61_ta_ph);
bevt_64_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_10));
bevt_63_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_64_ta_ph);
bevt_62_ta_ph = bevl_value.bem_and_1(bevt_63_ta_ph);
bevl_last = bevt_60_ta_ph.bem_or_1(bevt_62_ta_ph);
bevt_66_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_65_ta_ph = beva_txt.bem_addValue_1(bevt_66_ta_ph);
bevt_69_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_68_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_69_ta_ph);
bevt_70_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_71_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_72_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_67_ta_ph = bevl_first.bem_toString_4(bevt_68_ta_ph, bevt_70_ta_ph, bevt_71_ta_ph, bevt_72_ta_ph);
bevt_65_ta_ph.bem_addValue_1(bevt_67_ta_ph);
bevt_74_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_73_ta_ph = beva_txt.bem_addValue_1(bevt_74_ta_ph);
bevt_77_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_76_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_79_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_80_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_75_ta_ph = bevl_last.bem_toString_4(bevt_76_ta_ph, bevt_78_ta_ph, bevt_79_ta_ph, bevt_80_ta_ph);
bevt_73_ta_ph.bem_addValue_1(bevt_75_ta_ph);
} /* Line: 405*/
} /* Line: 398*/
} /* Line: 398*/
} /* Line: 387*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_1(BEC_2_6_6_SystemObject beva_toEscape) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevp_escaped.bem_clear_0();
bevt_1_ta_ph = bevp_mbi.bem_new_1((BEC_2_4_6_TextString) beva_toEscape );
bevt_0_ta_ph = bem_jsonEscape_3(bevt_1_ta_ph, bevp_txtpt, bevp_escaped);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_3(BEC_2_4_17_TextMultiByteIterator beva_mbi, BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_escaped) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
while (true)
/* Line: 416*/ {
bevt_0_ta_ph = beva_mbi.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 416*/ {
beva_mbi.bem_next_1(beva_txtpt);
bem_jsonEscapePoint_2(beva_txtpt, beva_escaped);
} /* Line: 418*/
 else /* Line: 416*/ {
break;
} /* Line: 416*/
} /* Line: 416*/
return beva_escaped;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteString_2(BEC_2_4_6_TextString beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_writer.bemd_1(135517263, bevp_q);
bevt_0_ta_ph = bem_jsonEscape_1(beva_inst);
beva_writer.bemd_1(135517263, bevt_0_ta_ph);
beva_writer.bemd_1(135517263, bevp_q);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteList_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_instin = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_11));
beva_writer.bemd_1(135517263, bevt_1_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(1965801140);
while (true)
/* Line: 432*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(-796347509);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 432*/ {
bevl_instin = bevt_0_ta_loop.bemd_0(-275494575);
if (bevl_first.bevi_bool)/* Line: 433*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 434*/
 else /* Line: 435*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(135517263, bevt_3_ta_ph);
} /* Line: 436*/
bem_marshallWriteInst_2(bevl_instin, beva_writer);
} /* Line: 438*/
 else /* Line: 432*/ {
break;
} /* Line: 432*/
} /* Line: 432*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_13));
beva_writer.bemd_1(135517263, bevt_4_ta_ph);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_14));
beva_writer.bemd_1(135517263, bevt_1_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(1965801140);
while (true)
/* Line: 446*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(-796347509);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 446*/ {
bevl_kv = bevt_0_ta_loop.bemd_0(-275494575);
if (bevl_first.bevi_bool)/* Line: 448*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 449*/
 else /* Line: 450*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(135517263, bevt_3_ta_ph);
} /* Line: 451*/
bevt_4_ta_ph = bevl_kv.bemd_0(-927680367);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_4_ta_ph , beva_writer);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_15));
beva_writer.bemd_1(135517263, bevt_5_ta_ph);
bevt_6_ta_ph = bevl_kv.bemd_0(-2039431595);
bem_marshallWriteInst_2(bevt_6_ta_ph, beva_writer);
} /* Line: 455*/
 else /* Line: 446*/ {
break;
} /* Line: 446*/
} /* Line: 446*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_16));
beva_writer.bemd_1(135517263, bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public final BEC_2_4_6_TextString bem_strGetDirect_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_arrGet_0() throws Throwable {
return bevp_arr;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_arrGetDirect_0() throws Throwable {
return bevp_arr;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_arrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_arrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_mapGetDirect_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_4_3_MathInt bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_booGet_0() throws Throwable {
return bevp_boo;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_booGetDirect_0() throws Throwable {
return bevp_boo;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_booSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_booSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_qGet_0() throws Throwable {
return bevp_q;
} /*method end*/
public final BEC_2_4_6_TextString bem_qGetDirect_0() throws Throwable {
return bevp_q;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_qSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_q = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_qSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_q = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiGet_0() throws Throwable {
return bevp_mbi;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_mbiGetDirect_0() throws Throwable {
return bevp_mbi;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mbiSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_mbiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_txtptGet_0() throws Throwable {
return bevp_txtpt;
} /*method end*/
public final BEC_2_4_6_TextString bem_txtptGetDirect_0() throws Throwable {
return bevp_txtpt;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_txtptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_txtptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_escapedGet_0() throws Throwable {
return bevp_escaped;
} /*method end*/
public final BEC_2_4_6_TextString bem_escapedGetDirect_0() throws Throwable {
return bevp_escaped;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_escapedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_10_JsonMarshaller bem_escapedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {291, 293, 293, 295, 297, 299, 301, 301, 303, 304, 305, 310, 310, 311, 313, 314, 315, 315, 319, 319, 320, 322, 326, 326, 327, 327, 328, 329, 330, 331, 332, 333, 334, 335, 335, 336, 337, 337, 339, 339, 344, 345, 347, 350, 350, 350, 351, 351, 351, 353, 353, 353, 355, 355, 355, 357, 357, 357, 359, 359, 359, 361, 361, 361, 363, 363, 363, 364, 364, 364, 366, 368, 368, 368, 368, 368, 368, 364, 371, 371, 371, 372, 373, 373, 373, 374, 376, 376, 376, 376, 377, 379, 383, 383, 383, 383, 384, 384, 387, 387, 387, 389, 390, 390, 391, 391, 392, 395, 397, 397, 397, 398, 398, 398, 399, 399, 399, 399, 399, 399, 399, 399, 399, 400, 400, 400, 401, 401, 401, 402, 402, 402, 402, 402, 402, 402, 402, 403, 403, 403, 403, 403, 403, 404, 404, 404, 404, 404, 404, 404, 404, 404, 405, 405, 405, 405, 405, 405, 405, 405, 405, 411, 412, 412, 412, 416, 417, 418, 420, 424, 425, 425, 426, 430, 430, 431, 432, 0, 432, 432, 434, 436, 436, 438, 440, 440, 444, 444, 445, 446, 0, 446, 446, 449, 451, 451, 453, 453, 454, 454, 455, 455, 457, 457, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 57, 62, 63, 65, 66, 67, 68, 72, 77, 78, 80, 94, 99, 100, 101, 104, 106, 109, 111, 114, 116, 119, 121, 122, 125, 127, 128, 131, 132, 233, 234, 235, 236, 237, 238, 239, 240, 245, 246, 247, 248, 251, 252, 257, 258, 259, 260, 263, 264, 269, 270, 271, 272, 276, 277, 282, 283, 286, 291, 292, 293, 294, 295, 296, 297, 298, 299, 306, 307, 312, 313, 316, 317, 322, 323, 326, 327, 328, 333, 334, 337, 341, 342, 343, 348, 349, 350, 352, 353, 358, 359, 360, 361, 362, 367, 368, 371, 375, 376, 381, 382, 383, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 400, 401, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 451, 452, 453, 454, 460, 462, 463, 469, 473, 474, 475, 476, 487, 488, 489, 490, 490, 493, 495, 497, 500, 501, 503, 509, 510, 524, 525, 526, 527, 527, 530, 532, 534, 537, 538, 540, 541, 542, 543, 544, 545, 551, 552, 556, 559, 562, 566, 570, 573, 576, 580, 584, 587, 590, 594, 598, 601, 604, 608, 612, 615, 618, 622, 626, 629, 632, 636, 640, 643, 646, 650, 654, 657, 660, 664, 668, 671, 674, 678};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 291 40
new 0 291 40
assign 1 293 41
new 0 293 41
assign 1 293 42
new 1 293 42
assign 1 295 43
new 0 295 43
assign 1 297 44
new 0 297 44
assign 1 299 45
new 0 299 45
assign 1 301 46
new 0 301 46
assign 1 301 47
quoteGet 0 301 47
assign 1 303 48
new 0 303 48
assign 1 304 49
new 0 304 49
assign 1 305 50
new 0 305 50
assign 1 310 57
undef 1 310 62
new 0 311 63
assign 1 313 65
new 0 313 65
marshallWriteInst 2 314 66
assign 1 315 67
toString 0 315 67
return 1 315 68
assign 1 319 72
undef 1 319 77
new 0 320 78
marshallWriteInst 2 322 80
assign 1 326 94
undef 1 326 99
assign 1 327 100
new 0 327 100
write 1 327 101
assign 1 328 104
sameType 1 328 104
marshallWriteString 2 329 106
assign 1 330 109
sameType 1 330 109
marshallWriteList 2 331 111
assign 1 332 114
sameType 1 332 114
marshallWriteMap 2 333 116
assign 1 334 119
sameType 1 334 119
assign 1 335 121
toString 0 335 121
write 1 335 122
assign 1 336 125
sameType 1 336 125
assign 1 337 127
toString 0 337 127
write 1 337 128
assign 1 339 131
toString 0 339 131
marshallWriteString 2 339 132
assign 1 344 233
new 0 344 233
assign 1 345 234
sizeGet 0 345 234
assign 1 347 235
sizeGet 0 347 235
assign 1 350 236
new 0 350 236
assign 1 350 237
new 0 350 237
assign 1 350 238
getInt 2 350 238
assign 1 351 239
new 0 351 239
assign 1 351 240
equals 1 351 245
assign 1 353 246
new 0 353 246
assign 1 353 247
hexNew 1 353 247
assign 1 353 248
and 1 353 248
assign 1 355 251
new 0 355 251
assign 1 355 252
equals 1 355 257
assign 1 357 258
new 0 357 258
assign 1 357 259
hexNew 1 357 259
assign 1 357 260
and 1 357 260
assign 1 359 263
new 0 359 263
assign 1 359 264
equals 1 359 269
assign 1 361 270
new 0 361 270
assign 1 361 271
hexNew 1 361 271
assign 1 361 272
and 1 361 272
assign 1 363 276
new 0 363 276
assign 1 363 277
greater 1 363 282
assign 1 364 283
new 0 364 283
assign 1 364 286
lesser 1 364 291
getInt 2 366 292
assign 1 368 293
new 0 368 293
assign 1 368 294
shiftLeft 1 368 294
assign 1 368 295
new 0 368 295
assign 1 368 296
hexNew 1 368 296
assign 1 368 297
and 1 368 297
assign 1 368 298
add 1 368 298
incrementValue 0 364 299
assign 1 371 306
new 0 371 306
assign 1 371 307
equals 1 371 312
assign 1 372 313
new 0 372 313
assign 1 373 316
new 0 373 316
assign 1 373 317
equals 1 373 322
assign 1 374 323
new 0 374 323
assign 1 376 326
new 0 376 326
assign 1 376 327
hexNew 1 376 327
assign 1 376 328
lesser 1 376 333
assign 1 377 334
new 0 377 334
assign 1 379 337
new 0 379 337
assign 1 383 341
capacityGet 0 383 341
assign 1 383 342
subtract 1 383 342
assign 1 383 343
lesser 1 383 348
assign 1 384 349
add 1 384 349
capacitySet 1 384 350
assign 1 387 352
new 0 387 352
assign 1 387 353
equals 1 387 358
assign 1 389 359
new 0 389 359
assign 1 390 360
toEscapesGet 0 390 360
assign 1 390 361
get 1 390 361
assign 1 391 362
def 1 391 367
addValue 1 392 368
addValue 1 395 371
assign 1 397 375
new 0 397 375
assign 1 397 376
greater 1 397 381
assign 1 398 382
new 0 398 382
assign 1 398 383
equals 1 398 388
assign 1 399 389
new 0 399 389
assign 1 399 390
addValue 1 399 390
assign 1 399 391
new 0 399 391
assign 1 399 392
new 1 399 392
assign 1 399 393
new 0 399 393
assign 1 399 394
new 0 399 394
assign 1 399 395
new 0 399 395
assign 1 399 396
toString 4 399 396
addValue 1 399 397
assign 1 400 400
new 0 400 400
assign 1 400 401
equals 1 400 406
assign 1 401 407
new 0 401 407
assign 1 401 408
hexNew 1 401 408
subtractValue 1 401 409
assign 1 402 410
new 0 402 410
assign 1 402 411
hexNew 1 402 411
assign 1 402 412
new 0 402 412
assign 1 402 413
hexNew 1 402 413
assign 1 402 414
and 1 402 414
assign 1 402 415
new 0 402 415
assign 1 402 416
shiftRight 1 402 416
assign 1 402 417
or 1 402 417
assign 1 403 418
new 0 403 418
assign 1 403 419
hexNew 1 403 419
assign 1 403 420
new 0 403 420
assign 1 403 421
hexNew 1 403 421
assign 1 403 422
and 1 403 422
assign 1 403 423
or 1 403 423
assign 1 404 424
new 0 404 424
assign 1 404 425
addValue 1 404 425
assign 1 404 426
new 0 404 426
assign 1 404 427
new 1 404 427
assign 1 404 428
new 0 404 428
assign 1 404 429
new 0 404 429
assign 1 404 430
new 0 404 430
assign 1 404 431
toString 4 404 431
addValue 1 404 432
assign 1 405 433
new 0 405 433
assign 1 405 434
addValue 1 405 434
assign 1 405 435
new 0 405 435
assign 1 405 436
new 1 405 436
assign 1 405 437
new 0 405 437
assign 1 405 438
new 0 405 438
assign 1 405 439
new 0 405 439
assign 1 405 440
toString 4 405 440
addValue 1 405 441
clear 0 411 451
assign 1 412 452
new 1 412 452
assign 1 412 453
jsonEscape 3 412 453
return 1 412 454
assign 1 416 460
hasNextGet 0 416 460
next 1 417 462
jsonEscapePoint 2 418 463
return 1 420 469
write 1 424 473
assign 1 425 474
jsonEscape 1 425 474
write 1 425 475
write 1 426 476
assign 1 430 487
new 0 430 487
write 1 430 488
assign 1 431 489
new 0 431 489
assign 1 432 490
iteratorGet 0 0 490
assign 1 432 493
hasNextGet 0 432 493
assign 1 432 495
nextGet 0 432 495
assign 1 434 497
new 0 434 497
assign 1 436 500
new 0 436 500
write 1 436 501
marshallWriteInst 2 438 503
assign 1 440 509
new 0 440 509
write 1 440 510
assign 1 444 524
new 0 444 524
write 1 444 525
assign 1 445 526
new 0 445 526
assign 1 446 527
iteratorGet 0 0 527
assign 1 446 530
hasNextGet 0 446 530
assign 1 446 532
nextGet 0 446 532
assign 1 449 534
new 0 449 534
assign 1 451 537
new 0 451 537
write 1 451 538
assign 1 453 540
keyGet 0 453 540
marshallWriteString 2 453 541
assign 1 454 542
new 0 454 542
write 1 454 543
assign 1 455 544
valueGet 0 455 544
marshallWriteInst 2 455 545
assign 1 457 551
new 0 457 551
write 1 457 552
return 1 0 556
return 1 0 559
assign 1 0 562
assign 1 0 566
return 1 0 570
return 1 0 573
assign 1 0 576
assign 1 0 580
return 1 0 584
return 1 0 587
assign 1 0 590
assign 1 0 594
return 1 0 598
return 1 0 601
assign 1 0 604
assign 1 0 608
return 1 0 612
return 1 0 615
assign 1 0 618
assign 1 0 622
return 1 0 626
return 1 0 629
assign 1 0 632
assign 1 0 636
return 1 0 640
return 1 0 643
assign 1 0 646
assign 1 0 650
return 1 0 654
return 1 0 657
assign 1 0 660
assign 1 0 664
return 1 0 668
return 1 0 671
assign 1 0 674
assign 1 0 678
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1131808500: return bem_mapGetDirect_0();
case -1648057302: return bem_echo_0();
case -1456422317: return bem_toAny_0();
case -315448632: return bem_create_0();
case 1533301608: return bem_once_0();
case -1485421802: return bem_serializeContents_0();
case -384334967: return bem_escapedGet_0();
case 1350181777: return bem_deserializeClassNameGet_0();
case -1070994386: return bem_serializeToString_0();
case -1988766442: return bem_booGetDirect_0();
case 1918015251: return bem_escapedGetDirect_0();
case 2062467928: return bem_txtptGetDirect_0();
case 2136450404: return bem_mbiGet_0();
case 1832905438: return bem_mapGet_0();
case 1085612775: return bem_tagGet_0();
case -1745697587: return bem_classNameGet_0();
case 983251128: return bem_new_0();
case 1579512018: return bem_print_0();
case 179059810: return bem_intGet_0();
case 1933145029: return bem_mbiGetDirect_0();
case -1062387307: return bem_strGetDirect_0();
case -1742282286: return bem_strGet_0();
case 1965801140: return bem_iteratorGet_0();
case -1322635312: return bem_qGet_0();
case 2090308182: return bem_serializationIteratorGet_0();
case 887875557: return bem_copy_0();
case -1398003509: return bem_qGetDirect_0();
case 677156823: return bem_hashGet_0();
case 469657691: return bem_fieldNamesGet_0();
case 84183111: return bem_arrGet_0();
case -2116850715: return bem_txtptGet_0();
case 1579512226: return bem_booGet_0();
case 385378060: return bem_intGetDirect_0();
case 1474843090: return bem_arrGetDirect_0();
case 1446040207: return bem_many_0();
case -1248679117: return bem_toString_0();
case 238971711: return bem_sourceFileNameGet_0();
case -369356392: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2023300100: return bem_sameObject_1(bevd_0);
case 130714078: return bem_equals_1(bevd_0);
case -516066761: return bem_defined_1(bevd_0);
case 1072056405: return bem_mapSetDirect_1(bevd_0);
case 1788882700: return bem_undef_1(bevd_0);
case -1706130399: return bem_intSetDirect_1(bevd_0);
case -1061002966: return bem_booSetDirect_1(bevd_0);
case -513408185: return bem_otherClass_1(bevd_0);
case 603494847: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2007747535: return bem_strSet_1(bevd_0);
case 38730350: return bem_jsonEscape_1(bevd_0);
case -1630597488: return bem_notEquals_1(bevd_0);
case 38767287: return bem_copyTo_1(bevd_0);
case -1732592591: return bem_txtptSet_1(bevd_0);
case 1189552868: return bem_escapedSetDirect_1(bevd_0);
case 1538571134: return bem_qSet_1(bevd_0);
case 203482140: return bem_undefined_1(bevd_0);
case 702187605: return bem_arrSetDirect_1(bevd_0);
case -1693745602: return bem_otherType_1(bevd_0);
case 543435641: return bem_arrSet_1(bevd_0);
case 2037863397: return bem_intSet_1(bevd_0);
case -1140877930: return bem_mapSet_1(bevd_0);
case 489212029: return bem_mbiSetDirect_1(bevd_0);
case 1039262659: return bem_qSetDirect_1(bevd_0);
case 607456901: return bem_booSet_1(bevd_0);
case -580813096: return bem_sameType_1(bevd_0);
case -1765818215: return bem_strSetDirect_1(bevd_0);
case -686701559: return bem_marshall_1(bevd_0);
case 203093992: return bem_escapedSet_1(bevd_0);
case 851006420: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 807537262: return bem_mbiSet_1(bevd_0);
case 1812369063: return bem_sameClass_1(bevd_0);
case 1474459106: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -123747253: return bem_txtptSetDirect_1(bevd_0);
case 565121501: return bem_def_1(bevd_0);
case 1894822196: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 619523077: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1932725737: return bem_marshallWriteList_2(bevd_0, bevd_1);
case -432356215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1753294364: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1623511580: return bem_marshallWrite_2(bevd_0, bevd_1);
case -1095283280: return bem_marshallWriteInst_2(bevd_0, bevd_1);
case -693517224: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 203612774: return bem_marshallWriteString_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1586705324: return bem_marshallWriteMap_2(bevd_0, bevd_1);
case 391432487: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 828688575: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -973565516: return bem_jsonEscapePoint_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1676574552: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 337125777: return bem_jsonEscape_3((BEC_2_4_17_TextMultiByteIterator) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_JsonMarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_10_JsonMarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_JsonMarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst = (BEC_2_4_10_JsonMarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_type;
}
}
