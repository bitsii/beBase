package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue extends BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_9_12_ContainerBoundedQueue bem_new_0() throws Throwable {
super.bem_new_0();
bevp_max = (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
super.bem_enqueue_1(beva_item);
if (bevp_size.bevi_int > bevp_max.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 190*/ {
bem_dequeue_0();
} /* Line: 191*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() throws Throwable {
return bevp_max;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {183, 185, 189, 190, 190, 191, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 19, 20, 25, 26, 31, 34};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 183 13
assign 1 185 14
new 0 185 14
enqueue 1 189 19
assign 1 190 20
greater 1 190 25
dequeue 0 191 26
return 1 0 31
assign 1 0 34
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1012381645: return bem_create_0();
case 454522998: return bem_print_0();
case -1531351375: return bem_get_0();
case -1965055770: return bem_sizeGet_0();
case 2080484347: return bem_bottomGet_0();
case 1478255442: return bem_copy_0();
case -467961868: return bem_isEmptyGet_0();
case -1423130981: return bem_hashGet_0();
case -1445069220: return bem_topGet_0();
case 455087168: return bem_iteratorGet_0();
case 1046646512: return bem_endGet_0();
case 252665408: return bem_dequeue_0();
case -1756046326: return bem_toString_0();
case 530227489: return bem_new_0();
case 1260826981: return bem_maxGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -215125627: return bem_topSet_1(bevd_0);
case -215143754: return bem_maxSet_1(bevd_0);
case 749348357: return bem_addValue_1(bevd_0);
case 1426843373: return bem_endSet_1(bevd_0);
case 96657329: return bem_notEquals_1(bevd_0);
case 576934107: return bem_copyTo_1(bevd_0);
case 889955668: return bem_undef_1(bevd_0);
case -915562673: return bem_put_1(bevd_0);
case 1276638363: return bem_equals_1(bevd_0);
case 121844428: return bem_bottomSet_1(bevd_0);
case 546919826: return bem_sizeSet_1(bevd_0);
case 1342373171: return bem_def_1(bevd_0);
case -1844563957: return bem_enqueue_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1465920918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1131482033: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 558464110: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 180847688: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
