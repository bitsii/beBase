package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue extends BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_9_12_ContainerBoundedQueue bem_new_0() throws Throwable {
super.bem_new_0();
bevp_max = (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
super.bem_enqueue_1(beva_item);
if (bevp_length.bevi_int > bevp_max.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 196*/ {
bem_dequeue_0();
} /* Line: 197*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() throws Throwable {
return bevp_max;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {189, 191, 195, 196, 196, 197, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 19, 20, 25, 26, 31, 34};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 189 13
assign 1 191 14
new 0 191 14
enqueue 1 195 19
assign 1 196 20
greater 1 196 25
dequeue 0 197 26
return 1 0 31
assign 1 0 34
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1531310319: return bem_endGet_0();
case -1469940816: return bem_hashGet_0();
case -2119149182: return bem_dequeue_0();
case -241347086: return bem_create_0();
case 1128037130: return bem_isEmptyGet_0();
case -643672405: return bem_bottomGet_0();
case 62063643: return bem_iteratorGet_0();
case -1528559952: return bem_new_0();
case 1797379901: return bem_toString_0();
case -817805991: return bem_copy_0();
case -660484209: return bem_topGet_0();
case 1854572431: return bem_lengthGet_0();
case -1017420513: return bem_get_0();
case 310032749: return bem_maxGet_0();
case -1764331563: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1051624436: return bem_notEquals_1(bevd_0);
case -914744082: return bem_lengthSet_1(bevd_0);
case 563072133: return bem_endSet_1(bevd_0);
case -1988651271: return bem_copyTo_1(bevd_0);
case 527456055: return bem_def_1(bevd_0);
case 1951419572: return bem_bottomSet_1(bevd_0);
case 1318145192: return bem_addValue_1(bevd_0);
case -795700054: return bem_put_1(bevd_0);
case -402753267: return bem_equals_1(bevd_0);
case 2029621851: return bem_maxSet_1(bevd_0);
case 1952840823: return bem_undef_1(bevd_0);
case -595547710: return bem_print_1(bevd_0);
case -889580698: return bem_topSet_1(bevd_0);
case -622835303: return bem_enqueue_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -507977338: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1843730802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1382402033: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1317838948: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
