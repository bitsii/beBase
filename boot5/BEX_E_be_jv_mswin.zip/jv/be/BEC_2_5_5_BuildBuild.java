package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_112, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_115 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_singleCC = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevp_saveIds = be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 99 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 117 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 117 */
 else  /* Line: 117 */ {
break;
} /* Line: 117 */
} /* Line: 117 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try  /* Line: 127 */ {
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 130 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(376367511);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 135 */
if (bevp_printSteps.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 137 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 138 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(1543632707);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-2130755695, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 144 */ {
} /* Line: 144 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 155 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(70486391);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 158 */
} /* Line: 156 */
 else  /* Line: 155 */ {
break;
} /* Line: 155 */
} /* Line: 155 */
} /* Line: 155 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 164 */
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 168 */
 else  /* Line: 169 */ {
bevp_exeName = bevp_libName;
} /* Line: 170 */
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(1543632707);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 188 */
bevt_61_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 192 */
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 196 */
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 200 */
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 204 */
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 208 */
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 212 */
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 216 */
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 220 */
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-401222514);
} /* Line: 224 */
bevt_79_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-401222514);
} /* Line: 228 */
 else  /* Line: 229 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 230 */
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 238 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 239 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_91_tmpany_phold).bevi_bool) /* Line: 239 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 240 */
 else  /* Line: 239 */ {
break;
} /* Line: 239 */
} /* Line: 239 */
} /* Line: 239 */
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitLangs = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevp_emitFlags = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_100_tmpany_phold = bevp_params.bem_get_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_100_tmpany_phold.bem_firstGet_0();
bevt_104_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_59));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bem_add_1(bevp_makeName);
bevt_109_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_109_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_62));
} /* Line: 263 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_platform.bemd_0(1543632707);
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_114_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_111_tmpany_phold);
if (bevl_platformSources == null) {
bevt_115_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_115_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_116_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 272 */
bevt_118_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_117_tmpany_phold = bevl_outLang.bem_add_1(bevt_118_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_117_tmpany_phold);
if (bevl_langSources == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_120_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 277 */
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_121_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_121_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_122_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 281 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(70486391);
bevt_123_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_123_tmpany_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-2052057071);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_125_tmpany_phold = bevt_126_tmpany_phold.bem_existsGet_0();
if (bevt_125_tmpany_phold.bevi_bool) {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_124_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 289 */ {
bevt_127_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_127_tmpany_phold.bem_makeDirs_0();
} /* Line: 290 */
if (bevp_emitFileHeader == null) {
bevt_128_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_128_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevt_129_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_129_tmpany_phold.bem_readerGet_0();
bevt_130_tmpany_phold = bevl_emr.bemd_0(1089524457);
bevp_emitFileHeader = bevt_130_tmpany_phold.bemd_0(-389772636);
bevl_emr.bemd_0(-1021119130);
} /* Line: 295 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(575965513, bevp_nl);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(575965513, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(575965513, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(575965513, bevp_nl);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(575965513, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(575965513, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_clnode = bevl_ci.bemd_0(70486391);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(2005486726);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1748612026);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(2005486726);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(781011196);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(376367511);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(2005486726);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(781011196);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(376367511);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(2005486726);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(781011196);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(376367511);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 322 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 320 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 327 */ {
bevl_clnode = bevl_ci.bemd_0(70486391);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(2005486726);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(2005486726);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(781011196);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(376367511);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(2059112515, bevt_26_tmpany_phold);
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 340 */ {
return bevp_emitCommon;
} /* Line: 341 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 348 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 348 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 348 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 354 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 355 */
 else  /* Line: 356 */ {
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_10_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 357 */
} /* Line: 348 */
} /* Line: 348 */
} /* Line: 348 */
return bevp_emitCommon;
} /* Line: 359 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(1089524457);
bevt_5_tmpany_phold = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 383 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 383 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 384 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 383 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 391 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 392 */
} /* Line: 391 */
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(-1788326649);
while (true)
 /* Line: 397 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 397 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(70486391);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 401 */
} /* Line: 398 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(-1788326649);
while (true)
 /* Line: 404 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 404 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(70486391);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-1311092427);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 409 */
} /* Line: 405 */
 else  /* Line: 404 */ {
break;
} /* Line: 404 */
} /* Line: 404 */
if (bevp_parse.bevi_bool) /* Line: 412 */ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 415 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 415 */ {
bevl_tb = bevl_i.bemd_0(70486391);
bevt_20_tmpany_phold = bevl_tb.bemd_0(376367511);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 418 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(376367511);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 420 */
} /* Line: 418 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bem_buildSyns_1(bevl_em);
} /* Line: 423 */
bevt_23_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_26_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 438 */
if (bevp_doEmit.bevi_bool) /* Line: 440 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-2018033262);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 444 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 444 */ {
bevl_clnode = bevl_ci.bemd_0(70486391);
bevl_em.bemd_1(1280761754, bevl_clnode);
} /* Line: 446 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
bevl_em.bemd_0(111863470);
bevl_em.bemd_0(80310113);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 450 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 450 */ {
bevl_clnode = bevl_ci.bemd_0(70486391);
bevl_em.bemd_1(1665345051, bevl_clnode);
} /* Line: 452 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
} /* Line: 450 */
bevt_44_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 458 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 461 */ {
bevl_em.bemd_1(1146207699, bevp_deployLibrary);
} /* Line: 463 */
if (bevp_make.bevi_bool) /* Line: 466 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 467 */ {
bevl_em.bemd_1(-2083419130, bevp_deployLibrary);
bevl_em.bemd_1(1196145425, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 470 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 471 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(-2018033262);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(457592076);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(-1963358688);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(-1607235285);
bevl_cpTo.bemd_1(236951978, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-676106203);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-198227668);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 475 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-676106203);
bevt_58_tmpany_phold.bemd_0(2081067775);
} /* Line: 476 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-676106203);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-198227668);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-1727276016);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-676106203);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-676106203);
bevl_em.bemd_2(1166563122, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 479 */
} /* Line: 478 */
 else  /* Line: 471 */ {
break;
} /* Line: 471 */
} /* Line: 471 */
} /* Line: 471 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 486 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 486 */
 else  /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 486 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(70486391);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(70486391);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-676106203);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(-198227668);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 490 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-676106203);
bevt_76_tmpany_phold.bemd_0(2081067775);
} /* Line: 491 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-676106203);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(-198227668);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(-1727276016);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 493 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-676106203);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-676106203);
bevl_em.bemd_2(1166563122, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 494 */
} /* Line: 493 */
 else  /* Line: 486 */ {
break;
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 467 */
bevt_83_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 502 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 504 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 505 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 507 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 508 */
if (bevp_run.bevi_bool) /* Line: 511 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(1158592325, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 515 */
bevt_98_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 521 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 521 */ {
bevl_kls = bevl_ci.bemd_0(70486391);
bevt_2_tmpany_phold = bevl_kls.bemd_0(2005486726);
bevt_2_tmpany_phold.bemd_1(652359368, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(652359368, bevp_libName);
} /* Line: 525 */
 else  /* Line: 521 */ {
break;
} /* Line: 521 */
} /* Line: 521 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 527 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 527 */ {
bevl_kls = bevl_ci.bemd_0(70486391);
bevt_5_tmpany_phold = bevl_kls.bemd_0(2005486726);
bevl_syn = bevt_5_tmpany_phold.bemd_0(559266872);
bevl_syn.bemd_2(-482374346, this, bevl_kls);
bevl_syn.bemd_1(872935474, this);
} /* Line: 531 */
 else  /* Line: 527 */ {
break;
} /* Line: 527 */
} /* Line: 527 */
bevt_6_tmpany_phold = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(2005486726);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(559266872);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 537 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(2005486726);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(559266872);
return bevt_3_tmpany_phold;
} /* Line: 538 */
bevt_5_tmpany_phold = beva_klass.bemd_0(2005486726);
bevt_5_tmpany_phold.bemd_1(652359368, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(2005486726);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1488112444);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 541 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 542 */
 else  /* Line: 543 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(2005486726);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1488112444);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(376367511);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 546 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(2005486726);
bevt_14_tmpany_phold.bemd_1(652359368, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 548 */
 else  /* Line: 549 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(2005486726);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1488112444);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 552 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 554 */
bevt_17_tmpany_phold = beva_klass.bemd_0(2005486726);
bevt_17_tmpany_phold.bemd_1(1453938082, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(2005486726);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(781011196);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(376367511);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(376367511);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 564 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 565 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(1488356279, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 580 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 581 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 594 */ {
if (bevp_printSteps.bevi_bool) /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 595 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 595 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 595 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_5_tmpany_phold = beva_toParse.bemd_0(376367511);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 596 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-676106203);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(47102774);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1089524457);
bevl_src = bevt_6_tmpany_phold.bemd_1(-1411041617, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-676106203);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(47102774);
bevt_9_tmpany_phold.bemd_0(-1021119130);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 605 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 606 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(1900201581);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 609 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_14_tmpany_phold);
} /* Line: 611 */
if (bevp_printSteps.bevi_bool) /* Line: 614 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 615 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-1180673908, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 618 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_18_tmpany_phold);
} /* Line: 620 */
if (bevp_printSteps.bevi_bool) /* Line: 622 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 623 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-1180673908, bevt_20_tmpany_phold);
bevl_trans.bemd_0(207193998);
if (bevp_printAllAst.bevi_bool) /* Line: 628 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_22_tmpany_phold);
} /* Line: 630 */
if (bevp_printSteps.bevi_bool) /* Line: 633 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 634 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-1180673908, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 637 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_26_tmpany_phold);
} /* Line: 639 */
if (bevp_printSteps.bevi_bool) /* Line: 642 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 643 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-1180673908, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 646 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_30_tmpany_phold);
} /* Line: 648 */
if (bevp_printSteps.bevi_bool) /* Line: 651 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 652 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-1180673908, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 655 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_34_tmpany_phold);
} /* Line: 657 */
if (bevp_printSteps.bevi_bool) /* Line: 660 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 661 */
bevt_36_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-1180673908, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 664 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_38_tmpany_phold);
} /* Line: 666 */
if (bevp_printSteps.bevi_bool) /* Line: 669 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 670 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-1180673908, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 673 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_42_tmpany_phold);
} /* Line: 675 */
if (bevp_printSteps.bevi_bool) /* Line: 678 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 679 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-1180673908, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 682 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_46_tmpany_phold);
} /* Line: 684 */
if (bevp_printSteps.bevi_bool) /* Line: 687 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 688 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-1180673908, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 691 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_50_tmpany_phold);
} /* Line: 693 */
if (bevp_printSteps.bevi_bool) /* Line: 695 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 696 */
bevt_52_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-1180673908, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 699 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_54_tmpany_phold);
} /* Line: 701 */
if (bevp_printSteps.bevi_bool) /* Line: 704 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 706 */
bevt_57_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-1180673908, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 709 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 709 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 709 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1180673908, bevt_59_tmpany_phold);
} /* Line: 711 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 713 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(-1477798291);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 713 */ {
bevl_clnode = bevl_ci.bemd_0(70486391);
bevl_tunode = bevl_clnode.bemd_0(1975288699);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(1189999910, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(2005486726);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1326550567);
bevl_ntt.bemd_1(-997778675, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(593438275, bevl_ntt);
bevl_clnode.bemd_0(2081067775);
bevl_ntunode.bemd_1(-252570450, bevl_clnode);
bevl_ntunode.bemd_1(683130996, bevl_clnode);
} /* Line: 724 */
 else  /* Line: 713 */ {
break;
} /* Line: 713 */
} /* Line: 713 */
} /* Line: 713 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(-1105925460);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(-115938766);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 734 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 734 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(593438275, bevt_2_tmpany_phold);
bevl_node.bemd_1(1793316008, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(2005486726);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-2130755695, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 738 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 739 */
bevt_6_tmpany_phold = bevl_node.bemd_0(2005486726);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(-886160285, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 741 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(239597339, beva_parnode);
} /* Line: 743 */
} /* Line: 741 */
 else  /* Line: 734 */ {
break;
} /* Line: 734 */
} /* Line: 734 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(691160175, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(1189999910, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(593438275, bevl_nlnp);
bevl_nlnpn.bemd_1(683130996, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_113));
bevl_nlc.bemd_1(-1356620423, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-517686358, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1062976618, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-1294078698, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(440082688, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(2005486726);
bevl_nlc.bemd_1(1528304474, bevt_11_tmpany_phold);
beva_node.bemd_1(-252570450, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(1189999910, bevt_12_tmpany_phold);
beva_node.bemd_1(593438275, bevl_nlc);
bevl_nlnpn.bemd_0(-1673849877);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_114));
bevt_13_tmpany_phold = beva_tName.bemd_1(-2130755695, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_115));
bevt_15_tmpany_phold = beva_tName.bemd_1(-2130755695, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevl_pn = beva_node.bemd_0(2062687018);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 775 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-741474847);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-2130755695, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-741474847);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(-2130755695, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 775 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 775 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 775 */ {
bevl_pn2 = bevl_pn.bemd_0(2062687018);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-741474847);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(-886160285, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-741474847);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(-886160285, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-741474847);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(-886160285, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-741474847);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(-886160285, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(2005486726);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(1608908695);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(575965513, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(1528304474, bevt_37_tmpany_phold);
bevl_pn.bemd_0(2081067775);
} /* Line: 784 */
} /* Line: 777 */
} /* Line: 775 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public final BEC_2_4_6_TextString bem_mainNameGetDirect_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public final BEC_2_4_6_TextString bem_exeNameGetDirect_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_platformGetDirect_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public final BEC_2_4_6_TextString bem_nlGetDirect_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public final BEC_2_4_6_TextString bem_buildMessageGetDirect_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_includePathGetDirect_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_builtGetDirect_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printAstGetDirect_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_parseGetDirect_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_makeGetDirect_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_codeGetDirect_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public final BEC_2_4_6_TextString bem_estrGetDirect_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public final BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public final BEC_2_4_6_TextString bem_deployPathGetDirect_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_runGetDirect_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public final BEC_2_4_6_TextString bem_compilerGetDirect_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public final BEC_2_4_6_TextString bem_makeNameGetDirect_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public final BEC_2_4_6_TextString bem_makeArgsGetDirect_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public final BEC_2_4_6_TextString bem_readBufferGetDirect_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() throws Throwable {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 81, 87, 88, 89, 90, 91, 91, 98, 98, 98, 98, 0, 98, 98, 0, 0, 0, 0, 0, 99, 99, 101, 101, 105, 105, 105, 105, 109, 109, 110, 110, 110, 114, 115, 116, 116, 116, 116, 116, 117, 117, 117, 118, 117, 120, 124, 125, 126, 128, 129, 130, 132, 133, 134, 134, 135, 0, 0, 0, 138, 140, 144, 144, 144, 146, 151, 153, 154, 154, 154, 155, 155, 0, 155, 155, 156, 156, 156, 157, 158, 158, 163, 163, 163, 163, 164, 166, 166, 166, 167, 167, 168, 168, 168, 170, 172, 172, 172, 172, 172, 172, 173, 174, 174, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 182, 182, 184, 184, 184, 185, 185, 185, 186, 186, 187, 187, 188, 190, 190, 191, 191, 192, 194, 194, 195, 195, 196, 198, 198, 199, 199, 200, 202, 202, 203, 203, 204, 206, 206, 207, 207, 208, 210, 210, 211, 211, 212, 214, 214, 215, 215, 216, 218, 218, 219, 219, 220, 222, 222, 223, 223, 224, 226, 226, 227, 227, 228, 230, 232, 232, 232, 233, 233, 233, 234, 234, 235, 235, 236, 237, 237, 238, 238, 238, 238, 238, 0, 0, 0, 239, 0, 239, 239, 240, 243, 243, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 252, 253, 254, 255, 256, 257, 260, 260, 261, 263, 270, 270, 270, 270, 270, 271, 271, 272, 272, 275, 275, 275, 276, 276, 277, 277, 280, 281, 281, 0, 281, 281, 282, 282, 284, 285, 286, 288, 289, 289, 289, 289, 290, 290, 292, 292, 293, 293, 294, 294, 295, 301, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 304, 308, 309, 309, 309, 310, 311, 311, 311, 311, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 319, 319, 319, 319, 319, 320, 320, 321, 0, 321, 321, 322, 327, 327, 327, 328, 329, 329, 329, 329, 329, 329, 336, 336, 340, 340, 341, 346, 346, 347, 348, 348, 349, 350, 350, 351, 352, 352, 353, 354, 354, 355, 357, 357, 357, 359, 361, 365, 367, 367, 367, 368, 368, 369, 369, 369, 370, 370, 371, 372, 372, 373, 373, 373, 374, 374, 374, 380, 380, 381, 382, 382, 383, 0, 383, 383, 384, 387, 388, 388, 389, 390, 392, 392, 392, 395, 397, 0, 397, 397, 398, 398, 398, 399, 400, 401, 404, 0, 404, 404, 405, 405, 405, 406, 407, 408, 409, 409, 414, 415, 415, 416, 418, 418, 419, 419, 420, 423, 426, 426, 426, 429, 429, 429, 431, 431, 432, 432, 433, 433, 433, 434, 434, 434, 435, 435, 435, 436, 436, 436, 437, 437, 437, 438, 438, 441, 442, 444, 444, 444, 445, 446, 448, 449, 450, 450, 450, 451, 452, 456, 456, 456, 457, 457, 458, 458, 458, 460, 460, 460, 463, 467, 467, 468, 469, 471, 0, 471, 471, 472, 472, 473, 473, 474, 474, 474, 475, 475, 476, 476, 478, 478, 478, 479, 479, 479, 483, 484, 486, 486, 0, 0, 0, 487, 487, 488, 488, 488, 488, 488, 488, 488, 488, 490, 490, 491, 491, 493, 493, 493, 494, 494, 494, 499, 499, 499, 501, 501, 502, 502, 502, 504, 504, 505, 505, 505, 507, 507, 508, 508, 508, 512, 512, 513, 514, 514, 514, 514, 514, 515, 517, 517, 521, 521, 521, 522, 523, 523, 524, 525, 527, 527, 527, 528, 529, 529, 530, 531, 533, 533, 537, 537, 537, 537, 538, 538, 538, 540, 540, 541, 541, 541, 541, 542, 544, 544, 544, 544, 544, 546, 546, 547, 547, 548, 552, 552, 552, 554, 556, 556, 557, 557, 557, 557, 558, 562, 563, 563, 564, 564, 565, 571, 571, 572, 573, 580, 580, 581, 583, 588, 589, 590, 591, 592, 593, 593, 0, 0, 0, 596, 596, 596, 596, 598, 600, 600, 600, 600, 601, 601, 601, 602, 606, 606, 608, 608, 610, 610, 611, 611, 615, 615, 617, 617, 619, 619, 620, 620, 623, 623, 626, 626, 627, 629, 629, 630, 630, 634, 634, 636, 636, 638, 638, 639, 639, 643, 643, 645, 645, 647, 647, 648, 648, 652, 652, 654, 654, 656, 656, 657, 657, 661, 661, 663, 663, 665, 665, 666, 666, 670, 670, 672, 672, 674, 674, 675, 675, 679, 679, 681, 681, 683, 683, 684, 684, 688, 688, 690, 690, 692, 692, 693, 693, 696, 696, 698, 698, 700, 700, 701, 701, 705, 705, 706, 706, 708, 708, 0, 0, 0, 710, 710, 711, 711, 713, 713, 713, 714, 716, 717, 718, 718, 719, 720, 720, 720, 721, 722, 723, 724, 730, 731, 732, 733, 733, 734, 734, 735, 736, 736, 737, 738, 738, 739, 741, 741, 742, 743, 750, 751, 753, 754, 754, 755, 756, 758, 759, 759, 760, 760, 761, 761, 762, 762, 763, 763, 764, 764, 766, 768, 768, 769, 771, 773, 773, 0, 773, 773, 0, 0, 774, 775, 775, 775, 775, 775, 0, 775, 775, 775, 0, 0, 0, 0, 0, 776, 777, 777, 0, 777, 777, 777, 777, 777, 777, 0, 0, 0, 777, 777, 777, 0, 0, 0, 777, 777, 777, 0, 0, 0, 0, 0, 783, 783, 783, 783, 784, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 294, 299, 300, 301, 303, 306, 307, 309, 312, 316, 319, 323, 326, 327, 329, 330, 336, 337, 338, 339, 346, 347, 348, 349, 350, 362, 363, 364, 365, 366, 367, 368, 369, 372, 377, 378, 379, 385, 393, 394, 395, 397, 398, 399, 403, 404, 405, 406, 407, 410, 414, 417, 421, 423, 429, 430, 431, 434, 577, 578, 579, 580, 585, 586, 587, 587, 590, 592, 593, 594, 599, 600, 601, 602, 610, 611, 612, 613, 615, 617, 618, 619, 620, 621, 623, 624, 625, 628, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 688, 689, 691, 692, 693, 698, 699, 701, 702, 703, 708, 709, 711, 712, 713, 718, 719, 721, 722, 723, 728, 729, 731, 732, 733, 738, 739, 741, 742, 743, 748, 749, 751, 752, 753, 758, 759, 761, 762, 763, 768, 769, 771, 772, 773, 778, 779, 781, 782, 783, 788, 789, 792, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 812, 813, 814, 819, 820, 823, 827, 830, 830, 833, 835, 836, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 881, 882, 885, 887, 888, 889, 890, 891, 892, 897, 898, 899, 901, 902, 903, 904, 909, 910, 911, 913, 914, 915, 915, 918, 920, 921, 922, 928, 929, 930, 931, 932, 933, 934, 939, 940, 941, 943, 948, 949, 950, 951, 952, 953, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 1018, 1019, 1020, 1023, 1025, 1026, 1027, 1028, 1029, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1045, 1046, 1046, 1049, 1051, 1052, 1059, 1060, 1061, 1062, 1063, 1064, 1069, 1070, 1070, 1073, 1075, 1076, 1089, 1090, 1093, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1111, 1112, 1128, 1133, 1134, 1136, 1141, 1142, 1143, 1144, 1146, 1149, 1150, 1152, 1155, 1156, 1158, 1161, 1162, 1164, 1167, 1168, 1169, 1174, 1176, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1335, 1336, 1337, 1338, 1343, 1344, 1344, 1347, 1349, 1350, 1357, 1358, 1363, 1364, 1365, 1367, 1368, 1369, 1372, 1373, 1373, 1376, 1378, 1379, 1380, 1385, 1386, 1387, 1388, 1395, 1395, 1398, 1400, 1401, 1402, 1407, 1408, 1409, 1410, 1411, 1412, 1420, 1421, 1424, 1426, 1427, 1428, 1430, 1431, 1432, 1439, 1441, 1442, 1443, 1444, 1445, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1474, 1475, 1476, 1477, 1480, 1482, 1483, 1489, 1490, 1491, 1492, 1495, 1497, 1498, 1505, 1506, 1507, 1508, 1513, 1514, 1515, 1516, 1518, 1519, 1520, 1522, 1525, 1530, 1531, 1532, 1534, 1534, 1537, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1550, 1551, 1553, 1554, 1555, 1557, 1558, 1559, 1567, 1568, 1571, 1573, 1575, 1578, 1582, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1598, 1599, 1601, 1602, 1603, 1605, 1606, 1607, 1616, 1617, 1618, 1619, 1624, 1625, 1626, 1627, 1629, 1634, 1635, 1636, 1637, 1639, 1644, 1645, 1646, 1647, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1660, 1661, 1674, 1675, 1678, 1680, 1681, 1682, 1683, 1684, 1690, 1691, 1694, 1696, 1697, 1698, 1699, 1700, 1706, 1707, 1735, 1736, 1737, 1742, 1743, 1744, 1745, 1747, 1748, 1749, 1750, 1751, 1756, 1757, 1760, 1761, 1762, 1763, 1764, 1765, 1770, 1771, 1772, 1773, 1776, 1777, 1778, 1780, 1782, 1783, 1784, 1785, 1786, 1787, 1788, 1796, 1797, 1798, 1799, 1804, 1805, 1807, 1808, 1809, 1810, 1814, 1819, 1820, 1822, 1901, 1902, 1903, 1904, 1905, 1906, 1907, 1910, 1914, 1917, 1921, 1922, 1923, 1924, 1926, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1936, 1937, 1939, 1940, 1942, 1943, 1944, 1945, 1948, 1949, 1951, 1952, 1954, 1955, 1956, 1957, 1960, 1961, 1963, 1964, 1965, 1967, 1968, 1969, 1970, 1973, 1974, 1976, 1977, 1979, 1980, 1981, 1982, 1985, 1986, 1988, 1989, 1991, 1992, 1993, 1994, 1997, 1998, 2000, 2001, 2003, 2004, 2005, 2006, 2009, 2010, 2012, 2013, 2015, 2016, 2017, 2018, 2021, 2022, 2024, 2025, 2027, 2028, 2029, 2030, 2033, 2034, 2036, 2037, 2039, 2040, 2041, 2042, 2045, 2046, 2048, 2049, 2051, 2052, 2053, 2054, 2057, 2058, 2060, 2061, 2063, 2064, 2065, 2066, 2069, 2070, 2071, 2072, 2074, 2075, 2077, 2081, 2084, 2088, 2089, 2090, 2091, 2093, 2094, 2097, 2099, 2100, 2101, 2102, 2103, 2104, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2133, 2134, 2135, 2136, 2137, 2138, 2141, 2143, 2144, 2145, 2146, 2147, 2148, 2150, 2152, 2153, 2155, 2156, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2236, 2237, 2239, 2242, 2243, 2245, 2248, 2252, 2253, 2258, 2259, 2260, 2261, 2263, 2266, 2267, 2268, 2270, 2273, 2277, 2280, 2284, 2287, 2288, 2293, 2294, 2297, 2298, 2299, 2301, 2302, 2303, 2305, 2308, 2312, 2315, 2316, 2317, 2319, 2322, 2326, 2329, 2330, 2331, 2333, 2336, 2340, 2343, 2346, 2350, 2351, 2352, 2353, 2354, 2361, 2364, 2367, 2371, 2375, 2378, 2381, 2385, 2389, 2392, 2395, 2399, 2403, 2406, 2409, 2413, 2417, 2420, 2423, 2427, 2431, 2434, 2437, 2441, 2445, 2448, 2451, 2455, 2459, 2462, 2465, 2469, 2473, 2476, 2479, 2483, 2487, 2490, 2493, 2497, 2501, 2504, 2507, 2511, 2515, 2518, 2521, 2525, 2529, 2532, 2535, 2539, 2543, 2546, 2549, 2553, 2557, 2560, 2563, 2567, 2571, 2574, 2577, 2581, 2585, 2588, 2591, 2595, 2599, 2602, 2605, 2609, 2613, 2616, 2619, 2623, 2627, 2630, 2633, 2637, 2641, 2644, 2647, 2651, 2655, 2658, 2661, 2665, 2669, 2672, 2675, 2679, 2683, 2686, 2689, 2693, 2697, 2700, 2703, 2707, 2711, 2714, 2717, 2721, 2725, 2728, 2731, 2735, 2739, 2742, 2745, 2749, 2753, 2756, 2759, 2763, 2767, 2770, 2773, 2777, 2781, 2784, 2787, 2791, 2795, 2798, 2801, 2805, 2809, 2812, 2815, 2819, 2823, 2826, 2829, 2833, 2837, 2840, 2843, 2847, 2851, 2854, 2857, 2861, 2865, 2868, 2871, 2875, 2879, 2882, 2885, 2889, 2893, 2896, 2899, 2903, 2907, 2910, 2913, 2917, 2921, 2924, 2927, 2931, 2935, 2938, 2941, 2945, 2949, 2952, 2955, 2959, 2963, 2966, 2969, 2973, 2977, 2980, 2983, 2987, 2991, 2994, 2997, 3001, 3005, 3008, 3011, 3015, 3019, 3022, 3025, 3029, 3033, 3036, 3039, 3043, 3047, 3050, 3053, 3057, 3061, 3064, 3067, 3071, 3075, 3078, 3081, 3085, 3089, 3092, 3095, 3099, 3103, 3106, 3109, 3113, 3117, 3120, 3123, 3127, 3131, 3134, 3137, 3141, 3145, 3148, 3151, 3155, 3159, 3162, 3165, 3169, 3173, 3176, 3179, 3183, 3187, 3190, 3193, 3197, 3201, 3204, 3207, 3211, 3215, 3218, 3221, 3225, 3229, 3232, 3235, 3239, 3243, 3246, 3249, 3253, 3257, 3260, 3263, 3267, 3271, 3274, 3277, 3281, 3285, 3288, 3291, 3295, 3299, 3302, 3305, 3309, 3313, 3316, 3319, 3323, 3327, 3330, 3333, 3337, 3341, 3344, 3347, 3351, 3355, 3358, 3361, 3365, 3369, 3372, 3376};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 51 255
new 0 51 255
assign 1 53 256
new 0 53 256
assign 1 54 257
new 0 54 257
assign 1 55 258
new 0 55 258
assign 1 56 259
new 0 56 259
assign 1 58 260
new 0 58 260
assign 1 59 261
new 0 59 261
assign 1 60 262
new 0 60 262
assign 1 61 263
new 0 61 263
assign 1 62 264
new 0 62 264
assign 1 63 265
new 0 63 265
assign 1 64 266
new 0 64 266
assign 1 68 267
new 0 68 267
assign 1 70 268
new 1 70 268
assign 1 71 269
ntypesGet 0 71 269
assign 1 72 270
twtokGet 0 72 270
assign 1 73 271
new 0 73 271
assign 1 73 272
new 1 73 272
assign 1 76 273
new 0 76 273
assign 1 79 274
new 0 79 274
assign 1 80 275
new 0 80 275
assign 1 81 276
new 0 81 276
assign 1 87 277
new 0 87 277
assign 1 88 278
new 0 88 278
assign 1 89 279
new 0 89 279
assign 1 90 280
new 0 90 280
assign 1 91 281
new 0 91 281
assign 1 91 282
new 1 91 282
assign 1 98 294
def 1 98 299
assign 1 98 300
new 0 98 300
assign 1 98 301
equals 1 98 301
assign 1 0 303
assign 1 98 306
new 0 98 306
assign 1 98 307
ends 1 98 307
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 0 319
assign 1 0 323
assign 1 99 326
new 0 99 326
return 1 99 327
assign 1 101 329
new 0 101 329
return 1 101 330
assign 1 105 336
new 0 105 336
assign 1 105 337
new 0 105 337
assign 1 105 338
swap 2 105 338
return 1 105 339
assign 1 109 346
new 0 109 346
assign 1 109 347
argsGet 0 109 347
assign 1 110 348
new 0 110 348
assign 1 110 349
main 1 110 349
exit 1 110 350
assign 1 114 362
assign 1 115 363
new 1 115 363
assign 1 116 364
new 0 116 364
assign 1 116 365
new 0 116 365
assign 1 116 366
get 2 116 366
assign 1 116 367
firstGet 0 116 367
assign 1 116 368
new 1 116 368
assign 1 117 369
new 0 117 369
assign 1 117 372
lesser 1 117 377
assign 1 118 378
go 0 118 378
incrementValue 0 117 379
return 1 120 385
assign 1 124 393
new 0 124 393
config 0 125 394
assign 1 126 395
new 0 126 395
assign 1 128 397
new 0 128 397
assign 1 129 398
doWhat 0 129 398
assign 1 130 399
new 0 130 399
assign 1 132 403
toString 0 132 403
assign 1 133 404
new 0 133 404
assign 1 134 405
new 0 134 405
assign 1 134 406
add 1 134 406
assign 1 135 407
new 0 135 407
assign 1 0 410
assign 1 0 414
assign 1 0 417
print 0 138 421
return 1 140 423
assign 1 144 429
nameGet 0 144 429
assign 1 144 430
new 0 144 430
assign 1 144 431
equals 1 144 431
return 1 146 434
assign 1 151 577
new 0 151 577
assign 1 153 578
new 0 153 578
assign 1 154 579
get 1 154 579
assign 1 154 580
def 1 154 585
assign 1 155 586
get 1 155 586
assign 1 155 587
iteratorGet 0 0 587
assign 1 155 590
hasNextGet 0 155 590
assign 1 155 592
nextGet 0 155 592
assign 1 156 593
has 1 156 593
assign 1 156 594
not 0 156 599
put 1 157 600
assign 1 158 601
new 1 158 601
addFile 1 158 602
assign 1 163 610
new 0 163 610
assign 1 163 611
nameGet 0 163 611
assign 1 163 612
new 0 163 612
assign 1 163 613
equals 1 163 613
preProcessorSet 1 164 615
assign 1 166 617
new 0 166 617
assign 1 166 618
get 1 166 618
assign 1 166 619
firstGet 0 166 619
assign 1 167 620
new 0 167 620
assign 1 167 621
has 1 167 621
assign 1 168 623
new 0 168 623
assign 1 168 624
get 1 168 624
assign 1 168 625
firstGet 0 168 625
assign 1 170 628
assign 1 172 630
new 0 172 630
assign 1 172 631
new 0 172 631
assign 1 172 632
get 2 172 632
assign 1 172 633
firstGet 0 172 633
assign 1 172 634
new 1 172 634
assign 1 172 635
pathGet 0 172 635
addStep 1 173 636
assign 1 174 637
new 0 174 637
addStep 1 174 638
assign 1 175 639
new 0 175 639
assign 1 175 640
new 0 175 640
assign 1 175 641
get 2 175 641
assign 1 175 642
firstGet 0 175 642
assign 1 175 643
new 1 175 643
assign 1 175 644
pathGet 0 175 644
assign 1 176 645
new 0 176 645
assign 1 176 646
new 0 176 646
assign 1 176 647
nameGet 0 176 647
assign 1 176 648
get 2 176 648
assign 1 176 649
firstGet 0 176 649
assign 1 176 650
new 1 176 650
assign 1 177 651
new 0 177 651
assign 1 177 652
nameGet 0 177 652
assign 1 177 653
get 2 177 653
assign 1 177 654
firstGet 0 177 654
assign 1 177 655
new 1 177 655
assign 1 178 656
new 0 178 656
assign 1 178 657
new 0 178 657
assign 1 178 658
get 2 178 658
assign 1 178 659
firstGet 0 178 659
assign 1 178 660
new 1 178 660
assign 1 179 661
new 0 179 661
assign 1 179 662
new 0 179 662
assign 1 179 663
get 2 179 663
assign 1 179 664
firstGet 0 179 664
assign 1 179 665
new 1 179 665
assign 1 180 666
new 0 180 666
assign 1 180 667
new 0 180 667
assign 1 180 668
get 2 180 668
assign 1 180 669
firstGet 0 180 669
assign 1 180 670
new 1 180 670
assign 1 181 671
new 0 181 671
assign 1 181 672
get 1 181 672
assign 1 182 673
new 0 182 673
assign 1 182 674
get 1 182 674
assign 1 184 675
new 0 184 675
assign 1 184 676
get 1 184 676
assign 1 184 677
firstGet 0 184 677
assign 1 185 678
new 0 185 678
assign 1 185 679
get 1 185 679
assign 1 185 680
firstGet 0 185 680
assign 1 186 681
new 0 186 681
assign 1 186 682
get 1 186 682
assign 1 187 683
undef 1 187 688
assign 1 188 689
new 0 188 689
assign 1 190 691
new 0 190 691
assign 1 190 692
get 1 190 692
assign 1 191 693
undef 1 191 698
assign 1 192 699
new 0 192 699
assign 1 194 701
new 0 194 701
assign 1 194 702
get 1 194 702
assign 1 195 703
undef 1 195 708
assign 1 196 709
new 0 196 709
assign 1 198 711
new 0 198 711
assign 1 198 712
get 1 198 712
assign 1 199 713
undef 1 199 718
assign 1 200 719
new 0 200 719
assign 1 202 721
new 0 202 721
assign 1 202 722
get 1 202 722
assign 1 203 723
undef 1 203 728
assign 1 204 729
new 0 204 729
assign 1 206 731
new 0 206 731
assign 1 206 732
get 1 206 732
assign 1 207 733
undef 1 207 738
assign 1 208 739
new 0 208 739
assign 1 210 741
new 0 210 741
assign 1 210 742
get 1 210 742
assign 1 211 743
undef 1 211 748
assign 1 212 749
new 0 212 749
assign 1 214 751
new 0 214 751
assign 1 214 752
get 1 214 752
assign 1 215 753
undef 1 215 758
assign 1 216 759
new 0 216 759
assign 1 218 761
new 0 218 761
assign 1 218 762
get 1 218 762
assign 1 219 763
undef 1 219 768
assign 1 220 769
new 0 220 769
assign 1 222 771
new 0 222 771
assign 1 222 772
get 1 222 772
assign 1 223 773
def 1 223 778
assign 1 224 779
firstGet 0 224 779
assign 1 226 781
new 0 226 781
assign 1 226 782
get 1 226 782
assign 1 227 783
def 1 227 788
assign 1 228 789
firstGet 0 228 789
assign 1 230 792
new 0 230 792
assign 1 232 794
new 0 232 794
assign 1 232 795
new 0 232 795
assign 1 232 796
isTrue 2 232 796
assign 1 233 797
new 0 233 797
assign 1 233 798
new 0 233 798
assign 1 233 799
isTrue 2 233 799
assign 1 234 800
new 0 234 800
assign 1 234 801
isTrue 1 234 801
assign 1 235 802
new 0 235 802
assign 1 235 803
isTrue 1 235 803
assign 1 236 804
new 0 236 804
assign 1 237 805
new 0 237 805
assign 1 237 806
get 1 237 806
assign 1 238 807
def 1 238 812
assign 1 238 813
isEmptyGet 0 238 813
assign 1 238 814
not 0 238 819
assign 1 0 820
assign 1 0 823
assign 1 0 827
assign 1 239 830
linkedListIteratorGet 0 0 830
assign 1 239 833
hasNextGet 0 239 833
assign 1 239 835
nextGet 0 239 835
put 1 240 836
assign 1 243 843
new 0 243 843
assign 1 243 844
isTrue 1 243 844
assign 1 244 845
new 0 244 845
assign 1 244 846
isTrue 1 244 846
assign 1 245 847
new 0 245 847
assign 1 245 848
isTrue 1 245 848
assign 1 246 849
new 0 246 849
assign 1 246 850
isTrue 1 246 850
assign 1 247 851
new 0 247 851
assign 1 247 852
new 0 247 852
assign 1 247 853
isTrue 2 247 853
assign 1 248 854
new 0 248 854
assign 1 248 855
get 1 248 855
assign 1 249 856
new 0 249 856
assign 1 249 857
get 1 249 857
assign 1 250 858
new 0 250 858
assign 1 250 859
new 0 250 859
assign 1 250 860
get 2 250 860
assign 1 250 861
firstGet 0 250 861
assign 1 251 862
new 0 251 862
assign 1 251 863
new 0 251 863
assign 1 251 864
get 2 251 864
assign 1 251 865
firstGet 0 251 865
assign 1 252 866
new 0 252 866
assign 1 252 867
add 1 252 867
assign 1 252 868
new 0 252 868
assign 1 252 869
get 2 252 869
assign 1 252 870
firstGet 0 252 870
assign 1 253 871
new 0 253 871
assign 1 254 872
new 0 254 872
assign 1 255 873
new 0 255 873
assign 1 256 874
new 0 256 874
assign 1 257 875
new 0 257 875
assign 1 260 876
def 1 260 881
assign 1 261 882
firstGet 0 261 882
assign 1 263 885
new 0 263 885
assign 1 270 887
new 0 270 887
assign 1 270 888
add 1 270 888
assign 1 270 889
nameGet 0 270 889
assign 1 270 890
add 1 270 890
assign 1 270 891
get 1 270 891
assign 1 271 892
def 1 271 897
assign 1 272 898
orderedGet 0 272 898
addAll 1 272 899
assign 1 275 901
new 0 275 901
assign 1 275 902
add 1 275 902
assign 1 275 903
get 1 275 903
assign 1 276 904
def 1 276 909
assign 1 277 910
orderedGet 0 277 910
addAll 1 277 911
assign 1 280 913
new 0 280 913
assign 1 281 914
orderedGet 0 281 914
assign 1 281 915
iteratorGet 0 0 915
assign 1 281 918
hasNextGet 0 281 918
assign 1 281 920
nextGet 0 281 920
assign 1 282 921
new 1 282 921
addValue 1 282 922
assign 1 284 928
newlineGet 0 284 928
assign 1 285 929
assign 1 286 930
new 1 286 930
assign 1 288 931
copy 0 288 931
assign 1 289 932
fileGet 0 289 932
assign 1 289 933
existsGet 0 289 933
assign 1 289 934
not 0 289 939
assign 1 290 940
fileGet 0 290 940
makeDirs 0 290 941
assign 1 292 943
def 1 292 948
assign 1 293 949
new 1 293 949
assign 1 293 950
readerGet 0 293 950
assign 1 294 951
open 0 294 951
assign 1 294 952
readString 0 294 952
close 0 295 953
assign 1 301 967
classNameGet 0 301 967
assign 1 302 968
add 1 302 968
assign 1 302 969
new 0 302 969
assign 1 302 970
add 1 302 970
assign 1 302 971
toString 0 302 971
assign 1 302 972
add 1 302 972
assign 1 303 973
add 1 303 973
assign 1 303 974
new 0 303 974
assign 1 303 975
add 1 303 975
assign 1 303 976
toString 0 303 976
assign 1 303 977
add 1 303 977
return 1 304 978
assign 1 308 1018
new 0 308 1018
assign 1 309 1019
classesGet 0 309 1019
assign 1 309 1020
valueIteratorGet 0 309 1020
assign 1 309 1023
hasNextGet 0 309 1023
assign 1 310 1025
nextGet 0 310 1025
assign 1 311 1026
shouldEmitGet 0 311 1026
assign 1 311 1027
heldGet 0 311 1027
assign 1 311 1028
fromFileGet 0 311 1028
assign 1 311 1029
has 1 311 1029
assign 1 312 1031
heldGet 0 312 1031
assign 1 312 1032
namepathGet 0 312 1032
assign 1 312 1033
toString 0 312 1033
put 1 312 1034
assign 1 313 1035
usedByGet 0 313 1035
assign 1 313 1036
heldGet 0 313 1036
assign 1 313 1037
namepathGet 0 313 1037
assign 1 313 1038
toString 0 313 1038
assign 1 313 1039
get 1 313 1039
assign 1 314 1040
def 1 314 1045
assign 1 315 1046
setIteratorGet 0 0 1046
assign 1 315 1049
hasNextGet 0 315 1049
assign 1 315 1051
nextGet 0 315 1051
put 1 316 1052
assign 1 319 1059
subClassesGet 0 319 1059
assign 1 319 1060
heldGet 0 319 1060
assign 1 319 1061
namepathGet 0 319 1061
assign 1 319 1062
toString 0 319 1062
assign 1 319 1063
get 1 319 1063
assign 1 320 1064
def 1 320 1069
assign 1 321 1070
setIteratorGet 0 0 1070
assign 1 321 1073
hasNextGet 0 321 1073
assign 1 321 1075
nextGet 0 321 1075
put 1 322 1076
assign 1 327 1089
classesGet 0 327 1089
assign 1 327 1090
valueIteratorGet 0 327 1090
assign 1 327 1093
hasNextGet 0 327 1093
assign 1 328 1095
nextGet 0 328 1095
assign 1 329 1096
heldGet 0 329 1096
assign 1 329 1097
heldGet 0 329 1097
assign 1 329 1098
namepathGet 0 329 1098
assign 1 329 1099
toString 0 329 1099
assign 1 329 1100
has 1 329 1100
shouldWriteSet 1 329 1101
assign 1 336 1111
new 0 336 1111
return 1 336 1112
assign 1 340 1128
def 1 340 1133
return 1 341 1134
assign 1 346 1136
def 1 346 1141
assign 1 347 1142
firstGet 0 347 1142
assign 1 348 1143
new 0 348 1143
assign 1 348 1144
equals 1 348 1144
assign 1 349 1146
new 1 349 1146
assign 1 350 1149
new 0 350 1149
assign 1 350 1150
equals 1 350 1150
assign 1 351 1152
new 1 351 1152
assign 1 352 1155
new 0 352 1155
assign 1 352 1156
equals 1 352 1156
assign 1 353 1158
new 1 353 1158
assign 1 354 1161
new 0 354 1161
assign 1 354 1162
equals 1 354 1162
assign 1 355 1164
new 1 355 1164
assign 1 357 1167
new 0 357 1167
assign 1 357 1168
new 1 357 1168
throw 1 357 1169
return 1 359 1174
return 1 361 1176
assign 1 365 1195
apNew 1 365 1195
assign 1 367 1196
new 0 367 1196
assign 1 367 1197
add 1 367 1197
print 0 367 1198
assign 1 368 1199
new 0 368 1199
assign 1 368 1200
now 0 368 1200
assign 1 369 1201
fileGet 0 369 1201
assign 1 369 1202
readerGet 0 369 1202
assign 1 369 1203
open 0 369 1203
assign 1 370 1204
new 0 370 1204
assign 1 370 1205
deserialize 1 370 1205
close 0 371 1206
assign 1 372 1207
synClassesGet 0 372 1207
addValue 1 372 1208
assign 1 373 1209
new 0 373 1209
assign 1 373 1210
now 0 373 1210
assign 1 373 1211
subtract 1 373 1211
assign 1 374 1212
new 0 374 1212
assign 1 374 1213
add 1 374 1213
print 0 374 1214
assign 1 380 1335
new 0 380 1335
assign 1 380 1336
now 0 380 1336
assign 1 381 1337
new 0 381 1337
assign 1 382 1338
def 1 382 1343
assign 1 383 1344
linkedListIteratorGet 0 0 1344
assign 1 383 1347
hasNextGet 0 383 1347
assign 1 383 1349
nextGet 0 383 1349
loadSyns 1 384 1350
assign 1 387 1357
emitterGet 0 387 1357
assign 1 388 1358
def 1 388 1363
assign 1 389 1364
new 4 389 1364
put 1 390 1365
assign 1 392 1367
new 0 392 1367
assign 1 392 1368
add 1 392 1368
print 0 392 1369
assign 1 395 1372
new 0 395 1372
assign 1 397 1373
iteratorGet 0 0 1373
assign 1 397 1376
hasNextGet 0 397 1376
assign 1 397 1378
nextGet 0 397 1378
assign 1 398 1379
has 1 398 1379
assign 1 398 1380
not 0 398 1385
put 1 399 1386
assign 1 400 1387
new 2 400 1387
addValue 1 401 1388
assign 1 404 1395
iteratorGet 0 0 1395
assign 1 404 1398
hasNextGet 0 404 1398
assign 1 404 1400
nextGet 0 404 1400
assign 1 405 1401
has 1 405 1401
assign 1 405 1402
not 0 405 1407
put 1 406 1408
assign 1 407 1409
new 2 407 1409
addValue 1 408 1410
assign 1 409 1411
libNameGet 0 409 1411
put 1 409 1412
assign 1 414 1420
new 0 414 1420
assign 1 415 1421
iteratorGet 0 415 1421
assign 1 415 1424
hasNextGet 0 415 1424
assign 1 416 1426
nextGet 0 416 1426
assign 1 418 1427
toString 0 418 1427
assign 1 418 1428
has 1 418 1428
assign 1 419 1430
toString 0 419 1430
put 1 419 1431
doParse 1 420 1432
buildSyns 1 423 1439
assign 1 426 1441
new 0 426 1441
assign 1 426 1442
now 0 426 1442
assign 1 426 1443
subtract 1 426 1443
assign 1 429 1444
emitCommonGet 0 429 1444
assign 1 429 1445
def 1 429 1450
assign 1 431 1451
new 0 431 1451
assign 1 431 1452
now 0 431 1452
assign 1 432 1453
emitCommonGet 0 432 1453
doEmit 0 432 1454
assign 1 433 1455
new 0 433 1455
assign 1 433 1456
now 0 433 1456
assign 1 433 1457
subtract 1 433 1457
assign 1 434 1458
new 0 434 1458
assign 1 434 1459
now 0 434 1459
assign 1 434 1460
subtract 1 434 1460
assign 1 435 1461
new 0 435 1461
assign 1 435 1462
add 1 435 1462
print 0 435 1463
assign 1 436 1464
new 0 436 1464
assign 1 436 1465
add 1 436 1465
print 0 436 1466
assign 1 437 1467
new 0 437 1467
assign 1 437 1468
add 1 437 1468
print 0 437 1469
assign 1 438 1470
new 0 438 1470
return 1 438 1471
setClassesToWrite 0 441 1474
libnameInfoGet 0 442 1475
assign 1 444 1476
classesGet 0 444 1476
assign 1 444 1477
valueIteratorGet 0 444 1477
assign 1 444 1480
hasNextGet 0 444 1480
assign 1 445 1482
nextGet 0 445 1482
doEmit 1 446 1483
emitMain 0 448 1489
emitCUInit 0 449 1490
assign 1 450 1491
classesGet 0 450 1491
assign 1 450 1492
valueIteratorGet 0 450 1492
assign 1 450 1495
hasNextGet 0 450 1495
assign 1 451 1497
nextGet 0 451 1497
emitSyn 1 452 1498
assign 1 456 1505
new 0 456 1505
assign 1 456 1506
now 0 456 1506
assign 1 456 1507
subtract 1 456 1507
assign 1 457 1508
def 1 457 1513
assign 1 458 1514
new 0 458 1514
assign 1 458 1515
add 1 458 1515
print 0 458 1516
assign 1 460 1518
new 0 460 1518
assign 1 460 1519
add 1 460 1519
print 0 460 1520
prepMake 1 463 1522
assign 1 467 1525
not 0 467 1530
make 1 468 1531
deployLibrary 1 469 1532
assign 1 471 1534
linkedListIteratorGet 0 0 1534
assign 1 471 1537
hasNextGet 0 471 1537
assign 1 471 1539
nextGet 0 471 1539
assign 1 472 1540
libnameInfoGet 0 472 1540
assign 1 472 1541
unitShlibGet 0 472 1541
assign 1 473 1542
emitPathGet 0 473 1542
assign 1 473 1543
copy 0 473 1543
assign 1 474 1544
stepsGet 0 474 1544
assign 1 474 1545
lastGet 0 474 1545
addStep 1 474 1546
assign 1 475 1547
fileGet 0 475 1547
assign 1 475 1548
existsGet 0 475 1548
assign 1 476 1550
fileGet 0 476 1550
delete 0 476 1551
assign 1 478 1553
fileGet 0 478 1553
assign 1 478 1554
existsGet 0 478 1554
assign 1 478 1555
not 0 478 1555
assign 1 479 1557
fileGet 0 479 1557
assign 1 479 1558
fileGet 0 479 1558
deployFile 2 479 1559
assign 1 483 1567
iteratorGet 0 483 1567
assign 1 484 1568
iteratorGet 0 484 1568
assign 1 486 1571
hasNextGet 0 486 1571
assign 1 486 1573
hasNextGet 0 486 1573
assign 1 0 1575
assign 1 0 1578
assign 1 0 1582
assign 1 487 1585
nextGet 0 487 1585
assign 1 487 1586
apNew 1 487 1586
assign 1 488 1587
emitPathGet 0 488 1587
assign 1 488 1588
copy 0 488 1588
assign 1 488 1589
toString 0 488 1589
assign 1 488 1590
new 0 488 1590
assign 1 488 1591
add 1 488 1591
assign 1 488 1592
nextGet 0 488 1592
assign 1 488 1593
add 1 488 1593
assign 1 488 1594
apNew 1 488 1594
assign 1 490 1595
fileGet 0 490 1595
assign 1 490 1596
existsGet 0 490 1596
assign 1 491 1598
fileGet 0 491 1598
delete 0 491 1599
assign 1 493 1601
fileGet 0 493 1601
assign 1 493 1602
existsGet 0 493 1602
assign 1 493 1603
not 0 493 1603
assign 1 494 1605
fileGet 0 494 1605
assign 1 494 1606
fileGet 0 494 1606
deployFile 2 494 1607
assign 1 499 1616
new 0 499 1616
assign 1 499 1617
now 0 499 1617
assign 1 499 1618
subtract 1 499 1618
assign 1 501 1619
def 1 501 1624
assign 1 502 1625
new 0 502 1625
assign 1 502 1626
add 1 502 1626
print 0 502 1627
assign 1 504 1629
def 1 504 1634
assign 1 505 1635
new 0 505 1635
assign 1 505 1636
add 1 505 1636
print 0 505 1637
assign 1 507 1639
def 1 507 1644
assign 1 508 1645
new 0 508 1645
assign 1 508 1646
add 1 508 1646
print 0 508 1647
assign 1 512 1650
new 0 512 1650
print 0 512 1651
assign 1 513 1652
run 2 513 1652
assign 1 514 1653
new 0 514 1653
assign 1 514 1654
add 1 514 1654
assign 1 514 1655
new 0 514 1655
assign 1 514 1656
add 1 514 1656
print 0 514 1657
return 1 515 1658
assign 1 517 1660
new 0 517 1660
return 1 517 1661
assign 1 521 1674
justParsedGet 0 521 1674
assign 1 521 1675
valueIteratorGet 0 521 1675
assign 1 521 1678
hasNextGet 0 521 1678
assign 1 522 1680
nextGet 0 522 1680
assign 1 523 1681
heldGet 0 523 1681
libNameSet 1 523 1682
assign 1 524 1683
getSyn 2 524 1683
libNameSet 1 525 1684
assign 1 527 1690
justParsedGet 0 527 1690
assign 1 527 1691
valueIteratorGet 0 527 1691
assign 1 527 1694
hasNextGet 0 527 1694
assign 1 528 1696
nextGet 0 528 1696
assign 1 529 1697
heldGet 0 529 1697
assign 1 529 1698
synGet 0 529 1698
checkInheritance 2 530 1699
integrate 1 531 1700
assign 1 533 1706
new 0 533 1706
justParsedSet 1 533 1707
assign 1 537 1735
heldGet 0 537 1735
assign 1 537 1736
synGet 0 537 1736
assign 1 537 1737
def 1 537 1742
assign 1 538 1743
heldGet 0 538 1743
assign 1 538 1744
synGet 0 538 1744
return 1 538 1745
assign 1 540 1747
heldGet 0 540 1747
libNameSet 1 540 1748
assign 1 541 1749
heldGet 0 541 1749
assign 1 541 1750
extendsGet 0 541 1750
assign 1 541 1751
undef 1 541 1756
assign 1 542 1757
new 1 542 1757
assign 1 544 1760
classesGet 0 544 1760
assign 1 544 1761
heldGet 0 544 1761
assign 1 544 1762
extendsGet 0 544 1762
assign 1 544 1763
toString 0 544 1763
assign 1 544 1764
get 1 544 1764
assign 1 546 1765
def 1 546 1770
assign 1 547 1771
heldGet 0 547 1771
libNameSet 1 547 1772
assign 1 548 1773
getSyn 2 548 1773
assign 1 552 1776
heldGet 0 552 1776
assign 1 552 1777
extendsGet 0 552 1777
assign 1 552 1778
getSynNp 1 552 1778
assign 1 554 1780
new 2 554 1780
assign 1 556 1782
heldGet 0 556 1782
synSet 1 556 1783
assign 1 557 1784
heldGet 0 557 1784
assign 1 557 1785
namepathGet 0 557 1785
assign 1 557 1786
toString 0 557 1786
addSynClass 2 557 1787
return 1 558 1788
assign 1 562 1796
toString 0 562 1796
assign 1 563 1797
synClassesGet 0 563 1797
assign 1 563 1798
get 1 563 1798
assign 1 564 1799
def 1 564 1804
return 1 565 1805
assign 1 571 1807
emitterGet 0 571 1807
assign 1 571 1808
loadSyn 1 571 1808
addSynClass 2 572 1809
return 1 573 1810
assign 1 580 1814
undef 1 580 1819
assign 1 581 1820
new 1 581 1820
return 1 583 1822
assign 1 588 1901
new 1 588 1901
assign 1 589 1902
new 0 589 1902
assign 1 590 1903
emitterGet 0 590 1903
assign 1 591 1904
assign 1 592 1905
new 0 592 1905
assign 1 593 1906
shouldEmitGet 0 593 1906
put 1 593 1907
assign 1 0 1910
assign 1 0 1914
assign 1 0 1917
assign 1 596 1921
new 0 596 1921
assign 1 596 1922
toString 0 596 1922
assign 1 596 1923
add 1 596 1923
print 0 596 1924
assign 1 598 1926
assign 1 600 1927
fileGet 0 600 1927
assign 1 600 1928
readerGet 0 600 1928
assign 1 600 1929
open 0 600 1929
assign 1 600 1930
readBuffer 1 600 1930
assign 1 601 1931
fileGet 0 601 1931
assign 1 601 1932
readerGet 0 601 1932
close 0 601 1933
assign 1 602 1934
tokenize 1 602 1934
assign 1 606 1936
new 0 606 1936
echo 0 606 1937
assign 1 608 1939
outermostGet 0 608 1939
nodify 2 608 1940
assign 1 610 1942
new 0 610 1942
print 0 610 1943
assign 1 611 1944
new 2 611 1944
traverse 1 611 1945
assign 1 615 1948
new 0 615 1948
echo 0 615 1949
assign 1 617 1951
new 0 617 1951
traverse 1 617 1952
assign 1 619 1954
new 0 619 1954
print 0 619 1955
assign 1 620 1956
new 2 620 1956
traverse 1 620 1957
assign 1 623 1960
new 0 623 1960
echo 0 623 1961
assign 1 626 1963
new 0 626 1963
traverse 1 626 1964
contain 0 627 1965
assign 1 629 1967
new 0 629 1967
print 0 629 1968
assign 1 630 1969
new 2 630 1969
traverse 1 630 1970
assign 1 634 1973
new 0 634 1973
echo 0 634 1974
assign 1 636 1976
new 0 636 1976
traverse 1 636 1977
assign 1 638 1979
new 0 638 1979
print 0 638 1980
assign 1 639 1981
new 2 639 1981
traverse 1 639 1982
assign 1 643 1985
new 0 643 1985
echo 0 643 1986
assign 1 645 1988
new 0 645 1988
traverse 1 645 1989
assign 1 647 1991
new 0 647 1991
print 0 647 1992
assign 1 648 1993
new 2 648 1993
traverse 1 648 1994
assign 1 652 1997
new 0 652 1997
echo 0 652 1998
assign 1 654 2000
new 0 654 2000
traverse 1 654 2001
assign 1 656 2003
new 0 656 2003
print 0 656 2004
assign 1 657 2005
new 2 657 2005
traverse 1 657 2006
assign 1 661 2009
new 0 661 2009
echo 0 661 2010
assign 1 663 2012
new 0 663 2012
traverse 1 663 2013
assign 1 665 2015
new 0 665 2015
print 0 665 2016
assign 1 666 2017
new 2 666 2017
traverse 1 666 2018
assign 1 670 2021
new 0 670 2021
echo 0 670 2022
assign 1 672 2024
new 0 672 2024
traverse 1 672 2025
assign 1 674 2027
new 0 674 2027
print 0 674 2028
assign 1 675 2029
new 2 675 2029
traverse 1 675 2030
assign 1 679 2033
new 0 679 2033
echo 0 679 2034
assign 1 681 2036
new 0 681 2036
traverse 1 681 2037
assign 1 683 2039
new 0 683 2039
print 0 683 2040
assign 1 684 2041
new 2 684 2041
traverse 1 684 2042
assign 1 688 2045
new 0 688 2045
echo 0 688 2046
assign 1 690 2048
new 0 690 2048
traverse 1 690 2049
assign 1 692 2051
new 0 692 2051
print 0 692 2052
assign 1 693 2053
new 2 693 2053
traverse 1 693 2054
assign 1 696 2057
new 0 696 2057
echo 0 696 2058
assign 1 698 2060
new 0 698 2060
traverse 1 698 2061
assign 1 700 2063
new 0 700 2063
print 0 700 2064
assign 1 701 2065
new 2 701 2065
traverse 1 701 2066
assign 1 705 2069
new 0 705 2069
echo 0 705 2070
assign 1 706 2071
new 0 706 2071
print 0 706 2072
assign 1 708 2074
new 0 708 2074
traverse 1 708 2075
assign 1 0 2077
assign 1 0 2081
assign 1 0 2084
assign 1 710 2088
new 0 710 2088
print 0 710 2089
assign 1 711 2090
new 2 711 2090
traverse 1 711 2091
assign 1 713 2093
classesGet 0 713 2093
assign 1 713 2094
valueIteratorGet 0 713 2094
assign 1 713 2097
hasNextGet 0 713 2097
assign 1 714 2099
nextGet 0 714 2099
assign 1 716 2100
transUnitGet 0 716 2100
assign 1 717 2101
new 1 717 2101
assign 1 718 2102
TRANSUNITGet 0 718 2102
typenameSet 1 718 2103
assign 1 719 2104
new 0 719 2104
assign 1 720 2105
heldGet 0 720 2105
assign 1 720 2106
emitsGet 0 720 2106
emitsSet 1 720 2107
heldSet 1 721 2108
delete 0 722 2109
addValue 1 723 2110
copyLoc 1 724 2111
reInitContained 0 730 2133
assign 1 731 2134
containedGet 0 731 2134
assign 1 732 2135
new 0 732 2135
assign 1 733 2136
new 0 733 2136
assign 1 733 2137
crGet 0 733 2137
assign 1 734 2138
linkedListIteratorGet 0 734 2138
assign 1 734 2141
hasNextGet 0 734 2141
assign 1 735 2143
new 1 735 2143
assign 1 736 2144
nextGet 0 736 2144
heldSet 1 736 2145
nlcSet 1 737 2146
assign 1 738 2147
heldGet 0 738 2147
assign 1 738 2148
equals 1 738 2148
assign 1 739 2150
increment 0 739 2150
assign 1 741 2152
heldGet 0 741 2152
assign 1 741 2153
notEquals 1 741 2153
addValue 1 742 2155
containerSet 1 743 2156
assign 1 750 2211
new 0 750 2211
fromString 1 751 2212
assign 1 753 2213
new 1 753 2213
assign 1 754 2214
NAMEPATHGet 0 754 2214
typenameSet 1 754 2215
heldSet 1 755 2216
copyLoc 1 756 2217
assign 1 758 2218
new 0 758 2218
assign 1 759 2219
new 0 759 2219
nameSet 1 759 2220
assign 1 760 2221
new 0 760 2221
wasBoundSet 1 760 2222
assign 1 761 2223
new 0 761 2223
boundSet 1 761 2224
assign 1 762 2225
new 0 762 2225
isConstructSet 1 762 2226
assign 1 763 2227
new 0 763 2227
isLiteralSet 1 763 2228
assign 1 764 2229
heldGet 0 764 2229
literalValueSet 1 764 2230
addValue 1 766 2231
assign 1 768 2232
CALLGet 0 768 2232
typenameSet 1 768 2233
heldSet 1 769 2234
resolveNp 0 771 2235
assign 1 773 2236
new 0 773 2236
assign 1 773 2237
equals 1 773 2237
assign 1 0 2239
assign 1 773 2242
new 0 773 2242
assign 1 773 2243
equals 1 773 2243
assign 1 0 2245
assign 1 0 2248
assign 1 774 2252
priorPeerGet 0 774 2252
assign 1 775 2253
def 1 775 2258
assign 1 775 2259
typenameGet 0 775 2259
assign 1 775 2260
SUBTRACTGet 0 775 2260
assign 1 775 2261
equals 1 775 2261
assign 1 0 2263
assign 1 775 2266
typenameGet 0 775 2266
assign 1 775 2267
ADDGet 0 775 2267
assign 1 775 2268
equals 1 775 2268
assign 1 0 2270
assign 1 0 2273
assign 1 0 2277
assign 1 0 2280
assign 1 0 2284
assign 1 776 2287
priorPeerGet 0 776 2287
assign 1 777 2288
undef 1 777 2293
assign 1 0 2294
assign 1 777 2297
typenameGet 0 777 2297
assign 1 777 2298
CALLGet 0 777 2298
assign 1 777 2299
notEquals 1 777 2299
assign 1 777 2301
typenameGet 0 777 2301
assign 1 777 2302
IDGet 0 777 2302
assign 1 777 2303
notEquals 1 777 2303
assign 1 0 2305
assign 1 0 2308
assign 1 0 2312
assign 1 777 2315
typenameGet 0 777 2315
assign 1 777 2316
VARGet 0 777 2316
assign 1 777 2317
notEquals 1 777 2317
assign 1 0 2319
assign 1 0 2322
assign 1 0 2326
assign 1 777 2329
typenameGet 0 777 2329
assign 1 777 2330
ACCESSORGet 0 777 2330
assign 1 777 2331
notEquals 1 777 2331
assign 1 0 2333
assign 1 0 2336
assign 1 0 2340
assign 1 0 2343
assign 1 0 2346
assign 1 783 2350
heldGet 0 783 2350
assign 1 783 2351
literalValueGet 0 783 2351
assign 1 783 2352
add 1 783 2352
literalValueSet 1 783 2353
delete 0 784 2354
return 1 0 2361
return 1 0 2364
assign 1 0 2367
assign 1 0 2371
return 1 0 2375
return 1 0 2378
assign 1 0 2381
assign 1 0 2385
return 1 0 2389
return 1 0 2392
assign 1 0 2395
assign 1 0 2399
return 1 0 2403
return 1 0 2406
assign 1 0 2409
assign 1 0 2413
return 1 0 2417
return 1 0 2420
assign 1 0 2423
assign 1 0 2427
return 1 0 2431
return 1 0 2434
assign 1 0 2437
assign 1 0 2441
return 1 0 2445
return 1 0 2448
assign 1 0 2451
assign 1 0 2455
return 1 0 2459
return 1 0 2462
assign 1 0 2465
assign 1 0 2469
return 1 0 2473
return 1 0 2476
assign 1 0 2479
assign 1 0 2483
return 1 0 2487
return 1 0 2490
assign 1 0 2493
assign 1 0 2497
return 1 0 2501
return 1 0 2504
assign 1 0 2507
assign 1 0 2511
return 1 0 2515
return 1 0 2518
assign 1 0 2521
assign 1 0 2525
return 1 0 2529
return 1 0 2532
assign 1 0 2535
assign 1 0 2539
return 1 0 2543
return 1 0 2546
assign 1 0 2549
assign 1 0 2553
return 1 0 2557
return 1 0 2560
assign 1 0 2563
assign 1 0 2567
return 1 0 2571
return 1 0 2574
assign 1 0 2577
assign 1 0 2581
return 1 0 2585
return 1 0 2588
assign 1 0 2591
assign 1 0 2595
return 1 0 2599
return 1 0 2602
assign 1 0 2605
assign 1 0 2609
return 1 0 2613
return 1 0 2616
assign 1 0 2619
assign 1 0 2623
return 1 0 2627
return 1 0 2630
assign 1 0 2633
assign 1 0 2637
return 1 0 2641
return 1 0 2644
assign 1 0 2647
assign 1 0 2651
return 1 0 2655
return 1 0 2658
assign 1 0 2661
assign 1 0 2665
return 1 0 2669
return 1 0 2672
assign 1 0 2675
assign 1 0 2679
return 1 0 2683
return 1 0 2686
assign 1 0 2689
assign 1 0 2693
return 1 0 2697
return 1 0 2700
assign 1 0 2703
assign 1 0 2707
return 1 0 2711
return 1 0 2714
assign 1 0 2717
assign 1 0 2721
return 1 0 2725
return 1 0 2728
assign 1 0 2731
assign 1 0 2735
return 1 0 2739
return 1 0 2742
assign 1 0 2745
assign 1 0 2749
return 1 0 2753
return 1 0 2756
assign 1 0 2759
assign 1 0 2763
return 1 0 2767
return 1 0 2770
assign 1 0 2773
assign 1 0 2777
return 1 0 2781
return 1 0 2784
assign 1 0 2787
assign 1 0 2791
return 1 0 2795
return 1 0 2798
assign 1 0 2801
assign 1 0 2805
return 1 0 2809
return 1 0 2812
assign 1 0 2815
assign 1 0 2819
return 1 0 2823
return 1 0 2826
assign 1 0 2829
assign 1 0 2833
return 1 0 2837
return 1 0 2840
assign 1 0 2843
assign 1 0 2847
return 1 0 2851
return 1 0 2854
assign 1 0 2857
assign 1 0 2861
return 1 0 2865
return 1 0 2868
assign 1 0 2871
assign 1 0 2875
return 1 0 2879
return 1 0 2882
assign 1 0 2885
assign 1 0 2889
return 1 0 2893
return 1 0 2896
assign 1 0 2899
assign 1 0 2903
return 1 0 2907
return 1 0 2910
assign 1 0 2913
assign 1 0 2917
return 1 0 2921
return 1 0 2924
assign 1 0 2927
assign 1 0 2931
return 1 0 2935
return 1 0 2938
assign 1 0 2941
assign 1 0 2945
return 1 0 2949
return 1 0 2952
assign 1 0 2955
assign 1 0 2959
return 1 0 2963
return 1 0 2966
assign 1 0 2969
assign 1 0 2973
return 1 0 2977
return 1 0 2980
assign 1 0 2983
assign 1 0 2987
return 1 0 2991
return 1 0 2994
assign 1 0 2997
assign 1 0 3001
return 1 0 3005
return 1 0 3008
assign 1 0 3011
assign 1 0 3015
return 1 0 3019
return 1 0 3022
assign 1 0 3025
assign 1 0 3029
return 1 0 3033
return 1 0 3036
assign 1 0 3039
assign 1 0 3043
return 1 0 3047
return 1 0 3050
assign 1 0 3053
assign 1 0 3057
return 1 0 3061
return 1 0 3064
assign 1 0 3067
assign 1 0 3071
return 1 0 3075
return 1 0 3078
assign 1 0 3081
assign 1 0 3085
return 1 0 3089
return 1 0 3092
assign 1 0 3095
assign 1 0 3099
return 1 0 3103
return 1 0 3106
assign 1 0 3109
assign 1 0 3113
return 1 0 3117
return 1 0 3120
assign 1 0 3123
assign 1 0 3127
return 1 0 3131
return 1 0 3134
assign 1 0 3137
assign 1 0 3141
return 1 0 3145
return 1 0 3148
assign 1 0 3151
assign 1 0 3155
return 1 0 3159
return 1 0 3162
assign 1 0 3165
assign 1 0 3169
return 1 0 3173
return 1 0 3176
assign 1 0 3179
assign 1 0 3183
return 1 0 3187
return 1 0 3190
assign 1 0 3193
assign 1 0 3197
return 1 0 3201
return 1 0 3204
assign 1 0 3207
assign 1 0 3211
return 1 0 3215
return 1 0 3218
assign 1 0 3221
assign 1 0 3225
return 1 0 3229
return 1 0 3232
assign 1 0 3235
assign 1 0 3239
return 1 0 3243
return 1 0 3246
assign 1 0 3249
assign 1 0 3253
return 1 0 3257
return 1 0 3260
assign 1 0 3263
assign 1 0 3267
return 1 0 3271
return 1 0 3274
assign 1 0 3277
assign 1 0 3281
return 1 0 3285
return 1 0 3288
assign 1 0 3291
assign 1 0 3295
return 1 0 3299
return 1 0 3302
assign 1 0 3305
assign 1 0 3309
return 1 0 3313
return 1 0 3316
assign 1 0 3319
assign 1 0 3323
return 1 0 3327
return 1 0 3330
assign 1 0 3333
assign 1 0 3337
return 1 0 3341
return 1 0 3344
assign 1 0 3347
assign 1 0 3351
return 1 0 3355
return 1 0 3358
assign 1 0 3361
assign 1 0 3365
return 1 0 3369
assign 1 0 3372
assign 1 0 3376
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 936661605: return bem_builtGetDirect_0();
case 1113829774: return bem_deployPathGet_0();
case -2060052900: return bem_classNameGet_0();
case -981148999: return bem_codeGetDirect_0();
case -1743830662: return bem_ntypesGetDirect_0();
case 820402301: return bem_ownProcessGetDirect_0();
case 1752666139: return bem_twtokGet_0();
case 519292104: return bem_loadSynsGetDirect_0();
case -873936973: return bem_closeLibrariesGetDirect_0();
case -442732453: return bem_makeArgsGet_0();
case -1969483371: return bem_printPlacesGet_0();
case 1310553923: return bem_ntypesGet_0();
case 907513582: return bem_singleCCGetDirect_0();
case 2146521070: return bem_doEmitGet_0();
case 2040840927: return bem_parseGet_0();
case -176083023: return bem_exeNameGetDirect_0();
case 393276323: return bem_parseGetDirect_0();
case 1997197826: return bem_deployUsedLibrariesGet_0();
case -1723272481: return bem_emitLangsGetDirect_0();
case -638848724: return bem_deployPathGetDirect_0();
case -1225303157: return bem_closeLibrariesStrGetDirect_0();
case -1665940267: return bem_deployFilesToGet_0();
case -859356113: return bem_codeGet_0();
case -653615460: return bem_fieldIteratorGet_0();
case 346974656: return bem_printAllAstGetDirect_0();
case -1902580501: return bem_emitFileHeaderGetDirect_0();
case 1379863885: return bem_includePathGetDirect_0();
case -1433875934: return bem_emitLangsGet_0();
case 1862027354: return bem_parseEmitCompileTimeGetDirect_0();
case 525857445: return bem_makeArgsGetDirect_0();
case -1901854496: return bem_builtGet_0();
case -758572681: return bem_deployLibraryGetDirect_0();
case -228391365: return bem_saveIdsGet_0();
case 298491750: return bem_extLibsGet_0();
case -796797306: return bem_printAstGet_0();
case 1214467743: return bem_emitFlagsGetDirect_0();
case 290904295: return bem_sharedEmitterGet_0();
case 1193903370: return bem_prepMakeGetDirect_0();
case -1540268445: return bem_estrGetDirect_0();
case -196193287: return bem_deployUsedLibrariesGetDirect_0();
case -1515515049: return bem_ccObjArgsGet_0();
case -1696985823: return bem_readBufferGet_0();
case 1757897696: return bem_emitterGet_0();
case -425109389: return bem_printPlacesGetDirect_0();
case 584319597: return bem_serializeContents_0();
case -872752245: return bem_toBuildGetDirect_0();
case -1498642357: return bem_doEmitGetDirect_0();
case 1154111609: return bem_serializeToString_0();
case 2145390056: return bem_ownProcessGet_0();
case 845843737: return bem_copy_0();
case 684803821: return bem_libNameGetDirect_0();
case 1601218778: return bem_makeNameGet_0();
case 746295924: return bem_deployLibraryGet_0();
case -1367904922: return bem_twtokGetDirect_0();
case -780240930: return bem_initLibsGet_0();
case 866670678: return bem_paramsGetDirect_0();
case -835256918: return bem_deserializeClassNameGet_0();
case -397614617: return bem_emitDebugGetDirect_0();
case 1110616001: return bem_platformGet_0();
case 1063995011: return bem_nlGetDirect_0();
case 2138594797: return bem_doWhat_0();
case 936108049: return bem_fieldNamesGet_0();
case 1941020361: return bem_makeGetDirect_0();
case -45870993: return bem_hashGet_0();
case 754626550: return bem_loadSynsGet_0();
case 1315167107: return bem_putLineNumbersInTraceGet_0();
case 926297895: return bem_compilerProfileGet_0();
case 1862086102: return bem_newlineGetDirect_0();
case 2010440786: return bem_buildSucceededGetDirect_0();
case 324544151: return bem_compilerGetDirect_0();
case -850716057: return bem_emitDataGet_0();
case 396991554: return bem_emitLibraryGet_0();
case 408608464: return bem_putLineNumbersInTraceGetDirect_0();
case 1639062936: return bem_create_0();
case 749114454: return bem_usedLibrarysGetDirect_0();
case 339379977: return bem_buildMessageGet_0();
case -1329932393: return bem_go_0();
case 931747255: return bem_extLibsGetDirect_0();
case 1042227348: return bem_print_0();
case 534019556: return bem_makeGet_0();
case 1300676841: return bem_emitCommonGetDirect_0();
case -1888802907: return bem_deployFilesFromGetDirect_0();
case -436494897: return bem_singleCCGet_0();
case 899219113: return bem_extLinkObjectsGet_0();
case -767869188: return bem_sharedEmitterGetDirect_0();
case 434703584: return bem_many_0();
case 1750758896: return bem_printAstElementsGetDirect_0();
case 1473032888: return bem_parseEmitCompileTimeGet_0();
case 110861615: return bem_emitDataGetDirect_0();
case 1045229932: return bem_initLibsGetDirect_0();
case -2143804874: return bem_deployFilesToGetDirect_0();
case 718482160: return bem_runGetDirect_0();
case 1098597291: return bem_emitPathGet_0();
case 376367511: return bem_toString_0();
case -1060968310: return bem_runArgsGet_0();
case -530633488: return bem_startTimeGetDirect_0();
case -1443481112: return bem_buildMessageGetDirect_0();
case 1398396645: return bem_fromFileGetDirect_0();
case 1811937928: return bem_saveIdsGetDirect_0();
case -579684448: return bem_saveSynsGet_0();
case 1173227505: return bem_once_0();
case -1984972348: return bem_printAstGetDirect_0();
case 1453828591: return bem_main_0();
case 935403849: return bem_linkLibArgsGetDirect_0();
case 745462950: return bem_emitFlagsGet_0();
case -1304661937: return bem_genOnlyGetDirect_0();
case -1710621873: return bem_mainNameGetDirect_0();
case -1788326649: return bem_iteratorGet_0();
case 74789265: return bem_emitCs_0();
case 1254228006: return bem_argsGet_0();
case 1979629115: return bem_closeLibrariesStrGet_0();
case 542454679: return bem_tagGet_0();
case -454529880: return bem_deployFilesFromGet_0();
case 1861716570: return bem_saveSynsGetDirect_0();
case 688428577: return bem_runArgsGetDirect_0();
case -1124047782: return bem_lctokGetDirect_0();
case 695019909: return bem_new_0();
case -619675985: return bem_outputPlatformGetDirect_0();
case -1072203201: return bem_parseTimeGetDirect_0();
case 2073348642: return bem_emitDebugGet_0();
case -1206807373: return bem_echo_0();
case -1451555458: return bem_paramsGet_0();
case -808273800: return bem_extIncludesGetDirect_0();
case 166943161: return bem_readBufferGetDirect_0();
case 409396413: return bem_buildSucceededGet_0();
case -1756292910: return bem_emitPathGetDirect_0();
case 311934667: return bem_emitFileHeaderGet_0();
case -800555869: return bem_nlGet_0();
case -104206199: return bem_parseEmitTimeGet_0();
case 1718619428: return bem_genOnlyGet_0();
case -1139964354: return bem_linkLibArgsGet_0();
case 244486831: return bem_buildPathGet_0();
case -602209381: return bem_ccObjArgsGetDirect_0();
case 15417257: return bem_emitLibraryGetDirect_0();
case 385937094: return bem_estrGet_0();
case -207238538: return bem_usedLibrarysStrGet_0();
case 444323894: return bem_parseTimeGet_0();
case -122308526: return bem_constantsGet_0();
case -1874048994: return bem_startTimeGet_0();
case 899339354: return bem_closeLibrariesGet_0();
case 40319586: return bem_runGet_0();
case -967613087: return bem_mainNameGet_0();
case -921579981: return bem_compilerProfileGetDirect_0();
case -1578965235: return bem_makeNameGetDirect_0();
case 179786648: return bem_printAstElementsGet_0();
case 435677300: return bem_usedLibrarysStrGetDirect_0();
case 1482395335: return bem_config_0();
case -17905577: return bem_toBuildGet_0();
case -1311092427: return bem_libNameGet_0();
case 672102630: return bem_emitCommonGet_0();
case -867540373: return bem_sourceFileNameGet_0();
case 797341755: return bem_usedLibrarysGet_0();
case -1114701471: return bem_printStepsGetDirect_0();
case 776944709: return bem_prepMakeGet_0();
case 1555545834: return bem_buildPathGetDirect_0();
case -1344096516: return bem_extLinkObjectsGetDirect_0();
case -1352987253: return bem_parseEmitTimeGetDirect_0();
case -1244778963: return bem_setClassesToWrite_0();
case 959864550: return bem_lctokGet_0();
case 102068176: return bem_printAllAstGet_0();
case -831443384: return bem_compilerGet_0();
case -1748612026: return bem_fromFileGet_0();
case 809451444: return bem_platformGetDirect_0();
case -1866675020: return bem_includePathGet_0();
case 1479115170: return bem_outputPlatformGet_0();
case 1495383112: return bem_argsGetDirect_0();
case -1685376203: return bem_constantsGetDirect_0();
case -102112748: return bem_printStepsGet_0();
case 702386781: return bem_serializationIteratorGet_0();
case -1700462219: return bem_extIncludesGet_0();
case -965329238: return bem_exeNameGet_0();
case -2063692354: return bem_toAny_0();
case -2052057071: return bem_newlineGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 424179892: return bem_printAstSet_1(bevd_0);
case 1880919458: return bem_emitCommonSetDirect_1(bevd_0);
case 151210142: return bem_deployUsedLibrariesSet_1(bevd_0);
case -770921502: return bem_emitFlagsSetDirect_1(bevd_0);
case -69422819: return bem_saveIdsSetDirect_1(bevd_0);
case -1337207122: return bem_exeNameSet_1(bevd_0);
case 1914827442: return bem_newlineSet_1(bevd_0);
case -1010831754: return bem_singleCCSetDirect_1(bevd_0);
case 1823487512: return bem_buildSucceededSet_1(bevd_0);
case 1443898877: return bem_makeNameSetDirect_1(bevd_0);
case -2103943992: return bem_buildSyns_1(bevd_0);
case 802499892: return bem_initLibsSetDirect_1(bevd_0);
case -963237783: return bem_ccObjArgsSet_1(bevd_0);
case 585390927: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1438256358: return bem_otherType_1(bevd_0);
case 1409524087: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -1947510172: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case -1332450289: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -2070336989: return bem_emitFileHeaderSet_1(bevd_0);
case 982102662: return bem_runSetDirect_1(bevd_0);
case 893723594: return bem_newlineSetDirect_1(bevd_0);
case 1461707552: return bem_extLibsSet_1(bevd_0);
case -1380509624: return bem_paramsSet_1(bevd_0);
case -1569160884: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 81592137: return bem_includePathSetDirect_1(bevd_0);
case 1078607517: return bem_builtSetDirect_1(bevd_0);
case 1231336039: return bem_sharedEmitterSet_1(bevd_0);
case 1812748555: return bem_ntypesSetDirect_1(bevd_0);
case 625988512: return bem_prepMakeSetDirect_1(bevd_0);
case -287321460: return bem_twtokSetDirect_1(bevd_0);
case -1990764599: return bem_readBufferSet_1(bevd_0);
case 291628607: return bem_deployPathSetDirect_1(bevd_0);
case 1063294560: return bem_lctokSetDirect_1(bevd_0);
case -1976110795: return bem_extIncludesSet_1(bevd_0);
case -1928648657: return bem_printStepsSet_1(bevd_0);
case -1601718042: return bem_emitFileHeaderSetDirect_1(bevd_0);
case 1689281313: return bem_defined_1(bevd_0);
case 10153204: return bem_mainNameSetDirect_1(bevd_0);
case -1031257179: return bem_closeLibrariesSet_1(bevd_0);
case -1914391932: return bem_exeNameSetDirect_1(bevd_0);
case 1919682394: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case 226576676: return bem_builtSet_1(bevd_0);
case 35443844: return bem_usedLibrarysSet_1(bevd_0);
case 1576357694: return bem_emitFlagsSet_1(bevd_0);
case 768823343: return bem_ownProcessSet_1(bevd_0);
case 1338888743: return bem_printAstElementsSet_1(bevd_0);
case 2140687501: return bem_estrSetDirect_1(bevd_0);
case -2037797273: return bem_parseEmitTimeSet_1(bevd_0);
case 10451052: return bem_printStepsSetDirect_1(bevd_0);
case -973184692: return bem_runArgsSetDirect_1(bevd_0);
case -400620640: return bem_usedLibrarysSetDirect_1(bevd_0);
case -226317721: return bem_paramsSetDirect_1(bevd_0);
case 878931993: return bem_startTimeSetDirect_1(bevd_0);
case -231733819: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case -1748101546: return bem_outputPlatformSetDirect_1(bevd_0);
case 817352651: return bem_emitDebugSet_1(bevd_0);
case -1520379083: return bem_libNameSetDirect_1(bevd_0);
case -1719406507: return bem_compilerProfileSet_1(bevd_0);
case 699166467: return bem_sameClass_1(bevd_0);
case -1633172465: return bem_ownProcessSetDirect_1(bevd_0);
case 1525044501: return bem_usedLibrarysStrSet_1(bevd_0);
case 471926371: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 613129413: return bem_platformSetDirect_1(bevd_0);
case -2102241417: return bem_linkLibArgsSetDirect_1(bevd_0);
case 1893506308: return bem_buildMessageSet_1(bevd_0);
case 69964590: return bem_makeArgsSetDirect_1(bevd_0);
case -671242318: return bem_deployPathSet_1(bevd_0);
case -671896844: return bem_closeLibrariesStrSet_1(bevd_0);
case 490735400: return bem_platformSet_1(bevd_0);
case -903554223: return bem_compilerProfileSetDirect_1(bevd_0);
case 3512025: return bem_buildPathSet_1(bevd_0);
case -1640186169: return bem_parseSet_1(bevd_0);
case 1817971108: return bem_runSet_1(bevd_0);
case -1622909602: return bem_extLinkObjectsSet_1(bevd_0);
case 327419819: return bem_makeNameSet_1(bevd_0);
case 1688223793: return bem_constantsSet_1(bevd_0);
case 1984909948: return bem_makeArgsSet_1(bevd_0);
case 938644139: return bem_parseTimeSetDirect_1(bevd_0);
case -759627734: return bem_deployFilesToSetDirect_1(bevd_0);
case 1966905973: return bem_doEmitSet_1(bevd_0);
case 671751193: return bem_nlSetDirect_1(bevd_0);
case -963734719: return bem_emitPathSet_1(bevd_0);
case 1882843374: return bem_fromFileSetDirect_1(bevd_0);
case -1253948557: return bem_otherClass_1(bevd_0);
case -1110332178: return bem_deployLibrarySetDirect_1(bevd_0);
case -214021709: return bem_readBufferSetDirect_1(bevd_0);
case -303443079: return bem_printAstSetDirect_1(bevd_0);
case -984141321: return bem_deployLibrarySet_1(bevd_0);
case 804459525: return bem_constantsSetDirect_1(bevd_0);
case 1123737531: return bem_loadSynsSetDirect_1(bevd_0);
case -1253472481: return bem_copyTo_1(bevd_0);
case 1738623736: return bem_sameType_1(bevd_0);
case 1195528693: return bem_makeSet_1(bevd_0);
case 1227823618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1230694520: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -1567325125: return bem_prepMakeSet_1(bevd_0);
case -893978670: return bem_doEmitSetDirect_1(bevd_0);
case 71032029: return bem_emitLangsSet_1(bevd_0);
case 1620192557: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case -1597571228: return bem_fromFileSet_1(bevd_0);
case 2071553731: return bem_emitCommonSet_1(bevd_0);
case -2120328032: return bem_makeSetDirect_1(bevd_0);
case 803054435: return bem_parseEmitTimeSetDirect_1(bevd_0);
case 1072743866: return bem_saveIdsSet_1(bevd_0);
case 1541004733: return bem_emitPathSetDirect_1(bevd_0);
case 254195874: return bem_buildPathSetDirect_1(bevd_0);
case 525628634: return bem_startTimeSet_1(bevd_0);
case -1176335178: return bem_loadSynsSet_1(bevd_0);
case -1558551223: return bem_nlSet_1(bevd_0);
case 365624395: return bem_getSynNp_1(bevd_0);
case -850460796: return bem_genOnlySet_1(bevd_0);
case -230620739: return bem_parseSetDirect_1(bevd_0);
case -1289044860: return bem_estrSet_1(bevd_0);
case 652359368: return bem_libNameSet_1(bevd_0);
case -1407279152: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -462709317: return bem_genOnlySetDirect_1(bevd_0);
case -1091093866: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -900824944: return bem_parseTimeSet_1(bevd_0);
case -1569901537: return bem_compilerSet_1(bevd_0);
case 604219486: return bem_undefined_1(bevd_0);
case -61281094: return bem_closeLibrariesSetDirect_1(bevd_0);
case -886160285: return bem_notEquals_1(bevd_0);
case 142440277: return bem_argsSetDirect_1(bevd_0);
case 814961633: return bem_toBuildSet_1(bevd_0);
case -2039814255: return bem_sharedEmitterSetDirect_1(bevd_0);
case -2089357858: return bem_emitLangsSetDirect_1(bevd_0);
case 1326560556: return bem_codeSetDirect_1(bevd_0);
case -670346435: return bem_sameObject_1(bevd_0);
case -1804080941: return bem_compilerSetDirect_1(bevd_0);
case 772465863: return bem_buildSucceededSetDirect_1(bevd_0);
case -2031145791: return bem_def_1(bevd_0);
case 1088848149: return bem_saveSynsSet_1(bevd_0);
case 1551474232: return bem_toBuildSetDirect_1(bevd_0);
case -1685387580: return bem_mainNameSet_1(bevd_0);
case -2130755695: return bem_equals_1(bevd_0);
case -671092537: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -632339273: return bem_printPlacesSet_1(bevd_0);
case -343214264: return bem_deployFilesFromSetDirect_1(bevd_0);
case -10292121: return bem_runArgsSet_1(bevd_0);
case 1876469286: return bem_saveSynsSetDirect_1(bevd_0);
case 436036984: return bem_emitLibrarySet_1(bevd_0);
case -789067853: return bem_deployFilesToSet_1(bevd_0);
case 1911566916: return bem_outputPlatformSet_1(bevd_0);
case 1263388506: return bem_lctokSet_1(bevd_0);
case 392776539: return bem_emitDebugSetDirect_1(bevd_0);
case 1862918260: return bem_ccObjArgsSetDirect_1(bevd_0);
case -1386305284: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1188189857: return bem_printAstElementsSetDirect_1(bevd_0);
case -442473713: return bem_initLibsSet_1(bevd_0);
case 88791429: return bem_doParse_1(bevd_0);
case 1835124372: return bem_printAllAstSet_1(bevd_0);
case 1861159474: return bem_extLibsSetDirect_1(bevd_0);
case -1213984578: return bem_ntypesSet_1(bevd_0);
case 2072925280: return bem_linkLibArgsSet_1(bevd_0);
case 2065328487: return bem_singleCCSet_1(bevd_0);
case 1227703194: return bem_includePathSet_1(bevd_0);
case 98184381: return bem_extIncludesSetDirect_1(bevd_0);
case 475266617: return bem_emitDataSet_1(bevd_0);
case 179352881: return bem_printAllAstSetDirect_1(bevd_0);
case 153229390: return bem_emitLibrarySetDirect_1(bevd_0);
case 301362299: return bem_undef_1(bevd_0);
case 625011021: return bem_emitDataSetDirect_1(bevd_0);
case -913467557: return bem_printPlacesSetDirect_1(bevd_0);
case 462588756: return bem_argsSet_1(bevd_0);
case -1876945665: return bem_codeSet_1(bevd_0);
case 1003126232: return bem_buildMessageSetDirect_1(bevd_0);
case 1804470577: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -1588938967: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case -491936841: return bem_twtokSet_1(bevd_0);
case -749156250: return bem_deployFilesFromSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -245478473: return bem_buildLiteral_2(bevd_0, bevd_1);
case 1353806938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 167635781: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1390495691: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1588508948: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 39825618: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1408048401: return bem_getSyn_2(bevd_0, bevd_1);
case 1897876712: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 1092172708: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1229766114: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
