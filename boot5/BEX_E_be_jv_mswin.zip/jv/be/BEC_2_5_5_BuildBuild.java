package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_singleCC = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevp_saveIds = be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 99 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 117 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 117 */
 else  /* Line: 117 */ {
break;
} /* Line: 117 */
} /* Line: 117 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try  /* Line: 127 */ {
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 130 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(-1370488335);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 135 */
if (bevp_printSteps.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 137 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 138 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(823080247);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1305486032, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 144 */ {
} /* Line: 144 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 155 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(414440845);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 158 */
} /* Line: 156 */
 else  /* Line: 155 */ {
break;
} /* Line: 155 */
} /* Line: 155 */
} /* Line: 155 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 164 */
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 168 */
 else  /* Line: 169 */ {
bevp_exeName = bevp_libName;
} /* Line: 170 */
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(823080247);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 188 */
bevt_61_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 192 */
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 196 */
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 200 */
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 204 */
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 208 */
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 212 */
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 216 */
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 220 */
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(1333064864);
} /* Line: 224 */
bevt_79_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevp_runArgs = bevp_runArgs.bemd_0(1333064864);
} /* Line: 228 */
 else  /* Line: 229 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 230 */
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 238 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 239 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_91_tmpany_phold).bevi_bool) /* Line: 239 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 240 */
 else  /* Line: 239 */ {
break;
} /* Line: 239 */
} /* Line: 239 */
} /* Line: 239 */
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitLangs = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevp_emitFlags = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_100_tmpany_phold = bevp_params.bem_get_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_100_tmpany_phold.bem_firstGet_0();
bevt_104_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_59));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bem_add_1(bevp_makeName);
bevt_109_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_109_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_62));
} /* Line: 263 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_platform.bemd_0(823080247);
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_114_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_111_tmpany_phold);
if (bevl_platformSources == null) {
bevt_115_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_115_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_116_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 272 */
bevt_118_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_117_tmpany_phold = bevl_outLang.bem_add_1(bevt_118_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_117_tmpany_phold);
if (bevl_langSources == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_120_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 277 */
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_121_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_121_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_122_tmpany_phold = bevt_2_tmpany_loop.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 281 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(414440845);
bevt_123_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_123_tmpany_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(1138269512);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_125_tmpany_phold = bevt_126_tmpany_phold.bem_existsGet_0();
if (bevt_125_tmpany_phold.bevi_bool) {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_124_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 289 */ {
bevt_127_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_127_tmpany_phold.bem_makeDirs_0();
} /* Line: 290 */
if (bevp_emitFileHeader == null) {
bevt_128_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_128_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevt_129_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_129_tmpany_phold.bem_readerGet_0();
bevt_130_tmpany_phold = bevl_emr.bemd_0(-1195835537);
bevp_emitFileHeader = bevt_130_tmpany_phold.bemd_0(1705864292);
bevl_emr.bemd_0(-593229028);
} /* Line: 295 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(305850503, bevp_nl);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(305850503, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(305850503, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(305850503, bevp_nl);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(305850503, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(305850503, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_clnode = bevl_ci.bemd_0(414440845);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(459531437);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1797267240);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(459531437);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-763395765);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1370488335);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(459531437);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-763395765);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-1370488335);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(459531437);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-763395765);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1370488335);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 322 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 320 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 327 */ {
bevl_clnode = bevl_ci.bemd_0(414440845);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(459531437);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(459531437);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(-763395765);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-1370488335);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(-593822741, bevt_26_tmpany_phold);
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 340 */ {
return bevp_emitCommon;
} /* Line: 341 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 348 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 348 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 354 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 355 */
 else  /* Line: 356 */ {
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_8_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 357 */
} /* Line: 348 */
} /* Line: 348 */
return bevp_emitCommon;
} /* Line: 359 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(-1195835537);
bevt_5_tmpany_phold = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 383 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 383 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 384 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 383 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 391 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 392 */
} /* Line: 391 */
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(674241091);
while (true)
 /* Line: 397 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 397 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(414440845);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 401 */
} /* Line: 398 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(674241091);
while (true)
 /* Line: 404 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 404 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(414440845);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-905609052);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 409 */
} /* Line: 405 */
 else  /* Line: 404 */ {
break;
} /* Line: 404 */
} /* Line: 404 */
if (bevp_parse.bevi_bool) /* Line: 412 */ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 415 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 415 */ {
bevl_tb = bevl_i.bemd_0(414440845);
bevt_20_tmpany_phold = bevl_tb.bemd_0(-1370488335);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 418 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(-1370488335);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 420 */
} /* Line: 418 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bem_buildSyns_1(bevl_em);
} /* Line: 423 */
bevt_23_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_26_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 438 */
if (bevp_doEmit.bevi_bool) /* Line: 440 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-998541071);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 444 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 444 */ {
bevl_clnode = bevl_ci.bemd_0(414440845);
bevl_em.bemd_1(-206338131, bevl_clnode);
} /* Line: 446 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
bevl_em.bemd_0(909484640);
bevl_em.bemd_0(1035433184);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 450 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 450 */ {
bevl_clnode = bevl_ci.bemd_0(414440845);
bevl_em.bemd_1(1532334013, bevl_clnode);
} /* Line: 452 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
} /* Line: 450 */
bevt_44_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 458 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 461 */ {
bevl_em.bemd_1(1118850489, bevp_deployLibrary);
} /* Line: 463 */
if (bevp_make.bevi_bool) /* Line: 466 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 467 */ {
bevl_em.bemd_1(-2096975336, bevp_deployLibrary);
bevl_em.bemd_1(2030204201, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 470 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 471 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(-998541071);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(40947689);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(-253693894);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(2049722943);
bevl_cpTo.bemd_1(246222310, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(1446337319);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-1691899713);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 475 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(1446337319);
bevt_58_tmpany_phold.bemd_0(857344853);
} /* Line: 476 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(1446337319);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-1691899713);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-78314766);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(1446337319);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(1446337319);
bevl_em.bemd_2(821171804, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 479 */
} /* Line: 478 */
 else  /* Line: 471 */ {
break;
} /* Line: 471 */
} /* Line: 471 */
} /* Line: 471 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 486 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 486 */
 else  /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 486 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(414440845);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(414440845);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(1446337319);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(-1691899713);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 490 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(1446337319);
bevt_76_tmpany_phold.bemd_0(857344853);
} /* Line: 491 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(1446337319);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(-1691899713);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(-78314766);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 493 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(1446337319);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(1446337319);
bevl_em.bemd_2(821171804, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 494 */
} /* Line: 493 */
 else  /* Line: 486 */ {
break;
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 467 */
bevt_83_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 502 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 504 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 505 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 507 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 508 */
if (bevp_run.bevi_bool) /* Line: 511 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(165719896, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 515 */
bevt_98_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 521 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 521 */ {
bevl_kls = bevl_ci.bemd_0(414440845);
bevt_2_tmpany_phold = bevl_kls.bemd_0(459531437);
bevt_2_tmpany_phold.bemd_1(1910409322, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1910409322, bevp_libName);
} /* Line: 525 */
 else  /* Line: 521 */ {
break;
} /* Line: 521 */
} /* Line: 521 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 527 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 527 */ {
bevl_kls = bevl_ci.bemd_0(414440845);
bevt_5_tmpany_phold = bevl_kls.bemd_0(459531437);
bevl_syn = bevt_5_tmpany_phold.bemd_0(1949882798);
bevl_syn.bemd_2(1806931984, this, bevl_kls);
bevl_syn.bemd_1(503670083, this);
} /* Line: 531 */
 else  /* Line: 527 */ {
break;
} /* Line: 527 */
} /* Line: 527 */
bevt_6_tmpany_phold = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(459531437);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1949882798);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 537 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(459531437);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1949882798);
return bevt_3_tmpany_phold;
} /* Line: 538 */
bevt_5_tmpany_phold = beva_klass.bemd_0(459531437);
bevt_5_tmpany_phold.bemd_1(1910409322, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(459531437);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(616658779);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 541 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 542 */
 else  /* Line: 543 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(459531437);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(616658779);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1370488335);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 546 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(459531437);
bevt_14_tmpany_phold.bemd_1(1910409322, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 548 */
 else  /* Line: 549 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(459531437);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(616658779);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 552 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 554 */
bevt_17_tmpany_phold = beva_klass.bemd_0(459531437);
bevt_17_tmpany_phold.bemd_1(62365291, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(459531437);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-763395765);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1370488335);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(-1370488335);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 564 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 565 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(-764593030, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 580 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 581 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 594 */ {
if (bevp_printSteps.bevi_bool) /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 595 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 595 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 595 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_5_tmpany_phold = beva_toParse.bemd_0(-1370488335);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 596 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(1446337319);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(935438605);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1195835537);
bevl_src = bevt_6_tmpany_phold.bemd_1(1564787131, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(1446337319);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(935438605);
bevt_9_tmpany_phold.bemd_0(-593229028);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 605 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 606 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(-1831771374);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 609 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_14_tmpany_phold);
} /* Line: 611 */
if (bevp_printSteps.bevi_bool) /* Line: 614 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 615 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-281099588, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 618 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_18_tmpany_phold);
} /* Line: 620 */
if (bevp_printSteps.bevi_bool) /* Line: 622 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 623 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-281099588, bevt_20_tmpany_phold);
bevl_trans.bemd_0(-156642215);
if (bevp_printAllAst.bevi_bool) /* Line: 628 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_22_tmpany_phold);
} /* Line: 630 */
if (bevp_printSteps.bevi_bool) /* Line: 633 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 634 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-281099588, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 637 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_26_tmpany_phold);
} /* Line: 639 */
if (bevp_printSteps.bevi_bool) /* Line: 642 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 643 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-281099588, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 646 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_30_tmpany_phold);
} /* Line: 648 */
if (bevp_printSteps.bevi_bool) /* Line: 651 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 652 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-281099588, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 655 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_34_tmpany_phold);
} /* Line: 657 */
if (bevp_printSteps.bevi_bool) /* Line: 660 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 661 */
bevt_36_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-281099588, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 664 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_38_tmpany_phold);
} /* Line: 666 */
if (bevp_printSteps.bevi_bool) /* Line: 669 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 670 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-281099588, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 673 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_42_tmpany_phold);
} /* Line: 675 */
if (bevp_printSteps.bevi_bool) /* Line: 678 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 679 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-281099588, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 682 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_46_tmpany_phold);
} /* Line: 684 */
if (bevp_printSteps.bevi_bool) /* Line: 687 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 688 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-281099588, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 691 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_50_tmpany_phold);
} /* Line: 693 */
if (bevp_printSteps.bevi_bool) /* Line: 695 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 696 */
bevt_52_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-281099588, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 699 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_54_tmpany_phold);
} /* Line: 701 */
if (bevp_printSteps.bevi_bool) /* Line: 704 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 706 */
bevt_57_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-281099588, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 709 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 709 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 709 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-281099588, bevt_59_tmpany_phold);
} /* Line: 711 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 713 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(747745848);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 713 */ {
bevl_clnode = bevl_ci.bemd_0(414440845);
bevl_tunode = bevl_clnode.bemd_0(-185901227);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(42122266, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(459531437);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1707169931);
bevl_ntt.bemd_1(-1548066875, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(-604438159, bevl_ntt);
bevl_clnode.bemd_0(857344853);
bevl_ntunode.bemd_1(1327762565, bevl_clnode);
bevl_ntunode.bemd_1(80661117, bevl_clnode);
} /* Line: 724 */
 else  /* Line: 713 */ {
break;
} /* Line: 713 */
} /* Line: 713 */
} /* Line: 713 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(-878208749);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(257272443);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 734 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 734 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(-604438159, bevt_2_tmpany_phold);
bevl_node.bemd_1(-2141612344, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(459531437);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1305486032, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 738 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 739 */
bevt_6_tmpany_phold = bevl_node.bemd_0(459531437);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(-640296056, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 741 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-1088724440, beva_parnode);
} /* Line: 743 */
} /* Line: 741 */
 else  /* Line: 734 */ {
break;
} /* Line: 734 */
} /* Line: 734 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(694682252, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(42122266, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(-604438159, bevl_nlnp);
bevl_nlnpn.bemd_1(80661117, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_112));
bevl_nlc.bemd_1(157860214, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1879822554, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(856197003, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(328395463, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-508733744, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(459531437);
bevl_nlc.bemd_1(928416689, bevt_11_tmpany_phold);
beva_node.bemd_1(1327762565, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(42122266, bevt_12_tmpany_phold);
beva_node.bemd_1(-604438159, bevl_nlc);
bevl_nlnpn.bemd_0(-702437759);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_113));
bevt_13_tmpany_phold = beva_tName.bemd_1(1305486032, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_114));
bevt_15_tmpany_phold = beva_tName.bemd_1(1305486032, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevl_pn = beva_node.bemd_0(504240799);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 775 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-1165174536);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(1305486032, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-1165174536);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1305486032, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 775 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 775 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 775 */ {
bevl_pn2 = bevl_pn.bemd_0(504240799);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-1165174536);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(-640296056, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-1165174536);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(-640296056, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-1165174536);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(-640296056, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-1165174536);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(-640296056, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(459531437);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(856850323);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(305850503, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(928416689, bevt_37_tmpany_phold);
bevl_pn.bemd_0(857344853);
} /* Line: 784 */
} /* Line: 777 */
} /* Line: 775 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public final BEC_2_4_6_TextString bem_mainNameGetDirect_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public final BEC_2_4_6_TextString bem_exeNameGetDirect_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_platformGetDirect_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public final BEC_2_4_6_TextString bem_nlGetDirect_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public final BEC_2_4_6_TextString bem_buildMessageGetDirect_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_includePathGetDirect_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_builtGetDirect_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printAstGetDirect_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_parseGetDirect_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_makeGetDirect_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_codeGetDirect_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public final BEC_2_4_6_TextString bem_estrGetDirect_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public final BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public final BEC_2_4_6_TextString bem_deployPathGetDirect_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_runGetDirect_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public final BEC_2_4_6_TextString bem_compilerGetDirect_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public final BEC_2_4_6_TextString bem_makeNameGetDirect_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public final BEC_2_4_6_TextString bem_makeArgsGetDirect_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public final BEC_2_4_6_TextString bem_readBufferGetDirect_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() throws Throwable {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 81, 87, 88, 89, 90, 91, 91, 98, 98, 98, 98, 0, 98, 98, 0, 0, 0, 0, 0, 99, 99, 101, 101, 105, 105, 105, 105, 109, 109, 110, 110, 110, 114, 115, 116, 116, 116, 116, 116, 117, 117, 117, 118, 117, 120, 124, 125, 126, 128, 129, 130, 132, 133, 134, 134, 135, 0, 0, 0, 138, 140, 144, 144, 144, 146, 151, 153, 154, 154, 154, 155, 155, 0, 155, 155, 156, 156, 156, 157, 158, 158, 163, 163, 163, 163, 164, 166, 166, 166, 167, 167, 168, 168, 168, 170, 172, 172, 172, 172, 172, 172, 173, 174, 174, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 182, 182, 184, 184, 184, 185, 185, 185, 186, 186, 187, 187, 188, 190, 190, 191, 191, 192, 194, 194, 195, 195, 196, 198, 198, 199, 199, 200, 202, 202, 203, 203, 204, 206, 206, 207, 207, 208, 210, 210, 211, 211, 212, 214, 214, 215, 215, 216, 218, 218, 219, 219, 220, 222, 222, 223, 223, 224, 226, 226, 227, 227, 228, 230, 232, 232, 232, 233, 233, 233, 234, 234, 235, 235, 236, 237, 237, 238, 238, 238, 238, 238, 0, 0, 0, 239, 0, 239, 239, 240, 243, 243, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 252, 253, 254, 255, 256, 257, 260, 260, 261, 263, 270, 270, 270, 270, 270, 271, 271, 272, 272, 275, 275, 275, 276, 276, 277, 277, 280, 281, 281, 0, 281, 281, 282, 282, 284, 285, 286, 288, 289, 289, 289, 289, 290, 290, 292, 292, 293, 293, 294, 294, 295, 301, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 304, 308, 309, 309, 309, 310, 311, 311, 311, 311, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 319, 319, 319, 319, 319, 320, 320, 321, 0, 321, 321, 322, 327, 327, 327, 328, 329, 329, 329, 329, 329, 329, 336, 336, 340, 340, 341, 346, 346, 347, 348, 348, 349, 350, 350, 351, 354, 354, 355, 357, 357, 357, 359, 361, 365, 367, 367, 367, 368, 368, 369, 369, 369, 370, 370, 371, 372, 372, 373, 373, 373, 374, 374, 374, 380, 380, 381, 382, 382, 383, 0, 383, 383, 384, 387, 388, 388, 389, 390, 392, 392, 392, 395, 397, 0, 397, 397, 398, 398, 398, 399, 400, 401, 404, 0, 404, 404, 405, 405, 405, 406, 407, 408, 409, 409, 414, 415, 415, 416, 418, 418, 419, 419, 420, 423, 426, 426, 426, 429, 429, 429, 431, 431, 432, 432, 433, 433, 433, 434, 434, 434, 435, 435, 435, 436, 436, 436, 437, 437, 437, 438, 438, 441, 442, 444, 444, 444, 445, 446, 448, 449, 450, 450, 450, 451, 452, 456, 456, 456, 457, 457, 458, 458, 458, 460, 460, 460, 463, 467, 467, 468, 469, 471, 0, 471, 471, 472, 472, 473, 473, 474, 474, 474, 475, 475, 476, 476, 478, 478, 478, 479, 479, 479, 483, 484, 486, 486, 0, 0, 0, 487, 487, 488, 488, 488, 488, 488, 488, 488, 488, 490, 490, 491, 491, 493, 493, 493, 494, 494, 494, 499, 499, 499, 501, 501, 502, 502, 502, 504, 504, 505, 505, 505, 507, 507, 508, 508, 508, 512, 512, 513, 514, 514, 514, 514, 514, 515, 517, 517, 521, 521, 521, 522, 523, 523, 524, 525, 527, 527, 527, 528, 529, 529, 530, 531, 533, 533, 537, 537, 537, 537, 538, 538, 538, 540, 540, 541, 541, 541, 541, 542, 544, 544, 544, 544, 544, 546, 546, 547, 547, 548, 552, 552, 552, 554, 556, 556, 557, 557, 557, 557, 558, 562, 563, 563, 564, 564, 565, 571, 571, 572, 573, 580, 580, 581, 583, 588, 589, 590, 591, 592, 593, 593, 0, 0, 0, 596, 596, 596, 596, 598, 600, 600, 600, 600, 601, 601, 601, 602, 606, 606, 608, 608, 610, 610, 611, 611, 615, 615, 617, 617, 619, 619, 620, 620, 623, 623, 626, 626, 627, 629, 629, 630, 630, 634, 634, 636, 636, 638, 638, 639, 639, 643, 643, 645, 645, 647, 647, 648, 648, 652, 652, 654, 654, 656, 656, 657, 657, 661, 661, 663, 663, 665, 665, 666, 666, 670, 670, 672, 672, 674, 674, 675, 675, 679, 679, 681, 681, 683, 683, 684, 684, 688, 688, 690, 690, 692, 692, 693, 693, 696, 696, 698, 698, 700, 700, 701, 701, 705, 705, 706, 706, 708, 708, 0, 0, 0, 710, 710, 711, 711, 713, 713, 713, 714, 716, 717, 718, 718, 719, 720, 720, 720, 721, 722, 723, 724, 730, 731, 732, 733, 733, 734, 734, 735, 736, 736, 737, 738, 738, 739, 741, 741, 742, 743, 750, 751, 753, 754, 754, 755, 756, 758, 759, 759, 760, 760, 761, 761, 762, 762, 763, 763, 764, 764, 766, 768, 768, 769, 771, 773, 773, 0, 773, 773, 0, 0, 774, 775, 775, 775, 775, 775, 0, 775, 775, 775, 0, 0, 0, 0, 0, 776, 777, 777, 0, 777, 777, 777, 777, 777, 777, 0, 0, 0, 777, 777, 777, 0, 0, 0, 777, 777, 777, 0, 0, 0, 0, 0, 783, 783, 783, 783, 784, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 292, 297, 298, 299, 301, 304, 305, 307, 310, 314, 317, 321, 324, 325, 327, 328, 334, 335, 336, 337, 344, 345, 346, 347, 348, 360, 361, 362, 363, 364, 365, 366, 367, 370, 375, 376, 377, 383, 391, 392, 393, 395, 396, 397, 401, 402, 403, 404, 405, 408, 412, 415, 419, 421, 427, 428, 429, 432, 575, 576, 577, 578, 583, 584, 585, 585, 588, 590, 591, 592, 597, 598, 599, 600, 608, 609, 610, 611, 613, 615, 616, 617, 618, 619, 621, 622, 623, 626, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 686, 687, 689, 690, 691, 696, 697, 699, 700, 701, 706, 707, 709, 710, 711, 716, 717, 719, 720, 721, 726, 727, 729, 730, 731, 736, 737, 739, 740, 741, 746, 747, 749, 750, 751, 756, 757, 759, 760, 761, 766, 767, 769, 770, 771, 776, 777, 779, 780, 781, 786, 787, 790, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 810, 811, 812, 817, 818, 821, 825, 828, 828, 831, 833, 834, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 879, 880, 883, 885, 886, 887, 888, 889, 890, 895, 896, 897, 899, 900, 901, 902, 907, 908, 909, 911, 912, 913, 913, 916, 918, 919, 920, 926, 927, 928, 929, 930, 931, 932, 937, 938, 939, 941, 946, 947, 948, 949, 950, 951, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 1016, 1017, 1018, 1021, 1023, 1024, 1025, 1026, 1027, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1043, 1044, 1044, 1047, 1049, 1050, 1057, 1058, 1059, 1060, 1061, 1062, 1067, 1068, 1068, 1071, 1073, 1074, 1087, 1088, 1091, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1109, 1110, 1124, 1129, 1130, 1132, 1137, 1138, 1139, 1140, 1142, 1145, 1146, 1148, 1151, 1152, 1154, 1157, 1158, 1159, 1163, 1165, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1324, 1325, 1326, 1327, 1332, 1333, 1333, 1336, 1338, 1339, 1346, 1347, 1352, 1353, 1354, 1356, 1357, 1358, 1361, 1362, 1362, 1365, 1367, 1368, 1369, 1374, 1375, 1376, 1377, 1384, 1384, 1387, 1389, 1390, 1391, 1396, 1397, 1398, 1399, 1400, 1401, 1409, 1410, 1413, 1415, 1416, 1417, 1419, 1420, 1421, 1428, 1430, 1431, 1432, 1433, 1434, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1463, 1464, 1465, 1466, 1469, 1471, 1472, 1478, 1479, 1480, 1481, 1484, 1486, 1487, 1494, 1495, 1496, 1497, 1502, 1503, 1504, 1505, 1507, 1508, 1509, 1511, 1514, 1519, 1520, 1521, 1523, 1523, 1526, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1539, 1540, 1542, 1543, 1544, 1546, 1547, 1548, 1556, 1557, 1560, 1562, 1564, 1567, 1571, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1587, 1588, 1590, 1591, 1592, 1594, 1595, 1596, 1605, 1606, 1607, 1608, 1613, 1614, 1615, 1616, 1618, 1623, 1624, 1625, 1626, 1628, 1633, 1634, 1635, 1636, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1649, 1650, 1663, 1664, 1667, 1669, 1670, 1671, 1672, 1673, 1679, 1680, 1683, 1685, 1686, 1687, 1688, 1689, 1695, 1696, 1724, 1725, 1726, 1731, 1732, 1733, 1734, 1736, 1737, 1738, 1739, 1740, 1745, 1746, 1749, 1750, 1751, 1752, 1753, 1754, 1759, 1760, 1761, 1762, 1765, 1766, 1767, 1769, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1785, 1786, 1787, 1788, 1793, 1794, 1796, 1797, 1798, 1799, 1803, 1808, 1809, 1811, 1890, 1891, 1892, 1893, 1894, 1895, 1896, 1899, 1903, 1906, 1910, 1911, 1912, 1913, 1915, 1916, 1917, 1918, 1919, 1920, 1921, 1922, 1923, 1925, 1926, 1928, 1929, 1931, 1932, 1933, 1934, 1937, 1938, 1940, 1941, 1943, 1944, 1945, 1946, 1949, 1950, 1952, 1953, 1954, 1956, 1957, 1958, 1959, 1962, 1963, 1965, 1966, 1968, 1969, 1970, 1971, 1974, 1975, 1977, 1978, 1980, 1981, 1982, 1983, 1986, 1987, 1989, 1990, 1992, 1993, 1994, 1995, 1998, 1999, 2001, 2002, 2004, 2005, 2006, 2007, 2010, 2011, 2013, 2014, 2016, 2017, 2018, 2019, 2022, 2023, 2025, 2026, 2028, 2029, 2030, 2031, 2034, 2035, 2037, 2038, 2040, 2041, 2042, 2043, 2046, 2047, 2049, 2050, 2052, 2053, 2054, 2055, 2058, 2059, 2060, 2061, 2063, 2064, 2066, 2070, 2073, 2077, 2078, 2079, 2080, 2082, 2083, 2086, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2122, 2123, 2124, 2125, 2126, 2127, 2130, 2132, 2133, 2134, 2135, 2136, 2137, 2139, 2141, 2142, 2144, 2145, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2228, 2231, 2232, 2234, 2237, 2241, 2242, 2247, 2248, 2249, 2250, 2252, 2255, 2256, 2257, 2259, 2262, 2266, 2269, 2273, 2276, 2277, 2282, 2283, 2286, 2287, 2288, 2290, 2291, 2292, 2294, 2297, 2301, 2304, 2305, 2306, 2308, 2311, 2315, 2318, 2319, 2320, 2322, 2325, 2329, 2332, 2335, 2339, 2340, 2341, 2342, 2343, 2350, 2353, 2356, 2360, 2364, 2367, 2370, 2374, 2378, 2381, 2384, 2388, 2392, 2395, 2398, 2402, 2406, 2409, 2412, 2416, 2420, 2423, 2426, 2430, 2434, 2437, 2440, 2444, 2448, 2451, 2454, 2458, 2462, 2465, 2468, 2472, 2476, 2479, 2482, 2486, 2490, 2493, 2496, 2500, 2504, 2507, 2510, 2514, 2518, 2521, 2524, 2528, 2532, 2535, 2538, 2542, 2546, 2549, 2552, 2556, 2560, 2563, 2566, 2570, 2574, 2577, 2580, 2584, 2588, 2591, 2594, 2598, 2602, 2605, 2608, 2612, 2616, 2619, 2622, 2626, 2630, 2633, 2636, 2640, 2644, 2647, 2650, 2654, 2658, 2661, 2664, 2668, 2672, 2675, 2678, 2682, 2686, 2689, 2692, 2696, 2700, 2703, 2706, 2710, 2714, 2717, 2720, 2724, 2728, 2731, 2734, 2738, 2742, 2745, 2748, 2752, 2756, 2759, 2762, 2766, 2770, 2773, 2776, 2780, 2784, 2787, 2790, 2794, 2798, 2801, 2804, 2808, 2812, 2815, 2818, 2822, 2826, 2829, 2832, 2836, 2840, 2843, 2846, 2850, 2854, 2857, 2860, 2864, 2868, 2871, 2874, 2878, 2882, 2885, 2888, 2892, 2896, 2899, 2902, 2906, 2910, 2913, 2916, 2920, 2924, 2927, 2930, 2934, 2938, 2941, 2944, 2948, 2952, 2955, 2958, 2962, 2966, 2969, 2972, 2976, 2980, 2983, 2986, 2990, 2994, 2997, 3000, 3004, 3008, 3011, 3014, 3018, 3022, 3025, 3028, 3032, 3036, 3039, 3042, 3046, 3050, 3053, 3056, 3060, 3064, 3067, 3070, 3074, 3078, 3081, 3084, 3088, 3092, 3095, 3098, 3102, 3106, 3109, 3112, 3116, 3120, 3123, 3126, 3130, 3134, 3137, 3140, 3144, 3148, 3151, 3154, 3158, 3162, 3165, 3168, 3172, 3176, 3179, 3182, 3186, 3190, 3193, 3196, 3200, 3204, 3207, 3210, 3214, 3218, 3221, 3224, 3228, 3232, 3235, 3238, 3242, 3246, 3249, 3252, 3256, 3260, 3263, 3266, 3270, 3274, 3277, 3280, 3284, 3288, 3291, 3294, 3298, 3302, 3305, 3308, 3312, 3316, 3319, 3322, 3326, 3330, 3333, 3336, 3340, 3344, 3347, 3350, 3354, 3358, 3361, 3365};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 51 253
new 0 51 253
assign 1 53 254
new 0 53 254
assign 1 54 255
new 0 54 255
assign 1 55 256
new 0 55 256
assign 1 56 257
new 0 56 257
assign 1 58 258
new 0 58 258
assign 1 59 259
new 0 59 259
assign 1 60 260
new 0 60 260
assign 1 61 261
new 0 61 261
assign 1 62 262
new 0 62 262
assign 1 63 263
new 0 63 263
assign 1 64 264
new 0 64 264
assign 1 68 265
new 0 68 265
assign 1 70 266
new 1 70 266
assign 1 71 267
ntypesGet 0 71 267
assign 1 72 268
twtokGet 0 72 268
assign 1 73 269
new 0 73 269
assign 1 73 270
new 1 73 270
assign 1 76 271
new 0 76 271
assign 1 79 272
new 0 79 272
assign 1 80 273
new 0 80 273
assign 1 81 274
new 0 81 274
assign 1 87 275
new 0 87 275
assign 1 88 276
new 0 88 276
assign 1 89 277
new 0 89 277
assign 1 90 278
new 0 90 278
assign 1 91 279
new 0 91 279
assign 1 91 280
new 1 91 280
assign 1 98 292
def 1 98 297
assign 1 98 298
new 0 98 298
assign 1 98 299
equals 1 98 299
assign 1 0 301
assign 1 98 304
new 0 98 304
assign 1 98 305
ends 1 98 305
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 0 317
assign 1 0 321
assign 1 99 324
new 0 99 324
return 1 99 325
assign 1 101 327
new 0 101 327
return 1 101 328
assign 1 105 334
new 0 105 334
assign 1 105 335
new 0 105 335
assign 1 105 336
swap 2 105 336
return 1 105 337
assign 1 109 344
new 0 109 344
assign 1 109 345
argsGet 0 109 345
assign 1 110 346
new 0 110 346
assign 1 110 347
main 1 110 347
exit 1 110 348
assign 1 114 360
assign 1 115 361
new 1 115 361
assign 1 116 362
new 0 116 362
assign 1 116 363
new 0 116 363
assign 1 116 364
get 2 116 364
assign 1 116 365
firstGet 0 116 365
assign 1 116 366
new 1 116 366
assign 1 117 367
new 0 117 367
assign 1 117 370
lesser 1 117 375
assign 1 118 376
go 0 118 376
incrementValue 0 117 377
return 1 120 383
assign 1 124 391
new 0 124 391
config 0 125 392
assign 1 126 393
new 0 126 393
assign 1 128 395
new 0 128 395
assign 1 129 396
doWhat 0 129 396
assign 1 130 397
new 0 130 397
assign 1 132 401
toString 0 132 401
assign 1 133 402
new 0 133 402
assign 1 134 403
new 0 134 403
assign 1 134 404
add 1 134 404
assign 1 135 405
new 0 135 405
assign 1 0 408
assign 1 0 412
assign 1 0 415
print 0 138 419
return 1 140 421
assign 1 144 427
nameGet 0 144 427
assign 1 144 428
new 0 144 428
assign 1 144 429
equals 1 144 429
return 1 146 432
assign 1 151 575
new 0 151 575
assign 1 153 576
new 0 153 576
assign 1 154 577
get 1 154 577
assign 1 154 578
def 1 154 583
assign 1 155 584
get 1 155 584
assign 1 155 585
iteratorGet 0 0 585
assign 1 155 588
hasNextGet 0 155 588
assign 1 155 590
nextGet 0 155 590
assign 1 156 591
has 1 156 591
assign 1 156 592
not 0 156 597
put 1 157 598
assign 1 158 599
new 1 158 599
addFile 1 158 600
assign 1 163 608
new 0 163 608
assign 1 163 609
nameGet 0 163 609
assign 1 163 610
new 0 163 610
assign 1 163 611
equals 1 163 611
preProcessorSet 1 164 613
assign 1 166 615
new 0 166 615
assign 1 166 616
get 1 166 616
assign 1 166 617
firstGet 0 166 617
assign 1 167 618
new 0 167 618
assign 1 167 619
has 1 167 619
assign 1 168 621
new 0 168 621
assign 1 168 622
get 1 168 622
assign 1 168 623
firstGet 0 168 623
assign 1 170 626
assign 1 172 628
new 0 172 628
assign 1 172 629
new 0 172 629
assign 1 172 630
get 2 172 630
assign 1 172 631
firstGet 0 172 631
assign 1 172 632
new 1 172 632
assign 1 172 633
pathGet 0 172 633
addStep 1 173 634
assign 1 174 635
new 0 174 635
addStep 1 174 636
assign 1 175 637
new 0 175 637
assign 1 175 638
new 0 175 638
assign 1 175 639
get 2 175 639
assign 1 175 640
firstGet 0 175 640
assign 1 175 641
new 1 175 641
assign 1 175 642
pathGet 0 175 642
assign 1 176 643
new 0 176 643
assign 1 176 644
new 0 176 644
assign 1 176 645
nameGet 0 176 645
assign 1 176 646
get 2 176 646
assign 1 176 647
firstGet 0 176 647
assign 1 176 648
new 1 176 648
assign 1 177 649
new 0 177 649
assign 1 177 650
nameGet 0 177 650
assign 1 177 651
get 2 177 651
assign 1 177 652
firstGet 0 177 652
assign 1 177 653
new 1 177 653
assign 1 178 654
new 0 178 654
assign 1 178 655
new 0 178 655
assign 1 178 656
get 2 178 656
assign 1 178 657
firstGet 0 178 657
assign 1 178 658
new 1 178 658
assign 1 179 659
new 0 179 659
assign 1 179 660
new 0 179 660
assign 1 179 661
get 2 179 661
assign 1 179 662
firstGet 0 179 662
assign 1 179 663
new 1 179 663
assign 1 180 664
new 0 180 664
assign 1 180 665
new 0 180 665
assign 1 180 666
get 2 180 666
assign 1 180 667
firstGet 0 180 667
assign 1 180 668
new 1 180 668
assign 1 181 669
new 0 181 669
assign 1 181 670
get 1 181 670
assign 1 182 671
new 0 182 671
assign 1 182 672
get 1 182 672
assign 1 184 673
new 0 184 673
assign 1 184 674
get 1 184 674
assign 1 184 675
firstGet 0 184 675
assign 1 185 676
new 0 185 676
assign 1 185 677
get 1 185 677
assign 1 185 678
firstGet 0 185 678
assign 1 186 679
new 0 186 679
assign 1 186 680
get 1 186 680
assign 1 187 681
undef 1 187 686
assign 1 188 687
new 0 188 687
assign 1 190 689
new 0 190 689
assign 1 190 690
get 1 190 690
assign 1 191 691
undef 1 191 696
assign 1 192 697
new 0 192 697
assign 1 194 699
new 0 194 699
assign 1 194 700
get 1 194 700
assign 1 195 701
undef 1 195 706
assign 1 196 707
new 0 196 707
assign 1 198 709
new 0 198 709
assign 1 198 710
get 1 198 710
assign 1 199 711
undef 1 199 716
assign 1 200 717
new 0 200 717
assign 1 202 719
new 0 202 719
assign 1 202 720
get 1 202 720
assign 1 203 721
undef 1 203 726
assign 1 204 727
new 0 204 727
assign 1 206 729
new 0 206 729
assign 1 206 730
get 1 206 730
assign 1 207 731
undef 1 207 736
assign 1 208 737
new 0 208 737
assign 1 210 739
new 0 210 739
assign 1 210 740
get 1 210 740
assign 1 211 741
undef 1 211 746
assign 1 212 747
new 0 212 747
assign 1 214 749
new 0 214 749
assign 1 214 750
get 1 214 750
assign 1 215 751
undef 1 215 756
assign 1 216 757
new 0 216 757
assign 1 218 759
new 0 218 759
assign 1 218 760
get 1 218 760
assign 1 219 761
undef 1 219 766
assign 1 220 767
new 0 220 767
assign 1 222 769
new 0 222 769
assign 1 222 770
get 1 222 770
assign 1 223 771
def 1 223 776
assign 1 224 777
firstGet 0 224 777
assign 1 226 779
new 0 226 779
assign 1 226 780
get 1 226 780
assign 1 227 781
def 1 227 786
assign 1 228 787
firstGet 0 228 787
assign 1 230 790
new 0 230 790
assign 1 232 792
new 0 232 792
assign 1 232 793
new 0 232 793
assign 1 232 794
isTrue 2 232 794
assign 1 233 795
new 0 233 795
assign 1 233 796
new 0 233 796
assign 1 233 797
isTrue 2 233 797
assign 1 234 798
new 0 234 798
assign 1 234 799
isTrue 1 234 799
assign 1 235 800
new 0 235 800
assign 1 235 801
isTrue 1 235 801
assign 1 236 802
new 0 236 802
assign 1 237 803
new 0 237 803
assign 1 237 804
get 1 237 804
assign 1 238 805
def 1 238 810
assign 1 238 811
isEmptyGet 0 238 811
assign 1 238 812
not 0 238 817
assign 1 0 818
assign 1 0 821
assign 1 0 825
assign 1 239 828
linkedListIteratorGet 0 0 828
assign 1 239 831
hasNextGet 0 239 831
assign 1 239 833
nextGet 0 239 833
put 1 240 834
assign 1 243 841
new 0 243 841
assign 1 243 842
isTrue 1 243 842
assign 1 244 843
new 0 244 843
assign 1 244 844
isTrue 1 244 844
assign 1 245 845
new 0 245 845
assign 1 245 846
isTrue 1 245 846
assign 1 246 847
new 0 246 847
assign 1 246 848
isTrue 1 246 848
assign 1 247 849
new 0 247 849
assign 1 247 850
new 0 247 850
assign 1 247 851
isTrue 2 247 851
assign 1 248 852
new 0 248 852
assign 1 248 853
get 1 248 853
assign 1 249 854
new 0 249 854
assign 1 249 855
get 1 249 855
assign 1 250 856
new 0 250 856
assign 1 250 857
new 0 250 857
assign 1 250 858
get 2 250 858
assign 1 250 859
firstGet 0 250 859
assign 1 251 860
new 0 251 860
assign 1 251 861
new 0 251 861
assign 1 251 862
get 2 251 862
assign 1 251 863
firstGet 0 251 863
assign 1 252 864
new 0 252 864
assign 1 252 865
add 1 252 865
assign 1 252 866
new 0 252 866
assign 1 252 867
get 2 252 867
assign 1 252 868
firstGet 0 252 868
assign 1 253 869
new 0 253 869
assign 1 254 870
new 0 254 870
assign 1 255 871
new 0 255 871
assign 1 256 872
new 0 256 872
assign 1 257 873
new 0 257 873
assign 1 260 874
def 1 260 879
assign 1 261 880
firstGet 0 261 880
assign 1 263 883
new 0 263 883
assign 1 270 885
new 0 270 885
assign 1 270 886
add 1 270 886
assign 1 270 887
nameGet 0 270 887
assign 1 270 888
add 1 270 888
assign 1 270 889
get 1 270 889
assign 1 271 890
def 1 271 895
assign 1 272 896
orderedGet 0 272 896
addAll 1 272 897
assign 1 275 899
new 0 275 899
assign 1 275 900
add 1 275 900
assign 1 275 901
get 1 275 901
assign 1 276 902
def 1 276 907
assign 1 277 908
orderedGet 0 277 908
addAll 1 277 909
assign 1 280 911
new 0 280 911
assign 1 281 912
orderedGet 0 281 912
assign 1 281 913
iteratorGet 0 0 913
assign 1 281 916
hasNextGet 0 281 916
assign 1 281 918
nextGet 0 281 918
assign 1 282 919
new 1 282 919
addValue 1 282 920
assign 1 284 926
newlineGet 0 284 926
assign 1 285 927
assign 1 286 928
new 1 286 928
assign 1 288 929
copy 0 288 929
assign 1 289 930
fileGet 0 289 930
assign 1 289 931
existsGet 0 289 931
assign 1 289 932
not 0 289 937
assign 1 290 938
fileGet 0 290 938
makeDirs 0 290 939
assign 1 292 941
def 1 292 946
assign 1 293 947
new 1 293 947
assign 1 293 948
readerGet 0 293 948
assign 1 294 949
open 0 294 949
assign 1 294 950
readString 0 294 950
close 0 295 951
assign 1 301 965
classNameGet 0 301 965
assign 1 302 966
add 1 302 966
assign 1 302 967
new 0 302 967
assign 1 302 968
add 1 302 968
assign 1 302 969
toString 0 302 969
assign 1 302 970
add 1 302 970
assign 1 303 971
add 1 303 971
assign 1 303 972
new 0 303 972
assign 1 303 973
add 1 303 973
assign 1 303 974
toString 0 303 974
assign 1 303 975
add 1 303 975
return 1 304 976
assign 1 308 1016
new 0 308 1016
assign 1 309 1017
classesGet 0 309 1017
assign 1 309 1018
valueIteratorGet 0 309 1018
assign 1 309 1021
hasNextGet 0 309 1021
assign 1 310 1023
nextGet 0 310 1023
assign 1 311 1024
shouldEmitGet 0 311 1024
assign 1 311 1025
heldGet 0 311 1025
assign 1 311 1026
fromFileGet 0 311 1026
assign 1 311 1027
has 1 311 1027
assign 1 312 1029
heldGet 0 312 1029
assign 1 312 1030
namepathGet 0 312 1030
assign 1 312 1031
toString 0 312 1031
put 1 312 1032
assign 1 313 1033
usedByGet 0 313 1033
assign 1 313 1034
heldGet 0 313 1034
assign 1 313 1035
namepathGet 0 313 1035
assign 1 313 1036
toString 0 313 1036
assign 1 313 1037
get 1 313 1037
assign 1 314 1038
def 1 314 1043
assign 1 315 1044
setIteratorGet 0 0 1044
assign 1 315 1047
hasNextGet 0 315 1047
assign 1 315 1049
nextGet 0 315 1049
put 1 316 1050
assign 1 319 1057
subClassesGet 0 319 1057
assign 1 319 1058
heldGet 0 319 1058
assign 1 319 1059
namepathGet 0 319 1059
assign 1 319 1060
toString 0 319 1060
assign 1 319 1061
get 1 319 1061
assign 1 320 1062
def 1 320 1067
assign 1 321 1068
setIteratorGet 0 0 1068
assign 1 321 1071
hasNextGet 0 321 1071
assign 1 321 1073
nextGet 0 321 1073
put 1 322 1074
assign 1 327 1087
classesGet 0 327 1087
assign 1 327 1088
valueIteratorGet 0 327 1088
assign 1 327 1091
hasNextGet 0 327 1091
assign 1 328 1093
nextGet 0 328 1093
assign 1 329 1094
heldGet 0 329 1094
assign 1 329 1095
heldGet 0 329 1095
assign 1 329 1096
namepathGet 0 329 1096
assign 1 329 1097
toString 0 329 1097
assign 1 329 1098
has 1 329 1098
shouldWriteSet 1 329 1099
assign 1 336 1109
new 0 336 1109
return 1 336 1110
assign 1 340 1124
def 1 340 1129
return 1 341 1130
assign 1 346 1132
def 1 346 1137
assign 1 347 1138
firstGet 0 347 1138
assign 1 348 1139
new 0 348 1139
assign 1 348 1140
equals 1 348 1140
assign 1 349 1142
new 1 349 1142
assign 1 350 1145
new 0 350 1145
assign 1 350 1146
equals 1 350 1146
assign 1 351 1148
new 1 351 1148
assign 1 354 1151
new 0 354 1151
assign 1 354 1152
equals 1 354 1152
assign 1 355 1154
new 1 355 1154
assign 1 357 1157
new 0 357 1157
assign 1 357 1158
new 1 357 1158
throw 1 357 1159
return 1 359 1163
return 1 361 1165
assign 1 365 1184
apNew 1 365 1184
assign 1 367 1185
new 0 367 1185
assign 1 367 1186
add 1 367 1186
print 0 367 1187
assign 1 368 1188
new 0 368 1188
assign 1 368 1189
now 0 368 1189
assign 1 369 1190
fileGet 0 369 1190
assign 1 369 1191
readerGet 0 369 1191
assign 1 369 1192
open 0 369 1192
assign 1 370 1193
new 0 370 1193
assign 1 370 1194
deserialize 1 370 1194
close 0 371 1195
assign 1 372 1196
synClassesGet 0 372 1196
addValue 1 372 1197
assign 1 373 1198
new 0 373 1198
assign 1 373 1199
now 0 373 1199
assign 1 373 1200
subtract 1 373 1200
assign 1 374 1201
new 0 374 1201
assign 1 374 1202
add 1 374 1202
print 0 374 1203
assign 1 380 1324
new 0 380 1324
assign 1 380 1325
now 0 380 1325
assign 1 381 1326
new 0 381 1326
assign 1 382 1327
def 1 382 1332
assign 1 383 1333
linkedListIteratorGet 0 0 1333
assign 1 383 1336
hasNextGet 0 383 1336
assign 1 383 1338
nextGet 0 383 1338
loadSyns 1 384 1339
assign 1 387 1346
emitterGet 0 387 1346
assign 1 388 1347
def 1 388 1352
assign 1 389 1353
new 4 389 1353
put 1 390 1354
assign 1 392 1356
new 0 392 1356
assign 1 392 1357
add 1 392 1357
print 0 392 1358
assign 1 395 1361
new 0 395 1361
assign 1 397 1362
iteratorGet 0 0 1362
assign 1 397 1365
hasNextGet 0 397 1365
assign 1 397 1367
nextGet 0 397 1367
assign 1 398 1368
has 1 398 1368
assign 1 398 1369
not 0 398 1374
put 1 399 1375
assign 1 400 1376
new 2 400 1376
addValue 1 401 1377
assign 1 404 1384
iteratorGet 0 0 1384
assign 1 404 1387
hasNextGet 0 404 1387
assign 1 404 1389
nextGet 0 404 1389
assign 1 405 1390
has 1 405 1390
assign 1 405 1391
not 0 405 1396
put 1 406 1397
assign 1 407 1398
new 2 407 1398
addValue 1 408 1399
assign 1 409 1400
libNameGet 0 409 1400
put 1 409 1401
assign 1 414 1409
new 0 414 1409
assign 1 415 1410
iteratorGet 0 415 1410
assign 1 415 1413
hasNextGet 0 415 1413
assign 1 416 1415
nextGet 0 416 1415
assign 1 418 1416
toString 0 418 1416
assign 1 418 1417
has 1 418 1417
assign 1 419 1419
toString 0 419 1419
put 1 419 1420
doParse 1 420 1421
buildSyns 1 423 1428
assign 1 426 1430
new 0 426 1430
assign 1 426 1431
now 0 426 1431
assign 1 426 1432
subtract 1 426 1432
assign 1 429 1433
emitCommonGet 0 429 1433
assign 1 429 1434
def 1 429 1439
assign 1 431 1440
new 0 431 1440
assign 1 431 1441
now 0 431 1441
assign 1 432 1442
emitCommonGet 0 432 1442
doEmit 0 432 1443
assign 1 433 1444
new 0 433 1444
assign 1 433 1445
now 0 433 1445
assign 1 433 1446
subtract 1 433 1446
assign 1 434 1447
new 0 434 1447
assign 1 434 1448
now 0 434 1448
assign 1 434 1449
subtract 1 434 1449
assign 1 435 1450
new 0 435 1450
assign 1 435 1451
add 1 435 1451
print 0 435 1452
assign 1 436 1453
new 0 436 1453
assign 1 436 1454
add 1 436 1454
print 0 436 1455
assign 1 437 1456
new 0 437 1456
assign 1 437 1457
add 1 437 1457
print 0 437 1458
assign 1 438 1459
new 0 438 1459
return 1 438 1460
setClassesToWrite 0 441 1463
libnameInfoGet 0 442 1464
assign 1 444 1465
classesGet 0 444 1465
assign 1 444 1466
valueIteratorGet 0 444 1466
assign 1 444 1469
hasNextGet 0 444 1469
assign 1 445 1471
nextGet 0 445 1471
doEmit 1 446 1472
emitMain 0 448 1478
emitCUInit 0 449 1479
assign 1 450 1480
classesGet 0 450 1480
assign 1 450 1481
valueIteratorGet 0 450 1481
assign 1 450 1484
hasNextGet 0 450 1484
assign 1 451 1486
nextGet 0 451 1486
emitSyn 1 452 1487
assign 1 456 1494
new 0 456 1494
assign 1 456 1495
now 0 456 1495
assign 1 456 1496
subtract 1 456 1496
assign 1 457 1497
def 1 457 1502
assign 1 458 1503
new 0 458 1503
assign 1 458 1504
add 1 458 1504
print 0 458 1505
assign 1 460 1507
new 0 460 1507
assign 1 460 1508
add 1 460 1508
print 0 460 1509
prepMake 1 463 1511
assign 1 467 1514
not 0 467 1519
make 1 468 1520
deployLibrary 1 469 1521
assign 1 471 1523
linkedListIteratorGet 0 0 1523
assign 1 471 1526
hasNextGet 0 471 1526
assign 1 471 1528
nextGet 0 471 1528
assign 1 472 1529
libnameInfoGet 0 472 1529
assign 1 472 1530
unitShlibGet 0 472 1530
assign 1 473 1531
emitPathGet 0 473 1531
assign 1 473 1532
copy 0 473 1532
assign 1 474 1533
stepsGet 0 474 1533
assign 1 474 1534
lastGet 0 474 1534
addStep 1 474 1535
assign 1 475 1536
fileGet 0 475 1536
assign 1 475 1537
existsGet 0 475 1537
assign 1 476 1539
fileGet 0 476 1539
delete 0 476 1540
assign 1 478 1542
fileGet 0 478 1542
assign 1 478 1543
existsGet 0 478 1543
assign 1 478 1544
not 0 478 1544
assign 1 479 1546
fileGet 0 479 1546
assign 1 479 1547
fileGet 0 479 1547
deployFile 2 479 1548
assign 1 483 1556
iteratorGet 0 483 1556
assign 1 484 1557
iteratorGet 0 484 1557
assign 1 486 1560
hasNextGet 0 486 1560
assign 1 486 1562
hasNextGet 0 486 1562
assign 1 0 1564
assign 1 0 1567
assign 1 0 1571
assign 1 487 1574
nextGet 0 487 1574
assign 1 487 1575
apNew 1 487 1575
assign 1 488 1576
emitPathGet 0 488 1576
assign 1 488 1577
copy 0 488 1577
assign 1 488 1578
toString 0 488 1578
assign 1 488 1579
new 0 488 1579
assign 1 488 1580
add 1 488 1580
assign 1 488 1581
nextGet 0 488 1581
assign 1 488 1582
add 1 488 1582
assign 1 488 1583
apNew 1 488 1583
assign 1 490 1584
fileGet 0 490 1584
assign 1 490 1585
existsGet 0 490 1585
assign 1 491 1587
fileGet 0 491 1587
delete 0 491 1588
assign 1 493 1590
fileGet 0 493 1590
assign 1 493 1591
existsGet 0 493 1591
assign 1 493 1592
not 0 493 1592
assign 1 494 1594
fileGet 0 494 1594
assign 1 494 1595
fileGet 0 494 1595
deployFile 2 494 1596
assign 1 499 1605
new 0 499 1605
assign 1 499 1606
now 0 499 1606
assign 1 499 1607
subtract 1 499 1607
assign 1 501 1608
def 1 501 1613
assign 1 502 1614
new 0 502 1614
assign 1 502 1615
add 1 502 1615
print 0 502 1616
assign 1 504 1618
def 1 504 1623
assign 1 505 1624
new 0 505 1624
assign 1 505 1625
add 1 505 1625
print 0 505 1626
assign 1 507 1628
def 1 507 1633
assign 1 508 1634
new 0 508 1634
assign 1 508 1635
add 1 508 1635
print 0 508 1636
assign 1 512 1639
new 0 512 1639
print 0 512 1640
assign 1 513 1641
run 2 513 1641
assign 1 514 1642
new 0 514 1642
assign 1 514 1643
add 1 514 1643
assign 1 514 1644
new 0 514 1644
assign 1 514 1645
add 1 514 1645
print 0 514 1646
return 1 515 1647
assign 1 517 1649
new 0 517 1649
return 1 517 1650
assign 1 521 1663
justParsedGet 0 521 1663
assign 1 521 1664
valueIteratorGet 0 521 1664
assign 1 521 1667
hasNextGet 0 521 1667
assign 1 522 1669
nextGet 0 522 1669
assign 1 523 1670
heldGet 0 523 1670
libNameSet 1 523 1671
assign 1 524 1672
getSyn 2 524 1672
libNameSet 1 525 1673
assign 1 527 1679
justParsedGet 0 527 1679
assign 1 527 1680
valueIteratorGet 0 527 1680
assign 1 527 1683
hasNextGet 0 527 1683
assign 1 528 1685
nextGet 0 528 1685
assign 1 529 1686
heldGet 0 529 1686
assign 1 529 1687
synGet 0 529 1687
checkInheritance 2 530 1688
integrate 1 531 1689
assign 1 533 1695
new 0 533 1695
justParsedSet 1 533 1696
assign 1 537 1724
heldGet 0 537 1724
assign 1 537 1725
synGet 0 537 1725
assign 1 537 1726
def 1 537 1731
assign 1 538 1732
heldGet 0 538 1732
assign 1 538 1733
synGet 0 538 1733
return 1 538 1734
assign 1 540 1736
heldGet 0 540 1736
libNameSet 1 540 1737
assign 1 541 1738
heldGet 0 541 1738
assign 1 541 1739
extendsGet 0 541 1739
assign 1 541 1740
undef 1 541 1745
assign 1 542 1746
new 1 542 1746
assign 1 544 1749
classesGet 0 544 1749
assign 1 544 1750
heldGet 0 544 1750
assign 1 544 1751
extendsGet 0 544 1751
assign 1 544 1752
toString 0 544 1752
assign 1 544 1753
get 1 544 1753
assign 1 546 1754
def 1 546 1759
assign 1 547 1760
heldGet 0 547 1760
libNameSet 1 547 1761
assign 1 548 1762
getSyn 2 548 1762
assign 1 552 1765
heldGet 0 552 1765
assign 1 552 1766
extendsGet 0 552 1766
assign 1 552 1767
getSynNp 1 552 1767
assign 1 554 1769
new 2 554 1769
assign 1 556 1771
heldGet 0 556 1771
synSet 1 556 1772
assign 1 557 1773
heldGet 0 557 1773
assign 1 557 1774
namepathGet 0 557 1774
assign 1 557 1775
toString 0 557 1775
addSynClass 2 557 1776
return 1 558 1777
assign 1 562 1785
toString 0 562 1785
assign 1 563 1786
synClassesGet 0 563 1786
assign 1 563 1787
get 1 563 1787
assign 1 564 1788
def 1 564 1793
return 1 565 1794
assign 1 571 1796
emitterGet 0 571 1796
assign 1 571 1797
loadSyn 1 571 1797
addSynClass 2 572 1798
return 1 573 1799
assign 1 580 1803
undef 1 580 1808
assign 1 581 1809
new 1 581 1809
return 1 583 1811
assign 1 588 1890
new 1 588 1890
assign 1 589 1891
new 0 589 1891
assign 1 590 1892
emitterGet 0 590 1892
assign 1 591 1893
assign 1 592 1894
new 0 592 1894
assign 1 593 1895
shouldEmitGet 0 593 1895
put 1 593 1896
assign 1 0 1899
assign 1 0 1903
assign 1 0 1906
assign 1 596 1910
new 0 596 1910
assign 1 596 1911
toString 0 596 1911
assign 1 596 1912
add 1 596 1912
print 0 596 1913
assign 1 598 1915
assign 1 600 1916
fileGet 0 600 1916
assign 1 600 1917
readerGet 0 600 1917
assign 1 600 1918
open 0 600 1918
assign 1 600 1919
readBuffer 1 600 1919
assign 1 601 1920
fileGet 0 601 1920
assign 1 601 1921
readerGet 0 601 1921
close 0 601 1922
assign 1 602 1923
tokenize 1 602 1923
assign 1 606 1925
new 0 606 1925
echo 0 606 1926
assign 1 608 1928
outermostGet 0 608 1928
nodify 2 608 1929
assign 1 610 1931
new 0 610 1931
print 0 610 1932
assign 1 611 1933
new 2 611 1933
traverse 1 611 1934
assign 1 615 1937
new 0 615 1937
echo 0 615 1938
assign 1 617 1940
new 0 617 1940
traverse 1 617 1941
assign 1 619 1943
new 0 619 1943
print 0 619 1944
assign 1 620 1945
new 2 620 1945
traverse 1 620 1946
assign 1 623 1949
new 0 623 1949
echo 0 623 1950
assign 1 626 1952
new 0 626 1952
traverse 1 626 1953
contain 0 627 1954
assign 1 629 1956
new 0 629 1956
print 0 629 1957
assign 1 630 1958
new 2 630 1958
traverse 1 630 1959
assign 1 634 1962
new 0 634 1962
echo 0 634 1963
assign 1 636 1965
new 0 636 1965
traverse 1 636 1966
assign 1 638 1968
new 0 638 1968
print 0 638 1969
assign 1 639 1970
new 2 639 1970
traverse 1 639 1971
assign 1 643 1974
new 0 643 1974
echo 0 643 1975
assign 1 645 1977
new 0 645 1977
traverse 1 645 1978
assign 1 647 1980
new 0 647 1980
print 0 647 1981
assign 1 648 1982
new 2 648 1982
traverse 1 648 1983
assign 1 652 1986
new 0 652 1986
echo 0 652 1987
assign 1 654 1989
new 0 654 1989
traverse 1 654 1990
assign 1 656 1992
new 0 656 1992
print 0 656 1993
assign 1 657 1994
new 2 657 1994
traverse 1 657 1995
assign 1 661 1998
new 0 661 1998
echo 0 661 1999
assign 1 663 2001
new 0 663 2001
traverse 1 663 2002
assign 1 665 2004
new 0 665 2004
print 0 665 2005
assign 1 666 2006
new 2 666 2006
traverse 1 666 2007
assign 1 670 2010
new 0 670 2010
echo 0 670 2011
assign 1 672 2013
new 0 672 2013
traverse 1 672 2014
assign 1 674 2016
new 0 674 2016
print 0 674 2017
assign 1 675 2018
new 2 675 2018
traverse 1 675 2019
assign 1 679 2022
new 0 679 2022
echo 0 679 2023
assign 1 681 2025
new 0 681 2025
traverse 1 681 2026
assign 1 683 2028
new 0 683 2028
print 0 683 2029
assign 1 684 2030
new 2 684 2030
traverse 1 684 2031
assign 1 688 2034
new 0 688 2034
echo 0 688 2035
assign 1 690 2037
new 0 690 2037
traverse 1 690 2038
assign 1 692 2040
new 0 692 2040
print 0 692 2041
assign 1 693 2042
new 2 693 2042
traverse 1 693 2043
assign 1 696 2046
new 0 696 2046
echo 0 696 2047
assign 1 698 2049
new 0 698 2049
traverse 1 698 2050
assign 1 700 2052
new 0 700 2052
print 0 700 2053
assign 1 701 2054
new 2 701 2054
traverse 1 701 2055
assign 1 705 2058
new 0 705 2058
echo 0 705 2059
assign 1 706 2060
new 0 706 2060
print 0 706 2061
assign 1 708 2063
new 0 708 2063
traverse 1 708 2064
assign 1 0 2066
assign 1 0 2070
assign 1 0 2073
assign 1 710 2077
new 0 710 2077
print 0 710 2078
assign 1 711 2079
new 2 711 2079
traverse 1 711 2080
assign 1 713 2082
classesGet 0 713 2082
assign 1 713 2083
valueIteratorGet 0 713 2083
assign 1 713 2086
hasNextGet 0 713 2086
assign 1 714 2088
nextGet 0 714 2088
assign 1 716 2089
transUnitGet 0 716 2089
assign 1 717 2090
new 1 717 2090
assign 1 718 2091
TRANSUNITGet 0 718 2091
typenameSet 1 718 2092
assign 1 719 2093
new 0 719 2093
assign 1 720 2094
heldGet 0 720 2094
assign 1 720 2095
emitsGet 0 720 2095
emitsSet 1 720 2096
heldSet 1 721 2097
delete 0 722 2098
addValue 1 723 2099
copyLoc 1 724 2100
reInitContained 0 730 2122
assign 1 731 2123
containedGet 0 731 2123
assign 1 732 2124
new 0 732 2124
assign 1 733 2125
new 0 733 2125
assign 1 733 2126
crGet 0 733 2126
assign 1 734 2127
linkedListIteratorGet 0 734 2127
assign 1 734 2130
hasNextGet 0 734 2130
assign 1 735 2132
new 1 735 2132
assign 1 736 2133
nextGet 0 736 2133
heldSet 1 736 2134
nlcSet 1 737 2135
assign 1 738 2136
heldGet 0 738 2136
assign 1 738 2137
equals 1 738 2137
assign 1 739 2139
increment 0 739 2139
assign 1 741 2141
heldGet 0 741 2141
assign 1 741 2142
notEquals 1 741 2142
addValue 1 742 2144
containerSet 1 743 2145
assign 1 750 2200
new 0 750 2200
fromString 1 751 2201
assign 1 753 2202
new 1 753 2202
assign 1 754 2203
NAMEPATHGet 0 754 2203
typenameSet 1 754 2204
heldSet 1 755 2205
copyLoc 1 756 2206
assign 1 758 2207
new 0 758 2207
assign 1 759 2208
new 0 759 2208
nameSet 1 759 2209
assign 1 760 2210
new 0 760 2210
wasBoundSet 1 760 2211
assign 1 761 2212
new 0 761 2212
boundSet 1 761 2213
assign 1 762 2214
new 0 762 2214
isConstructSet 1 762 2215
assign 1 763 2216
new 0 763 2216
isLiteralSet 1 763 2217
assign 1 764 2218
heldGet 0 764 2218
literalValueSet 1 764 2219
addValue 1 766 2220
assign 1 768 2221
CALLGet 0 768 2221
typenameSet 1 768 2222
heldSet 1 769 2223
resolveNp 0 771 2224
assign 1 773 2225
new 0 773 2225
assign 1 773 2226
equals 1 773 2226
assign 1 0 2228
assign 1 773 2231
new 0 773 2231
assign 1 773 2232
equals 1 773 2232
assign 1 0 2234
assign 1 0 2237
assign 1 774 2241
priorPeerGet 0 774 2241
assign 1 775 2242
def 1 775 2247
assign 1 775 2248
typenameGet 0 775 2248
assign 1 775 2249
SUBTRACTGet 0 775 2249
assign 1 775 2250
equals 1 775 2250
assign 1 0 2252
assign 1 775 2255
typenameGet 0 775 2255
assign 1 775 2256
ADDGet 0 775 2256
assign 1 775 2257
equals 1 775 2257
assign 1 0 2259
assign 1 0 2262
assign 1 0 2266
assign 1 0 2269
assign 1 0 2273
assign 1 776 2276
priorPeerGet 0 776 2276
assign 1 777 2277
undef 1 777 2282
assign 1 0 2283
assign 1 777 2286
typenameGet 0 777 2286
assign 1 777 2287
CALLGet 0 777 2287
assign 1 777 2288
notEquals 1 777 2288
assign 1 777 2290
typenameGet 0 777 2290
assign 1 777 2291
IDGet 0 777 2291
assign 1 777 2292
notEquals 1 777 2292
assign 1 0 2294
assign 1 0 2297
assign 1 0 2301
assign 1 777 2304
typenameGet 0 777 2304
assign 1 777 2305
VARGet 0 777 2305
assign 1 777 2306
notEquals 1 777 2306
assign 1 0 2308
assign 1 0 2311
assign 1 0 2315
assign 1 777 2318
typenameGet 0 777 2318
assign 1 777 2319
ACCESSORGet 0 777 2319
assign 1 777 2320
notEquals 1 777 2320
assign 1 0 2322
assign 1 0 2325
assign 1 0 2329
assign 1 0 2332
assign 1 0 2335
assign 1 783 2339
heldGet 0 783 2339
assign 1 783 2340
literalValueGet 0 783 2340
assign 1 783 2341
add 1 783 2341
literalValueSet 1 783 2342
delete 0 784 2343
return 1 0 2350
return 1 0 2353
assign 1 0 2356
assign 1 0 2360
return 1 0 2364
return 1 0 2367
assign 1 0 2370
assign 1 0 2374
return 1 0 2378
return 1 0 2381
assign 1 0 2384
assign 1 0 2388
return 1 0 2392
return 1 0 2395
assign 1 0 2398
assign 1 0 2402
return 1 0 2406
return 1 0 2409
assign 1 0 2412
assign 1 0 2416
return 1 0 2420
return 1 0 2423
assign 1 0 2426
assign 1 0 2430
return 1 0 2434
return 1 0 2437
assign 1 0 2440
assign 1 0 2444
return 1 0 2448
return 1 0 2451
assign 1 0 2454
assign 1 0 2458
return 1 0 2462
return 1 0 2465
assign 1 0 2468
assign 1 0 2472
return 1 0 2476
return 1 0 2479
assign 1 0 2482
assign 1 0 2486
return 1 0 2490
return 1 0 2493
assign 1 0 2496
assign 1 0 2500
return 1 0 2504
return 1 0 2507
assign 1 0 2510
assign 1 0 2514
return 1 0 2518
return 1 0 2521
assign 1 0 2524
assign 1 0 2528
return 1 0 2532
return 1 0 2535
assign 1 0 2538
assign 1 0 2542
return 1 0 2546
return 1 0 2549
assign 1 0 2552
assign 1 0 2556
return 1 0 2560
return 1 0 2563
assign 1 0 2566
assign 1 0 2570
return 1 0 2574
return 1 0 2577
assign 1 0 2580
assign 1 0 2584
return 1 0 2588
return 1 0 2591
assign 1 0 2594
assign 1 0 2598
return 1 0 2602
return 1 0 2605
assign 1 0 2608
assign 1 0 2612
return 1 0 2616
return 1 0 2619
assign 1 0 2622
assign 1 0 2626
return 1 0 2630
return 1 0 2633
assign 1 0 2636
assign 1 0 2640
return 1 0 2644
return 1 0 2647
assign 1 0 2650
assign 1 0 2654
return 1 0 2658
return 1 0 2661
assign 1 0 2664
assign 1 0 2668
return 1 0 2672
return 1 0 2675
assign 1 0 2678
assign 1 0 2682
return 1 0 2686
return 1 0 2689
assign 1 0 2692
assign 1 0 2696
return 1 0 2700
return 1 0 2703
assign 1 0 2706
assign 1 0 2710
return 1 0 2714
return 1 0 2717
assign 1 0 2720
assign 1 0 2724
return 1 0 2728
return 1 0 2731
assign 1 0 2734
assign 1 0 2738
return 1 0 2742
return 1 0 2745
assign 1 0 2748
assign 1 0 2752
return 1 0 2756
return 1 0 2759
assign 1 0 2762
assign 1 0 2766
return 1 0 2770
return 1 0 2773
assign 1 0 2776
assign 1 0 2780
return 1 0 2784
return 1 0 2787
assign 1 0 2790
assign 1 0 2794
return 1 0 2798
return 1 0 2801
assign 1 0 2804
assign 1 0 2808
return 1 0 2812
return 1 0 2815
assign 1 0 2818
assign 1 0 2822
return 1 0 2826
return 1 0 2829
assign 1 0 2832
assign 1 0 2836
return 1 0 2840
return 1 0 2843
assign 1 0 2846
assign 1 0 2850
return 1 0 2854
return 1 0 2857
assign 1 0 2860
assign 1 0 2864
return 1 0 2868
return 1 0 2871
assign 1 0 2874
assign 1 0 2878
return 1 0 2882
return 1 0 2885
assign 1 0 2888
assign 1 0 2892
return 1 0 2896
return 1 0 2899
assign 1 0 2902
assign 1 0 2906
return 1 0 2910
return 1 0 2913
assign 1 0 2916
assign 1 0 2920
return 1 0 2924
return 1 0 2927
assign 1 0 2930
assign 1 0 2934
return 1 0 2938
return 1 0 2941
assign 1 0 2944
assign 1 0 2948
return 1 0 2952
return 1 0 2955
assign 1 0 2958
assign 1 0 2962
return 1 0 2966
return 1 0 2969
assign 1 0 2972
assign 1 0 2976
return 1 0 2980
return 1 0 2983
assign 1 0 2986
assign 1 0 2990
return 1 0 2994
return 1 0 2997
assign 1 0 3000
assign 1 0 3004
return 1 0 3008
return 1 0 3011
assign 1 0 3014
assign 1 0 3018
return 1 0 3022
return 1 0 3025
assign 1 0 3028
assign 1 0 3032
return 1 0 3036
return 1 0 3039
assign 1 0 3042
assign 1 0 3046
return 1 0 3050
return 1 0 3053
assign 1 0 3056
assign 1 0 3060
return 1 0 3064
return 1 0 3067
assign 1 0 3070
assign 1 0 3074
return 1 0 3078
return 1 0 3081
assign 1 0 3084
assign 1 0 3088
return 1 0 3092
return 1 0 3095
assign 1 0 3098
assign 1 0 3102
return 1 0 3106
return 1 0 3109
assign 1 0 3112
assign 1 0 3116
return 1 0 3120
return 1 0 3123
assign 1 0 3126
assign 1 0 3130
return 1 0 3134
return 1 0 3137
assign 1 0 3140
assign 1 0 3144
return 1 0 3148
return 1 0 3151
assign 1 0 3154
assign 1 0 3158
return 1 0 3162
return 1 0 3165
assign 1 0 3168
assign 1 0 3172
return 1 0 3176
return 1 0 3179
assign 1 0 3182
assign 1 0 3186
return 1 0 3190
return 1 0 3193
assign 1 0 3196
assign 1 0 3200
return 1 0 3204
return 1 0 3207
assign 1 0 3210
assign 1 0 3214
return 1 0 3218
return 1 0 3221
assign 1 0 3224
assign 1 0 3228
return 1 0 3232
return 1 0 3235
assign 1 0 3238
assign 1 0 3242
return 1 0 3246
return 1 0 3249
assign 1 0 3252
assign 1 0 3256
return 1 0 3260
return 1 0 3263
assign 1 0 3266
assign 1 0 3270
return 1 0 3274
return 1 0 3277
assign 1 0 3280
assign 1 0 3284
return 1 0 3288
return 1 0 3291
assign 1 0 3294
assign 1 0 3298
return 1 0 3302
return 1 0 3305
assign 1 0 3308
assign 1 0 3312
return 1 0 3316
return 1 0 3319
assign 1 0 3322
assign 1 0 3326
return 1 0 3330
return 1 0 3333
assign 1 0 3336
assign 1 0 3340
return 1 0 3344
return 1 0 3347
assign 1 0 3350
assign 1 0 3354
return 1 0 3358
assign 1 0 3361
assign 1 0 3365
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -582411239: return bem_toBuildGet_0();
case 674241091: return bem_iteratorGet_0();
case -667387330: return bem_genOnlyGetDirect_0();
case 512181958: return bem_platformGet_0();
case 311228980: return bem_ccObjArgsGet_0();
case 494457329: return bem_emitCommonGetDirect_0();
case -2000869502: return bem_deserializeClassNameGet_0();
case -430114748: return bem_platformGetDirect_0();
case 550934614: return bem_makeGet_0();
case 1873404655: return bem_genOnlyGet_0();
case -1484721171: return bem_singleCCGet_0();
case 1432551129: return bem_builtGetDirect_0();
case -1525231363: return bem_extLibsGet_0();
case 950825159: return bem_parseTimeGetDirect_0();
case -1223303034: return bem_serializeContents_0();
case 41953221: return bem_emitFlagsGetDirect_0();
case -5932920: return bem_emitFileHeaderGetDirect_0();
case -1345920383: return bem_serializeToString_0();
case -93449420: return bem_once_0();
case 637794201: return bem_estrGetDirect_0();
case 155859462: return bem_initLibsGetDirect_0();
case -1312449744: return bem_emitDataGet_0();
case 639808161: return bem_compilerProfileGet_0();
case -1797267240: return bem_fromFileGet_0();
case -2130512674: return bem_parseEmitCompileTimeGetDirect_0();
case -439681017: return bem_sharedEmitterGet_0();
case -1948556863: return bem_prepMakeGetDirect_0();
case -1908695994: return bem_mainNameGetDirect_0();
case -752210152: return bem_estrGet_0();
case 1921834118: return bem_sourceFileNameGet_0();
case 1120458206: return bem_libNameGetDirect_0();
case 2020549980: return bem_extLinkObjectsGet_0();
case -538312537: return bem_fieldIteratorGet_0();
case 949714057: return bem_initLibsGet_0();
case -2093465585: return bem_compilerGetDirect_0();
case 758414687: return bem_putLineNumbersInTraceGet_0();
case 1351087407: return bem_emitDebugGetDirect_0();
case -1808282554: return bem_deployUsedLibrariesGetDirect_0();
case -1157138625: return bem_startTimeGetDirect_0();
case -315639346: return bem_deployLibraryGet_0();
case -420261879: return bem_ntypesGet_0();
case 1144594612: return bem_toAny_0();
case -208659062: return bem_deployPathGetDirect_0();
case -125778274: return bem_doEmitGet_0();
case 958890336: return bem_linkLibArgsGetDirect_0();
case -1988273620: return bem_codeGet_0();
case -1685867882: return bem_extLibsGetDirect_0();
case 193069652: return bem_emitPathGet_0();
case -156212770: return bem_deployFilesFromGet_0();
case -1370488335: return bem_toString_0();
case 1567786510: return bem_emitDataGetDirect_0();
case -609848272: return bem_twtokGet_0();
case -2054180438: return bem_tagGet_0();
case 1774551033: return bem_argsGetDirect_0();
case 1614180382: return bem_sharedEmitterGetDirect_0();
case -876645121: return bem_nlGetDirect_0();
case -948567555: return bem_constantsGet_0();
case -742590511: return bem_emitLibraryGetDirect_0();
case -309025159: return bem_argsGet_0();
case -905609052: return bem_libNameGet_0();
case 2077899298: return bem_print_0();
case -1270300499: return bem_includePathGetDirect_0();
case 1326361773: return bem_emitFileHeaderGet_0();
case -904008064: return bem_serializationIteratorGet_0();
case 494599016: return bem_deployLibraryGetDirect_0();
case -1240487755: return bem_parseEmitTimeGet_0();
case -1926967385: return bem_runGet_0();
case 919586803: return bem_parseEmitTimeGetDirect_0();
case 1928751071: return bem_outputPlatformGetDirect_0();
case -312557248: return bem_copy_0();
case -425671401: return bem_buildPathGetDirect_0();
case 1966868198: return bem_fromFileGetDirect_0();
case 1583058339: return bem_usedLibrarysStrGetDirect_0();
case -2076100360: return bem_codeGetDirect_0();
case 928013995: return bem_usedLibrarysStrGet_0();
case 1331785008: return bem_exeNameGet_0();
case 1866606653: return bem_buildSucceededGet_0();
case -489295671: return bem_go_0();
case 1388679813: return bem_paramsGet_0();
case 716721289: return bem_emitFlagsGet_0();
case 1950261116: return bem_parseEmitCompileTimeGet_0();
case -558858847: return bem_emitDebugGet_0();
case -740958985: return bem_echo_0();
case 1923816180: return bem_create_0();
case 1536030665: return bem_loadSynsGet_0();
case -442203483: return bem_builtGet_0();
case -114338232: return bem_ownProcessGetDirect_0();
case 1381029476: return bem_includePathGet_0();
case -1286789689: return bem_paramsGetDirect_0();
case 750902787: return bem_printStepsGet_0();
case 2105699928: return bem_printStepsGetDirect_0();
case -1177520738: return bem_prepMakeGet_0();
case 1714018597: return bem_readBufferGetDirect_0();
case 1795593121: return bem_main_0();
case 1293078636: return bem_makeGetDirect_0();
case 1001032610: return bem_saveIdsGet_0();
case 198514657: return bem_toBuildGetDirect_0();
case 605756325: return bem_makeNameGet_0();
case 179023267: return bem_deployPathGet_0();
case -144866456: return bem_ntypesGetDirect_0();
case 1250893833: return bem_emitPathGetDirect_0();
case -3069318: return bem_linkLibArgsGet_0();
case 139050381: return bem_printAstElementsGet_0();
case -1575227083: return bem_lctokGetDirect_0();
case 1831222129: return bem_config_0();
case -1463210484: return bem_new_0();
case 1537684085: return bem_readBufferGet_0();
case 126067397: return bem_printAstElementsGetDirect_0();
case -964403064: return bem_putLineNumbersInTraceGetDirect_0();
case -2072395246: return bem_printAstGet_0();
case 628010907: return bem_printPlacesGetDirect_0();
case 1745570746: return bem_parseGetDirect_0();
case 2146471307: return bem_usedLibrarysGet_0();
case 1407077164: return bem_closeLibrariesStrGetDirect_0();
case 1634581059: return bem_nlGet_0();
case 2113016002: return bem_runArgsGet_0();
case 1138269512: return bem_newlineGet_0();
case 1173821656: return bem_setClassesToWrite_0();
case -903130553: return bem_singleCCGetDirect_0();
case 858451309: return bem_deployFilesFromGetDirect_0();
case 226215516: return bem_emitCs_0();
case 1544079043: return bem_many_0();
case 1897132115: return bem_emitCommonGet_0();
case 1600840287: return bem_newlineGetDirect_0();
case 1702882485: return bem_makeArgsGet_0();
case 1742901473: return bem_ownProcessGet_0();
case -541074771: return bem_doEmitGetDirect_0();
case -1589868146: return bem_printPlacesGet_0();
case -1508200011: return bem_ccObjArgsGetDirect_0();
case 623289425: return bem_outputPlatformGet_0();
case 607887247: return bem_saveIdsGetDirect_0();
case 1591352546: return bem_usedLibrarysGetDirect_0();
case 1323551844: return bem_compilerGet_0();
case 1173035891: return bem_printAllAstGetDirect_0();
case 1496176420: return bem_makeArgsGetDirect_0();
case -898304671: return bem_fieldNamesGet_0();
case 238245463: return bem_runArgsGetDirect_0();
case 2036735890: return bem_extIncludesGet_0();
case 929319366: return bem_runGetDirect_0();
case -1852066203: return bem_emitterGet_0();
case -780183381: return bem_constantsGetDirect_0();
case 1184837020: return bem_parseGet_0();
case 2106520113: return bem_startTimeGet_0();
case 1847367607: return bem_compilerProfileGetDirect_0();
case 1959649789: return bem_loadSynsGetDirect_0();
case 1316670529: return bem_classNameGet_0();
case -1272720439: return bem_extLinkObjectsGetDirect_0();
case -1927041846: return bem_mainNameGet_0();
case -1335845813: return bem_deployFilesToGetDirect_0();
case -620746118: return bem_saveSynsGetDirect_0();
case 882799794: return bem_saveSynsGet_0();
case -322992971: return bem_buildSucceededGetDirect_0();
case 963930722: return bem_emitLangsGetDirect_0();
case 938164214: return bem_buildMessageGetDirect_0();
case 424183283: return bem_emitLangsGet_0();
case -1084887199: return bem_closeLibrariesGet_0();
case -227896704: return bem_deployFilesToGet_0();
case 588838155: return bem_deployUsedLibrariesGet_0();
case 1794126319: return bem_doWhat_0();
case 1153167115: return bem_makeNameGetDirect_0();
case 488705538: return bem_lctokGet_0();
case 1049938383: return bem_closeLibrariesGetDirect_0();
case -834603986: return bem_emitLibraryGet_0();
case -307148823: return bem_printAllAstGet_0();
case -605776940: return bem_closeLibrariesStrGet_0();
case -1809976796: return bem_exeNameGetDirect_0();
case -1724277753: return bem_buildPathGet_0();
case -1231060775: return bem_twtokGetDirect_0();
case 1510263462: return bem_extIncludesGetDirect_0();
case -519657354: return bem_printAstGetDirect_0();
case -1836675075: return bem_hashGet_0();
case -724994307: return bem_buildMessageGet_0();
case -1340498614: return bem_parseTimeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 368680202: return bem_exeNameSet_1(bevd_0);
case -58950120: return bem_extLibsSet_1(bevd_0);
case 2106504633: return bem_platformSetDirect_1(bevd_0);
case 2069704245: return bem_sharedEmitterSetDirect_1(bevd_0);
case -1707433346: return bem_paramsSet_1(bevd_0);
case 175221135: return bem_newlineSetDirect_1(bevd_0);
case 532034178: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1898593180: return bem_ccObjArgsSet_1(bevd_0);
case 989579109: return bem_readBufferSetDirect_1(bevd_0);
case 1260764349: return bem_deployFilesFromSet_1(bevd_0);
case -1419445767: return bem_printAstElementsSet_1(bevd_0);
case 828418562: return bem_mainNameSetDirect_1(bevd_0);
case -1516590332: return bem_emitDataSetDirect_1(bevd_0);
case 971016820: return bem_constantsSet_1(bevd_0);
case -1760527612: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -1147269230: return bem_buildSucceededSetDirect_1(bevd_0);
case 115797769: return bem_compilerSetDirect_1(bevd_0);
case -1388361532: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case -164720496: return bem_sameClass_1(bevd_0);
case 1239309448: return bem_doEmitSetDirect_1(bevd_0);
case -2034911372: return bem_makeSetDirect_1(bevd_0);
case 149928449: return bem_startTimeSet_1(bevd_0);
case 678169222: return bem_doParse_1(bevd_0);
case 1758723276: return bem_parseTimeSetDirect_1(bevd_0);
case 2086486990: return bem_builtSet_1(bevd_0);
case 1316891110: return bem_deployLibrarySetDirect_1(bevd_0);
case -30366782: return bem_buildMessageSet_1(bevd_0);
case -1120344169: return bem_def_1(bevd_0);
case 648732636: return bem_printPlacesSetDirect_1(bevd_0);
case -640296056: return bem_notEquals_1(bevd_0);
case 1788956116: return bem_nlSetDirect_1(bevd_0);
case -1329665170: return bem_newlineSet_1(bevd_0);
case -1755509471: return bem_otherClass_1(bevd_0);
case 380824363: return bem_usedLibrarysSetDirect_1(bevd_0);
case 1156102537: return bem_genOnlySetDirect_1(bevd_0);
case 64549732: return bem_outputPlatformSetDirect_1(bevd_0);
case 636591940: return bem_exeNameSetDirect_1(bevd_0);
case -1416064591: return bem_printAllAstSet_1(bevd_0);
case 1946627782: return bem_makeArgsSetDirect_1(bevd_0);
case -143754451: return bem_deployFilesToSet_1(bevd_0);
case -817576789: return bem_startTimeSetDirect_1(bevd_0);
case -135946501: return bem_codeSetDirect_1(bevd_0);
case -1086398098: return bem_defined_1(bevd_0);
case -1338453810: return bem_saveIdsSet_1(bevd_0);
case 1654444139: return bem_sharedEmitterSet_1(bevd_0);
case 716262419: return bem_makeSet_1(bevd_0);
case -123329325: return bem_fromFileSet_1(bevd_0);
case 133954608: return bem_saveIdsSetDirect_1(bevd_0);
case -1579291006: return bem_parseTimeSet_1(bevd_0);
case 2097923990: return bem_loadSynsSetDirect_1(bevd_0);
case -753551604: return bem_printAstSetDirect_1(bevd_0);
case 1381468365: return bem_platformSet_1(bevd_0);
case -245992722: return bem_printAllAstSetDirect_1(bevd_0);
case 62794630: return bem_includePathSet_1(bevd_0);
case -2091453267: return bem_closeLibrariesSetDirect_1(bevd_0);
case 219731562: return bem_closeLibrariesSet_1(bevd_0);
case 942435111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 62050771: return bem_emitFileHeaderSetDirect_1(bevd_0);
case -574724818: return bem_readBufferSet_1(bevd_0);
case 1582538793: return bem_deployFilesToSetDirect_1(bevd_0);
case -1054099754: return bem_printAstSet_1(bevd_0);
case -2091949787: return bem_initLibsSet_1(bevd_0);
case -1853742454: return bem_printStepsSet_1(bevd_0);
case -616266871: return bem_argsSet_1(bevd_0);
case -907240958: return bem_parseEmitTimeSet_1(bevd_0);
case -1886056359: return bem_initLibsSetDirect_1(bevd_0);
case 1717857841: return bem_ownProcessSet_1(bevd_0);
case -257057695: return bem_otherType_1(bevd_0);
case 1774619271: return bem_loadSynsSet_1(bevd_0);
case -735547334: return bem_paramsSetDirect_1(bevd_0);
case 738638253: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 675409179: return bem_sameObject_1(bevd_0);
case -193922413: return bem_fromFileSetDirect_1(bevd_0);
case -1522794170: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1109842233: return bem_printAstElementsSetDirect_1(bevd_0);
case -1762212665: return bem_emitLibrarySet_1(bevd_0);
case 1381170385: return bem_extLibsSetDirect_1(bevd_0);
case 1439562578: return bem_makeArgsSet_1(bevd_0);
case -432260434: return bem_runArgsSetDirect_1(bevd_0);
case -349797313: return bem_nlSet_1(bevd_0);
case -1731856958: return bem_includePathSetDirect_1(bevd_0);
case 1856080396: return bem_lctokSetDirect_1(bevd_0);
case 1761949929: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1255011981: return bem_deployLibrarySet_1(bevd_0);
case -2104285945: return bem_runArgsSet_1(bevd_0);
case -1306816572: return bem_emitPathSet_1(bevd_0);
case 172625853: return bem_saveSynsSetDirect_1(bevd_0);
case 2080966610: return bem_codeSet_1(bevd_0);
case 1667487498: return bem_emitDataSet_1(bevd_0);
case 697817289: return bem_ccObjArgsSetDirect_1(bevd_0);
case -82874350: return bem_twtokSetDirect_1(bevd_0);
case -2067968278: return bem_linkLibArgsSetDirect_1(bevd_0);
case -2096940743: return bem_emitLangsSet_1(bevd_0);
case 1143050880: return bem_twtokSet_1(bevd_0);
case 250733234: return bem_saveSynsSet_1(bevd_0);
case 1515358411: return bem_linkLibArgsSet_1(bevd_0);
case 1136905977: return bem_undef_1(bevd_0);
case -1253791758: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case -1338030119: return bem_estrSetDirect_1(bevd_0);
case -1813926840: return bem_parseSetDirect_1(bevd_0);
case -857285757: return bem_toBuildSetDirect_1(bevd_0);
case -1157709315: return bem_emitFileHeaderSet_1(bevd_0);
case -451875928: return bem_buildSyns_1(bevd_0);
case -1464835778: return bem_ownProcessSetDirect_1(bevd_0);
case 687966817: return bem_singleCCSet_1(bevd_0);
case 195920861: return bem_emitLangsSetDirect_1(bevd_0);
case 211275503: return bem_runSetDirect_1(bevd_0);
case 1095407089: return bem_mainNameSet_1(bevd_0);
case 689522287: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -1475219783: return bem_emitCommonSetDirect_1(bevd_0);
case -768394986: return bem_extIncludesSet_1(bevd_0);
case 1411392795: return bem_undefined_1(bevd_0);
case 986950245: return bem_prepMakeSetDirect_1(bevd_0);
case -1801531052: return bem_emitPathSetDirect_1(bevd_0);
case 1224207736: return bem_emitCommonSet_1(bevd_0);
case -2016980062: return bem_estrSet_1(bevd_0);
case 1677269270: return bem_compilerProfileSet_1(bevd_0);
case -1437100725: return bem_printStepsSetDirect_1(bevd_0);
case -1084251637: return bem_buildPathSetDirect_1(bevd_0);
case 1951849720: return bem_makeNameSet_1(bevd_0);
case -588775114: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 963669396: return bem_outputPlatformSet_1(bevd_0);
case 1893585148: return bem_sameType_1(bevd_0);
case -1022866965: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -1985033584: return bem_lctokSet_1(bevd_0);
case -278275014: return bem_builtSetDirect_1(bevd_0);
case 2108551526: return bem_emitLibrarySetDirect_1(bevd_0);
case -1196472683: return bem_deployPathSetDirect_1(bevd_0);
case -231556388: return bem_emitDebugSetDirect_1(bevd_0);
case -88200407: return bem_parseEmitTimeSetDirect_1(bevd_0);
case -227789211: return bem_copyTo_1(bevd_0);
case -906634470: return bem_parseSet_1(bevd_0);
case -1103186036: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case 1737064829: return bem_constantsSetDirect_1(bevd_0);
case -149227027: return bem_emitDebugSet_1(bevd_0);
case -511836069: return bem_libNameSetDirect_1(bevd_0);
case -2101240095: return bem_compilerSet_1(bevd_0);
case -725635874: return bem_genOnlySet_1(bevd_0);
case 1305486032: return bem_equals_1(bevd_0);
case 1124797861: return bem_extLinkObjectsSet_1(bevd_0);
case 889063570: return bem_singleCCSetDirect_1(bevd_0);
case 1275941843: return bem_buildPathSet_1(bevd_0);
case 1167105343: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 1910409322: return bem_libNameSet_1(bevd_0);
case 265946895: return bem_compilerProfileSetDirect_1(bevd_0);
case 1820161297: return bem_ntypesSet_1(bevd_0);
case 526915688: return bem_deployPathSet_1(bevd_0);
case -228295041: return bem_getSynNp_1(bevd_0);
case -683977131: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case 230028800: return bem_deployUsedLibrariesSet_1(bevd_0);
case -1135587735: return bem_buildMessageSetDirect_1(bevd_0);
case 111429307: return bem_ntypesSetDirect_1(bevd_0);
case 1574312103: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 1919442379: return bem_closeLibrariesStrSet_1(bevd_0);
case 109077707: return bem_makeNameSetDirect_1(bevd_0);
case -1446804130: return bem_usedLibrarysSet_1(bevd_0);
case -775733027: return bem_deployFilesFromSetDirect_1(bevd_0);
case 1611416838: return bem_printPlacesSet_1(bevd_0);
case 163012593: return bem_usedLibrarysStrSet_1(bevd_0);
case 1205429051: return bem_argsSetDirect_1(bevd_0);
case 1374937099: return bem_doEmitSet_1(bevd_0);
case 1897796841: return bem_emitFlagsSet_1(bevd_0);
case 465986052: return bem_buildSucceededSet_1(bevd_0);
case 2069782556: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case -160873134: return bem_runSet_1(bevd_0);
case 269771125: return bem_prepMakeSet_1(bevd_0);
case 170321081: return bem_toBuildSet_1(bevd_0);
case -1857333825: return bem_emitFlagsSetDirect_1(bevd_0);
case 643503446: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -2032375082: return bem_extIncludesSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2006332895: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1472458850: return bem_buildLiteral_2(bevd_0, bevd_1);
case 265265077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1327331293: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -305196806: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1035184286: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -882013396: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1602629663: return bem_getSyn_2(bevd_0, bevd_1);
case 1214675142: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 341335680: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
