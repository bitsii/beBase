package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_57, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_61, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_65, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_66, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 96 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 97 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 115 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 115 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try  /* Line: 125 */ {
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 128 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(-2069102102);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 133 */
if (bevp_printSteps.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 136 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(-1447107675);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1602696702, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 142 */ {
} /* Line: 142 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_121_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_122_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_124_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpany_phold = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 153 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1947306340);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 156 */
} /* Line: 154 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 162 */
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 166 */
 else  /* Line: 167 */ {
bevp_exeName = bevp_libName;
} /* Line: 168 */
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(-1447107675);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_27));
bevp_loadSyns = bevp_params.bem_get_1(bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_28));
bevp_initLibs = bevp_params.bem_get_1(bevt_50_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_29));
bevt_51_tmpany_phold = bevp_params.bem_get_1(bevt_52_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_firstGet_0();
bevt_54_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_30));
bevt_53_tmpany_phold = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_53_tmpany_phold.bem_firstGet_0();
bevt_55_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_55_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 184 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 185 */
bevt_57_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_57_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_61_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 204 */ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extLibs == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-1499145551);
} /* Line: 221 */
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_runArgs == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-1499145551);
} /* Line: 225 */
 else  /* Line: 226 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 227 */
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_42));
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_77_tmpany_phold, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_79_tmpany_phold, bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_81_tmpany_phold);
bevt_82_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_82_tmpany_phold);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_83_tmpany_phold);
if (bevl_pacm == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_86_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_86_tmpany_phold.bevi_bool) {
bevt_85_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_85_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_85_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 235 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 236 */ {
bevt_87_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_87_tmpany_phold).bevi_bool) /* Line: 236 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 237 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
} /* Line: 236 */
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_50));
bevt_92_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_91_tmpany_phold, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_emitLangs = bevp_params.bem_get_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_emitFlags = bevp_params.bem_get_1(bevt_94_tmpany_phold);
bevt_96_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_95_tmpany_phold = bevp_params.bem_get_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_95_tmpany_phold.bem_firstGet_0();
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_100_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_98_tmpany_phold = bevp_params.bem_get_2(bevt_99_tmpany_phold, bevt_100_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_firstGet_0();
bevt_103_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_102_tmpany_phold = bevt_103_tmpany_phold.bem_add_1(bevp_makeName);
bevt_104_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_101_tmpany_phold = bevp_params.bem_get_2(bevt_102_tmpany_phold, bevt_104_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_101_tmpany_phold.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_105_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_105_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_105_tmpany_phold.bevi_bool) /* Line: 256 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 257 */
 else  /* Line: 258 */ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_59));
} /* Line: 259 */
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_107_tmpany_phold = bevl_outLang.bem_add_1(bevt_108_tmpany_phold);
bevt_109_tmpany_phold = bevp_platform.bemd_0(-1447107675);
bevt_106_tmpany_phold = bevt_107_tmpany_phold.bem_add_1(bevt_109_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_106_tmpany_phold);
if (bevl_platformSources == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_111_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_111_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 268 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_112_tmpany_phold);
if (bevl_langSources == null) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_115_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_115_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 273 */
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_116_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 277 */ {
bevt_117_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_117_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(-1947306340);
bevt_118_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_118_tmpany_phold);
} /* Line: 278 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(339596740);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_121_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpany_phold = bevt_121_tmpany_phold.bem_existsGet_0();
if (bevt_120_tmpany_phold.bevi_bool) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevt_122_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_122_tmpany_phold.bem_makeDirs_0();
} /* Line: 286 */
if (bevp_emitFileHeader == null) {
bevt_123_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_124_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_124_tmpany_phold.bem_readerGet_0();
bevt_125_tmpany_phold = bevl_emr.bemd_0(-1762208676);
bevp_emitFileHeader = bevt_125_tmpany_phold.bemd_0(-894441276);
bevl_emr.bemd_0(-912676242);
} /* Line: 291 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(2044454682, bevp_nl);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_62));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(2044454682, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(2044454682, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(2044454682, bevp_nl);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_63));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(2044454682, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(2044454682, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 305 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 305 */ {
bevl_clnode = bevl_ci.bemd_0(-1947306340);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(-1200745202);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1935183779);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(-1200745202);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(112811732);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-2069102102);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(-1200745202);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(112811732);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-2069102102);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 310 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 311 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 312 */
 else  /* Line: 311 */ {
break;
} /* Line: 311 */
} /* Line: 311 */
} /* Line: 311 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(-1200745202);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(112811732);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-2069102102);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 317 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 318 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 316 */
} /* Line: 307 */
 else  /* Line: 305 */ {
break;
} /* Line: 305 */
} /* Line: 305 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 323 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 323 */ {
bevl_clnode = bevl_ci.bemd_0(-1947306340);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(-1200745202);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(-1200745202);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(112811732);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-2069102102);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(-404944486, bevt_26_tmpany_phold);
} /* Line: 325 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 336 */ {
return bevp_emitCommon;
} /* Line: 337 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 342 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 345 */
 else  /* Line: 344 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 347 */
 else  /* Line: 344 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 344 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 352 */ {
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_68));
bevt_10_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 353 */
} /* Line: 344 */
} /* Line: 344 */
} /* Line: 344 */
return bevp_emitCommon;
} /* Line: 355 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(-1762208676);
bevt_5_tmpany_phold = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 378 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 379 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 379 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 380 */
 else  /* Line: 379 */ {
break;
} /* Line: 379 */
} /* Line: 379 */
} /* Line: 379 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 387 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 388 */
} /* Line: 387 */
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(-1232907801);
while (true)
 /* Line: 393 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(-1947306340);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 397 */
} /* Line: 394 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(-1232907801);
while (true)
 /* Line: 400 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 400 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(-1947306340);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-1203105958);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 405 */
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
if (bevp_parse.bevi_bool) /* Line: 408 */ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 411 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevl_tb = bevl_i.bemd_0(-1947306340);
bevt_20_tmpany_phold = bevl_tb.bemd_0(-2069102102);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 414 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(-2069102102);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 416 */
} /* Line: 414 */
 else  /* Line: 411 */ {
break;
} /* Line: 411 */
} /* Line: 411 */
bem_buildSyns_1(bevl_em);
} /* Line: 419 */
bevt_23_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 425 */ {
bevt_26_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 434 */
if (bevp_doEmit.bevi_bool) /* Line: 436 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-363135826);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 440 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 440 */ {
bevl_clnode = bevl_ci.bemd_0(-1947306340);
bevl_em.bemd_1(278779730, bevl_clnode);
} /* Line: 442 */
 else  /* Line: 440 */ {
break;
} /* Line: 440 */
} /* Line: 440 */
bevl_em.bemd_0(1657223750);
bevl_em.bemd_0(1987062972);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 446 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 446 */ {
bevl_clnode = bevl_ci.bemd_0(-1947306340);
bevl_em.bemd_1(-1085065351, bevl_clnode);
} /* Line: 448 */
 else  /* Line: 446 */ {
break;
} /* Line: 446 */
} /* Line: 446 */
} /* Line: 446 */
bevt_44_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 454 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 457 */ {
bevl_em.bemd_1(216678311, bevp_deployLibrary);
} /* Line: 459 */
if (bevp_make.bevi_bool) /* Line: 462 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 463 */ {
bevl_em.bemd_1(1050744772, bevp_deployLibrary);
bevl_em.bemd_1(1121504821, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 466 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 467 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 467 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(-363135826);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(138423177);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(-175852657);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1811048653);
bevl_cpTo.bemd_1(1587714423, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(328641420);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(1467867398);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(328641420);
bevt_58_tmpany_phold.bemd_0(422356544);
} /* Line: 472 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(328641420);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(1467867398);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(964413679);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 474 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(328641420);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(328641420);
bevl_em.bemd_2(-1696785411, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 475 */
} /* Line: 474 */
 else  /* Line: 467 */ {
break;
} /* Line: 467 */
} /* Line: 467 */
} /* Line: 467 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 482 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 482 */
 else  /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 482 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(-1947306340);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(-1947306340);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(328641420);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(1467867398);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(328641420);
bevt_76_tmpany_phold.bemd_0(422356544);
} /* Line: 487 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(328641420);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(1467867398);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(964413679);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(328641420);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(328641420);
bevl_em.bemd_2(-1696785411, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 490 */
} /* Line: 489 */
 else  /* Line: 482 */ {
break;
} /* Line: 482 */
} /* Line: 482 */
} /* Line: 482 */
} /* Line: 463 */
bevt_83_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 498 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 500 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 501 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 504 */
if (bevp_run.bevi_bool) /* Line: 507 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(1383767612, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 511 */
bevt_98_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 517 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevl_kls = bevl_ci.bemd_0(-1947306340);
bevt_2_tmpany_phold = bevl_kls.bemd_0(-1200745202);
bevt_2_tmpany_phold.bemd_1(-132509534, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-132509534, bevp_libName);
} /* Line: 521 */
 else  /* Line: 517 */ {
break;
} /* Line: 517 */
} /* Line: 517 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 523 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 523 */ {
bevl_kls = bevl_ci.bemd_0(-1947306340);
bevt_5_tmpany_phold = bevl_kls.bemd_0(-1200745202);
bevl_syn = bevt_5_tmpany_phold.bemd_0(-49894022);
bevl_syn.bemd_2(-1128016502, this, bevl_kls);
bevl_syn.bemd_1(-659839426, this);
} /* Line: 527 */
 else  /* Line: 523 */ {
break;
} /* Line: 523 */
} /* Line: 523 */
bevt_6_tmpany_phold = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(-1200745202);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-49894022);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 533 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(-1200745202);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-49894022);
return bevt_3_tmpany_phold;
} /* Line: 534 */
bevt_5_tmpany_phold = beva_klass.bemd_0(-1200745202);
bevt_5_tmpany_phold.bemd_1(-132509534, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(-1200745202);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(2011682755);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 537 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 538 */
 else  /* Line: 539 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(-1200745202);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(2011682755);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-2069102102);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 542 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(-1200745202);
bevt_14_tmpany_phold.bemd_1(-132509534, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 544 */
 else  /* Line: 545 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(-1200745202);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(2011682755);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 548 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 550 */
bevt_17_tmpany_phold = beva_klass.bemd_0(-1200745202);
bevt_17_tmpany_phold.bemd_1(1432724913, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(-1200745202);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(112811732);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-2069102102);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(-2069102102);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 560 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 561 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(2070250733, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 576 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 577 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 590 */ {
if (bevp_printSteps.bevi_bool) /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 591 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 591 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_5_tmpany_phold = beva_toParse.bemd_0(-2069102102);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 592 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(328641420);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1608264791);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1762208676);
bevl_src = bevt_6_tmpany_phold.bemd_1(-1288770293, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(328641420);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1608264791);
bevt_9_tmpany_phold.bemd_0(-912676242);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 601 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 602 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(-934075116);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 605 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_14_tmpany_phold);
} /* Line: 607 */
if (bevp_printSteps.bevi_bool) /* Line: 610 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 611 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-1999628139, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 614 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_18_tmpany_phold);
} /* Line: 616 */
if (bevp_printSteps.bevi_bool) /* Line: 618 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 619 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-1999628139, bevt_20_tmpany_phold);
bevl_trans.bemd_0(1562568341);
if (bevp_printAllAst.bevi_bool) /* Line: 624 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_22_tmpany_phold);
} /* Line: 626 */
if (bevp_printSteps.bevi_bool) /* Line: 629 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 630 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-1999628139, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_26_tmpany_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 639 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-1999628139, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_30_tmpany_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 648 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-1999628139, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_34_tmpany_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 657 */
bevt_36_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-1999628139, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_38_tmpany_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 665 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 666 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-1999628139, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 669 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_42_tmpany_phold);
} /* Line: 671 */
if (bevp_printSteps.bevi_bool) /* Line: 674 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 675 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-1999628139, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 678 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_46_tmpany_phold);
} /* Line: 680 */
if (bevp_printSteps.bevi_bool) /* Line: 683 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 684 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-1999628139, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 687 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_50_tmpany_phold);
} /* Line: 689 */
if (bevp_printSteps.bevi_bool) /* Line: 691 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 692 */
bevt_52_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-1999628139, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 695 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_54_tmpany_phold);
} /* Line: 697 */
if (bevp_printSteps.bevi_bool) /* Line: 700 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 702 */
bevt_57_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-1999628139, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 705 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 705 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 705 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1999628139, bevt_59_tmpany_phold);
} /* Line: 707 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 709 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(-2011678843);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 709 */ {
bevl_clnode = bevl_ci.bemd_0(-1947306340);
bevl_tunode = bevl_clnode.bemd_0(127395247);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(870178787, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(-1200745202);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1446703603);
bevl_ntt.bemd_1(-1998390016, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(1901148596, bevl_ntt);
bevl_clnode.bemd_0(422356544);
bevl_ntunode.bemd_1(893770658, bevl_clnode);
bevl_ntunode.bemd_1(-1341830476, bevl_clnode);
} /* Line: 720 */
 else  /* Line: 709 */ {
break;
} /* Line: 709 */
} /* Line: 709 */
} /* Line: 709 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(-1619326576);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(918816723);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 730 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 730 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(1901148596, bevt_2_tmpany_phold);
bevl_node.bemd_1(-1039817436, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(-1200745202);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1602696702, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 734 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 735 */
bevt_6_tmpany_phold = bevl_node.bemd_0(-1200745202);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(650080222, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 737 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(1334503366, beva_parnode);
} /* Line: 739 */
} /* Line: 737 */
 else  /* Line: 730 */ {
break;
} /* Line: 730 */
} /* Line: 730 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(1310016579, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(870178787, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(1901148596, bevl_nlnp);
bevl_nlnpn.bemd_1(-1341830476, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_110));
bevl_nlc.bemd_1(489040096, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(478108651, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1272641445, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(866327001, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-1963866401, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(-1200745202);
bevl_nlc.bemd_1(246155143, bevt_11_tmpany_phold);
beva_node.bemd_1(893770658, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(870178787, bevt_12_tmpany_phold);
beva_node.bemd_1(1901148596, bevl_nlc);
bevl_nlnpn.bemd_0(-1428198119);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_111));
bevt_13_tmpany_phold = beva_tName.bemd_1(1602696702, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 769 */ {
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_112));
bevt_15_tmpany_phold = beva_tName.bemd_1(1602696702, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 769 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 769 */ {
bevl_pn = beva_node.bemd_0(1705364850);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 771 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(1878699153);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(1602696702, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(1878699153);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1602696702, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 771 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 771 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 771 */ {
bevl_pn2 = bevl_pn.bemd_0(1705364850);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(1878699153);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(650080222, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(1878699153);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(650080222, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(1878699153);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(650080222, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(1878699153);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(650080222, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(-1200745202);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(-1780486485);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(2044454682, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(246155143, bevt_37_tmpany_phold);
bevl_pn.bemd_0(422356544);
} /* Line: 780 */
} /* Line: 773 */
} /* Line: 771 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public final BEC_2_4_6_TextString bem_mainNameGetDirect_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public final BEC_2_4_6_TextString bem_exeNameGetDirect_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_platformGetDirect_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public final BEC_2_4_6_TextString bem_nlGetDirect_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public final BEC_2_4_6_TextString bem_buildMessageGetDirect_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_includePathGetDirect_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_builtGetDirect_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printAstGetDirect_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_parseGetDirect_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_makeGetDirect_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_codeGetDirect_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public final BEC_2_4_6_TextString bem_estrGetDirect_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public final BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public final BEC_2_4_6_TextString bem_deployPathGetDirect_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_runGetDirect_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public final BEC_2_4_6_TextString bem_compilerGetDirect_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public final BEC_2_4_6_TextString bem_makeNameGetDirect_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public final BEC_2_4_6_TextString bem_makeArgsGetDirect_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public final BEC_2_4_6_TextString bem_readBufferGetDirect_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() throws Throwable {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 86, 87, 88, 89, 89, 96, 96, 96, 96, 0, 96, 96, 0, 0, 0, 0, 0, 97, 97, 99, 99, 103, 103, 103, 103, 107, 107, 108, 108, 108, 112, 113, 114, 114, 114, 114, 114, 115, 115, 115, 116, 115, 118, 122, 123, 124, 126, 127, 128, 130, 131, 132, 132, 133, 0, 0, 0, 136, 138, 142, 142, 142, 144, 149, 151, 152, 152, 152, 153, 153, 0, 153, 153, 154, 154, 154, 155, 156, 156, 161, 161, 161, 161, 162, 164, 164, 164, 165, 165, 166, 166, 166, 168, 170, 170, 170, 170, 170, 170, 171, 172, 172, 173, 173, 173, 173, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 179, 179, 181, 181, 181, 182, 182, 182, 183, 183, 184, 184, 185, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 229, 229, 229, 230, 230, 230, 231, 231, 232, 232, 233, 234, 234, 235, 235, 235, 235, 235, 0, 0, 0, 236, 0, 236, 236, 237, 240, 240, 241, 241, 242, 242, 243, 243, 243, 244, 244, 245, 245, 246, 246, 246, 246, 247, 247, 247, 247, 248, 248, 248, 248, 248, 249, 250, 251, 252, 253, 256, 256, 257, 259, 266, 266, 266, 266, 266, 267, 267, 268, 268, 271, 271, 271, 272, 272, 273, 273, 276, 277, 277, 0, 277, 277, 278, 278, 280, 281, 282, 284, 285, 285, 285, 285, 286, 286, 288, 288, 289, 289, 290, 290, 291, 297, 298, 298, 298, 298, 298, 299, 299, 299, 299, 299, 300, 304, 305, 305, 305, 306, 307, 307, 307, 307, 308, 308, 308, 308, 309, 309, 309, 309, 309, 310, 310, 311, 0, 311, 311, 312, 315, 315, 315, 315, 315, 316, 316, 317, 0, 317, 317, 318, 323, 323, 323, 324, 325, 325, 325, 325, 325, 325, 332, 332, 336, 336, 337, 342, 342, 343, 344, 344, 345, 346, 346, 347, 348, 348, 349, 350, 350, 351, 353, 353, 353, 355, 357, 361, 363, 363, 363, 364, 364, 365, 365, 365, 366, 366, 367, 368, 368, 369, 369, 369, 370, 370, 370, 376, 376, 377, 378, 378, 379, 0, 379, 379, 380, 383, 384, 384, 385, 386, 388, 388, 388, 391, 393, 0, 393, 393, 394, 394, 394, 395, 396, 397, 400, 0, 400, 400, 401, 401, 401, 402, 403, 404, 405, 405, 410, 411, 411, 412, 414, 414, 415, 415, 416, 419, 422, 422, 422, 425, 425, 425, 427, 427, 428, 428, 429, 429, 429, 430, 430, 430, 431, 431, 431, 432, 432, 432, 433, 433, 433, 434, 434, 437, 438, 440, 440, 440, 441, 442, 444, 445, 446, 446, 446, 447, 448, 452, 452, 452, 453, 453, 454, 454, 454, 456, 456, 456, 459, 463, 463, 464, 465, 467, 0, 467, 467, 468, 468, 469, 469, 470, 470, 470, 471, 471, 472, 472, 474, 474, 474, 475, 475, 475, 479, 480, 482, 482, 0, 0, 0, 483, 483, 484, 484, 484, 484, 484, 484, 484, 484, 486, 486, 487, 487, 489, 489, 489, 490, 490, 490, 495, 495, 495, 497, 497, 498, 498, 498, 500, 500, 501, 501, 501, 503, 503, 504, 504, 504, 508, 508, 509, 510, 510, 510, 510, 510, 511, 513, 513, 517, 517, 517, 518, 519, 519, 520, 521, 523, 523, 523, 524, 525, 525, 526, 527, 529, 529, 533, 533, 533, 533, 534, 534, 534, 536, 536, 537, 537, 537, 537, 538, 540, 540, 540, 540, 540, 542, 542, 543, 543, 544, 548, 548, 548, 550, 552, 552, 553, 553, 553, 553, 554, 558, 559, 559, 560, 560, 561, 567, 567, 568, 569, 576, 576, 577, 579, 584, 585, 586, 587, 588, 589, 589, 0, 0, 0, 592, 592, 592, 592, 594, 596, 596, 596, 596, 597, 597, 597, 598, 602, 602, 604, 604, 606, 606, 607, 607, 611, 611, 613, 613, 615, 615, 616, 616, 619, 619, 622, 622, 623, 625, 625, 626, 626, 630, 630, 632, 632, 634, 634, 635, 635, 639, 639, 641, 641, 643, 643, 644, 644, 648, 648, 650, 650, 652, 652, 653, 653, 657, 657, 659, 659, 661, 661, 662, 662, 666, 666, 668, 668, 670, 670, 671, 671, 675, 675, 677, 677, 679, 679, 680, 680, 684, 684, 686, 686, 688, 688, 689, 689, 692, 692, 694, 694, 696, 696, 697, 697, 701, 701, 702, 702, 704, 704, 0, 0, 0, 706, 706, 707, 707, 709, 709, 709, 710, 712, 713, 714, 714, 715, 716, 716, 716, 717, 718, 719, 720, 726, 727, 728, 729, 729, 730, 730, 731, 732, 732, 733, 734, 734, 735, 737, 737, 738, 739, 746, 747, 749, 750, 750, 751, 752, 754, 755, 755, 756, 756, 757, 757, 758, 758, 759, 759, 760, 760, 762, 764, 764, 765, 767, 769, 769, 0, 769, 769, 0, 0, 770, 771, 771, 771, 771, 771, 0, 771, 771, 771, 0, 0, 0, 0, 0, 772, 773, 773, 0, 773, 773, 773, 773, 773, 773, 0, 0, 0, 773, 773, 773, 0, 0, 0, 773, 773, 773, 0, 0, 0, 0, 0, 779, 779, 779, 779, 780, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 287, 292, 293, 294, 296, 299, 300, 302, 305, 309, 312, 316, 319, 320, 322, 323, 329, 330, 331, 332, 339, 340, 341, 342, 343, 355, 356, 357, 358, 359, 360, 361, 362, 365, 370, 371, 372, 378, 386, 387, 388, 390, 391, 392, 396, 397, 398, 399, 400, 403, 407, 410, 414, 416, 422, 423, 424, 427, 565, 566, 567, 568, 573, 574, 575, 575, 578, 580, 581, 582, 587, 588, 589, 590, 598, 599, 600, 601, 603, 605, 606, 607, 608, 609, 611, 612, 613, 616, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 671, 672, 674, 675, 676, 681, 682, 684, 685, 686, 691, 692, 694, 695, 696, 701, 702, 704, 705, 706, 711, 712, 714, 715, 716, 721, 722, 724, 725, 726, 731, 732, 734, 735, 736, 741, 742, 744, 745, 746, 751, 752, 754, 755, 756, 761, 762, 764, 765, 766, 771, 772, 775, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 795, 796, 797, 802, 803, 806, 810, 813, 813, 816, 818, 819, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 862, 863, 866, 868, 869, 870, 871, 872, 873, 878, 879, 880, 882, 883, 884, 885, 890, 891, 892, 894, 895, 896, 896, 899, 901, 902, 903, 909, 910, 911, 912, 913, 914, 915, 920, 921, 922, 924, 929, 930, 931, 932, 933, 934, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 999, 1000, 1001, 1004, 1006, 1007, 1008, 1009, 1010, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1026, 1027, 1027, 1030, 1032, 1033, 1040, 1041, 1042, 1043, 1044, 1045, 1050, 1051, 1051, 1054, 1056, 1057, 1070, 1071, 1074, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1092, 1093, 1109, 1114, 1115, 1117, 1122, 1123, 1124, 1125, 1127, 1130, 1131, 1133, 1136, 1137, 1139, 1142, 1143, 1145, 1148, 1149, 1150, 1155, 1157, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1316, 1317, 1318, 1319, 1324, 1325, 1325, 1328, 1330, 1331, 1338, 1339, 1344, 1345, 1346, 1348, 1349, 1350, 1353, 1354, 1354, 1357, 1359, 1360, 1361, 1366, 1367, 1368, 1369, 1376, 1376, 1379, 1381, 1382, 1383, 1388, 1389, 1390, 1391, 1392, 1393, 1401, 1402, 1405, 1407, 1408, 1409, 1411, 1412, 1413, 1420, 1422, 1423, 1424, 1425, 1426, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1455, 1456, 1457, 1458, 1461, 1463, 1464, 1470, 1471, 1472, 1473, 1476, 1478, 1479, 1486, 1487, 1488, 1489, 1494, 1495, 1496, 1497, 1499, 1500, 1501, 1503, 1506, 1511, 1512, 1513, 1515, 1515, 1518, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1531, 1532, 1534, 1535, 1536, 1538, 1539, 1540, 1548, 1549, 1552, 1554, 1556, 1559, 1563, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1579, 1580, 1582, 1583, 1584, 1586, 1587, 1588, 1597, 1598, 1599, 1600, 1605, 1606, 1607, 1608, 1610, 1615, 1616, 1617, 1618, 1620, 1625, 1626, 1627, 1628, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1641, 1642, 1655, 1656, 1659, 1661, 1662, 1663, 1664, 1665, 1671, 1672, 1675, 1677, 1678, 1679, 1680, 1681, 1687, 1688, 1716, 1717, 1718, 1723, 1724, 1725, 1726, 1728, 1729, 1730, 1731, 1732, 1737, 1738, 1741, 1742, 1743, 1744, 1745, 1746, 1751, 1752, 1753, 1754, 1757, 1758, 1759, 1761, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1777, 1778, 1779, 1780, 1785, 1786, 1788, 1789, 1790, 1791, 1795, 1800, 1801, 1803, 1882, 1883, 1884, 1885, 1886, 1887, 1888, 1891, 1895, 1898, 1902, 1903, 1904, 1905, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1917, 1918, 1920, 1921, 1923, 1924, 1925, 1926, 1929, 1930, 1932, 1933, 1935, 1936, 1937, 1938, 1941, 1942, 1944, 1945, 1946, 1948, 1949, 1950, 1951, 1954, 1955, 1957, 1958, 1960, 1961, 1962, 1963, 1966, 1967, 1969, 1970, 1972, 1973, 1974, 1975, 1978, 1979, 1981, 1982, 1984, 1985, 1986, 1987, 1990, 1991, 1993, 1994, 1996, 1997, 1998, 1999, 2002, 2003, 2005, 2006, 2008, 2009, 2010, 2011, 2014, 2015, 2017, 2018, 2020, 2021, 2022, 2023, 2026, 2027, 2029, 2030, 2032, 2033, 2034, 2035, 2038, 2039, 2041, 2042, 2044, 2045, 2046, 2047, 2050, 2051, 2052, 2053, 2055, 2056, 2058, 2062, 2065, 2069, 2070, 2071, 2072, 2074, 2075, 2078, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2114, 2115, 2116, 2117, 2118, 2119, 2122, 2124, 2125, 2126, 2127, 2128, 2129, 2131, 2133, 2134, 2136, 2137, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2220, 2223, 2224, 2226, 2229, 2233, 2234, 2239, 2240, 2241, 2242, 2244, 2247, 2248, 2249, 2251, 2254, 2258, 2261, 2265, 2268, 2269, 2274, 2275, 2278, 2279, 2280, 2282, 2283, 2284, 2286, 2289, 2293, 2296, 2297, 2298, 2300, 2303, 2307, 2310, 2311, 2312, 2314, 2317, 2321, 2324, 2327, 2331, 2332, 2333, 2334, 2335, 2342, 2345, 2348, 2352, 2356, 2359, 2362, 2366, 2370, 2373, 2376, 2380, 2384, 2387, 2390, 2394, 2398, 2401, 2404, 2408, 2412, 2415, 2418, 2422, 2426, 2429, 2432, 2436, 2440, 2443, 2446, 2450, 2454, 2457, 2460, 2464, 2468, 2471, 2474, 2478, 2482, 2485, 2488, 2492, 2496, 2499, 2502, 2506, 2510, 2513, 2516, 2520, 2524, 2527, 2530, 2534, 2538, 2541, 2544, 2548, 2552, 2555, 2558, 2562, 2566, 2569, 2572, 2576, 2580, 2583, 2586, 2590, 2594, 2597, 2600, 2604, 2608, 2611, 2614, 2618, 2622, 2625, 2628, 2632, 2636, 2639, 2642, 2646, 2650, 2653, 2656, 2660, 2664, 2667, 2670, 2674, 2678, 2681, 2684, 2688, 2692, 2695, 2698, 2702, 2706, 2709, 2712, 2716, 2720, 2723, 2726, 2730, 2734, 2737, 2740, 2744, 2748, 2751, 2754, 2758, 2762, 2765, 2768, 2772, 2776, 2779, 2782, 2786, 2790, 2793, 2796, 2800, 2804, 2807, 2810, 2814, 2818, 2821, 2824, 2828, 2832, 2835, 2838, 2842, 2846, 2849, 2852, 2856, 2860, 2863, 2866, 2870, 2874, 2877, 2880, 2884, 2888, 2891, 2894, 2898, 2902, 2905, 2908, 2912, 2916, 2919, 2922, 2926, 2930, 2933, 2936, 2940, 2944, 2947, 2950, 2954, 2958, 2961, 2964, 2968, 2972, 2975, 2978, 2982, 2986, 2989, 2992, 2996, 3000, 3003, 3006, 3010, 3014, 3017, 3020, 3024, 3028, 3031, 3034, 3038, 3042, 3045, 3048, 3052, 3056, 3059, 3062, 3066, 3070, 3073, 3076, 3080, 3084, 3087, 3090, 3094, 3098, 3101, 3104, 3108, 3112, 3115, 3118, 3122, 3126, 3129, 3132, 3136, 3140, 3143, 3146, 3150, 3154, 3157, 3160, 3164, 3168, 3171, 3174, 3178, 3182, 3185, 3188, 3192, 3196, 3199, 3202, 3206, 3210, 3213, 3216, 3220, 3224, 3227, 3230, 3234, 3238, 3241, 3244, 3248, 3252, 3255, 3258, 3262, 3266, 3269, 3272, 3276, 3280, 3283, 3286, 3290, 3294, 3297, 3300, 3304, 3308, 3311, 3314, 3318, 3322, 3325, 3329};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 51 250
new 0 51 250
assign 1 53 251
new 0 53 251
assign 1 54 252
new 0 54 252
assign 1 55 253
new 0 55 253
assign 1 56 254
new 0 56 254
assign 1 58 255
new 0 58 255
assign 1 59 256
new 0 59 256
assign 1 60 257
new 0 60 257
assign 1 61 258
new 0 61 258
assign 1 62 259
new 0 62 259
assign 1 63 260
new 0 63 260
assign 1 64 261
new 0 64 261
assign 1 68 262
new 0 68 262
assign 1 70 263
new 1 70 263
assign 1 71 264
ntypesGet 0 71 264
assign 1 72 265
twtokGet 0 72 265
assign 1 73 266
new 0 73 266
assign 1 73 267
new 1 73 267
assign 1 76 268
new 0 76 268
assign 1 79 269
new 0 79 269
assign 1 80 270
new 0 80 270
assign 1 86 271
new 0 86 271
assign 1 87 272
new 0 87 272
assign 1 88 273
new 0 88 273
assign 1 89 274
new 0 89 274
assign 1 89 275
new 1 89 275
assign 1 96 287
def 1 96 292
assign 1 96 293
new 0 96 293
assign 1 96 294
equals 1 96 294
assign 1 0 296
assign 1 96 299
new 0 96 299
assign 1 96 300
ends 1 96 300
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 97 319
new 0 97 319
return 1 97 320
assign 1 99 322
new 0 99 322
return 1 99 323
assign 1 103 329
new 0 103 329
assign 1 103 330
new 0 103 330
assign 1 103 331
swap 2 103 331
return 1 103 332
assign 1 107 339
new 0 107 339
assign 1 107 340
argsGet 0 107 340
assign 1 108 341
new 0 108 341
assign 1 108 342
main 1 108 342
exit 1 108 343
assign 1 112 355
assign 1 113 356
new 1 113 356
assign 1 114 357
new 0 114 357
assign 1 114 358
new 0 114 358
assign 1 114 359
get 2 114 359
assign 1 114 360
firstGet 0 114 360
assign 1 114 361
new 1 114 361
assign 1 115 362
new 0 115 362
assign 1 115 365
lesser 1 115 370
assign 1 116 371
go 0 116 371
incrementValue 0 115 372
return 1 118 378
assign 1 122 386
new 0 122 386
config 0 123 387
assign 1 124 388
new 0 124 388
assign 1 126 390
new 0 126 390
assign 1 127 391
doWhat 0 127 391
assign 1 128 392
new 0 128 392
assign 1 130 396
toString 0 130 396
assign 1 131 397
new 0 131 397
assign 1 132 398
new 0 132 398
assign 1 132 399
add 1 132 399
assign 1 133 400
new 0 133 400
assign 1 0 403
assign 1 0 407
assign 1 0 410
print 0 136 414
return 1 138 416
assign 1 142 422
nameGet 0 142 422
assign 1 142 423
new 0 142 423
assign 1 142 424
equals 1 142 424
return 1 144 427
assign 1 149 565
new 0 149 565
assign 1 151 566
new 0 151 566
assign 1 152 567
get 1 152 567
assign 1 152 568
def 1 152 573
assign 1 153 574
get 1 153 574
assign 1 153 575
iteratorGet 0 0 575
assign 1 153 578
hasNextGet 0 153 578
assign 1 153 580
nextGet 0 153 580
assign 1 154 581
has 1 154 581
assign 1 154 582
not 0 154 587
put 1 155 588
assign 1 156 589
new 1 156 589
addFile 1 156 590
assign 1 161 598
new 0 161 598
assign 1 161 599
nameGet 0 161 599
assign 1 161 600
new 0 161 600
assign 1 161 601
equals 1 161 601
preProcessorSet 1 162 603
assign 1 164 605
new 0 164 605
assign 1 164 606
get 1 164 606
assign 1 164 607
firstGet 0 164 607
assign 1 165 608
new 0 165 608
assign 1 165 609
has 1 165 609
assign 1 166 611
new 0 166 611
assign 1 166 612
get 1 166 612
assign 1 166 613
firstGet 0 166 613
assign 1 168 616
assign 1 170 618
new 0 170 618
assign 1 170 619
new 0 170 619
assign 1 170 620
get 2 170 620
assign 1 170 621
firstGet 0 170 621
assign 1 170 622
new 1 170 622
assign 1 170 623
pathGet 0 170 623
addStep 1 171 624
assign 1 172 625
new 0 172 625
addStep 1 172 626
assign 1 173 627
new 0 173 627
assign 1 173 628
new 0 173 628
assign 1 173 629
get 2 173 629
assign 1 173 630
firstGet 0 173 630
assign 1 173 631
new 1 173 631
assign 1 173 632
pathGet 0 173 632
assign 1 174 633
new 0 174 633
assign 1 174 634
new 0 174 634
assign 1 174 635
nameGet 0 174 635
assign 1 174 636
get 2 174 636
assign 1 174 637
firstGet 0 174 637
assign 1 174 638
new 1 174 638
assign 1 175 639
new 0 175 639
assign 1 175 640
nameGet 0 175 640
assign 1 175 641
get 2 175 641
assign 1 175 642
firstGet 0 175 642
assign 1 175 643
new 1 175 643
assign 1 176 644
new 0 176 644
assign 1 176 645
new 0 176 645
assign 1 176 646
get 2 176 646
assign 1 176 647
firstGet 0 176 647
assign 1 176 648
new 1 176 648
assign 1 177 649
new 0 177 649
assign 1 177 650
new 0 177 650
assign 1 177 651
get 2 177 651
assign 1 177 652
firstGet 0 177 652
assign 1 177 653
new 1 177 653
assign 1 178 654
new 0 178 654
assign 1 178 655
get 1 178 655
assign 1 179 656
new 0 179 656
assign 1 179 657
get 1 179 657
assign 1 181 658
new 0 181 658
assign 1 181 659
get 1 181 659
assign 1 181 660
firstGet 0 181 660
assign 1 182 661
new 0 182 661
assign 1 182 662
get 1 182 662
assign 1 182 663
firstGet 0 182 663
assign 1 183 664
new 0 183 664
assign 1 183 665
get 1 183 665
assign 1 184 666
undef 1 184 671
assign 1 185 672
new 0 185 672
assign 1 187 674
new 0 187 674
assign 1 187 675
get 1 187 675
assign 1 188 676
undef 1 188 681
assign 1 189 682
new 0 189 682
assign 1 191 684
new 0 191 684
assign 1 191 685
get 1 191 685
assign 1 192 686
undef 1 192 691
assign 1 193 692
new 0 193 692
assign 1 195 694
new 0 195 694
assign 1 195 695
get 1 195 695
assign 1 196 696
undef 1 196 701
assign 1 197 702
new 0 197 702
assign 1 199 704
new 0 199 704
assign 1 199 705
get 1 199 705
assign 1 200 706
undef 1 200 711
assign 1 201 712
new 0 201 712
assign 1 203 714
new 0 203 714
assign 1 203 715
get 1 203 715
assign 1 204 716
undef 1 204 721
assign 1 205 722
new 0 205 722
assign 1 207 724
new 0 207 724
assign 1 207 725
get 1 207 725
assign 1 208 726
undef 1 208 731
assign 1 209 732
new 0 209 732
assign 1 211 734
new 0 211 734
assign 1 211 735
get 1 211 735
assign 1 212 736
undef 1 212 741
assign 1 213 742
new 0 213 742
assign 1 215 744
new 0 215 744
assign 1 215 745
get 1 215 745
assign 1 216 746
undef 1 216 751
assign 1 217 752
new 0 217 752
assign 1 219 754
new 0 219 754
assign 1 219 755
get 1 219 755
assign 1 220 756
def 1 220 761
assign 1 221 762
firstGet 0 221 762
assign 1 223 764
new 0 223 764
assign 1 223 765
get 1 223 765
assign 1 224 766
def 1 224 771
assign 1 225 772
firstGet 0 225 772
assign 1 227 775
new 0 227 775
assign 1 229 777
new 0 229 777
assign 1 229 778
new 0 229 778
assign 1 229 779
isTrue 2 229 779
assign 1 230 780
new 0 230 780
assign 1 230 781
new 0 230 781
assign 1 230 782
isTrue 2 230 782
assign 1 231 783
new 0 231 783
assign 1 231 784
isTrue 1 231 784
assign 1 232 785
new 0 232 785
assign 1 232 786
isTrue 1 232 786
assign 1 233 787
new 0 233 787
assign 1 234 788
new 0 234 788
assign 1 234 789
get 1 234 789
assign 1 235 790
def 1 235 795
assign 1 235 796
isEmptyGet 0 235 796
assign 1 235 797
not 0 235 802
assign 1 0 803
assign 1 0 806
assign 1 0 810
assign 1 236 813
linkedListIteratorGet 0 0 813
assign 1 236 816
hasNextGet 0 236 816
assign 1 236 818
nextGet 0 236 818
put 1 237 819
assign 1 240 826
new 0 240 826
assign 1 240 827
isTrue 1 240 827
assign 1 241 828
new 0 241 828
assign 1 241 829
isTrue 1 241 829
assign 1 242 830
new 0 242 830
assign 1 242 831
isTrue 1 242 831
assign 1 243 832
new 0 243 832
assign 1 243 833
new 0 243 833
assign 1 243 834
isTrue 2 243 834
assign 1 244 835
new 0 244 835
assign 1 244 836
get 1 244 836
assign 1 245 837
new 0 245 837
assign 1 245 838
get 1 245 838
assign 1 246 839
new 0 246 839
assign 1 246 840
new 0 246 840
assign 1 246 841
get 2 246 841
assign 1 246 842
firstGet 0 246 842
assign 1 247 843
new 0 247 843
assign 1 247 844
new 0 247 844
assign 1 247 845
get 2 247 845
assign 1 247 846
firstGet 0 247 846
assign 1 248 847
new 0 248 847
assign 1 248 848
add 1 248 848
assign 1 248 849
new 0 248 849
assign 1 248 850
get 2 248 850
assign 1 248 851
firstGet 0 248 851
assign 1 249 852
new 0 249 852
assign 1 250 853
new 0 250 853
assign 1 251 854
new 0 251 854
assign 1 252 855
new 0 252 855
assign 1 253 856
new 0 253 856
assign 1 256 857
def 1 256 862
assign 1 257 863
firstGet 0 257 863
assign 1 259 866
new 0 259 866
assign 1 266 868
new 0 266 868
assign 1 266 869
add 1 266 869
assign 1 266 870
nameGet 0 266 870
assign 1 266 871
add 1 266 871
assign 1 266 872
get 1 266 872
assign 1 267 873
def 1 267 878
assign 1 268 879
orderedGet 0 268 879
addAll 1 268 880
assign 1 271 882
new 0 271 882
assign 1 271 883
add 1 271 883
assign 1 271 884
get 1 271 884
assign 1 272 885
def 1 272 890
assign 1 273 891
orderedGet 0 273 891
addAll 1 273 892
assign 1 276 894
new 0 276 894
assign 1 277 895
orderedGet 0 277 895
assign 1 277 896
iteratorGet 0 0 896
assign 1 277 899
hasNextGet 0 277 899
assign 1 277 901
nextGet 0 277 901
assign 1 278 902
new 1 278 902
addValue 1 278 903
assign 1 280 909
newlineGet 0 280 909
assign 1 281 910
assign 1 282 911
new 1 282 911
assign 1 284 912
copy 0 284 912
assign 1 285 913
fileGet 0 285 913
assign 1 285 914
existsGet 0 285 914
assign 1 285 915
not 0 285 920
assign 1 286 921
fileGet 0 286 921
makeDirs 0 286 922
assign 1 288 924
def 1 288 929
assign 1 289 930
new 1 289 930
assign 1 289 931
readerGet 0 289 931
assign 1 290 932
open 0 290 932
assign 1 290 933
readString 0 290 933
close 0 291 934
assign 1 297 948
classNameGet 0 297 948
assign 1 298 949
add 1 298 949
assign 1 298 950
new 0 298 950
assign 1 298 951
add 1 298 951
assign 1 298 952
toString 0 298 952
assign 1 298 953
add 1 298 953
assign 1 299 954
add 1 299 954
assign 1 299 955
new 0 299 955
assign 1 299 956
add 1 299 956
assign 1 299 957
toString 0 299 957
assign 1 299 958
add 1 299 958
return 1 300 959
assign 1 304 999
new 0 304 999
assign 1 305 1000
classesGet 0 305 1000
assign 1 305 1001
valueIteratorGet 0 305 1001
assign 1 305 1004
hasNextGet 0 305 1004
assign 1 306 1006
nextGet 0 306 1006
assign 1 307 1007
shouldEmitGet 0 307 1007
assign 1 307 1008
heldGet 0 307 1008
assign 1 307 1009
fromFileGet 0 307 1009
assign 1 307 1010
has 1 307 1010
assign 1 308 1012
heldGet 0 308 1012
assign 1 308 1013
namepathGet 0 308 1013
assign 1 308 1014
toString 0 308 1014
put 1 308 1015
assign 1 309 1016
usedByGet 0 309 1016
assign 1 309 1017
heldGet 0 309 1017
assign 1 309 1018
namepathGet 0 309 1018
assign 1 309 1019
toString 0 309 1019
assign 1 309 1020
get 1 309 1020
assign 1 310 1021
def 1 310 1026
assign 1 311 1027
setIteratorGet 0 0 1027
assign 1 311 1030
hasNextGet 0 311 1030
assign 1 311 1032
nextGet 0 311 1032
put 1 312 1033
assign 1 315 1040
subClassesGet 0 315 1040
assign 1 315 1041
heldGet 0 315 1041
assign 1 315 1042
namepathGet 0 315 1042
assign 1 315 1043
toString 0 315 1043
assign 1 315 1044
get 1 315 1044
assign 1 316 1045
def 1 316 1050
assign 1 317 1051
setIteratorGet 0 0 1051
assign 1 317 1054
hasNextGet 0 317 1054
assign 1 317 1056
nextGet 0 317 1056
put 1 318 1057
assign 1 323 1070
classesGet 0 323 1070
assign 1 323 1071
valueIteratorGet 0 323 1071
assign 1 323 1074
hasNextGet 0 323 1074
assign 1 324 1076
nextGet 0 324 1076
assign 1 325 1077
heldGet 0 325 1077
assign 1 325 1078
heldGet 0 325 1078
assign 1 325 1079
namepathGet 0 325 1079
assign 1 325 1080
toString 0 325 1080
assign 1 325 1081
has 1 325 1081
shouldWriteSet 1 325 1082
assign 1 332 1092
new 0 332 1092
return 1 332 1093
assign 1 336 1109
def 1 336 1114
return 1 337 1115
assign 1 342 1117
def 1 342 1122
assign 1 343 1123
firstGet 0 343 1123
assign 1 344 1124
new 0 344 1124
assign 1 344 1125
equals 1 344 1125
assign 1 345 1127
new 1 345 1127
assign 1 346 1130
new 0 346 1130
assign 1 346 1131
equals 1 346 1131
assign 1 347 1133
new 1 347 1133
assign 1 348 1136
new 0 348 1136
assign 1 348 1137
equals 1 348 1137
assign 1 349 1139
new 1 349 1139
assign 1 350 1142
new 0 350 1142
assign 1 350 1143
equals 1 350 1143
assign 1 351 1145
new 1 351 1145
assign 1 353 1148
new 0 353 1148
assign 1 353 1149
new 1 353 1149
throw 1 353 1150
return 1 355 1155
return 1 357 1157
assign 1 361 1176
apNew 1 361 1176
assign 1 363 1177
new 0 363 1177
assign 1 363 1178
add 1 363 1178
print 0 363 1179
assign 1 364 1180
new 0 364 1180
assign 1 364 1181
now 0 364 1181
assign 1 365 1182
fileGet 0 365 1182
assign 1 365 1183
readerGet 0 365 1183
assign 1 365 1184
open 0 365 1184
assign 1 366 1185
new 0 366 1185
assign 1 366 1186
deserialize 1 366 1186
close 0 367 1187
assign 1 368 1188
synClassesGet 0 368 1188
addValue 1 368 1189
assign 1 369 1190
new 0 369 1190
assign 1 369 1191
now 0 369 1191
assign 1 369 1192
subtract 1 369 1192
assign 1 370 1193
new 0 370 1193
assign 1 370 1194
add 1 370 1194
print 0 370 1195
assign 1 376 1316
new 0 376 1316
assign 1 376 1317
now 0 376 1317
assign 1 377 1318
new 0 377 1318
assign 1 378 1319
def 1 378 1324
assign 1 379 1325
linkedListIteratorGet 0 0 1325
assign 1 379 1328
hasNextGet 0 379 1328
assign 1 379 1330
nextGet 0 379 1330
loadSyns 1 380 1331
assign 1 383 1338
emitterGet 0 383 1338
assign 1 384 1339
def 1 384 1344
assign 1 385 1345
new 4 385 1345
put 1 386 1346
assign 1 388 1348
new 0 388 1348
assign 1 388 1349
add 1 388 1349
print 0 388 1350
assign 1 391 1353
new 0 391 1353
assign 1 393 1354
iteratorGet 0 0 1354
assign 1 393 1357
hasNextGet 0 393 1357
assign 1 393 1359
nextGet 0 393 1359
assign 1 394 1360
has 1 394 1360
assign 1 394 1361
not 0 394 1366
put 1 395 1367
assign 1 396 1368
new 2 396 1368
addValue 1 397 1369
assign 1 400 1376
iteratorGet 0 0 1376
assign 1 400 1379
hasNextGet 0 400 1379
assign 1 400 1381
nextGet 0 400 1381
assign 1 401 1382
has 1 401 1382
assign 1 401 1383
not 0 401 1388
put 1 402 1389
assign 1 403 1390
new 2 403 1390
addValue 1 404 1391
assign 1 405 1392
libNameGet 0 405 1392
put 1 405 1393
assign 1 410 1401
new 0 410 1401
assign 1 411 1402
iteratorGet 0 411 1402
assign 1 411 1405
hasNextGet 0 411 1405
assign 1 412 1407
nextGet 0 412 1407
assign 1 414 1408
toString 0 414 1408
assign 1 414 1409
has 1 414 1409
assign 1 415 1411
toString 0 415 1411
put 1 415 1412
doParse 1 416 1413
buildSyns 1 419 1420
assign 1 422 1422
new 0 422 1422
assign 1 422 1423
now 0 422 1423
assign 1 422 1424
subtract 1 422 1424
assign 1 425 1425
emitCommonGet 0 425 1425
assign 1 425 1426
def 1 425 1431
assign 1 427 1432
new 0 427 1432
assign 1 427 1433
now 0 427 1433
assign 1 428 1434
emitCommonGet 0 428 1434
doEmit 0 428 1435
assign 1 429 1436
new 0 429 1436
assign 1 429 1437
now 0 429 1437
assign 1 429 1438
subtract 1 429 1438
assign 1 430 1439
new 0 430 1439
assign 1 430 1440
now 0 430 1440
assign 1 430 1441
subtract 1 430 1441
assign 1 431 1442
new 0 431 1442
assign 1 431 1443
add 1 431 1443
print 0 431 1444
assign 1 432 1445
new 0 432 1445
assign 1 432 1446
add 1 432 1446
print 0 432 1447
assign 1 433 1448
new 0 433 1448
assign 1 433 1449
add 1 433 1449
print 0 433 1450
assign 1 434 1451
new 0 434 1451
return 1 434 1452
setClassesToWrite 0 437 1455
libnameInfoGet 0 438 1456
assign 1 440 1457
classesGet 0 440 1457
assign 1 440 1458
valueIteratorGet 0 440 1458
assign 1 440 1461
hasNextGet 0 440 1461
assign 1 441 1463
nextGet 0 441 1463
doEmit 1 442 1464
emitMain 0 444 1470
emitCUInit 0 445 1471
assign 1 446 1472
classesGet 0 446 1472
assign 1 446 1473
valueIteratorGet 0 446 1473
assign 1 446 1476
hasNextGet 0 446 1476
assign 1 447 1478
nextGet 0 447 1478
emitSyn 1 448 1479
assign 1 452 1486
new 0 452 1486
assign 1 452 1487
now 0 452 1487
assign 1 452 1488
subtract 1 452 1488
assign 1 453 1489
def 1 453 1494
assign 1 454 1495
new 0 454 1495
assign 1 454 1496
add 1 454 1496
print 0 454 1497
assign 1 456 1499
new 0 456 1499
assign 1 456 1500
add 1 456 1500
print 0 456 1501
prepMake 1 459 1503
assign 1 463 1506
not 0 463 1511
make 1 464 1512
deployLibrary 1 465 1513
assign 1 467 1515
linkedListIteratorGet 0 0 1515
assign 1 467 1518
hasNextGet 0 467 1518
assign 1 467 1520
nextGet 0 467 1520
assign 1 468 1521
libnameInfoGet 0 468 1521
assign 1 468 1522
unitShlibGet 0 468 1522
assign 1 469 1523
emitPathGet 0 469 1523
assign 1 469 1524
copy 0 469 1524
assign 1 470 1525
stepsGet 0 470 1525
assign 1 470 1526
lastGet 0 470 1526
addStep 1 470 1527
assign 1 471 1528
fileGet 0 471 1528
assign 1 471 1529
existsGet 0 471 1529
assign 1 472 1531
fileGet 0 472 1531
delete 0 472 1532
assign 1 474 1534
fileGet 0 474 1534
assign 1 474 1535
existsGet 0 474 1535
assign 1 474 1536
not 0 474 1536
assign 1 475 1538
fileGet 0 475 1538
assign 1 475 1539
fileGet 0 475 1539
deployFile 2 475 1540
assign 1 479 1548
iteratorGet 0 479 1548
assign 1 480 1549
iteratorGet 0 480 1549
assign 1 482 1552
hasNextGet 0 482 1552
assign 1 482 1554
hasNextGet 0 482 1554
assign 1 0 1556
assign 1 0 1559
assign 1 0 1563
assign 1 483 1566
nextGet 0 483 1566
assign 1 483 1567
apNew 1 483 1567
assign 1 484 1568
emitPathGet 0 484 1568
assign 1 484 1569
copy 0 484 1569
assign 1 484 1570
toString 0 484 1570
assign 1 484 1571
new 0 484 1571
assign 1 484 1572
add 1 484 1572
assign 1 484 1573
nextGet 0 484 1573
assign 1 484 1574
add 1 484 1574
assign 1 484 1575
apNew 1 484 1575
assign 1 486 1576
fileGet 0 486 1576
assign 1 486 1577
existsGet 0 486 1577
assign 1 487 1579
fileGet 0 487 1579
delete 0 487 1580
assign 1 489 1582
fileGet 0 489 1582
assign 1 489 1583
existsGet 0 489 1583
assign 1 489 1584
not 0 489 1584
assign 1 490 1586
fileGet 0 490 1586
assign 1 490 1587
fileGet 0 490 1587
deployFile 2 490 1588
assign 1 495 1597
new 0 495 1597
assign 1 495 1598
now 0 495 1598
assign 1 495 1599
subtract 1 495 1599
assign 1 497 1600
def 1 497 1605
assign 1 498 1606
new 0 498 1606
assign 1 498 1607
add 1 498 1607
print 0 498 1608
assign 1 500 1610
def 1 500 1615
assign 1 501 1616
new 0 501 1616
assign 1 501 1617
add 1 501 1617
print 0 501 1618
assign 1 503 1620
def 1 503 1625
assign 1 504 1626
new 0 504 1626
assign 1 504 1627
add 1 504 1627
print 0 504 1628
assign 1 508 1631
new 0 508 1631
print 0 508 1632
assign 1 509 1633
run 2 509 1633
assign 1 510 1634
new 0 510 1634
assign 1 510 1635
add 1 510 1635
assign 1 510 1636
new 0 510 1636
assign 1 510 1637
add 1 510 1637
print 0 510 1638
return 1 511 1639
assign 1 513 1641
new 0 513 1641
return 1 513 1642
assign 1 517 1655
justParsedGet 0 517 1655
assign 1 517 1656
valueIteratorGet 0 517 1656
assign 1 517 1659
hasNextGet 0 517 1659
assign 1 518 1661
nextGet 0 518 1661
assign 1 519 1662
heldGet 0 519 1662
libNameSet 1 519 1663
assign 1 520 1664
getSyn 2 520 1664
libNameSet 1 521 1665
assign 1 523 1671
justParsedGet 0 523 1671
assign 1 523 1672
valueIteratorGet 0 523 1672
assign 1 523 1675
hasNextGet 0 523 1675
assign 1 524 1677
nextGet 0 524 1677
assign 1 525 1678
heldGet 0 525 1678
assign 1 525 1679
synGet 0 525 1679
checkInheritance 2 526 1680
integrate 1 527 1681
assign 1 529 1687
new 0 529 1687
justParsedSet 1 529 1688
assign 1 533 1716
heldGet 0 533 1716
assign 1 533 1717
synGet 0 533 1717
assign 1 533 1718
def 1 533 1723
assign 1 534 1724
heldGet 0 534 1724
assign 1 534 1725
synGet 0 534 1725
return 1 534 1726
assign 1 536 1728
heldGet 0 536 1728
libNameSet 1 536 1729
assign 1 537 1730
heldGet 0 537 1730
assign 1 537 1731
extendsGet 0 537 1731
assign 1 537 1732
undef 1 537 1737
assign 1 538 1738
new 1 538 1738
assign 1 540 1741
classesGet 0 540 1741
assign 1 540 1742
heldGet 0 540 1742
assign 1 540 1743
extendsGet 0 540 1743
assign 1 540 1744
toString 0 540 1744
assign 1 540 1745
get 1 540 1745
assign 1 542 1746
def 1 542 1751
assign 1 543 1752
heldGet 0 543 1752
libNameSet 1 543 1753
assign 1 544 1754
getSyn 2 544 1754
assign 1 548 1757
heldGet 0 548 1757
assign 1 548 1758
extendsGet 0 548 1758
assign 1 548 1759
getSynNp 1 548 1759
assign 1 550 1761
new 2 550 1761
assign 1 552 1763
heldGet 0 552 1763
synSet 1 552 1764
assign 1 553 1765
heldGet 0 553 1765
assign 1 553 1766
namepathGet 0 553 1766
assign 1 553 1767
toString 0 553 1767
addSynClass 2 553 1768
return 1 554 1769
assign 1 558 1777
toString 0 558 1777
assign 1 559 1778
synClassesGet 0 559 1778
assign 1 559 1779
get 1 559 1779
assign 1 560 1780
def 1 560 1785
return 1 561 1786
assign 1 567 1788
emitterGet 0 567 1788
assign 1 567 1789
loadSyn 1 567 1789
addSynClass 2 568 1790
return 1 569 1791
assign 1 576 1795
undef 1 576 1800
assign 1 577 1801
new 1 577 1801
return 1 579 1803
assign 1 584 1882
new 1 584 1882
assign 1 585 1883
new 0 585 1883
assign 1 586 1884
emitterGet 0 586 1884
assign 1 587 1885
assign 1 588 1886
new 0 588 1886
assign 1 589 1887
shouldEmitGet 0 589 1887
put 1 589 1888
assign 1 0 1891
assign 1 0 1895
assign 1 0 1898
assign 1 592 1902
new 0 592 1902
assign 1 592 1903
toString 0 592 1903
assign 1 592 1904
add 1 592 1904
print 0 592 1905
assign 1 594 1907
assign 1 596 1908
fileGet 0 596 1908
assign 1 596 1909
readerGet 0 596 1909
assign 1 596 1910
open 0 596 1910
assign 1 596 1911
readBuffer 1 596 1911
assign 1 597 1912
fileGet 0 597 1912
assign 1 597 1913
readerGet 0 597 1913
close 0 597 1914
assign 1 598 1915
tokenize 1 598 1915
assign 1 602 1917
new 0 602 1917
echo 0 602 1918
assign 1 604 1920
outermostGet 0 604 1920
nodify 2 604 1921
assign 1 606 1923
new 0 606 1923
print 0 606 1924
assign 1 607 1925
new 2 607 1925
traverse 1 607 1926
assign 1 611 1929
new 0 611 1929
echo 0 611 1930
assign 1 613 1932
new 0 613 1932
traverse 1 613 1933
assign 1 615 1935
new 0 615 1935
print 0 615 1936
assign 1 616 1937
new 2 616 1937
traverse 1 616 1938
assign 1 619 1941
new 0 619 1941
echo 0 619 1942
assign 1 622 1944
new 0 622 1944
traverse 1 622 1945
contain 0 623 1946
assign 1 625 1948
new 0 625 1948
print 0 625 1949
assign 1 626 1950
new 2 626 1950
traverse 1 626 1951
assign 1 630 1954
new 0 630 1954
echo 0 630 1955
assign 1 632 1957
new 0 632 1957
traverse 1 632 1958
assign 1 634 1960
new 0 634 1960
print 0 634 1961
assign 1 635 1962
new 2 635 1962
traverse 1 635 1963
assign 1 639 1966
new 0 639 1966
echo 0 639 1967
assign 1 641 1969
new 0 641 1969
traverse 1 641 1970
assign 1 643 1972
new 0 643 1972
print 0 643 1973
assign 1 644 1974
new 2 644 1974
traverse 1 644 1975
assign 1 648 1978
new 0 648 1978
echo 0 648 1979
assign 1 650 1981
new 0 650 1981
traverse 1 650 1982
assign 1 652 1984
new 0 652 1984
print 0 652 1985
assign 1 653 1986
new 2 653 1986
traverse 1 653 1987
assign 1 657 1990
new 0 657 1990
echo 0 657 1991
assign 1 659 1993
new 0 659 1993
traverse 1 659 1994
assign 1 661 1996
new 0 661 1996
print 0 661 1997
assign 1 662 1998
new 2 662 1998
traverse 1 662 1999
assign 1 666 2002
new 0 666 2002
echo 0 666 2003
assign 1 668 2005
new 0 668 2005
traverse 1 668 2006
assign 1 670 2008
new 0 670 2008
print 0 670 2009
assign 1 671 2010
new 2 671 2010
traverse 1 671 2011
assign 1 675 2014
new 0 675 2014
echo 0 675 2015
assign 1 677 2017
new 0 677 2017
traverse 1 677 2018
assign 1 679 2020
new 0 679 2020
print 0 679 2021
assign 1 680 2022
new 2 680 2022
traverse 1 680 2023
assign 1 684 2026
new 0 684 2026
echo 0 684 2027
assign 1 686 2029
new 0 686 2029
traverse 1 686 2030
assign 1 688 2032
new 0 688 2032
print 0 688 2033
assign 1 689 2034
new 2 689 2034
traverse 1 689 2035
assign 1 692 2038
new 0 692 2038
echo 0 692 2039
assign 1 694 2041
new 0 694 2041
traverse 1 694 2042
assign 1 696 2044
new 0 696 2044
print 0 696 2045
assign 1 697 2046
new 2 697 2046
traverse 1 697 2047
assign 1 701 2050
new 0 701 2050
echo 0 701 2051
assign 1 702 2052
new 0 702 2052
print 0 702 2053
assign 1 704 2055
new 0 704 2055
traverse 1 704 2056
assign 1 0 2058
assign 1 0 2062
assign 1 0 2065
assign 1 706 2069
new 0 706 2069
print 0 706 2070
assign 1 707 2071
new 2 707 2071
traverse 1 707 2072
assign 1 709 2074
classesGet 0 709 2074
assign 1 709 2075
valueIteratorGet 0 709 2075
assign 1 709 2078
hasNextGet 0 709 2078
assign 1 710 2080
nextGet 0 710 2080
assign 1 712 2081
transUnitGet 0 712 2081
assign 1 713 2082
new 1 713 2082
assign 1 714 2083
TRANSUNITGet 0 714 2083
typenameSet 1 714 2084
assign 1 715 2085
new 0 715 2085
assign 1 716 2086
heldGet 0 716 2086
assign 1 716 2087
emitsGet 0 716 2087
emitsSet 1 716 2088
heldSet 1 717 2089
delete 0 718 2090
addValue 1 719 2091
copyLoc 1 720 2092
reInitContained 0 726 2114
assign 1 727 2115
containedGet 0 727 2115
assign 1 728 2116
new 0 728 2116
assign 1 729 2117
new 0 729 2117
assign 1 729 2118
crGet 0 729 2118
assign 1 730 2119
linkedListIteratorGet 0 730 2119
assign 1 730 2122
hasNextGet 0 730 2122
assign 1 731 2124
new 1 731 2124
assign 1 732 2125
nextGet 0 732 2125
heldSet 1 732 2126
nlcSet 1 733 2127
assign 1 734 2128
heldGet 0 734 2128
assign 1 734 2129
equals 1 734 2129
assign 1 735 2131
increment 0 735 2131
assign 1 737 2133
heldGet 0 737 2133
assign 1 737 2134
notEquals 1 737 2134
addValue 1 738 2136
containerSet 1 739 2137
assign 1 746 2192
new 0 746 2192
fromString 1 747 2193
assign 1 749 2194
new 1 749 2194
assign 1 750 2195
NAMEPATHGet 0 750 2195
typenameSet 1 750 2196
heldSet 1 751 2197
copyLoc 1 752 2198
assign 1 754 2199
new 0 754 2199
assign 1 755 2200
new 0 755 2200
nameSet 1 755 2201
assign 1 756 2202
new 0 756 2202
wasBoundSet 1 756 2203
assign 1 757 2204
new 0 757 2204
boundSet 1 757 2205
assign 1 758 2206
new 0 758 2206
isConstructSet 1 758 2207
assign 1 759 2208
new 0 759 2208
isLiteralSet 1 759 2209
assign 1 760 2210
heldGet 0 760 2210
literalValueSet 1 760 2211
addValue 1 762 2212
assign 1 764 2213
CALLGet 0 764 2213
typenameSet 1 764 2214
heldSet 1 765 2215
resolveNp 0 767 2216
assign 1 769 2217
new 0 769 2217
assign 1 769 2218
equals 1 769 2218
assign 1 0 2220
assign 1 769 2223
new 0 769 2223
assign 1 769 2224
equals 1 769 2224
assign 1 0 2226
assign 1 0 2229
assign 1 770 2233
priorPeerGet 0 770 2233
assign 1 771 2234
def 1 771 2239
assign 1 771 2240
typenameGet 0 771 2240
assign 1 771 2241
SUBTRACTGet 0 771 2241
assign 1 771 2242
equals 1 771 2242
assign 1 0 2244
assign 1 771 2247
typenameGet 0 771 2247
assign 1 771 2248
ADDGet 0 771 2248
assign 1 771 2249
equals 1 771 2249
assign 1 0 2251
assign 1 0 2254
assign 1 0 2258
assign 1 0 2261
assign 1 0 2265
assign 1 772 2268
priorPeerGet 0 772 2268
assign 1 773 2269
undef 1 773 2274
assign 1 0 2275
assign 1 773 2278
typenameGet 0 773 2278
assign 1 773 2279
CALLGet 0 773 2279
assign 1 773 2280
notEquals 1 773 2280
assign 1 773 2282
typenameGet 0 773 2282
assign 1 773 2283
IDGet 0 773 2283
assign 1 773 2284
notEquals 1 773 2284
assign 1 0 2286
assign 1 0 2289
assign 1 0 2293
assign 1 773 2296
typenameGet 0 773 2296
assign 1 773 2297
VARGet 0 773 2297
assign 1 773 2298
notEquals 1 773 2298
assign 1 0 2300
assign 1 0 2303
assign 1 0 2307
assign 1 773 2310
typenameGet 0 773 2310
assign 1 773 2311
ACCESSORGet 0 773 2311
assign 1 773 2312
notEquals 1 773 2312
assign 1 0 2314
assign 1 0 2317
assign 1 0 2321
assign 1 0 2324
assign 1 0 2327
assign 1 779 2331
heldGet 0 779 2331
assign 1 779 2332
literalValueGet 0 779 2332
assign 1 779 2333
add 1 779 2333
literalValueSet 1 779 2334
delete 0 780 2335
return 1 0 2342
return 1 0 2345
assign 1 0 2348
assign 1 0 2352
return 1 0 2356
return 1 0 2359
assign 1 0 2362
assign 1 0 2366
return 1 0 2370
return 1 0 2373
assign 1 0 2376
assign 1 0 2380
return 1 0 2384
return 1 0 2387
assign 1 0 2390
assign 1 0 2394
return 1 0 2398
return 1 0 2401
assign 1 0 2404
assign 1 0 2408
return 1 0 2412
return 1 0 2415
assign 1 0 2418
assign 1 0 2422
return 1 0 2426
return 1 0 2429
assign 1 0 2432
assign 1 0 2436
return 1 0 2440
return 1 0 2443
assign 1 0 2446
assign 1 0 2450
return 1 0 2454
return 1 0 2457
assign 1 0 2460
assign 1 0 2464
return 1 0 2468
return 1 0 2471
assign 1 0 2474
assign 1 0 2478
return 1 0 2482
return 1 0 2485
assign 1 0 2488
assign 1 0 2492
return 1 0 2496
return 1 0 2499
assign 1 0 2502
assign 1 0 2506
return 1 0 2510
return 1 0 2513
assign 1 0 2516
assign 1 0 2520
return 1 0 2524
return 1 0 2527
assign 1 0 2530
assign 1 0 2534
return 1 0 2538
return 1 0 2541
assign 1 0 2544
assign 1 0 2548
return 1 0 2552
return 1 0 2555
assign 1 0 2558
assign 1 0 2562
return 1 0 2566
return 1 0 2569
assign 1 0 2572
assign 1 0 2576
return 1 0 2580
return 1 0 2583
assign 1 0 2586
assign 1 0 2590
return 1 0 2594
return 1 0 2597
assign 1 0 2600
assign 1 0 2604
return 1 0 2608
return 1 0 2611
assign 1 0 2614
assign 1 0 2618
return 1 0 2622
return 1 0 2625
assign 1 0 2628
assign 1 0 2632
return 1 0 2636
return 1 0 2639
assign 1 0 2642
assign 1 0 2646
return 1 0 2650
return 1 0 2653
assign 1 0 2656
assign 1 0 2660
return 1 0 2664
return 1 0 2667
assign 1 0 2670
assign 1 0 2674
return 1 0 2678
return 1 0 2681
assign 1 0 2684
assign 1 0 2688
return 1 0 2692
return 1 0 2695
assign 1 0 2698
assign 1 0 2702
return 1 0 2706
return 1 0 2709
assign 1 0 2712
assign 1 0 2716
return 1 0 2720
return 1 0 2723
assign 1 0 2726
assign 1 0 2730
return 1 0 2734
return 1 0 2737
assign 1 0 2740
assign 1 0 2744
return 1 0 2748
return 1 0 2751
assign 1 0 2754
assign 1 0 2758
return 1 0 2762
return 1 0 2765
assign 1 0 2768
assign 1 0 2772
return 1 0 2776
return 1 0 2779
assign 1 0 2782
assign 1 0 2786
return 1 0 2790
return 1 0 2793
assign 1 0 2796
assign 1 0 2800
return 1 0 2804
return 1 0 2807
assign 1 0 2810
assign 1 0 2814
return 1 0 2818
return 1 0 2821
assign 1 0 2824
assign 1 0 2828
return 1 0 2832
return 1 0 2835
assign 1 0 2838
assign 1 0 2842
return 1 0 2846
return 1 0 2849
assign 1 0 2852
assign 1 0 2856
return 1 0 2860
return 1 0 2863
assign 1 0 2866
assign 1 0 2870
return 1 0 2874
return 1 0 2877
assign 1 0 2880
assign 1 0 2884
return 1 0 2888
return 1 0 2891
assign 1 0 2894
assign 1 0 2898
return 1 0 2902
return 1 0 2905
assign 1 0 2908
assign 1 0 2912
return 1 0 2916
return 1 0 2919
assign 1 0 2922
assign 1 0 2926
return 1 0 2930
return 1 0 2933
assign 1 0 2936
assign 1 0 2940
return 1 0 2944
return 1 0 2947
assign 1 0 2950
assign 1 0 2954
return 1 0 2958
return 1 0 2961
assign 1 0 2964
assign 1 0 2968
return 1 0 2972
return 1 0 2975
assign 1 0 2978
assign 1 0 2982
return 1 0 2986
return 1 0 2989
assign 1 0 2992
assign 1 0 2996
return 1 0 3000
return 1 0 3003
assign 1 0 3006
assign 1 0 3010
return 1 0 3014
return 1 0 3017
assign 1 0 3020
assign 1 0 3024
return 1 0 3028
return 1 0 3031
assign 1 0 3034
assign 1 0 3038
return 1 0 3042
return 1 0 3045
assign 1 0 3048
assign 1 0 3052
return 1 0 3056
return 1 0 3059
assign 1 0 3062
assign 1 0 3066
return 1 0 3070
return 1 0 3073
assign 1 0 3076
assign 1 0 3080
return 1 0 3084
return 1 0 3087
assign 1 0 3090
assign 1 0 3094
return 1 0 3098
return 1 0 3101
assign 1 0 3104
assign 1 0 3108
return 1 0 3112
return 1 0 3115
assign 1 0 3118
assign 1 0 3122
return 1 0 3126
return 1 0 3129
assign 1 0 3132
assign 1 0 3136
return 1 0 3140
return 1 0 3143
assign 1 0 3146
assign 1 0 3150
return 1 0 3154
return 1 0 3157
assign 1 0 3160
assign 1 0 3164
return 1 0 3168
return 1 0 3171
assign 1 0 3174
assign 1 0 3178
return 1 0 3182
return 1 0 3185
assign 1 0 3188
assign 1 0 3192
return 1 0 3196
return 1 0 3199
assign 1 0 3202
assign 1 0 3206
return 1 0 3210
return 1 0 3213
assign 1 0 3216
assign 1 0 3220
return 1 0 3224
return 1 0 3227
assign 1 0 3230
assign 1 0 3234
return 1 0 3238
return 1 0 3241
assign 1 0 3244
assign 1 0 3248
return 1 0 3252
return 1 0 3255
assign 1 0 3258
assign 1 0 3262
return 1 0 3266
return 1 0 3269
assign 1 0 3272
assign 1 0 3276
return 1 0 3280
return 1 0 3283
assign 1 0 3286
assign 1 0 3290
return 1 0 3294
return 1 0 3297
assign 1 0 3300
assign 1 0 3304
return 1 0 3308
return 1 0 3311
assign 1 0 3314
assign 1 0 3318
return 1 0 3322
assign 1 0 3325
assign 1 0 3329
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 631263480: return bem_printAllAstGet_0();
case -307934882: return bem_emitDataGet_0();
case 244389216: return bem_lctokGetDirect_0();
case 1632201993: return bem_emitCs_0();
case -2129525550: return bem_emitLangsGet_0();
case -1805894980: return bem_printAstGet_0();
case 109643107: return bem_emitCommonGet_0();
case -424411064: return bem_estrGetDirect_0();
case -474555346: return bem_parseEmitTimeGet_0();
case 55315205: return bem_many_0();
case -1335234506: return bem_mainNameGet_0();
case -467059293: return bem_emitDebugGet_0();
case -1895076500: return bem_emitFlagsGet_0();
case -177839859: return bem_emitFlagsGetDirect_0();
case 1529087321: return bem_runArgsGetDirect_0();
case -503484578: return bem_deployUsedLibrariesGetDirect_0();
case -1949130680: return bem_emitLibraryGetDirect_0();
case -13233810: return bem_emitterGet_0();
case -1734346150: return bem_saveSynsGet_0();
case -297120752: return bem_emitFileHeaderGet_0();
case -1787148900: return bem_doWhat_0();
case 469758438: return bem_makeArgsGet_0();
case -188682571: return bem_buildSucceededGetDirect_0();
case -591153026: return bem_parseEmitCompileTimeGet_0();
case 882343056: return bem_closeLibrariesGet_0();
case 67562015: return bem_parseTimeGet_0();
case 321704245: return bem_print_0();
case -1064755557: return bem_runGet_0();
case 230564947: return bem_deployLibraryGetDirect_0();
case -1521684920: return bem_runArgsGet_0();
case 1644000934: return bem_copy_0();
case 854706024: return bem_usedLibrarysGetDirect_0();
case 1600608854: return bem_libNameGetDirect_0();
case 148213830: return bem_deployPathGetDirect_0();
case -1202054618: return bem_platformGet_0();
case -1296101467: return bem_constantsGetDirect_0();
case 27924418: return bem_go_0();
case -583579372: return bem_printStepsGetDirect_0();
case 1485817050: return bem_deployFilesToGetDirect_0();
case 1257973479: return bem_printPlacesGetDirect_0();
case 185243029: return bem_usedLibrarysStrGetDirect_0();
case -1718401757: return bem_emitFileHeaderGetDirect_0();
case -42477772: return bem_config_0();
case 690769442: return bem_exeNameGetDirect_0();
case -1985849081: return bem_buildPathGetDirect_0();
case -1232907801: return bem_iteratorGet_0();
case 185302373: return bem_printStepsGet_0();
case 798936950: return bem_newlineGetDirect_0();
case 9520619: return bem_emitDataGetDirect_0();
case -1188114901: return bem_compilerProfileGetDirect_0();
case 1129503343: return bem_once_0();
case -1673481479: return bem_prepMakeGet_0();
case -194738007: return bem_emitDebugGetDirect_0();
case 1661770391: return bem_compilerGetDirect_0();
case -981539446: return bem_genOnlyGetDirect_0();
case -494221089: return bem_emitLangsGetDirect_0();
case -1561145816: return bem_hashGet_0();
case -415720580: return bem_includePathGet_0();
case 757381675: return bem_initLibsGetDirect_0();
case -1923075661: return bem_deployLibraryGet_0();
case -2031688241: return bem_readBufferGet_0();
case 357463953: return bem_exeNameGet_0();
case -1956001907: return bem_builtGet_0();
case 1124142948: return bem_nlGetDirect_0();
case -891854020: return bem_saveSynsGetDirect_0();
case 500247996: return bem_extIncludesGetDirect_0();
case -505496518: return bem_runGetDirect_0();
case -810084898: return bem_usedLibrarysStrGet_0();
case 502526738: return bem_twtokGet_0();
case 553679558: return bem_twtokGetDirect_0();
case 944233434: return bem_constantsGet_0();
case -369754200: return bem_readBufferGetDirect_0();
case -1520639640: return bem_parseEmitTimeGetDirect_0();
case -1437550559: return bem_serializeContents_0();
case -284999675: return bem_toAny_0();
case -1098348762: return bem_ntypesGetDirect_0();
case -47801541: return bem_parseGetDirect_0();
case -1521614037: return bem_loadSynsGetDirect_0();
case -1708201033: return bem_codeGet_0();
case -1605431584: return bem_tagGet_0();
case -823937862: return bem_builtGetDirect_0();
case -1928822514: return bem_parseGet_0();
case -1008423604: return bem_ccObjArgsGetDirect_0();
case 1555900706: return bem_makeNameGetDirect_0();
case 492490621: return bem_putLineNumbersInTraceGetDirect_0();
case 1000276965: return bem_emitLibraryGet_0();
case 354404201: return bem_extLinkObjectsGet_0();
case -1839591604: return bem_extLibsGetDirect_0();
case 1563017126: return bem_mainNameGetDirect_0();
case -536387110: return bem_buildSucceededGet_0();
case 1901839190: return bem_compilerGet_0();
case -1677419910: return bem_create_0();
case 2078981348: return bem_emitPathGet_0();
case 1436283825: return bem_compilerProfileGet_0();
case 969059915: return bem_makeGet_0();
case -165009373: return bem_buildPathGet_0();
case 883860234: return bem_nlGet_0();
case -1706925057: return bem_includePathGetDirect_0();
case -421430407: return bem_extIncludesGet_0();
case -961598175: return bem_parseEmitCompileTimeGetDirect_0();
case 1703226864: return bem_ntypesGet_0();
case 1969755699: return bem_codeGetDirect_0();
case -1069999097: return bem_printAstElementsGet_0();
case 893227398: return bem_doEmitGet_0();
case 1029860087: return bem_fieldNamesGet_0();
case 236256787: return bem_outputPlatformGetDirect_0();
case 1785814802: return bem_usedLibrarysGet_0();
case -534192686: return bem_closeLibrariesStrGet_0();
case -1983347108: return bem_makeNameGet_0();
case 57159682: return bem_new_0();
case -542899758: return bem_startTimeGetDirect_0();
case 1922786893: return bem_lctokGet_0();
case 1353002060: return bem_deployPathGet_0();
case 444831026: return bem_serializationIteratorGet_0();
case 205276375: return bem_printAstElementsGetDirect_0();
case 1649954317: return bem_serializeToString_0();
case 383545470: return bem_deployFilesFromGet_0();
case -1301404188: return bem_sharedEmitterGet_0();
case -2065374866: return bem_doEmitGetDirect_0();
case 1919322248: return bem_platformGetDirect_0();
case 417688898: return bem_ownProcessGetDirect_0();
case 188752658: return bem_argsGet_0();
case -621556218: return bem_toBuildGet_0();
case 330098532: return bem_linkLibArgsGetDirect_0();
case 1123770377: return bem_emitCommonGetDirect_0();
case 397775235: return bem_startTimeGet_0();
case 760007080: return bem_loadSynsGet_0();
case -442599398: return bem_outputPlatformGet_0();
case 764788698: return bem_prepMakeGetDirect_0();
case 2124052149: return bem_printPlacesGet_0();
case 602097122: return bem_deserializeClassNameGet_0();
case 487398647: return bem_deployFilesFromGetDirect_0();
case -1026557803: return bem_deployFilesToGet_0();
case -550278144: return bem_argsGetDirect_0();
case -1523912481: return bem_paramsGet_0();
case -1961015046: return bem_estrGet_0();
case -1922441883: return bem_main_0();
case -429437759: return bem_sourceFileNameGet_0();
case -1956130788: return bem_buildMessageGet_0();
case 2117639469: return bem_echo_0();
case 1227526961: return bem_putLineNumbersInTraceGet_0();
case -1989617382: return bem_linkLibArgsGet_0();
case 956758244: return bem_fromFileGetDirect_0();
case -1582692330: return bem_ownProcessGet_0();
case 339596740: return bem_newlineGet_0();
case 1732941339: return bem_paramsGetDirect_0();
case 1398421491: return bem_genOnlyGet_0();
case 1215735159: return bem_classNameGet_0();
case 1671388103: return bem_extLinkObjectsGetDirect_0();
case -93389731: return bem_closeLibrariesStrGetDirect_0();
case -2003573238: return bem_closeLibrariesGetDirect_0();
case 283886681: return bem_sharedEmitterGetDirect_0();
case 1454234600: return bem_toBuildGetDirect_0();
case 152841846: return bem_parseTimeGetDirect_0();
case -1935183779: return bem_fromFileGet_0();
case 727996638: return bem_emitPathGetDirect_0();
case 1533192785: return bem_deployUsedLibrariesGet_0();
case -1055677288: return bem_fieldIteratorGet_0();
case -1382688606: return bem_initLibsGet_0();
case -1043054088: return bem_makeArgsGetDirect_0();
case -1972402888: return bem_extLibsGet_0();
case -184952541: return bem_setClassesToWrite_0();
case 133189600: return bem_printAstGetDirect_0();
case 1686025605: return bem_makeGetDirect_0();
case -272583552: return bem_ccObjArgsGet_0();
case 1179854951: return bem_printAllAstGetDirect_0();
case -334018608: return bem_buildMessageGetDirect_0();
case -1203105958: return bem_libNameGet_0();
case -2069102102: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1728448569: return bem_deployFilesToSetDirect_1(bevd_0);
case -561364529: return bem_printStepsSet_1(bevd_0);
case -1304857269: return bem_extIncludesSetDirect_1(bevd_0);
case 822855165: return bem_runArgsSetDirect_1(bevd_0);
case -882242276: return bem_parseEmitTimeSet_1(bevd_0);
case 1318919709: return bem_loadSynsSetDirect_1(bevd_0);
case -2069020830: return bem_getSynNp_1(bevd_0);
case 493426545: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -198492590: return bem_codeSetDirect_1(bevd_0);
case -1549706318: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case 120103231: return bem_emitDebugSet_1(bevd_0);
case 955502469: return bem_compilerSet_1(bevd_0);
case 447945176: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case -1879295070: return bem_buildSucceededSet_1(bevd_0);
case 1789523895: return bem_compilerSetDirect_1(bevd_0);
case 932157770: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 1662358704: return bem_emitDataSetDirect_1(bevd_0);
case -1716397733: return bem_startTimeSetDirect_1(bevd_0);
case 1544916672: return bem_buildPathSetDirect_1(bevd_0);
case 198652707: return bem_printAstElementsSet_1(bevd_0);
case 877769510: return bem_closeLibrariesStrSet_1(bevd_0);
case -415239836: return bem_fromFileSet_1(bevd_0);
case -2025172189: return bem_deployFilesFromSet_1(bevd_0);
case -1034838950: return bem_constantsSetDirect_1(bevd_0);
case -786986296: return bem_printAllAstSet_1(bevd_0);
case 644416816: return bem_deployFilesToSet_1(bevd_0);
case -1329342000: return bem_genOnlySet_1(bevd_0);
case -705237263: return bem_buildMessageSet_1(bevd_0);
case 1506938426: return bem_sharedEmitterSet_1(bevd_0);
case -1235326351: return bem_ccObjArgsSetDirect_1(bevd_0);
case -646689348: return bem_emitLangsSetDirect_1(bevd_0);
case -473840251: return bem_startTimeSet_1(bevd_0);
case 208310867: return bem_def_1(bevd_0);
case -1747170673: return bem_includePathSet_1(bevd_0);
case -1068481658: return bem_saveSynsSetDirect_1(bevd_0);
case -2099297666: return bem_parseSet_1(bevd_0);
case -1818403248: return bem_argsSetDirect_1(bevd_0);
case 1813179248: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 46056795: return bem_builtSetDirect_1(bevd_0);
case 1462812127: return bem_doEmitSetDirect_1(bevd_0);
case 203054349: return bem_runArgsSet_1(bevd_0);
case 433230410: return bem_exeNameSetDirect_1(bevd_0);
case 298209628: return bem_sharedEmitterSetDirect_1(bevd_0);
case 117557200: return bem_emitPathSetDirect_1(bevd_0);
case -1440897629: return bem_newlineSetDirect_1(bevd_0);
case -1283955658: return bem_libNameSetDirect_1(bevd_0);
case -962669917: return bem_otherType_1(bevd_0);
case 1498159302: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case -1685922940: return bem_deployLibrarySet_1(bevd_0);
case -883252094: return bem_usedLibrarysSetDirect_1(bevd_0);
case -1948197175: return bem_makeArgsSet_1(bevd_0);
case -1558601067: return bem_constantsSet_1(bevd_0);
case -888489203: return bem_emitLangsSet_1(bevd_0);
case 2052282128: return bem_deployUsedLibrariesSet_1(bevd_0);
case 1540855798: return bem_toBuildSetDirect_1(bevd_0);
case -671996872: return bem_saveSynsSet_1(bevd_0);
case -1666721596: return bem_emitFlagsSet_1(bevd_0);
case -704793853: return bem_paramsSetDirect_1(bevd_0);
case -750174106: return bem_printAstSet_1(bevd_0);
case -100553382: return bem_mainNameSetDirect_1(bevd_0);
case 83643948: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -1520002353: return bem_argsSet_1(bevd_0);
case 958997033: return bem_linkLibArgsSet_1(bevd_0);
case 909992649: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -396594264: return bem_printPlacesSet_1(bevd_0);
case 1366553936: return bem_undef_1(bevd_0);
case 8614343: return bem_printPlacesSetDirect_1(bevd_0);
case -1750508180: return bem_emitPathSet_1(bevd_0);
case -1106927713: return bem_emitCommonSet_1(bevd_0);
case 2029035562: return bem_buildSyns_1(bevd_0);
case -543695710: return bem_lctokSetDirect_1(bevd_0);
case 1716846129: return bem_emitLibrarySet_1(bevd_0);
case -233207361: return bem_printAllAstSetDirect_1(bevd_0);
case 1904756767: return bem_usedLibrarysSet_1(bevd_0);
case -1388018291: return bem_printAstSetDirect_1(bevd_0);
case -226696980: return bem_deployPathSet_1(bevd_0);
case -761144837: return bem_ownProcessSetDirect_1(bevd_0);
case 584371238: return bem_makeSet_1(bevd_0);
case -1894782263: return bem_includePathSetDirect_1(bevd_0);
case -1835793511: return bem_usedLibrarysStrSet_1(bevd_0);
case 1514164893: return bem_exeNameSet_1(bevd_0);
case -1994374607: return bem_estrSetDirect_1(bevd_0);
case 696752602: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -734169532: return bem_fromFileSetDirect_1(bevd_0);
case 163809948: return bem_ownProcessSet_1(bevd_0);
case 1262714266: return bem_newlineSet_1(bevd_0);
case -1422291148: return bem_sameClass_1(bevd_0);
case 1643935689: return bem_emitCommonSetDirect_1(bevd_0);
case -1500834025: return bem_runSetDirect_1(bevd_0);
case 1580255152: return bem_buildSucceededSetDirect_1(bevd_0);
case -1747877071: return bem_outputPlatformSet_1(bevd_0);
case -747823936: return bem_extIncludesSet_1(bevd_0);
case -611311023: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -1417495042: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case 1719096215: return bem_defined_1(bevd_0);
case -407163712: return bem_parseTimeSet_1(bevd_0);
case 120666503: return bem_compilerProfileSet_1(bevd_0);
case -2061993063: return bem_buildPathSet_1(bevd_0);
case -2108780546: return bem_ccObjArgsSet_1(bevd_0);
case -705016654: return bem_estrSet_1(bevd_0);
case 642926153: return bem_platformSet_1(bevd_0);
case 1521573585: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 225897531: return bem_makeSetDirect_1(bevd_0);
case 1973740237: return bem_readBufferSetDirect_1(bevd_0);
case -2082778208: return bem_parseSetDirect_1(bevd_0);
case -217225832: return bem_doParse_1(bevd_0);
case 1045892633: return bem_makeNameSet_1(bevd_0);
case -97426471: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1802553133: return bem_makeArgsSetDirect_1(bevd_0);
case -711008143: return bem_toBuildSet_1(bevd_0);
case 91585422: return bem_initLibsSetDirect_1(bevd_0);
case -906359659: return bem_builtSet_1(bevd_0);
case 769918585: return bem_printStepsSetDirect_1(bevd_0);
case -385513824: return bem_twtokSetDirect_1(bevd_0);
case -1953347248: return bem_makeNameSetDirect_1(bevd_0);
case -1406286739: return bem_loadSynsSet_1(bevd_0);
case -1988005274: return bem_sameObject_1(bevd_0);
case 2640404: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case 32606599: return bem_compilerProfileSetDirect_1(bevd_0);
case -728959275: return bem_lctokSet_1(bevd_0);
case 881248692: return bem_printAstElementsSetDirect_1(bevd_0);
case 272411093: return bem_prepMakeSetDirect_1(bevd_0);
case 1493015022: return bem_emitFileHeaderSetDirect_1(bevd_0);
case 650080222: return bem_notEquals_1(bevd_0);
case -1423754632: return bem_parseTimeSetDirect_1(bevd_0);
case -1309335983: return bem_nlSetDirect_1(bevd_0);
case -1022512265: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -1489005688: return bem_closeLibrariesSet_1(bevd_0);
case -1993666957: return bem_genOnlySetDirect_1(bevd_0);
case 1321178191: return bem_doEmitSet_1(bevd_0);
case -76906288: return bem_initLibsSet_1(bevd_0);
case 624662303: return bem_emitDataSet_1(bevd_0);
case -224451708: return bem_codeSet_1(bevd_0);
case -517870741: return bem_emitDebugSetDirect_1(bevd_0);
case -1568665294: return bem_linkLibArgsSetDirect_1(bevd_0);
case 1484718882: return bem_copyTo_1(bevd_0);
case 843381471: return bem_ntypesSet_1(bevd_0);
case -1371697669: return bem_twtokSet_1(bevd_0);
case 224102430: return bem_ntypesSetDirect_1(bevd_0);
case -1381884491: return bem_nlSet_1(bevd_0);
case 1595627740: return bem_mainNameSet_1(bevd_0);
case -1241319759: return bem_emitFlagsSetDirect_1(bevd_0);
case -1931047766: return bem_runSet_1(bevd_0);
case -1174413455: return bem_deployPathSetDirect_1(bevd_0);
case 655154386: return bem_platformSetDirect_1(bevd_0);
case -132509534: return bem_libNameSet_1(bevd_0);
case -6633989: return bem_deployLibrarySetDirect_1(bevd_0);
case -1457737173: return bem_outputPlatformSetDirect_1(bevd_0);
case 1178220548: return bem_sameType_1(bevd_0);
case 1602696702: return bem_equals_1(bevd_0);
case -756536057: return bem_otherClass_1(bevd_0);
case -12618880: return bem_extLibsSet_1(bevd_0);
case -1410708208: return bem_parseEmitTimeSetDirect_1(bevd_0);
case 168189615: return bem_readBufferSet_1(bevd_0);
case -1116646040: return bem_deployFilesFromSetDirect_1(bevd_0);
case -1371671937: return bem_undefined_1(bevd_0);
case -1676351945: return bem_extLinkObjectsSet_1(bevd_0);
case 177452518: return bem_extLibsSetDirect_1(bevd_0);
case -717300679: return bem_buildMessageSetDirect_1(bevd_0);
case 201084610: return bem_emitFileHeaderSet_1(bevd_0);
case 1750203067: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case 733044562: return bem_emitLibrarySetDirect_1(bevd_0);
case 1795025002: return bem_closeLibrariesSetDirect_1(bevd_0);
case -740299402: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -782884876: return bem_paramsSet_1(bevd_0);
case 1941287373: return bem_prepMakeSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1007299832: return bem_getSyn_2(bevd_0, bevd_1);
case 1772861707: return bem_buildLiteral_2(bevd_0, bevd_1);
case -533377424: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -12510800: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 36705687: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -933258594: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -281973651: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1959141176: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220358760: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1950811501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
