package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x64,0x6F,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6C,0x6F,0x61,0x64,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x63,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_9_3_ContainerSet bevp_emitChecks;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_doMain;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_loadIds;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_ta_ph);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_singleCC = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_doMain = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevp_saveIds = be.BECS_Runtime.boolFalse;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevt_2_ta_ph = beva_name.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_2));
bevt_4_ta_ph = beva_name.bem_ends_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 100*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 100*/
 else /* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 100*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 101*/
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_ta_ph = beva_arg.bem_swap_2(bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bem_main_1(bevl__args);
bevt_1_ta_ph.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_ta_ph );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_ta_ph = bevp_params.bem_get_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 119*/ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 119*/ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 119*/
 else /* Line: 119*/ {
break;
} /* Line: 119*/
} /* Line: 119*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try /* Line: 128*/ {
bem_config_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 132*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(-869004384);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_5_BuildBuild_bels_9));
bevp_buildMessage = bevt_1_ta_ph.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 137*/
if (bevp_printSteps.bevi_bool)/* Line: 139*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 139*/ {
if (bevl_buildFailed.bevi_bool)/* Line: 139*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 139*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 139*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 139*/ {
bevp_buildMessage.bem_print_0();
} /* Line: 140*/
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bevp_platform.bemd_0(1227862986);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-596585082, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 146*/ {
} /* Line: 146*/
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_ec = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_ta_loop = null;
BEC_2_6_6_SystemObject bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_6_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_2_4_IOFile bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_2_4_IOFile bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_108_ta_ph = null;
BEC_2_4_6_TextString bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_9_4_ContainerList bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_5_4_LogicBool bevt_127_ta_ph = null;
BEC_2_9_4_ContainerList bevt_128_ta_ph = null;
BEC_2_9_4_ContainerList bevt_129_ta_ph = null;
BEC_2_6_6_SystemObject bevt_130_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_5_4_LogicBool bevt_133_ta_ph = null;
BEC_2_2_4_IOFile bevt_134_ta_ph = null;
BEC_2_2_4_IOFile bevt_135_ta_ph = null;
BEC_2_5_4_LogicBool bevt_136_ta_ph = null;
BEC_2_2_4_IOFile bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_6_ta_ph = bevp_params.bem_get_1(bevl_bkey);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 156*/ {
bevt_7_ta_ph = bevp_params.bem_get_1(bevl_bkey);
bevt_0_ta_loop = bevt_7_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 157*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 157*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(222701055);
bevt_10_ta_ph = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_10_ta_ph.bevi_bool) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 158*/ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_11_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_11_ta_ph);
} /* Line: 160*/
} /* Line: 158*/
 else /* Line: 157*/ {
break;
} /* Line: 157*/
} /* Line: 157*/
} /* Line: 157*/
bevt_14_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_nameGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_12_ta_ph = bevt_13_ta_ph.bem_equals_1(bevt_15_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 165*/ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 166*/
bevt_17_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_12));
bevt_16_ta_ph = bevp_params.bem_get_1(bevt_17_ta_ph);
bevp_libName = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_firstGet_0();
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_18_ta_ph = bevp_params.bem_has_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 169*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_20_ta_ph = bevp_params.bem_get_1(bevt_21_ta_ph);
bevp_exeName = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_firstGet_0();
} /* Line: 170*/
 else /* Line: 171*/ {
bevp_exeName = bevp_libName;
} /* Line: 172*/
bevt_25_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_26_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_24_ta_ph = bevp_params.bem_get_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_firstGet_0();
bevt_22_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_23_ta_ph);
bevp_buildPath = bevt_22_ta_ph.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevp_buildPath.bem_addStep_1(bevt_27_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_32_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_30_ta_ph = bevp_params.bem_get_2(bevt_31_ta_ph, bevt_32_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bem_firstGet_0();
bevt_28_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_29_ta_ph);
bevp_includePath = bevt_28_ta_ph.bem_pathGet_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_18));
bevt_37_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_nameGet_0();
bevt_34_ta_ph = bevp_params.bem_get_2(bevt_35_ta_ph, bevt_36_ta_ph);
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_33_ta_ph );
bevt_40_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_41_ta_ph = bevp_platform.bemd_0(1227862986);
bevt_39_ta_ph = bevp_params.bem_get_2(bevt_40_ta_ph, (BEC_2_4_6_TextString) bevt_41_ta_ph );
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_38_ta_ph );
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_43_ta_ph = bevp_params.bem_get_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_42_ta_ph = bevt_43_ta_ph.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_42_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_49_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_47_ta_ph = bevp_params.bem_get_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_46_ta_ph = bevt_47_ta_ph.bem_firstGet_0();
bevp_doMain = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_46_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_53_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_51_ta_ph = bevp_params.bem_get_2(bevt_52_ta_ph, bevt_53_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_50_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_57_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_55_ta_ph = bevp_params.bem_get_2(bevt_56_ta_ph, bevt_57_ta_ph);
bevt_54_ta_ph = bevt_55_ta_ph.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_54_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_26));
bevp_loadSyns = bevp_params.bem_get_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevp_loadIds = bevp_params.bem_get_1(bevt_59_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_28));
bevp_initLibs = bevp_params.bem_get_1(bevt_60_ta_ph);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_29));
bevt_61_ta_ph = bevp_params.bem_get_1(bevt_62_ta_ph);
bevp_mainName = (BEC_2_4_6_TextString) bevt_61_ta_ph.bem_firstGet_0();
bevt_64_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_30));
bevt_63_ta_ph = bevp_params.bem_get_1(bevt_64_ta_ph);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_firstGet_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_65_ta_ph);
if (bevp_usedLibrarysStr == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 191*/ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 192*/
bevt_67_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_67_ta_ph);
if (bevp_closeLibrariesStr == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 195*/ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 196*/
bevt_69_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_69_ta_ph);
if (bevp_deployFilesFrom == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 199*/ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 200*/
bevt_71_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_71_ta_ph);
if (bevp_deployFilesTo == null) {
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_72_ta_ph.bevi_bool)/* Line: 203*/ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 204*/
bevt_73_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_73_ta_ph);
if (bevp_extIncludes == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 207*/ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 208*/
bevt_75_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_75_ta_ph);
if (bevp_ccObjArgs == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 211*/ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 212*/
bevt_77_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_77_ta_ph);
if (bevp_extLibs == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 215*/ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 216*/
bevt_79_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_79_ta_ph);
if (bevp_linkLibArgs == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 219*/ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 220*/
bevt_81_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_81_ta_ph);
if (bevp_extLinkObjects == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 223*/ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 224*/
bevt_83_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_83_ta_ph);
if (bevp_emitFileHeader == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 227*/ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-858214401);
} /* Line: 228*/
bevt_85_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_85_ta_ph);
if (bevp_runArgs == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 231*/ {
bevp_runArgs = bevp_runArgs.bemd_0(-858214401);
} /* Line: 232*/
 else /* Line: 233*/ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 234*/
bevt_87_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_42));
bevt_88_ta_ph = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_87_ta_ph, bevt_88_ta_ph);
bevt_89_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_89_ta_ph, bevt_90_ta_ph);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_92_ta_ph);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_93_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_93_ta_ph);
if (bevl_pacm == null) {
bevt_94_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_94_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_96_ta_ph = bevl_pacm.bem_isEmptyGet_0();
if (bevt_96_ta_ph.bevi_bool) {
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 242*/
 else /* Line: 242*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 242*/ {
bevt_1_ta_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
/* Line: 243*/ {
bevt_97_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 243*/ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 244*/
 else /* Line: 243*/ {
break;
} /* Line: 243*/
} /* Line: 243*/
} /* Line: 243*/
bevt_98_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_98_ta_ph);
bevt_99_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_100_ta_ph);
bevt_101_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_101_ta_ph);
bevt_102_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_51));
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_102_ta_ph, bevt_103_ta_ph);
bevt_104_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_emitLangs = bevp_params.bem_get_1(bevt_104_ta_ph);
bevt_105_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevp_emitFlags = bevp_params.bem_get_1(bevt_105_ta_ph);
bevp_emitChecks = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (bevp_emitFlags == null) {
bevt_106_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_106_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_106_ta_ph.bevi_bool)/* Line: 255*/ {
bevt_2_ta_loop = bevp_emitFlags.bem_linkedListIteratorGet_0();
while (true)
/* Line: 256*/ {
bevt_107_ta_ph = bevt_2_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 256*/ {
bevl_ec = (BEC_2_4_6_TextString) bevt_2_ta_loop.bem_nextGet_0();
bevp_emitChecks.bem_addValue_1(bevl_ec);
} /* Line: 258*/
 else /* Line: 256*/ {
break;
} /* Line: 256*/
} /* Line: 256*/
} /* Line: 256*/
bevt_109_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_110_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_108_ta_ph = bevp_params.bem_get_2(bevt_109_ta_ph, bevt_110_ta_ph);
bevp_compiler = (BEC_2_4_6_TextString) bevt_108_ta_ph.bem_firstGet_0();
bevt_112_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_113_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_111_ta_ph = bevp_params.bem_get_2(bevt_112_ta_ph, bevt_113_ta_ph);
bevp_makeName = (BEC_2_4_6_TextString) bevt_111_ta_ph.bem_firstGet_0();
bevt_116_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_115_ta_ph = bevt_116_ta_ph.bem_add_1(bevp_makeName);
bevt_117_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_114_ta_ph = bevp_params.bem_get_2(bevt_115_ta_ph, bevt_117_ta_ph);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_114_ta_ph.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 271*/ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 272*/
 else /* Line: 273*/ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_59));
} /* Line: 274*/
bevt_121_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_60));
bevt_120_ta_ph = bevl_outLang.bem_add_1(bevt_121_ta_ph);
bevt_122_ta_ph = bevp_platform.bemd_0(1227862986);
bevt_119_ta_ph = bevt_120_ta_ph.bem_add_1(bevt_122_ta_ph);
bevl_platformSources = bevp_params.bem_get_1(bevt_119_ta_ph);
if (bevl_platformSources == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 282*/ {
bevt_124_ta_ph = bevp_params.bem_orderedGet_0();
bevt_124_ta_ph.bem_addAll_1(bevl_platformSources);
} /* Line: 283*/
bevt_126_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_125_ta_ph = bevl_outLang.bem_add_1(bevt_126_ta_ph);
bevl_langSources = bevp_params.bem_get_1(bevt_125_ta_ph);
if (bevl_langSources == null) {
bevt_127_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_127_ta_ph.bevi_bool)/* Line: 287*/ {
bevt_128_ta_ph = bevp_params.bem_orderedGet_0();
bevt_128_ta_ph.bem_addAll_1(bevl_langSources);
} /* Line: 288*/
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_129_ta_ph = bevp_params.bem_orderedGet_0();
bevt_3_ta_loop = bevt_129_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 292*/ {
bevt_130_ta_ph = bevt_3_ta_loop.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_130_ta_ph).bevi_bool)/* Line: 292*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_3_ta_loop.bemd_0(222701055);
bevt_131_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_131_ta_ph);
} /* Line: 293*/
 else /* Line: 292*/ {
break;
} /* Line: 292*/
} /* Line: 292*/
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(328761609);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_134_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_133_ta_ph = bevt_134_ta_ph.bem_existsGet_0();
if (bevt_133_ta_ph.bevi_bool) {
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_135_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_135_ta_ph.bem_makeDirs_0();
} /* Line: 301*/
if (bevp_emitFileHeader == null) {
bevt_136_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_136_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_136_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_137_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_137_ta_ph.bem_readerGet_0();
bevt_138_ta_ph = bevl_emr.bemd_0(1893796331);
bevp_emitFileHeader = bevt_138_ta_ph.bemd_0(-1809667792);
bevl_emr.bemd_0(1671439768);
} /* Line: 306*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_7_SystemClasses bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_toRet = bevt_0_ta_ph.bem_className_1(this);
bevt_2_ta_ph = bevl_toRet.bemd_1(129732167, bevp_nl);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_62));
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(129732167, bevt_3_ta_ph);
bevt_4_ta_ph = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_1_ta_ph.bemd_1(129732167, bevt_4_ta_ph);
bevt_6_ta_ph = bevl_toRet.bemd_1(129732167, bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_63));
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(129732167, bevt_7_ta_ph);
bevt_8_ta_ph = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_5_ta_ph.bemd_1(129732167, bevt_8_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 319*/ {
bevt_3_ta_ph = bevl_ci.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 319*/ {
bevl_clnode = bevl_ci.bemd_0(222701055);
bevt_5_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_ta_ph = bevl_clnode.bemd_0(930744442);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(1788222665);
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 321*/ {
bevt_10_ta_ph = bevl_clnode.bemd_0(930744442);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-333764509);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-869004384);
bevl_toEmit.bem_put_1(bevt_8_ta_ph);
bevt_11_ta_ph = bevp_emitData.bem_usedByGet_0();
bevt_14_ta_ph = bevl_clnode.bemd_0(930744442);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(-333764509);
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-869004384);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_ta_ph.bem_get_1(bevt_12_ta_ph);
if (bevl_usedBy == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_0_ta_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
/* Line: 325*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 325*/ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 326*/
 else /* Line: 325*/ {
break;
} /* Line: 325*/
} /* Line: 325*/
} /* Line: 325*/
bevt_17_ta_ph = bevp_emitData.bem_subClassesGet_0();
bevt_20_ta_ph = bevl_clnode.bemd_0(930744442);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-333764509);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-869004384);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_ta_ph.bem_get_1(bevt_18_ta_ph);
if (bevl_subClasses == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_1_ta_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
/* Line: 331*/ {
bevt_22_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 331*/ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 332*/
 else /* Line: 331*/ {
break;
} /* Line: 331*/
} /* Line: 331*/
} /* Line: 331*/
} /* Line: 330*/
} /* Line: 321*/
 else /* Line: 319*/ {
break;
} /* Line: 319*/
} /* Line: 319*/
bevt_23_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 337*/ {
bevt_24_ta_ph = bevl_ci.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 337*/ {
bevl_clnode = bevl_ci.bemd_0(222701055);
bevt_25_ta_ph = bevl_clnode.bemd_0(930744442);
bevt_29_ta_ph = bevl_clnode.bemd_0(930744442);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-333764509);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(-869004384);
bevt_26_ta_ph = bevl_toEmit.bem_has_1(bevt_27_ta_ph);
bevt_25_ta_ph.bemd_1(-2116309525, bevt_26_ta_ph);
} /* Line: 339*/
 else /* Line: 337*/ {
break;
} /* Line: 337*/
} /* Line: 337*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_9_SystemException bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (bevp_emitCommon == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 350*/ {
return bevp_emitCommon;
} /* Line: 351*/
if (bevp_emitLangs == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 356*/ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_64));
bevt_2_ta_ph = bevl_emitLang.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 358*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 359*/
 else /* Line: 358*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_4_ta_ph = bevl_emitLang.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 360*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 361*/
 else /* Line: 358*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_6_ta_ph = bevl_emitLang.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 362*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 363*/
 else /* Line: 358*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_67));
bevt_8_ta_ph = bevl_emitLang.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 364*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 365*/
 else /* Line: 366*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_68));
bevt_10_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_ta_ph);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 367*/
} /* Line: 358*/
} /* Line: 358*/
} /* Line: 358*/
return bevp_emitCommon;
} /* Line: 369*/
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_2_6_10_SystemSerializer bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_7_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_69));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_lsp);
bevt_0_ta_ph.bem_print_0();
bevt_2_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_ta_ph.bem_now_0();
bevt_4_ta_ph = bevl_synEmitPath.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_ta_ph.bemd_0(1893796331);
bevt_5_ta_ph = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_ta_ph.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevt_6_ta_ph.bem_addValue_1(bevl_scls);
bevt_8_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_now_0();
bevl_sse = bevt_7_ta_ph.bem_subtract_1(bevl_sst);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_sse);
bevt_9_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_22_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_25_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_26_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_27_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_28_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_29_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_30_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_43_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_82_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_3_MathInt bevt_98_ta_ph = null;
bevt_5_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_ta_ph.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 392*/ {
bevt_0_ta_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
/* Line: 393*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 393*/ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 394*/
 else /* Line: 393*/ {
break;
} /* Line: 393*/
} /* Line: 393*/
} /* Line: 393*/
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 398*/ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool)/* Line: 401*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_libName);
bevt_9_ta_ph.bem_print_0();
} /* Line: 402*/
} /* Line: 401*/
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_ta_loop = bevp_usedLibrarysStr.bemd_0(348103798);
while (true)
/* Line: 407*/ {
bevt_11_ta_ph = bevt_1_ta_loop.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 407*/ {
bevl_ups = bevt_1_ta_loop.bemd_0(222701055);
bevt_13_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 408*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 411*/
} /* Line: 408*/
 else /* Line: 407*/ {
break;
} /* Line: 407*/
} /* Line: 407*/
bevt_2_ta_loop = bevp_closeLibrariesStr.bemd_0(348103798);
while (true)
/* Line: 414*/ {
bevt_14_ta_ph = bevt_2_ta_loop.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 414*/ {
bevl_ups = bevt_2_ta_loop.bemd_0(222701055);
bevt_16_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_ta_ph.bevi_bool) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 415*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_ta_ph = bevl_pack.bemd_0(-234477660);
bevp_closeLibraries.bem_put_1(bevt_17_ta_ph);
} /* Line: 419*/
} /* Line: 415*/
 else /* Line: 414*/ {
break;
} /* Line: 414*/
} /* Line: 414*/
if (bevp_parse.bevi_bool)/* Line: 422*/ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
/* Line: 425*/ {
bevt_18_ta_ph = bevl_i.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 425*/ {
bevl_tb = bevl_i.bemd_0(222701055);
bevt_20_ta_ph = bevl_tb.bemd_0(-869004384);
bevt_19_ta_ph = bevl_built.bem_has_1(bevt_20_ta_ph);
if (!(bevt_19_ta_ph.bevi_bool))/* Line: 428*/ {
bevt_21_ta_ph = bevl_tb.bemd_0(-869004384);
bevl_built.bem_put_1(bevt_21_ta_ph);
bem_doParse_1(bevl_tb);
} /* Line: 430*/
} /* Line: 428*/
 else /* Line: 425*/ {
break;
} /* Line: 425*/
} /* Line: 425*/
bem_buildSyns_1(bevl_em);
} /* Line: 433*/
bevt_23_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_now_0();
bevp_parseTime = bevt_22_ta_ph.bem_subtract_1(bevp_startTime);
bevt_25_ta_ph = bem_emitCommonGet_0();
if (bevt_25_ta_ph == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_26_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_ta_ph.bem_now_0();
bevt_27_ta_ph = bem_emitCommonGet_0();
bevt_27_ta_ph.bem_doEmit_0();
bevt_29_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_28_ta_ph.bem_subtract_1(bevp_startTime);
bevt_31_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_now_0();
bevl_emitTime = bevt_30_ta_ph.bem_subtract_1(bevl_emitStart);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevp_parseTime);
bevt_32_ta_ph.bem_print_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_5_BuildBuild_bels_73));
bevt_34_ta_ph = bevt_35_ta_ph.bem_add_1(bevl_emitTime);
bevt_34_ta_ph.bem_print_0();
bevt_37_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_36_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_38_ta_ph;
} /* Line: 448*/
if (bevp_doEmit.bevi_bool)/* Line: 450*/ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(781360362);
bevt_39_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 454*/ {
bevt_40_ta_ph = bevl_ci.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 454*/ {
bevl_clnode = bevl_ci.bemd_0(222701055);
bevl_em.bemd_1(-971129821, bevl_clnode);
} /* Line: 456*/
 else /* Line: 454*/ {
break;
} /* Line: 454*/
} /* Line: 454*/
bevl_em.bemd_0(-1131335207);
bevl_em.bemd_0(-1921135131);
bevt_41_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 460*/ {
bevt_42_ta_ph = bevl_ci.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 460*/ {
bevl_clnode = bevl_ci.bemd_0(222701055);
bevl_em.bemd_1(1715121797, bevl_clnode);
} /* Line: 462*/
 else /* Line: 460*/ {
break;
} /* Line: 460*/
} /* Line: 460*/
} /* Line: 460*/
bevt_44_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_ta_ph = bevt_44_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_43_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 467*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_46_ta_ph = bevt_47_ta_ph.bem_add_1(bevp_parseTime);
bevt_46_ta_ph.bem_print_0();
} /* Line: 468*/
bevt_49_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_48_ta_ph.bem_print_0();
if (bevp_prepMake.bevi_bool)/* Line: 471*/ {
bevl_em.bemd_1(-379886685, bevp_deployLibrary);
} /* Line: 473*/
if (bevp_make.bevi_bool)/* Line: 476*/ {
if (bevp_genOnly.bevi_bool) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 477*/ {
bevl_em.bemd_1(1532850348, bevp_deployLibrary);
bevl_em.bemd_1(25503507, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool)/* Line: 480*/ {
bevt_3_ta_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
/* Line: 481*/ {
bevt_51_ta_ph = bevt_3_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 481*/ {
bevl_bp = bevt_3_ta_loop.bem_nextGet_0();
bevt_52_ta_ph = bevl_bp.bemd_0(781360362);
bevl_cpFrom = bevt_52_ta_ph.bemd_0(-2116415695);
bevt_53_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_ta_ph.bem_copy_0();
bevt_55_ta_ph = bevl_cpFrom.bemd_0(-1441866059);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(578450515);
bevl_cpTo.bemd_1(-190534467, bevt_54_ta_ph);
bevt_57_ta_ph = bevl_cpTo.bemd_0(-62375364);
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(-1315187608);
if (((BEC_2_5_4_LogicBool) bevt_56_ta_ph).bevi_bool)/* Line: 485*/ {
bevt_58_ta_ph = bevl_cpTo.bemd_0(-62375364);
bevt_58_ta_ph.bemd_0(-1174487466);
} /* Line: 486*/
bevt_61_ta_ph = bevl_cpTo.bemd_0(-62375364);
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(-1315187608);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(1528037607);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 488*/ {
bevt_62_ta_ph = bevl_cpFrom.bemd_0(-62375364);
bevt_63_ta_ph = bevl_cpTo.bemd_0(-62375364);
bevl_em.bemd_2(881556841, bevt_62_ta_ph, bevt_63_ta_ph);
} /* Line: 489*/
} /* Line: 488*/
 else /* Line: 481*/ {
break;
} /* Line: 481*/
} /* Line: 481*/
} /* Line: 481*/
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
/* Line: 496*/ {
bevt_64_ta_ph = bevl_fIter.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 496*/ {
bevt_65_ta_ph = bevl_tIter.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_65_ta_ph).bevi_bool)/* Line: 496*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 496*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 496*/
 else /* Line: 496*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 496*/ {
bevt_66_ta_ph = bevl_fIter.bemd_0(222701055);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_ta_ph );
bevt_71_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_ta_ph = bevt_71_ta_ph.bem_copy_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_toString_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_68_ta_ph = bevt_69_ta_ph.bem_add_1(bevt_72_ta_ph);
bevt_73_ta_ph = bevl_tIter.bemd_0(222701055);
bevt_67_ta_ph = bevt_68_ta_ph.bem_add_1(bevt_73_ta_ph);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_ta_ph);
bevt_75_ta_ph = bevl_cpTo.bemd_0(-62375364);
bevt_74_ta_ph = bevt_75_ta_ph.bemd_0(-1315187608);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 500*/ {
bevt_76_ta_ph = bevl_cpTo.bemd_0(-62375364);
bevt_76_ta_ph.bemd_0(-1174487466);
} /* Line: 501*/
bevt_79_ta_ph = bevl_cpTo.bemd_0(-62375364);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(-1315187608);
bevt_77_ta_ph = bevt_78_ta_ph.bemd_0(1528037607);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 503*/ {
bevt_80_ta_ph = bevl_cpFrom.bemd_0(-62375364);
bevt_81_ta_ph = bevl_cpTo.bemd_0(-62375364);
bevl_em.bemd_2(881556841, bevt_80_ta_ph, bevt_81_ta_ph);
} /* Line: 504*/
} /* Line: 503*/
 else /* Line: 496*/ {
break;
} /* Line: 496*/
} /* Line: 496*/
} /* Line: 496*/
} /* Line: 477*/
bevt_83_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_ta_ph = bevt_83_ta_ph.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 511*/ {
bevt_86_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_85_ta_ph = bevt_86_ta_ph.bem_add_1(bevp_parseTime);
bevt_85_ta_ph.bem_print_0();
} /* Line: 512*/
if (bevp_parseEmitTime == null) {
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 514*/ {
bevt_89_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_88_ta_ph = bevt_89_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_88_ta_ph.bem_print_0();
} /* Line: 515*/
if (bevp_parseEmitCompileTime == null) {
bevt_90_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_90_ta_ph.bevi_bool)/* Line: 517*/ {
bevt_92_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_5_BuildBuild_bels_75));
bevt_91_ta_ph = bevt_92_ta_ph.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_ta_ph.bem_print_0();
} /* Line: 518*/
if (bevp_run.bevi_bool)/* Line: 521*/ {
bevt_93_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_76));
bevt_93_ta_ph.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(1849829790, bevp_deployLibrary, bevp_runArgs);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_77));
bevt_95_ta_ph = bevt_96_ta_ph.bem_add_1(bevl_result);
bevt_97_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_78));
bevt_94_ta_ph = bevt_95_ta_ph.bem_add_1(bevt_97_ta_ph);
bevt_94_ta_ph.bem_print_0();
return bevl_result;
} /* Line: 525*/
bevt_98_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_98_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 531*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 531*/ {
bevl_kls = bevl_ci.bemd_0(222701055);
bevt_2_ta_ph = bevl_kls.bemd_0(930744442);
bevt_2_ta_ph.bemd_1(-294367564, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-294367564, bevp_libName);
} /* Line: 535*/
 else /* Line: 531*/ {
break;
} /* Line: 531*/
} /* Line: 531*/
bevt_3_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 537*/ {
bevt_4_ta_ph = bevl_ci.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 537*/ {
bevl_kls = bevl_ci.bemd_0(222701055);
bevt_5_ta_ph = bevl_kls.bemd_0(930744442);
bevl_syn = bevt_5_ta_ph.bemd_0(791283377);
bevl_syn.bemd_2(-491697273, this, bevl_kls);
bevl_syn.bemd_1(-109986608, this);
} /* Line: 541*/
 else /* Line: 537*/ {
break;
} /* Line: 537*/
} /* Line: 537*/
bevt_6_ta_ph = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
bevt_2_ta_ph = beva_klass.bemd_0(930744442);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(791283377);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 547*/ {
bevt_4_ta_ph = beva_klass.bemd_0(930744442);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(791283377);
return bevt_3_ta_ph;
} /* Line: 548*/
bevt_5_ta_ph = beva_klass.bemd_0(930744442);
bevt_5_ta_ph.bemd_1(-294367564, bevp_libName);
bevt_8_ta_ph = beva_klass.bemd_0(930744442);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-24153784);
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 551*/ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 552*/
 else /* Line: 553*/ {
bevt_9_ta_ph = bevp_emitData.bem_classesGet_0();
bevt_12_ta_ph = beva_klass.bemd_0(930744442);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-24153784);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-869004384);
bevl_pklass = bevt_9_ta_ph.bem_get_1(bevt_10_ta_ph);
if (bevl_pklass == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 556*/ {
bevt_14_ta_ph = bevl_pklass.bemd_0(930744442);
bevt_14_ta_ph.bemd_1(-294367564, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 558*/
 else /* Line: 559*/ {
bevt_16_ta_ph = beva_klass.bemd_0(930744442);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-24153784);
bevl_psyn = bem_getSynNp_1(bevt_15_ta_ph);
} /* Line: 562*/
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 564*/
bevt_17_ta_ph = beva_klass.bemd_0(930744442);
bevt_17_ta_ph.bemd_1(-608788502, bevl_syn);
bevt_20_ta_ph = beva_klass.bemd_0(930744442);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-333764509);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-869004384);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_ta_ph , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_nps = beva_np.bemd_0(-869004384);
bevt_0_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_ta_ph.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 574*/ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 575*/
bevt_2_ta_ph = bem_emitterGet_0();
bevl_syn = bevt_2_ta_ph.bemd_1(737101922, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_sharedEmitter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 590*/ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 591*/
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_ta_ph.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool)/* Line: 604*/ {
if (bevp_printSteps.bevi_bool)/* Line: 605*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 605*/ {
if (bevp_printPlaces.bevi_bool)/* Line: 605*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 605*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 605*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 605*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_79));
bevt_5_ta_ph = beva_toParse.bemd_0(-869004384);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_3_ta_ph.bem_print_0();
} /* Line: 606*/
bevp_fromFile = beva_toParse;
bevt_8_ta_ph = beva_toParse.bemd_0(-62375364);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(5937208);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(1893796331);
bevl_src = bevt_6_ta_ph.bemd_1(-197662393, bevp_readBuffer);
bevt_10_ta_ph = beva_toParse.bemd_0(-62375364);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(5937208);
bevt_9_ta_ph.bemd_0(1671439768);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool)/* Line: 617*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_80));
bevt_11_ta_ph.bem_echo_0();
} /* Line: 618*/
bevt_12_ta_ph = bevl_trans.bemd_0(-602878273);
bem_nodify_2(bevt_12_ta_ph, bevl_toks);
if (bevp_printAllAst.bevi_bool)/* Line: 621*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_5_BuildBuild_bels_81));
bevt_13_ta_ph.bem_print_0();
bevt_14_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_14_ta_ph);
} /* Line: 623*/
if (bevp_printSteps.bevi_bool)/* Line: 626*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_82));
bevt_15_ta_ph.bem_echo_0();
} /* Line: 627*/
bevt_16_ta_ph = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(455933055, bevt_16_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 630*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_83));
bevt_17_ta_ph.bem_print_0();
bevt_18_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_18_ta_ph);
} /* Line: 632*/
if (bevp_printSteps.bevi_bool)/* Line: 634*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_84));
bevt_19_ta_ph.bem_echo_0();
} /* Line: 635*/
bevt_20_ta_ph = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(455933055, bevt_20_ta_ph);
bevl_trans.bemd_0(-646768043);
if (bevp_printAllAst.bevi_bool)/* Line: 640*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_85));
bevt_21_ta_ph.bem_print_0();
bevt_22_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_22_ta_ph);
} /* Line: 642*/
if (bevp_printSteps.bevi_bool)/* Line: 645*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_86));
bevt_23_ta_ph.bem_echo_0();
} /* Line: 646*/
bevt_24_ta_ph = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(455933055, bevt_24_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 649*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_87));
bevt_25_ta_ph.bem_print_0();
bevt_26_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_26_ta_ph);
} /* Line: 651*/
if (bevp_printSteps.bevi_bool)/* Line: 654*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_88));
bevt_27_ta_ph.bem_echo_0();
} /* Line: 655*/
bevt_28_ta_ph = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(455933055, bevt_28_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 658*/ {
bevt_29_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_89));
bevt_29_ta_ph.bem_print_0();
bevt_30_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_30_ta_ph);
} /* Line: 660*/
if (bevp_printSteps.bevi_bool)/* Line: 663*/ {
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_90));
bevt_31_ta_ph.bem_echo_0();
} /* Line: 664*/
bevt_32_ta_ph = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(455933055, bevt_32_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 667*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_91));
bevt_33_ta_ph.bem_print_0();
bevt_34_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_34_ta_ph);
} /* Line: 669*/
if (bevp_printSteps.bevi_bool)/* Line: 672*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_92));
bevt_35_ta_ph.bem_echo_0();
} /* Line: 673*/
bevt_36_ta_ph = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(455933055, bevt_36_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 676*/ {
bevt_37_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_93));
bevt_37_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_38_ta_ph);
} /* Line: 678*/
if (bevp_printSteps.bevi_bool)/* Line: 681*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_94));
bevt_39_ta_ph.bem_echo_0();
} /* Line: 682*/
bevt_40_ta_ph = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(455933055, bevt_40_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 685*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_95));
bevt_41_ta_ph.bem_print_0();
bevt_42_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_42_ta_ph);
} /* Line: 687*/
if (bevp_printSteps.bevi_bool)/* Line: 690*/ {
bevt_43_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_96));
bevt_43_ta_ph.bem_echo_0();
} /* Line: 691*/
bevt_44_ta_ph = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(455933055, bevt_44_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 694*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_97));
bevt_45_ta_ph.bem_print_0();
bevt_46_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_46_ta_ph);
} /* Line: 696*/
if (bevp_printSteps.bevi_bool)/* Line: 699*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_98));
bevt_47_ta_ph.bem_echo_0();
} /* Line: 700*/
bevt_48_ta_ph = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(455933055, bevt_48_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 703*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_99));
bevt_49_ta_ph.bem_print_0();
bevt_50_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_50_ta_ph);
} /* Line: 705*/
if (bevp_printSteps.bevi_bool)/* Line: 707*/ {
bevt_51_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_100));
bevt_51_ta_ph.bem_echo_0();
} /* Line: 708*/
bevt_52_ta_ph = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(455933055, bevt_52_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 711*/ {
bevt_53_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_101));
bevt_53_ta_ph.bem_print_0();
bevt_54_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_54_ta_ph);
} /* Line: 713*/
if (bevp_printSteps.bevi_bool)/* Line: 716*/ {
bevt_55_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_102));
bevt_55_ta_ph.bem_echo_0();
bevt_56_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_103));
bevt_56_ta_ph.bem_print_0();
} /* Line: 718*/
bevt_57_ta_ph = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(455933055, bevt_57_ta_ph);
if (bevp_printAst.bevi_bool)/* Line: 721*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 721*/ {
if (bevp_printAllAst.bevi_bool)/* Line: 721*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 721*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 721*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 721*/ {
bevt_58_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_104));
bevt_58_ta_ph.bem_print_0();
bevt_59_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(455933055, bevt_59_ta_ph);
} /* Line: 723*/
bevt_60_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 725*/ {
bevt_61_ta_ph = bevl_ci.bemd_0(-1287695915);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 725*/ {
bevl_clnode = bevl_ci.bemd_0(222701055);
bevl_tunode = bevl_clnode.bemd_0(1004856184);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(1589203634, bevt_62_ta_ph);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_ta_ph = bevl_tunode.bemd_0(930744442);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(-2142320193);
bevl_ntt.bemd_1(-816170716, bevt_63_ta_ph);
bevl_ntunode.bemd_1(1369552551, bevl_ntt);
bevl_clnode.bemd_0(-1174487466);
bevl_ntunode.bemd_1(916647682, bevl_clnode);
bevl_ntunode.bemd_1(1588586606, bevl_clnode);
} /* Line: 736*/
 else /* Line: 725*/ {
break;
} /* Line: 725*/
} /* Line: 725*/
} /* Line: 725*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
beva_parnode.bemd_0(-365810823);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(-230108322);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_ta_ph.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 746*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 746*/ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_ta_ph = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(1369552551, bevt_2_ta_ph);
bevl_node.bemd_1(1856552968, bevl_nlc);
bevt_4_ta_ph = bevl_node.bemd_0(930744442);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(-596585082, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 750*/ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 751*/
bevt_6_ta_ph = bevl_node.bemd_0(930744442);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(887202309, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 753*/ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(1100726538, beva_parnode);
} /* Line: 755*/
} /* Line: 753*/
 else /* Line: 746*/ {
break;
} /* Line: 746*/
} /* Line: 746*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-1817847671, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(1589203634, bevt_5_ta_ph);
bevl_nlnpn.bemd_1(1369552551, bevl_nlnp);
bevl_nlnpn.bemd_1(1588586606, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevl_nlc.bemd_1(-891296957, bevt_6_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1948156188, bevt_7_ta_ph);
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(189401666, bevt_8_ta_ph);
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1065647277, bevt_9_ta_ph);
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1530081659, bevt_10_ta_ph);
bevt_11_ta_ph = beva_node.bemd_0(930744442);
bevl_nlc.bemd_1(1814323931, bevt_11_ta_ph);
beva_node.bemd_1(916647682, bevl_nlnpn);
bevt_12_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(1589203634, bevt_12_ta_ph);
beva_node.bemd_1(1369552551, bevl_nlc);
bevl_nlnpn.bemd_0(-189963946);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_105));
bevt_13_ta_ph = beva_tName.bemd_1(-596585082, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 785*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 785*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_106));
bevt_15_ta_ph = beva_tName.bemd_1(-596585082, bevt_16_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 785*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 785*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 785*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 785*/ {
bevl_pn = beva_node.bemd_0(1737755972);
if (bevl_pn == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 787*/ {
bevt_19_ta_ph = bevl_pn.bemd_0(-2138532370);
bevt_20_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-596585082, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 787*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 787*/ {
bevt_22_ta_ph = bevl_pn.bemd_0(-2138532370);
bevt_23_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(-596585082, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 787*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 787*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 787*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 787*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 787*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 787*/
 else /* Line: 787*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 787*/ {
bevl_pn2 = bevl_pn.bemd_0(1737755972);
if (bevl_pn2 == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 789*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_26_ta_ph = bevl_pn2.bemd_0(-2138532370);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(887202309, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_29_ta_ph = bevl_pn2.bemd_0(-2138532370);
bevt_30_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(887202309, bevt_30_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 789*/
 else /* Line: 789*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 789*/ {
bevt_32_ta_ph = bevl_pn2.bemd_0(-2138532370);
bevt_33_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bemd_1(887202309, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_31_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 789*/
 else /* Line: 789*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 789*/ {
bevt_35_ta_ph = bevl_pn2.bemd_0(-2138532370);
bevt_36_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(887202309, bevt_36_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 789*/
 else /* Line: 789*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 789*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 789*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 789*/ {
bevt_38_ta_ph = bevl_pn.bemd_0(930744442);
bevt_39_ta_ph = bevl_nlc.bemd_0(2055567174);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(129732167, bevt_39_ta_ph);
bevl_nlc.bemd_1(1814323931, bevt_37_ta_ph);
bevl_pn.bemd_0(-1174487466);
} /* Line: 796*/
} /* Line: 789*/
} /* Line: 787*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_platform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_outputPlatform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLibrary = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runArgs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_includePath = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_code = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGet_0() throws Throwable {
return bevp_emitChecks;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doMainGet_0() throws Throwable {
return bevp_doMain;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doMainSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doMain = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadIdsGet_0() throws Throwable {
return bevp_loadIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loadIds = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 52, 53, 54, 55, 57, 58, 59, 60, 61, 62, 63, 67, 69, 70, 71, 72, 72, 75, 78, 79, 80, 87, 88, 89, 90, 91, 92, 92, 100, 100, 100, 100, 0, 100, 100, 0, 0, 0, 0, 0, 101, 101, 103, 103, 107, 107, 107, 107, 111, 111, 112, 112, 112, 116, 117, 118, 118, 118, 118, 118, 119, 119, 119, 120, 119, 122, 126, 127, 129, 130, 131, 132, 134, 135, 136, 136, 137, 0, 0, 0, 140, 142, 146, 146, 146, 148, 153, 155, 156, 156, 156, 157, 157, 0, 157, 157, 158, 158, 158, 159, 160, 160, 165, 165, 165, 165, 166, 168, 168, 168, 169, 169, 170, 170, 170, 172, 174, 174, 174, 174, 174, 174, 175, 176, 176, 177, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 184, 184, 185, 185, 186, 186, 188, 188, 188, 189, 189, 189, 190, 190, 191, 191, 192, 194, 194, 195, 195, 196, 198, 198, 199, 199, 200, 202, 202, 203, 203, 204, 206, 206, 207, 207, 208, 210, 210, 211, 211, 212, 214, 214, 215, 215, 216, 218, 218, 219, 219, 220, 222, 222, 223, 223, 224, 226, 226, 227, 227, 228, 230, 230, 231, 231, 232, 234, 236, 236, 236, 237, 237, 237, 238, 238, 239, 239, 240, 241, 241, 242, 242, 242, 242, 242, 0, 0, 0, 243, 0, 243, 243, 244, 247, 247, 248, 248, 249, 249, 250, 250, 251, 251, 251, 252, 252, 253, 253, 254, 255, 255, 256, 0, 256, 256, 258, 261, 261, 261, 261, 262, 262, 262, 262, 263, 263, 263, 263, 263, 264, 265, 266, 267, 268, 271, 271, 272, 274, 281, 281, 281, 281, 281, 282, 282, 283, 283, 286, 286, 286, 287, 287, 288, 288, 291, 292, 292, 0, 292, 292, 293, 293, 295, 296, 297, 299, 300, 300, 300, 300, 301, 301, 303, 303, 304, 304, 305, 305, 306, 311, 311, 312, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 318, 319, 319, 319, 320, 321, 321, 321, 321, 322, 322, 322, 322, 323, 323, 323, 323, 323, 324, 324, 325, 0, 325, 325, 326, 329, 329, 329, 329, 329, 330, 330, 331, 0, 331, 331, 332, 337, 337, 337, 338, 339, 339, 339, 339, 339, 339, 346, 346, 350, 350, 351, 356, 356, 357, 358, 358, 359, 360, 360, 361, 362, 362, 363, 364, 364, 365, 367, 367, 367, 369, 371, 375, 377, 377, 377, 378, 378, 379, 379, 379, 380, 380, 381, 382, 382, 383, 383, 383, 384, 384, 384, 390, 390, 391, 392, 392, 393, 0, 393, 393, 394, 397, 398, 398, 399, 400, 402, 402, 402, 405, 407, 0, 407, 407, 408, 408, 408, 409, 410, 411, 414, 0, 414, 414, 415, 415, 415, 416, 417, 418, 419, 419, 424, 425, 425, 426, 428, 428, 429, 429, 430, 433, 436, 436, 436, 439, 439, 439, 441, 441, 442, 442, 443, 443, 443, 444, 444, 444, 445, 445, 445, 446, 446, 446, 447, 447, 447, 448, 448, 451, 452, 454, 454, 454, 455, 456, 458, 459, 460, 460, 460, 461, 462, 466, 466, 466, 467, 467, 468, 468, 468, 470, 470, 470, 473, 477, 477, 478, 479, 481, 0, 481, 481, 482, 482, 483, 483, 484, 484, 484, 485, 485, 486, 486, 488, 488, 488, 489, 489, 489, 493, 494, 496, 496, 0, 0, 0, 497, 497, 498, 498, 498, 498, 498, 498, 498, 498, 500, 500, 501, 501, 503, 503, 503, 504, 504, 504, 509, 509, 509, 511, 511, 512, 512, 512, 514, 514, 515, 515, 515, 517, 517, 518, 518, 518, 522, 522, 523, 524, 524, 524, 524, 524, 525, 527, 527, 531, 531, 531, 532, 533, 533, 534, 535, 537, 537, 537, 538, 539, 539, 540, 541, 543, 543, 547, 547, 547, 547, 548, 548, 548, 550, 550, 551, 551, 551, 551, 552, 554, 554, 554, 554, 554, 556, 556, 557, 557, 558, 562, 562, 562, 564, 566, 566, 567, 567, 567, 567, 568, 572, 573, 573, 574, 574, 575, 581, 581, 582, 583, 590, 590, 591, 593, 598, 599, 600, 601, 602, 603, 603, 0, 0, 0, 606, 606, 606, 606, 608, 610, 610, 610, 610, 611, 611, 611, 614, 618, 618, 620, 620, 622, 622, 623, 623, 627, 627, 629, 629, 631, 631, 632, 632, 635, 635, 638, 638, 639, 641, 641, 642, 642, 646, 646, 648, 648, 650, 650, 651, 651, 655, 655, 657, 657, 659, 659, 660, 660, 664, 664, 666, 666, 668, 668, 669, 669, 673, 673, 675, 675, 677, 677, 678, 678, 682, 682, 684, 684, 686, 686, 687, 687, 691, 691, 693, 693, 695, 695, 696, 696, 700, 700, 702, 702, 704, 704, 705, 705, 708, 708, 710, 710, 712, 712, 713, 713, 717, 717, 718, 718, 720, 720, 0, 0, 0, 722, 722, 723, 723, 725, 725, 725, 726, 728, 729, 730, 730, 731, 732, 732, 732, 733, 734, 735, 736, 742, 743, 744, 745, 745, 746, 746, 747, 748, 748, 749, 750, 750, 751, 753, 753, 754, 755, 762, 763, 765, 766, 766, 767, 768, 770, 771, 771, 772, 772, 773, 773, 774, 774, 775, 775, 776, 776, 778, 780, 780, 781, 783, 785, 785, 0, 785, 785, 0, 0, 786, 787, 787, 787, 787, 787, 0, 787, 787, 787, 0, 0, 0, 0, 0, 788, 789, 789, 0, 789, 789, 789, 789, 789, 789, 0, 0, 0, 789, 789, 789, 0, 0, 0, 789, 789, 789, 0, 0, 0, 0, 0, 795, 795, 795, 795, 796, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 237, 242, 243, 244, 246, 249, 250, 252, 255, 259, 262, 266, 269, 270, 272, 273, 279, 280, 281, 282, 289, 290, 291, 292, 293, 305, 306, 307, 308, 309, 310, 311, 312, 315, 320, 321, 322, 328, 336, 337, 339, 340, 341, 342, 346, 347, 348, 349, 350, 353, 357, 360, 364, 366, 372, 373, 374, 377, 529, 530, 531, 532, 537, 538, 539, 539, 542, 544, 545, 546, 551, 552, 553, 554, 562, 563, 564, 565, 567, 569, 570, 571, 572, 573, 575, 576, 577, 580, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 647, 648, 650, 651, 652, 657, 658, 660, 661, 662, 667, 668, 670, 671, 672, 677, 678, 680, 681, 682, 687, 688, 690, 691, 692, 697, 698, 700, 701, 702, 707, 708, 710, 711, 712, 717, 718, 720, 721, 722, 727, 728, 730, 731, 732, 737, 738, 740, 741, 742, 747, 748, 751, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 771, 772, 773, 778, 779, 782, 786, 789, 789, 792, 794, 795, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 823, 824, 824, 827, 829, 830, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 860, 861, 864, 866, 867, 868, 869, 870, 871, 876, 877, 878, 880, 881, 882, 883, 888, 889, 890, 892, 893, 894, 894, 897, 899, 900, 901, 907, 908, 909, 910, 911, 912, 913, 918, 919, 920, 922, 927, 928, 929, 930, 931, 932, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 999, 1000, 1001, 1004, 1006, 1007, 1008, 1009, 1010, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1026, 1027, 1027, 1030, 1032, 1033, 1040, 1041, 1042, 1043, 1044, 1045, 1050, 1051, 1051, 1054, 1056, 1057, 1070, 1071, 1074, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1092, 1093, 1109, 1114, 1115, 1117, 1122, 1123, 1124, 1125, 1127, 1130, 1131, 1133, 1136, 1137, 1139, 1142, 1143, 1145, 1148, 1149, 1150, 1155, 1157, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1316, 1317, 1318, 1319, 1324, 1325, 1325, 1328, 1330, 1331, 1338, 1339, 1344, 1345, 1346, 1348, 1349, 1350, 1353, 1354, 1354, 1357, 1359, 1360, 1361, 1366, 1367, 1368, 1369, 1376, 1376, 1379, 1381, 1382, 1383, 1388, 1389, 1390, 1391, 1392, 1393, 1401, 1402, 1405, 1407, 1408, 1409, 1411, 1412, 1413, 1420, 1422, 1423, 1424, 1425, 1426, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1455, 1456, 1457, 1458, 1461, 1463, 1464, 1470, 1471, 1472, 1473, 1476, 1478, 1479, 1486, 1487, 1488, 1489, 1494, 1495, 1496, 1497, 1499, 1500, 1501, 1503, 1506, 1511, 1512, 1513, 1515, 1515, 1518, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1531, 1532, 1534, 1535, 1536, 1538, 1539, 1540, 1548, 1549, 1552, 1554, 1556, 1559, 1563, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1579, 1580, 1582, 1583, 1584, 1586, 1587, 1588, 1597, 1598, 1599, 1600, 1605, 1606, 1607, 1608, 1610, 1615, 1616, 1617, 1618, 1620, 1625, 1626, 1627, 1628, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1641, 1642, 1655, 1656, 1659, 1661, 1662, 1663, 1664, 1665, 1671, 1672, 1675, 1677, 1678, 1679, 1680, 1681, 1687, 1688, 1716, 1717, 1718, 1723, 1724, 1725, 1726, 1728, 1729, 1730, 1731, 1732, 1737, 1738, 1741, 1742, 1743, 1744, 1745, 1746, 1751, 1752, 1753, 1754, 1757, 1758, 1759, 1761, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1777, 1778, 1779, 1780, 1785, 1786, 1788, 1789, 1790, 1791, 1795, 1800, 1801, 1803, 1882, 1883, 1884, 1885, 1886, 1887, 1888, 1891, 1895, 1898, 1902, 1903, 1904, 1905, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1917, 1918, 1920, 1921, 1923, 1924, 1925, 1926, 1929, 1930, 1932, 1933, 1935, 1936, 1937, 1938, 1941, 1942, 1944, 1945, 1946, 1948, 1949, 1950, 1951, 1954, 1955, 1957, 1958, 1960, 1961, 1962, 1963, 1966, 1967, 1969, 1970, 1972, 1973, 1974, 1975, 1978, 1979, 1981, 1982, 1984, 1985, 1986, 1987, 1990, 1991, 1993, 1994, 1996, 1997, 1998, 1999, 2002, 2003, 2005, 2006, 2008, 2009, 2010, 2011, 2014, 2015, 2017, 2018, 2020, 2021, 2022, 2023, 2026, 2027, 2029, 2030, 2032, 2033, 2034, 2035, 2038, 2039, 2041, 2042, 2044, 2045, 2046, 2047, 2050, 2051, 2052, 2053, 2055, 2056, 2058, 2062, 2065, 2069, 2070, 2071, 2072, 2074, 2075, 2078, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2114, 2115, 2116, 2117, 2118, 2119, 2122, 2124, 2125, 2126, 2127, 2128, 2129, 2131, 2133, 2134, 2136, 2137, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2220, 2223, 2224, 2226, 2229, 2233, 2234, 2239, 2240, 2241, 2242, 2244, 2247, 2248, 2249, 2251, 2254, 2258, 2261, 2265, 2268, 2269, 2274, 2275, 2278, 2279, 2280, 2282, 2283, 2284, 2286, 2289, 2293, 2296, 2297, 2298, 2300, 2303, 2307, 2310, 2311, 2312, 2314, 2317, 2321, 2324, 2327, 2331, 2332, 2333, 2334, 2335, 2342, 2345, 2349, 2352, 2356, 2359, 2363, 2366, 2370, 2373, 2377, 2380, 2384, 2387, 2391, 2394, 2398, 2401, 2405, 2408, 2412, 2415, 2419, 2422, 2426, 2429, 2433, 2436, 2440, 2443, 2447, 2450, 2454, 2457, 2461, 2464, 2468, 2471, 2475, 2478, 2482, 2485, 2489, 2492, 2496, 2499, 2503, 2506, 2510, 2513, 2517, 2520, 2524, 2527, 2531, 2534, 2538, 2541, 2545, 2548, 2552, 2555, 2559, 2562, 2566, 2569, 2573, 2576, 2580, 2583, 2587, 2590, 2594, 2597, 2601, 2604, 2608, 2611, 2615, 2618, 2622, 2625, 2629, 2632, 2636, 2639, 2643, 2646, 2650, 2653, 2657, 2660, 2664, 2667, 2671, 2674, 2678, 2681, 2685, 2688, 2692, 2695, 2699, 2702, 2706, 2709, 2713, 2716, 2720, 2723, 2727, 2730, 2734, 2737, 2741, 2744, 2748, 2751, 2755, 2758, 2762, 2765, 2769, 2772, 2776, 2779, 2783, 2786, 2790, 2793, 2797, 2800, 2804, 2807, 2811, 2814, 2818, 2821, 2825, 2828, 2832, 2835, 2839, 2842, 2846, 2849, 2853, 2856, 2860, 2863, 2867};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 197
new 0 50 197
assign 1 52 198
new 0 52 198
assign 1 53 199
new 0 53 199
assign 1 54 200
new 0 54 200
assign 1 55 201
new 0 55 201
assign 1 57 202
new 0 57 202
assign 1 58 203
new 0 58 203
assign 1 59 204
new 0 59 204
assign 1 60 205
new 0 60 205
assign 1 61 206
new 0 61 206
assign 1 62 207
new 0 62 207
assign 1 63 208
new 0 63 208
assign 1 67 209
new 0 67 209
assign 1 69 210
new 1 69 210
assign 1 70 211
ntypesGet 0 70 211
assign 1 71 212
twtokGet 0 71 212
assign 1 72 213
new 0 72 213
assign 1 72 214
new 1 72 214
assign 1 75 215
new 0 75 215
assign 1 78 216
new 0 78 216
assign 1 79 217
new 0 79 217
assign 1 80 218
new 0 80 218
assign 1 87 219
new 0 87 219
assign 1 88 220
new 0 88 220
assign 1 89 221
new 0 89 221
assign 1 90 222
new 0 90 222
assign 1 91 223
new 0 91 223
assign 1 92 224
new 0 92 224
assign 1 92 225
new 1 92 225
assign 1 100 237
def 1 100 242
assign 1 100 243
new 0 100 243
assign 1 100 244
equals 1 100 244
assign 1 0 246
assign 1 100 249
new 0 100 249
assign 1 100 250
ends 1 100 250
assign 1 0 252
assign 1 0 255
assign 1 0 259
assign 1 0 262
assign 1 0 266
assign 1 101 269
new 0 101 269
return 1 101 270
assign 1 103 272
new 0 103 272
return 1 103 273
assign 1 107 279
new 0 107 279
assign 1 107 280
new 0 107 280
assign 1 107 281
swap 2 107 281
return 1 107 282
assign 1 111 289
new 0 111 289
assign 1 111 290
argsGet 0 111 290
assign 1 112 291
new 0 112 291
assign 1 112 292
main 1 112 292
exit 1 112 293
assign 1 116 305
assign 1 117 306
new 1 117 306
assign 1 118 307
new 0 118 307
assign 1 118 308
new 0 118 308
assign 1 118 309
get 2 118 309
assign 1 118 310
firstGet 0 118 310
assign 1 118 311
new 1 118 311
assign 1 119 312
new 0 119 312
assign 1 119 315
lesser 1 119 320
assign 1 120 321
go 0 120 321
incrementValue 0 119 322
return 1 122 328
assign 1 126 336
new 0 126 336
assign 1 127 337
new 0 127 337
config 0 129 339
assign 1 130 340
new 0 130 340
assign 1 131 341
doWhat 0 131 341
assign 1 132 342
new 0 132 342
assign 1 134 346
toString 0 134 346
assign 1 135 347
new 0 135 347
assign 1 136 348
new 0 136 348
assign 1 136 349
add 1 136 349
assign 1 137 350
new 0 137 350
assign 1 0 353
assign 1 0 357
assign 1 0 360
print 0 140 364
return 1 142 366
assign 1 146 372
nameGet 0 146 372
assign 1 146 373
new 0 146 373
assign 1 146 374
equals 1 146 374
return 1 148 377
assign 1 153 529
new 0 153 529
assign 1 155 530
new 0 155 530
assign 1 156 531
get 1 156 531
assign 1 156 532
def 1 156 537
assign 1 157 538
get 1 157 538
assign 1 157 539
iteratorGet 0 0 539
assign 1 157 542
hasNextGet 0 157 542
assign 1 157 544
nextGet 0 157 544
assign 1 158 545
has 1 158 545
assign 1 158 546
not 0 158 551
put 1 159 552
assign 1 160 553
new 1 160 553
addFile 1 160 554
assign 1 165 562
new 0 165 562
assign 1 165 563
nameGet 0 165 563
assign 1 165 564
new 0 165 564
assign 1 165 565
equals 1 165 565
preProcessorSet 1 166 567
assign 1 168 569
new 0 168 569
assign 1 168 570
get 1 168 570
assign 1 168 571
firstGet 0 168 571
assign 1 169 572
new 0 169 572
assign 1 169 573
has 1 169 573
assign 1 170 575
new 0 170 575
assign 1 170 576
get 1 170 576
assign 1 170 577
firstGet 0 170 577
assign 1 172 580
assign 1 174 582
new 0 174 582
assign 1 174 583
new 0 174 583
assign 1 174 584
get 2 174 584
assign 1 174 585
firstGet 0 174 585
assign 1 174 586
new 1 174 586
assign 1 174 587
pathGet 0 174 587
addStep 1 175 588
assign 1 176 589
new 0 176 589
addStep 1 176 590
assign 1 177 591
new 0 177 591
assign 1 177 592
new 0 177 592
assign 1 177 593
get 2 177 593
assign 1 177 594
firstGet 0 177 594
assign 1 177 595
new 1 177 595
assign 1 177 596
pathGet 0 177 596
assign 1 178 597
new 0 178 597
assign 1 178 598
new 0 178 598
assign 1 178 599
nameGet 0 178 599
assign 1 178 600
get 2 178 600
assign 1 178 601
firstGet 0 178 601
assign 1 178 602
new 1 178 602
assign 1 179 603
new 0 179 603
assign 1 179 604
nameGet 0 179 604
assign 1 179 605
get 2 179 605
assign 1 179 606
firstGet 0 179 606
assign 1 179 607
new 1 179 607
assign 1 180 608
new 0 180 608
assign 1 180 609
new 0 180 609
assign 1 180 610
get 2 180 610
assign 1 180 611
firstGet 0 180 611
assign 1 180 612
new 1 180 612
assign 1 181 613
new 0 181 613
assign 1 181 614
new 0 181 614
assign 1 181 615
get 2 181 615
assign 1 181 616
firstGet 0 181 616
assign 1 181 617
new 1 181 617
assign 1 182 618
new 0 182 618
assign 1 182 619
new 0 182 619
assign 1 182 620
get 2 182 620
assign 1 182 621
firstGet 0 182 621
assign 1 182 622
new 1 182 622
assign 1 183 623
new 0 183 623
assign 1 183 624
new 0 183 624
assign 1 183 625
get 2 183 625
assign 1 183 626
firstGet 0 183 626
assign 1 183 627
new 1 183 627
assign 1 184 628
new 0 184 628
assign 1 184 629
get 1 184 629
assign 1 185 630
new 0 185 630
assign 1 185 631
get 1 185 631
assign 1 186 632
new 0 186 632
assign 1 186 633
get 1 186 633
assign 1 188 634
new 0 188 634
assign 1 188 635
get 1 188 635
assign 1 188 636
firstGet 0 188 636
assign 1 189 637
new 0 189 637
assign 1 189 638
get 1 189 638
assign 1 189 639
firstGet 0 189 639
assign 1 190 640
new 0 190 640
assign 1 190 641
get 1 190 641
assign 1 191 642
undef 1 191 647
assign 1 192 648
new 0 192 648
assign 1 194 650
new 0 194 650
assign 1 194 651
get 1 194 651
assign 1 195 652
undef 1 195 657
assign 1 196 658
new 0 196 658
assign 1 198 660
new 0 198 660
assign 1 198 661
get 1 198 661
assign 1 199 662
undef 1 199 667
assign 1 200 668
new 0 200 668
assign 1 202 670
new 0 202 670
assign 1 202 671
get 1 202 671
assign 1 203 672
undef 1 203 677
assign 1 204 678
new 0 204 678
assign 1 206 680
new 0 206 680
assign 1 206 681
get 1 206 681
assign 1 207 682
undef 1 207 687
assign 1 208 688
new 0 208 688
assign 1 210 690
new 0 210 690
assign 1 210 691
get 1 210 691
assign 1 211 692
undef 1 211 697
assign 1 212 698
new 0 212 698
assign 1 214 700
new 0 214 700
assign 1 214 701
get 1 214 701
assign 1 215 702
undef 1 215 707
assign 1 216 708
new 0 216 708
assign 1 218 710
new 0 218 710
assign 1 218 711
get 1 218 711
assign 1 219 712
undef 1 219 717
assign 1 220 718
new 0 220 718
assign 1 222 720
new 0 222 720
assign 1 222 721
get 1 222 721
assign 1 223 722
undef 1 223 727
assign 1 224 728
new 0 224 728
assign 1 226 730
new 0 226 730
assign 1 226 731
get 1 226 731
assign 1 227 732
def 1 227 737
assign 1 228 738
firstGet 0 228 738
assign 1 230 740
new 0 230 740
assign 1 230 741
get 1 230 741
assign 1 231 742
def 1 231 747
assign 1 232 748
firstGet 0 232 748
assign 1 234 751
new 0 234 751
assign 1 236 753
new 0 236 753
assign 1 236 754
new 0 236 754
assign 1 236 755
isTrue 2 236 755
assign 1 237 756
new 0 237 756
assign 1 237 757
new 0 237 757
assign 1 237 758
isTrue 2 237 758
assign 1 238 759
new 0 238 759
assign 1 238 760
isTrue 1 238 760
assign 1 239 761
new 0 239 761
assign 1 239 762
isTrue 1 239 762
assign 1 240 763
new 0 240 763
assign 1 241 764
new 0 241 764
assign 1 241 765
get 1 241 765
assign 1 242 766
def 1 242 771
assign 1 242 772
isEmptyGet 0 242 772
assign 1 242 773
not 0 242 778
assign 1 0 779
assign 1 0 782
assign 1 0 786
assign 1 243 789
linkedListIteratorGet 0 0 789
assign 1 243 792
hasNextGet 0 243 792
assign 1 243 794
nextGet 0 243 794
put 1 244 795
assign 1 247 802
new 0 247 802
assign 1 247 803
isTrue 1 247 803
assign 1 248 804
new 0 248 804
assign 1 248 805
isTrue 1 248 805
assign 1 249 806
new 0 249 806
assign 1 249 807
isTrue 1 249 807
assign 1 250 808
new 0 250 808
assign 1 250 809
isTrue 1 250 809
assign 1 251 810
new 0 251 810
assign 1 251 811
new 0 251 811
assign 1 251 812
isTrue 2 251 812
assign 1 252 813
new 0 252 813
assign 1 252 814
get 1 252 814
assign 1 253 815
new 0 253 815
assign 1 253 816
get 1 253 816
assign 1 254 817
new 0 254 817
assign 1 255 818
def 1 255 823
assign 1 256 824
linkedListIteratorGet 0 0 824
assign 1 256 827
hasNextGet 0 256 827
assign 1 256 829
nextGet 0 256 829
addValue 1 258 830
assign 1 261 837
new 0 261 837
assign 1 261 838
new 0 261 838
assign 1 261 839
get 2 261 839
assign 1 261 840
firstGet 0 261 840
assign 1 262 841
new 0 262 841
assign 1 262 842
new 0 262 842
assign 1 262 843
get 2 262 843
assign 1 262 844
firstGet 0 262 844
assign 1 263 845
new 0 263 845
assign 1 263 846
add 1 263 846
assign 1 263 847
new 0 263 847
assign 1 263 848
get 2 263 848
assign 1 263 849
firstGet 0 263 849
assign 1 264 850
new 0 264 850
assign 1 265 851
new 0 265 851
assign 1 266 852
new 0 266 852
assign 1 267 853
new 0 267 853
assign 1 268 854
new 0 268 854
assign 1 271 855
def 1 271 860
assign 1 272 861
firstGet 0 272 861
assign 1 274 864
new 0 274 864
assign 1 281 866
new 0 281 866
assign 1 281 867
add 1 281 867
assign 1 281 868
nameGet 0 281 868
assign 1 281 869
add 1 281 869
assign 1 281 870
get 1 281 870
assign 1 282 871
def 1 282 876
assign 1 283 877
orderedGet 0 283 877
addAll 1 283 878
assign 1 286 880
new 0 286 880
assign 1 286 881
add 1 286 881
assign 1 286 882
get 1 286 882
assign 1 287 883
def 1 287 888
assign 1 288 889
orderedGet 0 288 889
addAll 1 288 890
assign 1 291 892
new 0 291 892
assign 1 292 893
orderedGet 0 292 893
assign 1 292 894
iteratorGet 0 0 894
assign 1 292 897
hasNextGet 0 292 897
assign 1 292 899
nextGet 0 292 899
assign 1 293 900
new 1 293 900
addValue 1 293 901
assign 1 295 907
newlineGet 0 295 907
assign 1 296 908
assign 1 297 909
new 1 297 909
assign 1 299 910
copy 0 299 910
assign 1 300 911
fileGet 0 300 911
assign 1 300 912
existsGet 0 300 912
assign 1 300 913
not 0 300 918
assign 1 301 919
fileGet 0 301 919
makeDirs 0 301 920
assign 1 303 922
def 1 303 927
assign 1 304 928
new 1 304 928
assign 1 304 929
readerGet 0 304 929
assign 1 305 930
open 0 305 930
assign 1 305 931
readString 0 305 931
close 0 306 932
assign 1 311 947
new 0 311 947
assign 1 311 948
className 1 311 948
assign 1 312 949
add 1 312 949
assign 1 312 950
new 0 312 950
assign 1 312 951
add 1 312 951
assign 1 312 952
toString 0 312 952
assign 1 312 953
add 1 312 953
assign 1 313 954
add 1 313 954
assign 1 313 955
new 0 313 955
assign 1 313 956
add 1 313 956
assign 1 313 957
toString 0 313 957
assign 1 313 958
add 1 313 958
return 1 314 959
assign 1 318 999
new 0 318 999
assign 1 319 1000
classesGet 0 319 1000
assign 1 319 1001
valueIteratorGet 0 319 1001
assign 1 319 1004
hasNextGet 0 319 1004
assign 1 320 1006
nextGet 0 320 1006
assign 1 321 1007
shouldEmitGet 0 321 1007
assign 1 321 1008
heldGet 0 321 1008
assign 1 321 1009
fromFileGet 0 321 1009
assign 1 321 1010
has 1 321 1010
assign 1 322 1012
heldGet 0 322 1012
assign 1 322 1013
namepathGet 0 322 1013
assign 1 322 1014
toString 0 322 1014
put 1 322 1015
assign 1 323 1016
usedByGet 0 323 1016
assign 1 323 1017
heldGet 0 323 1017
assign 1 323 1018
namepathGet 0 323 1018
assign 1 323 1019
toString 0 323 1019
assign 1 323 1020
get 1 323 1020
assign 1 324 1021
def 1 324 1026
assign 1 325 1027
setIteratorGet 0 0 1027
assign 1 325 1030
hasNextGet 0 325 1030
assign 1 325 1032
nextGet 0 325 1032
put 1 326 1033
assign 1 329 1040
subClassesGet 0 329 1040
assign 1 329 1041
heldGet 0 329 1041
assign 1 329 1042
namepathGet 0 329 1042
assign 1 329 1043
toString 0 329 1043
assign 1 329 1044
get 1 329 1044
assign 1 330 1045
def 1 330 1050
assign 1 331 1051
setIteratorGet 0 0 1051
assign 1 331 1054
hasNextGet 0 331 1054
assign 1 331 1056
nextGet 0 331 1056
put 1 332 1057
assign 1 337 1070
classesGet 0 337 1070
assign 1 337 1071
valueIteratorGet 0 337 1071
assign 1 337 1074
hasNextGet 0 337 1074
assign 1 338 1076
nextGet 0 338 1076
assign 1 339 1077
heldGet 0 339 1077
assign 1 339 1078
heldGet 0 339 1078
assign 1 339 1079
namepathGet 0 339 1079
assign 1 339 1080
toString 0 339 1080
assign 1 339 1081
has 1 339 1081
shouldWriteSet 1 339 1082
assign 1 346 1092
new 0 346 1092
return 1 346 1093
assign 1 350 1109
def 1 350 1114
return 1 351 1115
assign 1 356 1117
def 1 356 1122
assign 1 357 1123
firstGet 0 357 1123
assign 1 358 1124
new 0 358 1124
assign 1 358 1125
equals 1 358 1125
assign 1 359 1127
new 1 359 1127
assign 1 360 1130
new 0 360 1130
assign 1 360 1131
equals 1 360 1131
assign 1 361 1133
new 1 361 1133
assign 1 362 1136
new 0 362 1136
assign 1 362 1137
equals 1 362 1137
assign 1 363 1139
new 1 363 1139
assign 1 364 1142
new 0 364 1142
assign 1 364 1143
equals 1 364 1143
assign 1 365 1145
new 1 365 1145
assign 1 367 1148
new 0 367 1148
assign 1 367 1149
new 1 367 1149
throw 1 367 1150
return 1 369 1155
return 1 371 1157
assign 1 375 1176
apNew 1 375 1176
assign 1 377 1177
new 0 377 1177
assign 1 377 1178
add 1 377 1178
print 0 377 1179
assign 1 378 1180
new 0 378 1180
assign 1 378 1181
now 0 378 1181
assign 1 379 1182
fileGet 0 379 1182
assign 1 379 1183
readerGet 0 379 1183
assign 1 379 1184
open 0 379 1184
assign 1 380 1185
new 0 380 1185
assign 1 380 1186
deserialize 1 380 1186
close 0 381 1187
assign 1 382 1188
synClassesGet 0 382 1188
addValue 1 382 1189
assign 1 383 1190
new 0 383 1190
assign 1 383 1191
now 0 383 1191
assign 1 383 1192
subtract 1 383 1192
assign 1 384 1193
new 0 384 1193
assign 1 384 1194
add 1 384 1194
print 0 384 1195
assign 1 390 1316
new 0 390 1316
assign 1 390 1317
now 0 390 1317
assign 1 391 1318
new 0 391 1318
assign 1 392 1319
def 1 392 1324
assign 1 393 1325
linkedListIteratorGet 0 0 1325
assign 1 393 1328
hasNextGet 0 393 1328
assign 1 393 1330
nextGet 0 393 1330
loadSyns 1 394 1331
assign 1 397 1338
emitterGet 0 397 1338
assign 1 398 1339
def 1 398 1344
assign 1 399 1345
new 4 399 1345
put 1 400 1346
assign 1 402 1348
new 0 402 1348
assign 1 402 1349
add 1 402 1349
print 0 402 1350
assign 1 405 1353
new 0 405 1353
assign 1 407 1354
iteratorGet 0 0 1354
assign 1 407 1357
hasNextGet 0 407 1357
assign 1 407 1359
nextGet 0 407 1359
assign 1 408 1360
has 1 408 1360
assign 1 408 1361
not 0 408 1366
put 1 409 1367
assign 1 410 1368
new 2 410 1368
addValue 1 411 1369
assign 1 414 1376
iteratorGet 0 0 1376
assign 1 414 1379
hasNextGet 0 414 1379
assign 1 414 1381
nextGet 0 414 1381
assign 1 415 1382
has 1 415 1382
assign 1 415 1383
not 0 415 1388
put 1 416 1389
assign 1 417 1390
new 2 417 1390
addValue 1 418 1391
assign 1 419 1392
libNameGet 0 419 1392
put 1 419 1393
assign 1 424 1401
new 0 424 1401
assign 1 425 1402
iteratorGet 0 425 1402
assign 1 425 1405
hasNextGet 0 425 1405
assign 1 426 1407
nextGet 0 426 1407
assign 1 428 1408
toString 0 428 1408
assign 1 428 1409
has 1 428 1409
assign 1 429 1411
toString 0 429 1411
put 1 429 1412
doParse 1 430 1413
buildSyns 1 433 1420
assign 1 436 1422
new 0 436 1422
assign 1 436 1423
now 0 436 1423
assign 1 436 1424
subtract 1 436 1424
assign 1 439 1425
emitCommonGet 0 439 1425
assign 1 439 1426
def 1 439 1431
assign 1 441 1432
new 0 441 1432
assign 1 441 1433
now 0 441 1433
assign 1 442 1434
emitCommonGet 0 442 1434
doEmit 0 442 1435
assign 1 443 1436
new 0 443 1436
assign 1 443 1437
now 0 443 1437
assign 1 443 1438
subtract 1 443 1438
assign 1 444 1439
new 0 444 1439
assign 1 444 1440
now 0 444 1440
assign 1 444 1441
subtract 1 444 1441
assign 1 445 1442
new 0 445 1442
assign 1 445 1443
add 1 445 1443
print 0 445 1444
assign 1 446 1445
new 0 446 1445
assign 1 446 1446
add 1 446 1446
print 0 446 1447
assign 1 447 1448
new 0 447 1448
assign 1 447 1449
add 1 447 1449
print 0 447 1450
assign 1 448 1451
new 0 448 1451
return 1 448 1452
setClassesToWrite 0 451 1455
libnameInfoGet 0 452 1456
assign 1 454 1457
classesGet 0 454 1457
assign 1 454 1458
valueIteratorGet 0 454 1458
assign 1 454 1461
hasNextGet 0 454 1461
assign 1 455 1463
nextGet 0 455 1463
doEmit 1 456 1464
emitMain 0 458 1470
emitCUInit 0 459 1471
assign 1 460 1472
classesGet 0 460 1472
assign 1 460 1473
valueIteratorGet 0 460 1473
assign 1 460 1476
hasNextGet 0 460 1476
assign 1 461 1478
nextGet 0 461 1478
emitSyn 1 462 1479
assign 1 466 1486
new 0 466 1486
assign 1 466 1487
now 0 466 1487
assign 1 466 1488
subtract 1 466 1488
assign 1 467 1489
def 1 467 1494
assign 1 468 1495
new 0 468 1495
assign 1 468 1496
add 1 468 1496
print 0 468 1497
assign 1 470 1499
new 0 470 1499
assign 1 470 1500
add 1 470 1500
print 0 470 1501
prepMake 1 473 1503
assign 1 477 1506
not 0 477 1511
make 1 478 1512
deployLibrary 1 479 1513
assign 1 481 1515
linkedListIteratorGet 0 0 1515
assign 1 481 1518
hasNextGet 0 481 1518
assign 1 481 1520
nextGet 0 481 1520
assign 1 482 1521
libnameInfoGet 0 482 1521
assign 1 482 1522
unitShlibGet 0 482 1522
assign 1 483 1523
emitPathGet 0 483 1523
assign 1 483 1524
copy 0 483 1524
assign 1 484 1525
stepsGet 0 484 1525
assign 1 484 1526
lastGet 0 484 1526
addStep 1 484 1527
assign 1 485 1528
fileGet 0 485 1528
assign 1 485 1529
existsGet 0 485 1529
assign 1 486 1531
fileGet 0 486 1531
delete 0 486 1532
assign 1 488 1534
fileGet 0 488 1534
assign 1 488 1535
existsGet 0 488 1535
assign 1 488 1536
not 0 488 1536
assign 1 489 1538
fileGet 0 489 1538
assign 1 489 1539
fileGet 0 489 1539
deployFile 2 489 1540
assign 1 493 1548
iteratorGet 0 493 1548
assign 1 494 1549
iteratorGet 0 494 1549
assign 1 496 1552
hasNextGet 0 496 1552
assign 1 496 1554
hasNextGet 0 496 1554
assign 1 0 1556
assign 1 0 1559
assign 1 0 1563
assign 1 497 1566
nextGet 0 497 1566
assign 1 497 1567
apNew 1 497 1567
assign 1 498 1568
emitPathGet 0 498 1568
assign 1 498 1569
copy 0 498 1569
assign 1 498 1570
toString 0 498 1570
assign 1 498 1571
new 0 498 1571
assign 1 498 1572
add 1 498 1572
assign 1 498 1573
nextGet 0 498 1573
assign 1 498 1574
add 1 498 1574
assign 1 498 1575
apNew 1 498 1575
assign 1 500 1576
fileGet 0 500 1576
assign 1 500 1577
existsGet 0 500 1577
assign 1 501 1579
fileGet 0 501 1579
delete 0 501 1580
assign 1 503 1582
fileGet 0 503 1582
assign 1 503 1583
existsGet 0 503 1583
assign 1 503 1584
not 0 503 1584
assign 1 504 1586
fileGet 0 504 1586
assign 1 504 1587
fileGet 0 504 1587
deployFile 2 504 1588
assign 1 509 1597
new 0 509 1597
assign 1 509 1598
now 0 509 1598
assign 1 509 1599
subtract 1 509 1599
assign 1 511 1600
def 1 511 1605
assign 1 512 1606
new 0 512 1606
assign 1 512 1607
add 1 512 1607
print 0 512 1608
assign 1 514 1610
def 1 514 1615
assign 1 515 1616
new 0 515 1616
assign 1 515 1617
add 1 515 1617
print 0 515 1618
assign 1 517 1620
def 1 517 1625
assign 1 518 1626
new 0 518 1626
assign 1 518 1627
add 1 518 1627
print 0 518 1628
assign 1 522 1631
new 0 522 1631
print 0 522 1632
assign 1 523 1633
run 2 523 1633
assign 1 524 1634
new 0 524 1634
assign 1 524 1635
add 1 524 1635
assign 1 524 1636
new 0 524 1636
assign 1 524 1637
add 1 524 1637
print 0 524 1638
return 1 525 1639
assign 1 527 1641
new 0 527 1641
return 1 527 1642
assign 1 531 1655
justParsedGet 0 531 1655
assign 1 531 1656
valueIteratorGet 0 531 1656
assign 1 531 1659
hasNextGet 0 531 1659
assign 1 532 1661
nextGet 0 532 1661
assign 1 533 1662
heldGet 0 533 1662
libNameSet 1 533 1663
assign 1 534 1664
getSyn 2 534 1664
libNameSet 1 535 1665
assign 1 537 1671
justParsedGet 0 537 1671
assign 1 537 1672
valueIteratorGet 0 537 1672
assign 1 537 1675
hasNextGet 0 537 1675
assign 1 538 1677
nextGet 0 538 1677
assign 1 539 1678
heldGet 0 539 1678
assign 1 539 1679
synGet 0 539 1679
checkInheritance 2 540 1680
integrate 1 541 1681
assign 1 543 1687
new 0 543 1687
justParsedSet 1 543 1688
assign 1 547 1716
heldGet 0 547 1716
assign 1 547 1717
synGet 0 547 1717
assign 1 547 1718
def 1 547 1723
assign 1 548 1724
heldGet 0 548 1724
assign 1 548 1725
synGet 0 548 1725
return 1 548 1726
assign 1 550 1728
heldGet 0 550 1728
libNameSet 1 550 1729
assign 1 551 1730
heldGet 0 551 1730
assign 1 551 1731
extendsGet 0 551 1731
assign 1 551 1732
undef 1 551 1737
assign 1 552 1738
new 1 552 1738
assign 1 554 1741
classesGet 0 554 1741
assign 1 554 1742
heldGet 0 554 1742
assign 1 554 1743
extendsGet 0 554 1743
assign 1 554 1744
toString 0 554 1744
assign 1 554 1745
get 1 554 1745
assign 1 556 1746
def 1 556 1751
assign 1 557 1752
heldGet 0 557 1752
libNameSet 1 557 1753
assign 1 558 1754
getSyn 2 558 1754
assign 1 562 1757
heldGet 0 562 1757
assign 1 562 1758
extendsGet 0 562 1758
assign 1 562 1759
getSynNp 1 562 1759
assign 1 564 1761
new 2 564 1761
assign 1 566 1763
heldGet 0 566 1763
synSet 1 566 1764
assign 1 567 1765
heldGet 0 567 1765
assign 1 567 1766
namepathGet 0 567 1766
assign 1 567 1767
toString 0 567 1767
addSynClass 2 567 1768
return 1 568 1769
assign 1 572 1777
toString 0 572 1777
assign 1 573 1778
synClassesGet 0 573 1778
assign 1 573 1779
get 1 573 1779
assign 1 574 1780
def 1 574 1785
return 1 575 1786
assign 1 581 1788
emitterGet 0 581 1788
assign 1 581 1789
loadSyn 1 581 1789
addSynClass 2 582 1790
return 1 583 1791
assign 1 590 1795
undef 1 590 1800
assign 1 591 1801
new 1 591 1801
return 1 593 1803
assign 1 598 1882
new 1 598 1882
assign 1 599 1883
new 0 599 1883
assign 1 600 1884
emitterGet 0 600 1884
assign 1 601 1885
assign 1 602 1886
new 0 602 1886
assign 1 603 1887
shouldEmitGet 0 603 1887
put 1 603 1888
assign 1 0 1891
assign 1 0 1895
assign 1 0 1898
assign 1 606 1902
new 0 606 1902
assign 1 606 1903
toString 0 606 1903
assign 1 606 1904
add 1 606 1904
print 0 606 1905
assign 1 608 1907
assign 1 610 1908
fileGet 0 610 1908
assign 1 610 1909
readerGet 0 610 1909
assign 1 610 1910
open 0 610 1910
assign 1 610 1911
readBuffer 1 610 1911
assign 1 611 1912
fileGet 0 611 1912
assign 1 611 1913
readerGet 0 611 1913
close 0 611 1914
assign 1 614 1915
tokenize 1 614 1915
assign 1 618 1917
new 0 618 1917
echo 0 618 1918
assign 1 620 1920
outermostGet 0 620 1920
nodify 2 620 1921
assign 1 622 1923
new 0 622 1923
print 0 622 1924
assign 1 623 1925
new 2 623 1925
traverse 1 623 1926
assign 1 627 1929
new 0 627 1929
echo 0 627 1930
assign 1 629 1932
new 0 629 1932
traverse 1 629 1933
assign 1 631 1935
new 0 631 1935
print 0 631 1936
assign 1 632 1937
new 2 632 1937
traverse 1 632 1938
assign 1 635 1941
new 0 635 1941
echo 0 635 1942
assign 1 638 1944
new 0 638 1944
traverse 1 638 1945
contain 0 639 1946
assign 1 641 1948
new 0 641 1948
print 0 641 1949
assign 1 642 1950
new 2 642 1950
traverse 1 642 1951
assign 1 646 1954
new 0 646 1954
echo 0 646 1955
assign 1 648 1957
new 0 648 1957
traverse 1 648 1958
assign 1 650 1960
new 0 650 1960
print 0 650 1961
assign 1 651 1962
new 2 651 1962
traverse 1 651 1963
assign 1 655 1966
new 0 655 1966
echo 0 655 1967
assign 1 657 1969
new 0 657 1969
traverse 1 657 1970
assign 1 659 1972
new 0 659 1972
print 0 659 1973
assign 1 660 1974
new 2 660 1974
traverse 1 660 1975
assign 1 664 1978
new 0 664 1978
echo 0 664 1979
assign 1 666 1981
new 0 666 1981
traverse 1 666 1982
assign 1 668 1984
new 0 668 1984
print 0 668 1985
assign 1 669 1986
new 2 669 1986
traverse 1 669 1987
assign 1 673 1990
new 0 673 1990
echo 0 673 1991
assign 1 675 1993
new 0 675 1993
traverse 1 675 1994
assign 1 677 1996
new 0 677 1996
print 0 677 1997
assign 1 678 1998
new 2 678 1998
traverse 1 678 1999
assign 1 682 2002
new 0 682 2002
echo 0 682 2003
assign 1 684 2005
new 0 684 2005
traverse 1 684 2006
assign 1 686 2008
new 0 686 2008
print 0 686 2009
assign 1 687 2010
new 2 687 2010
traverse 1 687 2011
assign 1 691 2014
new 0 691 2014
echo 0 691 2015
assign 1 693 2017
new 0 693 2017
traverse 1 693 2018
assign 1 695 2020
new 0 695 2020
print 0 695 2021
assign 1 696 2022
new 2 696 2022
traverse 1 696 2023
assign 1 700 2026
new 0 700 2026
echo 0 700 2027
assign 1 702 2029
new 0 702 2029
traverse 1 702 2030
assign 1 704 2032
new 0 704 2032
print 0 704 2033
assign 1 705 2034
new 2 705 2034
traverse 1 705 2035
assign 1 708 2038
new 0 708 2038
echo 0 708 2039
assign 1 710 2041
new 0 710 2041
traverse 1 710 2042
assign 1 712 2044
new 0 712 2044
print 0 712 2045
assign 1 713 2046
new 2 713 2046
traverse 1 713 2047
assign 1 717 2050
new 0 717 2050
echo 0 717 2051
assign 1 718 2052
new 0 718 2052
print 0 718 2053
assign 1 720 2055
new 0 720 2055
traverse 1 720 2056
assign 1 0 2058
assign 1 0 2062
assign 1 0 2065
assign 1 722 2069
new 0 722 2069
print 0 722 2070
assign 1 723 2071
new 2 723 2071
traverse 1 723 2072
assign 1 725 2074
classesGet 0 725 2074
assign 1 725 2075
valueIteratorGet 0 725 2075
assign 1 725 2078
hasNextGet 0 725 2078
assign 1 726 2080
nextGet 0 726 2080
assign 1 728 2081
transUnitGet 0 728 2081
assign 1 729 2082
new 1 729 2082
assign 1 730 2083
TRANSUNITGet 0 730 2083
typenameSet 1 730 2084
assign 1 731 2085
new 0 731 2085
assign 1 732 2086
heldGet 0 732 2086
assign 1 732 2087
emitsGet 0 732 2087
emitsSet 1 732 2088
heldSet 1 733 2089
delete 0 734 2090
addValue 1 735 2091
copyLoc 1 736 2092
reInitContained 0 742 2114
assign 1 743 2115
containedGet 0 743 2115
assign 1 744 2116
new 0 744 2116
assign 1 745 2117
new 0 745 2117
assign 1 745 2118
crGet 0 745 2118
assign 1 746 2119
linkedListIteratorGet 0 746 2119
assign 1 746 2122
hasNextGet 0 746 2122
assign 1 747 2124
new 1 747 2124
assign 1 748 2125
nextGet 0 748 2125
heldSet 1 748 2126
nlcSet 1 749 2127
assign 1 750 2128
heldGet 0 750 2128
assign 1 750 2129
equals 1 750 2129
assign 1 751 2131
increment 0 751 2131
assign 1 753 2133
heldGet 0 753 2133
assign 1 753 2134
notEquals 1 753 2134
addValue 1 754 2136
containerSet 1 755 2137
assign 1 762 2192
new 0 762 2192
fromString 1 763 2193
assign 1 765 2194
new 1 765 2194
assign 1 766 2195
NAMEPATHGet 0 766 2195
typenameSet 1 766 2196
heldSet 1 767 2197
copyLoc 1 768 2198
assign 1 770 2199
new 0 770 2199
assign 1 771 2200
new 0 771 2200
nameSet 1 771 2201
assign 1 772 2202
new 0 772 2202
wasBoundSet 1 772 2203
assign 1 773 2204
new 0 773 2204
boundSet 1 773 2205
assign 1 774 2206
new 0 774 2206
isConstructSet 1 774 2207
assign 1 775 2208
new 0 775 2208
isLiteralSet 1 775 2209
assign 1 776 2210
heldGet 0 776 2210
literalValueSet 1 776 2211
addValue 1 778 2212
assign 1 780 2213
CALLGet 0 780 2213
typenameSet 1 780 2214
heldSet 1 781 2215
resolveNp 0 783 2216
assign 1 785 2217
new 0 785 2217
assign 1 785 2218
equals 1 785 2218
assign 1 0 2220
assign 1 785 2223
new 0 785 2223
assign 1 785 2224
equals 1 785 2224
assign 1 0 2226
assign 1 0 2229
assign 1 786 2233
priorPeerGet 0 786 2233
assign 1 787 2234
def 1 787 2239
assign 1 787 2240
typenameGet 0 787 2240
assign 1 787 2241
SUBTRACTGet 0 787 2241
assign 1 787 2242
equals 1 787 2242
assign 1 0 2244
assign 1 787 2247
typenameGet 0 787 2247
assign 1 787 2248
ADDGet 0 787 2248
assign 1 787 2249
equals 1 787 2249
assign 1 0 2251
assign 1 0 2254
assign 1 0 2258
assign 1 0 2261
assign 1 0 2265
assign 1 788 2268
priorPeerGet 0 788 2268
assign 1 789 2269
undef 1 789 2274
assign 1 0 2275
assign 1 789 2278
typenameGet 0 789 2278
assign 1 789 2279
CALLGet 0 789 2279
assign 1 789 2280
notEquals 1 789 2280
assign 1 789 2282
typenameGet 0 789 2282
assign 1 789 2283
IDGet 0 789 2283
assign 1 789 2284
notEquals 1 789 2284
assign 1 0 2286
assign 1 0 2289
assign 1 0 2293
assign 1 789 2296
typenameGet 0 789 2296
assign 1 789 2297
VARGet 0 789 2297
assign 1 789 2298
notEquals 1 789 2298
assign 1 0 2300
assign 1 0 2303
assign 1 0 2307
assign 1 789 2310
typenameGet 0 789 2310
assign 1 789 2311
ACCESSORGet 0 789 2311
assign 1 789 2312
notEquals 1 789 2312
assign 1 0 2314
assign 1 0 2317
assign 1 0 2321
assign 1 0 2324
assign 1 0 2327
assign 1 795 2331
heldGet 0 795 2331
assign 1 795 2332
literalValueGet 0 795 2332
assign 1 795 2333
add 1 795 2333
literalValueSet 1 795 2334
delete 0 796 2335
return 1 0 2342
assign 1 0 2345
return 1 0 2349
assign 1 0 2352
return 1 0 2356
assign 1 0 2359
return 1 0 2363
assign 1 0 2366
return 1 0 2370
assign 1 0 2373
return 1 0 2377
assign 1 0 2380
return 1 0 2384
assign 1 0 2387
return 1 0 2391
assign 1 0 2394
return 1 0 2398
assign 1 0 2401
return 1 0 2405
assign 1 0 2408
return 1 0 2412
assign 1 0 2415
return 1 0 2419
assign 1 0 2422
return 1 0 2426
assign 1 0 2429
return 1 0 2433
assign 1 0 2436
return 1 0 2440
assign 1 0 2443
return 1 0 2447
assign 1 0 2450
return 1 0 2454
assign 1 0 2457
return 1 0 2461
assign 1 0 2464
return 1 0 2468
assign 1 0 2471
return 1 0 2475
assign 1 0 2478
return 1 0 2482
assign 1 0 2485
return 1 0 2489
assign 1 0 2492
return 1 0 2496
assign 1 0 2499
return 1 0 2503
assign 1 0 2506
return 1 0 2510
assign 1 0 2513
return 1 0 2517
assign 1 0 2520
return 1 0 2524
assign 1 0 2527
return 1 0 2531
assign 1 0 2534
return 1 0 2538
assign 1 0 2541
return 1 0 2545
assign 1 0 2548
return 1 0 2552
assign 1 0 2555
return 1 0 2559
assign 1 0 2562
return 1 0 2566
assign 1 0 2569
return 1 0 2573
assign 1 0 2576
return 1 0 2580
assign 1 0 2583
return 1 0 2587
assign 1 0 2590
return 1 0 2594
assign 1 0 2597
return 1 0 2601
assign 1 0 2604
return 1 0 2608
assign 1 0 2611
return 1 0 2615
assign 1 0 2618
return 1 0 2622
assign 1 0 2625
return 1 0 2629
assign 1 0 2632
return 1 0 2636
assign 1 0 2639
return 1 0 2643
assign 1 0 2646
return 1 0 2650
assign 1 0 2653
return 1 0 2657
assign 1 0 2660
return 1 0 2664
assign 1 0 2667
return 1 0 2671
assign 1 0 2674
return 1 0 2678
assign 1 0 2681
return 1 0 2685
assign 1 0 2688
return 1 0 2692
assign 1 0 2695
return 1 0 2699
assign 1 0 2702
return 1 0 2706
assign 1 0 2709
return 1 0 2713
assign 1 0 2716
return 1 0 2720
assign 1 0 2723
return 1 0 2727
assign 1 0 2730
return 1 0 2734
assign 1 0 2737
return 1 0 2741
assign 1 0 2744
return 1 0 2748
assign 1 0 2751
return 1 0 2755
assign 1 0 2758
return 1 0 2762
assign 1 0 2765
return 1 0 2769
assign 1 0 2772
return 1 0 2776
assign 1 0 2779
return 1 0 2783
assign 1 0 2786
return 1 0 2790
assign 1 0 2793
return 1 0 2797
assign 1 0 2800
return 1 0 2804
assign 1 0 2807
return 1 0 2811
assign 1 0 2814
return 1 0 2818
assign 1 0 2821
return 1 0 2825
assign 1 0 2828
return 1 0 2832
assign 1 0 2835
return 1 0 2839
assign 1 0 2842
return 1 0 2846
assign 1 0 2849
return 1 0 2853
assign 1 0 2856
return 1 0 2860
assign 1 0 2863
assign 1 0 2867
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -213871784: return bem_main_0();
case 1367849082: return bem_emitLibraryGet_0();
case -1827562800: return bem_genOnlyGet_0();
case 1981425060: return bem_deployFilesFromGet_0();
case -1418150739: return bem_runGet_0();
case -1863726681: return bem_codeGet_0();
case -869004384: return bem_toString_0();
case 993904896: return bem_copy_0();
case 1838764507: return bem_buildMessageGet_0();
case -681366931: return bem_deployFilesToGet_0();
case 485745298: return bem_new_0();
case 1827894140: return bem_platformGet_0();
case 1336416205: return bem_exeNameGet_0();
case -1903210237: return bem_usedLibrarysStrGet_0();
case -1584431041: return bem_deployPathGet_0();
case -1356690296: return bem_lctokGet_0();
case 1042232146: return bem_builtGet_0();
case 793136173: return bem_deployUsedLibrariesGet_0();
case -1392356647: return bem_nlGet_0();
case 740041886: return bem_emitFileHeaderGet_0();
case 1618470773: return bem_emitCommonGet_0();
case -796664937: return bem_buildSucceededGet_0();
case 1484837023: return bem_parseEmitTimeGet_0();
case -234477660: return bem_libNameGet_0();
case 122069842: return bem_extLinkObjectsGet_0();
case 1802817659: return bem_loadSynsGet_0();
case 348103798: return bem_iteratorGet_0();
case -14706576: return bem_argsGet_0();
case -892809281: return bem_usedLibrarysGet_0();
case -960606498: return bem_ccObjArgsGet_0();
case -481150038: return bem_initLibsGet_0();
case 740076125: return bem_constantsGet_0();
case 1839686589: return bem_doWhat_0();
case -1707390999: return bem_sharedEmitterGet_0();
case -932245661: return bem_printAstGet_0();
case 170994837: return bem_outputPlatformGet_0();
case 911462251: return bem_printStepsGet_0();
case 4111327: return bem_emitFlagsGet_0();
case -946224299: return bem_singleCCGet_0();
case 1319429285: return bem_emitDebugGet_0();
case 110588408: return bem_prepMakeGet_0();
case -1421504754: return bem_extIncludesGet_0();
case -58527321: return bem_setClassesToWrite_0();
case 90550536: return bem_saveSynsGet_0();
case 933532408: return bem_mainNameGet_0();
case 328761609: return bem_newlineGet_0();
case 273901168: return bem_printPlacesGet_0();
case -1135273067: return bem_parseGet_0();
case 1097965970: return bem_makeNameGet_0();
case 1693871088: return bem_twtokGet_0();
case -400601238: return bem_readBufferGet_0();
case 30072982: return bem_deployLibraryGet_0();
case 842814675: return bem_go_0();
case 1569688611: return bem_printAstElementsGet_0();
case 2118199107: return bem_linkLibArgsGet_0();
case -719735332: return bem_loadIdsGet_0();
case 1310259491: return bem_emitPathGet_0();
case -494951909: return bem_saveIdsGet_0();
case 987944866: return bem_ntypesGet_0();
case 1144433930: return bem_emitCs_0();
case -192576929: return bem_buildPathGet_0();
case -121033251: return bem_create_0();
case -1767022969: return bem_startTimeGet_0();
case -421585504: return bem_emitDataGet_0();
case -2008262096: return bem_doEmitGet_0();
case -2059286466: return bem_emitLangsGet_0();
case -1678963081: return bem_parseEmitCompileTimeGet_0();
case -31775894: return bem_toBuildGet_0();
case -2107331119: return bem_makeGet_0();
case 1065458645: return bem_closeLibrariesGet_0();
case 1351795712: return bem_compilerGet_0();
case -1124463695: return bem_paramsGet_0();
case -249507359: return bem_makeArgsGet_0();
case -1430390622: return bem_parseTimeGet_0();
case 1400388227: return bem_includePathGet_0();
case -1629379899: return bem_closeLibrariesStrGet_0();
case 1853755003: return bem_emitChecksGet_0();
case 1873540986: return bem_hashGet_0();
case 1747762123: return bem_estrGet_0();
case 391628772: return bem_ownProcessGet_0();
case -1063200929: return bem_emitterGet_0();
case -1900847811: return bem_print_0();
case -323761999: return bem_extLibsGet_0();
case 1788222665: return bem_fromFileGet_0();
case 296544410: return bem_runArgsGet_0();
case -934866407: return bem_putLineNumbersInTraceGet_0();
case 1500048758: return bem_config_0();
case 1795439353: return bem_printAllAstGet_0();
case -234739285: return bem_doMainGet_0();
case -169516222: return bem_compilerProfileGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1317466186: return bem_compilerSet_1(bevd_0);
case -985275106: return bem_exeNameSet_1(bevd_0);
case 2093875506: return bem_buildSyns_1(bevd_0);
case 2087456667: return bem_fromFileSet_1(bevd_0);
case -1097500701: return bem_emitFlagsSet_1(bevd_0);
case 82429934: return bem_extLinkObjectsSet_1(bevd_0);
case -2075780983: return bem_loadIdsSet_1(bevd_0);
case -1820454528: return bem_doEmitSet_1(bevd_0);
case -218297632: return bem_usedLibrarysStrSet_1(bevd_0);
case 1297949038: return bem_printAstSet_1(bevd_0);
case 887202309: return bem_notEquals_1(bevd_0);
case -1675491147: return bem_deployUsedLibrariesSet_1(bevd_0);
case -404030393: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -302098683: return bem_emitCommonSet_1(bevd_0);
case 1077628264: return bem_initLibsSet_1(bevd_0);
case -890853550: return bem_lctokSet_1(bevd_0);
case -1503072154: return bem_emitDataSet_1(bevd_0);
case 2073986982: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -1626753521: return bem_genOnlySet_1(bevd_0);
case 492486985: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -1964988964: return bem_ccObjArgsSet_1(bevd_0);
case -634552848: return bem_parseEmitTimeSet_1(bevd_0);
case 120571708: return bem_singleCCSet_1(bevd_0);
case -332773414: return bem_getSynNp_1(bevd_0);
case 1510605350: return bem_compilerProfileSet_1(bevd_0);
case 916259092: return bem_copyTo_1(bevd_0);
case 1958815478: return bem_saveSynsSet_1(bevd_0);
case -522330401: return bem_emitFileHeaderSet_1(bevd_0);
case 2108720510: return bem_printStepsSet_1(bevd_0);
case -690983668: return bem_outputPlatformSet_1(bevd_0);
case 1013769114: return bem_startTimeSet_1(bevd_0);
case -596585082: return bem_equals_1(bevd_0);
case 1218368508: return bem_undef_1(bevd_0);
case -807339554: return bem_constantsSet_1(bevd_0);
case 513316279: return bem_ntypesSet_1(bevd_0);
case 1140963353: return bem_doMainSet_1(bevd_0);
case -119171554: return bem_toBuildSet_1(bevd_0);
case 750179890: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 1864052567: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -1396262952: return bem_codeSet_1(bevd_0);
case -1314822779: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case -1414224492: return bem_extLibsSet_1(bevd_0);
case 496751360: return bem_makeSet_1(bevd_0);
case 804940417: return bem_emitLangsSet_1(bevd_0);
case -2050605073: return bem_buildSucceededSet_1(bevd_0);
case -1705397899: return bem_mainNameSet_1(bevd_0);
case -1916068528: return bem_nlSet_1(bevd_0);
case -135441338: return bem_parseSet_1(bevd_0);
case -1186120661: return bem_emitLibrarySet_1(bevd_0);
case -1633138826: return bem_emitPathSet_1(bevd_0);
case 409458367: return bem_twtokSet_1(bevd_0);
case 21559410: return bem_deployPathSet_1(bevd_0);
case 639715452: return bem_closeLibrariesSet_1(bevd_0);
case -1516622309: return bem_deployFilesFromSet_1(bevd_0);
case -154849429: return bem_usedLibrarysSet_1(bevd_0);
case 2074698689: return bem_estrSet_1(bevd_0);
case -294367564: return bem_libNameSet_1(bevd_0);
case -1764807072: return bem_argsSet_1(bevd_0);
case 1784576530: return bem_readBufferSet_1(bevd_0);
case -1774538009: return bem_runArgsSet_1(bevd_0);
case 463786765: return bem_closeLibrariesStrSet_1(bevd_0);
case 1270286284: return bem_extIncludesSet_1(bevd_0);
case -1227167: return bem_printAllAstSet_1(bevd_0);
case -1412733595: return bem_deployFilesToSet_1(bevd_0);
case -768026299: return bem_includePathSet_1(bevd_0);
case 904250036: return bem_buildMessageSet_1(bevd_0);
case 965669301: return bem_ownProcessSet_1(bevd_0);
case 89962103: return bem_emitDebugSet_1(bevd_0);
case -1277809492: return bem_printPlacesSet_1(bevd_0);
case 1022608388: return bem_runSet_1(bevd_0);
case -361436813: return bem_doParse_1(bevd_0);
case 888589392: return bem_sharedEmitterSet_1(bevd_0);
case -554072871: return bem_def_1(bevd_0);
case 1805078229: return bem_platformSet_1(bevd_0);
case -451792800: return bem_linkLibArgsSet_1(bevd_0);
case -916278798: return bem_emitChecksSet_1(bevd_0);
case -266052389: return bem_loadSynsSet_1(bevd_0);
case 621846409: return bem_paramsSet_1(bevd_0);
case -2011836215: return bem_parseTimeSet_1(bevd_0);
case 1084677530: return bem_newlineSet_1(bevd_0);
case -952117320: return bem_builtSet_1(bevd_0);
case 1472731858: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -1920348308: return bem_saveIdsSet_1(bevd_0);
case -2098030382: return bem_prepMakeSet_1(bevd_0);
case 132038825: return bem_printAstElementsSet_1(bevd_0);
case 1539005070: return bem_makeNameSet_1(bevd_0);
case -2022711457: return bem_makeArgsSet_1(bevd_0);
case 30754610: return bem_buildPathSet_1(bevd_0);
case 1569359816: return bem_deployLibrarySet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -843657739: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -1669355053: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1189844441: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1255398578: return bem_getSyn_2(bevd_0, bevd_1);
case 87795638: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 80727269: return bem_buildLiteral_2(bevd_0, bevd_1);
case 14330381: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
