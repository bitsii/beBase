package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x64,0x6F,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6C,0x6F,0x61,0x64,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x63,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_9_3_ContainerSet bevp_emitChecks;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_doMain;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_loadIds;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_ta_ph);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_singleCC = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_doMain = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevp_saveIds = be.BECS_Runtime.boolFalse;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevt_2_ta_ph = beva_name.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_2));
bevt_4_ta_ph = beva_name.bem_ends_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 99*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 99*/
 else /* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 99*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 100*/
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_ta_ph = beva_arg.bem_swap_2(bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bem_main_1(bevl__args);
bevt_1_ta_ph.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_ta_ph );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_ta_ph = bevp_params.bem_get_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 118*/ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 118*/ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 118*/
 else /* Line: 118*/ {
break;
} /* Line: 118*/
} /* Line: 118*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try /* Line: 127*/ {
bem_config_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 131*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(-82017130);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_5_BuildBuild_bels_9));
bevp_buildMessage = bevt_1_ta_ph.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 136*/
if (bevp_printSteps.bevi_bool)/* Line: 138*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 138*/ {
if (bevl_buildFailed.bevi_bool)/* Line: 138*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 138*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 138*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 138*/ {
bevp_buildMessage.bem_print_0();
} /* Line: 139*/
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bevp_platform.bemd_0(1912951938);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-559238061, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 145*/ {
} /* Line: 145*/
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_ec = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_ta_loop = null;
BEC_2_6_6_SystemObject bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_6_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_2_4_IOFile bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_2_4_IOFile bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_108_ta_ph = null;
BEC_2_4_6_TextString bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_9_4_ContainerList bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_5_4_LogicBool bevt_127_ta_ph = null;
BEC_2_9_4_ContainerList bevt_128_ta_ph = null;
BEC_2_9_4_ContainerList bevt_129_ta_ph = null;
BEC_2_6_6_SystemObject bevt_130_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_5_4_LogicBool bevt_133_ta_ph = null;
BEC_2_2_4_IOFile bevt_134_ta_ph = null;
BEC_2_2_4_IOFile bevt_135_ta_ph = null;
BEC_2_5_4_LogicBool bevt_136_ta_ph = null;
BEC_2_2_4_IOFile bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_6_ta_ph = bevp_params.bem_get_1(bevl_bkey);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 155*/ {
bevt_7_ta_ph = bevp_params.bem_get_1(bevl_bkey);
bevt_0_ta_loop = bevt_7_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 156*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 156*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(1149836311);
bevt_10_ta_ph = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_10_ta_ph.bevi_bool) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 157*/ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_11_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_11_ta_ph);
} /* Line: 159*/
} /* Line: 157*/
 else /* Line: 156*/ {
break;
} /* Line: 156*/
} /* Line: 156*/
} /* Line: 156*/
bevt_14_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_nameGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_12_ta_ph = bevt_13_ta_ph.bem_equals_1(bevt_15_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 164*/ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 165*/
bevt_17_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_12));
bevt_16_ta_ph = bevp_params.bem_get_1(bevt_17_ta_ph);
bevp_libName = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_firstGet_0();
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_18_ta_ph = bevp_params.bem_has_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 168*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_20_ta_ph = bevp_params.bem_get_1(bevt_21_ta_ph);
bevp_exeName = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_firstGet_0();
} /* Line: 169*/
 else /* Line: 170*/ {
bevp_exeName = bevp_libName;
} /* Line: 171*/
bevt_25_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_26_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_24_ta_ph = bevp_params.bem_get_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_firstGet_0();
bevt_22_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_23_ta_ph);
bevp_buildPath = bevt_22_ta_ph.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevp_buildPath.bem_addStep_1(bevt_27_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_32_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_30_ta_ph = bevp_params.bem_get_2(bevt_31_ta_ph, bevt_32_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bem_firstGet_0();
bevt_28_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_29_ta_ph);
bevp_includePath = bevt_28_ta_ph.bem_pathGet_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_18));
bevt_37_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_nameGet_0();
bevt_34_ta_ph = bevp_params.bem_get_2(bevt_35_ta_ph, bevt_36_ta_ph);
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_33_ta_ph );
bevt_40_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_41_ta_ph = bevp_platform.bemd_0(1912951938);
bevt_39_ta_ph = bevp_params.bem_get_2(bevt_40_ta_ph, (BEC_2_4_6_TextString) bevt_41_ta_ph );
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_38_ta_ph );
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_43_ta_ph = bevp_params.bem_get_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_42_ta_ph = bevt_43_ta_ph.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_42_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_49_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_47_ta_ph = bevp_params.bem_get_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_46_ta_ph = bevt_47_ta_ph.bem_firstGet_0();
bevp_doMain = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_46_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_53_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_51_ta_ph = bevp_params.bem_get_2(bevt_52_ta_ph, bevt_53_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_50_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_57_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_55_ta_ph = bevp_params.bem_get_2(bevt_56_ta_ph, bevt_57_ta_ph);
bevt_54_ta_ph = bevt_55_ta_ph.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_54_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_26));
bevp_loadSyns = bevp_params.bem_get_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevp_loadIds = bevp_params.bem_get_1(bevt_59_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_28));
bevp_initLibs = bevp_params.bem_get_1(bevt_60_ta_ph);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_29));
bevt_61_ta_ph = bevp_params.bem_get_1(bevt_62_ta_ph);
bevp_mainName = (BEC_2_4_6_TextString) bevt_61_ta_ph.bem_firstGet_0();
bevt_64_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_30));
bevt_63_ta_ph = bevp_params.bem_get_1(bevt_64_ta_ph);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_firstGet_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_65_ta_ph);
if (bevp_usedLibrarysStr == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 190*/ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 191*/
bevt_67_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_67_ta_ph);
if (bevp_closeLibrariesStr == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 194*/ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 195*/
bevt_69_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_69_ta_ph);
if (bevp_deployFilesFrom == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 198*/ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 199*/
bevt_71_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_71_ta_ph);
if (bevp_deployFilesTo == null) {
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_72_ta_ph.bevi_bool)/* Line: 202*/ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 203*/
bevt_73_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_73_ta_ph);
if (bevp_extIncludes == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 206*/ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 207*/
bevt_75_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_75_ta_ph);
if (bevp_ccObjArgs == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 210*/ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 211*/
bevt_77_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_77_ta_ph);
if (bevp_extLibs == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 214*/ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 215*/
bevt_79_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_79_ta_ph);
if (bevp_linkLibArgs == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 218*/ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 219*/
bevt_81_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_81_ta_ph);
if (bevp_extLinkObjects == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 222*/ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 223*/
bevt_83_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_83_ta_ph);
if (bevp_emitFileHeader == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 226*/ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-1350805026);
} /* Line: 227*/
bevt_85_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_85_ta_ph);
if (bevp_runArgs == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 230*/ {
bevp_runArgs = bevp_runArgs.bemd_0(-1350805026);
} /* Line: 231*/
 else /* Line: 232*/ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 233*/
bevt_87_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_42));
bevt_88_ta_ph = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_87_ta_ph, bevt_88_ta_ph);
bevt_89_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_89_ta_ph, bevt_90_ta_ph);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_92_ta_ph);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_93_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_93_ta_ph);
if (bevl_pacm == null) {
bevt_94_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_94_ta_ph.bevi_bool)/* Line: 241*/ {
bevt_96_ta_ph = bevl_pacm.bem_isEmptyGet_0();
if (bevt_96_ta_ph.bevi_bool) {
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 241*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 241*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 241*/
 else /* Line: 241*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 241*/ {
bevt_1_ta_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
/* Line: 242*/ {
bevt_97_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 242*/ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 243*/
 else /* Line: 242*/ {
break;
} /* Line: 242*/
} /* Line: 242*/
} /* Line: 242*/
bevt_98_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_98_ta_ph);
bevt_99_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_100_ta_ph);
bevt_101_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_101_ta_ph);
bevt_102_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_51));
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_102_ta_ph, bevt_103_ta_ph);
bevt_104_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_emitLangs = bevp_params.bem_get_1(bevt_104_ta_ph);
bevt_105_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevp_emitFlags = bevp_params.bem_get_1(bevt_105_ta_ph);
bevp_emitChecks = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (bevp_emitFlags == null) {
bevt_106_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_106_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_106_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_2_ta_loop = bevp_emitFlags.bem_linkedListIteratorGet_0();
while (true)
/* Line: 255*/ {
bevt_107_ta_ph = bevt_2_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 255*/ {
bevl_ec = (BEC_2_4_6_TextString) bevt_2_ta_loop.bem_nextGet_0();
bevp_emitChecks.bem_addValue_1(bevl_ec);
} /* Line: 257*/
 else /* Line: 255*/ {
break;
} /* Line: 255*/
} /* Line: 255*/
} /* Line: 255*/
bevt_109_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_110_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_108_ta_ph = bevp_params.bem_get_2(bevt_109_ta_ph, bevt_110_ta_ph);
bevp_compiler = (BEC_2_4_6_TextString) bevt_108_ta_ph.bem_firstGet_0();
bevt_112_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_113_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_111_ta_ph = bevp_params.bem_get_2(bevt_112_ta_ph, bevt_113_ta_ph);
bevp_makeName = (BEC_2_4_6_TextString) bevt_111_ta_ph.bem_firstGet_0();
bevt_116_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_115_ta_ph = bevt_116_ta_ph.bem_add_1(bevp_makeName);
bevt_117_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_114_ta_ph = bevp_params.bem_get_2(bevt_115_ta_ph, bevt_117_ta_ph);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_114_ta_ph.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 270*/ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 271*/
 else /* Line: 272*/ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_59));
} /* Line: 273*/
bevt_121_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_60));
bevt_120_ta_ph = bevl_outLang.bem_add_1(bevt_121_ta_ph);
bevt_122_ta_ph = bevp_platform.bemd_0(1912951938);
bevt_119_ta_ph = bevt_120_ta_ph.bem_add_1(bevt_122_ta_ph);
bevl_platformSources = bevp_params.bem_get_1(bevt_119_ta_ph);
if (bevl_platformSources == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 281*/ {
bevt_124_ta_ph = bevp_params.bem_orderedGet_0();
bevt_124_ta_ph.bem_addAll_1(bevl_platformSources);
} /* Line: 282*/
bevt_126_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_125_ta_ph = bevl_outLang.bem_add_1(bevt_126_ta_ph);
bevl_langSources = bevp_params.bem_get_1(bevt_125_ta_ph);
if (bevl_langSources == null) {
bevt_127_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_127_ta_ph.bevi_bool)/* Line: 286*/ {
bevt_128_ta_ph = bevp_params.bem_orderedGet_0();
bevt_128_ta_ph.bem_addAll_1(bevl_langSources);
} /* Line: 287*/
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_129_ta_ph = bevp_params.bem_orderedGet_0();
bevt_3_ta_loop = bevt_129_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 291*/ {
bevt_130_ta_ph = bevt_3_ta_loop.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_130_ta_ph).bevi_bool)/* Line: 291*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_3_ta_loop.bemd_0(1149836311);
bevt_131_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_131_ta_ph);
} /* Line: 292*/
 else /* Line: 291*/ {
break;
} /* Line: 291*/
} /* Line: 291*/
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-1937935225);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_134_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_133_ta_ph = bevt_134_ta_ph.bem_existsGet_0();
if (bevt_133_ta_ph.bevi_bool) {
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 299*/ {
bevt_135_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_135_ta_ph.bem_makeDirs_0();
} /* Line: 300*/
if (bevp_emitFileHeader == null) {
bevt_136_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_136_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_136_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_137_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_137_ta_ph.bem_readerGet_0();
bevt_138_ta_ph = bevl_emr.bemd_0(13458020);
bevp_emitFileHeader = bevt_138_ta_ph.bemd_0(-1866333503);
bevl_emr.bemd_0(-400639193);
} /* Line: 305*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_7_SystemClasses bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_toRet = bevt_0_ta_ph.bem_className_1(this);
bevt_2_ta_ph = bevl_toRet.bemd_1(1589996905, bevp_nl);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_62));
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(1589996905, bevt_3_ta_ph);
bevt_4_ta_ph = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_1_ta_ph.bemd_1(1589996905, bevt_4_ta_ph);
bevt_6_ta_ph = bevl_toRet.bemd_1(1589996905, bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_63));
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(1589996905, bevt_7_ta_ph);
bevt_8_ta_ph = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_5_ta_ph.bemd_1(1589996905, bevt_8_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 318*/ {
bevt_3_ta_ph = bevl_ci.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 318*/ {
bevl_clnode = bevl_ci.bemd_0(1149836311);
bevt_5_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_ta_ph = bevl_clnode.bemd_0(-1830329539);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(376521784);
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_10_ta_ph = bevl_clnode.bemd_0(-1830329539);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1462096677);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-82017130);
bevl_toEmit.bem_put_1(bevt_8_ta_ph);
bevt_11_ta_ph = bevp_emitData.bem_usedByGet_0();
bevt_14_ta_ph = bevl_clnode.bemd_0(-1830329539);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(-1462096677);
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-82017130);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_ta_ph.bem_get_1(bevt_12_ta_ph);
if (bevl_usedBy == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_0_ta_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
/* Line: 324*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 324*/ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 325*/
 else /* Line: 324*/ {
break;
} /* Line: 324*/
} /* Line: 324*/
} /* Line: 324*/
bevt_17_ta_ph = bevp_emitData.bem_subClassesGet_0();
bevt_20_ta_ph = bevl_clnode.bemd_0(-1830329539);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-1462096677);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-82017130);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_ta_ph.bem_get_1(bevt_18_ta_ph);
if (bevl_subClasses == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_1_ta_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
/* Line: 330*/ {
bevt_22_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 330*/ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 331*/
 else /* Line: 330*/ {
break;
} /* Line: 330*/
} /* Line: 330*/
} /* Line: 330*/
} /* Line: 329*/
} /* Line: 320*/
 else /* Line: 318*/ {
break;
} /* Line: 318*/
} /* Line: 318*/
bevt_23_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 336*/ {
bevt_24_ta_ph = bevl_ci.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 336*/ {
bevl_clnode = bevl_ci.bemd_0(1149836311);
bevt_25_ta_ph = bevl_clnode.bemd_0(-1830329539);
bevt_29_ta_ph = bevl_clnode.bemd_0(-1830329539);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-1462096677);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(-82017130);
bevt_26_ta_ph = bevl_toEmit.bem_has_1(bevt_27_ta_ph);
bevt_25_ta_ph.bemd_1(-1488312661, bevt_26_ta_ph);
} /* Line: 338*/
 else /* Line: 336*/ {
break;
} /* Line: 336*/
} /* Line: 336*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_emitCommon == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 349*/ {
return bevp_emitCommon;
} /* Line: 350*/
if (bevp_emitLangs == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 355*/ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_64));
bevt_2_ta_ph = bevl_emitLang.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 357*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 358*/
 else /* Line: 357*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_4_ta_ph = bevl_emitLang.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 359*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 360*/
 else /* Line: 357*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_6_ta_ph = bevl_emitLang.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 361*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 362*/
 else /* Line: 363*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_67));
bevt_8_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 364*/
} /* Line: 357*/
} /* Line: 357*/
return bevp_emitCommon;
} /* Line: 366*/
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_2_6_10_SystemSerializer bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_7_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_68));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_lsp);
bevt_0_ta_ph.bem_print_0();
bevt_2_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_ta_ph.bem_now_0();
bevt_4_ta_ph = bevl_synEmitPath.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_ta_ph.bemd_0(13458020);
bevt_5_ta_ph = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_ta_ph.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevt_6_ta_ph.bem_addValue_1(bevl_scls);
bevt_8_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_now_0();
bevl_sse = bevt_7_ta_ph.bem_subtract_1(bevl_sst);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_5_BuildBuild_bels_69));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_sse);
bevt_9_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_22_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_25_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_26_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_27_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_28_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_29_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_30_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_43_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_82_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_3_MathInt bevt_98_ta_ph = null;
bevt_5_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_ta_ph.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 389*/ {
bevt_0_ta_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
/* Line: 390*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 390*/ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 391*/
 else /* Line: 390*/ {
break;
} /* Line: 390*/
} /* Line: 390*/
} /* Line: 390*/
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 395*/ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool)/* Line: 398*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_libName);
bevt_9_ta_ph.bem_print_0();
} /* Line: 399*/
} /* Line: 398*/
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_ta_loop = bevp_usedLibrarysStr.bemd_0(1140404476);
while (true)
/* Line: 404*/ {
bevt_11_ta_ph = bevt_1_ta_loop.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 404*/ {
bevl_ups = bevt_1_ta_loop.bemd_0(1149836311);
bevt_13_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 405*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 408*/
} /* Line: 405*/
 else /* Line: 404*/ {
break;
} /* Line: 404*/
} /* Line: 404*/
bevt_2_ta_loop = bevp_closeLibrariesStr.bemd_0(1140404476);
while (true)
/* Line: 411*/ {
bevt_14_ta_ph = bevt_2_ta_loop.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 411*/ {
bevl_ups = bevt_2_ta_loop.bemd_0(1149836311);
bevt_16_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_ta_ph.bevi_bool) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 412*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_ta_ph = bevl_pack.bemd_0(1847027530);
bevp_closeLibraries.bem_put_1(bevt_17_ta_ph);
} /* Line: 416*/
} /* Line: 412*/
 else /* Line: 411*/ {
break;
} /* Line: 411*/
} /* Line: 411*/
if (bevp_parse.bevi_bool)/* Line: 419*/ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
/* Line: 422*/ {
bevt_18_ta_ph = bevl_i.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 422*/ {
bevl_tb = bevl_i.bemd_0(1149836311);
bevt_20_ta_ph = bevl_tb.bemd_0(-82017130);
bevt_19_ta_ph = bevl_built.bem_has_1(bevt_20_ta_ph);
if (!(bevt_19_ta_ph.bevi_bool))/* Line: 425*/ {
bevt_21_ta_ph = bevl_tb.bemd_0(-82017130);
bevl_built.bem_put_1(bevt_21_ta_ph);
bem_doParse_1(bevl_tb);
} /* Line: 427*/
} /* Line: 425*/
 else /* Line: 422*/ {
break;
} /* Line: 422*/
} /* Line: 422*/
bem_buildSyns_1(bevl_em);
} /* Line: 430*/
bevt_23_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_now_0();
bevp_parseTime = bevt_22_ta_ph.bem_subtract_1(bevp_startTime);
bevt_25_ta_ph = bem_emitCommonGet_0();
if (bevt_25_ta_ph == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 436*/ {
bevt_26_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_ta_ph.bem_now_0();
bevt_27_ta_ph = bem_emitCommonGet_0();
bevt_27_ta_ph.bem_doEmit_0();
bevt_29_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_28_ta_ph.bem_subtract_1(bevp_startTime);
bevt_31_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_now_0();
bevl_emitTime = bevt_30_ta_ph.bem_subtract_1(bevl_emitStart);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevp_parseTime);
bevt_32_ta_ph.bem_print_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_34_ta_ph = bevt_35_ta_ph.bem_add_1(bevl_emitTime);
bevt_34_ta_ph.bem_print_0();
bevt_37_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_73));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_36_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_38_ta_ph;
} /* Line: 445*/
if (bevp_doEmit.bevi_bool)/* Line: 447*/ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-1974360626);
bevt_39_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 451*/ {
bevt_40_ta_ph = bevl_ci.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 451*/ {
bevl_clnode = bevl_ci.bemd_0(1149836311);
bevl_em.bemd_1(1305454549, bevl_clnode);
} /* Line: 453*/
 else /* Line: 451*/ {
break;
} /* Line: 451*/
} /* Line: 451*/
bevl_em.bemd_0(2054836709);
bevl_em.bemd_0(1002768823);
bevt_41_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 457*/ {
bevt_42_ta_ph = bevl_ci.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 457*/ {
bevl_clnode = bevl_ci.bemd_0(1149836311);
bevl_em.bemd_1(644860679, bevl_clnode);
} /* Line: 459*/
 else /* Line: 457*/ {
break;
} /* Line: 457*/
} /* Line: 457*/
} /* Line: 457*/
bevt_44_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_ta_ph = bevt_44_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_43_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 464*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_46_ta_ph = bevt_47_ta_ph.bem_add_1(bevp_parseTime);
bevt_46_ta_ph.bem_print_0();
} /* Line: 465*/
bevt_49_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_73));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_48_ta_ph.bem_print_0();
if (bevp_prepMake.bevi_bool)/* Line: 468*/ {
bevl_em.bemd_1(2063805370, bevp_deployLibrary);
} /* Line: 470*/
if (bevp_make.bevi_bool)/* Line: 473*/ {
if (bevp_genOnly.bevi_bool) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 474*/ {
bevl_em.bemd_1(445838177, bevp_deployLibrary);
bevl_em.bemd_1(871225435, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool)/* Line: 477*/ {
bevt_3_ta_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
/* Line: 478*/ {
bevt_51_ta_ph = bevt_3_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 478*/ {
bevl_bp = bevt_3_ta_loop.bem_nextGet_0();
bevt_52_ta_ph = bevl_bp.bemd_0(-1974360626);
bevl_cpFrom = bevt_52_ta_ph.bemd_0(-746851569);
bevt_53_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_ta_ph.bem_copy_0();
bevt_55_ta_ph = bevl_cpFrom.bemd_0(85937271);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(1977110334);
bevl_cpTo.bemd_1(1734891928, bevt_54_ta_ph);
bevt_57_ta_ph = bevl_cpTo.bemd_0(224906903);
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(970594978);
if (((BEC_2_5_4_LogicBool) bevt_56_ta_ph).bevi_bool)/* Line: 482*/ {
bevt_58_ta_ph = bevl_cpTo.bemd_0(224906903);
bevt_58_ta_ph.bemd_0(-1614601099);
} /* Line: 483*/
bevt_61_ta_ph = bevl_cpTo.bemd_0(224906903);
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(970594978);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(787218599);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 485*/ {
bevt_62_ta_ph = bevl_cpFrom.bemd_0(224906903);
bevt_63_ta_ph = bevl_cpTo.bemd_0(224906903);
bevl_em.bemd_2(-333081484, bevt_62_ta_ph, bevt_63_ta_ph);
} /* Line: 486*/
} /* Line: 485*/
 else /* Line: 478*/ {
break;
} /* Line: 478*/
} /* Line: 478*/
} /* Line: 478*/
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
/* Line: 493*/ {
bevt_64_ta_ph = bevl_fIter.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 493*/ {
bevt_65_ta_ph = bevl_tIter.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_65_ta_ph).bevi_bool)/* Line: 493*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 493*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 493*/
 else /* Line: 493*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 493*/ {
bevt_66_ta_ph = bevl_fIter.bemd_0(1149836311);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_ta_ph );
bevt_71_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_ta_ph = bevt_71_ta_ph.bem_copy_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_toString_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_68_ta_ph = bevt_69_ta_ph.bem_add_1(bevt_72_ta_ph);
bevt_73_ta_ph = bevl_tIter.bemd_0(1149836311);
bevt_67_ta_ph = bevt_68_ta_ph.bem_add_1(bevt_73_ta_ph);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_ta_ph);
bevt_75_ta_ph = bevl_cpTo.bemd_0(224906903);
bevt_74_ta_ph = bevt_75_ta_ph.bemd_0(970594978);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 497*/ {
bevt_76_ta_ph = bevl_cpTo.bemd_0(224906903);
bevt_76_ta_ph.bemd_0(-1614601099);
} /* Line: 498*/
bevt_79_ta_ph = bevl_cpTo.bemd_0(224906903);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(970594978);
bevt_77_ta_ph = bevt_78_ta_ph.bemd_0(787218599);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 500*/ {
bevt_80_ta_ph = bevl_cpFrom.bemd_0(224906903);
bevt_81_ta_ph = bevl_cpTo.bemd_0(224906903);
bevl_em.bemd_2(-333081484, bevt_80_ta_ph, bevt_81_ta_ph);
} /* Line: 501*/
} /* Line: 500*/
 else /* Line: 493*/ {
break;
} /* Line: 493*/
} /* Line: 493*/
} /* Line: 493*/
} /* Line: 474*/
bevt_83_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_ta_ph = bevt_83_ta_ph.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 508*/ {
bevt_86_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_85_ta_ph = bevt_86_ta_ph.bem_add_1(bevp_parseTime);
bevt_85_ta_ph.bem_print_0();
} /* Line: 509*/
if (bevp_parseEmitTime == null) {
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 511*/ {
bevt_89_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_73));
bevt_88_ta_ph = bevt_89_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_88_ta_ph.bem_print_0();
} /* Line: 512*/
if (bevp_parseEmitCompileTime == null) {
bevt_90_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_90_ta_ph.bevi_bool)/* Line: 514*/ {
bevt_92_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_91_ta_ph = bevt_92_ta_ph.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_ta_ph.bem_print_0();
} /* Line: 515*/
if (bevp_run.bevi_bool)/* Line: 518*/ {
bevt_93_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_75));
bevt_93_ta_ph.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(1623854694, bevp_deployLibrary, bevp_runArgs);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_76));
bevt_95_ta_ph = bevt_96_ta_ph.bem_add_1(bevl_result);
bevt_97_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_77));
bevt_94_ta_ph = bevt_95_ta_ph.bem_add_1(bevt_97_ta_ph);
bevt_94_ta_ph.bem_print_0();
return bevl_result;
} /* Line: 522*/
bevt_98_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_98_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 528*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 528*/ {
bevl_kls = bevl_ci.bemd_0(1149836311);
bevt_2_ta_ph = bevl_kls.bemd_0(-1830329539);
bevt_2_ta_ph.bemd_1(152411771, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(152411771, bevp_libName);
} /* Line: 532*/
 else /* Line: 528*/ {
break;
} /* Line: 528*/
} /* Line: 528*/
bevt_3_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 534*/ {
bevt_4_ta_ph = bevl_ci.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 534*/ {
bevl_kls = bevl_ci.bemd_0(1149836311);
bevt_5_ta_ph = bevl_kls.bemd_0(-1830329539);
bevl_syn = bevt_5_ta_ph.bemd_0(55108584);
bevl_syn.bemd_2(1967903816, this, bevl_kls);
bevl_syn.bemd_1(630064803, this);
} /* Line: 538*/
 else /* Line: 534*/ {
break;
} /* Line: 534*/
} /* Line: 534*/
bevt_6_ta_ph = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
bevt_2_ta_ph = beva_klass.bemd_0(-1830329539);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(55108584);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 544*/ {
bevt_4_ta_ph = beva_klass.bemd_0(-1830329539);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(55108584);
return bevt_3_ta_ph;
} /* Line: 545*/
bevt_5_ta_ph = beva_klass.bemd_0(-1830329539);
bevt_5_ta_ph.bemd_1(152411771, bevp_libName);
bevt_8_ta_ph = beva_klass.bemd_0(-1830329539);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-449422521);
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 548*/ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 549*/
 else /* Line: 550*/ {
bevt_9_ta_ph = bevp_emitData.bem_classesGet_0();
bevt_12_ta_ph = beva_klass.bemd_0(-1830329539);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-449422521);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-82017130);
bevl_pklass = bevt_9_ta_ph.bem_get_1(bevt_10_ta_ph);
if (bevl_pklass == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 553*/ {
bevt_14_ta_ph = bevl_pklass.bemd_0(-1830329539);
bevt_14_ta_ph.bemd_1(152411771, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 555*/
 else /* Line: 556*/ {
bevt_16_ta_ph = beva_klass.bemd_0(-1830329539);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-449422521);
bevl_psyn = bem_getSynNp_1(bevt_15_ta_ph);
} /* Line: 559*/
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 561*/
bevt_17_ta_ph = beva_klass.bemd_0(-1830329539);
bevt_17_ta_ph.bemd_1(923765542, bevl_syn);
bevt_20_ta_ph = beva_klass.bemd_0(-1830329539);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-1462096677);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-82017130);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_ta_ph , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_nps = beva_np.bemd_0(-82017130);
bevt_0_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_ta_ph.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 571*/ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 572*/
bevt_2_ta_ph = bem_emitterGet_0();
bevl_syn = bevt_2_ta_ph.bemd_1(-1865235320, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_sharedEmitter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 587*/ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 588*/
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_ta_ph.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool)/* Line: 601*/ {
if (bevp_printSteps.bevi_bool)/* Line: 602*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 602*/ {
if (bevp_printPlaces.bevi_bool)/* Line: 602*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 602*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 602*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 602*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_78));
bevt_5_ta_ph = beva_toParse.bemd_0(-82017130);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_3_ta_ph.bem_print_0();
} /* Line: 603*/
bevp_fromFile = beva_toParse;
bevt_8_ta_ph = beva_toParse.bemd_0(224906903);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-2075191838);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(13458020);
bevl_src = bevt_6_ta_ph.bemd_1(-1801450222, bevp_readBuffer);
bevt_10_ta_ph = beva_toParse.bemd_0(224906903);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-2075191838);
bevt_9_ta_ph.bemd_0(-400639193);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool)/* Line: 614*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_79));
bevt_11_ta_ph.bem_echo_0();
} /* Line: 615*/
bevt_12_ta_ph = bevl_trans.bemd_0(-548502217);
bem_nodify_2(bevt_12_ta_ph, bevl_toks);
if (bevp_printAllAst.bevi_bool)/* Line: 618*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_5_BuildBuild_bels_80));
bevt_13_ta_ph.bem_print_0();
bevt_14_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_14_ta_ph);
} /* Line: 620*/
if (bevp_printSteps.bevi_bool)/* Line: 623*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_81));
bevt_15_ta_ph.bem_echo_0();
} /* Line: 624*/
bevt_16_ta_ph = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-510689816, bevt_16_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 627*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_82));
bevt_17_ta_ph.bem_print_0();
bevt_18_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_18_ta_ph);
} /* Line: 629*/
if (bevp_printSteps.bevi_bool)/* Line: 631*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_83));
bevt_19_ta_ph.bem_echo_0();
} /* Line: 632*/
bevt_20_ta_ph = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-510689816, bevt_20_ta_ph);
bevl_trans.bemd_0(1376871868);
if (bevp_printAllAst.bevi_bool)/* Line: 637*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_84));
bevt_21_ta_ph.bem_print_0();
bevt_22_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_22_ta_ph);
} /* Line: 639*/
if (bevp_printSteps.bevi_bool)/* Line: 642*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_85));
bevt_23_ta_ph.bem_echo_0();
} /* Line: 643*/
bevt_24_ta_ph = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-510689816, bevt_24_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 646*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_86));
bevt_25_ta_ph.bem_print_0();
bevt_26_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_26_ta_ph);
} /* Line: 648*/
if (bevp_printSteps.bevi_bool)/* Line: 651*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_87));
bevt_27_ta_ph.bem_echo_0();
} /* Line: 652*/
bevt_28_ta_ph = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-510689816, bevt_28_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 655*/ {
bevt_29_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_88));
bevt_29_ta_ph.bem_print_0();
bevt_30_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_30_ta_ph);
} /* Line: 657*/
if (bevp_printSteps.bevi_bool)/* Line: 660*/ {
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_89));
bevt_31_ta_ph.bem_echo_0();
} /* Line: 661*/
bevt_32_ta_ph = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-510689816, bevt_32_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 664*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_90));
bevt_33_ta_ph.bem_print_0();
bevt_34_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_34_ta_ph);
} /* Line: 666*/
if (bevp_printSteps.bevi_bool)/* Line: 669*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_91));
bevt_35_ta_ph.bem_echo_0();
} /* Line: 670*/
bevt_36_ta_ph = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-510689816, bevt_36_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 673*/ {
bevt_37_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_92));
bevt_37_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_38_ta_ph);
} /* Line: 675*/
if (bevp_printSteps.bevi_bool)/* Line: 678*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_93));
bevt_39_ta_ph.bem_echo_0();
} /* Line: 679*/
bevt_40_ta_ph = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-510689816, bevt_40_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 682*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_94));
bevt_41_ta_ph.bem_print_0();
bevt_42_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_42_ta_ph);
} /* Line: 684*/
if (bevp_printSteps.bevi_bool)/* Line: 687*/ {
bevt_43_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_95));
bevt_43_ta_ph.bem_echo_0();
} /* Line: 688*/
bevt_44_ta_ph = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-510689816, bevt_44_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 691*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_96));
bevt_45_ta_ph.bem_print_0();
bevt_46_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_46_ta_ph);
} /* Line: 693*/
if (bevp_printSteps.bevi_bool)/* Line: 696*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_97));
bevt_47_ta_ph.bem_echo_0();
} /* Line: 697*/
bevt_48_ta_ph = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-510689816, bevt_48_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 700*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_98));
bevt_49_ta_ph.bem_print_0();
bevt_50_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_50_ta_ph);
} /* Line: 702*/
if (bevp_printSteps.bevi_bool)/* Line: 704*/ {
bevt_51_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_99));
bevt_51_ta_ph.bem_echo_0();
} /* Line: 705*/
bevt_52_ta_ph = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-510689816, bevt_52_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 708*/ {
bevt_53_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_100));
bevt_53_ta_ph.bem_print_0();
bevt_54_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_54_ta_ph);
} /* Line: 710*/
if (bevp_printSteps.bevi_bool)/* Line: 713*/ {
bevt_55_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_101));
bevt_55_ta_ph.bem_echo_0();
bevt_56_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_102));
bevt_56_ta_ph.bem_print_0();
} /* Line: 715*/
bevt_57_ta_ph = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-510689816, bevt_57_ta_ph);
if (bevp_printAst.bevi_bool)/* Line: 718*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 718*/ {
if (bevp_printAllAst.bevi_bool)/* Line: 718*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 718*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 718*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 718*/ {
bevt_58_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_103));
bevt_58_ta_ph.bem_print_0();
bevt_59_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-510689816, bevt_59_ta_ph);
} /* Line: 720*/
bevt_60_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 722*/ {
bevt_61_ta_ph = bevl_ci.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 722*/ {
bevl_clnode = bevl_ci.bemd_0(1149836311);
bevl_tunode = bevl_clnode.bemd_0(804716602);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(473105946, bevt_62_ta_ph);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_ta_ph = bevl_tunode.bemd_0(-1830329539);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(-621646769);
bevl_ntt.bemd_1(-431284304, bevt_63_ta_ph);
bevl_ntunode.bemd_1(916925645, bevl_ntt);
bevl_clnode.bemd_0(-1614601099);
bevl_ntunode.bemd_1(1835118420, bevl_clnode);
bevl_ntunode.bemd_1(-25184092, bevl_clnode);
} /* Line: 733*/
 else /* Line: 722*/ {
break;
} /* Line: 722*/
} /* Line: 722*/
} /* Line: 722*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
beva_parnode.bemd_0(196463431);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(-1850385927);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_ta_ph.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 743*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 743*/ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_ta_ph = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(916925645, bevt_2_ta_ph);
bevl_node.bemd_1(266690359, bevl_nlc);
bevt_4_ta_ph = bevl_node.bemd_0(-1830329539);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(-559238061, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 747*/ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 748*/
bevt_6_ta_ph = bevl_node.bemd_0(-1830329539);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(-850371892, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 750*/ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(830739156, beva_parnode);
} /* Line: 752*/
} /* Line: 750*/
 else /* Line: 743*/ {
break;
} /* Line: 743*/
} /* Line: 743*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-1167687992, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(473105946, bevt_5_ta_ph);
bevl_nlnpn.bemd_1(916925645, bevl_nlnp);
bevl_nlnpn.bemd_1(-25184092, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevl_nlc.bemd_1(1035482217, bevt_6_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-449068136, bevt_7_ta_ph);
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1695650158, bevt_8_ta_ph);
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(620039629, bevt_9_ta_ph);
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-936193235, bevt_10_ta_ph);
bevt_11_ta_ph = beva_node.bemd_0(-1830329539);
bevl_nlc.bemd_1(-264347505, bevt_11_ta_ph);
beva_node.bemd_1(1835118420, bevl_nlnpn);
bevt_12_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(473105946, bevt_12_ta_ph);
beva_node.bemd_1(916925645, bevl_nlc);
bevl_nlnpn.bemd_0(-482401035);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_104));
bevt_13_ta_ph = beva_tName.bemd_1(-559238061, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 782*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 782*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_105));
bevt_15_ta_ph = beva_tName.bemd_1(-559238061, bevt_16_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 782*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 782*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 782*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 782*/ {
bevl_pn = beva_node.bemd_0(936827464);
if (bevl_pn == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 784*/ {
bevt_19_ta_ph = bevl_pn.bemd_0(-1471974163);
bevt_20_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-559238061, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 784*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 784*/ {
bevt_22_ta_ph = bevl_pn.bemd_0(-1471974163);
bevt_23_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(-559238061, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 784*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 784*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 784*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 784*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 784*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 784*/
 else /* Line: 784*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 784*/ {
bevl_pn2 = bevl_pn.bemd_0(936827464);
if (bevl_pn2 == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 786*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 786*/ {
bevt_26_ta_ph = bevl_pn2.bemd_0(-1471974163);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(-850371892, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 786*/ {
bevt_29_ta_ph = bevl_pn2.bemd_0(-1471974163);
bevt_30_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(-850371892, bevt_30_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 786*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 786*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 786*/
 else /* Line: 786*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 786*/ {
bevt_32_ta_ph = bevl_pn2.bemd_0(-1471974163);
bevt_33_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bemd_1(-850371892, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_31_ta_ph).bevi_bool)/* Line: 786*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 786*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 786*/
 else /* Line: 786*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 786*/ {
bevt_35_ta_ph = bevl_pn2.bemd_0(-1471974163);
bevt_36_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(-850371892, bevt_36_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 786*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 786*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 786*/
 else /* Line: 786*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 786*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 786*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 786*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 786*/ {
bevt_38_ta_ph = bevl_pn.bemd_0(-1830329539);
bevt_39_ta_ph = bevl_nlc.bemd_0(-1394064148);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(1589996905, bevt_39_ta_ph);
bevl_nlc.bemd_1(-264347505, bevt_37_ta_ph);
bevl_pn.bemd_0(-1614601099);
} /* Line: 793*/
} /* Line: 786*/
} /* Line: 784*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_platform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_outputPlatform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLibrary = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runArgs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_includePath = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_code = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGet_0() throws Throwable {
return bevp_emitChecks;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doMainGet_0() throws Throwable {
return bevp_doMain;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doMainSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doMain = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadIdsGet_0() throws Throwable {
return bevp_loadIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loadIds = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {49, 51, 52, 53, 54, 56, 57, 58, 59, 60, 61, 62, 66, 68, 69, 70, 71, 71, 74, 77, 78, 79, 86, 87, 88, 89, 90, 91, 91, 99, 99, 99, 99, 0, 99, 99, 0, 0, 0, 0, 0, 100, 100, 102, 102, 106, 106, 106, 106, 110, 110, 111, 111, 111, 115, 116, 117, 117, 117, 117, 117, 118, 118, 118, 119, 118, 121, 125, 126, 128, 129, 130, 131, 133, 134, 135, 135, 136, 0, 0, 0, 139, 141, 145, 145, 145, 147, 152, 154, 155, 155, 155, 156, 156, 0, 156, 156, 157, 157, 157, 158, 159, 159, 164, 164, 164, 164, 165, 167, 167, 167, 168, 168, 169, 169, 169, 171, 173, 173, 173, 173, 173, 173, 174, 175, 175, 176, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 184, 184, 185, 185, 187, 187, 187, 188, 188, 188, 189, 189, 190, 190, 191, 193, 193, 194, 194, 195, 197, 197, 198, 198, 199, 201, 201, 202, 202, 203, 205, 205, 206, 206, 207, 209, 209, 210, 210, 211, 213, 213, 214, 214, 215, 217, 217, 218, 218, 219, 221, 221, 222, 222, 223, 225, 225, 226, 226, 227, 229, 229, 230, 230, 231, 233, 235, 235, 235, 236, 236, 236, 237, 237, 238, 238, 239, 240, 240, 241, 241, 241, 241, 241, 0, 0, 0, 242, 0, 242, 242, 243, 246, 246, 247, 247, 248, 248, 249, 249, 250, 250, 250, 251, 251, 252, 252, 253, 254, 254, 255, 0, 255, 255, 257, 260, 260, 260, 260, 261, 261, 261, 261, 262, 262, 262, 262, 262, 263, 264, 265, 266, 267, 270, 270, 271, 273, 280, 280, 280, 280, 280, 281, 281, 282, 282, 285, 285, 285, 286, 286, 287, 287, 290, 291, 291, 0, 291, 291, 292, 292, 294, 295, 296, 298, 299, 299, 299, 299, 300, 300, 302, 302, 303, 303, 304, 304, 305, 310, 310, 311, 311, 311, 311, 311, 312, 312, 312, 312, 312, 313, 317, 318, 318, 318, 319, 320, 320, 320, 320, 321, 321, 321, 321, 322, 322, 322, 322, 322, 323, 323, 324, 0, 324, 324, 325, 328, 328, 328, 328, 328, 329, 329, 330, 0, 330, 330, 331, 336, 336, 336, 337, 338, 338, 338, 338, 338, 338, 345, 345, 349, 349, 350, 355, 355, 356, 357, 357, 358, 359, 359, 360, 361, 361, 362, 364, 364, 364, 366, 368, 372, 374, 374, 374, 375, 375, 376, 376, 376, 377, 377, 378, 379, 379, 380, 380, 380, 381, 381, 381, 387, 387, 388, 389, 389, 390, 0, 390, 390, 391, 394, 395, 395, 396, 397, 399, 399, 399, 402, 404, 0, 404, 404, 405, 405, 405, 406, 407, 408, 411, 0, 411, 411, 412, 412, 412, 413, 414, 415, 416, 416, 421, 422, 422, 423, 425, 425, 426, 426, 427, 430, 433, 433, 433, 436, 436, 436, 438, 438, 439, 439, 440, 440, 440, 441, 441, 441, 442, 442, 442, 443, 443, 443, 444, 444, 444, 445, 445, 448, 449, 451, 451, 451, 452, 453, 455, 456, 457, 457, 457, 458, 459, 463, 463, 463, 464, 464, 465, 465, 465, 467, 467, 467, 470, 474, 474, 475, 476, 478, 0, 478, 478, 479, 479, 480, 480, 481, 481, 481, 482, 482, 483, 483, 485, 485, 485, 486, 486, 486, 490, 491, 493, 493, 0, 0, 0, 494, 494, 495, 495, 495, 495, 495, 495, 495, 495, 497, 497, 498, 498, 500, 500, 500, 501, 501, 501, 506, 506, 506, 508, 508, 509, 509, 509, 511, 511, 512, 512, 512, 514, 514, 515, 515, 515, 519, 519, 520, 521, 521, 521, 521, 521, 522, 524, 524, 528, 528, 528, 529, 530, 530, 531, 532, 534, 534, 534, 535, 536, 536, 537, 538, 540, 540, 544, 544, 544, 544, 545, 545, 545, 547, 547, 548, 548, 548, 548, 549, 551, 551, 551, 551, 551, 553, 553, 554, 554, 555, 559, 559, 559, 561, 563, 563, 564, 564, 564, 564, 565, 569, 570, 570, 571, 571, 572, 578, 578, 579, 580, 587, 587, 588, 590, 595, 596, 597, 598, 599, 600, 600, 0, 0, 0, 603, 603, 603, 603, 605, 607, 607, 607, 607, 608, 608, 608, 611, 615, 615, 617, 617, 619, 619, 620, 620, 624, 624, 626, 626, 628, 628, 629, 629, 632, 632, 635, 635, 636, 638, 638, 639, 639, 643, 643, 645, 645, 647, 647, 648, 648, 652, 652, 654, 654, 656, 656, 657, 657, 661, 661, 663, 663, 665, 665, 666, 666, 670, 670, 672, 672, 674, 674, 675, 675, 679, 679, 681, 681, 683, 683, 684, 684, 688, 688, 690, 690, 692, 692, 693, 693, 697, 697, 699, 699, 701, 701, 702, 702, 705, 705, 707, 707, 709, 709, 710, 710, 714, 714, 715, 715, 717, 717, 0, 0, 0, 719, 719, 720, 720, 722, 722, 722, 723, 725, 726, 727, 727, 728, 729, 729, 729, 730, 731, 732, 733, 739, 740, 741, 742, 742, 743, 743, 744, 745, 745, 746, 747, 747, 748, 750, 750, 751, 752, 759, 760, 762, 763, 763, 764, 765, 767, 768, 768, 769, 769, 770, 770, 771, 771, 772, 772, 773, 773, 775, 777, 777, 778, 780, 782, 782, 0, 782, 782, 0, 0, 783, 784, 784, 784, 784, 784, 0, 784, 784, 784, 0, 0, 0, 0, 0, 785, 786, 786, 0, 786, 786, 786, 786, 786, 786, 0, 0, 0, 786, 786, 786, 0, 0, 0, 786, 786, 786, 0, 0, 0, 0, 0, 792, 792, 792, 792, 793, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 236, 241, 242, 243, 245, 248, 249, 251, 254, 258, 261, 265, 268, 269, 271, 272, 278, 279, 280, 281, 288, 289, 290, 291, 292, 304, 305, 306, 307, 308, 309, 310, 311, 314, 319, 320, 321, 327, 335, 336, 338, 339, 340, 341, 345, 346, 347, 348, 349, 352, 356, 359, 363, 365, 371, 372, 373, 376, 528, 529, 530, 531, 536, 537, 538, 538, 541, 543, 544, 545, 550, 551, 552, 553, 561, 562, 563, 564, 566, 568, 569, 570, 571, 572, 574, 575, 576, 579, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 646, 647, 649, 650, 651, 656, 657, 659, 660, 661, 666, 667, 669, 670, 671, 676, 677, 679, 680, 681, 686, 687, 689, 690, 691, 696, 697, 699, 700, 701, 706, 707, 709, 710, 711, 716, 717, 719, 720, 721, 726, 727, 729, 730, 731, 736, 737, 739, 740, 741, 746, 747, 750, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 770, 771, 772, 777, 778, 781, 785, 788, 788, 791, 793, 794, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 822, 823, 823, 826, 828, 829, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 859, 860, 863, 865, 866, 867, 868, 869, 870, 875, 876, 877, 879, 880, 881, 882, 887, 888, 889, 891, 892, 893, 893, 896, 898, 899, 900, 906, 907, 908, 909, 910, 911, 912, 917, 918, 919, 921, 926, 927, 928, 929, 930, 931, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 998, 999, 1000, 1003, 1005, 1006, 1007, 1008, 1009, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1025, 1026, 1026, 1029, 1031, 1032, 1039, 1040, 1041, 1042, 1043, 1044, 1049, 1050, 1050, 1053, 1055, 1056, 1069, 1070, 1073, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1091, 1092, 1106, 1111, 1112, 1114, 1119, 1120, 1121, 1122, 1124, 1127, 1128, 1130, 1133, 1134, 1136, 1139, 1140, 1141, 1145, 1147, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1306, 1307, 1308, 1309, 1314, 1315, 1315, 1318, 1320, 1321, 1328, 1329, 1334, 1335, 1336, 1338, 1339, 1340, 1343, 1344, 1344, 1347, 1349, 1350, 1351, 1356, 1357, 1358, 1359, 1366, 1366, 1369, 1371, 1372, 1373, 1378, 1379, 1380, 1381, 1382, 1383, 1391, 1392, 1395, 1397, 1398, 1399, 1401, 1402, 1403, 1410, 1412, 1413, 1414, 1415, 1416, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1445, 1446, 1447, 1448, 1451, 1453, 1454, 1460, 1461, 1462, 1463, 1466, 1468, 1469, 1476, 1477, 1478, 1479, 1484, 1485, 1486, 1487, 1489, 1490, 1491, 1493, 1496, 1501, 1502, 1503, 1505, 1505, 1508, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1521, 1522, 1524, 1525, 1526, 1528, 1529, 1530, 1538, 1539, 1542, 1544, 1546, 1549, 1553, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1569, 1570, 1572, 1573, 1574, 1576, 1577, 1578, 1587, 1588, 1589, 1590, 1595, 1596, 1597, 1598, 1600, 1605, 1606, 1607, 1608, 1610, 1615, 1616, 1617, 1618, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1631, 1632, 1645, 1646, 1649, 1651, 1652, 1653, 1654, 1655, 1661, 1662, 1665, 1667, 1668, 1669, 1670, 1671, 1677, 1678, 1706, 1707, 1708, 1713, 1714, 1715, 1716, 1718, 1719, 1720, 1721, 1722, 1727, 1728, 1731, 1732, 1733, 1734, 1735, 1736, 1741, 1742, 1743, 1744, 1747, 1748, 1749, 1751, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1767, 1768, 1769, 1770, 1775, 1776, 1778, 1779, 1780, 1781, 1785, 1790, 1791, 1793, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1881, 1885, 1888, 1892, 1893, 1894, 1895, 1897, 1898, 1899, 1900, 1901, 1902, 1903, 1904, 1905, 1907, 1908, 1910, 1911, 1913, 1914, 1915, 1916, 1919, 1920, 1922, 1923, 1925, 1926, 1927, 1928, 1931, 1932, 1934, 1935, 1936, 1938, 1939, 1940, 1941, 1944, 1945, 1947, 1948, 1950, 1951, 1952, 1953, 1956, 1957, 1959, 1960, 1962, 1963, 1964, 1965, 1968, 1969, 1971, 1972, 1974, 1975, 1976, 1977, 1980, 1981, 1983, 1984, 1986, 1987, 1988, 1989, 1992, 1993, 1995, 1996, 1998, 1999, 2000, 2001, 2004, 2005, 2007, 2008, 2010, 2011, 2012, 2013, 2016, 2017, 2019, 2020, 2022, 2023, 2024, 2025, 2028, 2029, 2031, 2032, 2034, 2035, 2036, 2037, 2040, 2041, 2042, 2043, 2045, 2046, 2048, 2052, 2055, 2059, 2060, 2061, 2062, 2064, 2065, 2068, 2070, 2071, 2072, 2073, 2074, 2075, 2076, 2077, 2078, 2079, 2080, 2081, 2082, 2104, 2105, 2106, 2107, 2108, 2109, 2112, 2114, 2115, 2116, 2117, 2118, 2119, 2121, 2123, 2124, 2126, 2127, 2182, 2183, 2184, 2185, 2186, 2187, 2188, 2189, 2190, 2191, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2210, 2213, 2214, 2216, 2219, 2223, 2224, 2229, 2230, 2231, 2232, 2234, 2237, 2238, 2239, 2241, 2244, 2248, 2251, 2255, 2258, 2259, 2264, 2265, 2268, 2269, 2270, 2272, 2273, 2274, 2276, 2279, 2283, 2286, 2287, 2288, 2290, 2293, 2297, 2300, 2301, 2302, 2304, 2307, 2311, 2314, 2317, 2321, 2322, 2323, 2324, 2325, 2332, 2335, 2339, 2342, 2346, 2349, 2353, 2356, 2360, 2363, 2367, 2370, 2374, 2377, 2381, 2384, 2388, 2391, 2395, 2398, 2402, 2405, 2409, 2412, 2416, 2419, 2423, 2426, 2430, 2433, 2437, 2440, 2444, 2447, 2451, 2454, 2458, 2461, 2465, 2468, 2472, 2475, 2479, 2482, 2486, 2489, 2493, 2496, 2500, 2503, 2507, 2510, 2514, 2517, 2521, 2524, 2528, 2531, 2535, 2538, 2542, 2545, 2549, 2552, 2556, 2559, 2563, 2566, 2570, 2573, 2577, 2580, 2584, 2587, 2591, 2594, 2598, 2601, 2605, 2608, 2612, 2615, 2619, 2622, 2626, 2629, 2633, 2636, 2640, 2643, 2647, 2650, 2654, 2657, 2661, 2664, 2668, 2671, 2675, 2678, 2682, 2685, 2689, 2692, 2696, 2699, 2703, 2706, 2710, 2713, 2717, 2720, 2724, 2727, 2731, 2734, 2738, 2741, 2745, 2748, 2752, 2755, 2759, 2762, 2766, 2769, 2773, 2776, 2780, 2783, 2787, 2790, 2794, 2797, 2801, 2804, 2808, 2811, 2815, 2818, 2822, 2825, 2829, 2832, 2836, 2839, 2843, 2846, 2850, 2853, 2857};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 49 196
new 0 49 196
assign 1 51 197
new 0 51 197
assign 1 52 198
new 0 52 198
assign 1 53 199
new 0 53 199
assign 1 54 200
new 0 54 200
assign 1 56 201
new 0 56 201
assign 1 57 202
new 0 57 202
assign 1 58 203
new 0 58 203
assign 1 59 204
new 0 59 204
assign 1 60 205
new 0 60 205
assign 1 61 206
new 0 61 206
assign 1 62 207
new 0 62 207
assign 1 66 208
new 0 66 208
assign 1 68 209
new 1 68 209
assign 1 69 210
ntypesGet 0 69 210
assign 1 70 211
twtokGet 0 70 211
assign 1 71 212
new 0 71 212
assign 1 71 213
new 1 71 213
assign 1 74 214
new 0 74 214
assign 1 77 215
new 0 77 215
assign 1 78 216
new 0 78 216
assign 1 79 217
new 0 79 217
assign 1 86 218
new 0 86 218
assign 1 87 219
new 0 87 219
assign 1 88 220
new 0 88 220
assign 1 89 221
new 0 89 221
assign 1 90 222
new 0 90 222
assign 1 91 223
new 0 91 223
assign 1 91 224
new 1 91 224
assign 1 99 236
def 1 99 241
assign 1 99 242
new 0 99 242
assign 1 99 243
equals 1 99 243
assign 1 0 245
assign 1 99 248
new 0 99 248
assign 1 99 249
ends 1 99 249
assign 1 0 251
assign 1 0 254
assign 1 0 258
assign 1 0 261
assign 1 0 265
assign 1 100 268
new 0 100 268
return 1 100 269
assign 1 102 271
new 0 102 271
return 1 102 272
assign 1 106 278
new 0 106 278
assign 1 106 279
new 0 106 279
assign 1 106 280
swap 2 106 280
return 1 106 281
assign 1 110 288
new 0 110 288
assign 1 110 289
argsGet 0 110 289
assign 1 111 290
new 0 111 290
assign 1 111 291
main 1 111 291
exit 1 111 292
assign 1 115 304
assign 1 116 305
new 1 116 305
assign 1 117 306
new 0 117 306
assign 1 117 307
new 0 117 307
assign 1 117 308
get 2 117 308
assign 1 117 309
firstGet 0 117 309
assign 1 117 310
new 1 117 310
assign 1 118 311
new 0 118 311
assign 1 118 314
lesser 1 118 319
assign 1 119 320
go 0 119 320
incrementValue 0 118 321
return 1 121 327
assign 1 125 335
new 0 125 335
assign 1 126 336
new 0 126 336
config 0 128 338
assign 1 129 339
new 0 129 339
assign 1 130 340
doWhat 0 130 340
assign 1 131 341
new 0 131 341
assign 1 133 345
toString 0 133 345
assign 1 134 346
new 0 134 346
assign 1 135 347
new 0 135 347
assign 1 135 348
add 1 135 348
assign 1 136 349
new 0 136 349
assign 1 0 352
assign 1 0 356
assign 1 0 359
print 0 139 363
return 1 141 365
assign 1 145 371
nameGet 0 145 371
assign 1 145 372
new 0 145 372
assign 1 145 373
equals 1 145 373
return 1 147 376
assign 1 152 528
new 0 152 528
assign 1 154 529
new 0 154 529
assign 1 155 530
get 1 155 530
assign 1 155 531
def 1 155 536
assign 1 156 537
get 1 156 537
assign 1 156 538
iteratorGet 0 0 538
assign 1 156 541
hasNextGet 0 156 541
assign 1 156 543
nextGet 0 156 543
assign 1 157 544
has 1 157 544
assign 1 157 545
not 0 157 550
put 1 158 551
assign 1 159 552
new 1 159 552
addFile 1 159 553
assign 1 164 561
new 0 164 561
assign 1 164 562
nameGet 0 164 562
assign 1 164 563
new 0 164 563
assign 1 164 564
equals 1 164 564
preProcessorSet 1 165 566
assign 1 167 568
new 0 167 568
assign 1 167 569
get 1 167 569
assign 1 167 570
firstGet 0 167 570
assign 1 168 571
new 0 168 571
assign 1 168 572
has 1 168 572
assign 1 169 574
new 0 169 574
assign 1 169 575
get 1 169 575
assign 1 169 576
firstGet 0 169 576
assign 1 171 579
assign 1 173 581
new 0 173 581
assign 1 173 582
new 0 173 582
assign 1 173 583
get 2 173 583
assign 1 173 584
firstGet 0 173 584
assign 1 173 585
new 1 173 585
assign 1 173 586
pathGet 0 173 586
addStep 1 174 587
assign 1 175 588
new 0 175 588
addStep 1 175 589
assign 1 176 590
new 0 176 590
assign 1 176 591
new 0 176 591
assign 1 176 592
get 2 176 592
assign 1 176 593
firstGet 0 176 593
assign 1 176 594
new 1 176 594
assign 1 176 595
pathGet 0 176 595
assign 1 177 596
new 0 177 596
assign 1 177 597
new 0 177 597
assign 1 177 598
nameGet 0 177 598
assign 1 177 599
get 2 177 599
assign 1 177 600
firstGet 0 177 600
assign 1 177 601
new 1 177 601
assign 1 178 602
new 0 178 602
assign 1 178 603
nameGet 0 178 603
assign 1 178 604
get 2 178 604
assign 1 178 605
firstGet 0 178 605
assign 1 178 606
new 1 178 606
assign 1 179 607
new 0 179 607
assign 1 179 608
new 0 179 608
assign 1 179 609
get 2 179 609
assign 1 179 610
firstGet 0 179 610
assign 1 179 611
new 1 179 611
assign 1 180 612
new 0 180 612
assign 1 180 613
new 0 180 613
assign 1 180 614
get 2 180 614
assign 1 180 615
firstGet 0 180 615
assign 1 180 616
new 1 180 616
assign 1 181 617
new 0 181 617
assign 1 181 618
new 0 181 618
assign 1 181 619
get 2 181 619
assign 1 181 620
firstGet 0 181 620
assign 1 181 621
new 1 181 621
assign 1 182 622
new 0 182 622
assign 1 182 623
new 0 182 623
assign 1 182 624
get 2 182 624
assign 1 182 625
firstGet 0 182 625
assign 1 182 626
new 1 182 626
assign 1 183 627
new 0 183 627
assign 1 183 628
get 1 183 628
assign 1 184 629
new 0 184 629
assign 1 184 630
get 1 184 630
assign 1 185 631
new 0 185 631
assign 1 185 632
get 1 185 632
assign 1 187 633
new 0 187 633
assign 1 187 634
get 1 187 634
assign 1 187 635
firstGet 0 187 635
assign 1 188 636
new 0 188 636
assign 1 188 637
get 1 188 637
assign 1 188 638
firstGet 0 188 638
assign 1 189 639
new 0 189 639
assign 1 189 640
get 1 189 640
assign 1 190 641
undef 1 190 646
assign 1 191 647
new 0 191 647
assign 1 193 649
new 0 193 649
assign 1 193 650
get 1 193 650
assign 1 194 651
undef 1 194 656
assign 1 195 657
new 0 195 657
assign 1 197 659
new 0 197 659
assign 1 197 660
get 1 197 660
assign 1 198 661
undef 1 198 666
assign 1 199 667
new 0 199 667
assign 1 201 669
new 0 201 669
assign 1 201 670
get 1 201 670
assign 1 202 671
undef 1 202 676
assign 1 203 677
new 0 203 677
assign 1 205 679
new 0 205 679
assign 1 205 680
get 1 205 680
assign 1 206 681
undef 1 206 686
assign 1 207 687
new 0 207 687
assign 1 209 689
new 0 209 689
assign 1 209 690
get 1 209 690
assign 1 210 691
undef 1 210 696
assign 1 211 697
new 0 211 697
assign 1 213 699
new 0 213 699
assign 1 213 700
get 1 213 700
assign 1 214 701
undef 1 214 706
assign 1 215 707
new 0 215 707
assign 1 217 709
new 0 217 709
assign 1 217 710
get 1 217 710
assign 1 218 711
undef 1 218 716
assign 1 219 717
new 0 219 717
assign 1 221 719
new 0 221 719
assign 1 221 720
get 1 221 720
assign 1 222 721
undef 1 222 726
assign 1 223 727
new 0 223 727
assign 1 225 729
new 0 225 729
assign 1 225 730
get 1 225 730
assign 1 226 731
def 1 226 736
assign 1 227 737
firstGet 0 227 737
assign 1 229 739
new 0 229 739
assign 1 229 740
get 1 229 740
assign 1 230 741
def 1 230 746
assign 1 231 747
firstGet 0 231 747
assign 1 233 750
new 0 233 750
assign 1 235 752
new 0 235 752
assign 1 235 753
new 0 235 753
assign 1 235 754
isTrue 2 235 754
assign 1 236 755
new 0 236 755
assign 1 236 756
new 0 236 756
assign 1 236 757
isTrue 2 236 757
assign 1 237 758
new 0 237 758
assign 1 237 759
isTrue 1 237 759
assign 1 238 760
new 0 238 760
assign 1 238 761
isTrue 1 238 761
assign 1 239 762
new 0 239 762
assign 1 240 763
new 0 240 763
assign 1 240 764
get 1 240 764
assign 1 241 765
def 1 241 770
assign 1 241 771
isEmptyGet 0 241 771
assign 1 241 772
not 0 241 777
assign 1 0 778
assign 1 0 781
assign 1 0 785
assign 1 242 788
linkedListIteratorGet 0 0 788
assign 1 242 791
hasNextGet 0 242 791
assign 1 242 793
nextGet 0 242 793
put 1 243 794
assign 1 246 801
new 0 246 801
assign 1 246 802
isTrue 1 246 802
assign 1 247 803
new 0 247 803
assign 1 247 804
isTrue 1 247 804
assign 1 248 805
new 0 248 805
assign 1 248 806
isTrue 1 248 806
assign 1 249 807
new 0 249 807
assign 1 249 808
isTrue 1 249 808
assign 1 250 809
new 0 250 809
assign 1 250 810
new 0 250 810
assign 1 250 811
isTrue 2 250 811
assign 1 251 812
new 0 251 812
assign 1 251 813
get 1 251 813
assign 1 252 814
new 0 252 814
assign 1 252 815
get 1 252 815
assign 1 253 816
new 0 253 816
assign 1 254 817
def 1 254 822
assign 1 255 823
linkedListIteratorGet 0 0 823
assign 1 255 826
hasNextGet 0 255 826
assign 1 255 828
nextGet 0 255 828
addValue 1 257 829
assign 1 260 836
new 0 260 836
assign 1 260 837
new 0 260 837
assign 1 260 838
get 2 260 838
assign 1 260 839
firstGet 0 260 839
assign 1 261 840
new 0 261 840
assign 1 261 841
new 0 261 841
assign 1 261 842
get 2 261 842
assign 1 261 843
firstGet 0 261 843
assign 1 262 844
new 0 262 844
assign 1 262 845
add 1 262 845
assign 1 262 846
new 0 262 846
assign 1 262 847
get 2 262 847
assign 1 262 848
firstGet 0 262 848
assign 1 263 849
new 0 263 849
assign 1 264 850
new 0 264 850
assign 1 265 851
new 0 265 851
assign 1 266 852
new 0 266 852
assign 1 267 853
new 0 267 853
assign 1 270 854
def 1 270 859
assign 1 271 860
firstGet 0 271 860
assign 1 273 863
new 0 273 863
assign 1 280 865
new 0 280 865
assign 1 280 866
add 1 280 866
assign 1 280 867
nameGet 0 280 867
assign 1 280 868
add 1 280 868
assign 1 280 869
get 1 280 869
assign 1 281 870
def 1 281 875
assign 1 282 876
orderedGet 0 282 876
addAll 1 282 877
assign 1 285 879
new 0 285 879
assign 1 285 880
add 1 285 880
assign 1 285 881
get 1 285 881
assign 1 286 882
def 1 286 887
assign 1 287 888
orderedGet 0 287 888
addAll 1 287 889
assign 1 290 891
new 0 290 891
assign 1 291 892
orderedGet 0 291 892
assign 1 291 893
iteratorGet 0 0 893
assign 1 291 896
hasNextGet 0 291 896
assign 1 291 898
nextGet 0 291 898
assign 1 292 899
new 1 292 899
addValue 1 292 900
assign 1 294 906
newlineGet 0 294 906
assign 1 295 907
assign 1 296 908
new 1 296 908
assign 1 298 909
copy 0 298 909
assign 1 299 910
fileGet 0 299 910
assign 1 299 911
existsGet 0 299 911
assign 1 299 912
not 0 299 917
assign 1 300 918
fileGet 0 300 918
makeDirs 0 300 919
assign 1 302 921
def 1 302 926
assign 1 303 927
new 1 303 927
assign 1 303 928
readerGet 0 303 928
assign 1 304 929
open 0 304 929
assign 1 304 930
readString 0 304 930
close 0 305 931
assign 1 310 946
new 0 310 946
assign 1 310 947
className 1 310 947
assign 1 311 948
add 1 311 948
assign 1 311 949
new 0 311 949
assign 1 311 950
add 1 311 950
assign 1 311 951
toString 0 311 951
assign 1 311 952
add 1 311 952
assign 1 312 953
add 1 312 953
assign 1 312 954
new 0 312 954
assign 1 312 955
add 1 312 955
assign 1 312 956
toString 0 312 956
assign 1 312 957
add 1 312 957
return 1 313 958
assign 1 317 998
new 0 317 998
assign 1 318 999
classesGet 0 318 999
assign 1 318 1000
valueIteratorGet 0 318 1000
assign 1 318 1003
hasNextGet 0 318 1003
assign 1 319 1005
nextGet 0 319 1005
assign 1 320 1006
shouldEmitGet 0 320 1006
assign 1 320 1007
heldGet 0 320 1007
assign 1 320 1008
fromFileGet 0 320 1008
assign 1 320 1009
has 1 320 1009
assign 1 321 1011
heldGet 0 321 1011
assign 1 321 1012
namepathGet 0 321 1012
assign 1 321 1013
toString 0 321 1013
put 1 321 1014
assign 1 322 1015
usedByGet 0 322 1015
assign 1 322 1016
heldGet 0 322 1016
assign 1 322 1017
namepathGet 0 322 1017
assign 1 322 1018
toString 0 322 1018
assign 1 322 1019
get 1 322 1019
assign 1 323 1020
def 1 323 1025
assign 1 324 1026
setIteratorGet 0 0 1026
assign 1 324 1029
hasNextGet 0 324 1029
assign 1 324 1031
nextGet 0 324 1031
put 1 325 1032
assign 1 328 1039
subClassesGet 0 328 1039
assign 1 328 1040
heldGet 0 328 1040
assign 1 328 1041
namepathGet 0 328 1041
assign 1 328 1042
toString 0 328 1042
assign 1 328 1043
get 1 328 1043
assign 1 329 1044
def 1 329 1049
assign 1 330 1050
setIteratorGet 0 0 1050
assign 1 330 1053
hasNextGet 0 330 1053
assign 1 330 1055
nextGet 0 330 1055
put 1 331 1056
assign 1 336 1069
classesGet 0 336 1069
assign 1 336 1070
valueIteratorGet 0 336 1070
assign 1 336 1073
hasNextGet 0 336 1073
assign 1 337 1075
nextGet 0 337 1075
assign 1 338 1076
heldGet 0 338 1076
assign 1 338 1077
heldGet 0 338 1077
assign 1 338 1078
namepathGet 0 338 1078
assign 1 338 1079
toString 0 338 1079
assign 1 338 1080
has 1 338 1080
shouldWriteSet 1 338 1081
assign 1 345 1091
new 0 345 1091
return 1 345 1092
assign 1 349 1106
def 1 349 1111
return 1 350 1112
assign 1 355 1114
def 1 355 1119
assign 1 356 1120
firstGet 0 356 1120
assign 1 357 1121
new 0 357 1121
assign 1 357 1122
equals 1 357 1122
assign 1 358 1124
new 1 358 1124
assign 1 359 1127
new 0 359 1127
assign 1 359 1128
equals 1 359 1128
assign 1 360 1130
new 1 360 1130
assign 1 361 1133
new 0 361 1133
assign 1 361 1134
equals 1 361 1134
assign 1 362 1136
new 1 362 1136
assign 1 364 1139
new 0 364 1139
assign 1 364 1140
new 1 364 1140
throw 1 364 1141
return 1 366 1145
return 1 368 1147
assign 1 372 1166
apNew 1 372 1166
assign 1 374 1167
new 0 374 1167
assign 1 374 1168
add 1 374 1168
print 0 374 1169
assign 1 375 1170
new 0 375 1170
assign 1 375 1171
now 0 375 1171
assign 1 376 1172
fileGet 0 376 1172
assign 1 376 1173
readerGet 0 376 1173
assign 1 376 1174
open 0 376 1174
assign 1 377 1175
new 0 377 1175
assign 1 377 1176
deserialize 1 377 1176
close 0 378 1177
assign 1 379 1178
synClassesGet 0 379 1178
addValue 1 379 1179
assign 1 380 1180
new 0 380 1180
assign 1 380 1181
now 0 380 1181
assign 1 380 1182
subtract 1 380 1182
assign 1 381 1183
new 0 381 1183
assign 1 381 1184
add 1 381 1184
print 0 381 1185
assign 1 387 1306
new 0 387 1306
assign 1 387 1307
now 0 387 1307
assign 1 388 1308
new 0 388 1308
assign 1 389 1309
def 1 389 1314
assign 1 390 1315
linkedListIteratorGet 0 0 1315
assign 1 390 1318
hasNextGet 0 390 1318
assign 1 390 1320
nextGet 0 390 1320
loadSyns 1 391 1321
assign 1 394 1328
emitterGet 0 394 1328
assign 1 395 1329
def 1 395 1334
assign 1 396 1335
new 4 396 1335
put 1 397 1336
assign 1 399 1338
new 0 399 1338
assign 1 399 1339
add 1 399 1339
print 0 399 1340
assign 1 402 1343
new 0 402 1343
assign 1 404 1344
iteratorGet 0 0 1344
assign 1 404 1347
hasNextGet 0 404 1347
assign 1 404 1349
nextGet 0 404 1349
assign 1 405 1350
has 1 405 1350
assign 1 405 1351
not 0 405 1356
put 1 406 1357
assign 1 407 1358
new 2 407 1358
addValue 1 408 1359
assign 1 411 1366
iteratorGet 0 0 1366
assign 1 411 1369
hasNextGet 0 411 1369
assign 1 411 1371
nextGet 0 411 1371
assign 1 412 1372
has 1 412 1372
assign 1 412 1373
not 0 412 1378
put 1 413 1379
assign 1 414 1380
new 2 414 1380
addValue 1 415 1381
assign 1 416 1382
libNameGet 0 416 1382
put 1 416 1383
assign 1 421 1391
new 0 421 1391
assign 1 422 1392
iteratorGet 0 422 1392
assign 1 422 1395
hasNextGet 0 422 1395
assign 1 423 1397
nextGet 0 423 1397
assign 1 425 1398
toString 0 425 1398
assign 1 425 1399
has 1 425 1399
assign 1 426 1401
toString 0 426 1401
put 1 426 1402
doParse 1 427 1403
buildSyns 1 430 1410
assign 1 433 1412
new 0 433 1412
assign 1 433 1413
now 0 433 1413
assign 1 433 1414
subtract 1 433 1414
assign 1 436 1415
emitCommonGet 0 436 1415
assign 1 436 1416
def 1 436 1421
assign 1 438 1422
new 0 438 1422
assign 1 438 1423
now 0 438 1423
assign 1 439 1424
emitCommonGet 0 439 1424
doEmit 0 439 1425
assign 1 440 1426
new 0 440 1426
assign 1 440 1427
now 0 440 1427
assign 1 440 1428
subtract 1 440 1428
assign 1 441 1429
new 0 441 1429
assign 1 441 1430
now 0 441 1430
assign 1 441 1431
subtract 1 441 1431
assign 1 442 1432
new 0 442 1432
assign 1 442 1433
add 1 442 1433
print 0 442 1434
assign 1 443 1435
new 0 443 1435
assign 1 443 1436
add 1 443 1436
print 0 443 1437
assign 1 444 1438
new 0 444 1438
assign 1 444 1439
add 1 444 1439
print 0 444 1440
assign 1 445 1441
new 0 445 1441
return 1 445 1442
setClassesToWrite 0 448 1445
libnameInfoGet 0 449 1446
assign 1 451 1447
classesGet 0 451 1447
assign 1 451 1448
valueIteratorGet 0 451 1448
assign 1 451 1451
hasNextGet 0 451 1451
assign 1 452 1453
nextGet 0 452 1453
doEmit 1 453 1454
emitMain 0 455 1460
emitCUInit 0 456 1461
assign 1 457 1462
classesGet 0 457 1462
assign 1 457 1463
valueIteratorGet 0 457 1463
assign 1 457 1466
hasNextGet 0 457 1466
assign 1 458 1468
nextGet 0 458 1468
emitSyn 1 459 1469
assign 1 463 1476
new 0 463 1476
assign 1 463 1477
now 0 463 1477
assign 1 463 1478
subtract 1 463 1478
assign 1 464 1479
def 1 464 1484
assign 1 465 1485
new 0 465 1485
assign 1 465 1486
add 1 465 1486
print 0 465 1487
assign 1 467 1489
new 0 467 1489
assign 1 467 1490
add 1 467 1490
print 0 467 1491
prepMake 1 470 1493
assign 1 474 1496
not 0 474 1501
make 1 475 1502
deployLibrary 1 476 1503
assign 1 478 1505
linkedListIteratorGet 0 0 1505
assign 1 478 1508
hasNextGet 0 478 1508
assign 1 478 1510
nextGet 0 478 1510
assign 1 479 1511
libnameInfoGet 0 479 1511
assign 1 479 1512
unitShlibGet 0 479 1512
assign 1 480 1513
emitPathGet 0 480 1513
assign 1 480 1514
copy 0 480 1514
assign 1 481 1515
stepsGet 0 481 1515
assign 1 481 1516
lastGet 0 481 1516
addStep 1 481 1517
assign 1 482 1518
fileGet 0 482 1518
assign 1 482 1519
existsGet 0 482 1519
assign 1 483 1521
fileGet 0 483 1521
delete 0 483 1522
assign 1 485 1524
fileGet 0 485 1524
assign 1 485 1525
existsGet 0 485 1525
assign 1 485 1526
not 0 485 1526
assign 1 486 1528
fileGet 0 486 1528
assign 1 486 1529
fileGet 0 486 1529
deployFile 2 486 1530
assign 1 490 1538
iteratorGet 0 490 1538
assign 1 491 1539
iteratorGet 0 491 1539
assign 1 493 1542
hasNextGet 0 493 1542
assign 1 493 1544
hasNextGet 0 493 1544
assign 1 0 1546
assign 1 0 1549
assign 1 0 1553
assign 1 494 1556
nextGet 0 494 1556
assign 1 494 1557
apNew 1 494 1557
assign 1 495 1558
emitPathGet 0 495 1558
assign 1 495 1559
copy 0 495 1559
assign 1 495 1560
toString 0 495 1560
assign 1 495 1561
new 0 495 1561
assign 1 495 1562
add 1 495 1562
assign 1 495 1563
nextGet 0 495 1563
assign 1 495 1564
add 1 495 1564
assign 1 495 1565
apNew 1 495 1565
assign 1 497 1566
fileGet 0 497 1566
assign 1 497 1567
existsGet 0 497 1567
assign 1 498 1569
fileGet 0 498 1569
delete 0 498 1570
assign 1 500 1572
fileGet 0 500 1572
assign 1 500 1573
existsGet 0 500 1573
assign 1 500 1574
not 0 500 1574
assign 1 501 1576
fileGet 0 501 1576
assign 1 501 1577
fileGet 0 501 1577
deployFile 2 501 1578
assign 1 506 1587
new 0 506 1587
assign 1 506 1588
now 0 506 1588
assign 1 506 1589
subtract 1 506 1589
assign 1 508 1590
def 1 508 1595
assign 1 509 1596
new 0 509 1596
assign 1 509 1597
add 1 509 1597
print 0 509 1598
assign 1 511 1600
def 1 511 1605
assign 1 512 1606
new 0 512 1606
assign 1 512 1607
add 1 512 1607
print 0 512 1608
assign 1 514 1610
def 1 514 1615
assign 1 515 1616
new 0 515 1616
assign 1 515 1617
add 1 515 1617
print 0 515 1618
assign 1 519 1621
new 0 519 1621
print 0 519 1622
assign 1 520 1623
run 2 520 1623
assign 1 521 1624
new 0 521 1624
assign 1 521 1625
add 1 521 1625
assign 1 521 1626
new 0 521 1626
assign 1 521 1627
add 1 521 1627
print 0 521 1628
return 1 522 1629
assign 1 524 1631
new 0 524 1631
return 1 524 1632
assign 1 528 1645
justParsedGet 0 528 1645
assign 1 528 1646
valueIteratorGet 0 528 1646
assign 1 528 1649
hasNextGet 0 528 1649
assign 1 529 1651
nextGet 0 529 1651
assign 1 530 1652
heldGet 0 530 1652
libNameSet 1 530 1653
assign 1 531 1654
getSyn 2 531 1654
libNameSet 1 532 1655
assign 1 534 1661
justParsedGet 0 534 1661
assign 1 534 1662
valueIteratorGet 0 534 1662
assign 1 534 1665
hasNextGet 0 534 1665
assign 1 535 1667
nextGet 0 535 1667
assign 1 536 1668
heldGet 0 536 1668
assign 1 536 1669
synGet 0 536 1669
checkInheritance 2 537 1670
integrate 1 538 1671
assign 1 540 1677
new 0 540 1677
justParsedSet 1 540 1678
assign 1 544 1706
heldGet 0 544 1706
assign 1 544 1707
synGet 0 544 1707
assign 1 544 1708
def 1 544 1713
assign 1 545 1714
heldGet 0 545 1714
assign 1 545 1715
synGet 0 545 1715
return 1 545 1716
assign 1 547 1718
heldGet 0 547 1718
libNameSet 1 547 1719
assign 1 548 1720
heldGet 0 548 1720
assign 1 548 1721
extendsGet 0 548 1721
assign 1 548 1722
undef 1 548 1727
assign 1 549 1728
new 1 549 1728
assign 1 551 1731
classesGet 0 551 1731
assign 1 551 1732
heldGet 0 551 1732
assign 1 551 1733
extendsGet 0 551 1733
assign 1 551 1734
toString 0 551 1734
assign 1 551 1735
get 1 551 1735
assign 1 553 1736
def 1 553 1741
assign 1 554 1742
heldGet 0 554 1742
libNameSet 1 554 1743
assign 1 555 1744
getSyn 2 555 1744
assign 1 559 1747
heldGet 0 559 1747
assign 1 559 1748
extendsGet 0 559 1748
assign 1 559 1749
getSynNp 1 559 1749
assign 1 561 1751
new 2 561 1751
assign 1 563 1753
heldGet 0 563 1753
synSet 1 563 1754
assign 1 564 1755
heldGet 0 564 1755
assign 1 564 1756
namepathGet 0 564 1756
assign 1 564 1757
toString 0 564 1757
addSynClass 2 564 1758
return 1 565 1759
assign 1 569 1767
toString 0 569 1767
assign 1 570 1768
synClassesGet 0 570 1768
assign 1 570 1769
get 1 570 1769
assign 1 571 1770
def 1 571 1775
return 1 572 1776
assign 1 578 1778
emitterGet 0 578 1778
assign 1 578 1779
loadSyn 1 578 1779
addSynClass 2 579 1780
return 1 580 1781
assign 1 587 1785
undef 1 587 1790
assign 1 588 1791
new 1 588 1791
return 1 590 1793
assign 1 595 1872
new 1 595 1872
assign 1 596 1873
new 0 596 1873
assign 1 597 1874
emitterGet 0 597 1874
assign 1 598 1875
assign 1 599 1876
new 0 599 1876
assign 1 600 1877
shouldEmitGet 0 600 1877
put 1 600 1878
assign 1 0 1881
assign 1 0 1885
assign 1 0 1888
assign 1 603 1892
new 0 603 1892
assign 1 603 1893
toString 0 603 1893
assign 1 603 1894
add 1 603 1894
print 0 603 1895
assign 1 605 1897
assign 1 607 1898
fileGet 0 607 1898
assign 1 607 1899
readerGet 0 607 1899
assign 1 607 1900
open 0 607 1900
assign 1 607 1901
readBuffer 1 607 1901
assign 1 608 1902
fileGet 0 608 1902
assign 1 608 1903
readerGet 0 608 1903
close 0 608 1904
assign 1 611 1905
tokenize 1 611 1905
assign 1 615 1907
new 0 615 1907
echo 0 615 1908
assign 1 617 1910
outermostGet 0 617 1910
nodify 2 617 1911
assign 1 619 1913
new 0 619 1913
print 0 619 1914
assign 1 620 1915
new 2 620 1915
traverse 1 620 1916
assign 1 624 1919
new 0 624 1919
echo 0 624 1920
assign 1 626 1922
new 0 626 1922
traverse 1 626 1923
assign 1 628 1925
new 0 628 1925
print 0 628 1926
assign 1 629 1927
new 2 629 1927
traverse 1 629 1928
assign 1 632 1931
new 0 632 1931
echo 0 632 1932
assign 1 635 1934
new 0 635 1934
traverse 1 635 1935
contain 0 636 1936
assign 1 638 1938
new 0 638 1938
print 0 638 1939
assign 1 639 1940
new 2 639 1940
traverse 1 639 1941
assign 1 643 1944
new 0 643 1944
echo 0 643 1945
assign 1 645 1947
new 0 645 1947
traverse 1 645 1948
assign 1 647 1950
new 0 647 1950
print 0 647 1951
assign 1 648 1952
new 2 648 1952
traverse 1 648 1953
assign 1 652 1956
new 0 652 1956
echo 0 652 1957
assign 1 654 1959
new 0 654 1959
traverse 1 654 1960
assign 1 656 1962
new 0 656 1962
print 0 656 1963
assign 1 657 1964
new 2 657 1964
traverse 1 657 1965
assign 1 661 1968
new 0 661 1968
echo 0 661 1969
assign 1 663 1971
new 0 663 1971
traverse 1 663 1972
assign 1 665 1974
new 0 665 1974
print 0 665 1975
assign 1 666 1976
new 2 666 1976
traverse 1 666 1977
assign 1 670 1980
new 0 670 1980
echo 0 670 1981
assign 1 672 1983
new 0 672 1983
traverse 1 672 1984
assign 1 674 1986
new 0 674 1986
print 0 674 1987
assign 1 675 1988
new 2 675 1988
traverse 1 675 1989
assign 1 679 1992
new 0 679 1992
echo 0 679 1993
assign 1 681 1995
new 0 681 1995
traverse 1 681 1996
assign 1 683 1998
new 0 683 1998
print 0 683 1999
assign 1 684 2000
new 2 684 2000
traverse 1 684 2001
assign 1 688 2004
new 0 688 2004
echo 0 688 2005
assign 1 690 2007
new 0 690 2007
traverse 1 690 2008
assign 1 692 2010
new 0 692 2010
print 0 692 2011
assign 1 693 2012
new 2 693 2012
traverse 1 693 2013
assign 1 697 2016
new 0 697 2016
echo 0 697 2017
assign 1 699 2019
new 0 699 2019
traverse 1 699 2020
assign 1 701 2022
new 0 701 2022
print 0 701 2023
assign 1 702 2024
new 2 702 2024
traverse 1 702 2025
assign 1 705 2028
new 0 705 2028
echo 0 705 2029
assign 1 707 2031
new 0 707 2031
traverse 1 707 2032
assign 1 709 2034
new 0 709 2034
print 0 709 2035
assign 1 710 2036
new 2 710 2036
traverse 1 710 2037
assign 1 714 2040
new 0 714 2040
echo 0 714 2041
assign 1 715 2042
new 0 715 2042
print 0 715 2043
assign 1 717 2045
new 0 717 2045
traverse 1 717 2046
assign 1 0 2048
assign 1 0 2052
assign 1 0 2055
assign 1 719 2059
new 0 719 2059
print 0 719 2060
assign 1 720 2061
new 2 720 2061
traverse 1 720 2062
assign 1 722 2064
classesGet 0 722 2064
assign 1 722 2065
valueIteratorGet 0 722 2065
assign 1 722 2068
hasNextGet 0 722 2068
assign 1 723 2070
nextGet 0 723 2070
assign 1 725 2071
transUnitGet 0 725 2071
assign 1 726 2072
new 1 726 2072
assign 1 727 2073
TRANSUNITGet 0 727 2073
typenameSet 1 727 2074
assign 1 728 2075
new 0 728 2075
assign 1 729 2076
heldGet 0 729 2076
assign 1 729 2077
emitsGet 0 729 2077
emitsSet 1 729 2078
heldSet 1 730 2079
delete 0 731 2080
addValue 1 732 2081
copyLoc 1 733 2082
reInitContained 0 739 2104
assign 1 740 2105
containedGet 0 740 2105
assign 1 741 2106
new 0 741 2106
assign 1 742 2107
new 0 742 2107
assign 1 742 2108
crGet 0 742 2108
assign 1 743 2109
linkedListIteratorGet 0 743 2109
assign 1 743 2112
hasNextGet 0 743 2112
assign 1 744 2114
new 1 744 2114
assign 1 745 2115
nextGet 0 745 2115
heldSet 1 745 2116
nlcSet 1 746 2117
assign 1 747 2118
heldGet 0 747 2118
assign 1 747 2119
equals 1 747 2119
assign 1 748 2121
increment 0 748 2121
assign 1 750 2123
heldGet 0 750 2123
assign 1 750 2124
notEquals 1 750 2124
addValue 1 751 2126
containerSet 1 752 2127
assign 1 759 2182
new 0 759 2182
fromString 1 760 2183
assign 1 762 2184
new 1 762 2184
assign 1 763 2185
NAMEPATHGet 0 763 2185
typenameSet 1 763 2186
heldSet 1 764 2187
copyLoc 1 765 2188
assign 1 767 2189
new 0 767 2189
assign 1 768 2190
new 0 768 2190
nameSet 1 768 2191
assign 1 769 2192
new 0 769 2192
wasBoundSet 1 769 2193
assign 1 770 2194
new 0 770 2194
boundSet 1 770 2195
assign 1 771 2196
new 0 771 2196
isConstructSet 1 771 2197
assign 1 772 2198
new 0 772 2198
isLiteralSet 1 772 2199
assign 1 773 2200
heldGet 0 773 2200
literalValueSet 1 773 2201
addValue 1 775 2202
assign 1 777 2203
CALLGet 0 777 2203
typenameSet 1 777 2204
heldSet 1 778 2205
resolveNp 0 780 2206
assign 1 782 2207
new 0 782 2207
assign 1 782 2208
equals 1 782 2208
assign 1 0 2210
assign 1 782 2213
new 0 782 2213
assign 1 782 2214
equals 1 782 2214
assign 1 0 2216
assign 1 0 2219
assign 1 783 2223
priorPeerGet 0 783 2223
assign 1 784 2224
def 1 784 2229
assign 1 784 2230
typenameGet 0 784 2230
assign 1 784 2231
SUBTRACTGet 0 784 2231
assign 1 784 2232
equals 1 784 2232
assign 1 0 2234
assign 1 784 2237
typenameGet 0 784 2237
assign 1 784 2238
ADDGet 0 784 2238
assign 1 784 2239
equals 1 784 2239
assign 1 0 2241
assign 1 0 2244
assign 1 0 2248
assign 1 0 2251
assign 1 0 2255
assign 1 785 2258
priorPeerGet 0 785 2258
assign 1 786 2259
undef 1 786 2264
assign 1 0 2265
assign 1 786 2268
typenameGet 0 786 2268
assign 1 786 2269
CALLGet 0 786 2269
assign 1 786 2270
notEquals 1 786 2270
assign 1 786 2272
typenameGet 0 786 2272
assign 1 786 2273
IDGet 0 786 2273
assign 1 786 2274
notEquals 1 786 2274
assign 1 0 2276
assign 1 0 2279
assign 1 0 2283
assign 1 786 2286
typenameGet 0 786 2286
assign 1 786 2287
VARGet 0 786 2287
assign 1 786 2288
notEquals 1 786 2288
assign 1 0 2290
assign 1 0 2293
assign 1 0 2297
assign 1 786 2300
typenameGet 0 786 2300
assign 1 786 2301
ACCESSORGet 0 786 2301
assign 1 786 2302
notEquals 1 786 2302
assign 1 0 2304
assign 1 0 2307
assign 1 0 2311
assign 1 0 2314
assign 1 0 2317
assign 1 792 2321
heldGet 0 792 2321
assign 1 792 2322
literalValueGet 0 792 2322
assign 1 792 2323
add 1 792 2323
literalValueSet 1 792 2324
delete 0 793 2325
return 1 0 2332
assign 1 0 2335
return 1 0 2339
assign 1 0 2342
return 1 0 2346
assign 1 0 2349
return 1 0 2353
assign 1 0 2356
return 1 0 2360
assign 1 0 2363
return 1 0 2367
assign 1 0 2370
return 1 0 2374
assign 1 0 2377
return 1 0 2381
assign 1 0 2384
return 1 0 2388
assign 1 0 2391
return 1 0 2395
assign 1 0 2398
return 1 0 2402
assign 1 0 2405
return 1 0 2409
assign 1 0 2412
return 1 0 2416
assign 1 0 2419
return 1 0 2423
assign 1 0 2426
return 1 0 2430
assign 1 0 2433
return 1 0 2437
assign 1 0 2440
return 1 0 2444
assign 1 0 2447
return 1 0 2451
assign 1 0 2454
return 1 0 2458
assign 1 0 2461
return 1 0 2465
assign 1 0 2468
return 1 0 2472
assign 1 0 2475
return 1 0 2479
assign 1 0 2482
return 1 0 2486
assign 1 0 2489
return 1 0 2493
assign 1 0 2496
return 1 0 2500
assign 1 0 2503
return 1 0 2507
assign 1 0 2510
return 1 0 2514
assign 1 0 2517
return 1 0 2521
assign 1 0 2524
return 1 0 2528
assign 1 0 2531
return 1 0 2535
assign 1 0 2538
return 1 0 2542
assign 1 0 2545
return 1 0 2549
assign 1 0 2552
return 1 0 2556
assign 1 0 2559
return 1 0 2563
assign 1 0 2566
return 1 0 2570
assign 1 0 2573
return 1 0 2577
assign 1 0 2580
return 1 0 2584
assign 1 0 2587
return 1 0 2591
assign 1 0 2594
return 1 0 2598
assign 1 0 2601
return 1 0 2605
assign 1 0 2608
return 1 0 2612
assign 1 0 2615
return 1 0 2619
assign 1 0 2622
return 1 0 2626
assign 1 0 2629
return 1 0 2633
assign 1 0 2636
return 1 0 2640
assign 1 0 2643
return 1 0 2647
assign 1 0 2650
return 1 0 2654
assign 1 0 2657
return 1 0 2661
assign 1 0 2664
return 1 0 2668
assign 1 0 2671
return 1 0 2675
assign 1 0 2678
return 1 0 2682
assign 1 0 2685
return 1 0 2689
assign 1 0 2692
return 1 0 2696
assign 1 0 2699
return 1 0 2703
assign 1 0 2706
return 1 0 2710
assign 1 0 2713
return 1 0 2717
assign 1 0 2720
return 1 0 2724
assign 1 0 2727
return 1 0 2731
assign 1 0 2734
return 1 0 2738
assign 1 0 2741
return 1 0 2745
assign 1 0 2748
return 1 0 2752
assign 1 0 2755
return 1 0 2759
assign 1 0 2762
return 1 0 2766
assign 1 0 2769
return 1 0 2773
assign 1 0 2776
return 1 0 2780
assign 1 0 2783
return 1 0 2787
assign 1 0 2790
return 1 0 2794
assign 1 0 2797
return 1 0 2801
assign 1 0 2804
return 1 0 2808
assign 1 0 2811
return 1 0 2815
assign 1 0 2818
return 1 0 2822
assign 1 0 2825
return 1 0 2829
assign 1 0 2832
return 1 0 2836
assign 1 0 2839
return 1 0 2843
assign 1 0 2846
return 1 0 2850
assign 1 0 2853
assign 1 0 2857
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -299232554: return bem_outputPlatformGet_0();
case 1847027530: return bem_libNameGet_0();
case -1972541548: return bem_emitCs_0();
case -1197278081: return bem_usedLibrarysStrGet_0();
case 577156141: return bem_genOnlyGet_0();
case -857031112: return bem_initLibsGet_0();
case -1347347529: return bem_platformGet_0();
case 1718859954: return bem_deployLibraryGet_0();
case 1944509558: return bem_printAllAstGet_0();
case 721433396: return bem_argsGet_0();
case -1667624633: return bem_twtokGet_0();
case -2069487971: return bem_makeGet_0();
case 1550982742: return bem_makeArgsGet_0();
case -2112499595: return bem_ccObjArgsGet_0();
case 1530906677: return bem_paramsGet_0();
case -393061672: return bem_buildSucceededGet_0();
case -1522787406: return bem_closeLibrariesGet_0();
case 1753231484: return bem_ownProcessGet_0();
case -1937935225: return bem_newlineGet_0();
case 2035657214: return bem_emitDataGet_0();
case -159849764: return bem_hashGet_0();
case -1020125618: return bem_parseGet_0();
case 2102520524: return bem_deployPathGet_0();
case 1101703824: return bem_buildMessageGet_0();
case -285827633: return bem_codeGet_0();
case -235591676: return bem_parseEmitTimeGet_0();
case 1816992164: return bem_emitChecksGet_0();
case -86753562: return bem_singleCCGet_0();
case 2086448614: return bem_extLinkObjectsGet_0();
case -1562912086: return bem_doMainGet_0();
case 1739248355: return bem_deployUsedLibrariesGet_0();
case 431414617: return bem_parseEmitCompileTimeGet_0();
case -860967133: return bem_emitCommonGet_0();
case 1958738325: return bem_deployFilesToGet_0();
case 1140404476: return bem_iteratorGet_0();
case -516951268: return bem_parseTimeGet_0();
case 590663260: return bem_usedLibrarysGet_0();
case 1292239262: return bem_compilerGet_0();
case -105023770: return bem_emitFlagsGet_0();
case 56108897: return bem_emitFileHeaderGet_0();
case 2102553486: return bem_printPlacesGet_0();
case -790309006: return bem_emitLibraryGet_0();
case 1568765024: return bem_startTimeGet_0();
case -1202641585: return bem_toBuildGet_0();
case 1627322867: return bem_loadSynsGet_0();
case -2060498988: return bem_closeLibrariesStrGet_0();
case -1511254172: return bem_printAstGet_0();
case 1550514760: return bem_readBufferGet_0();
case 110543526: return bem_config_0();
case -1689509189: return bem_builtGet_0();
case 607182923: return bem_doWhat_0();
case -1554099210: return bem_runArgsGet_0();
case 1403353724: return bem_main_0();
case -2018922896: return bem_doEmitGet_0();
case 983904679: return bem_constantsGet_0();
case -297667472: return bem_estrGet_0();
case 376521784: return bem_fromFileGet_0();
case -1787566061: return bem_go_0();
case -767496314: return bem_makeNameGet_0();
case -1684863513: return bem_putLineNumbersInTraceGet_0();
case 1734725543: return bem_emitPathGet_0();
case 153130764: return bem_print_0();
case -1031336946: return bem_runGet_0();
case 1964033157: return bem_saveSynsGet_0();
case 1910676521: return bem_lctokGet_0();
case -60142962: return bem_emitDebugGet_0();
case -187492472: return bem_new_0();
case -368874719: return bem_printStepsGet_0();
case -82017130: return bem_toString_0();
case 1937490521: return bem_exeNameGet_0();
case 49505741: return bem_nlGet_0();
case 1799353425: return bem_emitterGet_0();
case -565296963: return bem_compilerProfileGet_0();
case -1766698336: return bem_extIncludesGet_0();
case -1332196255: return bem_mainNameGet_0();
case 448867364: return bem_printAstElementsGet_0();
case 416881831: return bem_copy_0();
case -1754165148: return bem_sharedEmitterGet_0();
case -18424967: return bem_linkLibArgsGet_0();
case -123196615: return bem_prepMakeGet_0();
case -1769979151: return bem_saveIdsGet_0();
case 849651383: return bem_loadIdsGet_0();
case 2145889240: return bem_buildPathGet_0();
case 1314272582: return bem_ntypesGet_0();
case -477278434: return bem_extLibsGet_0();
case -1468672749: return bem_includePathGet_0();
case -1409767181: return bem_emitLangsGet_0();
case -2046423278: return bem_setClassesToWrite_0();
case 324521155: return bem_create_0();
case -950097353: return bem_deployFilesFromGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -21788173: return bem_buildPathSet_1(bevd_0);
case -1984286538: return bem_loadIdsSet_1(bevd_0);
case 985140183: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 452999425: return bem_exeNameSet_1(bevd_0);
case 829639394: return bem_emitChecksSet_1(bevd_0);
case -1095073551: return bem_deployFilesToSet_1(bevd_0);
case 1832781102: return bem_mainNameSet_1(bevd_0);
case 400407075: return bem_usedLibrarysStrSet_1(bevd_0);
case -266013337: return bem_doEmitSet_1(bevd_0);
case 1474625106: return bem_printStepsSet_1(bevd_0);
case 71992266: return bem_sharedEmitterSet_1(bevd_0);
case -1436175409: return bem_usedLibrarysSet_1(bevd_0);
case 2077047635: return bem_compilerProfileSet_1(bevd_0);
case 352064636: return bem_prepMakeSet_1(bevd_0);
case 2036832294: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 95612826: return bem_toBuildSet_1(bevd_0);
case -1270934482: return bem_buildSyns_1(bevd_0);
case 298599394: return bem_emitFileHeaderSet_1(bevd_0);
case -702562956: return bem_codeSet_1(bevd_0);
case -214683463: return bem_loadSynsSet_1(bevd_0);
case -1631939162: return bem_printPlacesSet_1(bevd_0);
case -444681464: return bem_extIncludesSet_1(bevd_0);
case -1622413801: return bem_closeLibrariesStrSet_1(bevd_0);
case 1009921363: return bem_emitPathSet_1(bevd_0);
case 1275020344: return bem_buildSucceededSet_1(bevd_0);
case 1999877532: return bem_emitLibrarySet_1(bevd_0);
case -1452000997: return bem_makeNameSet_1(bevd_0);
case 1553965981: return bem_builtSet_1(bevd_0);
case -377700156: return bem_deployLibrarySet_1(bevd_0);
case -385349452: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -1094858203: return bem_doParse_1(bevd_0);
case 1952476190: return bem_printAllAstSet_1(bevd_0);
case 282218654: return bem_ownProcessSet_1(bevd_0);
case 1322420987: return bem_emitLangsSet_1(bevd_0);
case 580028650: return bem_outputPlatformSet_1(bevd_0);
case 541142520: return bem_linkLibArgsSet_1(bevd_0);
case 116965442: return bem_fromFileSet_1(bevd_0);
case -817039328: return bem_emitCommonSet_1(bevd_0);
case 1926678961: return bem_singleCCSet_1(bevd_0);
case -2020373384: return bem_ccObjArgsSet_1(bevd_0);
case 1336352814: return bem_copyTo_1(bevd_0);
case 2068773393: return bem_deployUsedLibrariesSet_1(bevd_0);
case -1089475466: return bem_extLibsSet_1(bevd_0);
case -293304165: return bem_emitDataSet_1(bevd_0);
case -10556524: return bem_buildMessageSet_1(bevd_0);
case 999066949: return bem_readBufferSet_1(bevd_0);
case 685215154: return bem_getSynNp_1(bevd_0);
case 1691004525: return bem_doMainSet_1(bevd_0);
case 95405989: return bem_runArgsSet_1(bevd_0);
case -1365129240: return bem_newlineSet_1(bevd_0);
case 886982221: return bem_parseSet_1(bevd_0);
case -325206129: return bem_nlSet_1(bevd_0);
case 152411771: return bem_libNameSet_1(bevd_0);
case -60689315: return bem_parseEmitTimeSet_1(bevd_0);
case -1452821944: return bem_saveIdsSet_1(bevd_0);
case -307955560: return bem_paramsSet_1(bevd_0);
case -953482711: return bem_printAstElementsSet_1(bevd_0);
case -530909464: return bem_deployPathSet_1(bevd_0);
case 910585205: return bem_runSet_1(bevd_0);
case -850371892: return bem_notEquals_1(bevd_0);
case -1207153457: return bem_twtokSet_1(bevd_0);
case 487253401: return bem_emitDebugSet_1(bevd_0);
case 638545686: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -393105689: return bem_undef_1(bevd_0);
case 787758648: return bem_includePathSet_1(bevd_0);
case 1130831615: return bem_parseTimeSet_1(bevd_0);
case 1267419746: return bem_def_1(bevd_0);
case 421465549: return bem_argsSet_1(bevd_0);
case 77778230: return bem_genOnlySet_1(bevd_0);
case -1988629114: return bem_lctokSet_1(bevd_0);
case 1575683994: return bem_makeSet_1(bevd_0);
case 723640587: return bem_extLinkObjectsSet_1(bevd_0);
case -911541014: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case -1590923538: return bem_emitFlagsSet_1(bevd_0);
case 135448242: return bem_printAstSet_1(bevd_0);
case 1295765079: return bem_startTimeSet_1(bevd_0);
case 2070254076: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -1930375520: return bem_closeLibrariesSet_1(bevd_0);
case 1005423377: return bem_compilerSet_1(bevd_0);
case 2048504287: return bem_makeArgsSet_1(bevd_0);
case -507196312: return bem_constantsSet_1(bevd_0);
case -650819365: return bem_saveSynsSet_1(bevd_0);
case -1225985778: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -559238061: return bem_equals_1(bevd_0);
case -1229272393: return bem_ntypesSet_1(bevd_0);
case -1647279733: return bem_deployFilesFromSet_1(bevd_0);
case 306987119: return bem_initLibsSet_1(bevd_0);
case -543923408: return bem_estrSet_1(bevd_0);
case 1912994635: return bem_platformSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2109827654: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2131432371: return bem_buildLiteral_2(bevd_0, bevd_1);
case -1822328732: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1733850915: return bem_getSyn_2(bevd_0, bevd_1);
case 347449110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -911952501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2006657938: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
